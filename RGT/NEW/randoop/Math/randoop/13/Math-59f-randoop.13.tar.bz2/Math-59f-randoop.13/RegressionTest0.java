import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        long long1 = org.apache.commons.math.util.FastMath.abs(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_INVALID;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 0, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9866275920404853d + "'", double1 == 0.9866275920404853d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_OVERFLOW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        double double2 = org.apache.commons.math.util.FastMath.pow(10.0d, (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E10d + "'", double2 == 1.0E10d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        double double1 = org.apache.commons.math.util.FastMath.log10((-1.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.36787944117144233d + "'", double1 == 0.36787944117144233d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        byte byte0 = org.apache.commons.math.dfp.Dfp.QNAN;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 3 + "'", byte0 == (byte) 3);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.99822295029797d + "'", double1 == 2.99822295029797d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-1L), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_DIV_ZERO;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (byte) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 171.88733853924697d + "'", double1 == 171.88733853924697d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_UNDERFLOW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 10.0f, (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.09966865249116202d + "'", double2 == 0.09966865249116202d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7853981633974483d) + "'", double1 == (-0.7853981633974483d));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int[] intArray2 = new int[] { (short) 10, (-1) };
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        mersenneTwister3.setSeed((long) (short) 1);
        double double6 = mersenneTwister3.nextGaussian();
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0019203836877835d + "'", double6 == 1.0019203836877835d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 3, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.36787944117144233d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.36787944117144233d + "'", double1 == 0.36787944117144233d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1 == 10.0f);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-0.7853981633974483d), 1.0019203836877835d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.6648420149633597d) + "'", double2 == (-0.6648420149633597d));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 4);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int0 = org.apache.commons.math.dfp.Dfp.ERR_SCALE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32760 + "'", int0 == 32760);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp5 = null;
        try {
            boolean boolean6 = dfp4.unequal(dfp5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (short) 10);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        long long2 = org.apache.commons.math.util.FastMath.max((long) '#', (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        int int0 = org.apache.commons.math.dfp.Dfp.RADIX;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10000 + "'", int0 == 10000);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.36787944117144233d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.38542559176909813d + "'", double1 == 0.38542559176909813d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.141592653589793d + "'", double1 == 3.141592653589793d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int0 = org.apache.commons.math.dfp.Dfp.MIN_EXP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-32767) + "'", int0 == (-32767));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        int int1 = org.apache.commons.math.util.FastMath.round(100.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        float float1 = org.apache.commons.math.util.FastMath.abs((-1.0f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { (byte) 1, (-1.0d) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable6 = mathIllegalArgumentException4.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNull(localizable6);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 'a', 0.9866275920404853d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 96.99999999999999d + "'", double2 == 96.99999999999999d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        double double1 = org.apache.commons.math.util.FastMath.acosh(4.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0634370688955608d + "'", double1 == 2.0634370688955608d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1622776601683795d + "'", double1 == 3.1622776601683795d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        byte byte0 = org.apache.commons.math.dfp.Dfp.SNAN;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 2 + "'", byte0 == (byte) 2);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.09966865249116202d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4636456564559829d + "'", double1 == 0.4636456564559829d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        double double1 = org.apache.commons.math.util.FastMath.log1p(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3978952727983707d + "'", double1 == 2.3978952727983707d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 0.9866275920404853d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9866275920404853d + "'", double2 == 0.9866275920404853d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 2, (long) 10000);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10000L + "'", long2 == 10000L);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        boolean boolean5 = dfp4.isNaN();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 'a');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 97L + "'", long1 == 97L);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 10.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        int int0 = org.apache.commons.math.dfp.Dfp.MAX_EXP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32768 + "'", int0 == 32768);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) 10, (float) (-4));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test064");
//        int[] intArray0 = null;
//        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(intArray0);
//        int int3 = mersenneTwister1.nextInt((int) '4');
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 43 + "'", int3 == 43);
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        double double1 = org.apache.commons.math.util.FastMath.cos(96.99999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9251475365964085d) + "'", double1 == (-0.9251475365964085d));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        int[] intArray2 = new int[] { (short) 10, (-1) };
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        double double4 = mersenneTwister3.nextDouble();
        java.lang.Class<?> wildcardClass5 = mersenneTwister3.getClass();
        long long6 = mersenneTwister3.nextLong();
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.8943285682649755d + "'", double4 == 0.8943285682649755d);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 5206088179365433653L + "'", long6 == 5206088179365433653L);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) 100);
        java.lang.String str3 = notStrictlyPositiveException2.toString();
        java.lang.Number number4 = notStrictlyPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        double[] doubleArray6 = dfp4.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp4.power10K(100);
        int int9 = dfp8.intValue();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2147483647 + "'", int9 == 2147483647);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        try {
            org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int int2 = org.apache.commons.math.util.FastMath.min(32760, 25);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25 + "'", int2 == 25);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        double double2 = org.apache.commons.math.util.FastMath.min((-0.9251475365964085d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9251475365964085d) + "'", double2 == (-0.9251475365964085d));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 32760, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.41782887182714457d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) 100);
        java.lang.String str3 = notStrictlyPositiveException2.toString();
        java.lang.Object[] objArray4 = notStrictlyPositiveException2.getArguments();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = new org.apache.commons.math.dfp.Dfp(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.getOne();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField15 = dfp14.getField();
        double[] doubleArray16 = dfp14.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.power10K(100);
        boolean boolean19 = dfp9.lessThan(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField21.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField21.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField25 = dfp24.getField();
        double[] doubleArray26 = dfp24.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp24.power10K(100);
        boolean boolean29 = dfp9.greaterThan(dfp28);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp28.multiply((int) (short) 1);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpField15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfpField25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(dfp31);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.getTwo();
        org.apache.commons.math.dfp.Dfp dfp8 = null;
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField10.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField14 = dfp13.getField();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp17 = new org.apache.commons.math.dfp.Dfp(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.getOne();
        try {
            org.apache.commons.math.dfp.Dfp dfp19 = dfp5.dotrap(2, "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)", dfp8, dfp18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpField14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 100L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_INEXACT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 1508871100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.13462759293782d + "'", double1 == 21.13462759293782d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.9866275920404853d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4070751110264852d + "'", double1 == 1.4070751110264852d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        int[] intArray6 = new int[] { (byte) -1, 0, (short) 0, 'a', (byte) 100, (short) 1 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        mersenneTwister7.setSeed(1);
        float float10 = mersenneTwister7.nextFloat();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.417022f + "'", float10 == 0.417022f);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 4, 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 43);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 43.0f + "'", float1 == 43.0f);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-1L), (float) 2147483647);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.14748365E9f + "'", float2 == 2.14748365E9f);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test089");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.9259609884950271d + "'", double0 == 0.9259609884950271d);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        byte byte0 = org.apache.commons.math.dfp.Dfp.FINITE;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 0 + "'", byte0 == (byte) 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-4), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        int[] intArray2 = new int[] { (short) 10, (-1) };
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        double double4 = mersenneTwister3.nextDouble();
        boolean boolean5 = mersenneTwister3.nextBoolean();
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.8943285682649755d + "'", double4 == 0.8943285682649755d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.getSqr3();
        int int12 = dfp11.classify();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp5.remainder(dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp5.rint();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp5.newInstance((byte) 3, (byte) 100);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2980.9579870417283d + "'", double1 == 2980.9579870417283d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = new org.apache.commons.math.dfp.Dfp(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.getOne();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField11.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField11.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp7.nextAfter(dfp17);
        java.lang.Object obj19 = null;
        boolean boolean20 = dfp17.equals(obj19);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getE();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField10.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField16.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.getSqr3();
        int int21 = dfp20.classify();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp14.remainder(dfp20);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp20.rint();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray26 = dfpField25.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField25.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField25.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray32 = dfpField31.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField31.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField31.getSqr3();
        int int36 = dfp35.classify();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp29.remainder(dfp35);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp35.rint();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp35.newInstance((long) (byte) 0);
        double[] doubleArray41 = dfp40.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp6.dotrap((-1), "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)", dfp20, dfp40);
        int int43 = dfp6.intValue();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfpArray26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfpArray32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 3 + "'", int43 == 3);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) '4');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 52L + "'", long1 == 52L);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        long long2 = org.apache.commons.math.util.FastMath.max((long) '#', 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 25);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 25.0d + "'", double1 == 25.0d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        double double1 = org.apache.commons.math.util.FastMath.cosh(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.591953275521519d + "'", double1 == 11.591953275521519d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.28222260952675615d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0049257137598122105d + "'", double1 == 0.0049257137598122105d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        double double1 = org.apache.commons.math.util.FastMath.expm1(2980.9579870417283d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) 100);
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.negate();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.negate();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 'a', 2.3978952727983707d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(11.591953275521519d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.59195327552152d + "'", double1 == 11.59195327552152d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        long long2 = org.apache.commons.math.util.FastMath.min(10L, (long) 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        double double1 = org.apache.commons.math.util.FastMath.asinh(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4422495703074083d + "'", double1 == 1.4422495703074083d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        byte byte0 = org.apache.commons.math.dfp.Dfp.INFINITE;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 1 + "'", byte0 == (byte) 1);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.8943285682649755d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) 100);
        java.lang.String str3 = notStrictlyPositiveException2.toString();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) (short) 100);
        java.lang.String str8 = notStrictlyPositiveException7.toString();
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException7.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (byte) 1, (-1.0d) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, objArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable9, objArray13);
        java.lang.Throwable[] throwableArray16 = mathIllegalArgumentException15.getSuppressed();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str8.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(throwableArray16);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 1508871100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.178652140405275d + "'", double1 == 9.178652140405275d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        int[] intArray2 = new int[] { (short) 10, (-1) };
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        double double4 = mersenneTwister3.nextDouble();
        java.lang.Class<?> wildcardClass5 = mersenneTwister3.getClass();
        float float6 = mersenneTwister3.nextFloat();
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.8943285682649755d + "'", double4 == 0.8943285682649755d);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.2822225f + "'", float6 == 0.2822225f);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5607966601082315d + "'", double1 == 1.5607966601082315d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        dfpField1.setIEEEFlagsBits(10000);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField1.getLn5Split();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfpArray10);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, (double) 0.4178288f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.4178287982940674d + "'", double2 == 0.4178287982940674d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) 100);
        java.lang.String str3 = notStrictlyPositiveException2.toString();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException2.getGeneralPattern();
        java.lang.Throwable[] throwableArray5 = notStrictlyPositiveException2.getSuppressed();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 25);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 25.0d + "'", double1 == 25.0d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField8.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField12 = dfp11.getField();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp15 = new org.apache.commons.math.dfp.Dfp(dfp14);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.getOne();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField18.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField22 = dfp21.getField();
        double[] doubleArray23 = dfp21.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp21.power10K(100);
        boolean boolean26 = dfp16.lessThan(dfp25);
        int int27 = dfp16.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField29.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray31 = dfpField29.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField29.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp4.dotrap((int) (byte) -1, "org.apache.commons.math.exception.MathIllegalArgumentException: ", dfp16, dfp32);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp33.getTwo();
        int int35 = dfp33.classify();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpField12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfpField22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 25 + "'", int27 == 25);
        org.junit.Assert.assertNotNull(dfpArray30);
        org.junit.Assert.assertNotNull(dfpArray31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.9251475365964085d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(97.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6929693744344998d + "'", double1 == 1.6929693744344998d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) 100);
        java.lang.String str3 = notStrictlyPositiveException2.toString();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) (short) 100);
        java.lang.String str8 = notStrictlyPositiveException7.toString();
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException7.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (byte) 1, (-1.0d) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, objArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable9, objArray13);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField17.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField17.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField23.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField23.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField23.getSqr3();
        int int28 = dfp27.classify();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp21.remainder(dfp27);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp27.getZero();
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray33 = dfpField32.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField32.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField36 = dfp35.getField();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField36.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp39 = new org.apache.commons.math.dfp.Dfp(dfp38);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp38.getOne();
        boolean boolean41 = dfp30.greaterThan(dfp38);
        java.lang.Object[] objArray42 = new java.lang.Object[] { dfp38 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException43 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, objArray42);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str8.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfpArray24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfpArray33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfpField36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(objArray42);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        int[] intArray2 = new int[] { (short) 10, (-1) };
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        float float5 = mersenneTwister4.nextFloat();
        double double6 = mersenneTwister4.nextGaussian();
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.8943285f + "'", float5 == 0.8943285f);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-0.0458130299611618d) + "'", double6 == (-0.0458130299611618d));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { (byte) 1, (-1.0d) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray3);
        java.lang.String str5 = mathIllegalArgumentException4.toString();
        java.lang.Throwable[] throwableArray6 = mathIllegalArgumentException4.getSuppressed();
        java.lang.Throwable[] throwableArray7 = mathIllegalArgumentException4.getSuppressed();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: " + "'", str5.equals("org.apache.commons.math.exception.MathIllegalArgumentException: "));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        dfpField1.setIEEEFlags((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField14.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField14.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.getSqr3();
        int int19 = dfp18.classify();
        int int20 = dfp18.classify();
        boolean boolean21 = dfp12.lessThan(dfp18);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { (byte) 1, (-1.0d) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray3);
        java.lang.String str5 = mathIllegalArgumentException4.toString();
        java.lang.Throwable[] throwableArray6 = mathIllegalArgumentException4.getSuppressed();
        java.lang.String str7 = mathIllegalArgumentException4.toString();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: " + "'", str5.equals("org.apache.commons.math.exception.MathIllegalArgumentException: "));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: " + "'", str7.equals("org.apache.commons.math.exception.MathIllegalArgumentException: "));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-0.6648420149633597d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8014417471111541d) + "'", double1 == (-0.8014417471111541d));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.4178287982940674d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        double double1 = org.apache.commons.math.util.FastMath.ulp(4.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 2.14748365E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.147483648E9d + "'", double1 == 2.147483648E9d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 43, (double) (-4));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 42.99999999999999d + "'", double2 == 42.99999999999999d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        int int1 = org.apache.commons.math.util.FastMath.abs(43);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 43 + "'", int1 == 43);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) 4);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 0.4178288f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.007292488239882743d + "'", double1 == 0.007292488239882743d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.getTwo();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp4.newInstance((byte) 0, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.power10((int) (short) 10);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp(2.99822295029797d);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        double double2 = org.apache.commons.math.util.FastMath.min(0.41782887182714457d, (double) 3);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.41782887182714457d + "'", double2 == 0.41782887182714457d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = new org.apache.commons.math.dfp.Dfp(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.getOne();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField11.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField11.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp7.nextAfter(dfp17);
        int int19 = dfp18.intValue();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) -1, 10000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        double double1 = org.apache.commons.math.util.FastMath.asin(2.3978952727983707d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField5.getLn5Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField5.getLn2Split();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) ' ');
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.28222260952675615d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2749609060237447d + "'", double1 == 0.2749609060237447d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) 100);
        java.lang.String str3 = notStrictlyPositiveException2.toString();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 100, (java.lang.Number) 171.88733853924697d, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 0L, (java.lang.Number) 2, false);
        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooSmallException12.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable13, (java.lang.Number) 0.09966865249116202d, (java.lang.Number) (-32767), true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        long long1 = org.apache.commons.math.util.FastMath.round((double) '#');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 35L + "'", long1 == 35L);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField5.getESplit();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        double double1 = org.apache.commons.math.util.FastMath.log(42.99999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.7612001156935624d + "'", double1 == 3.7612001156935624d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(2980.9579870417283d, (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2980.957987041728d + "'", double2 == 2980.957987041728d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        int int1 = org.apache.commons.math.util.FastMath.abs(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        int[] intArray6 = new int[] { (byte) -1, 0, (short) 0, 'a', (byte) 100, (short) 1 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        mersenneTwister7.setSeed((long) (short) 1);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 2.14748365E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        int int2 = org.apache.commons.math.util.FastMath.min(2, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (byte) 2, (double) 32768);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        int int2 = org.apache.commons.math.util.FastMath.min(0, 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.getSqr3();
        int int12 = dfp11.classify();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp5.remainder(dfp11);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField15.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.getTwo();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField15.newDfp((long) 4);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp11.nextAfter(dfp19);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(2147483647);
        boolean boolean2 = mersenneTwister1.nextBoolean();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 3);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3L + "'", long1 == 3L);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        double double1 = org.apache.commons.math.util.FastMath.asin(4.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        int[] intArray2 = new int[] { (short) 10, (-1) };
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        float float5 = mersenneTwister4.nextFloat();
        float float6 = mersenneTwister4.nextFloat();
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.8943285f + "'", float5 == 0.8943285f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.25900888f + "'", float6 == 0.25900888f);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.0E10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7453292519943297E8d + "'", double1 == 1.7453292519943297E8d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 0.25900888f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6374383972707328d + "'", double1 == 0.6374383972707328d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.09966865249116202d, 4.9E-324d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.09966865249116201d + "'", double2 == 0.09966865249116201d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        float float2 = org.apache.commons.math.util.FastMath.max(2.14748365E9f, 0.2822225f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.14748365E9f + "'", float2 == 2.14748365E9f);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { (byte) 1, (-1.0d) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray3);
        java.lang.String str5 = mathIllegalArgumentException4.toString();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException6 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException4);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathRuntimeException6.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: " + "'", str5.equals("org.apache.commons.math.exception.MathIllegalArgumentException: "));
        org.junit.Assert.assertNull(localizable7);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        int[] intArray2 = new int[] { (short) 10, (-1) };
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        mersenneTwister3.setSeed((long) (short) 1);
        boolean boolean6 = mersenneTwister3.nextBoolean();
        int int7 = mersenneTwister3.nextInt();
        double double8 = mersenneTwister3.nextDouble();
        mersenneTwister3.setSeed(10);
        double double11 = mersenneTwister3.nextDouble();
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1508871100 + "'", int7 == 1508871100);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.41782887182714457d + "'", double8 == 0.41782887182714457d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.77132064549269d + "'", double11 == 0.77132064549269d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        dfpField1.setIEEEFlags(0);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.0d + "'", double1 == 32.0d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        long long2 = org.apache.commons.math.util.FastMath.max((-1L), (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        double double1 = org.apache.commons.math.util.FastMath.signum(171.88733853924697d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 343.77467707849394d + "'", double1 == 343.77467707849394d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) 100);
        java.lang.String str3 = notStrictlyPositiveException2.toString();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 100, (java.lang.Number) 171.88733853924697d, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1L, (java.lang.Number) 4, false);
        boolean boolean13 = numberIsTooSmallException12.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 32768);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4879651793076247d + "'", double1 == 2.4879651793076247d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0049257137598122105d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5.313286089008626d) + "'", double1 == (-5.313286089008626d));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.017453292519943295d) + "'", double1 == (-0.017453292519943295d));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-4));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        double double2 = org.apache.commons.math.util.FastMath.min(8.881784197001252E-16d, (double) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8414709848078965d + "'", double1 == 0.8414709848078965d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 0.2822225f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0400898106232757d + "'", double1 == 1.0400898106232757d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getSqr2Split();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        int int10 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 25 + "'", int10 == 25);
        org.junit.Assert.assertNotNull(dfpArray11);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        float float1 = org.apache.commons.math.util.FastMath.abs(10.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1 == 10.0f);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.641588833612779d + "'", double1 == 4.641588833612779d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 2147483647);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.748066027288565E7d + "'", double1 == 3.748066027288565E7d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.newInstance((byte) 100, (byte) 100);
        boolean boolean10 = dfp6.isInfinite();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        long long2 = org.apache.commons.math.util.FastMath.max(10L, 35L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        double double1 = org.apache.commons.math.util.FastMath.cos(2.99822295029797d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.989740156313126d) + "'", double1 == (-0.989740156313126d));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        double double2 = org.apache.commons.math.util.FastMath.min(0.4178287982940674d, 1.4070751110264852d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.4178287982940674d + "'", double2 == 0.4178287982940674d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        int int10 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp((long) 8);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.getLn2();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 25 + "'", int10 == 25);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.4422495703074083d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        dfpField1.setIEEEFlags((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField12.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.getTwo();
        boolean boolean17 = dfp10.lessThan(dfp16);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 1508871100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5088711000000002E9d + "'", double1 == 1.5088711000000002E9d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 1.4422495703074083d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        int[] intArray4 = new int[] { 2, 43, 'a', 32760 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (byte) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.47712125471966244d + "'", double1 == 0.47712125471966244d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        int[] intArray2 = new int[] { (short) 10, (-1) };
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        double double4 = mersenneTwister3.nextDouble();
        double double5 = mersenneTwister3.nextDouble();
        double double6 = mersenneTwister3.nextGaussian();
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.8943285682649755d + "'", double4 == 0.8943285682649755d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.28222260952675615d + "'", double5 == 0.28222260952675615d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-0.21502679675769548d) + "'", double6 == (-0.21502679675769548d));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 10L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) 100);
        java.lang.String str3 = notStrictlyPositiveException2.toString();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) (short) 100);
        java.lang.String str8 = notStrictlyPositiveException7.toString();
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException7.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (byte) 1, (-1.0d) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, objArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable9, objArray13);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable16, (java.lang.Number) (short) 100);
        java.lang.String str19 = notStrictlyPositiveException18.toString();
        org.apache.commons.math.exception.util.Localizable localizable20 = notStrictlyPositiveException18.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable20, (java.lang.Number) 100, (java.lang.Number) 171.88733853924697d, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable20, (java.lang.Number) 0L, (java.lang.Number) 2, false);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray31 = dfpField30.getLn5Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable20, (java.lang.Object[]) dfpArray31);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException36 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) 0.417022f, (java.lang.Number) 0.0049257137598122105d, true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str8.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str19.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfpArray31);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        dfpField1.setIEEEFlagsBits(10000);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField11.getPiSplit();
        dfpField11.setIEEEFlagsBits(10000);
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField11.getESplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode20 = dfpField11.getRoundingMode();
        dfpField1.setRoundingMode(roundingMode20);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertTrue("'" + roundingMode20 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode20.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.getTwo();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp4.newInstance((byte) 0, (byte) 100);
        double double9 = dfp4.toDouble();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.getZero();
        int int11 = dfp10.log10K();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + Double.NEGATIVE_INFINITY + "'", double9 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8623188722876839d + "'", double1 == 0.8623188722876839d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) 100);
        java.lang.String str3 = notStrictlyPositiveException2.toString();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 100, (java.lang.Number) 171.88733853924697d, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1L, (java.lang.Number) 4, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) (short) 10, (java.lang.Number) 0.0d, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 1.5088711000000002E9d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        dfpField1.setIEEEFlags((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getOne();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 32760, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32760L + "'", long2 == 32760L);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        double double1 = org.apache.commons.math.util.FastMath.log(2.4879651793076247d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.911465179323861d + "'", double1 == 0.911465179323861d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        double double1 = org.apache.commons.math.util.FastMath.log(0.8943285682649755d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.11168204530630596d) + "'", double1 == (-0.11168204530630596d));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { (byte) 1, (-1.0d) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray3);
        java.lang.String str5 = mathIllegalArgumentException4.toString();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException6 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException4);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) (short) 100);
        java.lang.String str10 = notStrictlyPositiveException9.toString();
        org.apache.commons.math.exception.util.Localizable localizable11 = notStrictlyPositiveException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable12, (java.lang.Number) (short) 100);
        java.lang.String str15 = notStrictlyPositiveException14.toString();
        org.apache.commons.math.exception.util.Localizable localizable16 = notStrictlyPositiveException14.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { (byte) 1, (-1.0d) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable16, objArray20);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException25 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable23, (java.lang.Number) (short) 100);
        java.lang.String str26 = notStrictlyPositiveException25.toString();
        org.apache.commons.math.exception.util.Localizable localizable27 = notStrictlyPositiveException25.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException31 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable27, (java.lang.Number) 100, (java.lang.Number) 171.88733853924697d, false);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException35 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable33, (java.lang.Number) (short) 100);
        java.lang.String str36 = notStrictlyPositiveException35.toString();
        org.apache.commons.math.exception.util.Localizable localizable37 = notStrictlyPositiveException35.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException41 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable37, (java.lang.Number) 100, (java.lang.Number) 171.88733853924697d, false);
        java.lang.Object[] objArray44 = new java.lang.Object[] { (-0.7853981633974483d), 171.88733853924697d, 1, (short) 100 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException45 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException6, localizable16, localizable27, objArray44);
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException48 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable46, (java.lang.Number) (short) 100);
        java.lang.String str49 = notStrictlyPositiveException48.toString();
        org.apache.commons.math.exception.util.Localizable localizable50 = notStrictlyPositiveException48.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException54 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable50, (java.lang.Number) 100, (java.lang.Number) 171.88733853924697d, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException58 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable50, (java.lang.Number) 0L, (java.lang.Number) 2, false);
        java.lang.Object[] objArray59 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException60 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable27, localizable50, objArray59);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException62 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable50, (java.lang.Number) 0);
        java.lang.String str63 = notStrictlyPositiveException62.toString();
        java.lang.Number number64 = notStrictlyPositiveException62.getMin();
        org.apache.commons.math.exception.util.Localizable localizable65 = null;
        java.lang.Object[] objArray68 = new java.lang.Object[] { (byte) 1, (-1.0d) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException69 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable65, objArray68);
        java.lang.String str70 = mathIllegalArgumentException69.toString();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException71 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException69);
        org.apache.commons.math.exception.util.Localizable localizable72 = mathIllegalArgumentException69.getSpecificPattern();
        notStrictlyPositiveException62.addSuppressed((java.lang.Throwable) mathIllegalArgumentException69);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: " + "'", str5.equals("org.apache.commons.math.exception.MathIllegalArgumentException: "));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str10.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str15.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str26.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str36.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str49.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable50 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable50.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0): 0 is smaller than, or equal to, the minimum (0)" + "'", str63.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0): 0 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number64 + "' != '" + 0 + "'", number64.equals(0));
        org.junit.Assert.assertNotNull(objArray68);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: " + "'", str70.equals("org.apache.commons.math.exception.MathIllegalArgumentException: "));
        org.junit.Assert.assertNull(localizable72);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { (byte) 1, (-1.0d) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray3);
        java.lang.String str5 = mathIllegalArgumentException4.toString();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException6 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException4);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) (short) 100);
        java.lang.String str10 = notStrictlyPositiveException9.toString();
        org.apache.commons.math.exception.util.Localizable localizable11 = notStrictlyPositiveException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable12, (java.lang.Number) (short) 100);
        java.lang.String str15 = notStrictlyPositiveException14.toString();
        org.apache.commons.math.exception.util.Localizable localizable16 = notStrictlyPositiveException14.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { (byte) 1, (-1.0d) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable16, objArray20);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException25 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable23, (java.lang.Number) (short) 100);
        java.lang.String str26 = notStrictlyPositiveException25.toString();
        org.apache.commons.math.exception.util.Localizable localizable27 = notStrictlyPositiveException25.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException31 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable27, (java.lang.Number) 100, (java.lang.Number) 171.88733853924697d, false);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException35 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable33, (java.lang.Number) (short) 100);
        java.lang.String str36 = notStrictlyPositiveException35.toString();
        org.apache.commons.math.exception.util.Localizable localizable37 = notStrictlyPositiveException35.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException41 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable37, (java.lang.Number) 100, (java.lang.Number) 171.88733853924697d, false);
        java.lang.Object[] objArray44 = new java.lang.Object[] { (-0.7853981633974483d), 171.88733853924697d, 1, (short) 100 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException45 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException6, localizable16, localizable27, objArray44);
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException48 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable46, (java.lang.Number) (short) 100);
        java.lang.String str49 = notStrictlyPositiveException48.toString();
        org.apache.commons.math.exception.util.Localizable localizable50 = notStrictlyPositiveException48.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException54 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable50, (java.lang.Number) 100, (java.lang.Number) 171.88733853924697d, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException58 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable50, (java.lang.Number) 0L, (java.lang.Number) 2, false);
        java.lang.Object[] objArray59 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException60 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable27, localizable50, objArray59);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException62 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable50, (java.lang.Number) 0);
        java.lang.String str63 = notStrictlyPositiveException62.toString();
        java.lang.Number number64 = notStrictlyPositiveException62.getMin();
        org.apache.commons.math.exception.util.Localizable localizable65 = notStrictlyPositiveException62.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: " + "'", str5.equals("org.apache.commons.math.exception.MathIllegalArgumentException: "));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str10.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str15.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str26.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str36.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str49.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable50 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable50.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0): 0 is smaller than, or equal to, the minimum (0)" + "'", str63.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0): 0 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number64 + "' != '" + 0 + "'", number64.equals(0));
        org.junit.Assert.assertTrue("'" + localizable65 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable65.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.0E10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 10L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (short) 100, 52L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getOne();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = dfpField5.getRoundingMode();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode9.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.getTwo();
        org.apache.commons.math.dfp.Dfp dfp6 = new org.apache.commons.math.dfp.Dfp(dfp4);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField8.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.getTwo();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp6.add(dfp11);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.newInstance((byte) 3);
        java.lang.String str16 = dfp13.toString();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0." + "'", str16.equals("0."));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        int[] intArray2 = new int[] { (short) 10, (-1) };
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        double double4 = mersenneTwister3.nextDouble();
        int int5 = mersenneTwister3.nextInt();
        mersenneTwister3.setSeed(1);
        float float8 = mersenneTwister3.nextFloat();
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.8943285682649755d + "'", double4 == 0.8943285682649755d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1212136861 + "'", int5 == 1212136861);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.417022f + "'", float8 == 0.417022f);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField5.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField5.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.getSqr3();
        int int16 = dfp15.classify();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp9.remainder(dfp15);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp15.getZero();
        org.apache.commons.math.dfp.Dfp dfp19 = org.apache.commons.math.dfp.Dfp.copysign(dfp3, dfp18);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        int int8 = dfp7.getRadixDigits();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 25 + "'", int8 == 25);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance((long) 43);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = new org.apache.commons.math.dfp.Dfp(dfp5);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.newInstance();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 10L, (java.lang.Number) 1.2527237975288865d, false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.0049257137598122105d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.004925673923232586d + "'", double1 == 0.004925673923232586d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.8943285682649755d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = new org.apache.commons.math.dfp.Dfp(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.getOne();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField15 = dfp14.getField();
        double[] doubleArray16 = dfp14.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.power10K(100);
        boolean boolean19 = dfp9.lessThan(dfp18);
        int int20 = dfp18.intValue();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp18.getTwo();
        org.apache.commons.math.dfp.Dfp dfp22 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp23 = dfp21.subtract(dfp22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpField15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2147483647 + "'", int20 == 2147483647);
        org.junit.Assert.assertNotNull(dfp21);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        int[] intArray2 = new int[] { (short) 10, (-1) };
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        float float5 = mersenneTwister4.nextFloat();
        boolean boolean6 = mersenneTwister4.nextBoolean();
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.8943285f + "'", float5 == 0.8943285f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) 100);
        java.lang.String str3 = notStrictlyPositiveException2.toString();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 100, (java.lang.Number) 171.88733853924697d, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1L, (java.lang.Number) 4, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 0.5090805323561498d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.0E10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 23.7189981105004d + "'", double1 == 23.7189981105004d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.getSqr3();
        int int12 = dfp11.classify();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp5.remainder(dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.getZero();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField16.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField20 = dfp19.getField();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp23 = new org.apache.commons.math.dfp.Dfp(dfp22);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.getOne();
        boolean boolean25 = dfp14.greaterThan(dfp22);
        org.apache.commons.math.dfp.Dfp dfp26 = new org.apache.commons.math.dfp.Dfp(dfp14);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfpField20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-32767));
        double double2 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0870848052070263d + "'", double2 == 1.0870848052070263d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 1);
        double double2 = mersenneTwister1.nextDouble();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.4170220046815991d + "'", double2 == 0.4170220046815991d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField8.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField8.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField8.newDfp("hi!");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode16 = dfpField8.getRoundingMode();
        dfpField5.setRoundingMode(roundingMode16);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + roundingMode16 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode16.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9893582466233818d + "'", double1 == 0.9893582466233818d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        double double1 = org.apache.commons.math.util.FastMath.atan(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(21.13462759293782d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.597241302448439d + "'", double1 == 4.597241302448439d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        dfpField1.setIEEEFlagsBits((int) (short) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = new org.apache.commons.math.dfp.Dfp(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField12.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField12.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField18.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField18.getSqr3();
        int int23 = dfp22.classify();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp16.remainder(dfp22);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp22.rint();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp22.newInstance((long) (byte) 0);
        double[] doubleArray28 = dfp27.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray31 = dfpField30.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField30.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp34 = dfp33.getTwo();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp27.add(dfp34);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray38 = dfpField37.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField37.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField37.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray44 = dfpField43.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField43.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField43.getSqr3();
        int int48 = dfp47.classify();
        org.apache.commons.math.dfp.Dfp dfp49 = dfp41.remainder(dfp47);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp47.rint();
        org.apache.commons.math.dfp.Dfp dfp52 = dfp50.newInstance(5206088179365433653L);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp7.dotrap(0, "0.", dfp35, dfp52);
        boolean boolean54 = dfp7.isNaN();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(dfpArray31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfpArray38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfpArray44);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.9893582466233818d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9964400909602754d + "'", double1 == 0.9964400909602754d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getOne();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10(4);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = new org.apache.commons.math.dfp.Dfp(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.getOne();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField15 = dfp14.getField();
        double[] doubleArray16 = dfp14.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.power10K(100);
        boolean boolean19 = dfp9.lessThan(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField21.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField21.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField25 = dfp24.getField();
        double[] doubleArray26 = dfp24.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp24.power10K(100);
        boolean boolean29 = dfp9.greaterThan(dfp28);
        org.apache.commons.math.dfp.Dfp dfp30 = null;
        try {
            boolean boolean31 = dfp28.unequal(dfp30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpField15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfpField25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { (byte) 1, (-1.0d) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException6 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException4);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathRuntimeException6.getSpecificPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException8 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException6);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNull(localizable7);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        double double2 = org.apache.commons.math.util.FastMath.max(1.5088711000000002E9d, (double) 3L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5088711000000002E9d + "'", double2 == 1.5088711000000002E9d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.getSqr3();
        int int12 = dfp11.classify();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp5.remainder(dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.rint();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp11.newInstance((long) (byte) 0);
        double[] doubleArray17 = dfp16.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray20 = dfpField19.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp23 = dfp22.getTwo();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp16.add(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray27 = dfpField26.getLn5Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField26.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.getPi();
        org.apache.commons.math.dfp.Dfp dfp30 = org.apache.commons.math.dfp.Dfp.copysign(dfp16, dfp29);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp29.negate();
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray34 = dfpField33.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField37 = dfp36.getField();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField37.getE();
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray43 = dfpField42.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField42.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField42.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray49 = dfpField48.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField48.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField48.getSqr3();
        int int53 = dfp52.classify();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp46.remainder(dfp52);
        org.apache.commons.math.dfp.Dfp dfp55 = dfp52.rint();
        org.apache.commons.math.dfp.DfpField dfpField57 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray58 = dfpField57.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField57.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField57.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField63 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray64 = dfpField63.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp66 = dfpField63.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField63.getSqr3();
        int int68 = dfp67.classify();
        org.apache.commons.math.dfp.Dfp dfp69 = dfp61.remainder(dfp67);
        org.apache.commons.math.dfp.Dfp dfp70 = dfp67.rint();
        org.apache.commons.math.dfp.Dfp dfp72 = dfp67.newInstance((long) (byte) 0);
        double[] doubleArray73 = dfp72.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp74 = dfp38.dotrap((-1), "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)", dfp52, dfp72);
        boolean boolean75 = dfp29.greaterThan(dfp38);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(dfpArray20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfpArray27);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfpArray34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfpField37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfpArray43);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfpArray49);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfpArray58);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfpArray64);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        int[] intArray2 = new int[] { (short) 10, (-1) };
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        mersenneTwister3.setSeed((long) (short) 1);
        boolean boolean6 = mersenneTwister3.nextBoolean();
        int int7 = mersenneTwister3.nextInt();
        double double8 = mersenneTwister3.nextDouble();
        boolean boolean9 = mersenneTwister3.nextBoolean();
        double double10 = mersenneTwister3.nextGaussian();
        int int12 = mersenneTwister3.nextInt(43);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1508871100 + "'", int7 == 1508871100);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.41782887182714457d + "'", double8 == 0.41782887182714457d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.5090805323561498d + "'", double10 == 0.5090805323561498d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 33 + "'", int12 == 33);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        int[] intArray6 = new int[] { (byte) -1, 0, (short) 0, 'a', (byte) 100, (short) 1 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        mersenneTwister7.setSeed(1);
        long long10 = mersenneTwister7.nextLong();
        mersenneTwister7.setSeed((-1L));
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 7692698082559361259L + "'", long10 == 7692698082559361259L);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        int[] intArray2 = new int[] { (short) 10, (-1) };
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        mersenneTwister3.setSeed((long) (short) 1);
        boolean boolean6 = mersenneTwister3.nextBoolean();
        mersenneTwister3.setSeed((long) 1);
        byte[] byteArray12 = new byte[] { (byte) 10, (byte) 3, (byte) 3 };
        mersenneTwister3.nextBytes(byteArray12);
        double double14 = mersenneTwister3.nextGaussian();
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-0.21841921301152d) + "'", double14 == (-0.21841921301152d));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        int[] intArray2 = new int[] { (short) 10, (-1) };
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        mersenneTwister3.setSeed((long) (short) 1);
        boolean boolean6 = mersenneTwister3.nextBoolean();
        int int8 = mersenneTwister3.nextInt(25);
        double double9 = mersenneTwister3.nextDouble();
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.9347212764125521d + "'", double9 == 0.9347212764125521d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        int int8 = dfp7.log10K();
        org.apache.commons.math.dfp.Dfp dfp9 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp10 = dfp7.multiply(dfp9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.getTwo();
        org.apache.commons.math.dfp.Dfp dfp6 = new org.apache.commons.math.dfp.Dfp(dfp4);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField8.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.getTwo();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp6.add(dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.getOne();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 2147483647);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22.180709777452588d + "'", double1 == 22.180709777452588d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (byte) 2, (-0.017453292519943295d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9879751824754919d + "'", double2 == 0.9879751824754919d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        double double1 = org.apache.commons.math.util.FastMath.signum(97.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        double double1 = org.apache.commons.math.util.FastMath.asin(11.591953275521519d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) 100);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable3, (java.lang.Number) (short) 100);
        java.lang.String str6 = notStrictlyPositiveException5.toString();
        org.apache.commons.math.exception.util.Localizable localizable7 = notStrictlyPositiveException5.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) (short) 100);
        java.lang.String str11 = notStrictlyPositiveException10.toString();
        org.apache.commons.math.exception.util.Localizable localizable12 = notStrictlyPositiveException10.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { (byte) 1, (-1.0d) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, objArray16);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable12, objArray16);
        notStrictlyPositiveException2.addSuppressed((java.lang.Throwable) mathIllegalArgumentException18);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str6.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str11.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray16);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        dfpField1.setIEEEFlags((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.getOne();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = new org.apache.commons.math.dfp.Dfp(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.getOne();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField15 = dfp14.getField();
        double[] doubleArray16 = dfp14.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.power10K(100);
        boolean boolean19 = dfp9.lessThan(dfp18);
        int int20 = dfp18.intValue();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp18.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField23.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField23.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp27 = dfp26.getTwo();
        org.apache.commons.math.dfp.Dfp dfp28 = new org.apache.commons.math.dfp.Dfp(dfp26);
        org.apache.commons.math.dfp.Dfp dfp29 = org.apache.commons.math.dfp.Dfp.copysign(dfp21, dfp28);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp29.power10((-32767));
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpField15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2147483647 + "'", int20 == 2147483647);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfpArray24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) 1, (float) 2);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        int int2 = org.apache.commons.math.util.FastMath.min((-4), (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-4) + "'", int2 == (-4));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        int[] intArray2 = new int[] { (short) 10, (-1) };
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        mersenneTwister3.setSeed((long) (short) 1);
        boolean boolean6 = mersenneTwister3.nextBoolean();
        int int7 = mersenneTwister3.nextInt();
        mersenneTwister3.setSeed(0);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1508871100 + "'", int7 == 1508871100);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        dfpField1.setIEEEFlags((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((double) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getOne();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        float float2 = org.apache.commons.math.util.FastMath.min(100.0f, (float) 100L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        int[] intArray0 = null;
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(intArray0);
        mersenneTwister1.setSeed((long) 43);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(3);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = null;
        dfpField1.setRoundingMode(roundingMode2);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        double double1 = org.apache.commons.math.util.FastMath.signum(3.748066027288565E7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.getSqr3();
        int int12 = dfp11.classify();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp5.remainder(dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.rint();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp11.newInstance((long) (byte) 0);
        double[] doubleArray17 = dfp16.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray20 = dfpField19.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp23 = dfp22.getTwo();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp16.add(dfp23);
        boolean boolean25 = dfp16.isInfinite();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(dfpArray20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.getZero();
        double[] doubleArray8 = dfp6.toSplitDouble();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.4170220046815991d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4430053915591428d + "'", double1 == 0.4430053915591428d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.getTwo();
        org.apache.commons.math.dfp.Dfp dfp6 = new org.apache.commons.math.dfp.Dfp(dfp4);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.newInstance((byte) 0, (byte) 1);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        double double1 = org.apache.commons.math.util.FastMath.ceil(9.178652140405275d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp(0L);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn5();
        dfpField1.setIEEEFlagsBits((-1));
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(1.0019203836877835d);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getPi();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        int[] intArray2 = new int[] { (short) 10, (-1) };
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        mersenneTwister3.setSeed((long) (short) 1);
        boolean boolean6 = mersenneTwister3.nextBoolean();
        int int7 = mersenneTwister3.nextInt();
        float float8 = mersenneTwister3.nextFloat();
        mersenneTwister3.setSeed(32768);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1508871100 + "'", int7 == 1508871100);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.4178288f + "'", float8 == 0.4178288f);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) 100);
        java.lang.String str3 = notStrictlyPositiveException2.toString();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 100, (java.lang.Number) 171.88733853924697d, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1L, (java.lang.Number) 4, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) (short) 10, (java.lang.Number) 0.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException19 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable17, (java.lang.Number) (short) 100);
        java.lang.String str20 = notStrictlyPositiveException19.toString();
        org.apache.commons.math.exception.util.Localizable localizable21 = notStrictlyPositiveException19.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException25 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable21, (java.lang.Number) 100, (java.lang.Number) 171.88733853924697d, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable21, (java.lang.Number) 0L, (java.lang.Number) 2, false);
        org.apache.commons.math.exception.util.Localizable localizable30 = numberIsTooSmallException29.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException33 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable31, (java.lang.Number) (short) 100);
        java.lang.String str34 = notStrictlyPositiveException33.toString();
        org.apache.commons.math.exception.util.Localizable localizable35 = notStrictlyPositiveException33.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException39 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable35, (java.lang.Number) 100, (java.lang.Number) 171.88733853924697d, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException43 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable35, (java.lang.Number) 0L, (java.lang.Number) 2, false);
        org.apache.commons.math.exception.util.Localizable localizable44 = numberIsTooSmallException43.getSpecificPattern();
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray47 = dfpField46.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField46.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField46.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray51 = dfpField46.getPiSplit();
        dfpField46.setIEEEFlagsBits(10000);
        org.apache.commons.math.dfp.Dfp[] dfpArray54 = dfpField46.getESplit();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException55 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException16, localizable30, localizable44, (java.lang.Object[]) dfpArray54);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException57 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 4);
        boolean boolean58 = notStrictlyPositiveException57.getBoundIsAllowed();
        numberIsTooSmallException16.addSuppressed((java.lang.Throwable) notStrictlyPositiveException57);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException63 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.0d, (java.lang.Number) 0.9866275920404853d, false);
        java.lang.String str64 = numberIsTooSmallException63.toString();
        numberIsTooSmallException16.addSuppressed((java.lang.Throwable) numberIsTooSmallException63);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str20.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str34.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable35.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable44.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfpArray47);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfpArray51);
        org.junit.Assert.assertNotNull(dfpArray54);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 0 is smaller than, or equal to, the minimum (0.987)" + "'", str64.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 0 is smaller than, or equal to, the minimum (0.987)"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 7692698082559361259L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 7.6926979E18f + "'", float1 == 7.6926979E18f);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        int[] intArray2 = new int[] { (short) 10, (-1) };
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        float float5 = mersenneTwister4.nextFloat();
        int[] intArray8 = new int[] { (short) 10, (-1) };
        org.apache.commons.math.random.MersenneTwister mersenneTwister9 = new org.apache.commons.math.random.MersenneTwister(intArray8);
        mersenneTwister4.setSeed(intArray8);
        double double11 = mersenneTwister4.nextDouble();
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.8943285f + "'", float5 == 0.8943285f);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.8943285682649755d + "'", double11 == 0.8943285682649755d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.getSqr3();
        int int12 = dfp11.classify();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp5.remainder(dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.rint();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp11.newInstance((long) (byte) 0);
        double[] doubleArray17 = dfp16.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray20 = dfpField19.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp23 = dfp22.getTwo();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp16.add(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray27 = dfpField26.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField30 = dfp29.getField();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField30.newDfp((long) 4);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp23.multiply(dfp33);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray37 = dfpField36.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField36.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField40 = dfp39.getField();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField40.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField40.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp43 = new org.apache.commons.math.dfp.Dfp(dfp42);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp42.getOne();
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray47 = dfpField46.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField46.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField50 = dfp49.getField();
        double[] doubleArray51 = dfp49.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp49.power10K(100);
        boolean boolean54 = dfp44.lessThan(dfp53);
        int int55 = dfp53.intValue();
        org.apache.commons.math.dfp.DfpField dfpField57 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray58 = dfpField57.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField57.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField57.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray62 = dfpField57.getPiSplit();
        dfpField57.setIEEEFlags((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp66 = dfpField57.newDfp((byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField68 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray69 = dfpField68.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField68.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField72 = dfp71.getField();
        double[] doubleArray73 = dfp71.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp75 = dfp71.power10K(100);
        org.apache.commons.math.dfp.Dfp dfp76 = dfp75.getZero();
        org.apache.commons.math.dfp.Dfp dfp77 = dfpField57.newDfp(dfp76);
        org.apache.commons.math.dfp.Dfp dfp78 = dfp53.multiply(dfp77);
        org.apache.commons.math.dfp.Dfp dfp79 = dfp33.subtract(dfp53);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(dfpArray20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfpArray27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfpField30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfpArray37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfpField40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfpArray47);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfpField50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2147483647 + "'", int55 == 2147483647);
        org.junit.Assert.assertNotNull(dfpArray58);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfpArray62);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfpArray69);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfpField72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertNotNull(dfp79);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        int int6 = dfp5.classify();
        int int7 = dfp5.classify();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp5.rint();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance("0.");
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField12.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField12.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField18.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField18.getSqr3();
        int int23 = dfp22.classify();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp16.remainder(dfp22);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp22.rint();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField27.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField27.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.getTwo();
        org.apache.commons.math.dfp.Dfp dfp32 = new org.apache.commons.math.dfp.Dfp(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray35 = dfpField34.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField34.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp38 = dfp37.getTwo();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp32.add(dfp37);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray42 = dfpField41.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField41.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField41.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray48 = dfpField47.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField47.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField47.getSqr3();
        int int52 = dfp51.classify();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp45.remainder(dfp51);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp51.rint();
        org.apache.commons.math.dfp.Dfp dfp56 = dfp51.newInstance((long) (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp57 = dfp39.add(dfp51);
        org.apache.commons.math.dfp.Dfp dfp58 = dfp22.multiply(dfp51);
        org.apache.commons.math.dfp.Dfp dfp59 = org.apache.commons.math.dfp.Dfp.copysign(dfp8, dfp51);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfpArray35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfpArray42);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfpArray48);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.getSqr3();
        int int12 = dfp11.classify();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp5.remainder(dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.rint();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.newInstance(5206088179365433653L);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.floor();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray20 = dfpField19.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField23 = dfp22.getField();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField23.newDfp((long) 4);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray29 = dfpField28.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField28.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField32 = dfp31.getField();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField32.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField32.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp35 = new org.apache.commons.math.dfp.Dfp(dfp34);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp34.getOne();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray39 = dfpField38.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField38.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField38.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField38.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField38.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp34.nextAfter(dfp44);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp26.newInstance(dfp34);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray49 = dfpField48.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField48.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField48.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray55 = dfpField54.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField54.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField54.getSqr3();
        int int59 = dfp58.classify();
        org.apache.commons.math.dfp.Dfp dfp60 = dfp52.remainder(dfp58);
        org.apache.commons.math.dfp.Dfp dfp61 = dfp58.rint();
        org.apache.commons.math.dfp.Dfp dfp62 = dfp26.subtract(dfp58);
        org.apache.commons.math.dfp.DfpField dfpField64 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray65 = dfpField64.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField64.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField64.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField70 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray71 = dfpField70.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField70.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp74 = dfpField70.getSqr3();
        int int75 = dfp74.classify();
        org.apache.commons.math.dfp.Dfp dfp76 = dfp68.remainder(dfp74);
        org.apache.commons.math.dfp.Dfp dfp77 = dfp74.rint();
        org.apache.commons.math.dfp.Dfp dfp79 = dfp74.newInstance((long) (byte) 0);
        double[] doubleArray80 = dfp79.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField82 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray83 = dfpField82.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp85 = dfpField82.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp86 = dfp85.getTwo();
        org.apache.commons.math.dfp.Dfp dfp87 = dfp79.add(dfp86);
        org.apache.commons.math.dfp.DfpField dfpField89 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray90 = dfpField89.getLn5Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray91 = dfpField89.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp92 = dfpField89.getPi();
        org.apache.commons.math.dfp.Dfp dfp93 = org.apache.commons.math.dfp.Dfp.copysign(dfp79, dfp92);
        org.apache.commons.math.dfp.Dfp dfp94 = dfp79.getOne();
        boolean boolean95 = dfp62.unequal(dfp79);
        org.apache.commons.math.dfp.Dfp dfp96 = dfp16.nextAfter(dfp62);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfpArray20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfpField23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfpArray29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfpField32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfpArray39);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfpArray49);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfpArray55);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfpArray65);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfpArray71);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertNotNull(dfp79);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(dfpArray83);
        org.junit.Assert.assertNotNull(dfp85);
        org.junit.Assert.assertNotNull(dfp86);
        org.junit.Assert.assertNotNull(dfp87);
        org.junit.Assert.assertNotNull(dfpArray90);
        org.junit.Assert.assertNotNull(dfpArray91);
        org.junit.Assert.assertNotNull(dfp92);
        org.junit.Assert.assertNotNull(dfp93);
        org.junit.Assert.assertNotNull(dfp94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + true + "'", boolean95 == true);
        org.junit.Assert.assertNotNull(dfp96);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-32767), (float) 32760L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32760.0f + "'", float2 == 32760.0f);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        double double1 = org.apache.commons.math.util.FastMath.sin(11.59195327552152d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8273747768554842d) + "'", double1 == (-0.8273747768554842d));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.5088711000000002E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.13462759293782d + "'", double1 == 21.13462759293782d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        double double1 = org.apache.commons.math.util.FastMath.abs(3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1622776601683795d + "'", double1 == 3.1622776601683795d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-0.9251475365964085d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.592236257454434d) + "'", double1 == (-2.592236257454434d));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) 11.59195327552152d, true);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 2L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.9964400909602754d, (double) (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9964400909602753d + "'", double2 == 0.9964400909602753d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) 'a');
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-32767));
        int[] intArray4 = new int[] { (short) 10, (-1) };
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        mersenneTwister1.setSeed(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        dfpField1.setIEEEFlags((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp(32760);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.sqrt();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp1 = new org.apache.commons.math.dfp.Dfp(dfp0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = new org.apache.commons.math.dfp.Dfp(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.getOne();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField15 = dfp14.getField();
        double[] doubleArray16 = dfp14.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.power10K(100);
        boolean boolean19 = dfp9.lessThan(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField21.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField21.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField25 = dfp24.getField();
        double[] doubleArray26 = dfp24.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp24.power10K(100);
        boolean boolean29 = dfp9.greaterThan(dfp28);
        int int30 = dfp9.intValue();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp9.newInstance("org.apache.commons.math.exception.NumberIsTooSmallException: 0 is smaller than, or equal to, the minimum (0.987)");
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpField15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfpField25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(dfp32);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { (byte) 1, (-1.0d) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray3);
        java.lang.String str5 = mathIllegalArgumentException4.toString();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException6 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException4);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) (short) 100);
        java.lang.String str10 = notStrictlyPositiveException9.toString();
        org.apache.commons.math.exception.util.Localizable localizable11 = notStrictlyPositiveException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable12, (java.lang.Number) (short) 100);
        java.lang.String str15 = notStrictlyPositiveException14.toString();
        org.apache.commons.math.exception.util.Localizable localizable16 = notStrictlyPositiveException14.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { (byte) 1, (-1.0d) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable16, objArray20);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException25 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable23, (java.lang.Number) (short) 100);
        java.lang.String str26 = notStrictlyPositiveException25.toString();
        org.apache.commons.math.exception.util.Localizable localizable27 = notStrictlyPositiveException25.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException31 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable27, (java.lang.Number) 100, (java.lang.Number) 171.88733853924697d, false);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException35 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable33, (java.lang.Number) (short) 100);
        java.lang.String str36 = notStrictlyPositiveException35.toString();
        org.apache.commons.math.exception.util.Localizable localizable37 = notStrictlyPositiveException35.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException41 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable37, (java.lang.Number) 100, (java.lang.Number) 171.88733853924697d, false);
        java.lang.Object[] objArray44 = new java.lang.Object[] { (-0.7853981633974483d), 171.88733853924697d, 1, (short) 100 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException45 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException6, localizable16, localizable27, objArray44);
        java.lang.Object[] objArray46 = mathRuntimeException6.getArguments();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: " + "'", str5.equals("org.apache.commons.math.exception.MathIllegalArgumentException: "));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str10.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str15.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str26.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str36.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(objArray46);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.getTwo();
        org.apache.commons.math.dfp.Dfp dfp6 = new org.apache.commons.math.dfp.Dfp(dfp4);
        org.apache.commons.math.dfp.Dfp dfp7 = new org.apache.commons.math.dfp.Dfp(dfp6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField15 = dfp14.getField();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp18 = new org.apache.commons.math.dfp.Dfp(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray23 = dfpField22.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField22.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField22.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray29 = dfpField28.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField28.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField28.getSqr3();
        int int33 = dfp32.classify();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp26.remainder(dfp32);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp32.rint();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp32.newInstance((long) (byte) 0);
        double[] doubleArray38 = dfp37.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray41 = dfpField40.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField40.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp44 = dfp43.getTwo();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp37.add(dfp44);
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray48 = dfpField47.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField47.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField47.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField53 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray54 = dfpField53.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField53.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField53.getSqr3();
        int int58 = dfp57.classify();
        org.apache.commons.math.dfp.Dfp dfp59 = dfp51.remainder(dfp57);
        org.apache.commons.math.dfp.Dfp dfp60 = dfp57.rint();
        org.apache.commons.math.dfp.Dfp dfp62 = dfp60.newInstance(5206088179365433653L);
        org.apache.commons.math.dfp.Dfp dfp63 = dfp17.dotrap(0, "0.", dfp45, dfp62);
        org.apache.commons.math.dfp.Dfp dfp64 = dfp7.add(dfp62);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpField15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfpArray23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfpArray29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(dfpArray41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfpArray48);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfpArray54);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test314");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        double double1 = mersenneTwister0.nextGaussian();
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.03276926211119681d) + "'", double1 == (-0.03276926211119681d));
//    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 0.2822225f, (double) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.28222250938415533d + "'", double2 == 0.28222250938415533d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField5.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField5.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.getSqr3();
        int int16 = dfp15.classify();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp9.remainder(dfp15);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp15.rint();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp15.newInstance((long) (byte) 0);
        double[] doubleArray21 = dfp20.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField23.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField23.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField27 = dfp26.getField();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp30 = new org.apache.commons.math.dfp.Dfp(dfp29);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp29.getOne();
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray34 = dfpField33.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField37 = dfp36.getField();
        double[] doubleArray38 = dfp36.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp36.power10K(100);
        boolean boolean41 = dfp31.lessThan(dfp40);
        int int42 = dfp40.intValue();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp40.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray46 = dfpField45.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField45.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp49 = dfp48.getTwo();
        org.apache.commons.math.dfp.Dfp dfp50 = new org.apache.commons.math.dfp.Dfp(dfp48);
        org.apache.commons.math.dfp.Dfp dfp51 = org.apache.commons.math.dfp.Dfp.copysign(dfp43, dfp50);
        org.apache.commons.math.dfp.Dfp dfp52 = org.apache.commons.math.dfp.Dfp.copysign(dfp20, dfp43);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField1.newDfp(dfp43);
        org.apache.commons.math.dfp.Dfp[] dfpArray54 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(dfpArray24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfpField27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfpArray34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfpField37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2147483647 + "'", int42 == 2147483647);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfpArray46);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfpArray54);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.NumberIsTooSmallException: 0 is smaller than, or equal to, the minimum (0.987)");
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { (byte) 1, (-1.0d) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray3);
        java.lang.String str5 = mathIllegalArgumentException4.toString();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException6 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException4);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) (short) 100);
        java.lang.String str10 = notStrictlyPositiveException9.toString();
        org.apache.commons.math.exception.util.Localizable localizable11 = notStrictlyPositiveException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable12, (java.lang.Number) (short) 100);
        java.lang.String str15 = notStrictlyPositiveException14.toString();
        org.apache.commons.math.exception.util.Localizable localizable16 = notStrictlyPositiveException14.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { (byte) 1, (-1.0d) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable16, objArray20);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException25 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable23, (java.lang.Number) (short) 100);
        java.lang.String str26 = notStrictlyPositiveException25.toString();
        org.apache.commons.math.exception.util.Localizable localizable27 = notStrictlyPositiveException25.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException31 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable27, (java.lang.Number) 100, (java.lang.Number) 171.88733853924697d, false);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException35 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable33, (java.lang.Number) (short) 100);
        java.lang.String str36 = notStrictlyPositiveException35.toString();
        org.apache.commons.math.exception.util.Localizable localizable37 = notStrictlyPositiveException35.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException41 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable37, (java.lang.Number) 100, (java.lang.Number) 171.88733853924697d, false);
        java.lang.Object[] objArray44 = new java.lang.Object[] { (-0.7853981633974483d), 171.88733853924697d, 1, (short) 100 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException45 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException6, localizable16, localizable27, objArray44);
        org.apache.commons.math.exception.util.Localizable localizable46 = mathRuntimeException45.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: " + "'", str5.equals("org.apache.commons.math.exception.MathIllegalArgumentException: "));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str10.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str15.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str26.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str36.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertTrue("'" + localizable46 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable46.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        int int10 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp((long) 8);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.newDfp((double) 0L);
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 25 + "'", int10 == 25);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        dfpField1.setIEEEFlags((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp(32760);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(10L);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 0.417022f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getOne();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp();
        boolean boolean9 = dfp8.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.getSqr3();
        int int16 = dfp15.classify();
        int int17 = dfp15.classify();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp8.subtract(dfp15);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dfp18);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        dfpField1.setIEEEFlagsBits((int) (short) 100);
        dfpField1.setIEEEFlagsBits((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((long) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp((byte) 1);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getSqr2Split();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(6);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.0400898106232757d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2380240900532882d + "'", double1 == 1.2380240900532882d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        double[] doubleArray6 = dfp4.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp4.power10K(100);
        int int9 = dfp4.log10();
        int int10 = dfp4.log10();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp4.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.getOne();
        boolean boolean14 = dfp12.isInfinite();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-4) + "'", int9 == (-4));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-4) + "'", int10 == (-4));
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.getSqr3();
        int int12 = dfp11.classify();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp5.remainder(dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.rint();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp11.newInstance((long) (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp16.newInstance((byte) 3, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp19.getTwo();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.4170220046815991d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.551115123125783E-17d + "'", double1 == 5.551115123125783E-17d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((long) (byte) -1);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getOne();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField5.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField5.getLn2Split();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2.220446049250313E-16d, (java.lang.Number) 0.6374383972707328d, false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        int int6 = dfp5.classify();
        org.apache.commons.math.dfp.Dfp dfp7 = null;
        try {
            boolean boolean8 = dfp5.unequal(dfp7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.getSqr3();
        int int12 = dfp11.classify();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp5.remainder(dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.rint();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp11.newInstance((long) (byte) 0);
        double[] doubleArray17 = dfp16.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray20 = dfpField19.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp23 = dfp22.getTwo();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp16.add(dfp23);
        org.apache.commons.math.dfp.Dfp dfp25 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp26 = dfp24.nextAfter(dfp25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(dfpArray20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getESplit();
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.getTwo();
        org.apache.commons.math.dfp.Dfp dfp6 = new org.apache.commons.math.dfp.Dfp(dfp4);
        org.apache.commons.math.dfp.Dfp dfp7 = new org.apache.commons.math.dfp.Dfp(dfp6);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField9.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField13 = dfp12.getField();
        double[] doubleArray14 = dfp12.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.newInstance((byte) 0, (byte) 1);
        boolean boolean18 = dfp7.unequal(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray21 = dfpField20.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp24 = dfp23.getTwo();
        org.apache.commons.math.dfp.Dfp dfp25 = new org.apache.commons.math.dfp.Dfp(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField27.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField27.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.getTwo();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp25.add(dfp30);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp30.sqrt();
        boolean boolean34 = dfp12.greaterThan(dfp30);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpField13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dfpArray21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) (byte) 3);
        int int5 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 25 + "'", int5 == 25);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        double double1 = org.apache.commons.math.util.FastMath.log1p(4.641588833612779d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.730165733925067d + "'", double1 == 1.730165733925067d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) 100);
        java.lang.String str3 = notStrictlyPositiveException2.toString();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) (short) 100);
        java.lang.String str8 = notStrictlyPositiveException7.toString();
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException7.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (byte) 1, (-1.0d) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, objArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable9, objArray13);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 10.0f, (java.lang.Number) 1.0d, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 100.0d, (java.lang.Number) 1508871100, false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str8.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getOne();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField5.getLn5Split();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        int int2 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((byte) 2, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((-4));
        int int14 = dfp13.intValue();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-4) + "'", int14 == (-4));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.047442967903742035d + "'", double1 == 0.047442967903742035d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        int[] intArray2 = new int[] { (short) 10, (-1) };
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        mersenneTwister3.setSeed((long) (short) 1);
        boolean boolean6 = mersenneTwister3.nextBoolean();
        int int7 = mersenneTwister3.nextInt();
        double double8 = mersenneTwister3.nextDouble();
        boolean boolean9 = mersenneTwister3.nextBoolean();
        double double10 = mersenneTwister3.nextDouble();
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1508871100 + "'", int7 == 1508871100);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.41782887182714457d + "'", double8 == 0.41782887182714457d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.022821852739475013d + "'", double10 == 0.022821852739475013d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        int int10 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp((long) 8);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.newDfp((int) '4');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField1.getLn5();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 25 + "'", int10 == 25);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        double double1 = org.apache.commons.math.util.FastMath.abs(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.DfpField dfpField2 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField2.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField2.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField6 = dfp5.getField();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp9 = new org.apache.commons.math.dfp.Dfp(dfp8);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.getOne();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField12.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField16 = dfp15.getField();
        double[] doubleArray17 = dfp15.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp15.power10K(100);
        boolean boolean20 = dfp10.lessThan(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray23 = dfpField22.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField22.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField22.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray29 = dfpField28.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField28.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField28.getSqr3();
        int int33 = dfp32.classify();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp26.remainder(dfp32);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp32.rint();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp32.newInstance((long) (byte) 0);
        double[] doubleArray38 = dfp37.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray41 = dfpField40.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField40.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp44 = dfp43.getTwo();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp37.add(dfp44);
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray48 = dfpField47.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField47.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField51 = dfp50.getField();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField51.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField51.newDfp((long) 4);
        org.apache.commons.math.dfp.Dfp dfp55 = dfp44.multiply(dfp54);
        try {
            org.apache.commons.math.dfp.Dfp dfp56 = org.apache.commons.math.dfp.DfpField.computeLn(dfp0, dfp10, dfp44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpField6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpField16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dfpArray23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfpArray29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(dfpArray41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfpArray48);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfpField51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 2L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4436354751788103d + "'", double1 == 1.4436354751788103d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.floor();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.getTwo();
        org.apache.commons.math.dfp.Dfp dfp6 = new org.apache.commons.math.dfp.Dfp(dfp4);
        org.apache.commons.math.dfp.Dfp dfp7 = new org.apache.commons.math.dfp.Dfp(dfp6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance((byte) 2);
        int int10 = dfp9.log10K();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.getOne();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 229.1831180523293d + "'", double1 == 229.1831180523293d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        int int6 = dfp4.getRadixDigits();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 25 + "'", int6 == 25);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        int int10 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp((long) 8);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.newInstance();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 25 + "'", int10 == 25);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.0870848052070263d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = new org.apache.commons.math.dfp.Dfp(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.getOne();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField15 = dfp14.getField();
        double[] doubleArray16 = dfp14.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.power10K(100);
        boolean boolean19 = dfp9.lessThan(dfp18);
        int int20 = dfp18.intValue();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray23 = dfpField22.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField22.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField22.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray27 = dfpField22.getPiSplit();
        dfpField22.setIEEEFlags((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField22.newDfp((byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray34 = dfpField33.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField37 = dfp36.getField();
        double[] doubleArray38 = dfp36.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp36.power10K(100);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp40.getZero();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField22.newDfp(dfp41);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp18.multiply(dfp42);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp42.rint();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp44.newInstance((byte) 0, (byte) -1);
        int int48 = dfp44.intValue();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpField15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2147483647 + "'", int20 == 2147483647);
        org.junit.Assert.assertNotNull(dfpArray23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfpArray27);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfpArray34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfpField37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.getSqr3();
        int int12 = dfp11.classify();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp5.remainder(dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.rint();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.newInstance(5206088179365433653L);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.power10(2);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 10000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10000 + "'", int1 == 10000);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(0L);
        boolean boolean2 = mersenneTwister1.nextBoolean();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getOne();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.getTwo();
        org.apache.commons.math.dfp.Dfp dfp6 = new org.apache.commons.math.dfp.Dfp(dfp4);
        java.lang.Class<?> wildcardClass7 = dfp4.getClass();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField5.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField5.getESplit();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.36787944117144233d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1940688187363215d + "'", double1 == 1.1940688187363215d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 32760, (long) 32760);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32760L + "'", long2 == 32760L);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfpArray2);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        double double1 = org.apache.commons.math.util.FastMath.abs(229.1831180523293d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 229.1831180523293d + "'", double1 == 229.1831180523293d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField5.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp9.newInstance((byte) 10, (byte) 1);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.getTwo();
        org.apache.commons.math.dfp.Dfp dfp6 = new org.apache.commons.math.dfp.Dfp(dfp4);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField8.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.getTwo();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp6.add(dfp11);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField15.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField15.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField21.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField21.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField21.getSqr3();
        int int26 = dfp25.classify();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp19.remainder(dfp25);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp25.rint();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp25.newInstance((long) (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp13.add(dfp25);
        boolean boolean32 = dfp25.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp25.divide(3);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dfp34);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-1L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp9 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp10 = dfp8.remainder(dfp9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.28222250938415533d, (java.lang.Number) 0.047442967903742035d, true);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp5 = org.apache.commons.math.dfp.Dfp.copysign(dfp3, dfp4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 7.6926979E18f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.34262907054196288E17d + "'", double1 == 1.34262907054196288E17d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        double double1 = org.apache.commons.math.util.FastMath.atan((-0.8273747768554842d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6912114304410573d) + "'", double1 == (-0.6912114304410573d));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr2();
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        int int10 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp((long) 8);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getTwo();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 25 + "'", int10 == 25);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        double double2 = org.apache.commons.math.util.FastMath.max(Double.NaN, 97.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        double double1 = org.apache.commons.math.util.FastMath.atanh(11.591953275521519d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1752011936438014d + "'", double1 == 1.1752011936438014d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.getSqr3();
        int int12 = dfp11.classify();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp5.remainder(dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.rint();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.power10((int) '4');
        boolean boolean17 = dfp16.isInfinite();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        dfpField1.setIEEEFlags((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getSqr2Split();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfpArray9);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.getSqr3();
        int int12 = dfp11.classify();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp5.remainder(dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.rint();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp11.newInstance((long) (byte) 0);
        double[] doubleArray17 = dfp16.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray20 = dfpField19.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp23 = dfp22.getTwo();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp16.add(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray27 = dfpField26.getLn5Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField26.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.getPi();
        org.apache.commons.math.dfp.Dfp dfp30 = org.apache.commons.math.dfp.Dfp.copysign(dfp16, dfp29);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp29.negate();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp29.getTwo();
        int int33 = dfp29.getRadixDigits();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(dfpArray20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfpArray27);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 25 + "'", int33 == 25);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        double[] doubleArray6 = dfp4.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp4.power10K(100);
        int int9 = dfp4.log10K();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp4.newInstance((byte) 10, (byte) 0);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 'a', 4.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5295825641365763d + "'", double2 == 1.5295825641365763d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.getTwo();
        org.apache.commons.math.dfp.Dfp dfp6 = new org.apache.commons.math.dfp.Dfp(dfp4);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField8.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.getTwo();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp6.add(dfp11);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp16 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp17 = dfp15.newInstance(dfp16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 1.4436354751788103d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4436354751788103d + "'", double2 == 1.4436354751788103d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 10000);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.5295825641365763d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.61624943197943d + "'", double1 == 4.61624943197943d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 43);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getOne();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.getSqr3();
        int int9 = dfpField5.getIEEEFlags();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 16 + "'", int9 == 16);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField9.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField13 = dfp12.getField();
        double[] doubleArray14 = dfp12.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.newInstance((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.getOne();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField1.newDfp(dfp18);
        dfpField1.setIEEEFlagsBits(3);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpField13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-0.21502679675769548d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.21177293199150599d) + "'", double1 == (-0.21177293199150599d));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 32768);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(2);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.junit.Assert.assertNotNull(dfp2);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        int int2 = org.apache.commons.math.util.FastMath.min((int) '4', (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        double double1 = org.apache.commons.math.util.FastMath.asin((-0.8273747768554842d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9744173388376526d) + "'", double1 == (-0.9744173388376526d));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.negate();
        java.lang.Class<?> wildcardClass6 = dfp4.getClass();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField9.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField13 = dfp12.getField();
        double[] doubleArray14 = dfp12.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.newInstance((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.getOne();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField1.newDfp(dfp18);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray21 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField1.getPi();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpField13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpArray21);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.38542559176909813d, (java.lang.Number) 0.9259609884950271d, true);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        java.lang.Number number5 = numberIsTooSmallException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.9259609884950271d + "'", number4.equals(0.9259609884950271d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.38542559176909813d + "'", number5.equals(0.38542559176909813d));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp9 = null;
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.getTwo();
        org.apache.commons.math.dfp.Dfp dfp16 = new org.apache.commons.math.dfp.Dfp(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField18.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp22 = dfp21.getTwo();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp16.add(dfp21);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp21.sqrt();
        try {
            org.apache.commons.math.dfp.Dfp dfp25 = org.apache.commons.math.dfp.DfpField.computeLn(dfp8, dfp9, dfp24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.getSqr3();
        int int12 = dfp11.classify();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp5.remainder(dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.rint();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField16.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp20 = dfp19.getTwo();
        org.apache.commons.math.dfp.Dfp dfp21 = new org.apache.commons.math.dfp.Dfp(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField23.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField23.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp27 = dfp26.getTwo();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp21.add(dfp26);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray31 = dfpField30.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField30.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField30.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray37 = dfpField36.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField36.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField36.getSqr3();
        int int41 = dfp40.classify();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp34.remainder(dfp40);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp40.rint();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp40.newInstance((long) (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp28.add(dfp40);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp11.multiply(dfp40);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp11.rint();
        org.apache.commons.math.dfp.Dfp dfp49 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp50 = dfp11.add(dfp49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpArray24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfpArray31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfpArray37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getOne();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField5.getESplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = dfpField5.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField5.newDfp((byte) 100, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField15.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField15.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField21.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField21.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField21.getSqr3();
        int int26 = dfp25.classify();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp19.remainder(dfp25);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp19.newInstance();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp13.add(dfp19);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 100L, (float) 7692698082559361259L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 7.6926979E18f + "'", float2 == 7.6926979E18f);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-4), (-0.9251475365964085d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9251475365964085d) + "'", double2 == (-0.9251475365964085d));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) 100);
        java.lang.String str3 = notStrictlyPositiveException2.toString();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 100, (java.lang.Number) 171.88733853924697d, false);
        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooSmallException8.getSpecificPattern();
        java.lang.Object[] objArray10 = numberIsTooSmallException8.getArguments();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray10);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-32767));
        try {
            int int3 = mersenneTwister1.nextInt(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        int[] intArray2 = new int[] { (short) 10, (-1) };
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        mersenneTwister3.setSeed((long) (short) 1);
        boolean boolean6 = mersenneTwister3.nextBoolean();
        int int8 = mersenneTwister3.nextInt((int) (short) 1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(2147483647);
        long long2 = mersenneTwister1.nextLong();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7256785470231326570L + "'", long2 == 7256785470231326570L);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        int[] intArray2 = new int[] { (short) 10, (-1) };
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        double double4 = mersenneTwister3.nextDouble();
        int int5 = mersenneTwister3.nextInt();
        boolean boolean6 = mersenneTwister3.nextBoolean();
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.8943285682649755d + "'", double4 == 0.8943285682649755d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1212136861 + "'", int5 == 1212136861);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 3L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.getSqr3();
        int int12 = dfp11.classify();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp5.remainder(dfp11);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.divide(25);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.newInstance((double) (-1L));
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = new org.apache.commons.math.dfp.Dfp(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.getOne();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField11.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField11.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp7.nextAfter(dfp17);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.getTwo();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.power10((int) (byte) 0);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getOne();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField5.getESplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = dfpField5.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField5.newDfp((byte) 100, (byte) 10);
        boolean boolean14 = dfp13.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp13.power10(0);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        dfpField1.setIEEEFlagsBits(10000);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getESplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = dfpField1.getRoundingMode();
        dfpField1.clearIEEEFlags();
        int int12 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        int[] intArray3 = new int[] { (short) 0, 2, (short) 1 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) 100);
        java.lang.String str3 = notStrictlyPositiveException2.toString();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 11.591953275521519d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.getE();
        int int9 = dfp8.log10();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        double double1 = org.apache.commons.math.util.FastMath.tanh(3.748066027288565E7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp((long) 4);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField10.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField14 = dfp13.getField();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp17 = new org.apache.commons.math.dfp.Dfp(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.getOne();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray21 = dfpField20.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField20.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField20.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp16.nextAfter(dfp26);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp8.newInstance(dfp16);
        int int29 = dfp16.log10();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpField14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfpArray21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = new org.apache.commons.math.dfp.Dfp(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.getOne();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField15 = dfp14.getField();
        double[] doubleArray16 = dfp14.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.power10K(100);
        boolean boolean19 = dfp9.lessThan(dfp18);
        int int20 = dfp18.intValue();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray23 = dfpField22.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField22.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField22.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray27 = dfpField22.getPiSplit();
        dfpField22.setIEEEFlags((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField22.newDfp((byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray34 = dfpField33.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField37 = dfp36.getField();
        double[] doubleArray38 = dfp36.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp36.power10K(100);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp40.getZero();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField22.newDfp(dfp41);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp18.multiply(dfp42);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp42.rint();
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray47 = dfpField46.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField46.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField50 = dfp49.getField();
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField50.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField50.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp53 = new org.apache.commons.math.dfp.Dfp(dfp52);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp52.getOne();
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray57 = dfpField56.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField56.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField60 = dfp59.getField();
        double[] doubleArray61 = dfp59.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp63 = dfp59.power10K(100);
        boolean boolean64 = dfp54.lessThan(dfp63);
        boolean boolean65 = dfp44.lessThan(dfp54);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpField15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2147483647 + "'", int20 == 2147483647);
        org.junit.Assert.assertNotNull(dfpArray23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfpArray27);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfpArray34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfpField37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfpArray47);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfpField50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfpArray57);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfpField60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.getSqr3();
        int int12 = dfp11.classify();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp5.remainder(dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.rint();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp11.newInstance((long) (byte) 0);
        double[] doubleArray17 = dfp16.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray20 = dfpField19.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp23 = dfp22.getTwo();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp16.add(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray27 = dfpField26.getLn5Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField26.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.getPi();
        org.apache.commons.math.dfp.Dfp dfp30 = org.apache.commons.math.dfp.Dfp.copysign(dfp16, dfp29);
        int int31 = dfp29.log10();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(dfpArray20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfpArray27);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.9964400909602754d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9964400909602754d + "'", double1 == 0.9964400909602754d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.2380240900532882d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        int int5 = dfp4.intValue();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getE();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField10.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField16.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.getSqr3();
        int int21 = dfp20.classify();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp14.remainder(dfp20);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp20.rint();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray26 = dfpField25.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField25.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField25.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray32 = dfpField31.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField31.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField31.getSqr3();
        int int36 = dfp35.classify();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp29.remainder(dfp35);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp35.rint();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp35.newInstance((long) (byte) 0);
        double[] doubleArray41 = dfp40.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp6.dotrap((-1), "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)", dfp20, dfp40);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray45 = dfpField44.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField44.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField44.getSqr3();
        int int49 = dfp48.classify();
        org.apache.commons.math.dfp.Dfp dfp50 = dfp42.remainder(dfp48);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp42.getZero();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfpArray26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfpArray32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfpArray45);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.newInstance((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField9.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField13 = dfp12.getField();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.getSqr2();
        boolean boolean16 = dfp7.greaterThan(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.getTwo();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpField13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = new org.apache.commons.math.dfp.Dfp(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.getOne();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField15 = dfp14.getField();
        double[] doubleArray16 = dfp14.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.power10K(100);
        boolean boolean19 = dfp9.lessThan(dfp18);
        int int20 = dfp18.intValue();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray23 = dfpField22.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField22.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField22.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray27 = dfpField22.getPiSplit();
        dfpField22.setIEEEFlags((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField22.newDfp((byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray34 = dfpField33.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField37 = dfp36.getField();
        double[] doubleArray38 = dfp36.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp36.power10K(100);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp40.getZero();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField22.newDfp(dfp41);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp18.multiply(dfp42);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp42.rint();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp44.newInstance((byte) 0, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp47.multiply(8);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpField15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2147483647 + "'", int20 == 2147483647);
        org.junit.Assert.assertNotNull(dfpArray23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfpArray27);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfpArray34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfpField37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp49);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        int int6 = dfp5.classify();
        int int7 = dfp5.classify();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField9.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField13 = dfp12.getField();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp16 = new org.apache.commons.math.dfp.Dfp(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.getOne();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp5.remainder(dfp15);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getLn5();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp25 = dfp18.add(dfp24);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpField13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(0L);
        long long2 = mersenneTwister1.nextLong();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2780242596957121269L + "'", long2 == 2780242596957121269L);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(42.99999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2463.7185190625396d + "'", double1 == 2463.7185190625396d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1L);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.09966865249116202d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.09983440995178777d + "'", double1 == 0.09983440995178777d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { (byte) 1, (-1.0d) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray3);
        java.lang.String str5 = mathIllegalArgumentException4.toString();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException6 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException4);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) (short) 100);
        java.lang.String str10 = notStrictlyPositiveException9.toString();
        org.apache.commons.math.exception.util.Localizable localizable11 = notStrictlyPositiveException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable12, (java.lang.Number) (short) 100);
        java.lang.String str15 = notStrictlyPositiveException14.toString();
        org.apache.commons.math.exception.util.Localizable localizable16 = notStrictlyPositiveException14.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { (byte) 1, (-1.0d) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable16, objArray20);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException25 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable23, (java.lang.Number) (short) 100);
        java.lang.String str26 = notStrictlyPositiveException25.toString();
        org.apache.commons.math.exception.util.Localizable localizable27 = notStrictlyPositiveException25.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException31 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable27, (java.lang.Number) 100, (java.lang.Number) 171.88733853924697d, false);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException35 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable33, (java.lang.Number) (short) 100);
        java.lang.String str36 = notStrictlyPositiveException35.toString();
        org.apache.commons.math.exception.util.Localizable localizable37 = notStrictlyPositiveException35.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException41 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable37, (java.lang.Number) 100, (java.lang.Number) 171.88733853924697d, false);
        java.lang.Object[] objArray44 = new java.lang.Object[] { (-0.7853981633974483d), 171.88733853924697d, 1, (short) 100 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException45 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException6, localizable16, localizable27, objArray44);
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException48 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable46, (java.lang.Number) (short) 100);
        java.lang.String str49 = notStrictlyPositiveException48.toString();
        org.apache.commons.math.exception.util.Localizable localizable50 = notStrictlyPositiveException48.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException54 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable50, (java.lang.Number) 100, (java.lang.Number) 171.88733853924697d, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException58 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable50, (java.lang.Number) 0L, (java.lang.Number) 2, false);
        java.lang.Object[] objArray59 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException60 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable27, localizable50, objArray59);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException62 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable50, (java.lang.Number) 0);
        java.lang.String str63 = notStrictlyPositiveException62.toString();
        java.lang.Number number64 = notStrictlyPositiveException62.getMin();
        java.lang.Number number65 = notStrictlyPositiveException62.getMin();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: " + "'", str5.equals("org.apache.commons.math.exception.MathIllegalArgumentException: "));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str10.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str15.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str26.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str36.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str49.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable50 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable50.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0): 0 is smaller than, or equal to, the minimum (0)" + "'", str63.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0): 0 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number64 + "' != '" + 0 + "'", number64.equals(0));
        org.junit.Assert.assertTrue("'" + number65 + "' != '" + 0 + "'", number65.equals(0));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.8273747768554842d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8273747768554842d + "'", double1 == 0.8273747768554842d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 25);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.13235175009777303d) + "'", double1 == (-0.13235175009777303d));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 35L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5422326689561365d + "'", double1 == 1.5422326689561365d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField5.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField5.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.getSqr3();
        int int16 = dfp15.classify();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp9.remainder(dfp15);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp15.rint();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp15.newInstance((long) (byte) 0);
        double[] doubleArray21 = dfp20.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField23.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField23.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField27 = dfp26.getField();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp30 = new org.apache.commons.math.dfp.Dfp(dfp29);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp29.getOne();
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray34 = dfpField33.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField37 = dfp36.getField();
        double[] doubleArray38 = dfp36.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp36.power10K(100);
        boolean boolean41 = dfp31.lessThan(dfp40);
        int int42 = dfp40.intValue();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp40.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray46 = dfpField45.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField45.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp49 = dfp48.getTwo();
        org.apache.commons.math.dfp.Dfp dfp50 = new org.apache.commons.math.dfp.Dfp(dfp48);
        org.apache.commons.math.dfp.Dfp dfp51 = org.apache.commons.math.dfp.Dfp.copysign(dfp43, dfp50);
        org.apache.commons.math.dfp.Dfp dfp52 = org.apache.commons.math.dfp.Dfp.copysign(dfp20, dfp43);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField1.newDfp(dfp43);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp43.newInstance();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(dfpArray24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfpField27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfpArray34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfpField37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2147483647 + "'", int42 == 2147483647);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfpArray46);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-4), (long) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        int[] intArray2 = new int[] { (short) 10, (-1) };
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        mersenneTwister3.setSeed((long) (short) 1);
        boolean boolean6 = mersenneTwister3.nextBoolean();
        mersenneTwister3.setSeed((long) 1);
        byte[] byteArray13 = new byte[] { (byte) 3, (byte) 3, (byte) 1, (byte) 3 };
        mersenneTwister3.nextBytes(byteArray13);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(byteArray13);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        double double1 = org.apache.commons.math.util.FastMath.exp(4.61624943197943d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 101.11408481287508d + "'", double1 == 101.11408481287508d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        float float2 = org.apache.commons.math.util.FastMath.min((-1.0f), (float) 6);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getE();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        dfpField5.setRoundingMode(roundingMode7);
        dfpField5.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField5.getLn2();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        int[] intArray2 = new int[] { (short) 10, (-1) };
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        double double4 = mersenneTwister3.nextGaussian();
        long long5 = mersenneTwister3.nextLong();
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.2527237975288865d + "'", double4 == 1.2527237975288865d);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 5589611794929676027L + "'", long5 == 5589611794929676027L);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField5.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField5.getLn2Split();
        dfpField5.clearIEEEFlags();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        int int6 = dfp5.classify();
        int int7 = dfp5.classify();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField9.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField13 = dfp12.getField();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp16 = new org.apache.commons.math.dfp.Dfp(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.getOne();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp5.remainder(dfp15);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.power10((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp18.newInstance(8.881784197001252E-16d);
        org.apache.commons.math.dfp.Dfp dfp23 = null;
        try {
            boolean boolean24 = dfp18.greaterThan(dfp23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpField13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.getSqr3();
        int int12 = dfp11.classify();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp5.remainder(dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.rint();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField16.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp20 = dfp19.getTwo();
        org.apache.commons.math.dfp.Dfp dfp21 = new org.apache.commons.math.dfp.Dfp(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField23.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField23.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp27 = dfp26.getTwo();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp21.add(dfp26);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray31 = dfpField30.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField30.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField30.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray37 = dfpField36.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField36.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField36.getSqr3();
        int int41 = dfp40.classify();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp34.remainder(dfp40);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp40.rint();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp40.newInstance((long) (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp28.add(dfp40);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp11.multiply(dfp40);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp47.negate();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpArray24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfpArray31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfpArray37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17453292519943295d + "'", double1 == 0.17453292519943295d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 52L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9155040003582885E22d + "'", double1 == 1.9155040003582885E22d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) '#');
        boolean boolean2 = mersenneTwister1.nextBoolean();
        long long3 = mersenneTwister1.nextLong();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 8297254558039539692L + "'", long3 == 8297254558039539692L);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp12 = null;
        try {
            boolean boolean13 = dfp11.unequal(dfp12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        int int2 = org.apache.commons.math.util.FastMath.max(6, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) 100);
        java.lang.String str3 = notStrictlyPositiveException2.toString();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 100, (java.lang.Number) 171.88733853924697d, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 0L, (java.lang.Number) 2, false);
        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooSmallException12.getSpecificPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException15 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable13, (java.lang.Number) 1.5088711000000002E9d);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField17.getLn5Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, (java.lang.Object[]) dfpArray18);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable13, (java.lang.Number) 0.047442967903742035d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfpArray18);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.4178287982940674d, 4.597241302448439d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.41782879829406744d + "'", double2 == 0.41782879829406744d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.getSqr3();
        int int12 = dfp11.classify();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp5.remainder(dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.rint();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp11.newInstance((long) (byte) 0);
        double[] doubleArray17 = dfp16.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray20 = dfpField19.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp23 = dfp22.getTwo();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp16.add(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray27 = dfpField26.getLn5Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField26.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.getPi();
        org.apache.commons.math.dfp.Dfp dfp30 = org.apache.commons.math.dfp.Dfp.copysign(dfp16, dfp29);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp16.getOne();
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray34 = dfpField33.getLn5Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray35 = dfpField33.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.getPi();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField33.getE();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp31.subtract(dfp37);
        java.lang.Class<?> wildcardClass39 = dfp38.getClass();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(dfpArray20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfpArray27);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfpArray34);
        org.junit.Assert.assertNotNull(dfpArray35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(wildcardClass39);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        dfpField1.setIEEEFlagsBits((int) (short) 100);
        dfpField1.setIEEEFlagsBits((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.newInstance();
        int int12 = dfp11.getRadixDigits();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 25 + "'", int12 == 25);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = new org.apache.commons.math.dfp.Dfp(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.getOne();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField15 = dfp14.getField();
        double[] doubleArray16 = dfp14.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.power10K(100);
        boolean boolean19 = dfp9.lessThan(dfp18);
        int int20 = dfp18.intValue();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray23 = dfpField22.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField22.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField22.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray27 = dfpField22.getPiSplit();
        dfpField22.setIEEEFlags((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField22.newDfp((byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray34 = dfpField33.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField37 = dfp36.getField();
        double[] doubleArray38 = dfp36.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp36.power10K(100);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp40.getZero();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField22.newDfp(dfp41);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp18.multiply(dfp42);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp42.rint();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp44.newInstance((byte) 0, (byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField48 = dfp47.getField();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpField15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2147483647 + "'", int20 == 2147483647);
        org.junit.Assert.assertNotNull(dfpArray23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfpArray27);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfpArray34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfpField37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfpField48);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 4);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 4.0f + "'", float1 == 4.0f);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getOne();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField5.getESplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = dfpField5.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField5.newDfp((byte) 100, (byte) 10);
        boolean boolean14 = dfp13.isInfinite();
        boolean boolean15 = dfp13.isNaN();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getE();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.getTwo();
        org.apache.commons.math.dfp.Dfp dfp6 = new org.apache.commons.math.dfp.Dfp(dfp4);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField8.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.getTwo();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp6.add(dfp11);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField15.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField15.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField21.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField21.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField21.getSqr3();
        int int26 = dfp25.classify();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp19.remainder(dfp25);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp25.rint();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp25.newInstance((long) (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp13.add(dfp25);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp13.newInstance((byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField34 = dfp33.getField();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp33.power10K((int) '#');
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfpField34);
        org.junit.Assert.assertNotNull(dfp36);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getE();
        dfpField5.setIEEEFlagsBits(32768);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField5.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField5.newDfp(33);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField5.newDfp((double) 10000L);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.power10(16);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.9964400909602753d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9964400909602753d + "'", double1 == 0.9964400909602753d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getOne();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.getSqr3();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = dfpField5.getRoundingMode();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode9.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getE();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        dfpField5.setRoundingMode(roundingMode7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField5.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField5.newDfp(33);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        double double1 = org.apache.commons.math.util.FastMath.sin((-0.13235175009777303d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.13196568776520445d) + "'", double1 == (-0.13196568776520445d));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) 100);
        java.lang.String str3 = notStrictlyPositiveException2.toString();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException2.getGeneralPattern();
        boolean boolean5 = notStrictlyPositiveException2.getBoundIsAllowed();
        boolean boolean6 = notStrictlyPositiveException2.getBoundIsAllowed();
        java.lang.Number number7 = notStrictlyPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0 + "'", number7.equals(0));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        int int6 = dfp5.classify();
        int int7 = dfp5.classify();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField9.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField13 = dfp12.getField();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp16 = new org.apache.commons.math.dfp.Dfp(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.getOne();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp5.remainder(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray21 = dfpField20.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray27 = dfpField26.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField26.getSqr3();
        int int31 = dfp30.classify();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp24.remainder(dfp30);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp30.rint();
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray36 = dfpField35.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField35.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp39 = dfp38.getTwo();
        org.apache.commons.math.dfp.Dfp dfp40 = new org.apache.commons.math.dfp.Dfp(dfp38);
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray43 = dfpField42.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField42.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp46 = dfp45.getTwo();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp40.add(dfp45);
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray50 = dfpField49.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField49.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField49.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField55 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray56 = dfpField55.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField55.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField55.getSqr3();
        int int60 = dfp59.classify();
        org.apache.commons.math.dfp.Dfp dfp61 = dfp53.remainder(dfp59);
        org.apache.commons.math.dfp.Dfp dfp62 = dfp59.rint();
        org.apache.commons.math.dfp.Dfp dfp64 = dfp59.newInstance((long) (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp65 = dfp47.add(dfp59);
        org.apache.commons.math.dfp.Dfp dfp66 = dfp30.multiply(dfp59);
        org.apache.commons.math.dfp.Dfp dfp67 = dfp30.rint();
        org.apache.commons.math.dfp.Dfp dfp68 = dfp30.getZero();
        org.apache.commons.math.dfp.Dfp dfp69 = dfp5.newInstance(dfp68);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpField13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfpArray21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfpArray27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfpArray36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfpArray43);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfpArray50);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfpArray56);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp69);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        double double1 = org.apache.commons.math.util.FastMath.cosh(4.641588833612779d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 51.859317725494705d + "'", double1 == 51.859317725494705d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        double double1 = org.apache.commons.math.util.FastMath.expm1(3.748066027288565E7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(3);
        dfpField1.setIEEEFlagsBits((int) ' ');
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.2527237975288865d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.getSqr3();
        int int12 = dfp11.classify();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp5.remainder(dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.rint();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp11.newInstance((long) (byte) 0);
        double[] doubleArray17 = dfp16.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray20 = dfpField19.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp23 = dfp22.getTwo();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp16.add(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray27 = dfpField26.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField30 = dfp29.getField();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField30.newDfp((long) 4);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp23.multiply(dfp33);
        org.apache.commons.math.dfp.Dfp dfp35 = new org.apache.commons.math.dfp.Dfp(dfp34);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(dfpArray20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfpArray27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfpField30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = new org.apache.commons.math.dfp.Dfp(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.getOne();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField11.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField11.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp7.nextAfter(dfp17);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp17.newInstance("hi!");
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.getSqr3();
        int int12 = dfp11.classify();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp5.remainder(dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp5.rint();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField16.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField23.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField23.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField27 = dfp26.getField();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp30 = new org.apache.commons.math.dfp.Dfp(dfp29);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp29.getOne();
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray34 = dfpField33.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField37 = dfp36.getField();
        double[] doubleArray38 = dfp36.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp36.power10K(100);
        boolean boolean41 = dfp31.lessThan(dfp40);
        int int42 = dfp31.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray45 = dfpField44.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray46 = dfpField44.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField44.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp19.dotrap((int) (byte) -1, "org.apache.commons.math.exception.MathIllegalArgumentException: ", dfp31, dfp47);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp5.multiply(dfp48);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp5.floor();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfpArray24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfpField27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfpArray34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfpField37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 25 + "'", int42 == 25);
        org.junit.Assert.assertNotNull(dfpArray45);
        org.junit.Assert.assertNotNull(dfpArray46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.floor();
        boolean boolean6 = dfp4.isInfinite();
        java.lang.String str7 = dfp4.toString();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2.718281828459045235360287471352662497757247093699959574966967627724076630353547594571382178525166" + "'", str7.equals("2.718281828459045235360287471352662497757247093699959574966967627724076630353547594571382178525166"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        double double2 = org.apache.commons.math.util.FastMath.atan2(Double.NaN, 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        int[] intArray2 = new int[] { (short) 10, (-1) };
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        mersenneTwister3.setSeed((long) (short) 1);
        boolean boolean6 = mersenneTwister3.nextBoolean();
        int int8 = mersenneTwister3.nextInt(25);
        long long9 = mersenneTwister3.nextLong();
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1204179834679007461L) + "'", long9 == (-1204179834679007461L));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((int) (byte) 0);
        double[] doubleArray6 = dfp5.toSplitDouble();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.38542559176909813d, (java.lang.Number) 0.9259609884950271d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getSpecificPattern();
        org.junit.Assert.assertNull(localizable4);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.negate();
        double[] doubleArray10 = dfp9.toSplitDouble();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        dfpField1.setIEEEFlags((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((double) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp(6);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode14 = dfpField1.getRoundingMode();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + roundingMode14 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode14.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getTwo();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 100L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField5.getLn5Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField5.getESplit();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField5.getE();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField17.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField17.getSqr3();
        int int22 = dfp21.classify();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp15.remainder(dfp21);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp21.rint();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp21.newInstance((long) (byte) 0);
        double[] doubleArray27 = dfp26.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField29.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField29.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp33 = dfp32.getTwo();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp26.add(dfp33);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField5.newDfp(dfp26);
        org.apache.commons.math.dfp.Dfp[] dfpArray36 = dfpField5.getESplit();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField5.newDfp(0.007292488239882743d);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(dfpArray30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfpArray36);
        org.junit.Assert.assertNotNull(dfp38);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.floor();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp10 = org.apache.commons.math.dfp.DfpField.computeLn(dfp4, dfp8, dfp9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getE();
        dfpField5.setIEEEFlagsBits(32768);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField5.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField12.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField12.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField12.getPiSplit();
        dfpField12.setIEEEFlags((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField12.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField12.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp10.subtract(dfp22);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        int int2 = org.apache.commons.math.util.FastMath.min((int) '4', 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.getZero();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField13.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField13.getSqr3();
        int int18 = dfp17.classify();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp11.remainder(dfp17);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp17.rint();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.newInstance(5206088179365433653L);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp4.add(dfp22);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 35L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }
}

