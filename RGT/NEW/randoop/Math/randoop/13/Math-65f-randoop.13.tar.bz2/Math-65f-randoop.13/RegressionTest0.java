import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.apache.commons.math.linear.FieldMatrix<org.apache.commons.math.fraction.BigFraction> bigFractionFieldMatrix0 = null;
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = org.apache.commons.math.linear.MatrixUtils.bigFractionMatrixToRealMatrix(bigFractionFieldMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.math.BigDecimal[] bigDecimalArray0 = new java.math.BigDecimal[] {};
        java.math.BigDecimal[] bigDecimalArray1 = new java.math.BigDecimal[] {};
        java.math.BigDecimal[] bigDecimalArray2 = new java.math.BigDecimal[] {};
        java.math.BigDecimal[] bigDecimalArray3 = new java.math.BigDecimal[] {};
        java.math.BigDecimal[][] bigDecimalArray4 = new java.math.BigDecimal[][] { bigDecimalArray0, bigDecimalArray1, bigDecimalArray2, bigDecimalArray3 };
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix5 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(bigDecimalArray4);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigDecimalArray0);
        org.junit.Assert.assertNotNull(bigDecimalArray1);
        org.junit.Assert.assertNotNull(bigDecimalArray2);
        org.junit.Assert.assertNotNull(bigDecimalArray3);
        org.junit.Assert.assertNotNull(bigDecimalArray4);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.apache.commons.math.linear.AnyMatrix anyMatrix0 = null;
        org.apache.commons.math.linear.AnyMatrix anyMatrix1 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.checkSubtractionCompatible(anyMatrix0, anyMatrix1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.io.ObjectInputStream objectInputStream2 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) 10.0d, "hi!", objectInputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix2 = array2DRowRealMatrix0.getRowMatrix(10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 10 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.lang.String[] strArray1 = new java.lang.String[] { "" };
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix2 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(strArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        try {
            double[] doubleArray2 = array2DRowRealMatrix0.getRow((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 10 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test008");
//        org.apache.commons.math.exception.Localizable localizable0 = null;
//        double[][] doubleArray3 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
//        try {
//            java.lang.IllegalStateException illegalStateException4 = org.apache.commons.math.MathRuntimeException.createIllegalStateException(localizable0, (java.lang.Object[]) doubleArray3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(doubleArray3);
//    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor1 = null;
        try {
            double double6 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixChangingVisitor1, 1, 1, 0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 1 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = org.apache.commons.math.optimization.general.AbstractLeastSquaresOptimizer.DEFAULT_MAX_ITERATIONS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 100 + "'", int0 == 100);
    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test011");
//        org.apache.commons.math.exception.Localizable localizable1 = null;
//        double[] doubleArray2 = new double[] {};
//        double[][] doubleArray3 = new double[][] { doubleArray2 };
//        double[][] doubleArray4 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray3);
//        try {
//            java.text.ParseException parseException5 = org.apache.commons.math.MathRuntimeException.createParseException((int) (short) -1, localizable1, (java.lang.Object[]) doubleArray3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(doubleArray2);
//        org.junit.Assert.assertNotNull(doubleArray3);
//        org.junit.Assert.assertNotNull(doubleArray4);
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor2 = null;
        try {
            double double3 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixChangingVisitor2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 1, 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException1 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.io.ObjectInputStream objectInputStream3 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) functionEvaluationException1, "hi!", objectInputStream3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        try {
            double[] doubleArray3 = array2DRowRealMatrix0.getRow((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 0 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix1 = array2DRowRealMatrix0.copy();
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        double[] doubleArray4 = new double[] { (short) 100 };
        try {
            array2DRowRealMatrix0.setRow(1, doubleArray4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 1 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        double[] doubleArray6 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException7 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray6);
        try {
            org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl9 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 6x1 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix8);
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test019");
//        org.apache.commons.math.exception.Localizable localizable0 = null;
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException2 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
//        java.lang.Throwable[] throwableArray3 = functionEvaluationException2.getSuppressed();
//        try {
//            java.util.NoSuchElementException noSuchElementException4 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException(localizable0, (java.lang.Object[]) throwableArray3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(throwableArray3);
//    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.apache.commons.math.linear.AnyMatrix anyMatrix0 = null;
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math.linear.MatrixUtils.checkMultiplicationCompatible(anyMatrix0, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.lang.Object obj0 = null;
        java.io.ObjectInputStream objectInputStream2 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.deserializeRealVector(obj0, "hi!", objectInputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double[][] doubleArray0 = null;
        try {
            double[][] doubleArray1 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        double[] doubleArray8 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException(doubleArray8);
        org.apache.commons.math.exception.Localizable localizable10 = null;
        double[] doubleArray13 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable14 = null;
        double[] doubleArray15 = new double[] {};
        double[][] doubleArray16 = new double[][] { doubleArray15 };
        double[][] doubleArray17 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray16);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException(doubleArray13, localizable14, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException19 = new org.apache.commons.math.FunctionEvaluationException(doubleArray8, localizable10, (java.lang.Object[]) doubleArray16);
        try {
            array2DRowRealMatrix0.setRow((int) (short) -1, doubleArray8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index -1 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.apache.commons.math.linear.FieldMatrix<org.apache.commons.math.fraction.Fraction> fractionFieldMatrix0 = null;
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = org.apache.commons.math.linear.MatrixUtils.fractionMatrixToRealMatrix(fractionFieldMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        try {
            double[] doubleArray3 = array2DRowRealMatrix0.getRow((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 97 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.solve((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix2);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.apache.commons.math.linear.SingularMatrixException singularMatrixException0 = new org.apache.commons.math.linear.SingularMatrixException();
        java.lang.Class<?> wildcardClass1 = singularMatrixException0.getClass();
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix2 = array2DRowRealMatrix0.scalarAdd(0.0d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean2 = array2DRowRealMatrix1.isSquare();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.lang.Throwable throwable0 = null;
        double[] doubleArray1 = null;
        org.apache.commons.math.exception.Localizable localizable2 = null;
        double[] doubleArray6 = new double[] {};
        double[][] doubleArray7 = new double[][] { doubleArray6 };
        double[][] doubleArray8 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray7);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException9 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray8);
        org.apache.commons.math.exception.Localizable localizable10 = null;
        double[][] doubleArray13 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxEvaluationsExceededException9, localizable10, (java.lang.Object[]) doubleArray13);
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("", (java.lang.Object[]) doubleArray13);
        try {
            org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray1, localizable2, (java.lang.Object[]) doubleArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor1 = null;
        try {
            double double2 = array2DRowRealMatrix0.walkInOptimizedOrder(realMatrixChangingVisitor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix2 = array2DRowRealMatrix0.getRowMatrix((int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 32 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double[] doubleArray4 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[][] doubleArray7 = new double[][] { doubleArray6 };
        double[][] doubleArray8 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray7);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException(doubleArray4, localizable5, (java.lang.Object[]) doubleArray7);
        try {
            double[] doubleArray10 = array2DRowRealMatrix0.solve(doubleArray4);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        org.apache.commons.math.linear.RealVector realVector3 = null;
        try {
            array2DRowRealMatrix0.setColumnVector((int) (short) -1, realVector3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index -1 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix2 = array2DRowRealMatrix0.inverse();
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        try {
            org.apache.commons.math.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 100 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        double[] doubleArray7 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException8 = new org.apache.commons.math.FunctionEvaluationException(doubleArray7);
        org.apache.commons.math.linear.BigMatrix bigMatrix9 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray7);
        try {
            org.apache.commons.math.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math.linear.AnyMatrix) bigMatrix9);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(bigMatrix9);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor2 = null;
        try {
            double double3 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixPreservingVisitor2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.lang.String[] strArray0 = new java.lang.String[] {};
        java.lang.String[] strArray1 = new java.lang.String[] {};
        java.lang.String[] strArray2 = new java.lang.String[] {};
        java.lang.String[][] strArray3 = new java.lang.String[][] { strArray0, strArray1, strArray2 };
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix4 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(strArray3);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        double[] doubleArray1 = new double[] {};
        double[][] doubleArray2 = new double[][] { doubleArray1 };
        double[][] doubleArray3 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray2);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException4 = new org.apache.commons.math.linear.InvalidMatrixException("", (java.lang.Object[]) doubleArray3);
        java.lang.IllegalArgumentException illegalArgumentException5 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((java.lang.Throwable) invalidMatrixException4);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(illegalArgumentException5);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.io.ObjectInputStream objectInputStream2 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.deserializeRealVector((java.lang.Object) false, "", objectInputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = array2DRowRealMatrix0.add(array2DRowRealMatrix1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        double[] doubleArray3 = new double[] {};
        double[][] doubleArray4 = new double[][] { doubleArray3 };
        double[][] doubleArray5 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray4);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException6 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray5);
        org.apache.commons.math.exception.Localizable localizable7 = null;
        double[][] doubleArray10 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxEvaluationsExceededException6, localizable7, (java.lang.Object[]) doubleArray10);
        org.apache.commons.math.optimization.OptimizationException optimizationException12 = new org.apache.commons.math.optimization.OptimizationException("", (java.lang.Object[]) doubleArray10);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException13 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable) optimizationException12);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.apache.commons.math.exception.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException2 = new org.apache.commons.math.linear.InvalidMatrixException(localizable0, objArray1);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test045");
//        org.apache.commons.math.exception.Localizable localizable0 = null;
//        double[][] doubleArray4 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
//        java.lang.NullPointerException nullPointerException5 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray4);
//        try {
//            java.io.EOFException eOFException6 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable0, (java.lang.Object[]) doubleArray4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(doubleArray4);
//        org.junit.Assert.assertNotNull(nullPointerException5);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean4 = array2DRowRealMatrix3.isSquare();
        try {
            array2DRowRealMatrix0.setColumnMatrix((int) (short) 100, (org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 100 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.solve((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix2);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor1 = null;
        try {
            double double2 = array2DRowRealMatrix0.walkInRowOrder(realMatrixChangingVisitor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test049");
//        org.apache.commons.math.exception.Localizable localizable0 = null;
//        java.lang.Object[] objArray1 = null;
//        try {
//            java.lang.UnsupportedOperationException unsupportedOperationException2 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException(localizable0, objArray1);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix0, 1, 1, (-1), 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 1 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        double[] doubleArray1 = new double[] {};
        double[][] doubleArray2 = new double[][] { doubleArray1 };
        double[][] doubleArray3 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray2);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException4 = new org.apache.commons.math.linear.InvalidMatrixException("", (java.lang.Object[]) doubleArray3);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix5 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException1 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 10);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double[] doubleArray9 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException(doubleArray9);
        org.apache.commons.math.linear.RealMatrix realMatrix11 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray9);
        try {
            array2DRowRealMatrix0.setRowMatrix((int) (short) 10, realMatrix11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 10 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix2 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix((-1), 100);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test055");
//        org.apache.commons.math.exception.Localizable localizable0 = null;
//        double[] doubleArray5 = new double[] {};
//        double[][] doubleArray6 = new double[][] { doubleArray5 };
//        double[][] doubleArray7 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
//        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException8 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray7);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray7);
//        try {
//            java.lang.IllegalArgumentException illegalArgumentException10 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException(localizable0, (java.lang.Object[]) doubleArray7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(doubleArray5);
//        org.junit.Assert.assertNotNull(doubleArray6);
//        org.junit.Assert.assertNotNull(doubleArray7);
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        double[][] doubleArray3 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException4 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray3);
        org.apache.commons.math.exception.Localizable localizable6 = null;
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException12 = new org.apache.commons.math.MaxEvaluationsExceededException(10, "", (java.lang.Object[]) doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException13 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException4, (double) (short) -1, localizable6, (java.lang.Object[]) doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException4, 0.0d);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(nullPointerException4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        int int0 = org.apache.commons.math.linear.BlockRealMatrix.BLOCK_SIZE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 52 + "'", int0 == 52);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor2 = null;
        try {
            double double3 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixChangingVisitor2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor2 = null;
        try {
            double double3 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixPreservingVisitor2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix1 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix2 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix((int) 'a', 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        org.apache.commons.math.linear.RealVector realVector2 = null;
        try {
            org.apache.commons.math.linear.RealVector realVector3 = array2DRowRealMatrix0.preMultiply(realVector2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test063");
//        org.apache.commons.math.exception.Localizable localizable1 = null;
//        double[] doubleArray5 = new double[] {};
//        double[][] doubleArray6 = new double[][] { doubleArray5 };
//        double[][] doubleArray7 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
//        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException8 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray7);
//        java.lang.IllegalArgumentException illegalArgumentException9 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", (java.lang.Object[]) doubleArray7);
//        try {
//            java.text.ParseException parseException10 = org.apache.commons.math.MathRuntimeException.createParseException((int) '#', localizable1, (java.lang.Object[]) doubleArray7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(doubleArray5);
//        org.junit.Assert.assertNotNull(doubleArray6);
//        org.junit.Assert.assertNotNull(doubleArray7);
//        org.junit.Assert.assertNotNull(illegalArgumentException9);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        double[] doubleArray2 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable3 = null;
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray4 };
        double[][] doubleArray6 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray5);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException7 = new org.apache.commons.math.FunctionEvaluationException(doubleArray2, localizable3, (java.lang.Object[]) doubleArray5);
        try {
            java.lang.String str8 = functionEvaluationException7.getPattern();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor1 = null;
        try {
            double double6 = array2DRowRealMatrix0.walkInRowOrder(realMatrixPreservingVisitor1, (int) (byte) -1, (int) (short) 0, (int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index -1 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException1 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 0);
        org.apache.commons.math.optimization.OptimizationException optimizationException2 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) maxEvaluationsExceededException1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.apache.commons.math.exception.Localizable localizable1 = null;
        double[][] doubleArray5 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException6 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray5);
        java.lang.Throwable[] throwableArray7 = nullPointerException6.getSuppressed();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException8 = new org.apache.commons.math.MaxEvaluationsExceededException((-1), localizable1, (java.lang.Object[]) throwableArray7);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(nullPointerException6);
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException1 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 0);
        java.lang.String str2 = maxEvaluationsExceededException1.toString();
        int int3 = maxEvaluationsExceededException1.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded" + "'", str2.equals("org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int[] intArray6 = new int[] { 0, 52, (byte) -1, (-1), (byte) 0 };
        int[] intArray10 = new int[] { 1, (short) -1, (short) 1 };
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix11 = array2DRowRealMatrix0.getSubMatrix(intArray6, intArray10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 0 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray10);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getDeterminant();
        double[] doubleArray6 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable7 = null;
        double[] doubleArray8 = new double[] {};
        double[][] doubleArray9 = new double[][] { doubleArray8 };
        double[][] doubleArray10 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray9);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException11 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6, localizable7, (java.lang.Object[]) doubleArray9);
        double[] doubleArray17 = new double[] { 10L, '#', 0, 1.0d, '#' };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair19 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray6, doubleArray17, true);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray6);
        try {
            array2DRowRealMatrix0.setColumn(0, doubleArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 0 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realMatrix20);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor2 = null;
        try {
            double double3 = array2DRowRealMatrix0.walkInRowOrder(realMatrixChangingVisitor2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.lang.String[] strArray0 = null;
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix1 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(strArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math.linear.MatrixUtils.checkRowIndex((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix0, 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 10 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.apache.commons.math.exception.Localizable localizable2 = null;
        double[][] doubleArray6 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException7 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray6);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException8 = new org.apache.commons.math.linear.MatrixIndexException(localizable2, (java.lang.Object[]) doubleArray6);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math.linear.BlockRealMatrix((int) (short) 1, (int) (short) -1, doubleArray6, true);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(nullPointerException7);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getDeterminant();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor3 = null;
        try {
            double double8 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixChangingVisitor3, (int) (byte) 100, (int) (byte) 10, 52, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor2 = null;
        try {
            double double3 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixPreservingVisitor2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        double[] doubleArray2 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable3 = null;
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray4 };
        double[][] doubleArray6 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray5);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException7 = new org.apache.commons.math.FunctionEvaluationException(doubleArray2, localizable3, (java.lang.Object[]) doubleArray5);
        double[] doubleArray13 = new double[] { 10L, '#', 0, 1.0d, '#' };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair15 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray2, doubleArray13, true);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray2);
        int[] intArray21 = new int[] { '4', ' ', (byte) 1, '#' };
        int[] intArray28 = new int[] { '#', (byte) 1, 52, (byte) 10, 'a', ' ' };
        try {
            org.apache.commons.math.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math.linear.AnyMatrix) realMatrix16, intArray21, intArray28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 52 out of allowed range [0, 1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray28);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        double[] doubleArray3 = new double[] {};
        double[][] doubleArray4 = new double[][] { doubleArray3 };
        double[][] doubleArray5 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray4);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException6 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray5);
        org.apache.commons.math.exception.Localizable localizable7 = null;
        double[][] doubleArray10 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxEvaluationsExceededException6, localizable7, (java.lang.Object[]) doubleArray10);
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("", (java.lang.Object[]) doubleArray10);
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException12);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 1 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        try {
            org.apache.commons.math.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index -1 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.apache.commons.math.exception.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException8 = new org.apache.commons.math.FunctionEvaluationException(doubleArray7);
        org.apache.commons.math.exception.Localizable localizable9 = null;
        double[] doubleArray12 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable13 = null;
        double[] doubleArray14 = new double[] {};
        double[][] doubleArray15 = new double[][] { doubleArray14 };
        double[][] doubleArray16 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray15);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException(doubleArray12, localizable13, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException(doubleArray7, localizable9, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException(localizable0, (java.lang.Object[]) doubleArray15);
        try {
            java.lang.String str20 = convergenceException19.getPattern();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        boolean boolean2 = array2DRowRealMatrix0.isSingular();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.copy();
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.apache.commons.math.exception.Localizable localizable2 = null;
        double[] doubleArray9 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException(doubleArray9);
        org.apache.commons.math.exception.Localizable localizable11 = null;
        double[] doubleArray14 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable15 = null;
        double[] doubleArray16 = new double[] {};
        double[][] doubleArray17 = new double[][] { doubleArray16 };
        double[][] doubleArray18 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray17);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException19 = new org.apache.commons.math.FunctionEvaluationException(doubleArray14, localizable15, (java.lang.Object[]) doubleArray17);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException(doubleArray9, localizable11, (java.lang.Object[]) doubleArray17);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException(localizable2, (java.lang.Object[]) doubleArray17);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math.linear.BlockRealMatrix((-1), (int) (short) 0, doubleArray17, false);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        boolean boolean2 = array2DRowRealMatrix0.isSingular();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix4 = array2DRowRealMatrix0.scalarMultiply((double) (short) 10);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        boolean boolean2 = array2DRowRealMatrix0.isSingular();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix4 = array2DRowRealMatrix0.getColumnMatrix((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index -1 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double[][] doubleArray2 = array2DRowRealMatrix0.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int4 = array2DRowRealMatrix3.getColumnDimension();
        double double5 = array2DRowRealMatrix3.getDeterminant();
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = array2DRowRealMatrix0.subtract(array2DRowRealMatrix3);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        double[] doubleArray2 = new double[] {};
        double[][] doubleArray3 = new double[][] { doubleArray2 };
        double[][] doubleArray4 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray3);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException5 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray4);
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix6 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(doubleArray4);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.lang.String[] strArray0 = new java.lang.String[] {};
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix1 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(strArray0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.lang.String[] strArray1 = new java.lang.String[] { "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded" };
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix2 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(strArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        boolean boolean2 = array2DRowRealMatrix0.isSingular();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor3 = null;
        try {
            double double4 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixPreservingVisitor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix2 = array2DRowRealMatrix0.copy();
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.getColumnMatrix((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 100 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        double[][] doubleArray3 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException4 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray3);
        org.apache.commons.math.exception.Localizable localizable6 = null;
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException12 = new org.apache.commons.math.MaxEvaluationsExceededException(10, "", (java.lang.Object[]) doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException13 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException4, (double) (short) -1, localizable6, (java.lang.Object[]) doubleArray10);
        java.io.ObjectInputStream objectInputStream15 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.deserializeRealVector((java.lang.Object) localizable6, "hi!", objectInputStream15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(nullPointerException4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double[][] doubleArray2 = array2DRowRealMatrix0.getData();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix4 = array2DRowRealMatrix0.getRowMatrix((int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 32 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.apache.commons.math.exception.Localizable localizable0 = null;
        double[] doubleArray7 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException8 = new org.apache.commons.math.FunctionEvaluationException(doubleArray7);
        org.apache.commons.math.exception.Localizable localizable9 = null;
        double[] doubleArray12 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable13 = null;
        double[] doubleArray14 = new double[] {};
        double[][] doubleArray15 = new double[][] { doubleArray14 };
        double[][] doubleArray16 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray15);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException(doubleArray12, localizable13, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException(doubleArray7, localizable9, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException(localizable0, (java.lang.Object[]) doubleArray15);
        java.io.IOException iOException20 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) convergenceException19);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(iOException20);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        double[] doubleArray6 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException7 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6);
        org.apache.commons.math.linear.BigMatrix bigMatrix8 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray6);
        org.apache.commons.math.linear.AnyMatrix anyMatrix9 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math.linear.AnyMatrix) bigMatrix8, anyMatrix9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(bigMatrix8);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        double[] doubleArray9 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException(doubleArray9);
        org.apache.commons.math.linear.RealMatrix realMatrix11 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray9);
        double[] doubleArray18 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException19 = new org.apache.commons.math.FunctionEvaluationException(doubleArray18);
        org.apache.commons.math.exception.Localizable localizable20 = null;
        double[] doubleArray23 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable24 = null;
        double[] doubleArray25 = new double[] {};
        double[][] doubleArray26 = new double[][] { doubleArray25 };
        double[][] doubleArray27 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray26);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException28 = new org.apache.commons.math.FunctionEvaluationException(doubleArray23, localizable24, (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException(doubleArray18, localizable20, (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair31 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray9, doubleArray18, true);
        org.apache.commons.math.linear.RealMatrix realMatrix32 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray18);
        try {
            org.apache.commons.math.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math.linear.AnyMatrix) realMatrix32);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix32);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getDeterminant();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix5 = array2DRowRealMatrix0.createMatrix((int) (short) 1, (int) (short) 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        double[][] doubleArray3 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException4 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray3);
        try {
            double[][] doubleArray5 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(nullPointerException4);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        double[] doubleArray2 = new double[] {};
        double[][] doubleArray3 = new double[][] { doubleArray2 };
        double[][] doubleArray4 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray3);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException5 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray4);
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException12 = new org.apache.commons.math.MaxEvaluationsExceededException(10, "", (java.lang.Object[]) doubleArray10);
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException((java.lang.Throwable) maxEvaluationsExceededException5, "hi!", (java.lang.Object[]) doubleArray10);
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10, false);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        double[] doubleArray6 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException7 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6);
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) functionEvaluationException7);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        int int0 = org.apache.commons.math.linear.BlockFieldMatrix.BLOCK_SIZE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 36 + "'", int0 == 36);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double[][] doubleArray2 = array2DRowRealMatrix0.getData();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor3 = null;
        try {
            double double4 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixChangingVisitor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.scalarAdd((double) 0.0f);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException();
        double[] doubleArray7 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable8 = null;
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(doubleArray7, localizable8, (java.lang.Object[]) doubleArray10);
        double[][] doubleArray13 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray10);
        int int15 = maxIterationsExceededException14.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable16 = maxIterationsExceededException14.getLocalizablePattern();
        double[] doubleArray22 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable23 = null;
        double[] doubleArray24 = new double[] {};
        double[][] doubleArray25 = new double[][] { doubleArray24 };
        double[][] doubleArray26 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray25);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException27 = new org.apache.commons.math.FunctionEvaluationException(doubleArray22, localizable23, (java.lang.Object[]) doubleArray25);
        double[][] doubleArray28 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray25);
        int int30 = maxIterationsExceededException29.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable31 = maxIterationsExceededException29.getLocalizablePattern();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException33 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray34 = functionEvaluationException33.getSuppressed();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException35 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a', localizable31, (java.lang.Object[]) throwableArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException2, localizable16, (java.lang.Object[]) throwableArray34);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) throwableArray34);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 52 + "'", int15 == 52);
        org.junit.Assert.assertNotNull(localizable16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 52 + "'", int30 == 52);
        org.junit.Assert.assertNotNull(localizable31);
        org.junit.Assert.assertNotNull(throwableArray34);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.apache.commons.math.exception.Localizable localizable0 = null;
        double[][] doubleArray4 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException5 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray4);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException6 = new org.apache.commons.math.linear.MatrixIndexException(localizable0, (java.lang.Object[]) doubleArray4);
        java.lang.RuntimeException runtimeException7 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) matrixIndexException6);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(nullPointerException5);
        org.junit.Assert.assertNotNull(runtimeException7);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getDeterminant();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor3 = null;
        try {
            double double4 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixPreservingVisitor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getDeterminant();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.copy();
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor2 = null;
        try {
            double double3 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixChangingVisitor2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        boolean boolean4 = array2DRowRealMatrix0.equals((java.lang.Object) 36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int6 = array2DRowRealMatrix5.getColumnDimension();
        double double7 = array2DRowRealMatrix5.getFrobeniusNorm();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix8 = array2DRowRealMatrix0.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor3 = null;
        try {
            double double8 = array2DRowRealMatrix0.walkInOptimizedOrder(realMatrixPreservingVisitor3, 0, (-1), (-1), 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 0 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math.linear.RealVector realVector3 = null;
        try {
            org.apache.commons.math.linear.RealVector realVector4 = array2DRowRealMatrix0.operate(realVector3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        boolean boolean2 = array2DRowRealMatrix0.isSingular();
        try {
            org.apache.commons.math.linear.RealVector realVector4 = array2DRowRealMatrix0.getRowVector((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 0 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        boolean boolean2 = array2DRowRealMatrix0.isSingular();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.inverse();
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        double[] doubleArray2 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable3 = null;
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray4 };
        double[][] doubleArray6 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray5);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException7 = new org.apache.commons.math.FunctionEvaluationException(doubleArray2, localizable3, (java.lang.Object[]) doubleArray5);
        double[] doubleArray13 = new double[] { 10L, '#', 0, 1.0d, '#' };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair15 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray2, doubleArray13, true);
        org.apache.commons.math.exception.Localizable localizable16 = null;
        double[] doubleArray20 = new double[] {};
        double[][] doubleArray21 = new double[][] { doubleArray20 };
        double[][] doubleArray22 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray21);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException23 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray22);
        org.apache.commons.math.exception.Localizable localizable24 = null;
        double[][] doubleArray27 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxEvaluationsExceededException23, localizable24, (java.lang.Object[]) doubleArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException("", (java.lang.Object[]) doubleArray27);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException30 = new org.apache.commons.math.FunctionEvaluationException(doubleArray13, localizable16, (java.lang.Object[]) doubleArray27);
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix31 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(doubleArray27);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        boolean boolean2 = array2DRowRealMatrix0.isSingular();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean4 = array2DRowRealMatrix3.isSquare();
        boolean boolean5 = array2DRowRealMatrix3.isSingular();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix0.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix3);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        boolean boolean2 = array2DRowRealMatrix0.isSingular();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor3 = null;
        try {
            double double8 = array2DRowRealMatrix0.walkInRowOrder(realMatrixChangingVisitor3, 0, (int) (byte) 1, (int) (short) 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 0 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        double[] doubleArray2 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable3 = null;
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray4 };
        double[][] doubleArray6 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray5);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException7 = new org.apache.commons.math.FunctionEvaluationException(doubleArray2, localizable3, (java.lang.Object[]) doubleArray5);
        double[] doubleArray13 = new double[] { 10L, '#', 0, 1.0d, '#' };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair15 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray2, doubleArray13, true);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray2);
        try {
            org.apache.commons.math.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math.linear.AnyMatrix) realMatrix16, (int) (short) 100, 100, 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, 1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix16);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double[][] doubleArray2 = array2DRowRealMatrix0.getData();
        double[] doubleArray10 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException11 = new org.apache.commons.math.FunctionEvaluationException(doubleArray10);
        org.apache.commons.math.linear.RealMatrix realMatrix12 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray10);
        try {
            array2DRowRealMatrix0.setColumnMatrix((int) (byte) 100, realMatrix12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 100 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix12);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.lang.String[] strArray3 = new java.lang.String[] { "hi!", "hi!", "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded" };
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix4 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(strArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        double[] doubleArray2 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable3 = null;
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray4 };
        double[][] doubleArray6 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray5);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException7 = new org.apache.commons.math.FunctionEvaluationException(doubleArray2, localizable3, (java.lang.Object[]) doubleArray5);
        double[] doubleArray13 = new double[] { 10L, '#', 0, 1.0d, '#' };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair15 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray2, doubleArray13, true);
        org.apache.commons.math.exception.Localizable localizable16 = null;
        double[] doubleArray20 = new double[] {};
        double[][] doubleArray21 = new double[][] { doubleArray20 };
        double[][] doubleArray22 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray21);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException23 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray22);
        org.apache.commons.math.exception.Localizable localizable24 = null;
        double[][] doubleArray27 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxEvaluationsExceededException23, localizable24, (java.lang.Object[]) doubleArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException("", (java.lang.Object[]) doubleArray27);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException30 = new org.apache.commons.math.FunctionEvaluationException(doubleArray13, localizable16, (java.lang.Object[]) doubleArray27);
        java.io.ObjectInputStream objectInputStream32 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.deserializeRealVector((java.lang.Object) doubleArray27, "", objectInputStream32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.createMatrix((int) (byte) 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor2 = null;
        try {
            double double3 = array2DRowRealMatrix0.walkInOptimizedOrder(realMatrixPreservingVisitor2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        boolean boolean2 = array2DRowRealMatrix0.isSingular();
        int[] intArray8 = new int[] { (byte) 100, (byte) -1, (short) 1, (byte) -1, ' ' };
        int[] intArray9 = null;
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix10 = array2DRowRealMatrix0.getSubMatrix(intArray8, intArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(intArray8);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        boolean boolean2 = array2DRowRealMatrix0.isSingular();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean4 = array2DRowRealMatrix3.isSquare();
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = array2DRowRealMatrix0.multiply(array2DRowRealMatrix3);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double[] doubleArray6 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable7 = null;
        double[] doubleArray8 = new double[] {};
        double[][] doubleArray9 = new double[][] { doubleArray8 };
        double[][] doubleArray10 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray9);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException11 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6, localizable7, (java.lang.Object[]) doubleArray9);
        double[] doubleArray17 = new double[] { 10L, '#', 0, 1.0d, '#' };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair19 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray6, doubleArray17, true);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray6);
        try {
            blockRealMatrix2.setColumn((int) (byte) -1, doubleArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index -1 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realMatrix20);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        try {
            blockRealMatrix2.addToEntry((int) '4', (int) (short) 0, 10.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (52, 0) in a 35x10 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix2 = array2DRowRealMatrix0.getColumnMatrix(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 0 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        boolean boolean2 = array2DRowRealMatrix0.isSingular();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor3 = null;
        try {
            double double4 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixPreservingVisitor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        try {
            blockRealMatrix2.luDecompose();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 35x10 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor3 = null;
        try {
            double double8 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixPreservingVisitor3, (int) ' ', (int) '#', (int) (byte) 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 32 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        boolean boolean2 = array2DRowRealMatrix0.isSingular();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.inverse();
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor2 = null;
        try {
            double double3 = array2DRowRealMatrix0.walkInRowOrder(realMatrixPreservingVisitor2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = array2DRowRealMatrix0.subtract(array2DRowRealMatrix2);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        boolean boolean2 = array2DRowRealMatrix0.isSingular();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor3 = null;
        try {
            double double4 = array2DRowRealMatrix0.walkInRowOrder(realMatrixPreservingVisitor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        double[] doubleArray5 = new double[] {};
        double[][] doubleArray6 = new double[][] { doubleArray5 };
        double[][] doubleArray7 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException8 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray7);
        double[] doubleArray17 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException(doubleArray17);
        org.apache.commons.math.exception.Localizable localizable19 = null;
        double[] doubleArray22 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable23 = null;
        double[] doubleArray24 = new double[] {};
        double[][] doubleArray25 = new double[][] { doubleArray24 };
        double[][] doubleArray26 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray25);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException27 = new org.apache.commons.math.FunctionEvaluationException(doubleArray22, localizable23, (java.lang.Object[]) doubleArray25);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException28 = new org.apache.commons.math.FunctionEvaluationException(doubleArray17, localizable19, (java.lang.Object[]) doubleArray25);
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray25);
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException9, "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) doubleArray25);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException31 = new org.apache.commons.math.linear.InvalidMatrixException("hi!", (java.lang.Object[]) doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.RealVector realVector4 = null;
        try {
            blockRealMatrix2.setColumnVector((int) (short) 0, realVector4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor2 = null;
        try {
            double double7 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixChangingVisitor2, (int) '#', 36, (int) (short) -1, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 35 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        blockRealMatrix2.addToEntry(0, 1, (double) 1L);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double10 = blockRealMatrix9.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix9.getRowMatrix(0);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = blockRealMatrix2.multiply(blockRealMatrix12);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        double[] doubleArray12 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException13 = new org.apache.commons.math.FunctionEvaluationException(doubleArray12);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray12);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix5.add(realMatrix14);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realMatrix14);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        double[][] doubleArray3 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException4 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray3);
        java.lang.Throwable[] throwableArray5 = nullPointerException4.getSuppressed();
        org.apache.commons.math.exception.Localizable localizable6 = null;
        double[] doubleArray9 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable10 = null;
        double[] doubleArray11 = new double[] {};
        double[][] doubleArray12 = new double[][] { doubleArray11 };
        double[][] doubleArray13 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray12);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException14 = new org.apache.commons.math.FunctionEvaluationException(doubleArray9, localizable10, (java.lang.Object[]) doubleArray12);
        double[][] doubleArray15 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray12);
        org.apache.commons.math.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) nullPointerException4, localizable6, (java.lang.Object[]) doubleArray15);
        try {
            java.lang.String str17 = mathRuntimeException16.getPattern();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(nullPointerException4);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double[][] doubleArray2 = array2DRowRealMatrix0.getData();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix3 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        boolean boolean2 = array2DRowRealMatrix0.isSingular();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor3 = null;
        try {
            double double8 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixChangingVisitor3, (int) ' ', (int) (short) -1, (int) (byte) 100, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 32 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        double[] doubleArray6 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable7 = null;
        double[] doubleArray8 = new double[] {};
        double[][] doubleArray9 = new double[][] { doubleArray8 };
        double[][] doubleArray10 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray9);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException11 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6, localizable7, (java.lang.Object[]) doubleArray9);
        double[] doubleArray17 = new double[] { 10L, '#', 0, 1.0d, '#' };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair19 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray6, doubleArray17, true);
        try {
            double[] doubleArray20 = blockRealMatrix2.operate(doubleArray6);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double[][] doubleArray2 = array2DRowRealMatrix0.getData();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix4 = array2DRowRealMatrix0.scalarMultiply(10.0d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix8 = blockRealMatrix2.getSubMatrix(100, 36, 52, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, 34]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        blockRealMatrix2.addToEntry(0, 1, (double) 1L);
        try {
            double double9 = blockRealMatrix2.getEntry((int) 'a', (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (97, 100) in a 35x10 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        blockRealMatrix2.addToEntry(0, 1, (double) 1L);
        try {
            double[] doubleArray8 = blockRealMatrix2.getRow((-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index -1 out of allowed range [0, 34]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int3 = array2DRowRealMatrix2.getColumnDimension();
        double double4 = array2DRowRealMatrix2.getFrobeniusNorm();
        boolean boolean6 = array2DRowRealMatrix2.equals((java.lang.Object) 36);
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = array2DRowRealMatrix0.multiply(array2DRowRealMatrix2);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        boolean boolean2 = array2DRowRealMatrix0.isSingular();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean4 = array2DRowRealMatrix3.isSquare();
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = array2DRowRealMatrix0.multiply(array2DRowRealMatrix3);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.lang.String[] strArray6 = new java.lang.String[] { "Array2DRowRealMatrix{}", "hi!", "hi!", "Array2DRowRealMatrix{}", "", "{0}" };
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix7 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        double[] doubleArray5 = new double[] {};
        double[][] doubleArray6 = new double[][] { doubleArray5 };
        double[][] doubleArray7 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException8 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray7);
        java.lang.IllegalArgumentException illegalArgumentException9 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", (java.lang.Object[]) doubleArray7);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix11 = new org.apache.commons.math.linear.BlockRealMatrix(100, (int) ' ', doubleArray7, false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(illegalArgumentException9);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix4 = array2DRowRealMatrix0.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix3);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        double[][] doubleArray0 = null;
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix1 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor4 = null;
        try {
            double double5 = blockRealMatrix2.walkInRowOrder(realMatrixPreservingVisitor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.apache.commons.math.exception.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException2 = new org.apache.commons.math.linear.MatrixIndexException(localizable0, objArray1);
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException((java.lang.Throwable) matrixIndexException2);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.apache.commons.math.linear.RealVector realVector0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.serializeRealVector(realVector0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) -1, (-1));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        try {
            org.apache.commons.math.linear.RealVector realVector4 = blockRealMatrix2.getColumnVector((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index -1 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        boolean boolean2 = array2DRowRealMatrix0.isSquare();
        java.io.ObjectInputStream objectInputStream4 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.deserializeRealVector((java.lang.Object) boolean2, "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", objectInputStream4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.RealVector realVector4 = null;
        try {
            blockRealMatrix2.setColumnVector(0, realVector4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        double[] doubleArray5 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable6 = null;
        double[] doubleArray7 = new double[] {};
        double[][] doubleArray8 = new double[][] { doubleArray7 };
        double[][] doubleArray9 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray8);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException(doubleArray5, localizable6, (java.lang.Object[]) doubleArray8);
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray8);
        int int13 = maxIterationsExceededException12.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable14 = maxIterationsExceededException12.getLocalizablePattern();
        double[] doubleArray20 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable21 = null;
        double[] doubleArray22 = new double[] {};
        double[][] doubleArray23 = new double[][] { doubleArray22 };
        double[][] doubleArray24 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray23);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException(doubleArray20, localizable21, (java.lang.Object[]) doubleArray23);
        double[][] doubleArray26 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray23);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray23);
        int int28 = maxIterationsExceededException27.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable29 = maxIterationsExceededException27.getLocalizablePattern();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException31 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray32 = functionEvaluationException31.getSuppressed();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException33 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a', localizable29, (java.lang.Object[]) throwableArray32);
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException0, localizable14, (java.lang.Object[]) throwableArray32);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathException0, (double) (short) -1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 52 + "'", int13 == 52);
        org.junit.Assert.assertNotNull(localizable14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 52 + "'", int28 == 52);
        org.junit.Assert.assertNotNull(localizable29);
        org.junit.Assert.assertNotNull(throwableArray32);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        int int4 = blockRealMatrix2.getColumnDimension();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor5 = null;
        try {
            double double10 = blockRealMatrix2.walkInColumnOrder(realMatrixPreservingVisitor5, 10, 1, 1, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: initial row 10 after final row 1");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int3 = array2DRowRealMatrix2.getColumnDimension();
        double double4 = array2DRowRealMatrix2.getDeterminant();
        java.lang.String str5 = array2DRowRealMatrix2.toString();
        try {
            array2DRowRealMatrix0.setColumnMatrix((int) (short) 10, (org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 10 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Array2DRowRealMatrix{}" + "'", str5.equals("Array2DRowRealMatrix{}"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        double[] doubleArray5 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable6 = null;
        double[] doubleArray7 = new double[] {};
        double[][] doubleArray8 = new double[][] { doubleArray7 };
        double[][] doubleArray9 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray8);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException(doubleArray5, localizable6, (java.lang.Object[]) doubleArray8);
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray8);
        int int13 = maxIterationsExceededException12.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable14 = maxIterationsExceededException12.getLocalizablePattern();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray17 = functionEvaluationException16.getSuppressed();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException18 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a', localizable14, (java.lang.Object[]) throwableArray17);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException19 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable) maxEvaluationsExceededException18);
        int int20 = maxEvaluationsExceededException18.getMaxEvaluations();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 52 + "'", int13 == 52);
        org.junit.Assert.assertNotNull(localizable14);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 97 + "'", int20 == 97);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        double[] doubleArray0 = new double[] {};
        double[][] doubleArray1 = new double[][] { doubleArray0 };
        double[][] doubleArray2 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray1);
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray1, false);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        double[] doubleArray5 = blockRealMatrix2.getRow(10);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor6 = null;
        try {
            double double7 = blockRealMatrix2.walkInOptimizedOrder(realMatrixChangingVisitor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getDeterminant();
        try {
            double[] doubleArray4 = array2DRowRealMatrix0.getColumn(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 0 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix6 = null;
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix5.subtract(blockRealMatrix6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        double[][] doubleArray2 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(10, (int) ' ');
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor4 = null;
        try {
            double double5 = blockRealMatrix2.walkInOptimizedOrder(realMatrixChangingVisitor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.getSubMatrix((int) (byte) 1, (int) '#', 52, 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 35 out of allowed range [0, 34]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        blockRealMatrix2.addToEntry(0, 1, (double) 1L);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean9 = array2DRowRealMatrix8.isSquare();
        boolean boolean10 = array2DRowRealMatrix8.isSquare();
        try {
            blockRealMatrix2.setRowMatrix((int) (short) 1, (org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.InvalidMatrixException; message: dimensions mismatch: got 0x0 but expected 1x10");
        } catch (org.apache.commons.math.linear.InvalidMatrixException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double[][] doubleArray7 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException8 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray7);
        java.lang.Throwable[] throwableArray9 = nullPointerException8.getSuppressed();
        org.apache.commons.math.exception.Localizable localizable10 = null;
        double[] doubleArray13 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable14 = null;
        double[] doubleArray15 = new double[] {};
        double[][] doubleArray16 = new double[][] { doubleArray15 };
        double[][] doubleArray17 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray16);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException(doubleArray13, localizable14, (java.lang.Object[]) doubleArray16);
        double[][] doubleArray19 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray16);
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) nullPointerException8, localizable10, (java.lang.Object[]) doubleArray19);
        double[] doubleArray27 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException28 = new org.apache.commons.math.FunctionEvaluationException(doubleArray27);
        double[][] doubleArray33 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException34 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray33);
        java.lang.Throwable[] throwableArray35 = nullPointerException34.getSuppressed();
        double[] doubleArray42 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException43 = new org.apache.commons.math.FunctionEvaluationException(doubleArray42);
        org.apache.commons.math.linear.RealMatrix realMatrix44 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray42);
        double[] doubleArray51 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException52 = new org.apache.commons.math.FunctionEvaluationException(doubleArray51);
        java.io.IOException iOException53 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) functionEvaluationException52);
        double[] doubleArray57 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable58 = null;
        double[] doubleArray59 = new double[] {};
        double[][] doubleArray60 = new double[][] { doubleArray59 };
        double[][] doubleArray61 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray60);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException62 = new org.apache.commons.math.FunctionEvaluationException(doubleArray57, localizable58, (java.lang.Object[]) doubleArray60);
        double[][] doubleArray63 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray60);
        java.lang.NullPointerException nullPointerException64 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray63);
        java.lang.Object[] objArray65 = new java.lang.Object[] { nullPointerException34, realMatrix44, functionEvaluationException52, "" };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException66 = new org.apache.commons.math.FunctionEvaluationException(doubleArray27, "hi!", objArray65);
        org.apache.commons.math.linear.BigMatrix bigMatrix67 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(doubleArray27);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException68 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathRuntimeException20, doubleArray27);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException69 = new org.apache.commons.math.FunctionEvaluationException(doubleArray27);
        try {
            blockRealMatrix2.setRow(100, doubleArray27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, 34]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(nullPointerException8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(nullPointerException34);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(iOException53);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(nullPointerException64);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(bigMatrix67);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.apache.commons.math.exception.Localizable localizable1 = null;
        double[][] doubleArray5 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException6 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray5);
        org.apache.commons.math.exception.Localizable localizable8 = null;
        double[] doubleArray11 = new double[] {};
        double[][] doubleArray12 = new double[][] { doubleArray11 };
        double[][] doubleArray13 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray12);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException14 = new org.apache.commons.math.MaxEvaluationsExceededException(10, "", (java.lang.Object[]) doubleArray12);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException6, (double) (short) -1, localizable8, (java.lang.Object[]) doubleArray12);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException16 = new org.apache.commons.math.MaxIterationsExceededException(1, localizable1, (java.lang.Object[]) doubleArray12);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException17 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable) maxIterationsExceededException16);
        java.lang.Object[] objArray18 = invalidMatrixException17.getArguments();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(nullPointerException6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(objArray18);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        double[] doubleArray6 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException7 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6);
        double[][] doubleArray12 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException13 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray12);
        java.lang.Throwable[] throwableArray14 = nullPointerException13.getSuppressed();
        double[] doubleArray21 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException22 = new org.apache.commons.math.FunctionEvaluationException(doubleArray21);
        org.apache.commons.math.linear.RealMatrix realMatrix23 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray21);
        double[] doubleArray30 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException31 = new org.apache.commons.math.FunctionEvaluationException(doubleArray30);
        java.io.IOException iOException32 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) functionEvaluationException31);
        double[] doubleArray36 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable37 = null;
        double[] doubleArray38 = new double[] {};
        double[][] doubleArray39 = new double[][] { doubleArray38 };
        double[][] doubleArray40 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray39);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException41 = new org.apache.commons.math.FunctionEvaluationException(doubleArray36, localizable37, (java.lang.Object[]) doubleArray39);
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray39);
        java.lang.NullPointerException nullPointerException43 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray42);
        java.lang.Object[] objArray44 = new java.lang.Object[] { nullPointerException13, realMatrix23, functionEvaluationException31, "" };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException45 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6, "hi!", objArray44);
        java.lang.Throwable throwable46 = null;
        try {
            functionEvaluationException45.addSuppressed(throwable46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(nullPointerException13);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(iOException32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(nullPointerException43);
        org.junit.Assert.assertNotNull(objArray44);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        int int4 = blockRealMatrix2.getColumnDimension();
        int[] intArray6 = new int[] { '#' };
        int[] intArray12 = new int[] { 100, (byte) 1, 36, (short) 10, 97 };
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix13 = blockRealMatrix2.getSubMatrix(intArray6, intArray12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 35 out of allowed range [0, 34]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray12);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getDeterminant();
        org.apache.commons.math.linear.RealMatrix realMatrix3 = null;
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix4 = array2DRowRealMatrix0.multiply(realMatrix3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        double[][] doubleArray2 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix3 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        double[] doubleArray8 = new double[] {};
        double[][] doubleArray9 = new double[][] { doubleArray8 };
        double[][] doubleArray10 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray9);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException11 = new org.apache.commons.math.MaxEvaluationsExceededException(10, "", (java.lang.Object[]) doubleArray9);
        boolean boolean12 = blockRealMatrix5.equals((java.lang.Object) "");
        org.apache.commons.math.linear.AnyMatrix anyMatrix13 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix5, anyMatrix13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getDeterminant();
        java.lang.String str3 = array2DRowRealMatrix0.toString();
        double double4 = array2DRowRealMatrix0.getDeterminant();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor5 = null;
        try {
            double double10 = array2DRowRealMatrix0.walkInRowOrder(realMatrixChangingVisitor5, (int) '4', 0, (int) (short) 1, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 52 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Array2DRowRealMatrix{}" + "'", str3.equals("Array2DRowRealMatrix{}"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        double[] doubleArray6 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException7 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray6);
        try {
            org.apache.commons.math.linear.MatrixUtils.checkRowIndex((org.apache.commons.math.linear.AnyMatrix) realMatrix8, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, 5]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix8);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        boolean boolean2 = array2DRowRealMatrix0.isSingular();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int4 = array2DRowRealMatrix3.getColumnDimension();
        double double5 = array2DRowRealMatrix3.getDeterminant();
        java.lang.String str6 = array2DRowRealMatrix3.toString();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix7 = array2DRowRealMatrix0.multiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix3);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Array2DRowRealMatrix{}" + "'", str6.equals("Array2DRowRealMatrix{}"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        java.math.BigDecimal[] bigDecimalArray0 = new java.math.BigDecimal[] {};
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix1 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(bigDecimalArray0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigDecimalArray0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        boolean boolean2 = array2DRowRealMatrix0.isSingular();
        double[] doubleArray12 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable13 = null;
        double[] doubleArray14 = new double[] {};
        double[][] doubleArray15 = new double[][] { doubleArray14 };
        double[][] doubleArray16 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray15);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException(doubleArray12, localizable13, (java.lang.Object[]) doubleArray15);
        double[][] doubleArray18 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray15);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray15);
        int int20 = maxIterationsExceededException19.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable21 = maxIterationsExceededException19.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable22 = null;
        double[][] doubleArray26 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException27 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException28 = new org.apache.commons.math.linear.MatrixIndexException(localizable22, (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', localizable21, (java.lang.Object[]) doubleArray26);
        try {
            array2DRowRealMatrix0.copySubMatrix((int) '4', (-1), (int) (short) 10, (int) 'a', doubleArray26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 52 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 52 + "'", int20 == 52);
        org.junit.Assert.assertNotNull(localizable21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(nullPointerException27);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        boolean boolean2 = array2DRowRealMatrix0.isSquare();
        int[] intArray4 = new int[] { (byte) 10 };
        int[] intArray6 = new int[] { 36 };
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix7 = array2DRowRealMatrix0.getSubMatrix(intArray4, intArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 10 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double5 = blockRealMatrix4.getFrobeniusNorm();
        int int6 = blockRealMatrix4.getColumnDimension();
        org.apache.commons.math.linear.RealVector realVector8 = blockRealMatrix4.getColumnVector(0);
        try {
            org.apache.commons.math.linear.RealVector realVector9 = array2DRowRealMatrix0.preMultiply(realVector8);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(realVector8);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        double[] doubleArray8 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable9 = null;
        double[] doubleArray10 = new double[] {};
        double[][] doubleArray11 = new double[][] { doubleArray10 };
        double[][] doubleArray12 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray11);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException13 = new org.apache.commons.math.FunctionEvaluationException(doubleArray8, localizable9, (java.lang.Object[]) doubleArray11);
        double[][] doubleArray14 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray11);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray11);
        int int16 = maxIterationsExceededException15.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable17 = maxIterationsExceededException15.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable18 = null;
        double[][] doubleArray22 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException23 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray22);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException24 = new org.apache.commons.math.linear.MatrixIndexException(localizable18, (java.lang.Object[]) doubleArray22);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', localizable17, (java.lang.Object[]) doubleArray22);
        double[] doubleArray29 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable30 = null;
        double[] doubleArray31 = new double[] {};
        double[][] doubleArray32 = new double[][] { doubleArray31 };
        double[][] doubleArray33 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray32);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException34 = new org.apache.commons.math.FunctionEvaluationException(doubleArray29, localizable30, (java.lang.Object[]) doubleArray32);
        double[][] doubleArray35 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray32);
        java.lang.NullPointerException nullPointerException36 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray35);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException37 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 10, localizable17, (java.lang.Object[]) doubleArray35);
        java.text.ParseException parseException38 = org.apache.commons.math.MathRuntimeException.createParseException(1, "{0}", (java.lang.Object[]) doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 52 + "'", int16 == 52);
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(nullPointerException23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(nullPointerException36);
        org.junit.Assert.assertNotNull(parseException38);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        double[] doubleArray5 = blockRealMatrix2.getRow(10);
        double[][] doubleArray6 = blockRealMatrix2.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double11 = blockRealMatrix10.getFrobeniusNorm();
        int int12 = blockRealMatrix10.getColumnDimension();
        org.apache.commons.math.linear.RealVector realVector14 = blockRealMatrix10.getColumnVector(0);
        try {
            blockRealMatrix2.setRowVector(0, realVector14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.InvalidMatrixException; message: dimensions mismatch: got 1x35 but expected 1x10");
        } catch (org.apache.commons.math.linear.InvalidMatrixException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertNotNull(realVector14);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.RealVector realVector5 = null;
        try {
            blockRealMatrix2.setColumnVector(0, realVector5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        double[] doubleArray5 = blockRealMatrix2.getRow(10);
        double[][] doubleArray6 = blockRealMatrix2.getData();
        org.apache.commons.math.exception.Localizable localizable7 = null;
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException12 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray11);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException13 = new org.apache.commons.math.linear.MatrixIndexException(localizable7, (java.lang.Object[]) doubleArray11);
        try {
            blockRealMatrix2.setSubMatrix(doubleArray11, 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(nullPointerException12);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getDeterminant();
        java.lang.String str3 = array2DRowRealMatrix0.toString();
        double double4 = array2DRowRealMatrix0.getDeterminant();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double8 = blockRealMatrix7.getFrobeniusNorm();
        int int9 = blockRealMatrix7.getColumnDimension();
        org.apache.commons.math.linear.RealVector realVector11 = blockRealMatrix7.getColumnVector(0);
        try {
            org.apache.commons.math.linear.RealVector realVector12 = array2DRowRealMatrix0.preMultiply(realVector11);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Array2DRowRealMatrix{}" + "'", str3.equals("Array2DRowRealMatrix{}"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertNotNull(realVector11);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix6 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix((int) (byte) 1, 100);
        try {
            array2DRowRealMatrix0.setColumnMatrix((int) '4', realMatrix6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 52 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix6);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getDeterminant();
        java.lang.String str3 = array2DRowRealMatrix0.toString();
        double double4 = array2DRowRealMatrix0.getDeterminant();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor5 = null;
        try {
            double double10 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixPreservingVisitor5, (int) (short) 1, (int) (short) 100, 52, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 1 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Array2DRowRealMatrix{}" + "'", str3.equals("Array2DRowRealMatrix{}"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double[][] doubleArray2 = array2DRowRealMatrix0.getData();
        boolean boolean3 = array2DRowRealMatrix0.isSquare();
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl5 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix0, (double) 1.0f);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix6 = lUDecompositionImpl5.getP();
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        java.lang.String[] strArray5 = new java.lang.String[] { "hi!", "", "Array2DRowRealMatrix{}", "{0}", "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded" };
        java.lang.String[] strArray11 = new java.lang.String[] { "hi!", "", "Array2DRowRealMatrix{}", "{0}", "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded" };
        java.lang.String[] strArray17 = new java.lang.String[] { "hi!", "", "Array2DRowRealMatrix{}", "{0}", "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded" };
        java.lang.String[] strArray23 = new java.lang.String[] { "hi!", "", "Array2DRowRealMatrix{}", "{0}", "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded" };
        java.lang.String[][] strArray24 = new java.lang.String[][] { strArray5, strArray11, strArray17, strArray23 };
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix25 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(strArray24);
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertNotNull(strArray24);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor6 = null;
        try {
            double double7 = blockRealMatrix5.walkInRowOrder(realMatrixPreservingVisitor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        boolean boolean6 = blockRealMatrix2.isSquare();
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix2.getColumnMatrix(10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 10 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker2 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker((double) (-1), (double) 0L);
        double[] doubleArray6 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable7 = null;
        double[] doubleArray8 = new double[] {};
        double[][] doubleArray9 = new double[][] { doubleArray8 };
        double[][] doubleArray10 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray9);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException11 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6, localizable7, (java.lang.Object[]) doubleArray9);
        double[] doubleArray17 = new double[] { 10L, '#', 0, 1.0d, '#' };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair19 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray6, doubleArray17, true);
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker20 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        double[] doubleArray24 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable25 = null;
        double[] doubleArray26 = new double[] {};
        double[][] doubleArray27 = new double[][] { doubleArray26 };
        double[][] doubleArray28 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray27);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException(doubleArray24, localizable25, (java.lang.Object[]) doubleArray27);
        double[] doubleArray35 = new double[] { 10L, '#', 0, 1.0d, '#' };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair37 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray24, doubleArray35, true);
        double[] doubleArray40 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable41 = null;
        double[] doubleArray42 = new double[] {};
        double[][] doubleArray43 = new double[][] { doubleArray42 };
        double[][] doubleArray44 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray43);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException45 = new org.apache.commons.math.FunctionEvaluationException(doubleArray40, localizable41, (java.lang.Object[]) doubleArray43);
        double[] doubleArray51 = new double[] { 10L, '#', 0, 1.0d, '#' };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair53 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray40, doubleArray51, true);
        boolean boolean54 = simpleVectorialValueChecker20.converged(10, vectorialPointValuePair37, vectorialPointValuePair53);
        boolean boolean55 = simpleVectorialValueChecker2.converged((int) ' ', vectorialPointValuePair19, vectorialPointValuePair37);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        java.lang.String[][] strArray0 = new java.lang.String[][] {};
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix1 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(strArray0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        try {
            boolean boolean8 = blockRealMatrix5.isSingular();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 35x10 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        double[] doubleArray11 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(doubleArray11);
        double[][] doubleArray17 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException18 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray17);
        java.lang.Throwable[] throwableArray19 = nullPointerException18.getSuppressed();
        double[] doubleArray26 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException27 = new org.apache.commons.math.FunctionEvaluationException(doubleArray26);
        org.apache.commons.math.linear.RealMatrix realMatrix28 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray26);
        double[] doubleArray35 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException(doubleArray35);
        java.io.IOException iOException37 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) functionEvaluationException36);
        double[] doubleArray41 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable42 = null;
        double[] doubleArray43 = new double[] {};
        double[][] doubleArray44 = new double[][] { doubleArray43 };
        double[][] doubleArray45 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray44);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException46 = new org.apache.commons.math.FunctionEvaluationException(doubleArray41, localizable42, (java.lang.Object[]) doubleArray44);
        double[][] doubleArray47 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray44);
        java.lang.NullPointerException nullPointerException48 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray47);
        java.lang.Object[] objArray49 = new java.lang.Object[] { nullPointerException18, realMatrix28, functionEvaluationException36, "" };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException50 = new org.apache.commons.math.FunctionEvaluationException(doubleArray11, "hi!", objArray49);
        try {
            blockRealMatrix2.setColumn(10, doubleArray11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 10 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(nullPointerException18);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(iOException37);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(nullPointerException48);
        org.junit.Assert.assertNotNull(objArray49);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        double[][] doubleArray0 = null;
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        try {
            blockRealMatrix2.multiplyEntry((int) (byte) -1, 52, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (-1, 52) in a 35x10 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        double[] doubleArray6 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException7 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray6);
        double[] doubleArray15 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException(doubleArray15);
        org.apache.commons.math.exception.Localizable localizable17 = null;
        double[] doubleArray20 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable21 = null;
        double[] doubleArray22 = new double[] {};
        double[][] doubleArray23 = new double[][] { doubleArray22 };
        double[][] doubleArray24 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray23);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException(doubleArray20, localizable21, (java.lang.Object[]) doubleArray23);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException26 = new org.apache.commons.math.FunctionEvaluationException(doubleArray15, localizable17, (java.lang.Object[]) doubleArray23);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair28 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray6, doubleArray15, true);
        org.apache.commons.math.linear.RealVector realVector29 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray6);
        java.io.ObjectOutputStream objectOutputStream30 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.serializeRealVector(realVector29, objectOutputStream30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realVector29);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        double[] doubleArray4 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[][] doubleArray7 = new double[][] { doubleArray6 };
        double[][] doubleArray8 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray7);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException(doubleArray4, localizable5, (java.lang.Object[]) doubleArray7);
        double[][] doubleArray10 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray7);
        java.lang.NullPointerException nullPointerException11 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray10);
        java.lang.IllegalStateException illegalStateException12 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(nullPointerException11);
        org.junit.Assert.assertNotNull(illegalStateException12);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        double[] doubleArray1 = new double[] {};
        double[][] doubleArray2 = new double[][] { doubleArray1 };
        double[][] doubleArray3 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray2);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException4 = new org.apache.commons.math.linear.InvalidMatrixException("", (java.lang.Object[]) doubleArray3);
        java.io.ObjectInputStream objectInputStream6 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) doubleArray3, "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", objectInputStream6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        double[] doubleArray6 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException7 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray6);
        double[] doubleArray15 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException(doubleArray15);
        org.apache.commons.math.exception.Localizable localizable17 = null;
        double[] doubleArray20 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable21 = null;
        double[] doubleArray22 = new double[] {};
        double[][] doubleArray23 = new double[][] { doubleArray22 };
        double[][] doubleArray24 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray23);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException(doubleArray20, localizable21, (java.lang.Object[]) doubleArray23);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException26 = new org.apache.commons.math.FunctionEvaluationException(doubleArray15, localizable17, (java.lang.Object[]) doubleArray23);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair28 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray6, doubleArray15, true);
        double[] doubleArray29 = vectorialPointValuePair28.getPoint();
        double[] doubleArray30 = vectorialPointValuePair28.getValueRef();
        org.apache.commons.math.linear.RealMatrix realMatrix31 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(doubleArray30);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix34 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix37 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double38 = blockRealMatrix37.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix39 = blockRealMatrix34.subtract(blockRealMatrix37);
        try {
            org.apache.commons.math.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math.linear.AnyMatrix) realMatrix31, (org.apache.commons.math.linear.AnyMatrix) blockRealMatrix34);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(realMatrix31);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix39);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker2 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker(10.0d, (double) 97);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double5 = blockRealMatrix4.getFrobeniusNorm();
        int int6 = blockRealMatrix4.getColumnDimension();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix7 = array2DRowRealMatrix0.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix4);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        double[] doubleArray3 = new double[] {};
        double[][] doubleArray4 = new double[][] { doubleArray3 };
        double[][] doubleArray5 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray4);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException6 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray5);
        double[] doubleArray10 = new double[] {};
        double[][] doubleArray11 = new double[][] { doubleArray10 };
        double[][] doubleArray12 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray11);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException13 = new org.apache.commons.math.MaxEvaluationsExceededException(10, "", (java.lang.Object[]) doubleArray11);
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) maxEvaluationsExceededException6, "hi!", (java.lang.Object[]) doubleArray11);
        org.apache.commons.math.optimization.OptimizationException optimizationException15 = new org.apache.commons.math.optimization.OptimizationException("org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix2 = array2DRowRealMatrix0.copy();
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int7 = array2DRowRealMatrix6.getColumnDimension();
        double double8 = array2DRowRealMatrix6.getDeterminant();
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix6);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        try {
            org.apache.commons.math.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix5, (int) (short) -1, (int) (short) 0, (int) ' ', 97);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index -1 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        int int4 = blockRealMatrix2.getColumnDimension();
        org.apache.commons.math.linear.RealVector realVector6 = blockRealMatrix2.getColumnVector(0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double10 = blockRealMatrix9.getFrobeniusNorm();
        int int11 = blockRealMatrix9.getColumnDimension();
        org.apache.commons.math.linear.RealVector realVector13 = blockRealMatrix9.getColumnVector(0);
        try {
            org.apache.commons.math.linear.RealVector realVector14 = blockRealMatrix2.operate(realVector13);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
        org.junit.Assert.assertNotNull(realVector13);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        double[] doubleArray3 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable4 = null;
        double[] doubleArray5 = new double[] {};
        double[][] doubleArray6 = new double[][] { doubleArray5 };
        double[][] doubleArray7 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException8 = new org.apache.commons.math.FunctionEvaluationException(doubleArray3, localizable4, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException9 = new org.apache.commons.math.linear.MatrixIndexException("org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) doubleArray6);
        java.lang.Object[] objArray10 = matrixIndexException9.getArguments();
        double[] doubleArray18 = new double[] {};
        double[][] doubleArray19 = new double[][] { doubleArray18 };
        double[][] doubleArray20 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray19);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException21 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray20);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException22 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray20);
        double[] doubleArray30 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException31 = new org.apache.commons.math.FunctionEvaluationException(doubleArray30);
        org.apache.commons.math.exception.Localizable localizable32 = null;
        double[] doubleArray35 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable36 = null;
        double[] doubleArray37 = new double[] {};
        double[][] doubleArray38 = new double[][] { doubleArray37 };
        double[][] doubleArray39 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray38);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException(doubleArray35, localizable36, (java.lang.Object[]) doubleArray38);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException41 = new org.apache.commons.math.FunctionEvaluationException(doubleArray30, localizable32, (java.lang.Object[]) doubleArray38);
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray38);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException22, "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) doubleArray38);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException44 = new org.apache.commons.math.MaxIterationsExceededException(1, "hi!", (java.lang.Object[]) doubleArray38);
        java.lang.NullPointerException nullPointerException45 = org.apache.commons.math.MathRuntimeException.createNullPointerException("{0}", (java.lang.Object[]) doubleArray38);
        matrixIndexException9.addSuppressed((java.lang.Throwable) nullPointerException45);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(nullPointerException45);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        boolean boolean2 = array2DRowRealMatrix0.isSingular();
        org.apache.commons.math.linear.RealMatrix realMatrix5 = array2DRowRealMatrix0.createMatrix((int) '#', 1);
        try {
            org.apache.commons.math.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix0, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 35 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realMatrix5);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        boolean boolean6 = blockRealMatrix2.isSquare();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double14 = blockRealMatrix13.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix10.subtract(blockRealMatrix13);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = blockRealMatrix15.copy();
        try {
            blockRealMatrix2.setColumnMatrix(100, (org.apache.commons.math.linear.RealMatrix) blockRealMatrix16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 100 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertNotNull(blockRealMatrix16);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        double[] doubleArray5 = blockRealMatrix2.getRow(10);
        double[][] doubleArray6 = blockRealMatrix2.getData();
        double[] doubleArray13 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException14 = new org.apache.commons.math.FunctionEvaluationException(doubleArray13);
        org.apache.commons.math.linear.RealMatrix realMatrix15 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray13);
        double[] doubleArray22 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException23 = new org.apache.commons.math.FunctionEvaluationException(doubleArray22);
        org.apache.commons.math.exception.Localizable localizable24 = null;
        double[] doubleArray27 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable28 = null;
        double[] doubleArray29 = new double[] {};
        double[][] doubleArray30 = new double[][] { doubleArray29 };
        double[][] doubleArray31 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray30);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException32 = new org.apache.commons.math.FunctionEvaluationException(doubleArray27, localizable28, (java.lang.Object[]) doubleArray30);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException33 = new org.apache.commons.math.FunctionEvaluationException(doubleArray22, localizable24, (java.lang.Object[]) doubleArray30);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair35 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray13, doubleArray22, true);
        org.apache.commons.math.linear.RealVector realVector36 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray13);
        try {
            org.apache.commons.math.linear.RealVector realVector37 = blockRealMatrix2.preMultiply(realVector36);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realVector36);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException1 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 0);
        org.apache.commons.math.exception.Localizable localizable2 = null;
        double[][] doubleArray6 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException7 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray6);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException8 = new org.apache.commons.math.linear.MatrixIndexException(localizable2, (java.lang.Object[]) doubleArray6);
        double[] doubleArray15 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException(doubleArray15);
        org.apache.commons.math.linear.RealMatrix realMatrix17 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray15);
        double[] doubleArray24 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException(doubleArray24);
        org.apache.commons.math.exception.Localizable localizable26 = null;
        double[] doubleArray29 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable30 = null;
        double[] doubleArray31 = new double[] {};
        double[][] doubleArray32 = new double[][] { doubleArray31 };
        double[][] doubleArray33 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray32);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException34 = new org.apache.commons.math.FunctionEvaluationException(doubleArray29, localizable30, (java.lang.Object[]) doubleArray32);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException35 = new org.apache.commons.math.FunctionEvaluationException(doubleArray24, localizable26, (java.lang.Object[]) doubleArray32);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair37 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray15, doubleArray24, true);
        org.apache.commons.math.exception.Localizable localizable39 = null;
        double[][] doubleArray43 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException44 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray43);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException45 = new org.apache.commons.math.linear.MatrixIndexException(localizable39, (java.lang.Object[]) doubleArray43);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException46 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) matrixIndexException8, doubleArray15, "{0}", (java.lang.Object[]) doubleArray43);
        org.apache.commons.math.exception.Localizable localizable47 = null;
        double[] doubleArray54 = new double[] {};
        double[][] doubleArray55 = new double[][] { doubleArray54 };
        double[][] doubleArray56 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray55);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException57 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray56);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException58 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray56);
        double[] doubleArray66 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException67 = new org.apache.commons.math.FunctionEvaluationException(doubleArray66);
        org.apache.commons.math.exception.Localizable localizable68 = null;
        double[] doubleArray71 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable72 = null;
        double[] doubleArray73 = new double[] {};
        double[][] doubleArray74 = new double[][] { doubleArray73 };
        double[][] doubleArray75 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray74);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException76 = new org.apache.commons.math.FunctionEvaluationException(doubleArray71, localizable72, (java.lang.Object[]) doubleArray74);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException77 = new org.apache.commons.math.FunctionEvaluationException(doubleArray66, localizable68, (java.lang.Object[]) doubleArray74);
        double[][] doubleArray78 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray74);
        org.apache.commons.math.MathException mathException79 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException58, "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) doubleArray74);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException80 = new org.apache.commons.math.MaxIterationsExceededException(1, "hi!", (java.lang.Object[]) doubleArray74);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException81 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxEvaluationsExceededException1, doubleArray15, localizable47, (java.lang.Object[]) doubleArray74);
        int int82 = maxEvaluationsExceededException1.getMaxEvaluations();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(nullPointerException7);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(nullPointerException44);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        try {
            org.apache.commons.math.linear.RealVector realVector3 = array2DRowRealMatrix0.getRowVector((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        java.lang.String[] strArray5 = new java.lang.String[] { "hi!", "", "{0}", "", "hi!" };
        java.lang.String[] strArray11 = new java.lang.String[] { "hi!", "", "{0}", "", "hi!" };
        java.lang.String[][] strArray12 = new java.lang.String[][] { strArray5, strArray11 };
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix13 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(strArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray12);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        boolean boolean2 = array2DRowRealMatrix0.isSingular();
        org.apache.commons.math.linear.RealMatrix realMatrix5 = array2DRowRealMatrix0.createMatrix((int) '#', 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix11 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double12 = blockRealMatrix11.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = blockRealMatrix8.subtract(blockRealMatrix11);
        try {
            org.apache.commons.math.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math.linear.AnyMatrix) blockRealMatrix8);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix13);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        double[] doubleArray5 = blockRealMatrix2.getRow(10);
        double[][] doubleArray6 = blockRealMatrix2.getData();
        try {
            org.apache.commons.math.linear.RealVector realVector8 = blockRealMatrix2.getColumnVector((-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index -1 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        double[] doubleArray9 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException(doubleArray9);
        org.apache.commons.math.linear.RealMatrix realMatrix11 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray9);
        double[] doubleArray18 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException19 = new org.apache.commons.math.FunctionEvaluationException(doubleArray18);
        org.apache.commons.math.exception.Localizable localizable20 = null;
        double[] doubleArray23 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable24 = null;
        double[] doubleArray25 = new double[] {};
        double[][] doubleArray26 = new double[][] { doubleArray25 };
        double[][] doubleArray27 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray26);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException28 = new org.apache.commons.math.FunctionEvaluationException(doubleArray23, localizable24, (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException(doubleArray18, localizable20, (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair31 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray9, doubleArray18, true);
        org.apache.commons.math.linear.RealVector realVector32 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray9);
        try {
            org.apache.commons.math.linear.RealVector realVector33 = array2DRowRealMatrix0.preMultiply(realVector32);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realVector32);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        int int4 = blockRealMatrix2.getColumnDimension();
        try {
            blockRealMatrix2.setEntry((int) 'a', (int) (short) -1, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (97, -1) in a 35x10 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        double[][] doubleArray0 = null;
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getDeterminant();
        java.lang.String str3 = array2DRowRealMatrix0.toString();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double8 = blockRealMatrix7.getFrobeniusNorm();
        int int9 = blockRealMatrix7.getColumnDimension();
        org.apache.commons.math.linear.RealVector realVector11 = blockRealMatrix7.getColumnVector(0);
        try {
            array2DRowRealMatrix0.setColumnVector((int) (byte) 0, realVector11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 0 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Array2DRowRealMatrix{}" + "'", str3.equals("Array2DRowRealMatrix{}"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertNotNull(realVector11);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix7.copy();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor9 = null;
        try {
            double double14 = blockRealMatrix8.walkInOptimizedOrder(realMatrixChangingVisitor9, 0, (-1), (int) (byte) -1, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index -1 out of allowed range [0, 34]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        double[] doubleArray3 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable4 = null;
        double[] doubleArray5 = new double[] {};
        double[][] doubleArray6 = new double[][] { doubleArray5 };
        double[][] doubleArray7 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException8 = new org.apache.commons.math.FunctionEvaluationException(doubleArray3, localizable4, (java.lang.Object[]) doubleArray6);
        double[][] doubleArray9 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        java.lang.NullPointerException nullPointerException10 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray9);
        java.lang.RuntimeException runtimeException11 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) nullPointerException10);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(nullPointerException10);
        org.junit.Assert.assertNotNull(runtimeException11);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        double[] doubleArray6 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException7 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6);
        org.apache.commons.math.exception.Localizable localizable8 = null;
        double[] doubleArray11 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable12 = null;
        double[] doubleArray13 = new double[] {};
        double[][] doubleArray14 = new double[][] { doubleArray13 };
        double[][] doubleArray15 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray14);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException(doubleArray11, localizable12, (java.lang.Object[]) doubleArray14);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6, localizable8, (java.lang.Object[]) doubleArray14);
        double[][] doubleArray18 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray14);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray14);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0);
        java.lang.String str2 = maxIterationsExceededException1.getPattern();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "maximal number of iterations ({0}) exceeded" + "'", str2.equals("maximal number of iterations ({0}) exceeded"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        java.lang.String[] strArray3 = new java.lang.String[] { "{0}", "maximal number of iterations ({0}) exceeded", "" };
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix4 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(strArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        boolean boolean6 = blockRealMatrix2.isSquare();
        int[] intArray11 = new int[] { (byte) -1, (byte) 10, '4', 36 };
        int[] intArray13 = new int[] { 97 };
        double[] doubleArray19 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable20 = null;
        double[] doubleArray21 = new double[] {};
        double[][] doubleArray22 = new double[][] { doubleArray21 };
        double[][] doubleArray23 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray22);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException24 = new org.apache.commons.math.FunctionEvaluationException(doubleArray19, localizable20, (java.lang.Object[]) doubleArray22);
        double[][] doubleArray25 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray22);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray22);
        int int27 = maxIterationsExceededException26.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable28 = maxIterationsExceededException26.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable29 = null;
        double[][] doubleArray33 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException34 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray33);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException35 = new org.apache.commons.math.linear.MatrixIndexException(localizable29, (java.lang.Object[]) doubleArray33);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', localizable28, (java.lang.Object[]) doubleArray33);
        try {
            blockRealMatrix2.copySubMatrix(intArray11, intArray13, doubleArray33);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index -1 out of allowed range [0, 34]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 52 + "'", int27 == 52);
        org.junit.Assert.assertNotNull(localizable28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(nullPointerException34);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor8 = null;
        try {
            double double9 = blockRealMatrix2.walkInOptimizedOrder(realMatrixChangingVisitor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getDeterminant();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor3 = null;
        try {
            double double8 = array2DRowRealMatrix0.walkInRowOrder(realMatrixPreservingVisitor3, (int) '4', 36, 1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 52 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.apache.commons.math.linear.RealMatrix realMatrix2 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix((int) (byte) 1, 100);
        try {
            org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl3 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 1x100 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix2);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        double[] doubleArray2 = new double[] {};
        double[][] doubleArray3 = new double[][] { doubleArray2 };
        double[][] doubleArray4 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray3);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException5 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray4);
        java.lang.String str6 = maxEvaluationsExceededException5.getPattern();
        int int7 = maxEvaluationsExceededException5.getMaxEvaluations();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException1 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        double[] doubleArray2 = functionEvaluationException1.getArgument();
        double[] doubleArray8 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable9 = null;
        double[] doubleArray10 = new double[] {};
        double[][] doubleArray11 = new double[][] { doubleArray10 };
        double[][] doubleArray12 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray11);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException13 = new org.apache.commons.math.FunctionEvaluationException(doubleArray8, localizable9, (java.lang.Object[]) doubleArray11);
        double[][] doubleArray14 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray11);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray11);
        int int16 = maxIterationsExceededException15.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable17 = maxIterationsExceededException15.getLocalizablePattern();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException19 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray20 = functionEvaluationException19.getSuppressed();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException21 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a', localizable17, (java.lang.Object[]) throwableArray20);
        double[] doubleArray28 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable29 = null;
        double[] doubleArray30 = new double[] {};
        double[][] doubleArray31 = new double[][] { doubleArray30 };
        double[][] doubleArray32 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray31);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException33 = new org.apache.commons.math.FunctionEvaluationException(doubleArray28, localizable29, (java.lang.Object[]) doubleArray31);
        double[][] doubleArray34 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray31);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray31);
        int int36 = maxIterationsExceededException35.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable37 = maxIterationsExceededException35.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable38 = null;
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException43 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray42);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException44 = new org.apache.commons.math.linear.MatrixIndexException(localizable38, (java.lang.Object[]) doubleArray42);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException45 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', localizable37, (java.lang.Object[]) doubleArray42);
        double[] doubleArray49 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable50 = null;
        double[] doubleArray51 = new double[] {};
        double[][] doubleArray52 = new double[][] { doubleArray51 };
        double[][] doubleArray53 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray52);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException54 = new org.apache.commons.math.FunctionEvaluationException(doubleArray49, localizable50, (java.lang.Object[]) doubleArray52);
        double[][] doubleArray55 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray52);
        java.lang.NullPointerException nullPointerException56 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray55);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException57 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 10, localizable37, (java.lang.Object[]) doubleArray55);
        java.lang.Throwable[] throwableArray58 = maxEvaluationsExceededException57.getSuppressed();
        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException(localizable17, (java.lang.Object[]) throwableArray58);
        double[][] doubleArray62 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 100, (int) (short) 100);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException63 = new org.apache.commons.math.FunctionEvaluationException(doubleArray2, localizable17, (java.lang.Object[]) doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 52 + "'", int16 == 52);
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 52 + "'", int36 == 52);
        org.junit.Assert.assertNotNull(localizable37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(nullPointerException43);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(nullPointerException56);
        org.junit.Assert.assertNotNull(throwableArray58);
        org.junit.Assert.assertNotNull(doubleArray62);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        double[] doubleArray6 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable7 = null;
        double[] doubleArray8 = new double[] {};
        double[][] doubleArray9 = new double[][] { doubleArray8 };
        double[][] doubleArray10 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray9);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException11 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6, localizable7, (java.lang.Object[]) doubleArray9);
        double[][] doubleArray12 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray9);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray9);
        int int14 = maxIterationsExceededException13.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable15 = maxIterationsExceededException13.getLocalizablePattern();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray18 = functionEvaluationException17.getSuppressed();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException19 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a', localizable15, (java.lang.Object[]) throwableArray18);
        org.apache.commons.math.exception.Localizable localizable20 = null;
        double[][] doubleArray24 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException25 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray24);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException26 = new org.apache.commons.math.linear.MatrixIndexException(localizable20, (java.lang.Object[]) doubleArray24);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException27 = new org.apache.commons.math.linear.InvalidMatrixException(localizable15, (java.lang.Object[]) doubleArray24);
        java.lang.Throwable throwable30 = null;
        org.apache.commons.math.exception.Localizable localizable31 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException33 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray34 = functionEvaluationException33.getSuppressed();
        org.apache.commons.math.MathRuntimeException mathRuntimeException35 = new org.apache.commons.math.MathRuntimeException(throwable30, localizable31, (java.lang.Object[]) throwableArray34);
        java.text.ParseException parseException36 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) throwableArray34);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException37 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable15, (java.lang.Object[]) throwableArray34);
        double[] doubleArray41 = new double[] {};
        double[][] doubleArray42 = new double[][] { doubleArray41 };
        double[][] doubleArray43 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray42);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException44 = new org.apache.commons.math.MaxEvaluationsExceededException(10, "", (java.lang.Object[]) doubleArray42);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException45 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", (java.lang.Object[]) doubleArray42);
        java.text.ParseException parseException46 = org.apache.commons.math.MathRuntimeException.createParseException(0, localizable15, (java.lang.Object[]) doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertNotNull(localizable15);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(nullPointerException25);
        org.junit.Assert.assertNotNull(throwableArray34);
        org.junit.Assert.assertNotNull(parseException36);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException37);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException45);
        org.junit.Assert.assertNotNull(parseException46);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        boolean boolean6 = blockRealMatrix2.isSquare();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int8 = array2DRowRealMatrix7.getColumnDimension();
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix2.multiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix7);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray4 };
        double[][] doubleArray6 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray5);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException7 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray6);
        org.apache.commons.math.exception.Localizable localizable8 = null;
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxEvaluationsExceededException7, localizable8, (java.lang.Object[]) doubleArray11);
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException("", (java.lang.Object[]) doubleArray11);
        java.util.NoSuchElementException noSuchElementException14 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(noSuchElementException14);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        double[] doubleArray4 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[][] doubleArray7 = new double[][] { doubleArray6 };
        double[][] doubleArray8 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray7);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException(doubleArray4, localizable5, (java.lang.Object[]) doubleArray7);
        double[] doubleArray15 = new double[] { 10L, '#', 0, 1.0d, '#' };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair17 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray4, doubleArray15, true);
        org.apache.commons.math.linear.RealMatrix realMatrix18 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray4);
        try {
            double[] doubleArray19 = array2DRowRealMatrix0.operate(doubleArray4);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix18);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        double[] doubleArray5 = blockRealMatrix2.getRow(10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int7 = array2DRowRealMatrix6.getColumnDimension();
        double double8 = array2DRowRealMatrix6.getFrobeniusNorm();
        try {
            org.apache.commons.math.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix2, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix6);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        int int4 = blockRealMatrix2.getColumnDimension();
        org.apache.commons.math.linear.RealVector realVector6 = blockRealMatrix2.getColumnVector(0);
        double[] doubleArray11 = new double[] {};
        double[][] doubleArray12 = new double[][] { doubleArray11 };
        double[][] doubleArray13 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray12);
        try {
            blockRealMatrix2.copySubMatrix(36, 36, (int) (short) 10, (int) ' ', doubleArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 36 out of allowed range [0, 34]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix0, 52, (int) (short) 10, 36, 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 52 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        double[] doubleArray5 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable6 = null;
        double[] doubleArray7 = new double[] {};
        double[][] doubleArray8 = new double[][] { doubleArray7 };
        double[][] doubleArray9 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray8);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException(doubleArray5, localizable6, (java.lang.Object[]) doubleArray8);
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray8);
        int int13 = maxIterationsExceededException12.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable14 = maxIterationsExceededException12.getLocalizablePattern();
        double[] doubleArray20 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable21 = null;
        double[] doubleArray22 = new double[] {};
        double[][] doubleArray23 = new double[][] { doubleArray22 };
        double[][] doubleArray24 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray23);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException(doubleArray20, localizable21, (java.lang.Object[]) doubleArray23);
        double[][] doubleArray26 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray23);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray23);
        int int28 = maxIterationsExceededException27.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable29 = maxIterationsExceededException27.getLocalizablePattern();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException31 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray32 = functionEvaluationException31.getSuppressed();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException33 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a', localizable29, (java.lang.Object[]) throwableArray32);
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException0, localizable14, (java.lang.Object[]) throwableArray32);
        java.lang.Throwable throwable35 = null;
        org.apache.commons.math.MathRuntimeException mathRuntimeException36 = new org.apache.commons.math.MathRuntimeException(throwable35);
        double[] doubleArray42 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable43 = null;
        double[] doubleArray44 = new double[] {};
        double[][] doubleArray45 = new double[][] { doubleArray44 };
        double[][] doubleArray46 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray45);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException47 = new org.apache.commons.math.FunctionEvaluationException(doubleArray42, localizable43, (java.lang.Object[]) doubleArray45);
        double[][] doubleArray48 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray45);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException49 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray45);
        int int50 = maxIterationsExceededException49.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable51 = maxIterationsExceededException49.getLocalizablePattern();
        double[] doubleArray54 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable55 = null;
        double[] doubleArray56 = new double[] {};
        double[][] doubleArray57 = new double[][] { doubleArray56 };
        double[][] doubleArray58 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray57);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException59 = new org.apache.commons.math.FunctionEvaluationException(doubleArray54, localizable55, (java.lang.Object[]) doubleArray57);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException60 = new org.apache.commons.math.FunctionEvaluationException(throwable35, (double) (short) 100, localizable51, (java.lang.Object[]) doubleArray57);
        org.apache.commons.math.optimization.OptimizationException optimizationException61 = new org.apache.commons.math.optimization.OptimizationException(localizable14, (java.lang.Object[]) doubleArray57);
        double[] doubleArray68 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException69 = new org.apache.commons.math.FunctionEvaluationException(doubleArray68);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException70 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) optimizationException61, doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 52 + "'", int13 == 52);
        org.junit.Assert.assertNotNull(localizable14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 52 + "'", int28 == 52);
        org.junit.Assert.assertNotNull(localizable29);
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 52 + "'", int50 == 52);
        org.junit.Assert.assertNotNull(localizable51);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray68);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        boolean boolean4 = array2DRowRealMatrix0.equals((java.lang.Object) 36);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor5 = null;
        try {
            double double10 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixPreservingVisitor5, (int) (short) -1, (-1), (int) (short) -1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index -1 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        boolean boolean2 = array2DRowRealMatrix0.isSingular();
        org.apache.commons.math.linear.RealMatrix realMatrix5 = array2DRowRealMatrix0.createMatrix((int) '#', 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double9 = blockRealMatrix8.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix8.getRowMatrix(0);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix12 = array2DRowRealMatrix0.preMultiply((org.apache.commons.math.linear.RealMatrix) blockRealMatrix11);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getDeterminant();
        double[] doubleArray5 = new double[] {};
        double[][] doubleArray6 = new double[][] { doubleArray5 };
        double[][] doubleArray7 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException8 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray7);
        try {
            array2DRowRealMatrix0.setSubMatrix(doubleArray7, (int) (short) 100, (int) (byte) 10);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalStateException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double[][] doubleArray2 = array2DRowRealMatrix0.getData();
        boolean boolean3 = array2DRowRealMatrix0.isSquare();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix4 = array2DRowRealMatrix0.copy();
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        blockRealMatrix2.addToEntry(0, 1, (double) 1L);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix11 = blockRealMatrix2.getSubMatrix((int) 'a', (-1), 97, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 97 out of allowed range [0, 34]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        int[] intArray10 = new int[] { '4', (short) 0, 36, (byte) 10 };
        int[] intArray15 = new int[] { '#', 52, (byte) 10, 0 };
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix16 = blockRealMatrix5.getSubMatrix(intArray10, intArray15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 52 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray15);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix5.getSubMatrix(10, (int) '#', 0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 10 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        double[] doubleArray5 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable6 = null;
        double[] doubleArray7 = new double[] {};
        double[][] doubleArray8 = new double[][] { doubleArray7 };
        double[][] doubleArray9 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray8);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException(doubleArray5, localizable6, (java.lang.Object[]) doubleArray8);
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray8);
        int int13 = maxIterationsExceededException12.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable14 = maxIterationsExceededException12.getLocalizablePattern();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray17 = functionEvaluationException16.getSuppressed();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException18 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a', localizable14, (java.lang.Object[]) throwableArray17);
        org.apache.commons.math.exception.Localizable localizable19 = null;
        double[][] doubleArray23 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException24 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray23);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException25 = new org.apache.commons.math.linear.MatrixIndexException(localizable19, (java.lang.Object[]) doubleArray23);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException26 = new org.apache.commons.math.linear.InvalidMatrixException(localizable14, (java.lang.Object[]) doubleArray23);
        java.lang.Object[] objArray27 = null;
        java.lang.IllegalArgumentException illegalArgumentException28 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException(localizable14, objArray27);
        org.apache.commons.math.MathRuntimeException mathRuntimeException29 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) illegalArgumentException28);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 52 + "'", int13 == 52);
        org.junit.Assert.assertNotNull(localizable14);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(nullPointerException24);
        org.junit.Assert.assertNotNull(illegalArgumentException28);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        double[] doubleArray2 = new double[] {};
        double[][] doubleArray3 = new double[][] { doubleArray2 };
        double[][] doubleArray4 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray3);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException5 = new org.apache.commons.math.MaxEvaluationsExceededException(10, "", (java.lang.Object[]) doubleArray3);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException7 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxEvaluationsExceededException5, (double) 1);
        java.io.ObjectInputStream objectInputStream9 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.deserializeRealVector((java.lang.Object) functionEvaluationException7, "hi!", objectInputStream9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException1 = new org.apache.commons.math.linear.InvalidMatrixException(throwable0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix7.copy();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor9 = null;
        try {
            double double14 = blockRealMatrix7.walkInOptimizedOrder(realMatrixPreservingVisitor9, (int) (byte) 100, (int) (short) -1, (int) (byte) 10, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, 34]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        double[] doubleArray5 = blockRealMatrix2.getRow(10);
        double[][] doubleArray6 = blockRealMatrix2.getData();
        org.apache.commons.math.linear.RealVector realVector8 = blockRealMatrix2.getRowVector((int) (short) 0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double13 = blockRealMatrix12.getFrobeniusNorm();
        int int14 = blockRealMatrix12.getColumnDimension();
        org.apache.commons.math.linear.RealVector realVector16 = blockRealMatrix12.getColumnVector(0);
        try {
            blockRealMatrix2.setRowMatrix((int) 'a', blockRealMatrix12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 97 out of allowed range [0, 34]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertNotNull(realVector16);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        double[] doubleArray6 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable7 = null;
        double[] doubleArray8 = new double[] {};
        double[][] doubleArray9 = new double[][] { doubleArray8 };
        double[][] doubleArray10 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray9);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException11 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6, localizable7, (java.lang.Object[]) doubleArray9);
        double[][] doubleArray12 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray9);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray9);
        int int14 = maxIterationsExceededException13.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable15 = maxIterationsExceededException13.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable16 = null;
        double[][] doubleArray20 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException21 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray20);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException22 = new org.apache.commons.math.linear.MatrixIndexException(localizable16, (java.lang.Object[]) doubleArray20);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', localizable15, (java.lang.Object[]) doubleArray20);
        double[] doubleArray27 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable28 = null;
        double[] doubleArray29 = new double[] {};
        double[][] doubleArray30 = new double[][] { doubleArray29 };
        double[][] doubleArray31 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray30);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException32 = new org.apache.commons.math.FunctionEvaluationException(doubleArray27, localizable28, (java.lang.Object[]) doubleArray30);
        double[][] doubleArray33 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray30);
        java.lang.NullPointerException nullPointerException34 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray33);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException35 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 10, localizable15, (java.lang.Object[]) doubleArray33);
        double[] doubleArray42 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException43 = new org.apache.commons.math.FunctionEvaluationException(doubleArray42);
        org.apache.commons.math.exception.Localizable localizable44 = null;
        double[] doubleArray47 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable48 = null;
        double[] doubleArray49 = new double[] {};
        double[][] doubleArray50 = new double[][] { doubleArray49 };
        double[][] doubleArray51 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray50);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException52 = new org.apache.commons.math.FunctionEvaluationException(doubleArray47, localizable48, (java.lang.Object[]) doubleArray50);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException53 = new org.apache.commons.math.FunctionEvaluationException(doubleArray42, localizable44, (java.lang.Object[]) doubleArray50);
        double[][] doubleArray54 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray50);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException55 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable15, (java.lang.Object[]) doubleArray54);
        org.apache.commons.math.exception.Localizable localizable57 = null;
        double[] doubleArray62 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable63 = null;
        double[] doubleArray64 = new double[] {};
        double[][] doubleArray65 = new double[][] { doubleArray64 };
        double[][] doubleArray66 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray65);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException67 = new org.apache.commons.math.FunctionEvaluationException(doubleArray62, localizable63, (java.lang.Object[]) doubleArray65);
        double[][] doubleArray68 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray65);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException69 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray65);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException70 = new org.apache.commons.math.FunctionEvaluationException((double) 0.0f, localizable57, (java.lang.Object[]) doubleArray65);
        arrayIndexOutOfBoundsException55.addSuppressed((java.lang.Throwable) functionEvaluationException70);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertNotNull(localizable15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(nullPointerException21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(nullPointerException34);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException55);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray68);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        double[] doubleArray6 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable7 = null;
        double[] doubleArray8 = new double[] {};
        double[][] doubleArray9 = new double[][] { doubleArray8 };
        double[][] doubleArray10 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray9);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException11 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6, localizable7, (java.lang.Object[]) doubleArray9);
        double[][] doubleArray12 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray9);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray9);
        int int14 = maxIterationsExceededException13.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable15 = maxIterationsExceededException13.getLocalizablePattern();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray18 = functionEvaluationException17.getSuppressed();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException19 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a', localizable15, (java.lang.Object[]) throwableArray18);
        double[] doubleArray26 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable27 = null;
        double[] doubleArray28 = new double[] {};
        double[][] doubleArray29 = new double[][] { doubleArray28 };
        double[][] doubleArray30 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray29);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException31 = new org.apache.commons.math.FunctionEvaluationException(doubleArray26, localizable27, (java.lang.Object[]) doubleArray29);
        double[][] doubleArray32 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray29);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray29);
        int int34 = maxIterationsExceededException33.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable35 = maxIterationsExceededException33.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable36 = null;
        double[][] doubleArray40 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException41 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray40);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException42 = new org.apache.commons.math.linear.MatrixIndexException(localizable36, (java.lang.Object[]) doubleArray40);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException43 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', localizable35, (java.lang.Object[]) doubleArray40);
        double[] doubleArray47 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable48 = null;
        double[] doubleArray49 = new double[] {};
        double[][] doubleArray50 = new double[][] { doubleArray49 };
        double[][] doubleArray51 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray50);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException52 = new org.apache.commons.math.FunctionEvaluationException(doubleArray47, localizable48, (java.lang.Object[]) doubleArray50);
        double[][] doubleArray53 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray50);
        java.lang.NullPointerException nullPointerException54 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray53);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException55 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 10, localizable35, (java.lang.Object[]) doubleArray53);
        java.lang.Throwable[] throwableArray56 = maxEvaluationsExceededException55.getSuppressed();
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException(localizable15, (java.lang.Object[]) throwableArray56);
        double[] doubleArray60 = new double[] {};
        double[][] doubleArray61 = new double[][] { doubleArray60 };
        double[][] doubleArray62 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray61);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException63 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray62);
        double[] doubleArray67 = new double[] {};
        double[][] doubleArray68 = new double[][] { doubleArray67 };
        double[][] doubleArray69 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray68);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException70 = new org.apache.commons.math.MaxEvaluationsExceededException(10, "", (java.lang.Object[]) doubleArray68);
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException((java.lang.Throwable) maxEvaluationsExceededException63, "hi!", (java.lang.Object[]) doubleArray68);
        org.apache.commons.math.optimization.OptimizationException optimizationException72 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) mathException71);
        org.apache.commons.math.exception.Localizable localizable73 = null;
        java.lang.Object[] objArray75 = new java.lang.Object[] { 1L };
        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException71, localizable73, objArray75);
        java.util.ConcurrentModificationException concurrentModificationException77 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException(localizable15, objArray75);
        java.lang.Object[] objArray78 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException79 = new org.apache.commons.math.FunctionEvaluationException((double) 10.0f, localizable15, objArray78);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertNotNull(localizable15);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 52 + "'", int34 == 52);
        org.junit.Assert.assertNotNull(localizable35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(nullPointerException41);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(nullPointerException54);
        org.junit.Assert.assertNotNull(throwableArray56);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(objArray75);
        org.junit.Assert.assertNotNull(concurrentModificationException77);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double[][] doubleArray2 = array2DRowRealMatrix0.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean4 = array2DRowRealMatrix3.isSquare();
        boolean boolean5 = array2DRowRealMatrix3.isSquare();
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = array2DRowRealMatrix0.add(array2DRowRealMatrix3);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        java.lang.String[] strArray5 = new java.lang.String[] { "{0}", "hi!", "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", "{0}", "hi!" };
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix6 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(strArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double5 = blockRealMatrix4.getFrobeniusNorm();
        double[] doubleArray7 = blockRealMatrix4.getRow(10);
        double[][] doubleArray8 = blockRealMatrix4.getData();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException9 = new org.apache.commons.math.MaxEvaluationsExceededException(0, "{0}", (java.lang.Object[]) doubleArray8);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.apache.commons.math.linear.RealMatrix realMatrix1 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix(97);
        org.junit.Assert.assertNotNull(realMatrix1);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix11 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double12 = blockRealMatrix11.getFrobeniusNorm();
        try {
            blockRealMatrix2.setColumnMatrix((int) '#', (org.apache.commons.math.linear.RealMatrix) blockRealMatrix11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 35 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor3 = null;
        try {
            double double8 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixPreservingVisitor3, (int) (short) 0, (int) (short) -1, 97, 52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 0 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        boolean boolean2 = array2DRowRealMatrix0.isSingular();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix5 = array2DRowRealMatrix0.createMatrix((int) '#', 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.apache.commons.math.exception.Localizable localizable0 = null;
        double[][] doubleArray4 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException5 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray4);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException6 = new org.apache.commons.math.linear.MatrixIndexException(localizable0, (java.lang.Object[]) doubleArray4);
        double[] doubleArray13 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException14 = new org.apache.commons.math.FunctionEvaluationException(doubleArray13);
        org.apache.commons.math.linear.RealMatrix realMatrix15 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray13);
        double[] doubleArray22 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException23 = new org.apache.commons.math.FunctionEvaluationException(doubleArray22);
        org.apache.commons.math.exception.Localizable localizable24 = null;
        double[] doubleArray27 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable28 = null;
        double[] doubleArray29 = new double[] {};
        double[][] doubleArray30 = new double[][] { doubleArray29 };
        double[][] doubleArray31 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray30);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException32 = new org.apache.commons.math.FunctionEvaluationException(doubleArray27, localizable28, (java.lang.Object[]) doubleArray30);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException33 = new org.apache.commons.math.FunctionEvaluationException(doubleArray22, localizable24, (java.lang.Object[]) doubleArray30);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair35 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray13, doubleArray22, true);
        org.apache.commons.math.exception.Localizable localizable37 = null;
        double[][] doubleArray41 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException42 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException43 = new org.apache.commons.math.linear.MatrixIndexException(localizable37, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) matrixIndexException6, doubleArray13, "{0}", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) functionEvaluationException44);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(nullPointerException5);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(nullPointerException42);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        try {
            boolean boolean5 = blockRealMatrix4.isSingular();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 10x35 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        double[] doubleArray5 = blockRealMatrix2.getRow(10);
        double[][] doubleArray6 = blockRealMatrix2.getData();
        try {
            org.apache.commons.math.linear.RealVector realVector8 = blockRealMatrix2.getColumnVector((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 100 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        java.lang.Object[] objArray2 = null;
        java.text.ParseException parseException3 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) 1, "hi!", objArray2);
        org.junit.Assert.assertNotNull(parseException3);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        boolean boolean6 = blockRealMatrix2.isSquare();
        double[] doubleArray8 = null;
        try {
            blockRealMatrix2.setColumn((int) (byte) 100, doubleArray8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 100 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.MathRuntimeException mathRuntimeException1 = new org.apache.commons.math.MathRuntimeException(throwable0);
        java.lang.String str2 = mathRuntimeException1.getPattern();
        double[] doubleArray10 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable11 = null;
        double[] doubleArray12 = new double[] {};
        double[][] doubleArray13 = new double[][] { doubleArray12 };
        double[][] doubleArray14 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray13);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException(doubleArray10, localizable11, (java.lang.Object[]) doubleArray13);
        double[][] doubleArray16 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray13);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray13);
        int int18 = maxIterationsExceededException17.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable19 = maxIterationsExceededException17.getLocalizablePattern();
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException();
        double[] doubleArray27 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable28 = null;
        double[] doubleArray29 = new double[] {};
        double[][] doubleArray30 = new double[][] { doubleArray29 };
        double[][] doubleArray31 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray30);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException32 = new org.apache.commons.math.FunctionEvaluationException(doubleArray27, localizable28, (java.lang.Object[]) doubleArray30);
        double[][] doubleArray33 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray30);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException34 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray30);
        int int35 = maxIterationsExceededException34.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable36 = maxIterationsExceededException34.getLocalizablePattern();
        double[] doubleArray42 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable43 = null;
        double[] doubleArray44 = new double[] {};
        double[][] doubleArray45 = new double[][] { doubleArray44 };
        double[][] doubleArray46 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray45);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException47 = new org.apache.commons.math.FunctionEvaluationException(doubleArray42, localizable43, (java.lang.Object[]) doubleArray45);
        double[][] doubleArray48 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray45);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException49 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray45);
        int int50 = maxIterationsExceededException49.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable51 = maxIterationsExceededException49.getLocalizablePattern();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException53 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray54 = functionEvaluationException53.getSuppressed();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException55 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a', localizable51, (java.lang.Object[]) throwableArray54);
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException22, localizable36, (java.lang.Object[]) throwableArray54);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException57 = new org.apache.commons.math.MaxEvaluationsExceededException(0, "", (java.lang.Object[]) throwableArray54);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException58 = new org.apache.commons.math.MaxIterationsExceededException((int) '#', localizable19, (java.lang.Object[]) throwableArray54);
        java.lang.Object[] objArray59 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException60 = new org.apache.commons.math.MaxIterationsExceededException(36, localizable19, objArray59);
        org.apache.commons.math.exception.Localizable localizable63 = null;
        double[] doubleArray70 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException71 = new org.apache.commons.math.FunctionEvaluationException(doubleArray70);
        org.apache.commons.math.exception.Localizable localizable72 = null;
        double[] doubleArray75 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable76 = null;
        double[] doubleArray77 = new double[] {};
        double[][] doubleArray78 = new double[][] { doubleArray77 };
        double[][] doubleArray79 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray78);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException80 = new org.apache.commons.math.FunctionEvaluationException(doubleArray75, localizable76, (java.lang.Object[]) doubleArray78);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException81 = new org.apache.commons.math.FunctionEvaluationException(doubleArray70, localizable72, (java.lang.Object[]) doubleArray78);
        org.apache.commons.math.ConvergenceException convergenceException82 = new org.apache.commons.math.ConvergenceException(localizable63, (java.lang.Object[]) doubleArray78);
        java.lang.ArithmeticException arithmeticException83 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", (java.lang.Object[]) doubleArray78);
        org.apache.commons.math.ConvergenceException convergenceException84 = new org.apache.commons.math.ConvergenceException("hi!", (java.lang.Object[]) doubleArray78);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException85 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathRuntimeException1, (double) 52, localizable19, (java.lang.Object[]) doubleArray78);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}" + "'", str2.equals("{0}"));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 52 + "'", int18 == 52);
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 52 + "'", int35 == 52);
        org.junit.Assert.assertNotNull(localizable36);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 52 + "'", int50 == 52);
        org.junit.Assert.assertNotNull(localizable51);
        org.junit.Assert.assertNotNull(throwableArray54);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(arithmeticException83);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.apache.commons.math.linear.BigMatrix bigMatrix1 = org.apache.commons.math.linear.MatrixUtils.createBigIdentityMatrix((int) 'a');
        org.junit.Assert.assertNotNull(bigMatrix1);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        double[] doubleArray6 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable7 = null;
        double[] doubleArray8 = new double[] {};
        double[][] doubleArray9 = new double[][] { doubleArray8 };
        double[][] doubleArray10 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray9);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException11 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6, localizable7, (java.lang.Object[]) doubleArray9);
        double[][] doubleArray12 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray9);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray9);
        int int14 = maxIterationsExceededException13.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable15 = maxIterationsExceededException13.getLocalizablePattern();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray18 = functionEvaluationException17.getSuppressed();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException19 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a', localizable15, (java.lang.Object[]) throwableArray18);
        double[] doubleArray26 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable27 = null;
        double[] doubleArray28 = new double[] {};
        double[][] doubleArray29 = new double[][] { doubleArray28 };
        double[][] doubleArray30 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray29);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException31 = new org.apache.commons.math.FunctionEvaluationException(doubleArray26, localizable27, (java.lang.Object[]) doubleArray29);
        double[][] doubleArray32 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray29);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray29);
        int int34 = maxIterationsExceededException33.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable35 = maxIterationsExceededException33.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable36 = null;
        double[][] doubleArray40 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException41 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray40);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException42 = new org.apache.commons.math.linear.MatrixIndexException(localizable36, (java.lang.Object[]) doubleArray40);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException43 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', localizable35, (java.lang.Object[]) doubleArray40);
        double[] doubleArray47 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable48 = null;
        double[] doubleArray49 = new double[] {};
        double[][] doubleArray50 = new double[][] { doubleArray49 };
        double[][] doubleArray51 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray50);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException52 = new org.apache.commons.math.FunctionEvaluationException(doubleArray47, localizable48, (java.lang.Object[]) doubleArray50);
        double[][] doubleArray53 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray50);
        java.lang.NullPointerException nullPointerException54 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray53);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException55 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 10, localizable35, (java.lang.Object[]) doubleArray53);
        java.lang.Throwable[] throwableArray56 = maxEvaluationsExceededException55.getSuppressed();
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException(localizable15, (java.lang.Object[]) throwableArray56);
        double[] doubleArray61 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable62 = null;
        double[] doubleArray63 = new double[] {};
        double[][] doubleArray64 = new double[][] { doubleArray63 };
        double[][] doubleArray65 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray64);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException66 = new org.apache.commons.math.FunctionEvaluationException(doubleArray61, localizable62, (java.lang.Object[]) doubleArray64);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException67 = new org.apache.commons.math.linear.MatrixIndexException("org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) doubleArray64);
        java.lang.Object[] objArray68 = matrixIndexException67.getArguments();
        java.lang.NullPointerException nullPointerException69 = org.apache.commons.math.MathRuntimeException.createNullPointerException(localizable15, objArray68);
        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException("", objArray68);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertNotNull(localizable15);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 52 + "'", int34 == 52);
        org.junit.Assert.assertNotNull(localizable35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(nullPointerException41);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(nullPointerException54);
        org.junit.Assert.assertNotNull(throwableArray56);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(objArray68);
        org.junit.Assert.assertNotNull(nullPointerException69);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        try {
            org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl5 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) blockRealMatrix2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 35x10 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException1 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray2 = functionEvaluationException1.getSuppressed();
        java.lang.String str3 = functionEvaluationException1.getPattern();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "evaluation failed for argument = {0}" + "'", str3.equals("evaluation failed for argument = {0}"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        double[][] doubleArray0 = null;
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix1 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        double[] doubleArray5 = blockRealMatrix2.getRow(10);
        double[] doubleArray13 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException14 = new org.apache.commons.math.FunctionEvaluationException(doubleArray13);
        org.apache.commons.math.linear.RealMatrix realMatrix15 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray13);
        double[] doubleArray22 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException23 = new org.apache.commons.math.FunctionEvaluationException(doubleArray22);
        org.apache.commons.math.exception.Localizable localizable24 = null;
        double[] doubleArray27 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable28 = null;
        double[] doubleArray29 = new double[] {};
        double[][] doubleArray30 = new double[][] { doubleArray29 };
        double[][] doubleArray31 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray30);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException32 = new org.apache.commons.math.FunctionEvaluationException(doubleArray27, localizable28, (java.lang.Object[]) doubleArray30);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException33 = new org.apache.commons.math.FunctionEvaluationException(doubleArray22, localizable24, (java.lang.Object[]) doubleArray30);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair35 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray13, doubleArray22, true);
        org.apache.commons.math.linear.RealMatrix realMatrix36 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray22);
        try {
            blockRealMatrix2.setColumn((int) (short) 1, doubleArray22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.InvalidMatrixException; message: dimensions mismatch: got 6x1 but expected 35x1");
        } catch (org.apache.commons.math.linear.InvalidMatrixException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realMatrix36);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        double double6 = blockRealMatrix5.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double14 = blockRealMatrix13.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix10.subtract(blockRealMatrix13);
        try {
            blockRealMatrix5.setRowMatrix((int) 'a', blockRealMatrix13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 97 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.apache.commons.math.exception.Localizable localizable0 = null;
        double[] doubleArray3 = new double[] {};
        double[][] doubleArray4 = new double[][] { doubleArray3 };
        double[][] doubleArray5 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray4);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException6 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray5);
        org.apache.commons.math.exception.Localizable localizable7 = null;
        double[][] doubleArray10 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxEvaluationsExceededException6, localizable7, (java.lang.Object[]) doubleArray10);
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException(localizable0, (java.lang.Object[]) doubleArray10);
        try {
            java.lang.String str13 = mathException12.getPattern();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        boolean boolean6 = blockRealMatrix2.isSquare();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int9 = array2DRowRealMatrix8.getColumnDimension();
        double[][] doubleArray10 = array2DRowRealMatrix8.getData();
        try {
            blockRealMatrix2.setColumnMatrix((int) (byte) -1, (org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index -1 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix7.copy();
        try {
            org.apache.commons.math.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix7, (int) (short) 0, (int) (short) -1, (int) '#', (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index -1 out of allowed range [0, 34]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        double[] doubleArray5 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable6 = null;
        double[] doubleArray7 = new double[] {};
        double[][] doubleArray8 = new double[][] { doubleArray7 };
        double[][] doubleArray9 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray8);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException(doubleArray5, localizable6, (java.lang.Object[]) doubleArray8);
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray8);
        org.apache.commons.math.MathRuntimeException mathRuntimeException13 = new org.apache.commons.math.MathRuntimeException("org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix7.copy();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix8.copy();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor10 = null;
        try {
            double double11 = blockRealMatrix9.walkInColumnOrder(realMatrixPreservingVisitor10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        org.apache.commons.math.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix5, (int) (short) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix11 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(1, 100);
        try {
            blockRealMatrix5.setColumnMatrix((int) (byte) 100, realMatrix11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 100 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        boolean boolean4 = array2DRowRealMatrix0.equals((java.lang.Object) 36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int6 = array2DRowRealMatrix5.getColumnDimension();
        double double7 = array2DRowRealMatrix5.getFrobeniusNorm();
        boolean boolean8 = array2DRowRealMatrix5.isSquare();
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix0.subtract(array2DRowRealMatrix5);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        double[] doubleArray5 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable6 = null;
        double[] doubleArray7 = new double[] {};
        double[][] doubleArray8 = new double[][] { doubleArray7 };
        double[][] doubleArray9 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray8);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException(doubleArray5, localizable6, (java.lang.Object[]) doubleArray8);
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray8);
        int int13 = maxIterationsExceededException12.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable14 = maxIterationsExceededException12.getLocalizablePattern();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray17 = functionEvaluationException16.getSuppressed();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException18 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a', localizable14, (java.lang.Object[]) throwableArray17);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException19 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable) maxEvaluationsExceededException18);
        org.apache.commons.math.optimization.OptimizationException optimizationException20 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) invalidMatrixException19);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 52 + "'", int13 == 52);
        org.junit.Assert.assertNotNull(localizable14);
        org.junit.Assert.assertNotNull(throwableArray17);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker0 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        double[] doubleArray4 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[][] doubleArray7 = new double[][] { doubleArray6 };
        double[][] doubleArray8 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray7);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException(doubleArray4, localizable5, (java.lang.Object[]) doubleArray7);
        double[] doubleArray15 = new double[] { 10L, '#', 0, 1.0d, '#' };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair17 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray4, doubleArray15, true);
        double[] doubleArray20 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable21 = null;
        double[] doubleArray22 = new double[] {};
        double[][] doubleArray23 = new double[][] { doubleArray22 };
        double[][] doubleArray24 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray23);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException(doubleArray20, localizable21, (java.lang.Object[]) doubleArray23);
        double[] doubleArray31 = new double[] { 10L, '#', 0, 1.0d, '#' };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair33 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray20, doubleArray31, true);
        boolean boolean34 = simpleVectorialValueChecker0.converged(10, vectorialPointValuePair17, vectorialPointValuePair33);
        double[] doubleArray35 = vectorialPointValuePair17.getPointRef();
        java.lang.Throwable throwable36 = null;
        org.apache.commons.math.MathRuntimeException mathRuntimeException37 = new org.apache.commons.math.MathRuntimeException(throwable36);
        double[] doubleArray43 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable44 = null;
        double[] doubleArray45 = new double[] {};
        double[][] doubleArray46 = new double[][] { doubleArray45 };
        double[][] doubleArray47 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray46);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException48 = new org.apache.commons.math.FunctionEvaluationException(doubleArray43, localizable44, (java.lang.Object[]) doubleArray46);
        double[][] doubleArray49 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray46);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException50 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray46);
        int int51 = maxIterationsExceededException50.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable52 = maxIterationsExceededException50.getLocalizablePattern();
        double[] doubleArray55 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable56 = null;
        double[] doubleArray57 = new double[] {};
        double[][] doubleArray58 = new double[][] { doubleArray57 };
        double[][] doubleArray59 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray58);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException60 = new org.apache.commons.math.FunctionEvaluationException(doubleArray55, localizable56, (java.lang.Object[]) doubleArray58);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException61 = new org.apache.commons.math.FunctionEvaluationException(throwable36, (double) (short) 100, localizable52, (java.lang.Object[]) doubleArray58);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException63 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray64 = functionEvaluationException63.getSuppressed();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException65 = new org.apache.commons.math.FunctionEvaluationException(doubleArray35, localizable52, (java.lang.Object[]) throwableArray64);
        java.lang.Object[] objArray66 = null;
        java.lang.IllegalStateException illegalStateException67 = org.apache.commons.math.MathRuntimeException.createIllegalStateException(localizable52, objArray66);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 52 + "'", int51 == 52);
        org.junit.Assert.assertNotNull(localizable52);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(throwableArray64);
        org.junit.Assert.assertNotNull(illegalStateException67);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getDeterminant();
        java.lang.String str3 = array2DRowRealMatrix0.toString();
        double double4 = array2DRowRealMatrix0.getDeterminant();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int6 = array2DRowRealMatrix5.getColumnDimension();
        double double7 = array2DRowRealMatrix5.getDeterminant();
        java.lang.String str8 = array2DRowRealMatrix5.toString();
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = array2DRowRealMatrix0.subtract(array2DRowRealMatrix5);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Array2DRowRealMatrix{}" + "'", str3.equals("Array2DRowRealMatrix{}"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Array2DRowRealMatrix{}" + "'", str8.equals("Array2DRowRealMatrix{}"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        double[] doubleArray5 = blockRealMatrix2.getRow(10);
        double[][] doubleArray6 = blockRealMatrix2.getData();
        org.apache.commons.math.linear.RealVector realVector8 = blockRealMatrix2.getRowVector((int) (short) 0);
        double[] doubleArray16 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException(doubleArray16);
        org.apache.commons.math.linear.RealMatrix realMatrix18 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray16);
        double[] doubleArray25 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException26 = new org.apache.commons.math.FunctionEvaluationException(doubleArray25);
        org.apache.commons.math.exception.Localizable localizable27 = null;
        double[] doubleArray30 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable31 = null;
        double[] doubleArray32 = new double[] {};
        double[][] doubleArray33 = new double[][] { doubleArray32 };
        double[][] doubleArray34 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray33);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException35 = new org.apache.commons.math.FunctionEvaluationException(doubleArray30, localizable31, (java.lang.Object[]) doubleArray33);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException(doubleArray25, localizable27, (java.lang.Object[]) doubleArray33);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair38 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray16, doubleArray25, true);
        double[] doubleArray39 = vectorialPointValuePair38.getPoint();
        double[] doubleArray40 = vectorialPointValuePair38.getValueRef();
        try {
            blockRealMatrix2.setRow((int) (byte) -1, doubleArray40);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index -1 out of allowed range [0, 34]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        double double6 = blockRealMatrix5.getNorm();
        double[] doubleArray13 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException14 = new org.apache.commons.math.FunctionEvaluationException(doubleArray13);
        org.apache.commons.math.linear.RealMatrix realMatrix15 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray13);
        double[] doubleArray22 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException23 = new org.apache.commons.math.FunctionEvaluationException(doubleArray22);
        org.apache.commons.math.exception.Localizable localizable24 = null;
        double[] doubleArray27 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable28 = null;
        double[] doubleArray29 = new double[] {};
        double[][] doubleArray30 = new double[][] { doubleArray29 };
        double[][] doubleArray31 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray30);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException32 = new org.apache.commons.math.FunctionEvaluationException(doubleArray27, localizable28, (java.lang.Object[]) doubleArray30);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException33 = new org.apache.commons.math.FunctionEvaluationException(doubleArray22, localizable24, (java.lang.Object[]) doubleArray30);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair35 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray13, doubleArray22, true);
        double[] doubleArray36 = vectorialPointValuePair35.getPoint();
        double[] doubleArray37 = vectorialPointValuePair35.getValueRef();
        try {
            double[] doubleArray38 = blockRealMatrix5.preMultiply(doubleArray37);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        double[] doubleArray4 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[][] doubleArray7 = new double[][] { doubleArray6 };
        double[][] doubleArray8 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray7);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException(doubleArray4, localizable5, (java.lang.Object[]) doubleArray7);
        double[][] doubleArray10 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray7);
        java.lang.NullPointerException nullPointerException11 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray10);
        org.apache.commons.math.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.MathRuntimeException("", (java.lang.Object[]) doubleArray10);
        org.apache.commons.math.MathRuntimeException mathRuntimeException13 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) mathRuntimeException12);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(nullPointerException11);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray4 };
        double[][] doubleArray6 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray5);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException7 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray6);
        double[] doubleArray11 = new double[] {};
        double[][] doubleArray12 = new double[][] { doubleArray11 };
        double[][] doubleArray13 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray12);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException14 = new org.apache.commons.math.MaxEvaluationsExceededException(10, "", (java.lang.Object[]) doubleArray12);
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException((java.lang.Throwable) maxEvaluationsExceededException7, "hi!", (java.lang.Object[]) doubleArray12);
        org.apache.commons.math.optimization.OptimizationException optimizationException16 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) mathException15);
        org.apache.commons.math.exception.Localizable localizable17 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { 1L };
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException15, localizable17, objArray19);
        java.lang.IllegalStateException illegalStateException21 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("hi!", objArray19);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("", objArray19);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(illegalStateException21);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.apache.commons.math.exception.Localizable localizable0 = null;
        double[][] doubleArray4 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException5 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray4);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException6 = new org.apache.commons.math.linear.MatrixIndexException(localizable0, (java.lang.Object[]) doubleArray4);
        double[] doubleArray13 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException14 = new org.apache.commons.math.FunctionEvaluationException(doubleArray13);
        org.apache.commons.math.linear.RealMatrix realMatrix15 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray13);
        double[] doubleArray22 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException23 = new org.apache.commons.math.FunctionEvaluationException(doubleArray22);
        org.apache.commons.math.exception.Localizable localizable24 = null;
        double[] doubleArray27 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable28 = null;
        double[] doubleArray29 = new double[] {};
        double[][] doubleArray30 = new double[][] { doubleArray29 };
        double[][] doubleArray31 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray30);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException32 = new org.apache.commons.math.FunctionEvaluationException(doubleArray27, localizable28, (java.lang.Object[]) doubleArray30);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException33 = new org.apache.commons.math.FunctionEvaluationException(doubleArray22, localizable24, (java.lang.Object[]) doubleArray30);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair35 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray13, doubleArray22, true);
        org.apache.commons.math.exception.Localizable localizable37 = null;
        double[][] doubleArray41 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException42 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException43 = new org.apache.commons.math.linear.MatrixIndexException(localizable37, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) matrixIndexException6, doubleArray13, "{0}", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.linear.RealMatrix realMatrix45 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(nullPointerException5);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(nullPointerException42);
        org.junit.Assert.assertNotNull(realMatrix45);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getDeterminant();
        java.lang.String str3 = array2DRowRealMatrix0.toString();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor4 = null;
        try {
            double double9 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixPreservingVisitor4, (int) (byte) 100, 10, 52, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Array2DRowRealMatrix{}" + "'", str3.equals("Array2DRowRealMatrix{}"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        blockRealMatrix2.addToEntry(0, 1, (double) 1L);
        double[] doubleArray8 = null;
        try {
            blockRealMatrix2.setRow((int) (byte) 10, doubleArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix5.getColumnMatrix(10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 10 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        double[] doubleArray5 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable6 = null;
        double[] doubleArray7 = new double[] {};
        double[][] doubleArray8 = new double[][] { doubleArray7 };
        double[][] doubleArray9 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray8);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException(doubleArray5, localizable6, (java.lang.Object[]) doubleArray8);
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray8);
        int int13 = maxIterationsExceededException12.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable14 = maxIterationsExceededException12.getLocalizablePattern();
        double[] doubleArray20 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable21 = null;
        double[] doubleArray22 = new double[] {};
        double[][] doubleArray23 = new double[][] { doubleArray22 };
        double[][] doubleArray24 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray23);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException(doubleArray20, localizable21, (java.lang.Object[]) doubleArray23);
        double[][] doubleArray26 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray23);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray23);
        int int28 = maxIterationsExceededException27.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable29 = maxIterationsExceededException27.getLocalizablePattern();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException31 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray32 = functionEvaluationException31.getSuppressed();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException33 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a', localizable29, (java.lang.Object[]) throwableArray32);
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException0, localizable14, (java.lang.Object[]) throwableArray32);
        double[] doubleArray39 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable40 = null;
        double[] doubleArray41 = new double[] {};
        double[][] doubleArray42 = new double[][] { doubleArray41 };
        double[][] doubleArray43 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray42);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException(doubleArray39, localizable40, (java.lang.Object[]) doubleArray42);
        double[][] doubleArray45 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray42);
        java.lang.NullPointerException nullPointerException46 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray45);
        org.apache.commons.math.MathRuntimeException mathRuntimeException47 = new org.apache.commons.math.MathRuntimeException("", (java.lang.Object[]) doubleArray45);
        java.lang.IllegalArgumentException illegalArgumentException48 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException(localizable14, (java.lang.Object[]) doubleArray45);
        java.lang.Object[] objArray49 = null;
        java.io.EOFException eOFException50 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable14, objArray49);
        java.lang.Object[] objArray51 = null;
        java.lang.UnsupportedOperationException unsupportedOperationException52 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException(localizable14, objArray51);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 52 + "'", int13 == 52);
        org.junit.Assert.assertNotNull(localizable14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 52 + "'", int28 == 52);
        org.junit.Assert.assertNotNull(localizable29);
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(nullPointerException46);
        org.junit.Assert.assertNotNull(illegalArgumentException48);
        org.junit.Assert.assertNotNull(eOFException50);
        org.junit.Assert.assertNotNull(unsupportedOperationException52);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor2 = null;
        try {
            double double7 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixPreservingVisitor2, (int) (short) -1, 10, 0, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index -1 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix(0, (int) (byte) 10);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double[][] doubleArray2 = array2DRowRealMatrix0.getData();
        boolean boolean3 = array2DRowRealMatrix0.isSquare();
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl5 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix0, (double) 1.0f);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix6 = lUDecompositionImpl5.getL();
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        boolean boolean2 = array2DRowRealMatrix0.isSingular();
        org.apache.commons.math.linear.RealMatrix realMatrix5 = array2DRowRealMatrix0.createMatrix((int) '#', 1);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix0.transpose();
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realMatrix5);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        double[] doubleArray5 = blockRealMatrix2.getRow(10);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor6 = null;
        try {
            double double11 = blockRealMatrix2.walkInRowOrder(realMatrixChangingVisitor6, (int) (byte) 10, 97, (int) 'a', 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 97 out of allowed range [0, 34]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException();
        double[] doubleArray7 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable8 = null;
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(doubleArray7, localizable8, (java.lang.Object[]) doubleArray10);
        double[][] doubleArray13 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray10);
        int int15 = maxIterationsExceededException14.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable16 = maxIterationsExceededException14.getLocalizablePattern();
        double[] doubleArray22 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable23 = null;
        double[] doubleArray24 = new double[] {};
        double[][] doubleArray25 = new double[][] { doubleArray24 };
        double[][] doubleArray26 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray25);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException27 = new org.apache.commons.math.FunctionEvaluationException(doubleArray22, localizable23, (java.lang.Object[]) doubleArray25);
        double[][] doubleArray28 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray25);
        int int30 = maxIterationsExceededException29.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable31 = maxIterationsExceededException29.getLocalizablePattern();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException33 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray34 = functionEvaluationException33.getSuppressed();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException35 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a', localizable31, (java.lang.Object[]) throwableArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException2, localizable16, (java.lang.Object[]) throwableArray34);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException37 = new org.apache.commons.math.MaxEvaluationsExceededException(0, "", (java.lang.Object[]) throwableArray34);
        java.lang.Object[] objArray40 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException41 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxEvaluationsExceededException37, (-1.0d), "", objArray40);
        java.io.ObjectInputStream objectInputStream43 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.deserializeRealVector((java.lang.Object) "", "evaluation failed for argument = {0}", objectInputStream43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 52 + "'", int15 == 52);
        org.junit.Assert.assertNotNull(localizable16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 52 + "'", int30 == 52);
        org.junit.Assert.assertNotNull(localizable31);
        org.junit.Assert.assertNotNull(throwableArray34);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor5 = null;
        try {
            double double10 = blockRealMatrix2.walkInRowOrder(realMatrixChangingVisitor5, 52, 36, (int) (short) 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 52 out of allowed range [0, 34]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        int[] intArray5 = null;
        int[] intArray12 = new int[] { 36, 'a', 97, 0, (short) -1, 97 };
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix13 = blockRealMatrix2.getSubMatrix(intArray5, intArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(intArray12);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        boolean boolean2 = array2DRowRealMatrix0.isSingular();
        org.apache.commons.math.linear.RealMatrix realMatrix5 = array2DRowRealMatrix0.createMatrix((int) '#', 1);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int7 = array2DRowRealMatrix6.getColumnDimension();
        double[][] doubleArray8 = array2DRowRealMatrix6.getData();
        boolean boolean9 = array2DRowRealMatrix6.isSquare();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix10 = array2DRowRealMatrix0.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix6);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double[][] doubleArray2 = array2DRowRealMatrix0.getDataRef();
        double[] doubleArray10 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException11 = new org.apache.commons.math.FunctionEvaluationException(doubleArray10);
        org.apache.commons.math.linear.BigMatrix bigMatrix12 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray10);
        try {
            array2DRowRealMatrix0.setRow((int) (short) -1, doubleArray10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index -1 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(bigMatrix12);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.apache.commons.math.exception.Localizable localizable1 = null;
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math.exception.Localizable localizable3 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray6 = functionEvaluationException5.getSuppressed();
        org.apache.commons.math.MathRuntimeException mathRuntimeException7 = new org.apache.commons.math.MathRuntimeException(throwable2, localizable3, (java.lang.Object[]) throwableArray6);
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException(localizable1, (java.lang.Object[]) throwableArray6);
        org.apache.commons.math.optimization.OptimizationException optimizationException9 = new org.apache.commons.math.optimization.OptimizationException("org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.apache.commons.math.exception.Localizable localizable2 = null;
        double[] doubleArray9 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException(doubleArray9);
        org.apache.commons.math.exception.Localizable localizable11 = null;
        double[] doubleArray14 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable15 = null;
        double[] doubleArray16 = new double[] {};
        double[][] doubleArray17 = new double[][] { doubleArray16 };
        double[][] doubleArray18 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray17);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException19 = new org.apache.commons.math.FunctionEvaluationException(doubleArray14, localizable15, (java.lang.Object[]) doubleArray17);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException(doubleArray9, localizable11, (java.lang.Object[]) doubleArray17);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException(localizable2, (java.lang.Object[]) doubleArray17);
        java.lang.ArithmeticException arithmeticException22 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", (java.lang.Object[]) doubleArray17);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("hi!", (java.lang.Object[]) doubleArray17);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix24 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray17);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(arithmeticException22);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        double[] doubleArray5 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable6 = null;
        double[] doubleArray7 = new double[] {};
        double[][] doubleArray8 = new double[][] { doubleArray7 };
        double[][] doubleArray9 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray8);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException(doubleArray5, localizable6, (java.lang.Object[]) doubleArray8);
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray8);
        int int13 = maxIterationsExceededException12.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable14 = maxIterationsExceededException12.getLocalizablePattern();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray17 = functionEvaluationException16.getSuppressed();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException18 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a', localizable14, (java.lang.Object[]) throwableArray17);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxEvaluationsExceededException18, (double) 100.0f);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 52 + "'", int13 == 52);
        org.junit.Assert.assertNotNull(localizable14);
        org.junit.Assert.assertNotNull(throwableArray17);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix7.copy();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double16 = blockRealMatrix15.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix12.subtract(blockRealMatrix15);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix17.copy();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix18.copy();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix21 = blockRealMatrix18.scalarAdd(0.0d);
        try {
            blockRealMatrix8.setRowMatrix(0, blockRealMatrix21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.InvalidMatrixException; message: dimensions mismatch: got 35x10 but expected 1x10");
        } catch (org.apache.commons.math.linear.InvalidMatrixException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertNotNull(blockRealMatrix21);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        double[] doubleArray5 = blockRealMatrix2.getRow(10);
        double[][] doubleArray6 = blockRealMatrix2.getData();
        org.apache.commons.math.linear.RealVector realVector8 = blockRealMatrix2.getRowVector((int) (short) 0);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor9 = null;
        try {
            double double10 = blockRealMatrix2.walkInOptimizedOrder(realMatrixPreservingVisitor9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector8);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor2 = null;
        try {
            double double7 = array2DRowRealMatrix0.walkInRowOrder(realMatrixChangingVisitor2, 97, (int) (short) -1, 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 97 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        boolean boolean3 = array2DRowRealMatrix0.isSquare();
        try {
            org.apache.commons.math.linear.MatrixUtils.checkRowIndex((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix5.createMatrix((int) (byte) 100, 52);
        double[] doubleArray16 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException(doubleArray16);
        org.apache.commons.math.linear.RealMatrix realMatrix18 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray16);
        double[] doubleArray25 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException26 = new org.apache.commons.math.FunctionEvaluationException(doubleArray25);
        org.apache.commons.math.exception.Localizable localizable27 = null;
        double[] doubleArray30 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable31 = null;
        double[] doubleArray32 = new double[] {};
        double[][] doubleArray33 = new double[][] { doubleArray32 };
        double[][] doubleArray34 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray33);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException35 = new org.apache.commons.math.FunctionEvaluationException(doubleArray30, localizable31, (java.lang.Object[]) doubleArray33);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException(doubleArray25, localizable27, (java.lang.Object[]) doubleArray33);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair38 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray16, doubleArray25, true);
        org.apache.commons.math.linear.RealVector realVector39 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray16);
        try {
            blockRealMatrix8.setRowVector(10, realVector39);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.InvalidMatrixException; message: dimensions mismatch: got 1x6 but expected 1x52");
        } catch (org.apache.commons.math.linear.InvalidMatrixException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realVector39);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException();
        double[] doubleArray6 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable7 = null;
        double[] doubleArray8 = new double[] {};
        double[][] doubleArray9 = new double[][] { doubleArray8 };
        double[][] doubleArray10 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray9);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException11 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6, localizable7, (java.lang.Object[]) doubleArray9);
        double[][] doubleArray12 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray9);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray9);
        int int14 = maxIterationsExceededException13.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable15 = maxIterationsExceededException13.getLocalizablePattern();
        double[] doubleArray21 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable22 = null;
        double[] doubleArray23 = new double[] {};
        double[][] doubleArray24 = new double[][] { doubleArray23 };
        double[][] doubleArray25 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray24);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException26 = new org.apache.commons.math.FunctionEvaluationException(doubleArray21, localizable22, (java.lang.Object[]) doubleArray24);
        double[][] doubleArray27 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray24);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray24);
        int int29 = maxIterationsExceededException28.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable30 = maxIterationsExceededException28.getLocalizablePattern();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException32 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray33 = functionEvaluationException32.getSuppressed();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException34 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a', localizable30, (java.lang.Object[]) throwableArray33);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException1, localizable15, (java.lang.Object[]) throwableArray33);
        java.lang.Throwable throwable36 = null;
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException();
        double[] doubleArray43 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable44 = null;
        double[] doubleArray45 = new double[] {};
        double[][] doubleArray46 = new double[][] { doubleArray45 };
        double[][] doubleArray47 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray46);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException48 = new org.apache.commons.math.FunctionEvaluationException(doubleArray43, localizable44, (java.lang.Object[]) doubleArray46);
        double[][] doubleArray49 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray46);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException50 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray46);
        int int51 = maxIterationsExceededException50.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable52 = maxIterationsExceededException50.getLocalizablePattern();
        double[] doubleArray58 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable59 = null;
        double[] doubleArray60 = new double[] {};
        double[][] doubleArray61 = new double[][] { doubleArray60 };
        double[][] doubleArray62 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray61);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException63 = new org.apache.commons.math.FunctionEvaluationException(doubleArray58, localizable59, (java.lang.Object[]) doubleArray61);
        double[][] doubleArray64 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray61);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException65 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray61);
        int int66 = maxIterationsExceededException65.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable67 = maxIterationsExceededException65.getLocalizablePattern();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException69 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray70 = functionEvaluationException69.getSuppressed();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException71 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a', localizable67, (java.lang.Object[]) throwableArray70);
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException38, localizable52, (java.lang.Object[]) throwableArray70);
        double[] doubleArray77 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable78 = null;
        double[] doubleArray79 = new double[] {};
        double[][] doubleArray80 = new double[][] { doubleArray79 };
        double[][] doubleArray81 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray80);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException82 = new org.apache.commons.math.FunctionEvaluationException(doubleArray77, localizable78, (java.lang.Object[]) doubleArray80);
        double[][] doubleArray83 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray80);
        java.lang.NullPointerException nullPointerException84 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray83);
        org.apache.commons.math.MathRuntimeException mathRuntimeException85 = new org.apache.commons.math.MathRuntimeException("", (java.lang.Object[]) doubleArray83);
        java.lang.IllegalArgumentException illegalArgumentException86 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException(localizable52, (java.lang.Object[]) doubleArray83);
        java.lang.Object[] objArray87 = null;
        java.io.EOFException eOFException88 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable52, objArray87);
        double[][] doubleArray92 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException93 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray92);
        java.lang.Throwable[] throwableArray94 = nullPointerException93.getSuppressed();
        org.apache.commons.math.optimization.OptimizationException optimizationException95 = new org.apache.commons.math.optimization.OptimizationException(localizable52, (java.lang.Object[]) throwableArray94);
        org.apache.commons.math.MathException mathException96 = new org.apache.commons.math.MathException(throwable36, "Array2DRowRealMatrix{}", (java.lang.Object[]) throwableArray94);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException97 = new org.apache.commons.math.MaxEvaluationsExceededException((-1), localizable15, (java.lang.Object[]) throwableArray94);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertNotNull(localizable15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 52 + "'", int29 == 52);
        org.junit.Assert.assertNotNull(localizable30);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 52 + "'", int51 == 52);
        org.junit.Assert.assertNotNull(localizable52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 52 + "'", int66 == 52);
        org.junit.Assert.assertNotNull(localizable67);
        org.junit.Assert.assertNotNull(throwableArray70);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(nullPointerException84);
        org.junit.Assert.assertNotNull(illegalArgumentException86);
        org.junit.Assert.assertNotNull(eOFException88);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertNotNull(nullPointerException93);
        org.junit.Assert.assertNotNull(throwableArray94);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        double[] doubleArray5 = blockRealMatrix2.getRow(10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double10 = blockRealMatrix9.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix9.getRowMatrix(0);
        org.apache.commons.math.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix12, (int) (short) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = blockRealMatrix12.scalarMultiply(0.0d);
        try {
            blockRealMatrix2.setRowMatrix(36, blockRealMatrix12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 36 out of allowed range [0, 34]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
        org.junit.Assert.assertNotNull(realMatrix16);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        double[] doubleArray8 = new double[] {};
        double[][] doubleArray9 = new double[][] { doubleArray8 };
        double[][] doubleArray10 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray9);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException11 = new org.apache.commons.math.MaxEvaluationsExceededException(10, "", (java.lang.Object[]) doubleArray9);
        boolean boolean12 = blockRealMatrix5.equals((java.lang.Object) "");
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix5.getColumnMatrix(10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 10 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        double[] doubleArray5 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable6 = null;
        double[] doubleArray7 = new double[] {};
        double[][] doubleArray8 = new double[][] { doubleArray7 };
        double[][] doubleArray9 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray8);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException(doubleArray5, localizable6, (java.lang.Object[]) doubleArray8);
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray8);
        int int13 = maxIterationsExceededException12.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable14 = maxIterationsExceededException12.getLocalizablePattern();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray17 = functionEvaluationException16.getSuppressed();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException18 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a', localizable14, (java.lang.Object[]) throwableArray17);
        org.apache.commons.math.exception.Localizable localizable19 = null;
        double[][] doubleArray23 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException24 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray23);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException25 = new org.apache.commons.math.linear.MatrixIndexException(localizable19, (java.lang.Object[]) doubleArray23);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException26 = new org.apache.commons.math.linear.InvalidMatrixException(localizable14, (java.lang.Object[]) doubleArray23);
        double[] doubleArray29 = new double[] {};
        double[][] doubleArray30 = new double[][] { doubleArray29 };
        double[][] doubleArray31 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray30);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException32 = new org.apache.commons.math.MaxEvaluationsExceededException(10, "", (java.lang.Object[]) doubleArray30);
        java.lang.NullPointerException nullPointerException33 = org.apache.commons.math.MathRuntimeException.createNullPointerException(localizable14, (java.lang.Object[]) doubleArray30);
        java.lang.Object[] objArray34 = null;
        org.apache.commons.math.MathRuntimeException mathRuntimeException35 = new org.apache.commons.math.MathRuntimeException(localizable14, objArray34);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 52 + "'", int13 == 52);
        org.junit.Assert.assertNotNull(localizable14);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(nullPointerException24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(nullPointerException33);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix7.copy();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix8.copy();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double13 = blockRealMatrix12.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix12.getRowMatrix(0);
        double[] doubleArray18 = new double[] {};
        double[][] doubleArray19 = new double[][] { doubleArray18 };
        double[][] doubleArray20 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray19);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException21 = new org.apache.commons.math.MaxEvaluationsExceededException(10, "", (java.lang.Object[]) doubleArray19);
        boolean boolean22 = blockRealMatrix15.equals((java.lang.Object) "");
        try {
            org.apache.commons.math.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix8, (org.apache.commons.math.linear.AnyMatrix) blockRealMatrix15);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException1 = new org.apache.commons.math.FunctionEvaluationException((double) 1);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        boolean boolean2 = array2DRowRealMatrix0.isSingular();
        org.apache.commons.math.linear.BigMatrix bigMatrix4 = org.apache.commons.math.linear.MatrixUtils.createBigIdentityMatrix((int) (byte) 100);
        try {
            org.apache.commons.math.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math.linear.AnyMatrix) bigMatrix4);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(bigMatrix4);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.apache.commons.math.exception.Localizable localizable3 = null;
        double[] doubleArray10 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException11 = new org.apache.commons.math.FunctionEvaluationException(doubleArray10);
        org.apache.commons.math.exception.Localizable localizable12 = null;
        double[] doubleArray15 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable16 = null;
        double[] doubleArray17 = new double[] {};
        double[][] doubleArray18 = new double[][] { doubleArray17 };
        double[][] doubleArray19 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray18);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException(doubleArray15, localizable16, (java.lang.Object[]) doubleArray18);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException21 = new org.apache.commons.math.FunctionEvaluationException(doubleArray10, localizable12, (java.lang.Object[]) doubleArray18);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(localizable3, (java.lang.Object[]) doubleArray18);
        java.lang.ArithmeticException arithmeticException23 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", (java.lang.Object[]) doubleArray18);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("hi!", (java.lang.Object[]) doubleArray18);
        java.lang.NullPointerException nullPointerException25 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(arithmeticException23);
        org.junit.Assert.assertNotNull(nullPointerException25);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 1, (int) (short) 1);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int4 = array2DRowRealMatrix3.getColumnDimension();
        double double5 = array2DRowRealMatrix3.getDeterminant();
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = array2DRowRealMatrix2.add(array2DRowRealMatrix3);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        boolean boolean2 = array2DRowRealMatrix0.isSingular();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor3 = null;
        try {
            double double4 = array2DRowRealMatrix0.walkInRowOrder(realMatrixChangingVisitor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(52);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        boolean boolean2 = array2DRowRealMatrix0.isSingular();
        int[] intArray5 = new int[] { (byte) 1, (byte) 10 };
        int[] intArray11 = new int[] { (short) -1, (short) 10, (short) 10, (byte) 0, 36 };
        double[] doubleArray15 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable16 = null;
        double[] doubleArray17 = new double[] {};
        double[][] doubleArray18 = new double[][] { doubleArray17 };
        double[][] doubleArray19 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray18);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException(doubleArray15, localizable16, (java.lang.Object[]) doubleArray18);
        double[][] doubleArray21 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray18);
        java.lang.ArithmeticException arithmeticException22 = org.apache.commons.math.MathRuntimeException.createArithmeticException("org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) doubleArray18);
        try {
            array2DRowRealMatrix0.copySubMatrix(intArray5, intArray11, doubleArray18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 1 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(arithmeticException22);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        double[] doubleArray5 = new double[] {};
        double[][] doubleArray6 = new double[][] { doubleArray5 };
        double[][] doubleArray7 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException8 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray7);
        double[] doubleArray17 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException(doubleArray17);
        org.apache.commons.math.exception.Localizable localizable19 = null;
        double[] doubleArray22 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable23 = null;
        double[] doubleArray24 = new double[] {};
        double[][] doubleArray25 = new double[][] { doubleArray24 };
        double[][] doubleArray26 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray25);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException27 = new org.apache.commons.math.FunctionEvaluationException(doubleArray22, localizable23, (java.lang.Object[]) doubleArray25);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException28 = new org.apache.commons.math.FunctionEvaluationException(doubleArray17, localizable19, (java.lang.Object[]) doubleArray25);
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray25);
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException9, "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) doubleArray25);
        java.lang.NullPointerException nullPointerException31 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray25);
        double[] doubleArray38 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable39 = null;
        double[] doubleArray40 = new double[] {};
        double[][] doubleArray41 = new double[][] { doubleArray40 };
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException43 = new org.apache.commons.math.FunctionEvaluationException(doubleArray38, localizable39, (java.lang.Object[]) doubleArray41);
        double[][] doubleArray44 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException45 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray41);
        int int46 = maxIterationsExceededException45.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable47 = maxIterationsExceededException45.getLocalizablePattern();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException49 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray50 = functionEvaluationException49.getSuppressed();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException51 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a', localizable47, (java.lang.Object[]) throwableArray50);
        double[] doubleArray58 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable59 = null;
        double[] doubleArray60 = new double[] {};
        double[][] doubleArray61 = new double[][] { doubleArray60 };
        double[][] doubleArray62 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray61);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException63 = new org.apache.commons.math.FunctionEvaluationException(doubleArray58, localizable59, (java.lang.Object[]) doubleArray61);
        double[][] doubleArray64 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray61);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException65 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray61);
        int int66 = maxIterationsExceededException65.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable67 = maxIterationsExceededException65.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable68 = null;
        double[][] doubleArray72 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException73 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray72);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException74 = new org.apache.commons.math.linear.MatrixIndexException(localizable68, (java.lang.Object[]) doubleArray72);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException75 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', localizable67, (java.lang.Object[]) doubleArray72);
        double[] doubleArray79 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable80 = null;
        double[] doubleArray81 = new double[] {};
        double[][] doubleArray82 = new double[][] { doubleArray81 };
        double[][] doubleArray83 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray82);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException84 = new org.apache.commons.math.FunctionEvaluationException(doubleArray79, localizable80, (java.lang.Object[]) doubleArray82);
        double[][] doubleArray85 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray82);
        java.lang.NullPointerException nullPointerException86 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray85);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException87 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 10, localizable67, (java.lang.Object[]) doubleArray85);
        java.lang.Throwable[] throwableArray88 = maxEvaluationsExceededException87.getSuppressed();
        org.apache.commons.math.MathException mathException89 = new org.apache.commons.math.MathException(localizable47, (java.lang.Object[]) throwableArray88);
        double[] doubleArray94 = new double[] {};
        double[][] doubleArray95 = new double[][] { doubleArray94 };
        double[][] doubleArray96 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray95);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException97 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray96);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException98 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray96);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException99 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException31, 0.0d, localizable47, (java.lang.Object[]) doubleArray96);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(nullPointerException31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 52 + "'", int46 == 52);
        org.junit.Assert.assertNotNull(localizable47);
        org.junit.Assert.assertNotNull(throwableArray50);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 52 + "'", int66 == 52);
        org.junit.Assert.assertNotNull(localizable67);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(nullPointerException73);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(nullPointerException86);
        org.junit.Assert.assertNotNull(throwableArray88);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertNotNull(doubleArray95);
        org.junit.Assert.assertNotNull(doubleArray96);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor8 = null;
        try {
            double double13 = blockRealMatrix5.walkInOptimizedOrder(realMatrixPreservingVisitor8, 0, 100, (int) '#', 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, 34]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        double[] doubleArray2 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable3 = null;
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray4 };
        double[][] doubleArray6 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray5);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException7 = new org.apache.commons.math.FunctionEvaluationException(doubleArray2, localizable3, (java.lang.Object[]) doubleArray5);
        double[] doubleArray13 = new double[] { 10L, '#', 0, 1.0d, '#' };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair15 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray2, doubleArray13, true);
        double[] doubleArray16 = vectorialPointValuePair15.getValueRef();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double[][] doubleArray2 = array2DRowRealMatrix0.getData();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor3 = null;
        try {
            double double4 = array2DRowRealMatrix0.walkInRowOrder(realMatrixPreservingVisitor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        double[] doubleArray6 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException7 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6);
        org.apache.commons.math.linear.BigMatrix bigMatrix8 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(doubleArray6);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(bigMatrix8);
        org.junit.Assert.assertNotNull(realMatrix10);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix7.copy();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix8.copy();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix8.scalarAdd(0.0d);
        int int12 = blockRealMatrix8.getColumnDimension();
        try {
            org.apache.commons.math.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix8, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 35 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        double[][] doubleArray3 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        org.apache.commons.math.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.MathRuntimeException("", (java.lang.Object[]) doubleArray3);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.MathRuntimeException mathRuntimeException1 = new org.apache.commons.math.MathRuntimeException(throwable0);
        double[] doubleArray7 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable8 = null;
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(doubleArray7, localizable8, (java.lang.Object[]) doubleArray10);
        double[][] doubleArray13 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray10);
        int int15 = maxIterationsExceededException14.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable16 = maxIterationsExceededException14.getLocalizablePattern();
        double[] doubleArray19 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable20 = null;
        double[] doubleArray21 = new double[] {};
        double[][] doubleArray22 = new double[][] { doubleArray21 };
        double[][] doubleArray23 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray22);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException24 = new org.apache.commons.math.FunctionEvaluationException(doubleArray19, localizable20, (java.lang.Object[]) doubleArray22);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException(throwable0, (double) (short) 100, localizable16, (java.lang.Object[]) doubleArray22);
        double[] doubleArray33 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[] doubleArray35 = new double[] {};
        double[][] doubleArray36 = new double[][] { doubleArray35 };
        double[][] doubleArray37 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray36);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException38 = new org.apache.commons.math.FunctionEvaluationException(doubleArray33, localizable34, (java.lang.Object[]) doubleArray36);
        double[][] doubleArray39 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray36);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException40 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray36);
        int int41 = maxIterationsExceededException40.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable42 = maxIterationsExceededException40.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable43 = null;
        double[][] doubleArray47 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException48 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray47);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException49 = new org.apache.commons.math.linear.MatrixIndexException(localizable43, (java.lang.Object[]) doubleArray47);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException50 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', localizable42, (java.lang.Object[]) doubleArray47);
        double[] doubleArray54 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable55 = null;
        double[] doubleArray56 = new double[] {};
        double[][] doubleArray57 = new double[][] { doubleArray56 };
        double[][] doubleArray58 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray57);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException59 = new org.apache.commons.math.FunctionEvaluationException(doubleArray54, localizable55, (java.lang.Object[]) doubleArray57);
        double[][] doubleArray60 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray57);
        java.lang.NullPointerException nullPointerException61 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray60);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException62 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 10, localizable42, (java.lang.Object[]) doubleArray60);
        double[] doubleArray69 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException70 = new org.apache.commons.math.FunctionEvaluationException(doubleArray69);
        org.apache.commons.math.exception.Localizable localizable71 = null;
        double[] doubleArray74 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable75 = null;
        double[] doubleArray76 = new double[] {};
        double[][] doubleArray77 = new double[][] { doubleArray76 };
        double[][] doubleArray78 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray77);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException79 = new org.apache.commons.math.FunctionEvaluationException(doubleArray74, localizable75, (java.lang.Object[]) doubleArray77);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException80 = new org.apache.commons.math.FunctionEvaluationException(doubleArray69, localizable71, (java.lang.Object[]) doubleArray77);
        double[][] doubleArray81 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray77);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException82 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable42, (java.lang.Object[]) doubleArray81);
        java.lang.NullPointerException nullPointerException83 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray81);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException84 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable16, (java.lang.Object[]) doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 52 + "'", int15 == 52);
        org.junit.Assert.assertNotNull(localizable16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 52 + "'", int41 == 52);
        org.junit.Assert.assertNotNull(localizable42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(nullPointerException48);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(nullPointerException61);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException82);
        org.junit.Assert.assertNotNull(nullPointerException83);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException84);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        java.lang.Object obj0 = null;
        java.io.ObjectInputStream objectInputStream2 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.deserializeRealMatrix(obj0, "maximal number of iterations ({0}) exceeded", objectInputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        double[][] doubleArray2 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (byte) 100, (int) 'a');
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException();
        double[] doubleArray8 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable9 = null;
        double[] doubleArray10 = new double[] {};
        double[][] doubleArray11 = new double[][] { doubleArray10 };
        double[][] doubleArray12 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray11);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException13 = new org.apache.commons.math.FunctionEvaluationException(doubleArray8, localizable9, (java.lang.Object[]) doubleArray11);
        double[][] doubleArray14 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray11);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray11);
        int int16 = maxIterationsExceededException15.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable17 = maxIterationsExceededException15.getLocalizablePattern();
        double[] doubleArray23 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable24 = null;
        double[] doubleArray25 = new double[] {};
        double[][] doubleArray26 = new double[][] { doubleArray25 };
        double[][] doubleArray27 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray26);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException28 = new org.apache.commons.math.FunctionEvaluationException(doubleArray23, localizable24, (java.lang.Object[]) doubleArray26);
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray26);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray26);
        int int31 = maxIterationsExceededException30.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable32 = maxIterationsExceededException30.getLocalizablePattern();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException34 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray35 = functionEvaluationException34.getSuppressed();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException36 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a', localizable32, (java.lang.Object[]) throwableArray35);
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException3, localizable17, (java.lang.Object[]) throwableArray35);
        org.apache.commons.math.exception.Localizable localizable38 = null;
        java.lang.Throwable throwable39 = null;
        org.apache.commons.math.exception.Localizable localizable40 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException42 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray43 = functionEvaluationException42.getSuppressed();
        org.apache.commons.math.MathRuntimeException mathRuntimeException44 = new org.apache.commons.math.MathRuntimeException(throwable39, localizable40, (java.lang.Object[]) throwableArray43);
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException(localizable38, (java.lang.Object[]) throwableArray43);
        java.text.ParseException parseException46 = org.apache.commons.math.MathRuntimeException.createParseException((int) ' ', localizable17, (java.lang.Object[]) throwableArray43);
        double[] doubleArray52 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable53 = null;
        double[] doubleArray54 = new double[] {};
        double[][] doubleArray55 = new double[][] { doubleArray54 };
        double[][] doubleArray56 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray55);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException57 = new org.apache.commons.math.FunctionEvaluationException(doubleArray52, localizable53, (java.lang.Object[]) doubleArray55);
        double[][] doubleArray58 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray55);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException59 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray55);
        int int60 = maxIterationsExceededException59.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable61 = maxIterationsExceededException59.getLocalizablePattern();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException63 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray64 = functionEvaluationException63.getSuppressed();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException65 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a', localizable61, (java.lang.Object[]) throwableArray64);
        java.util.NoSuchElementException noSuchElementException66 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException(localizable17, (java.lang.Object[]) throwableArray64);
        java.text.ParseException parseException67 = org.apache.commons.math.MathRuntimeException.createParseException(0, "{0}", (java.lang.Object[]) throwableArray64);
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) parseException67);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 52 + "'", int16 == 52);
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 52 + "'", int31 == 52);
        org.junit.Assert.assertNotNull(localizable32);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertNotNull(throwableArray43);
        org.junit.Assert.assertNotNull(parseException46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 52 + "'", int60 == 52);
        org.junit.Assert.assertNotNull(localizable61);
        org.junit.Assert.assertNotNull(throwableArray64);
        org.junit.Assert.assertNotNull(noSuchElementException66);
        org.junit.Assert.assertNotNull(parseException67);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix2.multiply(blockRealMatrix7);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math.exception.Localizable localizable3 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray6 = functionEvaluationException5.getSuppressed();
        org.apache.commons.math.MathRuntimeException mathRuntimeException7 = new org.apache.commons.math.MathRuntimeException(throwable2, localizable3, (java.lang.Object[]) throwableArray6);
        java.text.ParseException parseException8 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) throwableArray6);
        org.apache.commons.math.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) parseException8);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(parseException8);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        java.lang.String[] strArray3 = new java.lang.String[] { "{0}", "maximal number of iterations ({0}) exceeded", "Array2DRowRealMatrix{}" };
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix4 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(strArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 1, (int) (short) 1);
        double[][] doubleArray6 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException7 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray6);
        java.lang.Throwable[] throwableArray8 = nullPointerException7.getSuppressed();
        org.apache.commons.math.exception.Localizable localizable9 = null;
        double[] doubleArray12 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable13 = null;
        double[] doubleArray14 = new double[] {};
        double[][] doubleArray15 = new double[][] { doubleArray14 };
        double[][] doubleArray16 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray15);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException(doubleArray12, localizable13, (java.lang.Object[]) doubleArray15);
        double[][] doubleArray18 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray15);
        org.apache.commons.math.MathRuntimeException mathRuntimeException19 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) nullPointerException7, localizable9, (java.lang.Object[]) doubleArray18);
        double[] doubleArray26 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException27 = new org.apache.commons.math.FunctionEvaluationException(doubleArray26);
        double[][] doubleArray32 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException33 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray32);
        java.lang.Throwable[] throwableArray34 = nullPointerException33.getSuppressed();
        double[] doubleArray41 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException42 = new org.apache.commons.math.FunctionEvaluationException(doubleArray41);
        org.apache.commons.math.linear.RealMatrix realMatrix43 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray41);
        double[] doubleArray50 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException51 = new org.apache.commons.math.FunctionEvaluationException(doubleArray50);
        java.io.IOException iOException52 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) functionEvaluationException51);
        double[] doubleArray56 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable57 = null;
        double[] doubleArray58 = new double[] {};
        double[][] doubleArray59 = new double[][] { doubleArray58 };
        double[][] doubleArray60 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray59);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException61 = new org.apache.commons.math.FunctionEvaluationException(doubleArray56, localizable57, (java.lang.Object[]) doubleArray59);
        double[][] doubleArray62 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray59);
        java.lang.NullPointerException nullPointerException63 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray62);
        java.lang.Object[] objArray64 = new java.lang.Object[] { nullPointerException33, realMatrix43, functionEvaluationException51, "" };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException65 = new org.apache.commons.math.FunctionEvaluationException(doubleArray26, "hi!", objArray64);
        org.apache.commons.math.linear.BigMatrix bigMatrix66 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(doubleArray26);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException67 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathRuntimeException19, doubleArray26);
        double[] doubleArray68 = functionEvaluationException67.getArgument();
        try {
            double[] doubleArray69 = array2DRowRealMatrix2.operate(doubleArray68);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(nullPointerException7);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(nullPointerException33);
        org.junit.Assert.assertNotNull(throwableArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(iOException52);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(nullPointerException63);
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(bigMatrix66);
        org.junit.Assert.assertNotNull(doubleArray68);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        try {
            double[] doubleArray9 = blockRealMatrix5.getColumn(36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 36 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix5.getRowMatrix(0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix8.createMatrix((int) (byte) 100, 52);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix8);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double[][] doubleArray2 = array2DRowRealMatrix0.getDataRef();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix4 = array2DRowRealMatrix0.getColumnMatrix((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index -1 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(doubleArray2);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        double[] doubleArray5 = blockRealMatrix2.getRow(10);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor6 = null;
        try {
            double double7 = blockRealMatrix2.walkInRowOrder(realMatrixPreservingVisitor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double[][] doubleArray6 = null;
        try {
            array2DRowRealMatrix0.copySubMatrix(0, (int) (byte) 10, 36, (int) '#', doubleArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 0 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor6 = null;
        try {
            double double7 = blockRealMatrix2.walkInColumnOrder(realMatrixPreservingVisitor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        boolean boolean2 = array2DRowRealMatrix0.isSingular();
        int[] intArray3 = null;
        int[] intArray10 = new int[] { (byte) -1, (byte) 10, (-1), ' ', (short) -1, '4' };
        double[] doubleArray16 = new double[] { 100L, 0, (short) 1, 1L, 10L };
        double[] doubleArray22 = new double[] { 100L, 0, (short) 1, 1L, 10L };
        double[][] doubleArray23 = new double[][] { doubleArray16, doubleArray22 };
        try {
            array2DRowRealMatrix0.copySubMatrix(intArray3, intArray10, doubleArray23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        double[] doubleArray8 = new double[] {};
        double[][] doubleArray9 = new double[][] { doubleArray8 };
        double[][] doubleArray10 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray9);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException11 = new org.apache.commons.math.MaxEvaluationsExceededException(10, "", (java.lang.Object[]) doubleArray9);
        boolean boolean12 = blockRealMatrix5.equals((java.lang.Object) "");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int15 = array2DRowRealMatrix14.getColumnDimension();
        double double16 = array2DRowRealMatrix14.getFrobeniusNorm();
        try {
            blockRealMatrix5.setColumnMatrix(0, (org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.InvalidMatrixException; message: dimensions mismatch: got 0x0 but expected 1x1");
        } catch (org.apache.commons.math.linear.InvalidMatrixException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double9 = blockRealMatrix8.getFrobeniusNorm();
        double[] doubleArray11 = blockRealMatrix8.getRow(10);
        double[][] doubleArray12 = blockRealMatrix8.getData();
        org.apache.commons.math.linear.RealVector realVector14 = blockRealMatrix8.getRowVector((int) (short) 0);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix2.multiply((org.apache.commons.math.linear.RealMatrix) blockRealMatrix8);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector14);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        double[] doubleArray6 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable7 = null;
        double[] doubleArray8 = new double[] {};
        double[][] doubleArray9 = new double[][] { doubleArray8 };
        double[][] doubleArray10 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray9);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException11 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6, localizable7, (java.lang.Object[]) doubleArray9);
        double[][] doubleArray12 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray9);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray9);
        int int14 = maxIterationsExceededException13.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable15 = maxIterationsExceededException13.getLocalizablePattern();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray18 = functionEvaluationException17.getSuppressed();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException19 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a', localizable15, (java.lang.Object[]) throwableArray18);
        org.apache.commons.math.exception.Localizable localizable20 = null;
        double[][] doubleArray24 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException25 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray24);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException26 = new org.apache.commons.math.linear.MatrixIndexException(localizable20, (java.lang.Object[]) doubleArray24);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException27 = new org.apache.commons.math.linear.InvalidMatrixException(localizable15, (java.lang.Object[]) doubleArray24);
        java.lang.Throwable throwable30 = null;
        org.apache.commons.math.exception.Localizable localizable31 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException33 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray34 = functionEvaluationException33.getSuppressed();
        org.apache.commons.math.MathRuntimeException mathRuntimeException35 = new org.apache.commons.math.MathRuntimeException(throwable30, localizable31, (java.lang.Object[]) throwableArray34);
        java.text.ParseException parseException36 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) throwableArray34);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException37 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable15, (java.lang.Object[]) throwableArray34);
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException();
        double[] doubleArray43 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable44 = null;
        double[] doubleArray45 = new double[] {};
        double[][] doubleArray46 = new double[][] { doubleArray45 };
        double[][] doubleArray47 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray46);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException48 = new org.apache.commons.math.FunctionEvaluationException(doubleArray43, localizable44, (java.lang.Object[]) doubleArray46);
        double[][] doubleArray49 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray46);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException50 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray46);
        int int51 = maxIterationsExceededException50.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable52 = maxIterationsExceededException50.getLocalizablePattern();
        double[] doubleArray58 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable59 = null;
        double[] doubleArray60 = new double[] {};
        double[][] doubleArray61 = new double[][] { doubleArray60 };
        double[][] doubleArray62 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray61);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException63 = new org.apache.commons.math.FunctionEvaluationException(doubleArray58, localizable59, (java.lang.Object[]) doubleArray61);
        double[][] doubleArray64 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray61);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException65 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray61);
        int int66 = maxIterationsExceededException65.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable67 = maxIterationsExceededException65.getLocalizablePattern();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException69 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray70 = functionEvaluationException69.getSuppressed();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException71 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a', localizable67, (java.lang.Object[]) throwableArray70);
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException38, localizable52, (java.lang.Object[]) throwableArray70);
        java.lang.Object[] objArray73 = null;
        java.lang.NullPointerException nullPointerException74 = org.apache.commons.math.MathRuntimeException.createNullPointerException(localizable52, objArray73);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix77 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double78 = blockRealMatrix77.getFrobeniusNorm();
        double[] doubleArray80 = blockRealMatrix77.getRow(10);
        double[][] doubleArray81 = blockRealMatrix77.getData();
        java.util.NoSuchElementException noSuchElementException82 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException(localizable52, (java.lang.Object[]) doubleArray81);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException83 = new org.apache.commons.math.FunctionEvaluationException((double) (-1L), localizable15, (java.lang.Object[]) doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertNotNull(localizable15);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(nullPointerException25);
        org.junit.Assert.assertNotNull(throwableArray34);
        org.junit.Assert.assertNotNull(parseException36);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 52 + "'", int51 == 52);
        org.junit.Assert.assertNotNull(localizable52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 52 + "'", int66 == 52);
        org.junit.Assert.assertNotNull(localizable67);
        org.junit.Assert.assertNotNull(throwableArray70);
        org.junit.Assert.assertNotNull(nullPointerException74);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(noSuchElementException82);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        double[] doubleArray5 = new double[] { (-1.0d), (byte) 0, 0.0d };
        double[] doubleArray10 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable11 = null;
        double[] doubleArray12 = new double[] {};
        double[][] doubleArray13 = new double[][] { doubleArray12 };
        double[][] doubleArray14 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray13);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException(doubleArray10, localizable11, (java.lang.Object[]) doubleArray13);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException16 = new org.apache.commons.math.linear.MatrixIndexException("org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) doubleArray13);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException(doubleArray5, "", (java.lang.Object[]) doubleArray13);
        org.apache.commons.math.linear.RealMatrix realMatrix18 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix19 = array2DRowRealMatrix0.multiply(realMatrix18);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix18);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math.MathRuntimeException mathRuntimeException2 = new org.apache.commons.math.MathRuntimeException(throwable1);
        java.lang.String str3 = mathRuntimeException2.getPattern();
        org.apache.commons.math.exception.Localizable localizable4 = mathRuntimeException2.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable5 = null;
        java.lang.Throwable throwable6 = null;
        org.apache.commons.math.exception.Localizable localizable7 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray10 = functionEvaluationException9.getSuppressed();
        org.apache.commons.math.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.MathRuntimeException(throwable6, localizable7, (java.lang.Object[]) throwableArray10);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException(localizable5, (java.lang.Object[]) throwableArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException13 = new org.apache.commons.math.FunctionEvaluationException(100.0d, localizable4, (java.lang.Object[]) throwableArray10);
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException();
        double[] doubleArray20 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable21 = null;
        double[] doubleArray22 = new double[] {};
        double[][] doubleArray23 = new double[][] { doubleArray22 };
        double[][] doubleArray24 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray23);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException(doubleArray20, localizable21, (java.lang.Object[]) doubleArray23);
        double[][] doubleArray26 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray23);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray23);
        int int28 = maxIterationsExceededException27.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable29 = maxIterationsExceededException27.getLocalizablePattern();
        double[] doubleArray35 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable36 = null;
        double[] doubleArray37 = new double[] {};
        double[][] doubleArray38 = new double[][] { doubleArray37 };
        double[][] doubleArray39 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray38);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException(doubleArray35, localizable36, (java.lang.Object[]) doubleArray38);
        double[][] doubleArray41 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray38);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException42 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray38);
        int int43 = maxIterationsExceededException42.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable44 = maxIterationsExceededException42.getLocalizablePattern();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException46 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray47 = functionEvaluationException46.getSuppressed();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException48 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a', localizable44, (java.lang.Object[]) throwableArray47);
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException15, localizable29, (java.lang.Object[]) throwableArray47);
        double[] doubleArray54 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable55 = null;
        double[] doubleArray56 = new double[] {};
        double[][] doubleArray57 = new double[][] { doubleArray56 };
        double[][] doubleArray58 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray57);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException59 = new org.apache.commons.math.FunctionEvaluationException(doubleArray54, localizable55, (java.lang.Object[]) doubleArray57);
        double[][] doubleArray60 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray57);
        java.lang.NullPointerException nullPointerException61 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray60);
        org.apache.commons.math.MathRuntimeException mathRuntimeException62 = new org.apache.commons.math.MathRuntimeException("", (java.lang.Object[]) doubleArray60);
        java.lang.IllegalArgumentException illegalArgumentException63 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException(localizable29, (java.lang.Object[]) doubleArray60);
        java.util.NoSuchElementException noSuchElementException64 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("{0}", (java.lang.Object[]) doubleArray60);
        java.util.ConcurrentModificationException concurrentModificationException65 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException(localizable4, (java.lang.Object[]) doubleArray60);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{0}" + "'", str3.equals("{0}"));
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable4.equals(org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 52 + "'", int28 == 52);
        org.junit.Assert.assertNotNull(localizable29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 52 + "'", int43 == 52);
        org.junit.Assert.assertNotNull(localizable44);
        org.junit.Assert.assertNotNull(throwableArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(nullPointerException61);
        org.junit.Assert.assertNotNull(illegalArgumentException63);
        org.junit.Assert.assertNotNull(noSuchElementException64);
        org.junit.Assert.assertNotNull(concurrentModificationException65);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        boolean boolean2 = array2DRowRealMatrix0.isSingular();
        org.apache.commons.math.linear.RealMatrix realMatrix5 = array2DRowRealMatrix0.createMatrix((int) '#', 1);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int7 = array2DRowRealMatrix6.getColumnDimension();
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = array2DRowRealMatrix0.multiply(array2DRowRealMatrix6);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        try {
            blockRealMatrix2.luDecompose();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 35x10 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        double double6 = blockRealMatrix5.getNorm();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException();
        double[] doubleArray7 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable8 = null;
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(doubleArray7, localizable8, (java.lang.Object[]) doubleArray10);
        double[][] doubleArray13 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray10);
        int int15 = maxIterationsExceededException14.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable16 = maxIterationsExceededException14.getLocalizablePattern();
        double[] doubleArray22 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable23 = null;
        double[] doubleArray24 = new double[] {};
        double[][] doubleArray25 = new double[][] { doubleArray24 };
        double[][] doubleArray26 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray25);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException27 = new org.apache.commons.math.FunctionEvaluationException(doubleArray22, localizable23, (java.lang.Object[]) doubleArray25);
        double[][] doubleArray28 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray25);
        int int30 = maxIterationsExceededException29.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable31 = maxIterationsExceededException29.getLocalizablePattern();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException33 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray34 = functionEvaluationException33.getSuppressed();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException35 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a', localizable31, (java.lang.Object[]) throwableArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException2, localizable16, (java.lang.Object[]) throwableArray34);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException37 = new org.apache.commons.math.MaxEvaluationsExceededException(0, "", (java.lang.Object[]) throwableArray34);
        java.lang.Object[] objArray40 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException41 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxEvaluationsExceededException37, (-1.0d), "", objArray40);
        double[][] doubleArray46 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException47 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray46);
        java.lang.Throwable[] throwableArray48 = nullPointerException47.getSuppressed();
        org.apache.commons.math.exception.Localizable localizable49 = null;
        double[] doubleArray52 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable53 = null;
        double[] doubleArray54 = new double[] {};
        double[][] doubleArray55 = new double[][] { doubleArray54 };
        double[][] doubleArray56 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray55);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException57 = new org.apache.commons.math.FunctionEvaluationException(doubleArray52, localizable53, (java.lang.Object[]) doubleArray55);
        double[][] doubleArray58 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray55);
        org.apache.commons.math.MathRuntimeException mathRuntimeException59 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) nullPointerException47, localizable49, (java.lang.Object[]) doubleArray58);
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException((java.lang.Throwable) maxEvaluationsExceededException37, "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) doubleArray58);
        try {
            double[][] doubleArray61 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray58);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 52 + "'", int15 == 52);
        org.junit.Assert.assertNotNull(localizable16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 52 + "'", int30 == 52);
        org.junit.Assert.assertNotNull(localizable31);
        org.junit.Assert.assertNotNull(throwableArray34);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(nullPointerException47);
        org.junit.Assert.assertNotNull(throwableArray48);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        boolean boolean2 = array2DRowRealMatrix0.isSingular();
        double[] doubleArray10 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException11 = new org.apache.commons.math.FunctionEvaluationException(doubleArray10);
        double[][] doubleArray16 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException17 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray16);
        java.lang.Throwable[] throwableArray18 = nullPointerException17.getSuppressed();
        double[] doubleArray25 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException26 = new org.apache.commons.math.FunctionEvaluationException(doubleArray25);
        org.apache.commons.math.linear.RealMatrix realMatrix27 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray25);
        double[] doubleArray34 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException35 = new org.apache.commons.math.FunctionEvaluationException(doubleArray34);
        java.io.IOException iOException36 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) functionEvaluationException35);
        double[] doubleArray40 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable41 = null;
        double[] doubleArray42 = new double[] {};
        double[][] doubleArray43 = new double[][] { doubleArray42 };
        double[][] doubleArray44 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray43);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException45 = new org.apache.commons.math.FunctionEvaluationException(doubleArray40, localizable41, (java.lang.Object[]) doubleArray43);
        double[][] doubleArray46 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray43);
        java.lang.NullPointerException nullPointerException47 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray46);
        java.lang.Object[] objArray48 = new java.lang.Object[] { nullPointerException17, realMatrix27, functionEvaluationException35, "" };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException49 = new org.apache.commons.math.FunctionEvaluationException(doubleArray10, "hi!", objArray48);
        org.apache.commons.math.linear.BigMatrix bigMatrix50 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(doubleArray10);
        try {
            array2DRowRealMatrix0.setColumn((int) '#', doubleArray10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 35 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(nullPointerException17);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(iOException36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(nullPointerException47);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(bigMatrix50);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        double[] doubleArray4 = new double[] { (-1.0d), (byte) 0, 0.0d };
        double[] doubleArray9 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable10 = null;
        double[] doubleArray11 = new double[] {};
        double[][] doubleArray12 = new double[][] { doubleArray11 };
        double[][] doubleArray13 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray12);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException14 = new org.apache.commons.math.FunctionEvaluationException(doubleArray9, localizable10, (java.lang.Object[]) doubleArray12);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException15 = new org.apache.commons.math.linear.MatrixIndexException("org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) doubleArray12);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException(doubleArray4, "", (java.lang.Object[]) doubleArray12);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException17 = new org.apache.commons.math.linear.MatrixIndexException("", (java.lang.Object[]) doubleArray12);
        org.apache.commons.math.exception.Localizable localizable18 = matrixIndexException17.getLocalizablePattern();
        double[][] doubleArray21 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 100, (int) (short) 100);
        java.lang.NullPointerException nullPointerException22 = org.apache.commons.math.MathRuntimeException.createNullPointerException(localizable18, (java.lang.Object[]) doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(localizable18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(nullPointerException22);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        double[] doubleArray8 = new double[] {};
        double[][] doubleArray9 = new double[][] { doubleArray8 };
        double[][] doubleArray10 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray9);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException11 = new org.apache.commons.math.MaxEvaluationsExceededException(10, "", (java.lang.Object[]) doubleArray9);
        boolean boolean12 = blockRealMatrix5.equals((java.lang.Object) "");
        try {
            blockRealMatrix5.setEntry((int) (short) -1, 52, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (-1, 52) in a 1x10 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException4 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 0);
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[][] doubleArray9 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException10 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray9);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException11 = new org.apache.commons.math.linear.MatrixIndexException(localizable5, (java.lang.Object[]) doubleArray9);
        double[] doubleArray18 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException19 = new org.apache.commons.math.FunctionEvaluationException(doubleArray18);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray18);
        double[] doubleArray27 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException28 = new org.apache.commons.math.FunctionEvaluationException(doubleArray27);
        org.apache.commons.math.exception.Localizable localizable29 = null;
        double[] doubleArray32 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable33 = null;
        double[] doubleArray34 = new double[] {};
        double[][] doubleArray35 = new double[][] { doubleArray34 };
        double[][] doubleArray36 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray35);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException37 = new org.apache.commons.math.FunctionEvaluationException(doubleArray32, localizable33, (java.lang.Object[]) doubleArray35);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException38 = new org.apache.commons.math.FunctionEvaluationException(doubleArray27, localizable29, (java.lang.Object[]) doubleArray35);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair40 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray18, doubleArray27, true);
        org.apache.commons.math.exception.Localizable localizable42 = null;
        double[][] doubleArray46 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException47 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray46);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException48 = new org.apache.commons.math.linear.MatrixIndexException(localizable42, (java.lang.Object[]) doubleArray46);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException49 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) matrixIndexException11, doubleArray18, "{0}", (java.lang.Object[]) doubleArray46);
        org.apache.commons.math.exception.Localizable localizable50 = null;
        double[] doubleArray57 = new double[] {};
        double[][] doubleArray58 = new double[][] { doubleArray57 };
        double[][] doubleArray59 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray58);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException60 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray59);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException61 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray59);
        double[] doubleArray69 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException70 = new org.apache.commons.math.FunctionEvaluationException(doubleArray69);
        org.apache.commons.math.exception.Localizable localizable71 = null;
        double[] doubleArray74 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable75 = null;
        double[] doubleArray76 = new double[] {};
        double[][] doubleArray77 = new double[][] { doubleArray76 };
        double[][] doubleArray78 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray77);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException79 = new org.apache.commons.math.FunctionEvaluationException(doubleArray74, localizable75, (java.lang.Object[]) doubleArray77);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException80 = new org.apache.commons.math.FunctionEvaluationException(doubleArray69, localizable71, (java.lang.Object[]) doubleArray77);
        double[][] doubleArray81 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray77);
        org.apache.commons.math.MathException mathException82 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException61, "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) doubleArray77);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException83 = new org.apache.commons.math.MaxIterationsExceededException(1, "hi!", (java.lang.Object[]) doubleArray77);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException84 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxEvaluationsExceededException4, doubleArray18, localizable50, (java.lang.Object[]) doubleArray77);
        java.text.ParseException parseException85 = org.apache.commons.math.MathRuntimeException.createParseException((int) ' ', "evaluation failed for argument = {0}", (java.lang.Object[]) doubleArray77);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException86 = new org.apache.commons.math.linear.MatrixIndexException("", (java.lang.Object[]) doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(nullPointerException10);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(nullPointerException47);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(parseException85);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException();
        double[] doubleArray8 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable9 = null;
        double[] doubleArray10 = new double[] {};
        double[][] doubleArray11 = new double[][] { doubleArray10 };
        double[][] doubleArray12 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray11);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException13 = new org.apache.commons.math.FunctionEvaluationException(doubleArray8, localizable9, (java.lang.Object[]) doubleArray11);
        double[][] doubleArray14 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray11);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray11);
        int int16 = maxIterationsExceededException15.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable17 = maxIterationsExceededException15.getLocalizablePattern();
        double[] doubleArray23 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable24 = null;
        double[] doubleArray25 = new double[] {};
        double[][] doubleArray26 = new double[][] { doubleArray25 };
        double[][] doubleArray27 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray26);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException28 = new org.apache.commons.math.FunctionEvaluationException(doubleArray23, localizable24, (java.lang.Object[]) doubleArray26);
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray26);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray26);
        int int31 = maxIterationsExceededException30.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable32 = maxIterationsExceededException30.getLocalizablePattern();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException34 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray35 = functionEvaluationException34.getSuppressed();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException36 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a', localizable32, (java.lang.Object[]) throwableArray35);
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException3, localizable17, (java.lang.Object[]) throwableArray35);
        org.apache.commons.math.exception.Localizable localizable38 = null;
        java.lang.Throwable throwable39 = null;
        org.apache.commons.math.exception.Localizable localizable40 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException42 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray43 = functionEvaluationException42.getSuppressed();
        org.apache.commons.math.MathRuntimeException mathRuntimeException44 = new org.apache.commons.math.MathRuntimeException(throwable39, localizable40, (java.lang.Object[]) throwableArray43);
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException(localizable38, (java.lang.Object[]) throwableArray43);
        java.text.ParseException parseException46 = org.apache.commons.math.MathRuntimeException.createParseException((int) ' ', localizable17, (java.lang.Object[]) throwableArray43);
        double[] doubleArray52 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable53 = null;
        double[] doubleArray54 = new double[] {};
        double[][] doubleArray55 = new double[][] { doubleArray54 };
        double[][] doubleArray56 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray55);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException57 = new org.apache.commons.math.FunctionEvaluationException(doubleArray52, localizable53, (java.lang.Object[]) doubleArray55);
        double[][] doubleArray58 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray55);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException59 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray55);
        int int60 = maxIterationsExceededException59.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable61 = maxIterationsExceededException59.getLocalizablePattern();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException63 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray64 = functionEvaluationException63.getSuppressed();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException65 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a', localizable61, (java.lang.Object[]) throwableArray64);
        java.util.NoSuchElementException noSuchElementException66 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException(localizable17, (java.lang.Object[]) throwableArray64);
        java.text.ParseException parseException67 = org.apache.commons.math.MathRuntimeException.createParseException(0, "{0}", (java.lang.Object[]) throwableArray64);
        java.io.IOException iOException68 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) parseException67);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 52 + "'", int16 == 52);
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 52 + "'", int31 == 52);
        org.junit.Assert.assertNotNull(localizable32);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertNotNull(throwableArray43);
        org.junit.Assert.assertNotNull(parseException46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 52 + "'", int60 == 52);
        org.junit.Assert.assertNotNull(localizable61);
        org.junit.Assert.assertNotNull(throwableArray64);
        org.junit.Assert.assertNotNull(noSuchElementException66);
        org.junit.Assert.assertNotNull(parseException67);
        org.junit.Assert.assertNotNull(iOException68);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix7.copy();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix8.copy();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix8.scalarAdd(0.0d);
        double[] doubleArray18 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException19 = new org.apache.commons.math.FunctionEvaluationException(doubleArray18);
        try {
            double[] doubleArray20 = blockRealMatrix11.solve(doubleArray18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 35x10 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        java.lang.Throwable throwable0 = null;
        double[] doubleArray5 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable6 = null;
        double[] doubleArray7 = new double[] {};
        double[][] doubleArray8 = new double[][] { doubleArray7 };
        double[][] doubleArray9 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray8);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException(doubleArray5, localizable6, (java.lang.Object[]) doubleArray8);
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray8);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(throwable0, 0.0d, "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) doubleArray11);
        double[] doubleArray17 = new double[] {};
        double[][] doubleArray18 = new double[][] { doubleArray17 };
        double[][] doubleArray19 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray18);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException20 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray19);
        double[] doubleArray24 = new double[] {};
        double[][] doubleArray25 = new double[][] { doubleArray24 };
        double[][] doubleArray26 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray25);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException27 = new org.apache.commons.math.MaxEvaluationsExceededException(10, "", (java.lang.Object[]) doubleArray25);
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException((java.lang.Throwable) maxEvaluationsExceededException20, "hi!", (java.lang.Object[]) doubleArray25);
        org.apache.commons.math.optimization.OptimizationException optimizationException29 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) mathException28);
        org.apache.commons.math.exception.Localizable localizable30 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { 1L };
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException28, localizable30, objArray32);
        java.lang.IllegalStateException illegalStateException34 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("hi!", objArray32);
        org.apache.commons.math.MathRuntimeException mathRuntimeException35 = new org.apache.commons.math.MathRuntimeException(throwable0, "evaluation failed for argument = {0}", objArray32);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(illegalStateException34);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        double[] doubleArray5 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable6 = null;
        double[] doubleArray7 = new double[] {};
        double[][] doubleArray8 = new double[][] { doubleArray7 };
        double[][] doubleArray9 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray8);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException(doubleArray5, localizable6, (java.lang.Object[]) doubleArray8);
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray8);
        int int13 = maxIterationsExceededException12.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable14 = maxIterationsExceededException12.getLocalizablePattern();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray17 = functionEvaluationException16.getSuppressed();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException18 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a', localizable14, (java.lang.Object[]) throwableArray17);
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker19 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        double[] doubleArray23 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable24 = null;
        double[] doubleArray25 = new double[] {};
        double[][] doubleArray26 = new double[][] { doubleArray25 };
        double[][] doubleArray27 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray26);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException28 = new org.apache.commons.math.FunctionEvaluationException(doubleArray23, localizable24, (java.lang.Object[]) doubleArray26);
        double[] doubleArray34 = new double[] { 10L, '#', 0, 1.0d, '#' };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair36 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray23, doubleArray34, true);
        double[] doubleArray39 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable40 = null;
        double[] doubleArray41 = new double[] {};
        double[][] doubleArray42 = new double[][] { doubleArray41 };
        double[][] doubleArray43 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray42);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException(doubleArray39, localizable40, (java.lang.Object[]) doubleArray42);
        double[] doubleArray50 = new double[] { 10L, '#', 0, 1.0d, '#' };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair52 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray39, doubleArray50, true);
        boolean boolean53 = simpleVectorialValueChecker19.converged(10, vectorialPointValuePair36, vectorialPointValuePair52);
        double[] doubleArray54 = vectorialPointValuePair36.getPointRef();
        java.lang.Throwable throwable55 = null;
        org.apache.commons.math.MathRuntimeException mathRuntimeException56 = new org.apache.commons.math.MathRuntimeException(throwable55);
        double[] doubleArray62 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable63 = null;
        double[] doubleArray64 = new double[] {};
        double[][] doubleArray65 = new double[][] { doubleArray64 };
        double[][] doubleArray66 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray65);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException67 = new org.apache.commons.math.FunctionEvaluationException(doubleArray62, localizable63, (java.lang.Object[]) doubleArray65);
        double[][] doubleArray68 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray65);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException69 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray65);
        int int70 = maxIterationsExceededException69.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable71 = maxIterationsExceededException69.getLocalizablePattern();
        double[] doubleArray74 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable75 = null;
        double[] doubleArray76 = new double[] {};
        double[][] doubleArray77 = new double[][] { doubleArray76 };
        double[][] doubleArray78 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray77);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException79 = new org.apache.commons.math.FunctionEvaluationException(doubleArray74, localizable75, (java.lang.Object[]) doubleArray77);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException80 = new org.apache.commons.math.FunctionEvaluationException(throwable55, (double) (short) 100, localizable71, (java.lang.Object[]) doubleArray77);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException82 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray83 = functionEvaluationException82.getSuppressed();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException84 = new org.apache.commons.math.FunctionEvaluationException(doubleArray54, localizable71, (java.lang.Object[]) throwableArray83);
        java.lang.IllegalStateException illegalStateException85 = org.apache.commons.math.MathRuntimeException.createIllegalStateException(localizable14, (java.lang.Object[]) throwableArray83);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 52 + "'", int13 == 52);
        org.junit.Assert.assertNotNull(localizable14);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 52 + "'", int70 == 52);
        org.junit.Assert.assertNotNull(localizable71);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(throwableArray83);
        org.junit.Assert.assertNotNull(illegalStateException85);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        double[] doubleArray6 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException7 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6);
        org.apache.commons.math.linear.BigMatrix bigMatrix8 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(doubleArray6);
        double[] doubleArray11 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable12 = null;
        double[] doubleArray13 = new double[] {};
        double[][] doubleArray14 = new double[][] { doubleArray13 };
        double[][] doubleArray15 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray14);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException(doubleArray11, localizable12, (java.lang.Object[]) doubleArray14);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair17 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray6, doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(bigMatrix8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double[][] doubleArray2 = array2DRowRealMatrix0.getDataRef();
        org.apache.commons.math.exception.Localizable localizable3 = null;
        double[][] doubleArray7 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException8 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray7);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException9 = new org.apache.commons.math.linear.MatrixIndexException(localizable3, (java.lang.Object[]) doubleArray7);
        double[] doubleArray16 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException(doubleArray16);
        org.apache.commons.math.linear.RealMatrix realMatrix18 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray16);
        double[] doubleArray25 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException26 = new org.apache.commons.math.FunctionEvaluationException(doubleArray25);
        org.apache.commons.math.exception.Localizable localizable27 = null;
        double[] doubleArray30 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable31 = null;
        double[] doubleArray32 = new double[] {};
        double[][] doubleArray33 = new double[][] { doubleArray32 };
        double[][] doubleArray34 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray33);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException35 = new org.apache.commons.math.FunctionEvaluationException(doubleArray30, localizable31, (java.lang.Object[]) doubleArray33);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException(doubleArray25, localizable27, (java.lang.Object[]) doubleArray33);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair38 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray16, doubleArray25, true);
        org.apache.commons.math.exception.Localizable localizable40 = null;
        double[][] doubleArray44 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException45 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray44);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException46 = new org.apache.commons.math.linear.MatrixIndexException(localizable40, (java.lang.Object[]) doubleArray44);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException47 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) matrixIndexException9, doubleArray16, "{0}", (java.lang.Object[]) doubleArray44);
        org.apache.commons.math.linear.BigMatrix bigMatrix48 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray16);
        try {
            double[] doubleArray49 = array2DRowRealMatrix0.operate(doubleArray16);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(nullPointerException8);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(nullPointerException45);
        org.junit.Assert.assertNotNull(bigMatrix48);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        double[][] doubleArray0 = null;
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix1 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        double double6 = blockRealMatrix5.getNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix8 = blockRealMatrix5.scalarAdd((double) (-1L));
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean10 = array2DRowRealMatrix9.isSquare();
        boolean boolean11 = array2DRowRealMatrix9.isSingular();
        try {
            org.apache.commons.math.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix5, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix9);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double14 = blockRealMatrix13.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix10.subtract(blockRealMatrix13);
        boolean boolean17 = blockRealMatrix15.equals((java.lang.Object) 100.0d);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) blockRealMatrix15);
        double[] doubleArray22 = new double[] { (byte) -1, ' ' };
        try {
            blockRealMatrix18.setRow((-1), doubleArray22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index -1 out of allowed range [0, 34]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math.exception.Localizable localizable3 = null;
        double[][] doubleArray7 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException8 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray7);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException9 = new org.apache.commons.math.linear.MatrixIndexException(localizable3, (java.lang.Object[]) doubleArray7);
        double[] doubleArray16 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException(doubleArray16);
        org.apache.commons.math.linear.RealMatrix realMatrix18 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray16);
        double[] doubleArray25 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException26 = new org.apache.commons.math.FunctionEvaluationException(doubleArray25);
        org.apache.commons.math.exception.Localizable localizable27 = null;
        double[] doubleArray30 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable31 = null;
        double[] doubleArray32 = new double[] {};
        double[][] doubleArray33 = new double[][] { doubleArray32 };
        double[][] doubleArray34 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray33);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException35 = new org.apache.commons.math.FunctionEvaluationException(doubleArray30, localizable31, (java.lang.Object[]) doubleArray33);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException(doubleArray25, localizable27, (java.lang.Object[]) doubleArray33);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair38 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray16, doubleArray25, true);
        org.apache.commons.math.exception.Localizable localizable40 = null;
        double[][] doubleArray44 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException45 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray44);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException46 = new org.apache.commons.math.linear.MatrixIndexException(localizable40, (java.lang.Object[]) doubleArray44);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException47 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) matrixIndexException9, doubleArray16, "{0}", (java.lang.Object[]) doubleArray44);
        try {
            array2DRowRealMatrix0.setSubMatrix(doubleArray44, 97, (int) (byte) 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalStateException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(nullPointerException8);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(nullPointerException45);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math.MathRuntimeException mathRuntimeException2 = new org.apache.commons.math.MathRuntimeException(throwable1);
        double[] doubleArray8 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable9 = null;
        double[] doubleArray10 = new double[] {};
        double[][] doubleArray11 = new double[][] { doubleArray10 };
        double[][] doubleArray12 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray11);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException13 = new org.apache.commons.math.FunctionEvaluationException(doubleArray8, localizable9, (java.lang.Object[]) doubleArray11);
        double[][] doubleArray14 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray11);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray11);
        int int16 = maxIterationsExceededException15.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable17 = maxIterationsExceededException15.getLocalizablePattern();
        double[] doubleArray20 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable21 = null;
        double[] doubleArray22 = new double[] {};
        double[][] doubleArray23 = new double[][] { doubleArray22 };
        double[][] doubleArray24 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray23);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException(doubleArray20, localizable21, (java.lang.Object[]) doubleArray23);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException26 = new org.apache.commons.math.FunctionEvaluationException(throwable1, (double) (short) 100, localizable17, (java.lang.Object[]) doubleArray23);
        java.lang.NullPointerException nullPointerException27 = org.apache.commons.math.MathRuntimeException.createNullPointerException("evaluation failed for argument = {0}", (java.lang.Object[]) doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 52 + "'", int16 == 52);
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(nullPointerException27);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.lang.String[] strArray3 = new java.lang.String[] { "{0}", "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", "maximal number of iterations ({0}) exceeded" };
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix4 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(strArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        double[] doubleArray6 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable7 = null;
        double[] doubleArray8 = new double[] {};
        double[][] doubleArray9 = new double[][] { doubleArray8 };
        double[][] doubleArray10 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray9);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException11 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6, localizable7, (java.lang.Object[]) doubleArray9);
        double[][] doubleArray12 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray9);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray9);
        int int14 = maxIterationsExceededException13.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable15 = maxIterationsExceededException13.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable16 = null;
        double[][] doubleArray20 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException21 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray20);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException22 = new org.apache.commons.math.linear.MatrixIndexException(localizable16, (java.lang.Object[]) doubleArray20);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', localizable15, (java.lang.Object[]) doubleArray20);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException24 = new org.apache.commons.math.linear.MatrixIndexException("{0}", (java.lang.Object[]) doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertNotNull(localizable15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(nullPointerException21);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        double[] doubleArray12 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException13 = new org.apache.commons.math.FunctionEvaluationException(doubleArray12);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray12);
        try {
            org.apache.commons.math.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix5, (org.apache.commons.math.linear.AnyMatrix) realMatrix14);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realMatrix14);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        double[] doubleArray3 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable4 = null;
        double[] doubleArray5 = new double[] {};
        double[][] doubleArray6 = new double[][] { doubleArray5 };
        double[][] doubleArray7 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException8 = new org.apache.commons.math.FunctionEvaluationException(doubleArray3, localizable4, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException9 = new org.apache.commons.math.linear.MatrixIndexException("org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) doubleArray6);
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix7.copy();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix8.copy();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix8.scalarAdd(0.0d);
        int int12 = blockRealMatrix8.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable14 = null;
        double[][] doubleArray18 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException19 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray18);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException20 = new org.apache.commons.math.linear.MatrixIndexException(localizable14, (java.lang.Object[]) doubleArray18);
        double[] doubleArray27 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException28 = new org.apache.commons.math.FunctionEvaluationException(doubleArray27);
        org.apache.commons.math.linear.RealMatrix realMatrix29 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray27);
        double[] doubleArray36 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException37 = new org.apache.commons.math.FunctionEvaluationException(doubleArray36);
        org.apache.commons.math.exception.Localizable localizable38 = null;
        double[] doubleArray41 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable42 = null;
        double[] doubleArray43 = new double[] {};
        double[][] doubleArray44 = new double[][] { doubleArray43 };
        double[][] doubleArray45 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray44);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException46 = new org.apache.commons.math.FunctionEvaluationException(doubleArray41, localizable42, (java.lang.Object[]) doubleArray44);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException47 = new org.apache.commons.math.FunctionEvaluationException(doubleArray36, localizable38, (java.lang.Object[]) doubleArray44);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair49 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray27, doubleArray36, true);
        org.apache.commons.math.exception.Localizable localizable51 = null;
        double[][] doubleArray55 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException56 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray55);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException57 = new org.apache.commons.math.linear.MatrixIndexException(localizable51, (java.lang.Object[]) doubleArray55);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException58 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) matrixIndexException20, doubleArray27, "{0}", (java.lang.Object[]) doubleArray55);
        org.apache.commons.math.linear.BigMatrix bigMatrix59 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray27);
        try {
            blockRealMatrix8.setColumn((int) (byte) 0, doubleArray27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.InvalidMatrixException; message: dimensions mismatch: got 6x1 but expected 35x1");
        } catch (org.apache.commons.math.linear.InvalidMatrixException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(nullPointerException19);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(nullPointerException56);
        org.junit.Assert.assertNotNull(bigMatrix59);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        boolean boolean3 = array2DRowRealMatrix0.isSquare();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double7 = blockRealMatrix6.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix6.getRowMatrix(0);
        double double10 = blockRealMatrix9.getNorm();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix11 = array2DRowRealMatrix0.add((org.apache.commons.math.linear.RealMatrix) blockRealMatrix9);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        int[] intArray9 = new int[] { 36, '4', '#' };
        int[] intArray13 = new int[] { (short) 1, (byte) -1, 52 };
        double[] doubleArray19 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable20 = null;
        double[] doubleArray21 = new double[] {};
        double[][] doubleArray22 = new double[][] { doubleArray21 };
        double[][] doubleArray23 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray22);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException24 = new org.apache.commons.math.FunctionEvaluationException(doubleArray19, localizable20, (java.lang.Object[]) doubleArray22);
        double[][] doubleArray25 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray22);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray22);
        int int27 = maxIterationsExceededException26.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable28 = maxIterationsExceededException26.getLocalizablePattern();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException30 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray31 = functionEvaluationException30.getSuppressed();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException32 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a', localizable28, (java.lang.Object[]) throwableArray31);
        org.apache.commons.math.exception.Localizable localizable33 = null;
        double[][] doubleArray37 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException38 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray37);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException39 = new org.apache.commons.math.linear.MatrixIndexException(localizable33, (java.lang.Object[]) doubleArray37);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException40 = new org.apache.commons.math.linear.InvalidMatrixException(localizable28, (java.lang.Object[]) doubleArray37);
        try {
            blockRealMatrix2.copySubMatrix(intArray9, intArray13, doubleArray37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 36 out of allowed range [0, 34]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 52 + "'", int27 == 52);
        org.junit.Assert.assertNotNull(localizable28);
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(nullPointerException38);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        double[] doubleArray6 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException7 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray6);
        double[] doubleArray15 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException(doubleArray15);
        org.apache.commons.math.exception.Localizable localizable17 = null;
        double[] doubleArray20 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable21 = null;
        double[] doubleArray22 = new double[] {};
        double[][] doubleArray23 = new double[][] { doubleArray22 };
        double[][] doubleArray24 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray23);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException(doubleArray20, localizable21, (java.lang.Object[]) doubleArray23);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException26 = new org.apache.commons.math.FunctionEvaluationException(doubleArray15, localizable17, (java.lang.Object[]) doubleArray23);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair28 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray6, doubleArray15, true);
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker29 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        double[] doubleArray33 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[] doubleArray35 = new double[] {};
        double[][] doubleArray36 = new double[][] { doubleArray35 };
        double[][] doubleArray37 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray36);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException38 = new org.apache.commons.math.FunctionEvaluationException(doubleArray33, localizable34, (java.lang.Object[]) doubleArray36);
        double[] doubleArray44 = new double[] { 10L, '#', 0, 1.0d, '#' };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray33, doubleArray44, true);
        double[] doubleArray49 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable50 = null;
        double[] doubleArray51 = new double[] {};
        double[][] doubleArray52 = new double[][] { doubleArray51 };
        double[][] doubleArray53 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray52);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException54 = new org.apache.commons.math.FunctionEvaluationException(doubleArray49, localizable50, (java.lang.Object[]) doubleArray52);
        double[] doubleArray60 = new double[] { 10L, '#', 0, 1.0d, '#' };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair62 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray49, doubleArray60, true);
        boolean boolean63 = simpleVectorialValueChecker29.converged(10, vectorialPointValuePair46, vectorialPointValuePair62);
        double[] doubleArray64 = vectorialPointValuePair46.getPointRef();
        org.apache.commons.math.linear.RealVector realVector65 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray64);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair66 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray6, doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(realVector65);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        int int4 = blockRealMatrix2.getColumnDimension();
        org.apache.commons.math.linear.RealVector realVector6 = blockRealMatrix2.getColumnVector(0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double14 = blockRealMatrix13.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix10.subtract(blockRealMatrix13);
        boolean boolean17 = blockRealMatrix15.equals((java.lang.Object) 100.0d);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double22 = blockRealMatrix21.getFrobeniusNorm();
        int int23 = blockRealMatrix21.getColumnDimension();
        org.apache.commons.math.linear.RealVector realVector25 = blockRealMatrix21.getColumnVector(0);
        blockRealMatrix15.setColumnVector(0, realVector25);
        try {
            blockRealMatrix2.setRowVector(0, realVector25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.InvalidMatrixException; message: dimensions mismatch: got 1x35 but expected 1x10");
        } catch (org.apache.commons.math.linear.InvalidMatrixException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
        org.junit.Assert.assertNotNull(realVector25);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double[][] doubleArray2 = array2DRowRealMatrix0.getData();
        boolean boolean3 = array2DRowRealMatrix0.isSquare();
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl5 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix0, (double) 1.0f);
        int int6 = array2DRowRealMatrix0.getRowDimension();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor7 = null;
        try {
            double double12 = array2DRowRealMatrix0.walkInOptimizedOrder(realMatrixChangingVisitor7, 0, (int) (byte) 1, 100, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 0 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException1 = new org.apache.commons.math.MaxEvaluationsExceededException((int) ' ');
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException();
        double[] doubleArray6 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable7 = null;
        double[] doubleArray8 = new double[] {};
        double[][] doubleArray9 = new double[][] { doubleArray8 };
        double[][] doubleArray10 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray9);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException11 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6, localizable7, (java.lang.Object[]) doubleArray9);
        double[][] doubleArray12 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray9);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray9);
        int int14 = maxIterationsExceededException13.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable15 = maxIterationsExceededException13.getLocalizablePattern();
        double[] doubleArray21 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable22 = null;
        double[] doubleArray23 = new double[] {};
        double[][] doubleArray24 = new double[][] { doubleArray23 };
        double[][] doubleArray25 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray24);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException26 = new org.apache.commons.math.FunctionEvaluationException(doubleArray21, localizable22, (java.lang.Object[]) doubleArray24);
        double[][] doubleArray27 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray24);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray24);
        int int29 = maxIterationsExceededException28.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable30 = maxIterationsExceededException28.getLocalizablePattern();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException32 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray33 = functionEvaluationException32.getSuppressed();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException34 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a', localizable30, (java.lang.Object[]) throwableArray33);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException1, localizable15, (java.lang.Object[]) throwableArray33);
        org.apache.commons.math.exception.Localizable localizable36 = null;
        java.lang.Throwable throwable37 = null;
        org.apache.commons.math.exception.Localizable localizable38 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray41 = functionEvaluationException40.getSuppressed();
        org.apache.commons.math.MathRuntimeException mathRuntimeException42 = new org.apache.commons.math.MathRuntimeException(throwable37, localizable38, (java.lang.Object[]) throwableArray41);
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException(localizable36, (java.lang.Object[]) throwableArray41);
        java.text.ParseException parseException44 = org.apache.commons.math.MathRuntimeException.createParseException((int) ' ', localizable15, (java.lang.Object[]) throwableArray41);
        double[] doubleArray50 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable51 = null;
        double[] doubleArray52 = new double[] {};
        double[][] doubleArray53 = new double[][] { doubleArray52 };
        double[][] doubleArray54 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray53);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException55 = new org.apache.commons.math.FunctionEvaluationException(doubleArray50, localizable51, (java.lang.Object[]) doubleArray53);
        double[][] doubleArray56 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray53);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException57 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray53);
        int int58 = maxIterationsExceededException57.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable59 = maxIterationsExceededException57.getLocalizablePattern();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException61 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray62 = functionEvaluationException61.getSuppressed();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException63 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a', localizable59, (java.lang.Object[]) throwableArray62);
        java.util.NoSuchElementException noSuchElementException64 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException(localizable15, (java.lang.Object[]) throwableArray62);
        java.lang.Throwable throwable67 = null;
        org.apache.commons.math.MathRuntimeException mathRuntimeException68 = new org.apache.commons.math.MathRuntimeException(throwable67);
        java.lang.String str69 = mathRuntimeException68.getPattern();
        org.apache.commons.math.exception.Localizable localizable70 = mathRuntimeException68.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable71 = null;
        java.lang.Throwable throwable72 = null;
        org.apache.commons.math.exception.Localizable localizable73 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException75 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray76 = functionEvaluationException75.getSuppressed();
        org.apache.commons.math.MathRuntimeException mathRuntimeException77 = new org.apache.commons.math.MathRuntimeException(throwable72, localizable73, (java.lang.Object[]) throwableArray76);
        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException(localizable71, (java.lang.Object[]) throwableArray76);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException79 = new org.apache.commons.math.FunctionEvaluationException(100.0d, localizable70, (java.lang.Object[]) throwableArray76);
        org.apache.commons.math.MathException mathException80 = new org.apache.commons.math.MathException((java.lang.Throwable) noSuchElementException64, "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) throwableArray76);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertNotNull(localizable15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 52 + "'", int29 == 52);
        org.junit.Assert.assertNotNull(localizable30);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertNotNull(throwableArray41);
        org.junit.Assert.assertNotNull(parseException44);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 52 + "'", int58 == 52);
        org.junit.Assert.assertNotNull(localizable59);
        org.junit.Assert.assertNotNull(throwableArray62);
        org.junit.Assert.assertNotNull(noSuchElementException64);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "{0}" + "'", str69.equals("{0}"));
        org.junit.Assert.assertTrue("'" + localizable70 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable70.equals(org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(throwableArray76);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix7.copy();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix8.copy();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor10 = null;
        try {
            double double11 = blockRealMatrix8.walkInColumnOrder(realMatrixPreservingVisitor10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        double[] doubleArray6 = new double[] {};
        double[][] doubleArray7 = new double[][] { doubleArray6 };
        double[][] doubleArray8 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray7);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException9 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray8);
        double[] doubleArray18 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException19 = new org.apache.commons.math.FunctionEvaluationException(doubleArray18);
        org.apache.commons.math.exception.Localizable localizable20 = null;
        double[] doubleArray23 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable24 = null;
        double[] doubleArray25 = new double[] {};
        double[][] doubleArray26 = new double[][] { doubleArray25 };
        double[][] doubleArray27 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray26);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException28 = new org.apache.commons.math.FunctionEvaluationException(doubleArray23, localizable24, (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException(doubleArray18, localizable20, (java.lang.Object[]) doubleArray26);
        double[][] doubleArray30 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray26);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException10, "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) doubleArray26);
        java.lang.NullPointerException nullPointerException32 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException33 = new org.apache.commons.math.linear.InvalidMatrixException("org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) doubleArray26);
        java.lang.Throwable[] throwableArray34 = invalidMatrixException33.getSuppressed();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(nullPointerException32);
        org.junit.Assert.assertNotNull(throwableArray34);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.getRowMatrix((int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 35 out of allowed range [0, 34]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray4 };
        double[][] doubleArray6 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray5);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException7 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray6);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray6);
        double[] doubleArray16 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException(doubleArray16);
        org.apache.commons.math.exception.Localizable localizable18 = null;
        double[] doubleArray21 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable22 = null;
        double[] doubleArray23 = new double[] {};
        double[][] doubleArray24 = new double[][] { doubleArray23 };
        double[][] doubleArray25 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray24);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException26 = new org.apache.commons.math.FunctionEvaluationException(doubleArray21, localizable22, (java.lang.Object[]) doubleArray24);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException27 = new org.apache.commons.math.FunctionEvaluationException(doubleArray16, localizable18, (java.lang.Object[]) doubleArray24);
        double[][] doubleArray28 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray24);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException8, "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) doubleArray24);
        double[] doubleArray36 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException37 = new org.apache.commons.math.FunctionEvaluationException(doubleArray36);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException38 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException8, doubleArray36);
        int int39 = maxIterationsExceededException8.getMaxIterations();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix2 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix((-1), (int) (short) 10);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        double double6 = blockRealMatrix5.getNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix8 = blockRealMatrix5.scalarAdd((double) (-1L));
        try {
            double[] doubleArray10 = blockRealMatrix5.getRow((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 10 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix8);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double14 = blockRealMatrix13.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix10.subtract(blockRealMatrix13);
        boolean boolean17 = blockRealMatrix15.equals((java.lang.Object) 100.0d);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) blockRealMatrix15);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor19 = null;
        try {
            double double20 = blockRealMatrix15.walkInOptimizedOrder(realMatrixChangingVisitor19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        double[] doubleArray0 = new double[] {};
        double[][] doubleArray1 = new double[][] { doubleArray0 };
        double[][] doubleArray2 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray1);
        java.io.ObjectInputStream objectInputStream4 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.deserializeRealVector((java.lang.Object) doubleArray1, "{0}", objectInputStream4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        boolean boolean2 = array2DRowRealMatrix0.isSingular();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix5 = array2DRowRealMatrix0.createMatrix(52, 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        boolean boolean2 = array2DRowRealMatrix0.isSingular();
        org.apache.commons.math.linear.RealMatrix realMatrix5 = array2DRowRealMatrix0.createMatrix((int) '#', 1);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int7 = array2DRowRealMatrix6.getColumnDimension();
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = array2DRowRealMatrix0.add(array2DRowRealMatrix6);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.MathRuntimeException mathRuntimeException1 = new org.apache.commons.math.MathRuntimeException(throwable0);
        double[] doubleArray7 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable8 = null;
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(doubleArray7, localizable8, (java.lang.Object[]) doubleArray10);
        double[][] doubleArray13 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray10);
        int int15 = maxIterationsExceededException14.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable16 = maxIterationsExceededException14.getLocalizablePattern();
        double[] doubleArray19 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable20 = null;
        double[] doubleArray21 = new double[] {};
        double[][] doubleArray22 = new double[][] { doubleArray21 };
        double[][] doubleArray23 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray22);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException24 = new org.apache.commons.math.FunctionEvaluationException(doubleArray19, localizable20, (java.lang.Object[]) doubleArray22);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException(throwable0, (double) (short) 100, localizable16, (java.lang.Object[]) doubleArray22);
        org.apache.commons.math.exception.Localizable localizable29 = null;
        double[][] doubleArray33 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException34 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray33);
        org.apache.commons.math.exception.Localizable localizable36 = null;
        double[] doubleArray39 = new double[] {};
        double[][] doubleArray40 = new double[][] { doubleArray39 };
        double[][] doubleArray41 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray40);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException42 = new org.apache.commons.math.MaxEvaluationsExceededException(10, "", (java.lang.Object[]) doubleArray40);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException43 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException34, (double) (short) -1, localizable36, (java.lang.Object[]) doubleArray40);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException44 = new org.apache.commons.math.MaxIterationsExceededException(1, localizable29, (java.lang.Object[]) doubleArray40);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException45 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException25, (double) 52, "hi!", (java.lang.Object[]) doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 52 + "'", int15 == 52);
        org.junit.Assert.assertNotNull(localizable16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(nullPointerException34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException();
        double[] doubleArray7 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable8 = null;
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(doubleArray7, localizable8, (java.lang.Object[]) doubleArray10);
        double[][] doubleArray13 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray10);
        int int15 = maxIterationsExceededException14.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable16 = maxIterationsExceededException14.getLocalizablePattern();
        double[] doubleArray22 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable23 = null;
        double[] doubleArray24 = new double[] {};
        double[][] doubleArray25 = new double[][] { doubleArray24 };
        double[][] doubleArray26 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray25);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException27 = new org.apache.commons.math.FunctionEvaluationException(doubleArray22, localizable23, (java.lang.Object[]) doubleArray25);
        double[][] doubleArray28 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray25);
        int int30 = maxIterationsExceededException29.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable31 = maxIterationsExceededException29.getLocalizablePattern();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException33 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray34 = functionEvaluationException33.getSuppressed();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException35 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a', localizable31, (java.lang.Object[]) throwableArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException2, localizable16, (java.lang.Object[]) throwableArray34);
        java.lang.Throwable throwable37 = null;
        org.apache.commons.math.MathRuntimeException mathRuntimeException38 = new org.apache.commons.math.MathRuntimeException(throwable37);
        double[] doubleArray44 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable45 = null;
        double[] doubleArray46 = new double[] {};
        double[][] doubleArray47 = new double[][] { doubleArray46 };
        double[][] doubleArray48 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray47);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException49 = new org.apache.commons.math.FunctionEvaluationException(doubleArray44, localizable45, (java.lang.Object[]) doubleArray47);
        double[][] doubleArray50 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray47);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException51 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray47);
        int int52 = maxIterationsExceededException51.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable53 = maxIterationsExceededException51.getLocalizablePattern();
        double[] doubleArray56 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable57 = null;
        double[] doubleArray58 = new double[] {};
        double[][] doubleArray59 = new double[][] { doubleArray58 };
        double[][] doubleArray60 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray59);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException61 = new org.apache.commons.math.FunctionEvaluationException(doubleArray56, localizable57, (java.lang.Object[]) doubleArray59);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException62 = new org.apache.commons.math.FunctionEvaluationException(throwable37, (double) (short) 100, localizable53, (java.lang.Object[]) doubleArray59);
        org.apache.commons.math.optimization.OptimizationException optimizationException63 = new org.apache.commons.math.optimization.OptimizationException(localizable16, (java.lang.Object[]) doubleArray59);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException64 = new org.apache.commons.math.FunctionEvaluationException((double) 10L, "{0}", (java.lang.Object[]) doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 52 + "'", int15 == 52);
        org.junit.Assert.assertNotNull(localizable16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 52 + "'", int30 == 52);
        org.junit.Assert.assertNotNull(localizable31);
        org.junit.Assert.assertNotNull(throwableArray34);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 52 + "'", int52 == 52);
        org.junit.Assert.assertNotNull(localizable53);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        double[] doubleArray8 = new double[] {};
        double[][] doubleArray9 = new double[][] { doubleArray8 };
        double[][] doubleArray10 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray9);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException11 = new org.apache.commons.math.MaxEvaluationsExceededException(10, "", (java.lang.Object[]) doubleArray9);
        boolean boolean12 = blockRealMatrix5.equals((java.lang.Object) "");
        try {
            double[] doubleArray14 = blockRealMatrix5.getRow(52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 52 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        double[] doubleArray8 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable9 = null;
        double[] doubleArray10 = new double[] {};
        double[][] doubleArray11 = new double[][] { doubleArray10 };
        double[][] doubleArray12 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray11);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException13 = new org.apache.commons.math.FunctionEvaluationException(doubleArray8, localizable9, (java.lang.Object[]) doubleArray11);
        double[][] doubleArray14 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray11);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray11);
        int int16 = maxIterationsExceededException15.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable17 = maxIterationsExceededException15.getLocalizablePattern();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException19 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray20 = functionEvaluationException19.getSuppressed();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException21 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a', localizable17, (java.lang.Object[]) throwableArray20);
        org.apache.commons.math.exception.Localizable localizable22 = null;
        double[][] doubleArray26 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException27 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException28 = new org.apache.commons.math.linear.MatrixIndexException(localizable22, (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException29 = new org.apache.commons.math.linear.InvalidMatrixException(localizable17, (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.exception.Localizable localizable31 = null;
        double[] doubleArray36 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable37 = null;
        double[] doubleArray38 = new double[] {};
        double[][] doubleArray39 = new double[][] { doubleArray38 };
        double[][] doubleArray40 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray39);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException41 = new org.apache.commons.math.FunctionEvaluationException(doubleArray36, localizable37, (java.lang.Object[]) doubleArray39);
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray39);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException43 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((double) 0.0f, localizable31, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException(localizable17, (java.lang.Object[]) doubleArray39);
        try {
            array2DRowRealMatrix0.setSubMatrix(doubleArray39, (int) '#', (int) (short) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalStateException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 52 + "'", int16 == 52);
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(nullPointerException27);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        double double6 = blockRealMatrix5.getNorm();
        org.apache.commons.math.linear.RealVector realVector8 = null;
        try {
            blockRealMatrix5.setRowVector((int) (byte) 100, realVector8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException1 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 0);
        java.lang.String str2 = maxEvaluationsExceededException1.toString();
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.MathRuntimeException(throwable3);
        double[] doubleArray10 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable11 = null;
        double[] doubleArray12 = new double[] {};
        double[][] doubleArray13 = new double[][] { doubleArray12 };
        double[][] doubleArray14 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray13);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException(doubleArray10, localizable11, (java.lang.Object[]) doubleArray13);
        double[][] doubleArray16 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray13);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray13);
        int int18 = maxIterationsExceededException17.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable19 = maxIterationsExceededException17.getLocalizablePattern();
        double[] doubleArray22 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable23 = null;
        double[] doubleArray24 = new double[] {};
        double[][] doubleArray25 = new double[][] { doubleArray24 };
        double[][] doubleArray26 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray25);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException27 = new org.apache.commons.math.FunctionEvaluationException(doubleArray22, localizable23, (java.lang.Object[]) doubleArray25);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException28 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) (short) 100, localizable19, (java.lang.Object[]) doubleArray25);
        double[] doubleArray33 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[] doubleArray35 = new double[] {};
        double[][] doubleArray36 = new double[][] { doubleArray35 };
        double[][] doubleArray37 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray36);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException38 = new org.apache.commons.math.FunctionEvaluationException(doubleArray33, localizable34, (java.lang.Object[]) doubleArray36);
        double[][] doubleArray39 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray36);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException40 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray36);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxEvaluationsExceededException1, localizable19, (java.lang.Object[]) doubleArray36);
        double[][] doubleArray45 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException46 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray45);
        org.apache.commons.math.exception.Localizable localizable48 = null;
        double[] doubleArray51 = new double[] {};
        double[][] doubleArray52 = new double[][] { doubleArray51 };
        double[][] doubleArray53 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray52);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException54 = new org.apache.commons.math.MaxEvaluationsExceededException(10, "", (java.lang.Object[]) doubleArray52);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException55 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException46, (double) (short) -1, localizable48, (java.lang.Object[]) doubleArray52);
        java.io.EOFException eOFException56 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable19, (java.lang.Object[]) doubleArray52);
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix57 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(doubleArray52);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded" + "'", str2.equals("org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded"));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 52 + "'", int18 == 52);
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(nullPointerException46);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(eOFException56);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException2 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 0);
        java.lang.String str3 = maxEvaluationsExceededException2.toString();
        java.lang.Throwable throwable4 = null;
        org.apache.commons.math.MathRuntimeException mathRuntimeException5 = new org.apache.commons.math.MathRuntimeException(throwable4);
        double[] doubleArray11 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable12 = null;
        double[] doubleArray13 = new double[] {};
        double[][] doubleArray14 = new double[][] { doubleArray13 };
        double[][] doubleArray15 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray14);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException(doubleArray11, localizable12, (java.lang.Object[]) doubleArray14);
        double[][] doubleArray17 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray14);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray14);
        int int19 = maxIterationsExceededException18.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable20 = maxIterationsExceededException18.getLocalizablePattern();
        double[] doubleArray23 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable24 = null;
        double[] doubleArray25 = new double[] {};
        double[][] doubleArray26 = new double[][] { doubleArray25 };
        double[][] doubleArray27 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray26);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException28 = new org.apache.commons.math.FunctionEvaluationException(doubleArray23, localizable24, (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException(throwable4, (double) (short) 100, localizable20, (java.lang.Object[]) doubleArray26);
        double[] doubleArray34 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable35 = null;
        double[] doubleArray36 = new double[] {};
        double[][] doubleArray37 = new double[][] { doubleArray36 };
        double[][] doubleArray38 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray37);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException39 = new org.apache.commons.math.FunctionEvaluationException(doubleArray34, localizable35, (java.lang.Object[]) doubleArray37);
        double[][] doubleArray40 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray37);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException41 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray37);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxEvaluationsExceededException2, localizable20, (java.lang.Object[]) doubleArray37);
        double[][] doubleArray46 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException47 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray46);
        org.apache.commons.math.exception.Localizable localizable49 = null;
        double[] doubleArray52 = new double[] {};
        double[][] doubleArray53 = new double[][] { doubleArray52 };
        double[][] doubleArray54 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray53);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException55 = new org.apache.commons.math.MaxEvaluationsExceededException(10, "", (java.lang.Object[]) doubleArray53);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException56 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException47, (double) (short) -1, localizable49, (java.lang.Object[]) doubleArray53);
        java.io.EOFException eOFException57 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable20, (java.lang.Object[]) doubleArray53);
        org.apache.commons.math.exception.Localizable localizable59 = null;
        double[] doubleArray64 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable65 = null;
        double[] doubleArray66 = new double[] {};
        double[][] doubleArray67 = new double[][] { doubleArray66 };
        double[][] doubleArray68 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray67);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException69 = new org.apache.commons.math.FunctionEvaluationException(doubleArray64, localizable65, (java.lang.Object[]) doubleArray67);
        double[][] doubleArray70 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray67);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException71 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray67);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException72 = new org.apache.commons.math.FunctionEvaluationException((double) 0.0f, localizable59, (java.lang.Object[]) doubleArray67);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException73 = new org.apache.commons.math.FunctionEvaluationException(10.0d, localizable20, (java.lang.Object[]) doubleArray67);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded" + "'", str3.equals("org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded"));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 52 + "'", int19 == 52);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(nullPointerException47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(eOFException57);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray70);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getDeterminant();
        java.lang.String str3 = array2DRowRealMatrix0.toString();
        double double4 = array2DRowRealMatrix0.getDeterminant();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor5 = null;
        try {
            double double10 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixChangingVisitor5, (int) (byte) 0, (int) (short) 100, (int) (short) 100, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 0 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Array2DRowRealMatrix{}" + "'", str3.equals("Array2DRowRealMatrix{}"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double14 = blockRealMatrix13.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix10.subtract(blockRealMatrix13);
        boolean boolean17 = blockRealMatrix15.equals((java.lang.Object) 100.0d);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) blockRealMatrix15);
        int int19 = blockRealMatrix2.getColumnDimension();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double24 = blockRealMatrix23.getFrobeniusNorm();
        org.apache.commons.math.linear.RealVector realVector26 = blockRealMatrix23.getColumnVector((int) (short) 1);
        try {
            blockRealMatrix2.setColumnVector((int) ' ', realVector26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 32 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(realVector26);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        boolean boolean2 = array2DRowRealMatrix0.isSquare();
        double[][] doubleArray3 = array2DRowRealMatrix0.getData();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix5 = array2DRowRealMatrix0.getRowMatrix(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 0 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        org.apache.commons.math.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix5, (int) (short) 0);
        blockRealMatrix5.addToEntry((int) (byte) 0, (int) (byte) 0, (double) (-1L));
        double[] doubleArray16 = new double[] { (-1.0d), (byte) 0, 0.0d };
        double[] doubleArray21 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable22 = null;
        double[] doubleArray23 = new double[] {};
        double[][] doubleArray24 = new double[][] { doubleArray23 };
        double[][] doubleArray25 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray24);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException26 = new org.apache.commons.math.FunctionEvaluationException(doubleArray21, localizable22, (java.lang.Object[]) doubleArray24);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException27 = new org.apache.commons.math.linear.MatrixIndexException("org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) doubleArray24);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException28 = new org.apache.commons.math.FunctionEvaluationException(doubleArray16, "", (java.lang.Object[]) doubleArray24);
        org.apache.commons.math.linear.RealMatrix realMatrix29 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(doubleArray16);
        try {
            blockRealMatrix5.setColumn((int) ' ', doubleArray16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 32 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix29);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.apache.commons.math.exception.Localizable localizable3 = null;
        double[] doubleArray10 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException11 = new org.apache.commons.math.FunctionEvaluationException(doubleArray10);
        org.apache.commons.math.exception.Localizable localizable12 = null;
        double[] doubleArray15 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable16 = null;
        double[] doubleArray17 = new double[] {};
        double[][] doubleArray18 = new double[][] { doubleArray17 };
        double[][] doubleArray19 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray18);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException(doubleArray15, localizable16, (java.lang.Object[]) doubleArray18);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException21 = new org.apache.commons.math.FunctionEvaluationException(doubleArray10, localizable12, (java.lang.Object[]) doubleArray18);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(localizable3, (java.lang.Object[]) doubleArray18);
        java.lang.ArithmeticException arithmeticException23 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", (java.lang.Object[]) doubleArray18);
        java.text.ParseException parseException24 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) 100, "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(arithmeticException23);
        org.junit.Assert.assertNotNull(parseException24);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        boolean boolean2 = array2DRowRealMatrix0.isSquare();
        double[][] doubleArray3 = array2DRowRealMatrix0.getData();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor4 = null;
        try {
            double double9 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixPreservingVisitor4, (int) (short) -1, (int) (byte) 1, 1, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index -1 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException1 = new org.apache.commons.math.FunctionEvaluationException((double) (byte) 100);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        int int4 = blockRealMatrix2.getColumnDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int7 = array2DRowRealMatrix6.getColumnDimension();
        double[][] doubleArray8 = array2DRowRealMatrix6.getData();
        boolean boolean9 = array2DRowRealMatrix6.isSquare();
        try {
            blockRealMatrix2.setRowMatrix(97, (org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 97 out of allowed range [0, 34]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        double[] doubleArray3 = new double[] {};
        double[][] doubleArray4 = new double[][] { doubleArray3 };
        double[][] doubleArray5 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray4);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException6 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray5);
        double[] doubleArray10 = new double[] {};
        double[][] doubleArray11 = new double[][] { doubleArray10 };
        double[][] doubleArray12 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray11);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException13 = new org.apache.commons.math.MaxEvaluationsExceededException(10, "", (java.lang.Object[]) doubleArray11);
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) maxEvaluationsExceededException6, "hi!", (java.lang.Object[]) doubleArray11);
        java.util.ConcurrentModificationException concurrentModificationException15 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("evaluation failed for argument = {0}", (java.lang.Object[]) doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(concurrentModificationException15);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix7.copy();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix8.copy();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix8.scalarAdd(0.0d);
        int int12 = blockRealMatrix8.getColumnDimension();
        int[] intArray13 = new int[] {};
        int[] intArray14 = null;
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix15 = blockRealMatrix8.getSubMatrix(intArray13, intArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertNotNull(intArray13);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.apache.commons.math.linear.BigMatrix bigMatrix1 = org.apache.commons.math.linear.MatrixUtils.createBigIdentityMatrix(10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int3 = array2DRowRealMatrix2.getColumnDimension();
        double double4 = array2DRowRealMatrix2.getDeterminant();
        java.lang.String str5 = array2DRowRealMatrix2.toString();
        double double6 = array2DRowRealMatrix2.getDeterminant();
        double double7 = array2DRowRealMatrix2.getNorm();
        try {
            org.apache.commons.math.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math.linear.AnyMatrix) bigMatrix1, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix2);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigMatrix1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Array2DRowRealMatrix{}" + "'", str5.equals("Array2DRowRealMatrix{}"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getDeterminant();
        java.lang.String str3 = array2DRowRealMatrix0.toString();
        double double4 = array2DRowRealMatrix0.getDeterminant();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor5 = null;
        try {
            double double10 = array2DRowRealMatrix0.walkInOptimizedOrder(realMatrixChangingVisitor5, (int) '4', (-1), 36, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 52 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Array2DRowRealMatrix{}" + "'", str3.equals("Array2DRowRealMatrix{}"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double14 = blockRealMatrix13.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix10.subtract(blockRealMatrix13);
        boolean boolean17 = blockRealMatrix15.equals((java.lang.Object) 100.0d);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) blockRealMatrix15);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix24 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double25 = blockRealMatrix24.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = blockRealMatrix21.subtract(blockRealMatrix24);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix29 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double33 = blockRealMatrix32.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix34 = blockRealMatrix29.subtract(blockRealMatrix32);
        boolean boolean36 = blockRealMatrix34.equals((java.lang.Object) 100.0d);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix21.add((org.apache.commons.math.linear.RealMatrix) blockRealMatrix34);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix18.multiply(blockRealMatrix34);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix26);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.apache.commons.math.exception.Localizable localizable1 = null;
        double[][] doubleArray5 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException6 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray5);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException7 = new org.apache.commons.math.linear.MatrixIndexException(localizable1, (java.lang.Object[]) doubleArray5);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException();
        double[] doubleArray14 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable15 = null;
        double[] doubleArray16 = new double[] {};
        double[][] doubleArray17 = new double[][] { doubleArray16 };
        double[][] doubleArray18 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray17);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException19 = new org.apache.commons.math.FunctionEvaluationException(doubleArray14, localizable15, (java.lang.Object[]) doubleArray17);
        double[][] doubleArray20 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray17);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException21 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray17);
        int int22 = maxIterationsExceededException21.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable23 = maxIterationsExceededException21.getLocalizablePattern();
        double[] doubleArray29 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable30 = null;
        double[] doubleArray31 = new double[] {};
        double[][] doubleArray32 = new double[][] { doubleArray31 };
        double[][] doubleArray33 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray32);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException34 = new org.apache.commons.math.FunctionEvaluationException(doubleArray29, localizable30, (java.lang.Object[]) doubleArray32);
        double[][] doubleArray35 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray32);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray32);
        int int37 = maxIterationsExceededException36.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable38 = maxIterationsExceededException36.getLocalizablePattern();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray41 = functionEvaluationException40.getSuppressed();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException42 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a', localizable38, (java.lang.Object[]) throwableArray41);
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException9, localizable23, (java.lang.Object[]) throwableArray41);
        double[] doubleArray46 = new double[] {};
        double[][] doubleArray47 = new double[][] { doubleArray46 };
        double[][] doubleArray48 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray47);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException49 = new org.apache.commons.math.MaxEvaluationsExceededException(10, "", (java.lang.Object[]) doubleArray47);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException50 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) matrixIndexException7, (double) (short) -1, localizable23, (java.lang.Object[]) doubleArray47);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException51 = new org.apache.commons.math.linear.InvalidMatrixException("", (java.lang.Object[]) doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(nullPointerException6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 52 + "'", int22 == 52);
        org.junit.Assert.assertNotNull(localizable23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 52 + "'", int37 == 52);
        org.junit.Assert.assertNotNull(localizable38);
        org.junit.Assert.assertNotNull(throwableArray41);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double[][] doubleArray2 = array2DRowRealMatrix0.getData();
        boolean boolean3 = array2DRowRealMatrix0.isSquare();
        org.apache.commons.math.linear.RealMatrix realMatrix4 = null;
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix5 = array2DRowRealMatrix0.multiply(realMatrix4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        java.math.BigDecimal[][] bigDecimalArray0 = new java.math.BigDecimal[][] {};
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix1 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(bigDecimalArray0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigDecimalArray0);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double[][] doubleArray2 = array2DRowRealMatrix0.getData();
        boolean boolean3 = array2DRowRealMatrix0.isSquare();
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl5 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix0, (double) 1.0f);
        java.lang.Throwable throwable11 = null;
        org.apache.commons.math.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.MathRuntimeException(throwable11);
        double[] doubleArray18 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable19 = null;
        double[] doubleArray20 = new double[] {};
        double[][] doubleArray21 = new double[][] { doubleArray20 };
        double[][] doubleArray22 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray21);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException23 = new org.apache.commons.math.FunctionEvaluationException(doubleArray18, localizable19, (java.lang.Object[]) doubleArray21);
        double[][] doubleArray24 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray21);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray21);
        int int26 = maxIterationsExceededException25.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable27 = maxIterationsExceededException25.getLocalizablePattern();
        double[] doubleArray30 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable31 = null;
        double[] doubleArray32 = new double[] {};
        double[][] doubleArray33 = new double[][] { doubleArray32 };
        double[][] doubleArray34 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray33);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException35 = new org.apache.commons.math.FunctionEvaluationException(doubleArray30, localizable31, (java.lang.Object[]) doubleArray33);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException(throwable11, (double) (short) 100, localizable27, (java.lang.Object[]) doubleArray33);
        double[] doubleArray41 = new double[] {};
        double[][] doubleArray42 = new double[][] { doubleArray41 };
        double[][] doubleArray43 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray42);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException44 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray43);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException45 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray43);
        double[] doubleArray53 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException54 = new org.apache.commons.math.FunctionEvaluationException(doubleArray53);
        org.apache.commons.math.exception.Localizable localizable55 = null;
        double[] doubleArray58 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable59 = null;
        double[] doubleArray60 = new double[] {};
        double[][] doubleArray61 = new double[][] { doubleArray60 };
        double[][] doubleArray62 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray61);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException63 = new org.apache.commons.math.FunctionEvaluationException(doubleArray58, localizable59, (java.lang.Object[]) doubleArray61);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException64 = new org.apache.commons.math.FunctionEvaluationException(doubleArray53, localizable55, (java.lang.Object[]) doubleArray61);
        double[][] doubleArray65 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray61);
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException45, "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) doubleArray61);
        java.lang.UnsupportedOperationException unsupportedOperationException67 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException(localizable27, (java.lang.Object[]) doubleArray61);
        java.util.ConcurrentModificationException concurrentModificationException68 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("{0}", (java.lang.Object[]) doubleArray61);
        try {
            array2DRowRealMatrix0.copySubMatrix(10, 1, (int) ' ', 1, doubleArray61);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 10 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 52 + "'", int26 == 52);
        org.junit.Assert.assertNotNull(localizable27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(unsupportedOperationException67);
        org.junit.Assert.assertNotNull(concurrentModificationException68);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.RealVector realVector5 = blockRealMatrix2.getColumnVector((int) (short) 1);
        java.io.ObjectOutputStream objectOutputStream6 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.serializeRealVector(realVector5, objectOutputStream6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(realVector5);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("maximal number of iterations ({0}) exceeded", objArray1);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double8 = blockRealMatrix7.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix4.multiply(blockRealMatrix7);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double17 = blockRealMatrix16.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix13.subtract(blockRealMatrix16);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix24 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double25 = blockRealMatrix24.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = blockRealMatrix21.subtract(blockRealMatrix24);
        boolean boolean28 = blockRealMatrix26.equals((java.lang.Object) 100.0d);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix29 = blockRealMatrix13.add((org.apache.commons.math.linear.RealMatrix) blockRealMatrix26);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double33 = blockRealMatrix32.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix34 = blockRealMatrix32.transpose();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix37 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double38 = blockRealMatrix37.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix39 = blockRealMatrix34.multiply(blockRealMatrix37);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix40 = blockRealMatrix26.multiply((org.apache.commons.math.linear.RealMatrix) blockRealMatrix39);
        try {
            blockRealMatrix7.setRowMatrix((int) ' ', (org.apache.commons.math.linear.RealMatrix) blockRealMatrix40);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.InvalidMatrixException; message: dimensions mismatch: got 35x10 but expected 1x10");
        } catch (org.apache.commons.math.linear.InvalidMatrixException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix29);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix34);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix39);
        org.junit.Assert.assertNotNull(blockRealMatrix40);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.apache.commons.math.exception.Localizable localizable1 = null;
        double[][] doubleArray5 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException6 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray5);
        org.apache.commons.math.exception.Localizable localizable8 = null;
        double[] doubleArray11 = new double[] {};
        double[][] doubleArray12 = new double[][] { doubleArray11 };
        double[][] doubleArray13 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray12);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException14 = new org.apache.commons.math.MaxEvaluationsExceededException(10, "", (java.lang.Object[]) doubleArray12);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException6, (double) (short) -1, localizable8, (java.lang.Object[]) doubleArray12);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException16 = new org.apache.commons.math.MaxIterationsExceededException(1, localizable1, (java.lang.Object[]) doubleArray12);
        int int17 = maxIterationsExceededException16.getMaxIterations();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(nullPointerException6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.apache.commons.math.exception.Localizable localizable2 = null;
        double[] doubleArray7 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable8 = null;
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(doubleArray7, localizable8, (java.lang.Object[]) doubleArray10);
        double[][] doubleArray13 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException((double) 0.0f, localizable2, (java.lang.Object[]) doubleArray10);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException16 = new org.apache.commons.math.linear.InvalidMatrixException("maximal number of iterations ({0}) exceeded", (java.lang.Object[]) doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        double[] doubleArray6 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException7 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6);
        org.apache.commons.math.exception.Localizable localizable8 = null;
        double[][] doubleArray12 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException13 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray12);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException14 = new org.apache.commons.math.linear.MatrixIndexException(localizable8, (java.lang.Object[]) doubleArray12);
        double[] doubleArray21 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException22 = new org.apache.commons.math.FunctionEvaluationException(doubleArray21);
        org.apache.commons.math.linear.RealMatrix realMatrix23 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray21);
        double[] doubleArray30 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException31 = new org.apache.commons.math.FunctionEvaluationException(doubleArray30);
        org.apache.commons.math.exception.Localizable localizable32 = null;
        double[] doubleArray35 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable36 = null;
        double[] doubleArray37 = new double[] {};
        double[][] doubleArray38 = new double[][] { doubleArray37 };
        double[][] doubleArray39 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray38);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException(doubleArray35, localizable36, (java.lang.Object[]) doubleArray38);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException41 = new org.apache.commons.math.FunctionEvaluationException(doubleArray30, localizable32, (java.lang.Object[]) doubleArray38);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair43 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray21, doubleArray30, true);
        org.apache.commons.math.exception.Localizable localizable45 = null;
        double[][] doubleArray49 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException50 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray49);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException51 = new org.apache.commons.math.linear.MatrixIndexException(localizable45, (java.lang.Object[]) doubleArray49);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException52 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) matrixIndexException14, doubleArray21, "{0}", (java.lang.Object[]) doubleArray49);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair54 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray6, doubleArray21, false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(nullPointerException13);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(nullPointerException50);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double14 = blockRealMatrix13.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix10.subtract(blockRealMatrix13);
        boolean boolean17 = blockRealMatrix15.equals((java.lang.Object) 100.0d);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) blockRealMatrix15);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double22 = blockRealMatrix21.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix23 = blockRealMatrix21.transpose();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double27 = blockRealMatrix26.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix28 = blockRealMatrix23.multiply(blockRealMatrix26);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix29 = blockRealMatrix15.multiply((org.apache.commons.math.linear.RealMatrix) blockRealMatrix28);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix31 = blockRealMatrix28.getColumnMatrix(36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 36 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix23);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix28);
        org.junit.Assert.assertNotNull(blockRealMatrix29);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getDeterminant();
        double[] doubleArray9 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException(doubleArray9);
        org.apache.commons.math.linear.RealMatrix realMatrix11 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray9);
        double[] doubleArray12 = null;
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair14 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray9, doubleArray12, false);
        try {
            double[] doubleArray15 = array2DRowRealMatrix0.operate(doubleArray9);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 1, (int) (short) 10);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor3 = null;
        try {
            double double8 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixPreservingVisitor3, (int) (short) 1, (int) ' ', (int) (byte) -1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 1 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double9 = blockRealMatrix8.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix8.getRowMatrix(0);
        org.apache.commons.math.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix11, (int) (short) 0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix5.add((org.apache.commons.math.linear.RealMatrix) blockRealMatrix11);
        try {
            double double15 = blockRealMatrix5.getDeterminant();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 1x10 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double14 = blockRealMatrix13.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix10.subtract(blockRealMatrix13);
        boolean boolean17 = blockRealMatrix15.equals((java.lang.Object) 100.0d);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) blockRealMatrix15);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double22 = blockRealMatrix21.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix23 = blockRealMatrix21.transpose();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double27 = blockRealMatrix26.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix28 = blockRealMatrix23.multiply(blockRealMatrix26);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix29 = blockRealMatrix15.multiply((org.apache.commons.math.linear.RealMatrix) blockRealMatrix28);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl30 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) blockRealMatrix28);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean32 = array2DRowRealMatrix31.isSquare();
        boolean boolean33 = array2DRowRealMatrix31.isSingular();
        org.apache.commons.math.linear.RealMatrix realMatrix36 = array2DRowRealMatrix31.createMatrix((int) '#', 1);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix37 = blockRealMatrix28.preMultiply(realMatrix36);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix23);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix28);
        org.junit.Assert.assertNotNull(blockRealMatrix29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(realMatrix36);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        double[][] doubleArray4 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException5 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray4);
        java.lang.IllegalArgumentException illegalArgumentException6 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) doubleArray4);
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, true);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(nullPointerException5);
        org.junit.Assert.assertNotNull(illegalArgumentException6);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        double[] doubleArray5 = blockRealMatrix2.getRow(10);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor6 = null;
        try {
            double double7 = blockRealMatrix2.walkInOptimizedOrder(realMatrixChangingVisitor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix7.copy();
        int[] intArray9 = null;
        int[] intArray12 = new int[] { (byte) 100, 'a' };
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix13 = blockRealMatrix7.getSubMatrix(intArray9, intArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(intArray12);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix7.copy();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix8.copy();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix8.scalarAdd(0.0d);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix13 = blockRealMatrix8.getColumnMatrix((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 97 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double[][] doubleArray2 = array2DRowRealMatrix0.getData();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor3 = null;
        try {
            double double4 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixChangingVisitor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        double[] doubleArray2 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable3 = null;
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray4 };
        double[][] doubleArray6 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray5);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException7 = new org.apache.commons.math.FunctionEvaluationException(doubleArray2, localizable3, (java.lang.Object[]) doubleArray5);
        double[] doubleArray13 = new double[] { 10L, '#', 0, 1.0d, '#' };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair15 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray2, doubleArray13, true);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray2);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl17 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix16);
        double double18 = lUDecompositionImpl17.getDeterminant();
        org.apache.commons.math.linear.DecompositionSolver decompositionSolver19 = lUDecompositionImpl17.getSolver();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 10.0d + "'", double18 == 10.0d);
        org.junit.Assert.assertNotNull(decompositionSolver19);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        blockRealMatrix2.addToEntry(0, 1, (double) 1L);
        double double7 = blockRealMatrix2.getFrobeniusNorm();
        try {
            double double8 = blockRealMatrix2.getDeterminant();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 35x10 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        double[] doubleArray2 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable3 = null;
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray4 };
        double[][] doubleArray6 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray5);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException7 = new org.apache.commons.math.FunctionEvaluationException(doubleArray2, localizable3, (java.lang.Object[]) doubleArray5);
        double[] doubleArray13 = new double[] { 10L, '#', 0, 1.0d, '#' };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair15 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray2, doubleArray13, true);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray2);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl18 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix16, (double) (byte) 10);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix16);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.MathRuntimeException mathRuntimeException1 = new org.apache.commons.math.MathRuntimeException(throwable0);
        java.lang.String str2 = mathRuntimeException1.getPattern();
        org.apache.commons.math.exception.Localizable localizable3 = mathRuntimeException1.getLocalizablePattern();
        java.lang.Class<?> wildcardClass4 = localizable3.getClass();
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray12 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException13 = new org.apache.commons.math.FunctionEvaluationException(doubleArray12);
        org.apache.commons.math.exception.Localizable localizable14 = null;
        double[] doubleArray17 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable18 = null;
        double[] doubleArray19 = new double[] {};
        double[][] doubleArray20 = new double[][] { doubleArray19 };
        double[][] doubleArray21 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException22 = new org.apache.commons.math.FunctionEvaluationException(doubleArray17, localizable18, (java.lang.Object[]) doubleArray20);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException23 = new org.apache.commons.math.FunctionEvaluationException(doubleArray12, localizable14, (java.lang.Object[]) doubleArray20);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException(localizable5, (java.lang.Object[]) doubleArray20);
        java.lang.IllegalArgumentException illegalArgumentException25 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException(localizable3, (java.lang.Object[]) doubleArray20);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}" + "'", str2.equals("{0}"));
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable3.equals(org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(illegalArgumentException25);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        double[] doubleArray5 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable6 = null;
        double[] doubleArray7 = new double[] {};
        double[][] doubleArray8 = new double[][] { doubleArray7 };
        double[][] doubleArray9 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray8);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException(doubleArray5, localizable6, (java.lang.Object[]) doubleArray8);
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray8);
        int int13 = maxIterationsExceededException12.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable14 = maxIterationsExceededException12.getLocalizablePattern();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray17 = functionEvaluationException16.getSuppressed();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException18 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a', localizable14, (java.lang.Object[]) throwableArray17);
        org.apache.commons.math.exception.Localizable localizable19 = null;
        double[][] doubleArray23 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException24 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray23);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException25 = new org.apache.commons.math.linear.MatrixIndexException(localizable19, (java.lang.Object[]) doubleArray23);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException26 = new org.apache.commons.math.linear.InvalidMatrixException(localizable14, (java.lang.Object[]) doubleArray23);
        java.lang.Object[] objArray27 = null;
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException(localizable14, objArray27);
        org.apache.commons.math.exception.Localizable localizable29 = null;
        double[][] doubleArray33 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException34 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray33);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException35 = new org.apache.commons.math.linear.MatrixIndexException(localizable29, (java.lang.Object[]) doubleArray33);
        java.util.NoSuchElementException noSuchElementException36 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException(localizable14, (java.lang.Object[]) doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 52 + "'", int13 == 52);
        org.junit.Assert.assertNotNull(localizable14);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(nullPointerException24);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(nullPointerException34);
        org.junit.Assert.assertNotNull(noSuchElementException36);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        double[] doubleArray5 = new double[] {};
        double[][] doubleArray6 = new double[][] { doubleArray5 };
        double[][] doubleArray7 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException8 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray7);
        java.lang.IllegalArgumentException illegalArgumentException9 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", (java.lang.Object[]) doubleArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, "evaluation failed for argument = {0}", (java.lang.Object[]) doubleArray7);
        java.io.ObjectInputStream objectInputStream12 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) (short) 0, "hi!", objectInputStream12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(illegalArgumentException9);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double[][] doubleArray2 = array2DRowRealMatrix0.getData();
        boolean boolean3 = array2DRowRealMatrix0.isSquare();
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl5 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix0, (double) 1.0f);
        int int6 = array2DRowRealMatrix0.getRowDimension();
        double[] doubleArray9 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable10 = null;
        double[] doubleArray11 = new double[] {};
        double[][] doubleArray12 = new double[][] { doubleArray11 };
        double[][] doubleArray13 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray12);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException14 = new org.apache.commons.math.FunctionEvaluationException(doubleArray9, localizable10, (java.lang.Object[]) doubleArray12);
        try {
            double[] doubleArray15 = array2DRowRealMatrix0.preMultiply(doubleArray9);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException1 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray2 = functionEvaluationException1.getSuppressed();
        double[] doubleArray3 = functionEvaluationException1.getArgument();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double14 = blockRealMatrix13.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix10.subtract(blockRealMatrix13);
        boolean boolean17 = blockRealMatrix15.equals((java.lang.Object) 100.0d);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) blockRealMatrix15);
        int int19 = blockRealMatrix2.getColumnDimension();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor20 = null;
        try {
            double double21 = blockRealMatrix2.walkInOptimizedOrder(realMatrixPreservingVisitor20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        java.lang.String[] strArray3 = new java.lang.String[] { "Array2DRowRealMatrix{}", "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", "evaluation failed for argument = {0}" };
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix4 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(strArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double[][] doubleArray2 = array2DRowRealMatrix0.getData();
        boolean boolean3 = array2DRowRealMatrix0.isSquare();
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl5 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix0, (double) 1.0f);
        int int6 = array2DRowRealMatrix0.getRowDimension();
        try {
            double[] doubleArray8 = array2DRowRealMatrix0.getRow(100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getJacobianEvaluations();
        levenbergMarquardtOptimizer0.setCostRelativeTolerance(0.0d);
        levenbergMarquardtOptimizer0.setParRelativeTolerance((double) '#');
        org.apache.commons.math.optimization.VectorialConvergenceChecker vectorialConvergenceChecker6 = levenbergMarquardtOptimizer0.getConvergenceChecker();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(vectorialConvergenceChecker6);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        int[] intArray5 = new int[] { 36, (byte) -1 };
        int[] intArray12 = new int[] { '#', (byte) 1, 0, (byte) -1, (byte) 100, (short) 100 };
        double[] doubleArray18 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable19 = null;
        double[] doubleArray20 = new double[] {};
        double[][] doubleArray21 = new double[][] { doubleArray20 };
        double[][] doubleArray22 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray21);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException23 = new org.apache.commons.math.FunctionEvaluationException(doubleArray18, localizable19, (java.lang.Object[]) doubleArray21);
        double[][] doubleArray24 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray21);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray21);
        int int26 = maxIterationsExceededException25.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable27 = maxIterationsExceededException25.getLocalizablePattern();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray30 = functionEvaluationException29.getSuppressed();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException31 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a', localizable27, (java.lang.Object[]) throwableArray30);
        org.apache.commons.math.exception.Localizable localizable32 = null;
        double[][] doubleArray36 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException37 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray36);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException38 = new org.apache.commons.math.linear.MatrixIndexException(localizable32, (java.lang.Object[]) doubleArray36);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException39 = new org.apache.commons.math.linear.InvalidMatrixException(localizable27, (java.lang.Object[]) doubleArray36);
        try {
            array2DRowRealMatrix0.copySubMatrix(intArray5, intArray12, doubleArray36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 36 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 52 + "'", int26 == 52);
        org.junit.Assert.assertNotNull(localizable27);
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(nullPointerException37);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        double[] doubleArray2 = new double[] {};
        double[][] doubleArray3 = new double[][] { doubleArray2 };
        double[][] doubleArray4 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray3);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException5 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray4);
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException12 = new org.apache.commons.math.MaxEvaluationsExceededException(10, "", (java.lang.Object[]) doubleArray10);
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException((java.lang.Throwable) maxEvaluationsExceededException5, "hi!", (java.lang.Object[]) doubleArray10);
        org.apache.commons.math.optimization.OptimizationException optimizationException14 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) mathException13);
        org.apache.commons.math.exception.Localizable localizable15 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 1L };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException13, localizable15, objArray17);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException19 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable) convergenceException18);
        java.lang.Object[] objArray20 = invalidMatrixException19.getArguments();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray20);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double14 = blockRealMatrix13.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix10.subtract(blockRealMatrix13);
        boolean boolean17 = blockRealMatrix15.equals((java.lang.Object) 100.0d);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) blockRealMatrix15);
        double[][] doubleArray19 = blockRealMatrix15.getData();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        double double1 = levenbergMarquardtOptimizer0.getRMS();
        try {
            double[] doubleArray2 = levenbergMarquardtOptimizer0.guessParametersErrors();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.optimization.OptimizationException; message: no degrees of freedom (0 measurements, 0 parameters)");
        } catch (org.apache.commons.math.optimization.OptimizationException e) {
        }
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        boolean boolean2 = array2DRowRealMatrix0.isSingular();
        org.apache.commons.math.linear.RealMatrix realMatrix5 = array2DRowRealMatrix0.createMatrix((int) '#', 1);
        try {
            double[] doubleArray7 = array2DRowRealMatrix0.getColumn(52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 52 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realMatrix5);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getDeterminant();
        java.lang.String str3 = array2DRowRealMatrix0.toString();
        double double4 = array2DRowRealMatrix0.getDeterminant();
        double[][] doubleArray5 = array2DRowRealMatrix0.getDataRef();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor6 = null;
        try {
            double double7 = array2DRowRealMatrix0.walkInRowOrder(realMatrixPreservingVisitor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Array2DRowRealMatrix{}" + "'", str3.equals("Array2DRowRealMatrix{}"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNull(doubleArray5);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix7.copy();
        try {
            double[] doubleArray10 = blockRealMatrix8.getRow((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 97 out of allowed range [0, 34]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        boolean boolean2 = array2DRowRealMatrix0.isSingular();
        org.apache.commons.math.linear.RealMatrix realMatrix5 = array2DRowRealMatrix0.createMatrix((int) '#', 1);
        double[] doubleArray12 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException13 = new org.apache.commons.math.FunctionEvaluationException(doubleArray12);
        org.apache.commons.math.exception.Localizable localizable14 = null;
        double[] doubleArray17 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable18 = null;
        double[] doubleArray19 = new double[] {};
        double[][] doubleArray20 = new double[][] { doubleArray19 };
        double[][] doubleArray21 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException22 = new org.apache.commons.math.FunctionEvaluationException(doubleArray17, localizable18, (java.lang.Object[]) doubleArray20);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException23 = new org.apache.commons.math.FunctionEvaluationException(doubleArray12, localizable14, (java.lang.Object[]) doubleArray20);
        try {
            array2DRowRealMatrix0.setSubMatrix(doubleArray20, (int) '4', (int) (short) 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalStateException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getDeterminant();
        java.lang.String str3 = array2DRowRealMatrix0.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int5 = array2DRowRealMatrix4.getColumnDimension();
        double double6 = array2DRowRealMatrix4.getDeterminant();
        java.lang.String str7 = array2DRowRealMatrix4.toString();
        double double8 = array2DRowRealMatrix4.getDeterminant();
        double[][] doubleArray9 = array2DRowRealMatrix4.getDataRef();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix10 = array2DRowRealMatrix0.solve((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix4);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Array2DRowRealMatrix{}" + "'", str3.equals("Array2DRowRealMatrix{}"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Array2DRowRealMatrix{}" + "'", str7.equals("Array2DRowRealMatrix{}"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNull(doubleArray9);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        boolean boolean2 = array2DRowRealMatrix0.isSingular();
        org.apache.commons.math.linear.RealMatrix realMatrix5 = array2DRowRealMatrix0.createMatrix((int) '#', 1);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor6 = null;
        try {
            double double7 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixChangingVisitor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realMatrix5);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException();
        double[] doubleArray7 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable8 = null;
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(doubleArray7, localizable8, (java.lang.Object[]) doubleArray10);
        double[][] doubleArray13 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray10);
        int int15 = maxIterationsExceededException14.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable16 = maxIterationsExceededException14.getLocalizablePattern();
        double[] doubleArray22 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable23 = null;
        double[] doubleArray24 = new double[] {};
        double[][] doubleArray25 = new double[][] { doubleArray24 };
        double[][] doubleArray26 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray25);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException27 = new org.apache.commons.math.FunctionEvaluationException(doubleArray22, localizable23, (java.lang.Object[]) doubleArray25);
        double[][] doubleArray28 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray25);
        int int30 = maxIterationsExceededException29.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable31 = maxIterationsExceededException29.getLocalizablePattern();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException33 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray34 = functionEvaluationException33.getSuppressed();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException35 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a', localizable31, (java.lang.Object[]) throwableArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException2, localizable16, (java.lang.Object[]) throwableArray34);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException37 = new org.apache.commons.math.MaxEvaluationsExceededException(0, "", (java.lang.Object[]) throwableArray34);
        java.lang.Object[] objArray39 = null;
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxEvaluationsExceededException37, "hi!", objArray39);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 52 + "'", int15 == 52);
        org.junit.Assert.assertNotNull(localizable16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 52 + "'", int30 == 52);
        org.junit.Assert.assertNotNull(localizable31);
        org.junit.Assert.assertNotNull(throwableArray34);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        double[] doubleArray6 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException7 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6);
        org.apache.commons.math.linear.BigMatrix bigMatrix8 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(doubleArray6);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException10 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 0);
        java.lang.String str11 = maxEvaluationsExceededException10.toString();
        java.lang.Throwable throwable12 = null;
        org.apache.commons.math.MathRuntimeException mathRuntimeException13 = new org.apache.commons.math.MathRuntimeException(throwable12);
        double[] doubleArray19 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable20 = null;
        double[] doubleArray21 = new double[] {};
        double[][] doubleArray22 = new double[][] { doubleArray21 };
        double[][] doubleArray23 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray22);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException24 = new org.apache.commons.math.FunctionEvaluationException(doubleArray19, localizable20, (java.lang.Object[]) doubleArray22);
        double[][] doubleArray25 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray22);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray22);
        int int27 = maxIterationsExceededException26.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable28 = maxIterationsExceededException26.getLocalizablePattern();
        double[] doubleArray31 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable32 = null;
        double[] doubleArray33 = new double[] {};
        double[][] doubleArray34 = new double[][] { doubleArray33 };
        double[][] doubleArray35 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray34);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException(doubleArray31, localizable32, (java.lang.Object[]) doubleArray34);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException37 = new org.apache.commons.math.FunctionEvaluationException(throwable12, (double) (short) 100, localizable28, (java.lang.Object[]) doubleArray34);
        double[] doubleArray42 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable43 = null;
        double[] doubleArray44 = new double[] {};
        double[][] doubleArray45 = new double[][] { doubleArray44 };
        double[][] doubleArray46 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray45);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException47 = new org.apache.commons.math.FunctionEvaluationException(doubleArray42, localizable43, (java.lang.Object[]) doubleArray45);
        double[][] doubleArray48 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray45);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException49 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray45);
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxEvaluationsExceededException10, localizable28, (java.lang.Object[]) doubleArray45);
        double[] doubleArray54 = new double[] {};
        double[][] doubleArray55 = new double[][] { doubleArray54 };
        double[][] doubleArray56 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray55);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException57 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray56);
        double[] doubleArray61 = new double[] {};
        double[][] doubleArray62 = new double[][] { doubleArray61 };
        double[][] doubleArray63 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray62);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException64 = new org.apache.commons.math.MaxEvaluationsExceededException(10, "", (java.lang.Object[]) doubleArray62);
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException((java.lang.Throwable) maxEvaluationsExceededException57, "hi!", (java.lang.Object[]) doubleArray62);
        org.apache.commons.math.optimization.OptimizationException optimizationException66 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) mathException65);
        org.apache.commons.math.exception.Localizable localizable67 = null;
        java.lang.Object[] objArray69 = new java.lang.Object[] { 1L };
        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException65, localizable67, objArray69);
        java.lang.IllegalStateException illegalStateException71 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("hi!", objArray69);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException72 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6, localizable28, objArray69);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(bigMatrix8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded" + "'", str11.equals("org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded"));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 52 + "'", int27 == 52);
        org.junit.Assert.assertNotNull(localizable28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(objArray69);
        org.junit.Assert.assertNotNull(illegalStateException71);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix5.createMatrix((int) (byte) 100, 52);
        java.lang.String str9 = blockRealMatrix8.toString();
        double double10 = blockRealMatrix8.getFrobeniusNorm();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix12 = blockRealMatrix8.getColumnMatrix(100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 100 out of allowed range [0, 51]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        boolean boolean9 = blockRealMatrix7.equals((java.lang.Object) 100.0d);
        try {
            double double10 = blockRealMatrix7.getDeterminant();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 35x10 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        double[] doubleArray9 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable10 = null;
        double[] doubleArray11 = new double[] {};
        double[][] doubleArray12 = new double[][] { doubleArray11 };
        double[][] doubleArray13 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray12);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException14 = new org.apache.commons.math.FunctionEvaluationException(doubleArray9, localizable10, (java.lang.Object[]) doubleArray12);
        double[][] doubleArray15 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray12);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException16 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray12);
        int int17 = maxIterationsExceededException16.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable18 = maxIterationsExceededException16.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable19 = null;
        double[][] doubleArray23 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException24 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray23);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException25 = new org.apache.commons.math.linear.MatrixIndexException(localizable19, (java.lang.Object[]) doubleArray23);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', localizable18, (java.lang.Object[]) doubleArray23);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, "hi!", (java.lang.Object[]) doubleArray23);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException28 = new org.apache.commons.math.FunctionEvaluationException(0.0d, "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
        org.junit.Assert.assertNotNull(localizable18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(nullPointerException24);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        double double6 = blockRealMatrix2.getFrobeniusNorm();
        double double7 = blockRealMatrix2.getNorm();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) 'a', (int) 'a');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        int int7 = blockRealMatrix5.getColumnDimension();
        org.apache.commons.math.linear.RealVector realVector9 = blockRealMatrix5.getColumnVector(0);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.multiply((org.apache.commons.math.linear.RealMatrix) blockRealMatrix5);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertNotNull(realVector9);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getJacobianEvaluations();
        levenbergMarquardtOptimizer0.setCostRelativeTolerance(0.0d);
        levenbergMarquardtOptimizer0.setMaxIterations((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math.linear.NonSquareMatrixException((int) (byte) 1, 52);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        double double6 = blockRealMatrix5.getNorm();
        double double7 = blockRealMatrix5.getFrobeniusNorm();
        double[] doubleArray9 = blockRealMatrix5.getColumn(1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        java.lang.String[] strArray3 = new java.lang.String[] { "{0}", "hi!", "maximal number of iterations ({0}) exceeded" };
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix4 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(strArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getJacobianEvaluations();
        levenbergMarquardtOptimizer0.setCostRelativeTolerance(0.0d);
        levenbergMarquardtOptimizer0.setParRelativeTolerance((double) '#');
        levenbergMarquardtOptimizer0.setOrthoTolerance(0.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        try {
            double[] doubleArray2 = array2DRowRealMatrix0.getRow(10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 10 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        java.lang.Object[] objArray1 = null;
        java.lang.NullPointerException nullPointerException2 = org.apache.commons.math.MathRuntimeException.createNullPointerException("{0}", objArray1);
        java.lang.Class<?> wildcardClass3 = nullPointerException2.getClass();
        org.junit.Assert.assertNotNull(nullPointerException2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        boolean boolean6 = blockRealMatrix2.isSquare();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix2.getRowMatrix(10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double9 = blockRealMatrix8.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix8.getRowMatrix(0);
        org.apache.commons.math.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix11, (int) (short) 0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix5.add((org.apache.commons.math.linear.RealMatrix) blockRealMatrix11);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix5.copy();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double19 = blockRealMatrix18.getFrobeniusNorm();
        org.apache.commons.math.linear.RealVector realVector21 = blockRealMatrix18.getColumnVector((int) (short) 1);
        try {
            org.apache.commons.math.linear.RealVector realVector22 = blockRealMatrix5.operate(realVector21);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(realVector21);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        java.lang.Object obj0 = null;
        java.io.ObjectInputStream objectInputStream2 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.deserializeRealVector(obj0, "", objectInputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        blockRealMatrix5.setEntry(0, (int) (byte) 0, (double) 0);
        int[] intArray14 = new int[] { ' ', (byte) 1 };
        int[] intArray16 = new int[] { (short) 10 };
        double[] doubleArray21 = new double[] {};
        double[][] doubleArray22 = new double[][] { doubleArray21 };
        double[][] doubleArray23 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray22);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException24 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray23);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException(1.0d, "evaluation failed for argument = {0}", (java.lang.Object[]) doubleArray23);
        try {
            blockRealMatrix5.copySubMatrix(intArray14, intArray16, doubleArray23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 10 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getJacobianEvaluations();
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker2 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        double[] doubleArray6 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable7 = null;
        double[] doubleArray8 = new double[] {};
        double[][] doubleArray9 = new double[][] { doubleArray8 };
        double[][] doubleArray10 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray9);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException11 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6, localizable7, (java.lang.Object[]) doubleArray9);
        double[] doubleArray17 = new double[] { 10L, '#', 0, 1.0d, '#' };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair19 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray6, doubleArray17, true);
        double[] doubleArray22 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable23 = null;
        double[] doubleArray24 = new double[] {};
        double[][] doubleArray25 = new double[][] { doubleArray24 };
        double[][] doubleArray26 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray25);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException27 = new org.apache.commons.math.FunctionEvaluationException(doubleArray22, localizable23, (java.lang.Object[]) doubleArray25);
        double[] doubleArray33 = new double[] { 10L, '#', 0, 1.0d, '#' };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair35 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray22, doubleArray33, true);
        boolean boolean36 = simpleVectorialValueChecker2.converged(10, vectorialPointValuePair19, vectorialPointValuePair35);
        double[] doubleArray40 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable41 = null;
        double[] doubleArray42 = new double[] {};
        double[][] doubleArray43 = new double[][] { doubleArray42 };
        double[][] doubleArray44 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray43);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException45 = new org.apache.commons.math.FunctionEvaluationException(doubleArray40, localizable41, (java.lang.Object[]) doubleArray43);
        double[] doubleArray51 = new double[] { 10L, '#', 0, 1.0d, '#' };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair53 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray40, doubleArray51, true);
        double[] doubleArray54 = vectorialPointValuePair53.getPoint();
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker55 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        double[] doubleArray59 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable60 = null;
        double[] doubleArray61 = new double[] {};
        double[][] doubleArray62 = new double[][] { doubleArray61 };
        double[][] doubleArray63 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray62);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException64 = new org.apache.commons.math.FunctionEvaluationException(doubleArray59, localizable60, (java.lang.Object[]) doubleArray62);
        double[] doubleArray70 = new double[] { 10L, '#', 0, 1.0d, '#' };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair72 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray59, doubleArray70, true);
        double[] doubleArray75 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable76 = null;
        double[] doubleArray77 = new double[] {};
        double[][] doubleArray78 = new double[][] { doubleArray77 };
        double[][] doubleArray79 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray78);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException80 = new org.apache.commons.math.FunctionEvaluationException(doubleArray75, localizable76, (java.lang.Object[]) doubleArray78);
        double[] doubleArray86 = new double[] { 10L, '#', 0, 1.0d, '#' };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair88 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray75, doubleArray86, true);
        boolean boolean89 = simpleVectorialValueChecker55.converged(10, vectorialPointValuePair72, vectorialPointValuePair88);
        boolean boolean90 = simpleVectorialValueChecker2.converged((int) '#', vectorialPointValuePair53, vectorialPointValuePair72);
        levenbergMarquardtOptimizer0.setConvergenceChecker((org.apache.commons.math.optimization.VectorialConvergenceChecker) simpleVectorialValueChecker2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        double[][] doubleArray3 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException4 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray3);
        java.lang.Throwable[] throwableArray5 = nullPointerException4.getSuppressed();
        org.apache.commons.math.exception.Localizable localizable6 = null;
        double[] doubleArray9 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable10 = null;
        double[] doubleArray11 = new double[] {};
        double[][] doubleArray12 = new double[][] { doubleArray11 };
        double[][] doubleArray13 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray12);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException14 = new org.apache.commons.math.FunctionEvaluationException(doubleArray9, localizable10, (java.lang.Object[]) doubleArray12);
        double[][] doubleArray15 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray12);
        org.apache.commons.math.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) nullPointerException4, localizable6, (java.lang.Object[]) doubleArray15);
        double[] doubleArray23 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException24 = new org.apache.commons.math.FunctionEvaluationException(doubleArray23);
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException30 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray29);
        java.lang.Throwable[] throwableArray31 = nullPointerException30.getSuppressed();
        double[] doubleArray38 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException39 = new org.apache.commons.math.FunctionEvaluationException(doubleArray38);
        org.apache.commons.math.linear.RealMatrix realMatrix40 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray38);
        double[] doubleArray47 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException48 = new org.apache.commons.math.FunctionEvaluationException(doubleArray47);
        java.io.IOException iOException49 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) functionEvaluationException48);
        double[] doubleArray53 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable54 = null;
        double[] doubleArray55 = new double[] {};
        double[][] doubleArray56 = new double[][] { doubleArray55 };
        double[][] doubleArray57 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray56);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException58 = new org.apache.commons.math.FunctionEvaluationException(doubleArray53, localizable54, (java.lang.Object[]) doubleArray56);
        double[][] doubleArray59 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray56);
        java.lang.NullPointerException nullPointerException60 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray59);
        java.lang.Object[] objArray61 = new java.lang.Object[] { nullPointerException30, realMatrix40, functionEvaluationException48, "" };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException62 = new org.apache.commons.math.FunctionEvaluationException(doubleArray23, "hi!", objArray61);
        org.apache.commons.math.linear.BigMatrix bigMatrix63 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(doubleArray23);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException64 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathRuntimeException16, doubleArray23);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException65 = new org.apache.commons.math.FunctionEvaluationException(doubleArray23);
        double[] doubleArray66 = functionEvaluationException65.getArgument();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(nullPointerException4);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(nullPointerException30);
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(realMatrix40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(iOException49);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(nullPointerException60);
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(bigMatrix63);
        org.junit.Assert.assertNotNull(doubleArray66);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        java.lang.Object[] objArray1 = null;
        java.util.NoSuchElementException noSuchElementException2 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("{0}", objArray1);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException4 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) noSuchElementException2, (double) 97);
        org.junit.Assert.assertNotNull(noSuchElementException2);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix5.createMatrix((int) (byte) 100, 52);
        java.lang.String str9 = blockRealMatrix8.toString();
        double double10 = blockRealMatrix8.getFrobeniusNorm();
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = blockRealMatrix8.createMatrix((int) 'a', 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.apache.commons.math.exception.Localizable localizable1 = null;
        double[] doubleArray6 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable7 = null;
        double[] doubleArray8 = new double[] {};
        double[][] doubleArray9 = new double[][] { doubleArray8 };
        double[][] doubleArray10 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray9);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException11 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6, localizable7, (java.lang.Object[]) doubleArray9);
        double[][] doubleArray12 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray9);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray9);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException14 = new org.apache.commons.math.FunctionEvaluationException((double) 0.0f, localizable1, (java.lang.Object[]) doubleArray9);
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix15 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(doubleArray9);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        java.lang.Throwable throwable0 = null;
        double[] doubleArray5 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable6 = null;
        double[] doubleArray7 = new double[] {};
        double[][] doubleArray8 = new double[][] { doubleArray7 };
        double[][] doubleArray9 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray8);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException(doubleArray5, localizable6, (java.lang.Object[]) doubleArray8);
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray8);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(throwable0, 0.0d, "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) doubleArray11);
        java.lang.String str13 = functionEvaluationException12.getPattern();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded" + "'", str13.equals("org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        double[][] doubleArray3 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException4 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray3);
        java.lang.Throwable[] throwableArray5 = nullPointerException4.getSuppressed();
        org.apache.commons.math.exception.Localizable localizable6 = null;
        double[] doubleArray9 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable10 = null;
        double[] doubleArray11 = new double[] {};
        double[][] doubleArray12 = new double[][] { doubleArray11 };
        double[][] doubleArray13 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray12);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException14 = new org.apache.commons.math.FunctionEvaluationException(doubleArray9, localizable10, (java.lang.Object[]) doubleArray12);
        double[][] doubleArray15 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray12);
        org.apache.commons.math.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) nullPointerException4, localizable6, (java.lang.Object[]) doubleArray15);
        double[] doubleArray23 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException24 = new org.apache.commons.math.FunctionEvaluationException(doubleArray23);
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException30 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray29);
        java.lang.Throwable[] throwableArray31 = nullPointerException30.getSuppressed();
        double[] doubleArray38 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException39 = new org.apache.commons.math.FunctionEvaluationException(doubleArray38);
        org.apache.commons.math.linear.RealMatrix realMatrix40 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray38);
        double[] doubleArray47 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException48 = new org.apache.commons.math.FunctionEvaluationException(doubleArray47);
        java.io.IOException iOException49 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) functionEvaluationException48);
        double[] doubleArray53 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable54 = null;
        double[] doubleArray55 = new double[] {};
        double[][] doubleArray56 = new double[][] { doubleArray55 };
        double[][] doubleArray57 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray56);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException58 = new org.apache.commons.math.FunctionEvaluationException(doubleArray53, localizable54, (java.lang.Object[]) doubleArray56);
        double[][] doubleArray59 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray56);
        java.lang.NullPointerException nullPointerException60 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray59);
        java.lang.Object[] objArray61 = new java.lang.Object[] { nullPointerException30, realMatrix40, functionEvaluationException48, "" };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException62 = new org.apache.commons.math.FunctionEvaluationException(doubleArray23, "hi!", objArray61);
        org.apache.commons.math.linear.BigMatrix bigMatrix63 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(doubleArray23);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException64 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathRuntimeException16, doubleArray23);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException65 = new org.apache.commons.math.FunctionEvaluationException(doubleArray23);
        org.apache.commons.math.linear.BigMatrix bigMatrix66 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(doubleArray23);
        double[] doubleArray73 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException74 = new org.apache.commons.math.FunctionEvaluationException(doubleArray73);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair76 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray23, doubleArray73, false);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(nullPointerException4);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(nullPointerException30);
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(realMatrix40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(iOException49);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(nullPointerException60);
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(bigMatrix63);
        org.junit.Assert.assertNotNull(bigMatrix66);
        org.junit.Assert.assertNotNull(doubleArray73);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getDeterminant();
        java.lang.String str3 = array2DRowRealMatrix0.toString();
        double[][] doubleArray4 = array2DRowRealMatrix0.getDataRef();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int6 = array2DRowRealMatrix5.getColumnDimension();
        double[][] doubleArray7 = array2DRowRealMatrix5.getData();
        boolean boolean8 = array2DRowRealMatrix5.isSquare();
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl10 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5, (double) 1.0f);
        int int11 = array2DRowRealMatrix5.getRowDimension();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix12 = array2DRowRealMatrix0.multiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Array2DRowRealMatrix{}" + "'", str3.equals("Array2DRowRealMatrix{}"));
        org.junit.Assert.assertNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.apache.commons.math.exception.Localizable localizable0 = null;
        double[][] doubleArray4 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException5 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray4);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException6 = new org.apache.commons.math.linear.MatrixIndexException(localizable0, (java.lang.Object[]) doubleArray4);
        double[] doubleArray13 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException14 = new org.apache.commons.math.FunctionEvaluationException(doubleArray13);
        org.apache.commons.math.linear.RealMatrix realMatrix15 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray13);
        double[] doubleArray22 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException23 = new org.apache.commons.math.FunctionEvaluationException(doubleArray22);
        org.apache.commons.math.exception.Localizable localizable24 = null;
        double[] doubleArray27 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable28 = null;
        double[] doubleArray29 = new double[] {};
        double[][] doubleArray30 = new double[][] { doubleArray29 };
        double[][] doubleArray31 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray30);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException32 = new org.apache.commons.math.FunctionEvaluationException(doubleArray27, localizable28, (java.lang.Object[]) doubleArray30);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException33 = new org.apache.commons.math.FunctionEvaluationException(doubleArray22, localizable24, (java.lang.Object[]) doubleArray30);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair35 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray13, doubleArray22, true);
        org.apache.commons.math.exception.Localizable localizable37 = null;
        double[][] doubleArray41 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException42 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException43 = new org.apache.commons.math.linear.MatrixIndexException(localizable37, (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) matrixIndexException6, doubleArray13, "{0}", (java.lang.Object[]) doubleArray41);
        double[] doubleArray48 = new double[] {};
        double[][] doubleArray49 = new double[][] { doubleArray48 };
        double[][] doubleArray50 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray49);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException51 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray50);
        double[] doubleArray55 = new double[] {};
        double[][] doubleArray56 = new double[][] { doubleArray55 };
        double[][] doubleArray57 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray56);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException58 = new org.apache.commons.math.MaxEvaluationsExceededException(10, "", (java.lang.Object[]) doubleArray56);
        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException((java.lang.Throwable) maxEvaluationsExceededException51, "hi!", (java.lang.Object[]) doubleArray56);
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException44, "Array2DRowRealMatrix{}", (java.lang.Object[]) doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(nullPointerException5);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(nullPointerException42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getDeterminant();
        try {
            org.apache.commons.math.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix0, 100, (int) (byte) 0, (int) ' ', 52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        boolean boolean6 = blockRealMatrix2.isSquare();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor7 = null;
        try {
            double double8 = blockRealMatrix2.walkInRowOrder(realMatrixChangingVisitor7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double14 = blockRealMatrix13.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix10.subtract(blockRealMatrix13);
        boolean boolean17 = blockRealMatrix15.equals((java.lang.Object) 100.0d);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) blockRealMatrix15);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double22 = blockRealMatrix21.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix23 = blockRealMatrix21.transpose();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double27 = blockRealMatrix26.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix28 = blockRealMatrix23.multiply(blockRealMatrix26);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix29 = blockRealMatrix15.multiply((org.apache.commons.math.linear.RealMatrix) blockRealMatrix28);
        try {
            org.apache.commons.math.linear.RealVector realVector31 = blockRealMatrix28.getRowVector(2147483647);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 2,147,483,647 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix23);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix28);
        org.junit.Assert.assertNotNull(blockRealMatrix29);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, (int) ' ');
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix5 = array2DRowRealMatrix2.createMatrix(10, 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.RealVector realVector5 = blockRealMatrix2.getColumnVector((int) (short) 1);
        int[] intArray12 = new int[] { (short) 10, (byte) 1, 'a', (short) 100, 10, (byte) 100 };
        int[] intArray13 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix2, intArray12, intArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(intArray12);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double8 = blockRealMatrix7.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix4.multiply(blockRealMatrix7);
        double[] doubleArray12 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable13 = null;
        double[] doubleArray14 = new double[] {};
        double[][] doubleArray15 = new double[][] { doubleArray14 };
        double[][] doubleArray16 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray15);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException(doubleArray12, localizable13, (java.lang.Object[]) doubleArray15);
        double[] doubleArray23 = new double[] { 10L, '#', 0, 1.0d, '#' };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair25 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray12, doubleArray23, true);
        org.apache.commons.math.linear.RealMatrix realMatrix26 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray12);
        try {
            double[] doubleArray27 = blockRealMatrix4.operate(doubleArray12);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix26);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException();
        double[] doubleArray7 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable8 = null;
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(doubleArray7, localizable8, (java.lang.Object[]) doubleArray10);
        double[][] doubleArray13 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray10);
        int int15 = maxIterationsExceededException14.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable16 = maxIterationsExceededException14.getLocalizablePattern();
        double[] doubleArray22 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable23 = null;
        double[] doubleArray24 = new double[] {};
        double[][] doubleArray25 = new double[][] { doubleArray24 };
        double[][] doubleArray26 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray25);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException27 = new org.apache.commons.math.FunctionEvaluationException(doubleArray22, localizable23, (java.lang.Object[]) doubleArray25);
        double[][] doubleArray28 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray25);
        int int30 = maxIterationsExceededException29.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable31 = maxIterationsExceededException29.getLocalizablePattern();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException33 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray34 = functionEvaluationException33.getSuppressed();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException35 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a', localizable31, (java.lang.Object[]) throwableArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException2, localizable16, (java.lang.Object[]) throwableArray34);
        java.lang.Object[] objArray37 = null;
        java.lang.NullPointerException nullPointerException38 = org.apache.commons.math.MathRuntimeException.createNullPointerException(localizable16, objArray37);
        org.apache.commons.math.exception.Localizable localizable39 = null;
        double[] doubleArray42 = new double[] {};
        double[][] doubleArray43 = new double[][] { doubleArray42 };
        double[][] doubleArray44 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray43);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException45 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray44);
        org.apache.commons.math.exception.Localizable localizable46 = null;
        double[][] doubleArray49 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxEvaluationsExceededException45, localizable46, (java.lang.Object[]) doubleArray49);
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException(localizable39, (java.lang.Object[]) doubleArray49);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException52 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 1, localizable16, (java.lang.Object[]) doubleArray49);
        java.io.EOFException eOFException53 = org.apache.commons.math.MathRuntimeException.createEOFException("org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 52 + "'", int15 == 52);
        org.junit.Assert.assertNotNull(localizable16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 52 + "'", int30 == 52);
        org.junit.Assert.assertNotNull(localizable31);
        org.junit.Assert.assertNotNull(throwableArray34);
        org.junit.Assert.assertNotNull(nullPointerException38);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(eOFException53);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        boolean boolean3 = array2DRowRealMatrix0.isSquare();
        double[][] doubleArray4 = array2DRowRealMatrix0.getDataRef();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(doubleArray4);
    }
}

