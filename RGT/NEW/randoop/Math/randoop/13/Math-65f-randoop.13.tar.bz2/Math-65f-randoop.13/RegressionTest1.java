import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix7.copy();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix8.copy();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix8.scalarAdd(0.0d);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor12 = null;
        try {
            double double13 = blockRealMatrix8.walkInOptimizedOrder(realMatrixPreservingVisitor12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        double[] doubleArray6 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException7 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray6);
        double[] doubleArray15 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException(doubleArray15);
        org.apache.commons.math.exception.Localizable localizable17 = null;
        double[] doubleArray20 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable21 = null;
        double[] doubleArray22 = new double[] {};
        double[][] doubleArray23 = new double[][] { doubleArray22 };
        double[][] doubleArray24 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray23);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException(doubleArray20, localizable21, (java.lang.Object[]) doubleArray23);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException26 = new org.apache.commons.math.FunctionEvaluationException(doubleArray15, localizable17, (java.lang.Object[]) doubleArray23);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair28 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray6, doubleArray15, true);
        double[] doubleArray29 = vectorialPointValuePair28.getPoint();
        double[] doubleArray30 = vectorialPointValuePair28.getPointRef();
        double[] doubleArray36 = new double[] { 100.0f, (short) 1, (byte) -1, '4', 100 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair37 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray30, doubleArray36);
        double[] doubleArray38 = vectorialPointValuePair37.getPointRef();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        double[] doubleArray6 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException7 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6);
        double[] doubleArray8 = functionEvaluationException7.getArgument();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getJacobianEvaluations();
        levenbergMarquardtOptimizer0.setCostRelativeTolerance(0.0d);
        double double4 = levenbergMarquardtOptimizer0.getChiSquare();
        org.apache.commons.math.optimization.VectorialConvergenceChecker vectorialConvergenceChecker5 = levenbergMarquardtOptimizer0.getConvergenceChecker();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNull(vectorialConvergenceChecker5);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        org.apache.commons.math.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix5, (int) (short) 0);
        blockRealMatrix5.addToEntry((int) (byte) 0, (int) (byte) 0, (double) (-1L));
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix16 = blockRealMatrix5.getSubMatrix(2147483647, 0, 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 2,147,483,647 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        double double6 = blockRealMatrix5.getNorm();
        double double7 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor8 = null;
        try {
            double double9 = blockRealMatrix5.walkInOptimizedOrder(realMatrixPreservingVisitor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double[][] doubleArray2 = array2DRowRealMatrix0.getData();
        boolean boolean3 = array2DRowRealMatrix0.isSquare();
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl5 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix0, (double) 1.0f);
        double double6 = lUDecompositionImpl5.getDeterminant();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix7.copy();
        try {
            blockRealMatrix8.addToEntry((int) (byte) -1, (int) (short) 0, 1.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (-1, 0) in a 35x10 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double[] doubleArray12 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException13 = new org.apache.commons.math.FunctionEvaluationException(doubleArray12);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray12);
        double[] doubleArray21 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException22 = new org.apache.commons.math.FunctionEvaluationException(doubleArray21);
        org.apache.commons.math.exception.Localizable localizable23 = null;
        double[] doubleArray26 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable27 = null;
        double[] doubleArray28 = new double[] {};
        double[][] doubleArray29 = new double[][] { doubleArray28 };
        double[][] doubleArray30 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray29);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException31 = new org.apache.commons.math.FunctionEvaluationException(doubleArray26, localizable27, (java.lang.Object[]) doubleArray29);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException32 = new org.apache.commons.math.FunctionEvaluationException(doubleArray21, localizable23, (java.lang.Object[]) doubleArray29);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair34 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray12, doubleArray21, true);
        double[] doubleArray35 = vectorialPointValuePair34.getPoint();
        double[] doubleArray36 = vectorialPointValuePair34.getPoint();
        org.apache.commons.math.linear.RealVector realVector37 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray36);
        try {
            blockRealMatrix2.setColumnVector((int) (short) 10, realVector37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 10 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector37);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        double[][] doubleArray3 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException4 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray3);
        java.lang.Throwable[] throwableArray5 = nullPointerException4.getSuppressed();
        org.apache.commons.math.exception.Localizable localizable6 = null;
        double[] doubleArray9 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable10 = null;
        double[] doubleArray11 = new double[] {};
        double[][] doubleArray12 = new double[][] { doubleArray11 };
        double[][] doubleArray13 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray12);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException14 = new org.apache.commons.math.FunctionEvaluationException(doubleArray9, localizable10, (java.lang.Object[]) doubleArray12);
        double[][] doubleArray15 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray12);
        org.apache.commons.math.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) nullPointerException4, localizable6, (java.lang.Object[]) doubleArray15);
        double[] doubleArray23 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException24 = new org.apache.commons.math.FunctionEvaluationException(doubleArray23);
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException30 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray29);
        java.lang.Throwable[] throwableArray31 = nullPointerException30.getSuppressed();
        double[] doubleArray38 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException39 = new org.apache.commons.math.FunctionEvaluationException(doubleArray38);
        org.apache.commons.math.linear.RealMatrix realMatrix40 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray38);
        double[] doubleArray47 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException48 = new org.apache.commons.math.FunctionEvaluationException(doubleArray47);
        java.io.IOException iOException49 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) functionEvaluationException48);
        double[] doubleArray53 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable54 = null;
        double[] doubleArray55 = new double[] {};
        double[][] doubleArray56 = new double[][] { doubleArray55 };
        double[][] doubleArray57 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray56);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException58 = new org.apache.commons.math.FunctionEvaluationException(doubleArray53, localizable54, (java.lang.Object[]) doubleArray56);
        double[][] doubleArray59 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray56);
        java.lang.NullPointerException nullPointerException60 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray59);
        java.lang.Object[] objArray61 = new java.lang.Object[] { nullPointerException30, realMatrix40, functionEvaluationException48, "" };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException62 = new org.apache.commons.math.FunctionEvaluationException(doubleArray23, "hi!", objArray61);
        org.apache.commons.math.linear.BigMatrix bigMatrix63 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(doubleArray23);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException64 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathRuntimeException16, doubleArray23);
        double[] doubleArray65 = functionEvaluationException64.getArgument();
        java.lang.String str66 = functionEvaluationException64.toString();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(nullPointerException4);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(nullPointerException30);
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(realMatrix40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(iOException49);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(nullPointerException60);
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(bigMatrix63);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "org.apache.commons.math.FunctionEvaluationException: " + "'", str66.equals("org.apache.commons.math.FunctionEvaluationException: "));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getJacobianEvaluations();
        levenbergMarquardtOptimizer0.setCostRelativeTolerance(0.0d);
        int int4 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker7 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker(0.0d, (double) '4');
        double[] doubleArray15 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException(doubleArray15);
        org.apache.commons.math.linear.RealMatrix realMatrix17 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray15);
        double[] doubleArray24 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException(doubleArray24);
        org.apache.commons.math.exception.Localizable localizable26 = null;
        double[] doubleArray29 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable30 = null;
        double[] doubleArray31 = new double[] {};
        double[][] doubleArray32 = new double[][] { doubleArray31 };
        double[][] doubleArray33 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray32);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException34 = new org.apache.commons.math.FunctionEvaluationException(doubleArray29, localizable30, (java.lang.Object[]) doubleArray32);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException35 = new org.apache.commons.math.FunctionEvaluationException(doubleArray24, localizable26, (java.lang.Object[]) doubleArray32);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair37 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray15, doubleArray24, true);
        double[] doubleArray38 = vectorialPointValuePair37.getPoint();
        double[] doubleArray39 = vectorialPointValuePair37.getPointRef();
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker40 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        double[] doubleArray44 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable45 = null;
        double[] doubleArray46 = new double[] {};
        double[][] doubleArray47 = new double[][] { doubleArray46 };
        double[][] doubleArray48 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray47);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException49 = new org.apache.commons.math.FunctionEvaluationException(doubleArray44, localizable45, (java.lang.Object[]) doubleArray47);
        double[] doubleArray55 = new double[] { 10L, '#', 0, 1.0d, '#' };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair57 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray44, doubleArray55, true);
        double[] doubleArray60 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable61 = null;
        double[] doubleArray62 = new double[] {};
        double[][] doubleArray63 = new double[][] { doubleArray62 };
        double[][] doubleArray64 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray63);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException65 = new org.apache.commons.math.FunctionEvaluationException(doubleArray60, localizable61, (java.lang.Object[]) doubleArray63);
        double[] doubleArray71 = new double[] { 10L, '#', 0, 1.0d, '#' };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair73 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray60, doubleArray71, true);
        boolean boolean74 = simpleVectorialValueChecker40.converged(10, vectorialPointValuePair57, vectorialPointValuePair73);
        boolean boolean75 = simpleVectorialValueChecker7.converged((int) (short) 100, vectorialPointValuePair37, vectorialPointValuePair57);
        levenbergMarquardtOptimizer0.setConvergenceChecker((org.apache.commons.math.optimization.VectorialConvergenceChecker) simpleVectorialValueChecker7);
        levenbergMarquardtOptimizer0.setQRRankingThreshold((double) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException12 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray11);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray11);
        double[] doubleArray21 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException22 = new org.apache.commons.math.FunctionEvaluationException(doubleArray21);
        org.apache.commons.math.exception.Localizable localizable23 = null;
        double[] doubleArray26 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable27 = null;
        double[] doubleArray28 = new double[] {};
        double[][] doubleArray29 = new double[][] { doubleArray28 };
        double[][] doubleArray30 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray29);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException31 = new org.apache.commons.math.FunctionEvaluationException(doubleArray26, localizable27, (java.lang.Object[]) doubleArray29);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException32 = new org.apache.commons.math.FunctionEvaluationException(doubleArray21, localizable23, (java.lang.Object[]) doubleArray29);
        double[][] doubleArray33 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray29);
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException13, "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) doubleArray29);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException(1, "hi!", (java.lang.Object[]) doubleArray29);
        java.lang.NullPointerException nullPointerException36 = org.apache.commons.math.MathRuntimeException.createNullPointerException("{0}", (java.lang.Object[]) doubleArray29);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "org.apache.commons.math.FunctionEvaluationException: ", (java.lang.Object[]) doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(nullPointerException36);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, (int) ' ');
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor3 = null;
        try {
            double double4 = array2DRowRealMatrix2.walkInRowOrder(realMatrixChangingVisitor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        double[] doubleArray2 = new double[] {};
        double[][] doubleArray3 = new double[][] { doubleArray2 };
        double[][] doubleArray4 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray3);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException5 = new org.apache.commons.math.MaxEvaluationsExceededException(10, "", (java.lang.Object[]) doubleArray3);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException7 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxEvaluationsExceededException5, (double) 1);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException8 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable) maxEvaluationsExceededException5);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getDeterminant();
        java.lang.String str3 = array2DRowRealMatrix0.toString();
        double double4 = array2DRowRealMatrix0.getDeterminant();
        double[][] doubleArray5 = array2DRowRealMatrix0.getDataRef();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean7 = array2DRowRealMatrix6.isSquare();
        boolean boolean8 = array2DRowRealMatrix6.isSingular();
        org.apache.commons.math.linear.RealMatrix realMatrix11 = array2DRowRealMatrix6.createMatrix((int) '#', 1);
        org.apache.commons.math.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Array2DRowRealMatrix{}" + "'", str3.equals("Array2DRowRealMatrix{}"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix7.copy();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix8.copy();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix8.scalarAdd(0.0d);
        int int12 = blockRealMatrix8.getColumnDimension();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double16 = blockRealMatrix15.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix15.getRowMatrix(0);
        double double19 = blockRealMatrix18.getNorm();
        double double20 = blockRealMatrix18.getFrobeniusNorm();
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix21 = blockRealMatrix8.multiply(blockRealMatrix18);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException1 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 0);
        java.lang.String str2 = maxEvaluationsExceededException1.toString();
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.MathRuntimeException(throwable3);
        double[] doubleArray10 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable11 = null;
        double[] doubleArray12 = new double[] {};
        double[][] doubleArray13 = new double[][] { doubleArray12 };
        double[][] doubleArray14 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray13);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException(doubleArray10, localizable11, (java.lang.Object[]) doubleArray13);
        double[][] doubleArray16 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray13);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray13);
        int int18 = maxIterationsExceededException17.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable19 = maxIterationsExceededException17.getLocalizablePattern();
        double[] doubleArray22 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable23 = null;
        double[] doubleArray24 = new double[] {};
        double[][] doubleArray25 = new double[][] { doubleArray24 };
        double[][] doubleArray26 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray25);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException27 = new org.apache.commons.math.FunctionEvaluationException(doubleArray22, localizable23, (java.lang.Object[]) doubleArray25);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException28 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) (short) 100, localizable19, (java.lang.Object[]) doubleArray25);
        double[] doubleArray33 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[] doubleArray35 = new double[] {};
        double[][] doubleArray36 = new double[][] { doubleArray35 };
        double[][] doubleArray37 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray36);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException38 = new org.apache.commons.math.FunctionEvaluationException(doubleArray33, localizable34, (java.lang.Object[]) doubleArray36);
        double[][] doubleArray39 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray36);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException40 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray36);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxEvaluationsExceededException1, localizable19, (java.lang.Object[]) doubleArray36);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException42 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable) maxEvaluationsExceededException1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded" + "'", str2.equals("org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded"));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 52 + "'", int18 == 52);
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean3 = array2DRowRealMatrix2.isSquare();
        boolean boolean4 = array2DRowRealMatrix2.isSingular();
        org.apache.commons.math.linear.RealMatrix realMatrix7 = array2DRowRealMatrix2.createMatrix((int) '#', 1);
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = array2DRowRealMatrix0.add(array2DRowRealMatrix2);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(realMatrix7);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        boolean boolean6 = blockRealMatrix2.isSquare();
        org.apache.commons.math.linear.RealMatrix realMatrix8 = blockRealMatrix2.scalarMultiply((double) (short) -1);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = blockRealMatrix2.getColumnMatrix((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix10);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray4 };
        double[][] doubleArray6 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray5);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException7 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray6);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray6);
        double[] doubleArray16 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException(doubleArray16);
        org.apache.commons.math.exception.Localizable localizable18 = null;
        double[] doubleArray21 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable22 = null;
        double[] doubleArray23 = new double[] {};
        double[][] doubleArray24 = new double[][] { doubleArray23 };
        double[][] doubleArray25 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray24);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException26 = new org.apache.commons.math.FunctionEvaluationException(doubleArray21, localizable22, (java.lang.Object[]) doubleArray24);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException27 = new org.apache.commons.math.FunctionEvaluationException(doubleArray16, localizable18, (java.lang.Object[]) doubleArray24);
        double[][] doubleArray28 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray24);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException8, "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) doubleArray24);
        double[] doubleArray36 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException37 = new org.apache.commons.math.FunctionEvaluationException(doubleArray36);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException38 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException8, doubleArray36);
        double[] doubleArray39 = functionEvaluationException38.getArgument();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix7.copy();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix8.copy();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix8.scalarAdd(0.0d);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = blockRealMatrix11.scalarMultiply((double) 1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(realMatrix13);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        int[] intArray6 = new int[] {};
        int[] intArray9 = new int[] { 36, (byte) 10 };
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix10 = blockRealMatrix5.getSubMatrix(intArray6, intArray9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: empty selected row index array");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray9);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        double[][] doubleArray2 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(0, 0);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        double[] doubleArray6 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException7 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6);
        org.apache.commons.math.linear.BigMatrix bigMatrix8 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray6);
        org.apache.commons.math.linear.BigMatrix bigMatrix9 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(bigMatrix8);
        org.junit.Assert.assertNotNull(bigMatrix9);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix7.copy();
        try {
            double[] doubleArray10 = blockRealMatrix8.getColumn((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index -1 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math.exception.Localizable localizable3 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray6 = functionEvaluationException5.getSuppressed();
        org.apache.commons.math.MathRuntimeException mathRuntimeException7 = new org.apache.commons.math.MathRuntimeException(throwable2, localizable3, (java.lang.Object[]) throwableArray6);
        java.text.ParseException parseException8 = org.apache.commons.math.MathRuntimeException.createParseException((int) (short) -1, "org.apache.commons.math.FunctionEvaluationException: ", (java.lang.Object[]) throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(parseException8);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math.MathRuntimeException mathRuntimeException2 = new org.apache.commons.math.MathRuntimeException(throwable1);
        double[] doubleArray8 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable9 = null;
        double[] doubleArray10 = new double[] {};
        double[][] doubleArray11 = new double[][] { doubleArray10 };
        double[][] doubleArray12 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray11);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException13 = new org.apache.commons.math.FunctionEvaluationException(doubleArray8, localizable9, (java.lang.Object[]) doubleArray11);
        double[][] doubleArray14 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray11);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray11);
        int int16 = maxIterationsExceededException15.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable17 = maxIterationsExceededException15.getLocalizablePattern();
        double[] doubleArray20 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable21 = null;
        double[] doubleArray22 = new double[] {};
        double[][] doubleArray23 = new double[][] { doubleArray22 };
        double[][] doubleArray24 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray23);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException(doubleArray20, localizable21, (java.lang.Object[]) doubleArray23);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException26 = new org.apache.commons.math.FunctionEvaluationException(throwable1, (double) (short) 100, localizable17, (java.lang.Object[]) doubleArray23);
        double[] doubleArray31 = new double[] {};
        double[][] doubleArray32 = new double[][] { doubleArray31 };
        double[][] doubleArray33 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray32);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException34 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray33);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray33);
        double[] doubleArray43 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException(doubleArray43);
        org.apache.commons.math.exception.Localizable localizable45 = null;
        double[] doubleArray48 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable49 = null;
        double[] doubleArray50 = new double[] {};
        double[][] doubleArray51 = new double[][] { doubleArray50 };
        double[][] doubleArray52 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray51);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException53 = new org.apache.commons.math.FunctionEvaluationException(doubleArray48, localizable49, (java.lang.Object[]) doubleArray51);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException54 = new org.apache.commons.math.FunctionEvaluationException(doubleArray43, localizable45, (java.lang.Object[]) doubleArray51);
        double[][] doubleArray55 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray51);
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException35, "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) doubleArray51);
        java.lang.UnsupportedOperationException unsupportedOperationException57 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException(localizable17, (java.lang.Object[]) doubleArray51);
        org.apache.commons.math.optimization.OptimizationException optimizationException58 = new org.apache.commons.math.optimization.OptimizationException("org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 52 + "'", int16 == 52);
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(unsupportedOperationException57);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double14 = blockRealMatrix13.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix10.subtract(blockRealMatrix13);
        boolean boolean17 = blockRealMatrix15.equals((java.lang.Object) 100.0d);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) blockRealMatrix15);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double22 = blockRealMatrix21.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix23 = blockRealMatrix21.transpose();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double27 = blockRealMatrix26.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix28 = blockRealMatrix23.multiply(blockRealMatrix26);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix29 = blockRealMatrix15.multiply((org.apache.commons.math.linear.RealMatrix) blockRealMatrix28);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl30 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) blockRealMatrix28);
        org.apache.commons.math.linear.DecompositionSolver decompositionSolver31 = lUDecompositionImpl30.getSolver();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix23);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix28);
        org.junit.Assert.assertNotNull(blockRealMatrix29);
        org.junit.Assert.assertNotNull(decompositionSolver31);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker0 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        double[] doubleArray4 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[][] doubleArray7 = new double[][] { doubleArray6 };
        double[][] doubleArray8 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray7);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException(doubleArray4, localizable5, (java.lang.Object[]) doubleArray7);
        double[] doubleArray15 = new double[] { 10L, '#', 0, 1.0d, '#' };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair17 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray4, doubleArray15, true);
        double[] doubleArray20 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable21 = null;
        double[] doubleArray22 = new double[] {};
        double[][] doubleArray23 = new double[][] { doubleArray22 };
        double[][] doubleArray24 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray23);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException(doubleArray20, localizable21, (java.lang.Object[]) doubleArray23);
        double[] doubleArray31 = new double[] { 10L, '#', 0, 1.0d, '#' };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair33 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray20, doubleArray31, true);
        boolean boolean34 = simpleVectorialValueChecker0.converged(10, vectorialPointValuePair17, vectorialPointValuePair33);
        double[] doubleArray35 = vectorialPointValuePair17.getPointRef();
        java.lang.Throwable throwable36 = null;
        org.apache.commons.math.MathRuntimeException mathRuntimeException37 = new org.apache.commons.math.MathRuntimeException(throwable36);
        double[] doubleArray43 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable44 = null;
        double[] doubleArray45 = new double[] {};
        double[][] doubleArray46 = new double[][] { doubleArray45 };
        double[][] doubleArray47 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray46);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException48 = new org.apache.commons.math.FunctionEvaluationException(doubleArray43, localizable44, (java.lang.Object[]) doubleArray46);
        double[][] doubleArray49 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray46);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException50 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray46);
        int int51 = maxIterationsExceededException50.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable52 = maxIterationsExceededException50.getLocalizablePattern();
        double[] doubleArray55 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable56 = null;
        double[] doubleArray57 = new double[] {};
        double[][] doubleArray58 = new double[][] { doubleArray57 };
        double[][] doubleArray59 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray58);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException60 = new org.apache.commons.math.FunctionEvaluationException(doubleArray55, localizable56, (java.lang.Object[]) doubleArray58);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException61 = new org.apache.commons.math.FunctionEvaluationException(throwable36, (double) (short) 100, localizable52, (java.lang.Object[]) doubleArray58);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException63 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray64 = functionEvaluationException63.getSuppressed();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException65 = new org.apache.commons.math.FunctionEvaluationException(doubleArray35, localizable52, (java.lang.Object[]) throwableArray64);
        java.lang.Object[] objArray66 = functionEvaluationException65.getArguments();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 52 + "'", int51 == 52);
        org.junit.Assert.assertNotNull(localizable52);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(throwableArray64);
        org.junit.Assert.assertNotNull(objArray66);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException2 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 0);
        org.apache.commons.math.exception.Localizable localizable3 = null;
        double[][] doubleArray7 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException8 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray7);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException9 = new org.apache.commons.math.linear.MatrixIndexException(localizable3, (java.lang.Object[]) doubleArray7);
        double[] doubleArray16 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException(doubleArray16);
        org.apache.commons.math.linear.RealMatrix realMatrix18 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray16);
        double[] doubleArray25 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException26 = new org.apache.commons.math.FunctionEvaluationException(doubleArray25);
        org.apache.commons.math.exception.Localizable localizable27 = null;
        double[] doubleArray30 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable31 = null;
        double[] doubleArray32 = new double[] {};
        double[][] doubleArray33 = new double[][] { doubleArray32 };
        double[][] doubleArray34 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray33);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException35 = new org.apache.commons.math.FunctionEvaluationException(doubleArray30, localizable31, (java.lang.Object[]) doubleArray33);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException(doubleArray25, localizable27, (java.lang.Object[]) doubleArray33);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair38 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray16, doubleArray25, true);
        org.apache.commons.math.exception.Localizable localizable40 = null;
        double[][] doubleArray44 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException45 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray44);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException46 = new org.apache.commons.math.linear.MatrixIndexException(localizable40, (java.lang.Object[]) doubleArray44);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException47 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) matrixIndexException9, doubleArray16, "{0}", (java.lang.Object[]) doubleArray44);
        org.apache.commons.math.exception.Localizable localizable48 = null;
        double[] doubleArray55 = new double[] {};
        double[][] doubleArray56 = new double[][] { doubleArray55 };
        double[][] doubleArray57 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray56);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException58 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray57);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException59 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray57);
        double[] doubleArray67 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException68 = new org.apache.commons.math.FunctionEvaluationException(doubleArray67);
        org.apache.commons.math.exception.Localizable localizable69 = null;
        double[] doubleArray72 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable73 = null;
        double[] doubleArray74 = new double[] {};
        double[][] doubleArray75 = new double[][] { doubleArray74 };
        double[][] doubleArray76 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray75);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException77 = new org.apache.commons.math.FunctionEvaluationException(doubleArray72, localizable73, (java.lang.Object[]) doubleArray75);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException78 = new org.apache.commons.math.FunctionEvaluationException(doubleArray67, localizable69, (java.lang.Object[]) doubleArray75);
        double[][] doubleArray79 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray75);
        org.apache.commons.math.MathException mathException80 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException59, "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) doubleArray75);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException81 = new org.apache.commons.math.MaxIterationsExceededException(1, "hi!", (java.lang.Object[]) doubleArray75);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException82 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxEvaluationsExceededException2, doubleArray16, localizable48, (java.lang.Object[]) doubleArray75);
        java.lang.IllegalArgumentException illegalArgumentException83 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", (java.lang.Object[]) doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(nullPointerException8);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(nullPointerException45);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(illegalArgumentException83);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.RealVector realVector5 = blockRealMatrix2.getColumnVector((int) (short) 1);
        java.lang.Class<?> wildcardClass6 = blockRealMatrix2.getClass();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException1 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 0);
        java.lang.String str2 = maxEvaluationsExceededException1.toString();
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.MathRuntimeException(throwable3);
        double[] doubleArray10 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable11 = null;
        double[] doubleArray12 = new double[] {};
        double[][] doubleArray13 = new double[][] { doubleArray12 };
        double[][] doubleArray14 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray13);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException(doubleArray10, localizable11, (java.lang.Object[]) doubleArray13);
        double[][] doubleArray16 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray13);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray13);
        int int18 = maxIterationsExceededException17.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable19 = maxIterationsExceededException17.getLocalizablePattern();
        double[] doubleArray22 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable23 = null;
        double[] doubleArray24 = new double[] {};
        double[][] doubleArray25 = new double[][] { doubleArray24 };
        double[][] doubleArray26 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray25);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException27 = new org.apache.commons.math.FunctionEvaluationException(doubleArray22, localizable23, (java.lang.Object[]) doubleArray25);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException28 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) (short) 100, localizable19, (java.lang.Object[]) doubleArray25);
        double[] doubleArray33 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable34 = null;
        double[] doubleArray35 = new double[] {};
        double[][] doubleArray36 = new double[][] { doubleArray35 };
        double[][] doubleArray37 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray36);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException38 = new org.apache.commons.math.FunctionEvaluationException(doubleArray33, localizable34, (java.lang.Object[]) doubleArray36);
        double[][] doubleArray39 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray36);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException40 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray36);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxEvaluationsExceededException1, localizable19, (java.lang.Object[]) doubleArray36);
        double[][] doubleArray45 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException46 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray45);
        org.apache.commons.math.exception.Localizable localizable48 = null;
        double[] doubleArray51 = new double[] {};
        double[][] doubleArray52 = new double[][] { doubleArray51 };
        double[][] doubleArray53 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray52);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException54 = new org.apache.commons.math.MaxEvaluationsExceededException(10, "", (java.lang.Object[]) doubleArray52);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException55 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException46, (double) (short) -1, localizable48, (java.lang.Object[]) doubleArray52);
        java.io.EOFException eOFException56 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable19, (java.lang.Object[]) doubleArray52);
        double[] doubleArray60 = new double[] {};
        double[][] doubleArray61 = new double[][] { doubleArray60 };
        double[][] doubleArray62 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray61);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException63 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray62);
        java.lang.IllegalArgumentException illegalArgumentException64 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", (java.lang.Object[]) doubleArray62);
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException(localizable19, (java.lang.Object[]) doubleArray62);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int67 = array2DRowRealMatrix66.getColumnDimension();
        double[][] doubleArray68 = array2DRowRealMatrix66.getData();
        java.lang.NullPointerException nullPointerException69 = org.apache.commons.math.MathRuntimeException.createNullPointerException(localizable19, (java.lang.Object[]) doubleArray68);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded" + "'", str2.equals("org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded"));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 52 + "'", int18 == 52);
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(nullPointerException46);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(eOFException56);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(illegalArgumentException64);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(nullPointerException69);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        double[] doubleArray6 = new double[] {};
        double[][] doubleArray7 = new double[][] { doubleArray6 };
        double[][] doubleArray8 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray7);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException9 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray8);
        double[] doubleArray18 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException19 = new org.apache.commons.math.FunctionEvaluationException(doubleArray18);
        org.apache.commons.math.exception.Localizable localizable20 = null;
        double[] doubleArray23 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable24 = null;
        double[] doubleArray25 = new double[] {};
        double[][] doubleArray26 = new double[][] { doubleArray25 };
        double[][] doubleArray27 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray26);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException28 = new org.apache.commons.math.FunctionEvaluationException(doubleArray23, localizable24, (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException(doubleArray18, localizable20, (java.lang.Object[]) doubleArray26);
        double[][] doubleArray30 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray26);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException10, "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) doubleArray26);
        java.util.NoSuchElementException noSuchElementException32 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("evaluation failed for argument = {0}", (java.lang.Object[]) doubleArray26);
        java.util.ConcurrentModificationException concurrentModificationException33 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(noSuchElementException32);
        org.junit.Assert.assertNotNull(concurrentModificationException33);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        org.apache.commons.math.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix5, (int) (short) 0);
        blockRealMatrix5.addToEntry((int) (byte) 0, (int) (byte) 0, (double) (-1L));
        boolean boolean12 = blockRealMatrix5.isSquare();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        boolean boolean2 = array2DRowRealMatrix0.isSingular();
        org.apache.commons.math.linear.RealMatrix realMatrix5 = array2DRowRealMatrix0.createMatrix((int) '#', 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double9 = blockRealMatrix8.getFrobeniusNorm();
        double[] doubleArray11 = blockRealMatrix8.getRow(10);
        double[] doubleArray13 = blockRealMatrix8.getRow(10);
        try {
            double[] doubleArray14 = array2DRowRealMatrix0.preMultiply(doubleArray13);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        double[] doubleArray5 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable6 = null;
        double[] doubleArray7 = new double[] {};
        double[][] doubleArray8 = new double[][] { doubleArray7 };
        double[][] doubleArray9 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray8);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException(doubleArray5, localizable6, (java.lang.Object[]) doubleArray8);
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray8);
        int int13 = maxIterationsExceededException12.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable14 = maxIterationsExceededException12.getLocalizablePattern();
        double[] doubleArray20 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable21 = null;
        double[] doubleArray22 = new double[] {};
        double[][] doubleArray23 = new double[][] { doubleArray22 };
        double[][] doubleArray24 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray23);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException(doubleArray20, localizable21, (java.lang.Object[]) doubleArray23);
        double[][] doubleArray26 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray23);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray23);
        int int28 = maxIterationsExceededException27.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable29 = maxIterationsExceededException27.getLocalizablePattern();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException31 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray32 = functionEvaluationException31.getSuppressed();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException33 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a', localizable29, (java.lang.Object[]) throwableArray32);
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException0, localizable14, (java.lang.Object[]) throwableArray32);
        java.lang.Object[] objArray35 = null;
        java.lang.NullPointerException nullPointerException36 = org.apache.commons.math.MathRuntimeException.createNullPointerException(localizable14, objArray35);
        java.lang.RuntimeException runtimeException37 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) nullPointerException36);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 52 + "'", int13 == 52);
        org.junit.Assert.assertNotNull(localizable14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 52 + "'", int28 == 52);
        org.junit.Assert.assertNotNull(localizable29);
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertNotNull(nullPointerException36);
        org.junit.Assert.assertNotNull(runtimeException37);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        java.lang.Throwable throwable5 = null;
        org.apache.commons.math.exception.Localizable localizable6 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException8 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray9 = functionEvaluationException8.getSuppressed();
        org.apache.commons.math.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.MathRuntimeException(throwable5, localizable6, (java.lang.Object[]) throwableArray9);
        java.text.ParseException parseException11 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) throwableArray9);
        java.lang.ArithmeticException arithmeticException12 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", (java.lang.Object[]) throwableArray9);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException13 = new org.apache.commons.math.FunctionEvaluationException((double) 1.0f, "", (java.lang.Object[]) throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(parseException11);
        org.junit.Assert.assertNotNull(arithmeticException12);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        double[] doubleArray8 = new double[] {};
        double[][] doubleArray9 = new double[][] { doubleArray8 };
        double[][] doubleArray10 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray9);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException11 = new org.apache.commons.math.MaxEvaluationsExceededException(10, "", (java.lang.Object[]) doubleArray9);
        boolean boolean12 = blockRealMatrix5.equals((java.lang.Object) "");
        try {
            org.apache.commons.math.linear.RealVector realVector14 = blockRealMatrix5.getRowVector((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double14 = blockRealMatrix13.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix10.subtract(blockRealMatrix13);
        boolean boolean17 = blockRealMatrix15.equals((java.lang.Object) 100.0d);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) blockRealMatrix15);
        int int19 = blockRealMatrix2.getColumnDimension();
        try {
            org.apache.commons.math.linear.RealVector realVector21 = blockRealMatrix2.getColumnVector((int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 32 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.apache.commons.math.exception.Localizable localizable0 = null;
        double[][] doubleArray4 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException5 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray4);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException6 = new org.apache.commons.math.linear.MatrixIndexException(localizable0, (java.lang.Object[]) doubleArray4);
        java.lang.Object[] objArray7 = matrixIndexException6.getArguments();
        double[] doubleArray12 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable13 = null;
        double[] doubleArray14 = new double[] {};
        double[][] doubleArray15 = new double[][] { doubleArray14 };
        double[][] doubleArray16 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray15);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException(doubleArray12, localizable13, (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException18 = new org.apache.commons.math.linear.MatrixIndexException("org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.exception.Localizable localizable19 = matrixIndexException18.getLocalizablePattern();
        double[] doubleArray24 = new double[] {};
        double[][] doubleArray25 = new double[][] { doubleArray24 };
        double[][] doubleArray26 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray25);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException27 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException28 = new org.apache.commons.math.FunctionEvaluationException(1.0d, "evaluation failed for argument = {0}", (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException(localizable19, (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.MathRuntimeException mathRuntimeException30 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) matrixIndexException6, "", (java.lang.Object[]) doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(nullPointerException5);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        double[] doubleArray6 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException7 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray6);
        double[] doubleArray15 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException(doubleArray15);
        org.apache.commons.math.exception.Localizable localizable17 = null;
        double[] doubleArray20 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable21 = null;
        double[] doubleArray22 = new double[] {};
        double[][] doubleArray23 = new double[][] { doubleArray22 };
        double[][] doubleArray24 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray23);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException(doubleArray20, localizable21, (java.lang.Object[]) doubleArray23);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException26 = new org.apache.commons.math.FunctionEvaluationException(doubleArray15, localizable17, (java.lang.Object[]) doubleArray23);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair28 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray6, doubleArray15, true);
        org.apache.commons.math.linear.RealVector realVector29 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realVector29);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        int int4 = blockRealMatrix2.getColumnDimension();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.transpose();
        double[] doubleArray12 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException13 = new org.apache.commons.math.FunctionEvaluationException(doubleArray12);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray12);
        double[] doubleArray21 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException22 = new org.apache.commons.math.FunctionEvaluationException(doubleArray21);
        org.apache.commons.math.exception.Localizable localizable23 = null;
        double[] doubleArray26 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable27 = null;
        double[] doubleArray28 = new double[] {};
        double[][] doubleArray29 = new double[][] { doubleArray28 };
        double[][] doubleArray30 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray29);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException31 = new org.apache.commons.math.FunctionEvaluationException(doubleArray26, localizable27, (java.lang.Object[]) doubleArray29);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException32 = new org.apache.commons.math.FunctionEvaluationException(doubleArray21, localizable23, (java.lang.Object[]) doubleArray29);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair34 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray12, doubleArray21, true);
        double[] doubleArray35 = vectorialPointValuePair34.getPoint();
        double[] doubleArray36 = vectorialPointValuePair34.getPoint();
        org.apache.commons.math.linear.RealVector realVector37 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray36);
        try {
            org.apache.commons.math.linear.RealVector realVector38 = blockRealMatrix5.operate(realVector37);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector37);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        double[] doubleArray15 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException(doubleArray15);
        org.apache.commons.math.linear.RealMatrix realMatrix17 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray15);
        double[] doubleArray24 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException(doubleArray24);
        org.apache.commons.math.exception.Localizable localizable26 = null;
        double[] doubleArray29 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable30 = null;
        double[] doubleArray31 = new double[] {};
        double[][] doubleArray32 = new double[][] { doubleArray31 };
        double[][] doubleArray33 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray32);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException34 = new org.apache.commons.math.FunctionEvaluationException(doubleArray29, localizable30, (java.lang.Object[]) doubleArray32);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException35 = new org.apache.commons.math.FunctionEvaluationException(doubleArray24, localizable26, (java.lang.Object[]) doubleArray32);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair37 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray15, doubleArray24, true);
        org.apache.commons.math.linear.RealVector realVector38 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray15);
        try {
            blockRealMatrix7.setColumnVector(0, realVector38);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.InvalidMatrixException; message: dimensions mismatch: got 6x1 but expected 35x1");
        } catch (org.apache.commons.math.linear.InvalidMatrixException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(realVector38);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        double[] doubleArray5 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable6 = null;
        double[] doubleArray7 = new double[] {};
        double[][] doubleArray8 = new double[][] { doubleArray7 };
        double[][] doubleArray9 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray8);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException(doubleArray5, localizable6, (java.lang.Object[]) doubleArray8);
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray8);
        int int13 = maxIterationsExceededException12.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable14 = maxIterationsExceededException12.getLocalizablePattern();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray17 = functionEvaluationException16.getSuppressed();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException18 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a', localizable14, (java.lang.Object[]) throwableArray17);
        org.apache.commons.math.exception.Localizable localizable19 = null;
        double[][] doubleArray23 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException24 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray23);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException25 = new org.apache.commons.math.linear.MatrixIndexException(localizable19, (java.lang.Object[]) doubleArray23);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException26 = new org.apache.commons.math.linear.InvalidMatrixException(localizable14, (java.lang.Object[]) doubleArray23);
        java.lang.Throwable throwable29 = null;
        org.apache.commons.math.exception.Localizable localizable30 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException32 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray33 = functionEvaluationException32.getSuppressed();
        org.apache.commons.math.MathRuntimeException mathRuntimeException34 = new org.apache.commons.math.MathRuntimeException(throwable29, localizable30, (java.lang.Object[]) throwableArray33);
        java.text.ParseException parseException35 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) throwableArray33);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException36 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable14, (java.lang.Object[]) throwableArray33);
        java.lang.Object[] objArray38 = new java.lang.Object[] {};
        java.lang.IllegalArgumentException illegalArgumentException39 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", objArray38);
        java.lang.NullPointerException nullPointerException40 = org.apache.commons.math.MathRuntimeException.createNullPointerException(localizable14, objArray38);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 52 + "'", int13 == 52);
        org.junit.Assert.assertNotNull(localizable14);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(nullPointerException24);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertNotNull(parseException35);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException36);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(illegalArgumentException39);
        org.junit.Assert.assertNotNull(nullPointerException40);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getJacobianEvaluations();
        levenbergMarquardtOptimizer0.setQRRankingThreshold((double) 10L);
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker6 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker((double) 10, (double) (short) 10);
        levenbergMarquardtOptimizer0.setConvergenceChecker((org.apache.commons.math.optimization.VectorialConvergenceChecker) simpleVectorialValueChecker6);
        try {
            double[] doubleArray8 = levenbergMarquardtOptimizer0.guessParametersErrors();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.optimization.OptimizationException; message: no degrees of freedom (0 measurements, 0 parameters)");
        } catch (org.apache.commons.math.optimization.OptimizationException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix5.createMatrix((int) (byte) 100, 52);
        java.lang.String str9 = blockRealMatrix8.toString();
        try {
            org.apache.commons.math.linear.RealVector realVector11 = blockRealMatrix8.getRowVector((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index -1 out of allowed range [0, 99]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        double double6 = blockRealMatrix5.getNorm();
        double double7 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix5.transpose();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException();
        double[] doubleArray7 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable8 = null;
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(doubleArray7, localizable8, (java.lang.Object[]) doubleArray10);
        double[][] doubleArray13 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray10);
        int int15 = maxIterationsExceededException14.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable16 = maxIterationsExceededException14.getLocalizablePattern();
        double[] doubleArray22 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable23 = null;
        double[] doubleArray24 = new double[] {};
        double[][] doubleArray25 = new double[][] { doubleArray24 };
        double[][] doubleArray26 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray25);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException27 = new org.apache.commons.math.FunctionEvaluationException(doubleArray22, localizable23, (java.lang.Object[]) doubleArray25);
        double[][] doubleArray28 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray25);
        int int30 = maxIterationsExceededException29.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable31 = maxIterationsExceededException29.getLocalizablePattern();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException33 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray34 = functionEvaluationException33.getSuppressed();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException35 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a', localizable31, (java.lang.Object[]) throwableArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException2, localizable16, (java.lang.Object[]) throwableArray34);
        java.lang.Object[] objArray37 = null;
        java.lang.NullPointerException nullPointerException38 = org.apache.commons.math.MathRuntimeException.createNullPointerException(localizable16, objArray37);
        org.apache.commons.math.exception.Localizable localizable39 = null;
        double[] doubleArray42 = new double[] {};
        double[][] doubleArray43 = new double[][] { doubleArray42 };
        double[][] doubleArray44 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray43);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException45 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray44);
        org.apache.commons.math.exception.Localizable localizable46 = null;
        double[][] doubleArray49 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxEvaluationsExceededException45, localizable46, (java.lang.Object[]) doubleArray49);
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException(localizable39, (java.lang.Object[]) doubleArray49);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException52 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 1, localizable16, (java.lang.Object[]) doubleArray49);
        java.lang.IllegalArgumentException illegalArgumentException53 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 52 + "'", int15 == 52);
        org.junit.Assert.assertNotNull(localizable16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 52 + "'", int30 == 52);
        org.junit.Assert.assertNotNull(localizable31);
        org.junit.Assert.assertNotNull(throwableArray34);
        org.junit.Assert.assertNotNull(nullPointerException38);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(illegalArgumentException53);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor2 = null;
        try {
            double double7 = array2DRowRealMatrix0.walkInRowOrder(realMatrixPreservingVisitor2, (-1), (-1), (int) (byte) 1, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index -1 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 1, (int) (short) 1);
        array2DRowRealMatrix2.addToEntry(0, 0, 10.0d);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor7 = null;
        try {
            double double8 = array2DRowRealMatrix2.walkInColumnOrder(realMatrixPreservingVisitor7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.apache.commons.math.exception.Localizable localizable2 = null;
        double[] doubleArray9 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException(doubleArray9);
        org.apache.commons.math.exception.Localizable localizable11 = null;
        double[] doubleArray14 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable15 = null;
        double[] doubleArray16 = new double[] {};
        double[][] doubleArray17 = new double[][] { doubleArray16 };
        double[][] doubleArray18 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray17);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException19 = new org.apache.commons.math.FunctionEvaluationException(doubleArray14, localizable15, (java.lang.Object[]) doubleArray17);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException(doubleArray9, localizable11, (java.lang.Object[]) doubleArray17);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException(localizable2, (java.lang.Object[]) doubleArray17);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException22 = new org.apache.commons.math.linear.MatrixIndexException("hi!", (java.lang.Object[]) doubleArray17);
        java.lang.IllegalStateException illegalStateException23 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("", (java.lang.Object[]) doubleArray17);
        java.io.IOException iOException24 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) illegalStateException23);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(illegalStateException23);
        org.junit.Assert.assertNotNull(iOException24);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        boolean boolean6 = blockRealMatrix2.isSquare();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor7 = null;
        try {
            double double8 = blockRealMatrix2.walkInOptimizedOrder(realMatrixChangingVisitor7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.apache.commons.math.linear.BigMatrix bigMatrix1 = org.apache.commons.math.linear.MatrixUtils.createBigIdentityMatrix((int) (byte) 100);
        org.apache.commons.math.linear.MatrixUtils.checkRowIndex((org.apache.commons.math.linear.AnyMatrix) bigMatrix1, 0);
        org.junit.Assert.assertNotNull(bigMatrix1);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        double[] doubleArray3 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable4 = null;
        double[] doubleArray5 = new double[] {};
        double[][] doubleArray6 = new double[][] { doubleArray5 };
        double[][] doubleArray7 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException8 = new org.apache.commons.math.FunctionEvaluationException(doubleArray3, localizable4, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException9 = new org.apache.commons.math.linear.MatrixIndexException("org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) doubleArray6);
        org.apache.commons.math.exception.Localizable localizable10 = matrixIndexException9.getLocalizablePattern();
        double[] doubleArray13 = new double[] {};
        double[][] doubleArray14 = new double[][] { doubleArray13 };
        double[][] doubleArray15 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray14);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException16 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray15);
        double[] doubleArray20 = new double[] {};
        double[][] doubleArray21 = new double[][] { doubleArray20 };
        double[][] doubleArray22 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray21);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException23 = new org.apache.commons.math.MaxEvaluationsExceededException(10, "", (java.lang.Object[]) doubleArray21);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) maxEvaluationsExceededException16, "hi!", (java.lang.Object[]) doubleArray21);
        org.apache.commons.math.exception.Localizable localizable25 = mathException24.getLocalizablePattern();
        double[] doubleArray30 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable31 = null;
        double[] doubleArray32 = new double[] {};
        double[][] doubleArray33 = new double[][] { doubleArray32 };
        double[][] doubleArray34 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray33);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException35 = new org.apache.commons.math.FunctionEvaluationException(doubleArray30, localizable31, (java.lang.Object[]) doubleArray33);
        double[][] doubleArray36 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray33);
        java.lang.ArithmeticException arithmeticException37 = org.apache.commons.math.MathRuntimeException.createArithmeticException("org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) doubleArray33);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException38 = new org.apache.commons.math.linear.InvalidMatrixException("{0}", (java.lang.Object[]) doubleArray33);
        org.apache.commons.math.MathRuntimeException mathRuntimeException39 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) matrixIndexException9, localizable25, (java.lang.Object[]) doubleArray33);
        double[][] doubleArray40 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(localizable25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(arithmeticException37);
        org.junit.Assert.assertNotNull(doubleArray40);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        double double6 = blockRealMatrix5.getNorm();
        java.io.ObjectOutputStream objectOutputStream7 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.serializeRealMatrix((org.apache.commons.math.linear.RealMatrix) blockRealMatrix5, objectOutputStream7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        java.math.BigDecimal[] bigDecimalArray0 = new java.math.BigDecimal[] {};
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix1 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(bigDecimalArray0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigDecimalArray0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        boolean boolean2 = array2DRowRealMatrix0.isSquare();
        double[][] doubleArray3 = array2DRowRealMatrix0.getData();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor4 = null;
        try {
            double double9 = array2DRowRealMatrix0.walkInRowOrder(realMatrixPreservingVisitor4, 97, 97, 2147483647, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 97 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        double[] doubleArray6 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException7 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6);
        org.apache.commons.math.linear.BigMatrix bigMatrix8 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray6);
        org.apache.commons.math.linear.BigMatrix bigMatrix9 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(bigMatrix8);
        org.junit.Assert.assertNotNull(bigMatrix9);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix7.copy();
        int int9 = blockRealMatrix8.getColumnDimension();
        try {
            org.apache.commons.math.linear.RealVector realVector11 = blockRealMatrix8.getRowVector((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, 34]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.RealVector realVector5 = blockRealMatrix2.getColumnVector((int) (short) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix11 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double12 = blockRealMatrix11.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = blockRealMatrix8.subtract(blockRealMatrix11);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double20 = blockRealMatrix19.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix21 = blockRealMatrix16.subtract(blockRealMatrix19);
        boolean boolean23 = blockRealMatrix21.equals((java.lang.Object) 100.0d);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix24 = blockRealMatrix8.add((org.apache.commons.math.linear.RealMatrix) blockRealMatrix21);
        org.apache.commons.math.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix2, (org.apache.commons.math.linear.AnyMatrix) blockRealMatrix24);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix13);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix24);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        double[] doubleArray5 = new double[] {};
        double[][] doubleArray6 = new double[][] { doubleArray5 };
        double[][] doubleArray7 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException8 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray7);
        double[] doubleArray12 = new double[] {};
        double[][] doubleArray13 = new double[][] { doubleArray12 };
        double[][] doubleArray14 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray13);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException15 = new org.apache.commons.math.MaxEvaluationsExceededException(10, "", (java.lang.Object[]) doubleArray13);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) maxEvaluationsExceededException8, "hi!", (java.lang.Object[]) doubleArray13);
        org.apache.commons.math.optimization.OptimizationException optimizationException17 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) mathException16);
        org.apache.commons.math.exception.Localizable localizable18 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { 1L };
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException16, localizable18, objArray20);
        java.lang.IllegalStateException illegalStateException22 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("hi!", objArray20);
        java.lang.Class<?> wildcardClass23 = objArray20.getClass();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException24 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) -1, "Array2DRowRealMatrix{}", objArray20);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(illegalStateException22);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getJacobianEvaluations();
        levenbergMarquardtOptimizer0.setQRRankingThreshold((double) 10L);
        levenbergMarquardtOptimizer0.setParRelativeTolerance((double) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        double[] doubleArray6 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException7 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix8);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix7.copy();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix8.copy();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix8.scalarAdd(0.0d);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double15 = blockRealMatrix14.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = blockRealMatrix11.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix14);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor17 = null;
        try {
            double double18 = blockRealMatrix16.walkInOptimizedOrder(realMatrixChangingVisitor17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix16);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix5.createMatrix((int) (byte) 100, 52);
        java.lang.String str9 = blockRealMatrix8.toString();
        double double10 = blockRealMatrix8.getFrobeniusNorm();
        double[] doubleArray18 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException19 = new org.apache.commons.math.FunctionEvaluationException(doubleArray18);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray18);
        double[] doubleArray27 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException28 = new org.apache.commons.math.FunctionEvaluationException(doubleArray27);
        org.apache.commons.math.exception.Localizable localizable29 = null;
        double[] doubleArray32 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable33 = null;
        double[] doubleArray34 = new double[] {};
        double[][] doubleArray35 = new double[][] { doubleArray34 };
        double[][] doubleArray36 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray35);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException37 = new org.apache.commons.math.FunctionEvaluationException(doubleArray32, localizable33, (java.lang.Object[]) doubleArray35);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException38 = new org.apache.commons.math.FunctionEvaluationException(doubleArray27, localizable29, (java.lang.Object[]) doubleArray35);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair40 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray18, doubleArray27, true);
        org.apache.commons.math.linear.RealVector realVector41 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray18);
        try {
            blockRealMatrix8.setRowVector((int) '#', realVector41);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.InvalidMatrixException; message: dimensions mismatch: got 1x6 but expected 1x52");
        } catch (org.apache.commons.math.linear.InvalidMatrixException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector41);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double8 = blockRealMatrix7.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix4.multiply(blockRealMatrix7);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean11 = array2DRowRealMatrix10.isSquare();
        boolean boolean12 = array2DRowRealMatrix10.isSquare();
        try {
            org.apache.commons.math.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix9, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix10);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        blockRealMatrix5.setEntry(0, (int) (byte) 0, (double) 0);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix13 = blockRealMatrix5.getRowMatrix(97);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 97 out of allowed range [0, 34]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) (byte) 1, (int) (short) 10);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.apache.commons.math.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math.linear.NonSquareMatrixException((int) 'a', (int) '4');
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double14 = blockRealMatrix13.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix10.subtract(blockRealMatrix13);
        boolean boolean17 = blockRealMatrix15.equals((java.lang.Object) 100.0d);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) blockRealMatrix15);
        int int19 = blockRealMatrix2.getColumnDimension();
        double[][] doubleArray20 = null;
        try {
            blockRealMatrix2.setSubMatrix(doubleArray20, 52, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        java.lang.Throwable throwable4 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException7 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray8 = functionEvaluationException7.getSuppressed();
        org.apache.commons.math.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.MathRuntimeException(throwable4, localizable5, (java.lang.Object[]) throwableArray8);
        java.text.ParseException parseException10 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) throwableArray8);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException11 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 1, "maximal number of iterations ({0}) exceeded", (java.lang.Object[]) throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(parseException10);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        double[] doubleArray1 = new double[] {};
        double[][] doubleArray2 = new double[][] { doubleArray1 };
        double[][] doubleArray3 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray2);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException4 = new org.apache.commons.math.linear.InvalidMatrixException("", (java.lang.Object[]) doubleArray3);
        double[][] doubleArray8 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException9 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray8);
        org.apache.commons.math.exception.Localizable localizable11 = null;
        double[] doubleArray14 = new double[] {};
        double[][] doubleArray15 = new double[][] { doubleArray14 };
        double[][] doubleArray16 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray15);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException17 = new org.apache.commons.math.MaxEvaluationsExceededException(10, "", (java.lang.Object[]) doubleArray15);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException9, (double) (short) -1, localizable11, (java.lang.Object[]) doubleArray15);
        invalidMatrixException4.addSuppressed((java.lang.Throwable) functionEvaluationException18);
        java.lang.Object[] objArray20 = invalidMatrixException4.getArguments();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(nullPointerException9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(objArray20);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double14 = blockRealMatrix13.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix10.subtract(blockRealMatrix13);
        boolean boolean17 = blockRealMatrix15.equals((java.lang.Object) 100.0d);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) blockRealMatrix15);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double23 = blockRealMatrix22.getFrobeniusNorm();
        double[] doubleArray25 = blockRealMatrix22.getRow(10);
        double[][] doubleArray26 = blockRealMatrix22.getData();
        org.apache.commons.math.linear.RealVector realVector28 = blockRealMatrix22.getRowVector((int) (short) 0);
        try {
            blockRealMatrix2.setColumnVector((int) (short) 0, realVector28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.InvalidMatrixException; message: dimensions mismatch: got 10x1 but expected 35x1");
        } catch (org.apache.commons.math.linear.InvalidMatrixException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realVector28);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.transpose();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double8 = blockRealMatrix7.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix4.multiply(blockRealMatrix7);
        double[] doubleArray17 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException(doubleArray17);
        org.apache.commons.math.linear.BigMatrix bigMatrix19 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(doubleArray17);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException(doubleArray17);
        try {
            blockRealMatrix9.setRow(100, doubleArray17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(bigMatrix19);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double14 = blockRealMatrix13.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix10.subtract(blockRealMatrix13);
        boolean boolean17 = blockRealMatrix15.equals((java.lang.Object) 100.0d);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix2.add((org.apache.commons.math.linear.RealMatrix) blockRealMatrix15);
        int int19 = blockRealMatrix2.getColumnDimension();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double23 = blockRealMatrix22.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix25 = blockRealMatrix22.getRowMatrix(0);
        org.apache.commons.math.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix25, (int) (short) 0);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix28 = blockRealMatrix2.add(blockRealMatrix25);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix25);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        int int4 = blockRealMatrix2.getColumnDimension();
        org.apache.commons.math.linear.RealVector realVector6 = blockRealMatrix2.getColumnVector(0);
        blockRealMatrix2.multiplyEntry((int) (byte) 1, (int) (byte) 0, (double) 1);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor11 = null;
        try {
            double double12 = blockRealMatrix2.walkInRowOrder(realMatrixChangingVisitor11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(realVector6);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double[] doubleArray6 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException7 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray6);
        double[] doubleArray15 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException(doubleArray15);
        org.apache.commons.math.exception.Localizable localizable17 = null;
        double[] doubleArray20 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable21 = null;
        double[] doubleArray22 = new double[] {};
        double[][] doubleArray23 = new double[][] { doubleArray22 };
        double[][] doubleArray24 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray23);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException(doubleArray20, localizable21, (java.lang.Object[]) doubleArray23);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException26 = new org.apache.commons.math.FunctionEvaluationException(doubleArray15, localizable17, (java.lang.Object[]) doubleArray23);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair28 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray6, doubleArray15, true);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException(doubleArray15);
        org.apache.commons.math.exception.Localizable localizable30 = functionEvaluationException29.getLocalizablePattern();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.EVALUATION_FAILED + "'", localizable30.equals(org.apache.commons.math.exception.LocalizedFormats.EVALUATION_FAILED));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getJacobianEvaluations();
        levenbergMarquardtOptimizer0.setCostRelativeTolerance(0.0d);
        int int4 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        levenbergMarquardtOptimizer0.setParRelativeTolerance((double) 100L);
        int int7 = levenbergMarquardtOptimizer0.getJacobianEvaluations();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.apache.commons.math.exception.Localizable localizable1 = null;
        double[] doubleArray8 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException(doubleArray8);
        org.apache.commons.math.exception.Localizable localizable10 = null;
        double[] doubleArray13 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable14 = null;
        double[] doubleArray15 = new double[] {};
        double[][] doubleArray16 = new double[][] { doubleArray15 };
        double[][] doubleArray17 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray16);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException(doubleArray13, localizable14, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException19 = new org.apache.commons.math.FunctionEvaluationException(doubleArray8, localizable10, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException(localizable1, (java.lang.Object[]) doubleArray16);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException21 = new org.apache.commons.math.linear.MatrixIndexException("hi!", (java.lang.Object[]) doubleArray16);
        java.lang.String str22 = matrixIndexException21.getPattern();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        double[] doubleArray10 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable11 = null;
        double[] doubleArray12 = new double[] {};
        double[][] doubleArray13 = new double[][] { doubleArray12 };
        double[][] doubleArray14 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray13);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException(doubleArray10, localizable11, (java.lang.Object[]) doubleArray13);
        double[][] doubleArray16 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray13);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray13);
        int int18 = maxIterationsExceededException17.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable19 = maxIterationsExceededException17.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable20 = null;
        double[][] doubleArray24 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException25 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray24);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException26 = new org.apache.commons.math.linear.MatrixIndexException(localizable20, (java.lang.Object[]) doubleArray24);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', localizable19, (java.lang.Object[]) doubleArray24);
        double[] doubleArray31 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable32 = null;
        double[] doubleArray33 = new double[] {};
        double[][] doubleArray34 = new double[][] { doubleArray33 };
        double[][] doubleArray35 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray34);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException(doubleArray31, localizable32, (java.lang.Object[]) doubleArray34);
        double[][] doubleArray37 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray34);
        java.lang.NullPointerException nullPointerException38 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray37);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException39 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 10, localizable19, (java.lang.Object[]) doubleArray37);
        double[] doubleArray46 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException47 = new org.apache.commons.math.FunctionEvaluationException(doubleArray46);
        org.apache.commons.math.exception.Localizable localizable48 = null;
        double[] doubleArray51 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable52 = null;
        double[] doubleArray53 = new double[] {};
        double[][] doubleArray54 = new double[][] { doubleArray53 };
        double[][] doubleArray55 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray54);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException56 = new org.apache.commons.math.FunctionEvaluationException(doubleArray51, localizable52, (java.lang.Object[]) doubleArray54);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException57 = new org.apache.commons.math.FunctionEvaluationException(doubleArray46, localizable48, (java.lang.Object[]) doubleArray54);
        double[][] doubleArray58 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray54);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException59 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable19, (java.lang.Object[]) doubleArray58);
        java.lang.NullPointerException nullPointerException60 = org.apache.commons.math.MathRuntimeException.createNullPointerException("hi!", (java.lang.Object[]) doubleArray58);
        java.lang.IllegalArgumentException illegalArgumentException61 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("{0}", (java.lang.Object[]) doubleArray58);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException62 = new org.apache.commons.math.FunctionEvaluationException(0.0d, "evaluation failed for argument = {0}", (java.lang.Object[]) doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 52 + "'", int18 == 52);
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(nullPointerException25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(nullPointerException38);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException59);
        org.junit.Assert.assertNotNull(nullPointerException60);
        org.junit.Assert.assertNotNull(illegalArgumentException61);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        boolean boolean9 = blockRealMatrix7.equals((java.lang.Object) 100.0d);
        org.apache.commons.math.linear.RealVector realVector11 = blockRealMatrix7.getColumnVector((int) (short) 1);
        java.io.ObjectOutputStream objectOutputStream12 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.serializeRealVector(realVector11, objectOutputStream12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(realVector11);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix7 = blockRealMatrix2.getRowMatrix((int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 52 out of allowed range [0, 34]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        try {
            boolean boolean5 = blockRealMatrix2.isSingular();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 35x10 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        boolean boolean2 = array2DRowRealMatrix0.isSquare();
        double[][] doubleArray3 = array2DRowRealMatrix0.getData();
        int[] intArray5 = new int[] { (short) 100 };
        int[] intArray7 = new int[] { 1 };
        double[] doubleArray10 = new double[] {};
        double[][] doubleArray11 = new double[][] { doubleArray10 };
        double[][] doubleArray12 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray11);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException13 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray12);
        org.apache.commons.math.exception.Localizable localizable14 = null;
        double[][] doubleArray17 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxEvaluationsExceededException13, localizable14, (java.lang.Object[]) doubleArray17);
        try {
            array2DRowRealMatrix0.copySubMatrix(intArray5, intArray7, doubleArray17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.apache.commons.math.linear.RealMatrix realMatrix2 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix((int) (short) 1, (int) 'a');
        org.junit.Assert.assertNotNull(realMatrix2);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getDeterminant();
        java.lang.String str3 = array2DRowRealMatrix0.toString();
        double double4 = array2DRowRealMatrix0.getDeterminant();
        double[][] doubleArray5 = array2DRowRealMatrix0.getDataRef();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor6 = null;
        try {
            double double7 = array2DRowRealMatrix0.walkInOptimizedOrder(realMatrixPreservingVisitor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Array2DRowRealMatrix{}" + "'", str3.equals("Array2DRowRealMatrix{}"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNull(doubleArray5);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        double[][] doubleArray4 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        java.lang.NullPointerException nullPointerException5 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray4);
        org.apache.commons.math.exception.Localizable localizable7 = null;
        double[] doubleArray10 = new double[] {};
        double[][] doubleArray11 = new double[][] { doubleArray10 };
        double[][] doubleArray12 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray11);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException13 = new org.apache.commons.math.MaxEvaluationsExceededException(10, "", (java.lang.Object[]) doubleArray11);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException14 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) nullPointerException5, (double) (short) -1, localizable7, (java.lang.Object[]) doubleArray11);
        java.util.ConcurrentModificationException concurrentModificationException15 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("maximal number of iterations ({0}) exceeded", (java.lang.Object[]) doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(nullPointerException5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(concurrentModificationException15);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        double[] doubleArray2 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable3 = null;
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray4 };
        double[][] doubleArray6 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray5);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException7 = new org.apache.commons.math.FunctionEvaluationException(doubleArray2, localizable3, (java.lang.Object[]) doubleArray5);
        double[] doubleArray13 = new double[] { 10L, '#', 0, 1.0d, '#' };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair15 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray2, doubleArray13, true);
        org.apache.commons.math.exception.Localizable localizable16 = null;
        double[] doubleArray20 = new double[] {};
        double[][] doubleArray21 = new double[][] { doubleArray20 };
        double[][] doubleArray22 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray21);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException23 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray22);
        org.apache.commons.math.exception.Localizable localizable24 = null;
        double[][] doubleArray27 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) 0, (int) 'a');
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxEvaluationsExceededException23, localizable24, (java.lang.Object[]) doubleArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException("", (java.lang.Object[]) doubleArray27);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException30 = new org.apache.commons.math.FunctionEvaluationException(doubleArray13, localizable16, (java.lang.Object[]) doubleArray27);
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException();
        double[] doubleArray37 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable38 = null;
        double[] doubleArray39 = new double[] {};
        double[][] doubleArray40 = new double[][] { doubleArray39 };
        double[][] doubleArray41 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray40);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException42 = new org.apache.commons.math.FunctionEvaluationException(doubleArray37, localizable38, (java.lang.Object[]) doubleArray40);
        double[][] doubleArray43 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray40);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException44 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray40);
        int int45 = maxIterationsExceededException44.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable46 = maxIterationsExceededException44.getLocalizablePattern();
        double[] doubleArray52 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable53 = null;
        double[] doubleArray54 = new double[] {};
        double[][] doubleArray55 = new double[][] { doubleArray54 };
        double[][] doubleArray56 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray55);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException57 = new org.apache.commons.math.FunctionEvaluationException(doubleArray52, localizable53, (java.lang.Object[]) doubleArray55);
        double[][] doubleArray58 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray55);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException59 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray55);
        int int60 = maxIterationsExceededException59.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable61 = maxIterationsExceededException59.getLocalizablePattern();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException63 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray64 = functionEvaluationException63.getSuppressed();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException65 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a', localizable61, (java.lang.Object[]) throwableArray64);
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException32, localizable46, (java.lang.Object[]) throwableArray64);
        double[] doubleArray71 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable72 = null;
        double[] doubleArray73 = new double[] {};
        double[][] doubleArray74 = new double[][] { doubleArray73 };
        double[][] doubleArray75 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray74);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException76 = new org.apache.commons.math.FunctionEvaluationException(doubleArray71, localizable72, (java.lang.Object[]) doubleArray74);
        double[][] doubleArray77 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray74);
        java.lang.NullPointerException nullPointerException78 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray77);
        org.apache.commons.math.MathRuntimeException mathRuntimeException79 = new org.apache.commons.math.MathRuntimeException("", (java.lang.Object[]) doubleArray77);
        java.lang.IllegalArgumentException illegalArgumentException80 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException(localizable46, (java.lang.Object[]) doubleArray77);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException81 = new org.apache.commons.math.FunctionEvaluationException(doubleArray13, "hi!", (java.lang.Object[]) doubleArray77);
        org.apache.commons.math.linear.RealMatrix realMatrix82 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 52 + "'", int45 == 52);
        org.junit.Assert.assertNotNull(localizable46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 52 + "'", int60 == 52);
        org.junit.Assert.assertNotNull(localizable61);
        org.junit.Assert.assertNotNull(throwableArray64);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(nullPointerException78);
        org.junit.Assert.assertNotNull(illegalArgumentException80);
        org.junit.Assert.assertNotNull(realMatrix82);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        double[] doubleArray5 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable6 = null;
        double[] doubleArray7 = new double[] {};
        double[][] doubleArray8 = new double[][] { doubleArray7 };
        double[][] doubleArray9 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray8);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException(doubleArray5, localizable6, (java.lang.Object[]) doubleArray8);
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray8);
        int int13 = maxIterationsExceededException12.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable14 = maxIterationsExceededException12.getLocalizablePattern();
        double[] doubleArray20 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable21 = null;
        double[] doubleArray22 = new double[] {};
        double[][] doubleArray23 = new double[][] { doubleArray22 };
        double[][] doubleArray24 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray23);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException(doubleArray20, localizable21, (java.lang.Object[]) doubleArray23);
        double[][] doubleArray26 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray23);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", (java.lang.Object[]) doubleArray23);
        int int28 = maxIterationsExceededException27.getMaxIterations();
        org.apache.commons.math.exception.Localizable localizable29 = maxIterationsExceededException27.getLocalizablePattern();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException31 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray32 = functionEvaluationException31.getSuppressed();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException33 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a', localizable29, (java.lang.Object[]) throwableArray32);
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException0, localizable14, (java.lang.Object[]) throwableArray32);
        double[] doubleArray39 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable40 = null;
        double[] doubleArray41 = new double[] {};
        double[][] doubleArray42 = new double[][] { doubleArray41 };
        double[][] doubleArray43 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray42);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException(doubleArray39, localizable40, (java.lang.Object[]) doubleArray42);
        double[][] doubleArray45 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray42);
        java.lang.NullPointerException nullPointerException46 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray45);
        org.apache.commons.math.MathRuntimeException mathRuntimeException47 = new org.apache.commons.math.MathRuntimeException("", (java.lang.Object[]) doubleArray45);
        java.lang.IllegalArgumentException illegalArgumentException48 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException(localizable14, (java.lang.Object[]) doubleArray45);
        java.lang.Throwable throwable49 = null;
        org.apache.commons.math.exception.Localizable localizable50 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException52 = new org.apache.commons.math.FunctionEvaluationException((double) 'a');
        java.lang.Throwable[] throwableArray53 = functionEvaluationException52.getSuppressed();
        org.apache.commons.math.MathRuntimeException mathRuntimeException54 = new org.apache.commons.math.MathRuntimeException(throwable49, localizable50, (java.lang.Object[]) throwableArray53);
        java.lang.IllegalStateException illegalStateException55 = org.apache.commons.math.MathRuntimeException.createIllegalStateException(localizable14, (java.lang.Object[]) throwableArray53);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException56 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable) illegalStateException55);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 52 + "'", int13 == 52);
        org.junit.Assert.assertNotNull(localizable14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 52 + "'", int28 == 52);
        org.junit.Assert.assertNotNull(localizable29);
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(nullPointerException46);
        org.junit.Assert.assertNotNull(illegalArgumentException48);
        org.junit.Assert.assertNotNull(throwableArray53);
        org.junit.Assert.assertNotNull(illegalStateException55);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker2 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker((double) (-1), (double) 0L);
        double[] doubleArray6 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable7 = null;
        double[] doubleArray8 = new double[] {};
        double[][] doubleArray9 = new double[][] { doubleArray8 };
        double[][] doubleArray10 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray9);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException11 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6, localizable7, (java.lang.Object[]) doubleArray9);
        double[] doubleArray17 = new double[] { 10L, '#', 0, 1.0d, '#' };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair19 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray6, doubleArray17, true);
        double[] doubleArray20 = vectorialPointValuePair19.getPointRef();
        double[] doubleArray21 = vectorialPointValuePair19.getPoint();
        double[] doubleArray22 = vectorialPointValuePair19.getValue();
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker25 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker(0.0d, (double) '4');
        double[] doubleArray33 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException34 = new org.apache.commons.math.FunctionEvaluationException(doubleArray33);
        org.apache.commons.math.linear.RealMatrix realMatrix35 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray33);
        double[] doubleArray42 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException43 = new org.apache.commons.math.FunctionEvaluationException(doubleArray42);
        org.apache.commons.math.exception.Localizable localizable44 = null;
        double[] doubleArray47 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable48 = null;
        double[] doubleArray49 = new double[] {};
        double[][] doubleArray50 = new double[][] { doubleArray49 };
        double[][] doubleArray51 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray50);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException52 = new org.apache.commons.math.FunctionEvaluationException(doubleArray47, localizable48, (java.lang.Object[]) doubleArray50);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException53 = new org.apache.commons.math.FunctionEvaluationException(doubleArray42, localizable44, (java.lang.Object[]) doubleArray50);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair55 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray33, doubleArray42, true);
        double[] doubleArray56 = vectorialPointValuePair55.getPoint();
        double[] doubleArray57 = vectorialPointValuePair55.getPointRef();
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker58 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        double[] doubleArray62 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable63 = null;
        double[] doubleArray64 = new double[] {};
        double[][] doubleArray65 = new double[][] { doubleArray64 };
        double[][] doubleArray66 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray65);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException67 = new org.apache.commons.math.FunctionEvaluationException(doubleArray62, localizable63, (java.lang.Object[]) doubleArray65);
        double[] doubleArray73 = new double[] { 10L, '#', 0, 1.0d, '#' };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair75 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray62, doubleArray73, true);
        double[] doubleArray78 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable79 = null;
        double[] doubleArray80 = new double[] {};
        double[][] doubleArray81 = new double[][] { doubleArray80 };
        double[][] doubleArray82 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray81);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException83 = new org.apache.commons.math.FunctionEvaluationException(doubleArray78, localizable79, (java.lang.Object[]) doubleArray81);
        double[] doubleArray89 = new double[] { 10L, '#', 0, 1.0d, '#' };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair91 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray78, doubleArray89, true);
        boolean boolean92 = simpleVectorialValueChecker58.converged(10, vectorialPointValuePair75, vectorialPointValuePair91);
        boolean boolean93 = simpleVectorialValueChecker25.converged((int) (short) 100, vectorialPointValuePair55, vectorialPointValuePair75);
        boolean boolean94 = simpleVectorialValueChecker2.converged((int) (byte) 0, vectorialPointValuePair19, vectorialPointValuePair75);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + true + "'", boolean92 == true);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + true + "'", boolean94 == true);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        boolean boolean6 = blockRealMatrix2.isSquare();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double10 = blockRealMatrix9.getFrobeniusNorm();
        int int11 = blockRealMatrix9.getColumnDimension();
        org.apache.commons.math.linear.RealVector realVector13 = blockRealMatrix9.getColumnVector(0);
        blockRealMatrix9.multiplyEntry((int) (byte) 1, (int) (byte) 0, (double) 1);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix2.subtract(blockRealMatrix9);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        boolean boolean5 = blockRealMatrix2.isSquare();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getFrobeniusNorm();
        boolean boolean3 = array2DRowRealMatrix0.isSquare();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double7 = blockRealMatrix6.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix6.getRowMatrix(0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double13 = blockRealMatrix12.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix12.getRowMatrix(0);
        org.apache.commons.math.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix15, (int) (short) 0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix9.add((org.apache.commons.math.linear.RealMatrix) blockRealMatrix15);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix19 = array2DRowRealMatrix0.add((org.apache.commons.math.linear.RealMatrix) blockRealMatrix9);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix15);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getJacobianEvaluations();
        levenbergMarquardtOptimizer0.setCostRelativeTolerance(0.0d);
        double double4 = levenbergMarquardtOptimizer0.getChiSquare();
        double double5 = levenbergMarquardtOptimizer0.getRMS();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSquare();
        boolean boolean2 = array2DRowRealMatrix0.isSquare();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.inverse();
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix5);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix7.copy();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix7.copy();
        double[] doubleArray12 = new double[] {};
        double[][] doubleArray13 = new double[][] { doubleArray12 };
        double[][] doubleArray14 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray13);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException15 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray14);
        double[] doubleArray19 = new double[] {};
        double[][] doubleArray20 = new double[][] { doubleArray19 };
        double[][] doubleArray21 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException22 = new org.apache.commons.math.MaxEvaluationsExceededException(10, "", (java.lang.Object[]) doubleArray20);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException((java.lang.Throwable) maxEvaluationsExceededException15, "hi!", (java.lang.Object[]) doubleArray20);
        org.apache.commons.math.optimization.OptimizationException optimizationException24 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) mathException23);
        java.lang.Object[] objArray27 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException28 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) optimizationException24, (double) '4', "hi!", objArray27);
        boolean boolean29 = blockRealMatrix9.equals((java.lang.Object) objArray27);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int1 = array2DRowRealMatrix0.getColumnDimension();
        double double2 = array2DRowRealMatrix0.getDeterminant();
        java.lang.String str3 = array2DRowRealMatrix0.toString();
        double double4 = array2DRowRealMatrix0.getDeterminant();
        double double5 = array2DRowRealMatrix0.getNorm();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        int int7 = array2DRowRealMatrix6.getColumnDimension();
        double double8 = array2DRowRealMatrix6.getFrobeniusNorm();
        boolean boolean10 = array2DRowRealMatrix6.equals((java.lang.Object) 36);
        double[] doubleArray17 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException(doubleArray17);
        org.apache.commons.math.linear.RealMatrix realMatrix19 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray17);
        double[] doubleArray26 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException27 = new org.apache.commons.math.FunctionEvaluationException(doubleArray26);
        org.apache.commons.math.exception.Localizable localizable28 = null;
        double[] doubleArray31 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable32 = null;
        double[] doubleArray33 = new double[] {};
        double[][] doubleArray34 = new double[][] { doubleArray33 };
        double[][] doubleArray35 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray34);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException(doubleArray31, localizable32, (java.lang.Object[]) doubleArray34);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException37 = new org.apache.commons.math.FunctionEvaluationException(doubleArray26, localizable28, (java.lang.Object[]) doubleArray34);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair39 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray17, doubleArray26, true);
        double[] doubleArray40 = vectorialPointValuePair39.getPoint();
        double[] doubleArray41 = vectorialPointValuePair39.getValueRef();
        double[] doubleArray42 = vectorialPointValuePair39.getValueRef();
        boolean boolean43 = array2DRowRealMatrix6.equals((java.lang.Object) doubleArray42);
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = array2DRowRealMatrix0.subtract(array2DRowRealMatrix6);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Array2DRowRealMatrix{}" + "'", str3.equals("Array2DRowRealMatrix{}"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix5.getRowMatrix(0);
        double double9 = blockRealMatrix8.getNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix11 = blockRealMatrix8.scalarAdd((double) (-1L));
        org.apache.commons.math.linear.RealMatrix realMatrix13 = blockRealMatrix8.scalarMultiply((double) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = blockRealMatrix8.createMatrix((int) '#', 1);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix2.multiply(blockRealMatrix16);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(blockRealMatrix16);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        double[] doubleArray6 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException7 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6);
        java.io.IOException iOException8 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) functionEvaluationException7);
        org.apache.commons.math.optimization.OptimizationException optimizationException9 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) functionEvaluationException7);
        org.apache.commons.math.exception.Localizable localizable10 = optimizationException9.getLocalizablePattern();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) optimizationException9, (double) 0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(iOException8);
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable10.equals(org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        try {
            org.apache.commons.math.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix2, (int) '4', 36, 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 52 out of allowed range [0, 34]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        double[] doubleArray6 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException7 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6);
        java.io.IOException iOException8 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) functionEvaluationException7);
        org.apache.commons.math.optimization.OptimizationException optimizationException9 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) functionEvaluationException7);
        org.apache.commons.math.exception.Localizable localizable10 = optimizationException9.getLocalizablePattern();
        java.lang.Object[] objArray11 = null;
        java.io.EOFException eOFException12 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable10, objArray11);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(iOException8);
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable10.equals(org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(eOFException12);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(0);
        double double6 = blockRealMatrix5.getNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix8 = blockRealMatrix5.scalarAdd((double) (-1L));
        org.apache.commons.math.linear.RealMatrix realMatrix10 = blockRealMatrix5.scalarMultiply((double) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = blockRealMatrix5.createMatrix((int) '#', 1);
        double[] doubleArray15 = blockRealMatrix13.getRow((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(blockRealMatrix13);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        java.lang.String[] strArray3 = new java.lang.String[] { "maximal number of iterations ({0}) exceeded", "{0}", "org.apache.commons.math.FunctionEvaluationException: " };
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix4 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(strArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        double[] doubleArray5 = new double[] { (-1.0d), (byte) 0, 0.0d };
        double[] doubleArray10 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable11 = null;
        double[] doubleArray12 = new double[] {};
        double[][] doubleArray13 = new double[][] { doubleArray12 };
        double[][] doubleArray14 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray13);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException(doubleArray10, localizable11, (java.lang.Object[]) doubleArray13);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException16 = new org.apache.commons.math.linear.MatrixIndexException("org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) doubleArray13);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException(doubleArray5, "", (java.lang.Object[]) doubleArray13);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException18 = new org.apache.commons.math.linear.MatrixIndexException("", (java.lang.Object[]) doubleArray13);
        org.apache.commons.math.exception.Localizable localizable19 = matrixIndexException18.getLocalizablePattern();
        double[] doubleArray27 = new double[] {};
        double[][] doubleArray28 = new double[][] { doubleArray27 };
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException30 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray29);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, "", (java.lang.Object[]) doubleArray29);
        double[] doubleArray39 = new double[] { 100, 1.0d, 10.0d, 10L, 1, 10.0f };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException(doubleArray39);
        org.apache.commons.math.exception.Localizable localizable41 = null;
        double[] doubleArray44 = new double[] { 1.0d, 10 };
        org.apache.commons.math.exception.Localizable localizable45 = null;
        double[] doubleArray46 = new double[] {};
        double[][] doubleArray47 = new double[][] { doubleArray46 };
        double[][] doubleArray48 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray47);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException49 = new org.apache.commons.math.FunctionEvaluationException(doubleArray44, localizable45, (java.lang.Object[]) doubleArray47);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException50 = new org.apache.commons.math.FunctionEvaluationException(doubleArray39, localizable41, (java.lang.Object[]) doubleArray47);
        double[][] doubleArray51 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray47);
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException31, "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) doubleArray47);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException53 = new org.apache.commons.math.MaxIterationsExceededException(1, "hi!", (java.lang.Object[]) doubleArray47);
        java.lang.IllegalArgumentException illegalArgumentException54 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) doubleArray47);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException55 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable19, (java.lang.Object[]) doubleArray47);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean58 = array2DRowRealMatrix57.isSquare();
        boolean boolean59 = array2DRowRealMatrix57.isSquare();
        double[][] doubleArray60 = array2DRowRealMatrix57.getData();
        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException55, "{0}", (java.lang.Object[]) doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(illegalArgumentException54);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(doubleArray60);
    }
}

