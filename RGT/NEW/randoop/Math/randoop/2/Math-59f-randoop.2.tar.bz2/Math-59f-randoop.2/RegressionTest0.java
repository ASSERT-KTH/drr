import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.Dfp dfp1 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp2 = org.apache.commons.math.dfp.Dfp.copysign(dfp0, dfp1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.apache.commons.math.dfp.Dfp.MAX_EXP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32768 + "'", int0 == 32768);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_OVERFLOW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double double1 = org.apache.commons.math.util.FastMath.expm1(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22025.465794806718d + "'", double1 == 22025.465794806718d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = org.apache.commons.math.dfp.Dfp.RADIX;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10000 + "'", int0 == 10000);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        byte byte0 = org.apache.commons.math.dfp.Dfp.SNAN;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 2 + "'", byte0 == (byte) 2);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5395564933646284d + "'", double1 == 1.5395564933646284d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        long long2 = org.apache.commons.math.util.FastMath.min(100L, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 10000, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963267948966d) + "'", double1 == (-1.5707963267948966d));
    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test016");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.6893392667306705d + "'", double0 == 0.6893392667306705d);
//    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = org.apache.commons.math.dfp.Dfp.MIN_EXP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-32767) + "'", int0 == (-32767));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22026.465794806718d + "'", double1 == 22026.465794806718d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_UNDERFLOW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8623188722876839d + "'", double1 == 0.8623188722876839d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        byte byte0 = org.apache.commons.math.dfp.Dfp.INFINITE;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 1 + "'", byte0 == (byte) 1);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6321205588285577d) + "'", double1 == (-0.6321205588285577d));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int1 = org.apache.commons.math.util.FastMath.abs((-32767));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32767 + "'", int1 == 32767);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int int2 = org.apache.commons.math.util.FastMath.max((-1), (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 4, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 1, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999999999999999d) + "'", double1 == (-0.9999999999999999d));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        double double1 = org.apache.commons.math.util.FastMath.ulp(22026.465794806718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.637978807091713E-12d + "'", double1 == 3.637978807091713E-12d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        double double1 = org.apache.commons.math.util.FastMath.atanh(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.Dfp dfp1 = null;
        org.apache.commons.math.dfp.Dfp dfp2 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp3 = org.apache.commons.math.dfp.DfpField.computeLn(dfp0, dfp1, dfp2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 1);
        double double2 = mersenneTwister1.nextDouble();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.1129943035738381d + "'", double2 == 0.1129943035738381d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        double double1 = org.apache.commons.math.util.FastMath.exp((-0.6321205588285577d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5314636053866156d + "'", double1 == 0.5314636053866156d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp1 = new org.apache.commons.math.dfp.Dfp(dfp0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 10L, (double) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) '#');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 1);
        byte[] byteArray5 = new byte[] { (byte) 2, (byte) 2, (byte) 1 };
        mersenneTwister1.nextBytes(byteArray5);
        int[] intArray7 = new int[] {};
        try {
            mersenneTwister1.setSeed(intArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        double double2 = org.apache.commons.math.util.FastMath.max((-1.5707963267948966d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.5314636053866156d, (double) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.4885005257385622d + "'", double2 == 0.4885005257385622d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) ' ', (double) 4);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1048576.0d + "'", double2 == 1048576.0d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 10000);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10000.0f + "'", float1 == 10000.0f);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        byte byte0 = org.apache.commons.math.dfp.Dfp.QNAN;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 3 + "'", byte0 == (byte) 3);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (byte) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_INEXACT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 'a', (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.00000000000001d + "'", double2 == 97.00000000000001d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1048576.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int2 = org.apache.commons.math.util.FastMath.min(4, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 10000);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999958776927d + "'", double1 == 0.9999999958776927d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.Dfp dfp1 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp2 = org.apache.commons.math.dfp.DfpField.computeExp(dfp0, dfp1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int int1 = org.apache.commons.math.util.FastMath.abs(10000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10000 + "'", int1 == 10000);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 10000.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.210340371976184d + "'", double1 == 9.210340371976184d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 100.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_INVALID;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 0, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (short) -1, 3.637978807091713E-12d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963267912586d) + "'", double2 == (-1.5707963267912586d));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        double double1 = org.apache.commons.math.util.FastMath.floor(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-1.0f), (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.009999666686665238d) + "'", double2 == (-0.009999666686665238d));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 16);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        float float2 = org.apache.commons.math.util.FastMath.max((float) ' ', 10.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 10000);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10000.000000000002d + "'", double1 == 10000.000000000002d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        double double1 = org.apache.commons.math.util.FastMath.floor((-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.0d) + "'", double1 == (-2.0d));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5401776706283436E45d + "'", double1 == 1.5401776706283436E45d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6610060414837631d + "'", double1 == 0.6610060414837631d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        float float2 = org.apache.commons.math.util.FastMath.min(100.0f, (float) 4);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.0f + "'", float2 == 4.0f);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-1.5707963267912586d), 100.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963267912584d) + "'", double2 == (-1.5707963267912584d));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        double double1 = org.apache.commons.math.util.FastMath.tanh(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.99627207622075d + "'", double1 == 0.99627207622075d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        int int1 = org.apache.commons.math.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.248291097914389d + "'", double1 == 4.248291097914389d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        double double2 = mersenneTwister1.nextGaussian();
        double double3 = mersenneTwister1.nextDouble();
        double double4 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.866531296165219d + "'", double2 == 0.866531296165219d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0032884513038209384d + "'", double3 == 0.0032884513038209384d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.06245429448283257d + "'", double4 == 0.06245429448283257d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        long long1 = org.apache.commons.math.util.FastMath.round(4.248291097914389d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 4L + "'", long1 == 4L);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        double double1 = org.apache.commons.math.util.FastMath.tanh(2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        byte byte0 = org.apache.commons.math.dfp.Dfp.FINITE;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 0 + "'", byte0 == (byte) 0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 'a');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-57.29577951308232d) + "'", double1 == (-57.29577951308232d));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        double double1 = org.apache.commons.math.util.FastMath.ulp(9.210340371976184d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.3440585709080678E43d, (double) 0L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3440585709080676E43d + "'", double2 == 1.3440585709080676E43d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-1.5707963267912584d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.2334031175092632d) + "'", double1 == (-1.2334031175092632d));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        long long2 = mersenneTwister1.nextLong();
        float float3 = mersenneTwister1.nextFloat();
        mersenneTwister1.setSeed(8);
        mersenneTwister1.setSeed(0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 211235929750981552L + "'", long2 == 211235929750981552L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.68564963f + "'", float3 == 0.68564963f);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        double double1 = org.apache.commons.math.util.FastMath.atan((-2.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1071487177940904d) + "'", double1 == (-1.1071487177940904d));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        int int2 = org.apache.commons.math.util.FastMath.max(32768, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32768 + "'", int2 == 32768);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 32768);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32768.0d + "'", double1 == 32768.0d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        long long2 = org.apache.commons.math.util.FastMath.min((-1L), (long) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, 3.637978807091713E-12d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 211235929750981552L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 39.891752054200694d + "'", double1 == 39.891752054200694d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        int[] intArray4 = new int[] { (byte) 1, (short) 10 };
        mersenneTwister1.setSeed(intArray4);
        java.lang.Class<?> wildcardClass6 = mersenneTwister1.getClass();
        float float7 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.8907622f + "'", float7 == 0.8907622f);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 'a');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 0.8907622f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.890762209892273d + "'", double1 == 0.890762209892273d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0.011451006f, (java.lang.Number) (-1L), false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        java.lang.Class<?> wildcardClass6 = number5.getClass();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1L) + "'", number5.equals((-1L)));
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        int int2 = org.apache.commons.math.util.FastMath.max(32767, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32767 + "'", int2 == 32767);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3978952727983707d + "'", double1 == 2.3978952727983707d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        double double1 = org.apache.commons.math.util.FastMath.rint(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        int int0 = org.apache.commons.math.dfp.Dfp.ERR_SCALE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32760 + "'", int0 == 32760);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) ' ');
        byte[] byteArray2 = null;
        try {
            mersenneTwister1.nextBytes(byteArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        int[] intArray4 = new int[] { (byte) 1, (short) 10 };
        mersenneTwister1.setSeed(intArray4);
        long long6 = mersenneTwister1.nextLong();
        long long7 = mersenneTwister1.nextLong();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2015080886171156972L) + "'", long6 == (-2015080886171156972L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3114545432277141210L + "'", long7 == 3114545432277141210L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        double double2 = org.apache.commons.math.util.FastMath.pow((-0.9999999999999999d), (double) 32.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999999999999964d + "'", double2 == 0.9999999999999964d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-32767), (float) (short) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        int[] intArray4 = new int[] { (byte) 1, (short) 10 };
        mersenneTwister1.setSeed(intArray4);
        org.apache.commons.math.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        double double7 = mersenneTwister6.nextDouble();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.8907622435414719d + "'", double7 == 0.8907622435414719d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        int[] intArray4 = new int[] { (byte) 1, (short) 10 };
        mersenneTwister1.setSeed(intArray4);
        long long6 = mersenneTwister1.nextLong();
        double double7 = mersenneTwister1.nextGaussian();
        long long8 = mersenneTwister1.nextLong();
        mersenneTwister1.setSeed((long) 32768);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2015080886171156972L) + "'", long6 == (-2015080886171156972L));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.46314732482245285d + "'", double7 == 0.46314732482245285d);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1049191337521486288L + "'", long8 == 1049191337521486288L);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9155040003582885E22d + "'", double1 == 1.9155040003582885E22d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 10000);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 1);
        mersenneTwister1.setSeed((long) (-32767));
        mersenneTwister1.setSeed(10);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.9999999958776927d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023093369417d + "'", double1 == 0.5403023093369417d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) -1, 3114545432277141210L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(9.210340371976184d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0961638486218908d + "'", double1 == 2.0961638486218908d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) ' ');
        int int2 = mersenneTwister1.nextInt();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-606065961) + "'", int2 == (-606065961));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000000000002d + "'", double1 == 1.0000000000000002d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable4, objArray10);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, localizable2, objArray10);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray10);
        org.apache.commons.math.exception.util.Localizable localizable14 = mathIllegalArgumentException13.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable15 = mathIllegalArgumentException13.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNull(localizable14);
        org.junit.Assert.assertNull(localizable15);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_DIV_ZERO;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 16);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 16.0d + "'", double1 == 16.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 100.0f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (-2015080886171156972L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9342612293281634d + "'", double1 == 0.9342612293281634d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        double double2 = mersenneTwister1.nextGaussian();
        mersenneTwister1.setSeed(10);
        int int5 = mersenneTwister1.nextInt();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.866531296165219d + "'", double2 == 0.866531296165219d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-982170359) + "'", int5 == (-982170359));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) Double.NaN, (java.lang.Number) 0.1129943035738381d, true);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.000000000000002d + "'", double1 == 10.000000000000002d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable4, objArray10);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, localizable2, objArray10);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray10);
        org.apache.commons.math.exception.util.Localizable localizable14 = mathIllegalArgumentException13.getGeneralPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException13);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNull(localizable14);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 1L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-32767));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-571.892036000982d) + "'", double1 == (-571.892036000982d));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        long long2 = mersenneTwister1.nextLong();
        float float3 = mersenneTwister1.nextFloat();
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister((long) 1);
        byte[] byteArray9 = new byte[] { (byte) 2, (byte) 2, (byte) 1 };
        mersenneTwister5.nextBytes(byteArray9);
        mersenneTwister1.nextBytes(byteArray9);
        float float12 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 211235929750981552L + "'", long2 == 211235929750981552L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.68564963f + "'", float3 == 0.68564963f);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.0032883883f + "'", float12 == 0.0032883883f);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        double double2 = mersenneTwister1.nextGaussian();
        mersenneTwister1.setSeed(10);
        mersenneTwister1.setSeed((int) '4');
        mersenneTwister1.setSeed((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.866531296165219d + "'", double2 == 0.866531296165219d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = mathIllegalArgumentException8.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable11, objArray17);
        org.apache.commons.math.exception.util.Localizable localizable19 = mathIllegalArgumentException18.getGeneralPattern();
        mathIllegalArgumentException8.addSuppressed((java.lang.Throwable) mathIllegalArgumentException18);
        org.apache.commons.math.exception.util.Localizable localizable21 = mathIllegalArgumentException18.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNull(localizable9);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNull(localizable19);
        org.junit.Assert.assertNull(localizable21);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        long long2 = mersenneTwister1.nextLong();
        float float3 = mersenneTwister1.nextFloat();
        float float4 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 211235929750981552L + "'", long2 == 211235929750981552L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.68564963f + "'", float3 == 0.68564963f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.32825363f + "'", float4 == 0.32825363f);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp(dfp5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        double double1 = org.apache.commons.math.util.FastMath.atan(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        double double1 = org.apache.commons.math.util.FastMath.cos(10000.000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9521553682584589d) + "'", double1 == (-0.9521553682584589d));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 0, 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (short) 100);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 0.011451006f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999344379479402d + "'", double1 == 0.9999344379479402d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 32768);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32768 + "'", int2 == 32768);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.multiply(dfp5);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.rint();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.rint();
        int int9 = dfp7.log10K();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.multiply(dfp5);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp2.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getZero();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getZero();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.multiply(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getZero();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp2.dotrap((-1), "org.apache.commons.math.exception.MathRuntimeException: ", dfp14, dfp21);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp2.rint();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.getZero();
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getZero();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp26.multiply(dfp29);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.rint();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp31.rint();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp2.nextAfter(dfp32);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp33.newInstance((byte) 100);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.1129943035738381d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4575601846855093d + "'", double1 == 1.4575601846855093d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.dfp.DfpField dfpField3 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField3.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, (java.lang.Object[]) dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray4);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 32767);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32767.0d + "'", double1 == 32767.0d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        boolean boolean4 = dfp3.isNaN();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298292365610485d + "'", double1 == 5.298292365610485d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0032883883f, 1.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0032883883f + "'", float2 == 0.0032883883f);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6483608274590866d + "'", double1 == 0.6483608274590866d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) -1, (float) (short) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 4);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        double double2 = org.apache.commons.math.util.FastMath.min((-1.1071487177940904d), 0.6610060414837631d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.1071487177940904d) + "'", double2 == (-1.1071487177940904d));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.multiply(dfp5);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp2.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getZero();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getZero();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.multiply(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getZero();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp2.dotrap((-1), "org.apache.commons.math.exception.MathRuntimeException: ", dfp14, dfp21);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp2.getZero();
        int int24 = dfp2.log10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-4) + "'", int24 == (-4));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.multiply(dfp5);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.rint();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) (-1.5707963267912586d));
        java.lang.Number number11 = notStrictlyPositiveException10.getArgument();
        java.lang.Number number12 = notStrictlyPositiveException10.getArgument();
        boolean boolean13 = dfp6.equals((java.lang.Object) notStrictlyPositiveException10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp6.getOne();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (-1.5707963267912586d) + "'", number11.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.5707963267912586d) + "'", number12.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (short) 10);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0, (java.lang.Number) 97.00000000000001d, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 97.00000000000001d + "'", number4.equals(97.00000000000001d));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1049191337521486288L, (float) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8813735870195429d + "'", double1 == 0.8813735870195429d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3383347192042695E42d + "'", double1 == 1.3383347192042695E42d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        int int1 = org.apache.commons.math.util.FastMath.round(100.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        float float2 = mersenneTwister1.nextFloat();
        mersenneTwister1.setSeed((-2015080886171156972L));
        int int6 = mersenneTwister1.nextInt((int) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.011451006f + "'", float2 == 0.011451006f);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 22 + "'", int6 == 22);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 0.8907622f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4369864387400422d + "'", double1 == 1.4369864387400422d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1048576.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 13.862944564872768d + "'", double1 == 13.862944564872768d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 1049191337521486288L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.04919133752148634E18d + "'", double1 == 1.04919133752148634E18d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = mathIllegalArgumentException8.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable11, objArray17);
        org.apache.commons.math.exception.util.Localizable localizable19 = mathIllegalArgumentException18.getGeneralPattern();
        mathIllegalArgumentException8.addSuppressed((java.lang.Throwable) mathIllegalArgumentException18);
        java.lang.Object[] objArray21 = mathIllegalArgumentException8.getArguments();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNull(localizable9);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNull(localizable19);
        org.junit.Assert.assertNotNull(objArray21);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 10);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        double double1 = org.apache.commons.math.util.FastMath.log(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.6610060414837631d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(32768);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 0.011451006f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.01145075569721739d + "'", double1 == 0.01145075569721739d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = mathIllegalArgumentException8.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable11, objArray17);
        org.apache.commons.math.exception.util.Localizable localizable19 = mathIllegalArgumentException18.getGeneralPattern();
        mathIllegalArgumentException8.addSuppressed((java.lang.Throwable) mathIllegalArgumentException18);
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode24 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        org.apache.commons.math.random.MersenneTwister mersenneTwister27 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        long long28 = mersenneTwister27.nextLong();
        org.apache.commons.math.random.MersenneTwister mersenneTwister30 = new org.apache.commons.math.random.MersenneTwister((long) 1);
        byte[] byteArray34 = new byte[] { (byte) 2, (byte) 2, (byte) 1 };
        mersenneTwister30.nextBytes(byteArray34);
        java.lang.Object[] objArray36 = new java.lang.Object[] { 10, roundingMode24, (byte) 1, mersenneTwister27, mersenneTwister30 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException37 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException18, localizable21, localizable22, objArray36);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException38 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException37);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNull(localizable9);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNull(localizable19);
        org.junit.Assert.assertTrue("'" + roundingMode24 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode24.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 211235929750981552L + "'", long28 == 211235929750981552L);
        org.junit.Assert.assertNotNull(byteArray34);
        org.junit.Assert.assertNotNull(objArray36);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.multiply(dfp5);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp2.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getZero();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getZero();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.multiply(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getZero();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp2.dotrap((-1), "org.apache.commons.math.exception.MathRuntimeException: ", dfp14, dfp21);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp2.rint();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.getZero();
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getZero();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp26.multiply(dfp29);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.rint();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp31.rint();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp2.nextAfter(dfp32);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.getZero();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField38.getZero();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp36.multiply(dfp39);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp36.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp36.getTwo();
        org.apache.commons.math.dfp.Dfp dfp45 = org.apache.commons.math.dfp.Dfp.copysign(dfp32, dfp36);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp45.getTwo();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.8623188722876839d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.862318872287684d + "'", double1 == 0.862318872287684d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        double double2 = mersenneTwister1.nextGaussian();
        mersenneTwister1.setSeed((long) (short) 10);
        int int6 = mersenneTwister1.nextInt(100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.866531296165219d + "'", double2 == 0.866531296165219d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 41 + "'", int6 == 41);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.multiply(dfp5);
        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        double double9 = mersenneTwister8.nextGaussian();
        double double10 = mersenneTwister8.nextDouble();
        boolean boolean11 = dfp6.equals((java.lang.Object) double10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp6.multiply((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp6.power10((int) (short) 1);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.866531296165219d + "'", double9 == 0.866531296165219d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0032884513038209384d + "'", double10 == 0.0032884513038209384d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        float float2 = mersenneTwister1.nextFloat();
        mersenneTwister1.setSeed((-2015080886171156972L));
        int int5 = mersenneTwister1.nextInt();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.011451006f + "'", float2 == 0.011451006f);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1635934220) + "'", int5 == (-1635934220));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 4L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        int int2 = org.apache.commons.math.util.FastMath.max(10, 32767);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32767 + "'", int2 == 32767);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = mathIllegalArgumentException8.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable11, objArray17);
        org.apache.commons.math.exception.util.Localizable localizable19 = mathIllegalArgumentException18.getGeneralPattern();
        mathIllegalArgumentException8.addSuppressed((java.lang.Throwable) mathIllegalArgumentException18);
        java.lang.String str21 = mathIllegalArgumentException18.toString();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException18);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNull(localizable9);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNull(localizable19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: " + "'", str21.equals("org.apache.commons.math.exception.MathIllegalArgumentException: "));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        double double1 = org.apache.commons.math.util.FastMath.asinh(22025.465794806718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.69310178011491d + "'", double1 == 10.69310178011491d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        double double2 = org.apache.commons.math.util.FastMath.pow(3.637978807091713E-12d, (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        double double1 = org.apache.commons.math.util.FastMath.ceil(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 2, (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister0.setSeed(32767);
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        int[] intArray7 = new int[] { (byte) 1, (short) 10 };
        mersenneTwister4.setSeed(intArray7);
        org.apache.commons.math.random.MersenneTwister mersenneTwister9 = new org.apache.commons.math.random.MersenneTwister(intArray7);
        mersenneTwister0.setSeed(intArray7);
        org.apache.commons.math.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math.random.MersenneTwister(intArray7);
        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister(intArray7);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.multiply(dfp5);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.rint();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.newInstance("hi!");
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister0.setSeed(32767);
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        int[] intArray7 = new int[] { (byte) 1, (short) 10 };
        mersenneTwister4.setSeed(intArray7);
        org.apache.commons.math.random.MersenneTwister mersenneTwister9 = new org.apache.commons.math.random.MersenneTwister(intArray7);
        mersenneTwister0.setSeed(intArray7);
        org.apache.commons.math.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math.random.MersenneTwister(intArray7);
        int int13 = mersenneTwister11.nextInt(32767);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 32412 + "'", int13 == 32412);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (short) 0, (double) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        dfpField1.clearIEEEFlags();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.negate();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.newInstance((byte) 3, (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.negate();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(32760);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        long long2 = org.apache.commons.math.util.FastMath.max(100L, 211235929750981552L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 211235929750981552L + "'", long2 == 211235929750981552L);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 1049191337521486288L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        double double1 = org.apache.commons.math.util.FastMath.tan(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5872139151569291d) + "'", double1 == (-0.5872139151569291d));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        long long2 = mersenneTwister1.nextLong();
        float float3 = mersenneTwister1.nextFloat();
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister((long) 1);
        byte[] byteArray9 = new byte[] { (byte) 2, (byte) 2, (byte) 1 };
        mersenneTwister5.nextBytes(byteArray9);
        java.lang.Class<?> wildcardClass11 = byteArray9.getClass();
        mersenneTwister1.nextBytes(byteArray9);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 211235929750981552L + "'", long2 == 211235929750981552L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.68564963f + "'", float3 == 0.68564963f);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (short) 10, 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3440585709080678E43d + "'", double2 == 1.3440585709080678E43d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.4885005257385622d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4530255085769369d + "'", double1 == 0.4530255085769369d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        double double1 = org.apache.commons.math.util.FastMath.acosh(39.891752054200694d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.379159631488079d + "'", double1 == 4.379159631488079d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0.011451006f, (java.lang.Number) (-1L), false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException6 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException4);
        java.lang.Number number7 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1L) + "'", number5.equals((-1L)));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1L) + "'", number7.equals((-1L)));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister();
        java.lang.Class<?> wildcardClass5 = mersenneTwister4.getClass();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable10, objArray16);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray16);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray16);
        org.apache.commons.math.exception.util.Localizable localizable20 = mathIllegalArgumentException19.getGeneralPattern();
        org.apache.commons.math.random.MersenneTwister mersenneTwister22 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        float float23 = mersenneTwister22.nextFloat();
        java.lang.Object[] objArray24 = new java.lang.Object[] { 0.68564963f, (short) 10, wildcardClass5, localizable20, float23 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray24);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException29 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException25, localizable26, localizable27, objArray28);
        java.lang.Object[] objArray30 = mathRuntimeException29.getArguments();
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNull(localizable20);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.011451006f + "'", float23 == 0.011451006f);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray30);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        double double2 = mersenneTwister1.nextGaussian();
        boolean boolean3 = mersenneTwister1.nextBoolean();
        mersenneTwister1.setSeed(0L);
        int int6 = mersenneTwister1.nextInt();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.866531296165219d + "'", double2 == 0.866531296165219d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 647325673 + "'", int6 == 647325673);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 10000);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.DfpField dfpField2 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField2.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField2.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField2.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getZero();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getZero();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp9.multiply(dfp12);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp9.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp9.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        dfpField19.clearIEEEFlags();
        int int21 = dfpField19.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField19.newDfp((long) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp24 = org.apache.commons.math.dfp.DfpField.computeLn(dfp6, dfp17, dfp23);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray27 = dfpField26.getESplit();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.getLn2();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField26.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.ceil();
        try {
            org.apache.commons.math.dfp.Dfp dfp32 = org.apache.commons.math.dfp.DfpField.computeLn(dfp0, dfp24, dfp30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfpArray27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) 1);
        mersenneTwister1.setSeed(1049191337521486288L);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.4369864387400422d, 22025.465794806718d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4369864387400424d + "'", double2 == 1.4369864387400424d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        double double1 = org.apache.commons.math.util.FastMath.tan((-0.9999999999999999d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5574077246549018d) + "'", double1 == (-1.5574077246549018d));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        double double1 = org.apache.commons.math.util.FastMath.floor(32767.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32767.0d + "'", double1 == 32767.0d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 2L, (float) 16);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfp2);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        dfpField1.clearIEEEFlags();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp6 = new org.apache.commons.math.dfp.Dfp(dfp5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8813735870195429d) + "'", double1 == (-0.8813735870195429d));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.1129943035738381d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.Dfp dfp1 = null;
        org.apache.commons.math.dfp.DfpField dfpField3 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField3.getZero();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getZero();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp4.multiply(dfp7);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp4.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getZero();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getZero();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.multiply(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.getZero();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp4.dotrap((-1), "org.apache.commons.math.exception.MathRuntimeException: ", dfp16, dfp23);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp4.getZero();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.newInstance();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp25.newInstance((byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode31 = dfpField30.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray32 = dfpField30.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField30.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        dfpField35.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField35.getSqr3Reciprocal();
        boolean boolean38 = dfp33.equals((java.lang.Object) dfpField35);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp25.multiply(dfp33);
        try {
            org.apache.commons.math.dfp.Dfp dfp40 = org.apache.commons.math.dfp.DfpField.computeLn(dfp0, dfp1, dfp33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + roundingMode31 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode31.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dfp39);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.multiply(dfp5);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp2.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getZero();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getZero();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.multiply(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getZero();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp2.dotrap((-1), "org.apache.commons.math.exception.MathRuntimeException: ", dfp14, dfp21);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp2.getZero();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp23.newInstance();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp23.power10K((int) (byte) 100);
        boolean boolean27 = dfp23.isNaN();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        double double1 = org.apache.commons.math.util.FastMath.asinh(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.99627207622075d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7835307228365398d + "'", double1 == 0.7835307228365398d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        dfpField1.clearIEEEFlags();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.negate();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp5.newInstance("org.apache.commons.math.exception.MathRuntimeException: ");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 97, (java.lang.Number) (-0.009999666686665238d), true);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 1);
        mersenneTwister1.setSeed((long) (-32767));
        float float4 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.017108321f + "'", float4 == 0.017108321f);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        dfpField1.clearIEEEFlags();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 3, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getPiSplit();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 4L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1578212823495775d + "'", double1 == 1.1578212823495775d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        float float1 = org.apache.commons.math.util.FastMath.abs(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        double double1 = org.apache.commons.math.util.FastMath.acos(39.891752054200694d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        dfpField1.setRoundingMode(roundingMode8);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        int[] intArray4 = new int[] { (byte) 1, (short) 10 };
        mersenneTwister1.setSeed(intArray4);
        long long6 = mersenneTwister1.nextLong();
        mersenneTwister1.setSeed(211235929750981552L);
        double double9 = mersenneTwister1.nextDouble();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2015080886171156972L) + "'", long6 == (-2015080886171156972L));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.34588514968740003d + "'", double9 == 0.34588514968740003d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.9342612293281634d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.54533234608214d + "'", double1 == 2.54533234608214d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (-1.5707963267912586d));
        java.lang.Number number3 = notStrictlyPositiveException2.getArgument();
        java.lang.Number number4 = notStrictlyPositiveException2.getArgument();
        java.lang.String str5 = notStrictlyPositiveException2.toString();
        org.apache.commons.math.exception.util.Localizable localizable6 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) (-1.5707963267912586d));
        java.lang.Number number10 = notStrictlyPositiveException9.getArgument();
        java.lang.Number number11 = notStrictlyPositiveException9.getArgument();
        java.lang.String str12 = notStrictlyPositiveException9.toString();
        org.apache.commons.math.exception.util.Localizable localizable13 = notStrictlyPositiveException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, localizable18, objArray24);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, localizable16, objArray24);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, objArray24);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException28 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException27);
        java.lang.Throwable[] throwableArray29 = mathIllegalArgumentException27.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable13, (java.lang.Object[]) throwableArray29);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException32 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable13, (java.lang.Number) (-0.6321205588285577d));
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException35 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable33, (java.lang.Number) (-1.5707963267912586d));
        java.lang.Number number36 = notStrictlyPositiveException35.getMin();
        notStrictlyPositiveException32.addSuppressed((java.lang.Throwable) notStrictlyPositiveException35);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (-1.5707963267912586d) + "'", number3.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.5707963267912586d) + "'", number4.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: -1.571 is smaller than, or equal to, the minimum (0)" + "'", str5.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: -1.571 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (-1.5707963267912586d) + "'", number10.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (-1.5707963267912586d) + "'", number11.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: -1.571 is smaller than, or equal to, the minimum (0)" + "'", str12.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: -1.571 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 0 + "'", number36.equals(0));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (short) 0, (double) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-1635934220), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 0, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn2();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister();
        java.lang.Class<?> wildcardClass5 = mersenneTwister4.getClass();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable10, objArray16);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray16);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray16);
        org.apache.commons.math.exception.util.Localizable localizable20 = mathIllegalArgumentException19.getGeneralPattern();
        org.apache.commons.math.random.MersenneTwister mersenneTwister22 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        float float23 = mersenneTwister22.nextFloat();
        java.lang.Object[] objArray24 = new java.lang.Object[] { 0.68564963f, (short) 10, wildcardClass5, localizable20, float23 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray24);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException29 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException25, localizable26, localizable27, objArray28);
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        java.lang.Object[] objArray37 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable30, localizable31, objArray37);
        org.apache.commons.math.exception.util.Localizable localizable39 = mathIllegalArgumentException38.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        java.lang.Object[] objArray47 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable40, localizable41, objArray47);
        org.apache.commons.math.exception.util.Localizable localizable49 = mathIllegalArgumentException48.getGeneralPattern();
        mathIllegalArgumentException38.addSuppressed((java.lang.Throwable) mathIllegalArgumentException48);
        mathIllegalArgumentException25.addSuppressed((java.lang.Throwable) mathIllegalArgumentException38);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException52 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException25);
        org.apache.commons.math.exception.util.Localizable localizable53 = mathIllegalArgumentException25.getSpecificPattern();
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNull(localizable20);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.011451006f + "'", float23 == 0.011451006f);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNull(localizable39);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNull(localizable49);
        org.junit.Assert.assertNull(localizable53);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        double double2 = mersenneTwister1.nextGaussian();
        long long3 = mersenneTwister1.nextLong();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.866531296165219d + "'", double2 == 0.866531296165219d);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 60661410412606597L + "'", long3 == 60661410412606597L);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (-1.5707963267912586d));
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 1);
        byte[] byteArray5 = new byte[] { (byte) 2, (byte) 2, (byte) 1 };
        mersenneTwister1.nextBytes(byteArray5);
        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        long long9 = mersenneTwister8.nextLong();
        float float10 = mersenneTwister8.nextFloat();
        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister((long) 1);
        byte[] byteArray16 = new byte[] { (byte) 2, (byte) 2, (byte) 1 };
        mersenneTwister12.nextBytes(byteArray16);
        mersenneTwister8.nextBytes(byteArray16);
        mersenneTwister1.nextBytes(byteArray16);
        org.apache.commons.math.random.MersenneTwister mersenneTwister21 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        int[] intArray24 = new int[] { (byte) 1, (short) 10 };
        mersenneTwister21.setSeed(intArray24);
        mersenneTwister1.setSeed(intArray24);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 211235929750981552L + "'", long9 == 211235929750981552L);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.68564963f + "'", float10 == 0.68564963f);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertNotNull(intArray24);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) (-1.5707963267912586d));
        java.lang.Number number4 = notStrictlyPositiveException3.getArgument();
        java.lang.Number number5 = notStrictlyPositiveException3.getArgument();
        java.lang.String str6 = notStrictlyPositiveException3.toString();
        org.apache.commons.math.exception.util.Localizable localizable7 = notStrictlyPositiveException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) (-1.5707963267912586d));
        java.lang.Number number11 = notStrictlyPositiveException10.getArgument();
        java.lang.Number number12 = notStrictlyPositiveException10.getArgument();
        java.lang.String str13 = notStrictlyPositiveException10.toString();
        org.apache.commons.math.exception.util.Localizable localizable14 = notStrictlyPositiveException10.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray25 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable19, objArray25);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray25);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, objArray25);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException29 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException28);
        java.lang.Throwable[] throwableArray30 = mathIllegalArgumentException28.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable14, (java.lang.Object[]) throwableArray30);
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.random.MersenneTwister mersenneTwister37 = new org.apache.commons.math.random.MersenneTwister();
        java.lang.Class<?> wildcardClass38 = mersenneTwister37.getClass();
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable42, localizable43, objArray49);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException51 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable40, localizable41, objArray49);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException52 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable39, objArray49);
        org.apache.commons.math.exception.util.Localizable localizable53 = mathIllegalArgumentException52.getGeneralPattern();
        org.apache.commons.math.random.MersenneTwister mersenneTwister55 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        float float56 = mersenneTwister55.nextFloat();
        java.lang.Object[] objArray57 = new java.lang.Object[] { 0.68564963f, (short) 10, wildcardClass38, localizable53, float56 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, localizable34, objArray57);
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        org.apache.commons.math.exception.util.Localizable localizable60 = null;
        java.lang.Object[] objArray61 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException62 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException58, localizable59, localizable60, objArray61);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException63 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable14, localizable32, objArray61);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.5707963267912586d) + "'", number4.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1.5707963267912586d) + "'", number5.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: -1.571 is smaller than, or equal to, the minimum (0)" + "'", str6.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: -1.571 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (-1.5707963267912586d) + "'", number11.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.5707963267912586d) + "'", number12.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: -1.571 is smaller than, or equal to, the minimum (0)" + "'", str13.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: -1.571 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNull(localizable53);
        org.junit.Assert.assertTrue("'" + float56 + "' != '" + 0.011451006f + "'", float56 == 0.011451006f);
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertNotNull(objArray61);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 10.0d, (java.lang.Number) 10000, false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.34588514968740003d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5881200129968372d + "'", double1 == 0.5881200129968372d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        double double1 = org.apache.commons.math.util.FastMath.asin((-1.1071487177940904d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.multiply(dfp5);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp2.newInstance((byte) 0, (byte) 10);
        double double10 = dfp9.toDouble();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp9.multiply(16);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + Double.NEGATIVE_INFINITY + "'", double10 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.multiply(dfp9);
        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        double double13 = mersenneTwister12.nextGaussian();
        double double14 = mersenneTwister12.nextDouble();
        boolean boolean15 = dfp10.equals((java.lang.Object) double14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp10.multiply(10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp(dfp10);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField1.getE();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.866531296165219d + "'", double13 == 0.866531296165219d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0032884513038209384d + "'", double14 == 0.0032884513038209384d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) 1);
        float float2 = mersenneTwister1.nextFloat();
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        int[] intArray7 = new int[] { (byte) 1, (short) 10 };
        mersenneTwister4.setSeed(intArray7);
        org.apache.commons.math.random.MersenneTwister mersenneTwister9 = new org.apache.commons.math.random.MersenneTwister(intArray7);
        mersenneTwister1.setSeed(intArray7);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.417022f + "'", float2 == 0.417022f);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.1071487177940904d), (java.lang.Number) 10.69310178011491d, false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 10, 16);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) -1);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(0L);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        int int2 = org.apache.commons.math.util.FastMath.min(0, 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.multiply(dfp5);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp2.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getZero();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getZero();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.multiply(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getZero();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp2.dotrap((-1), "org.apache.commons.math.exception.MathRuntimeException: ", dfp14, dfp21);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp2.divide(10);
        org.apache.commons.math.dfp.Dfp dfp25 = new org.apache.commons.math.dfp.Dfp(dfp24);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        long long2 = mersenneTwister1.nextLong();
        int int3 = mersenneTwister1.nextInt();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 211235929750981552L + "'", long2 == 211235929750981552L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1350124506) + "'", int3 == (-1350124506));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.multiply(dfp9);
        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        double double13 = mersenneTwister12.nextGaussian();
        double double14 = mersenneTwister12.nextDouble();
        boolean boolean15 = dfp10.equals((java.lang.Object) double14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp10.multiply(10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp(dfp10);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        int int21 = dfpField20.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getZero();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getZero();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp25.multiply(dfp28);
        org.apache.commons.math.random.MersenneTwister mersenneTwister31 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        double double32 = mersenneTwister31.nextGaussian();
        double double33 = mersenneTwister31.nextDouble();
        boolean boolean34 = dfp29.equals((java.lang.Object) double33);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp29.multiply((int) (short) 10);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField38.getZero();
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField41.getZero();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp39.multiply(dfp42);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp39.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField50.getZero();
        org.apache.commons.math.dfp.DfpField dfpField53 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField53.getZero();
        org.apache.commons.math.dfp.Dfp dfp55 = dfp51.multiply(dfp54);
        org.apache.commons.math.dfp.DfpField dfpField57 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField57.getZero();
        org.apache.commons.math.dfp.Dfp dfp59 = dfp39.dotrap((-1), "org.apache.commons.math.exception.MathRuntimeException: ", dfp51, dfp58);
        boolean boolean60 = dfp36.greaterThan(dfp51);
        org.apache.commons.math.dfp.Dfp dfp61 = dfp22.newInstance(dfp51);
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField1.newDfp(dfp22);
        org.apache.commons.math.dfp.Dfp dfp64 = dfp62.power10K((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.866531296165219d + "'", double13 == 0.866531296165219d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0032884513038209384d + "'", double14 == 0.0032884513038209384d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 16 + "'", int21 == 16);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.866531296165219d + "'", double32 == 0.866531296165219d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0032884513038209384d + "'", double33 == 0.0032884513038209384d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp64);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (short) 0, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.34588514968740003d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3458851496874001d + "'", double1 == 0.3458851496874001d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 100L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 16);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        double double1 = org.apache.commons.math.util.FastMath.asin(97.00000000000001d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-1350124506));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.350124506E9d) + "'", double1 == (-1.350124506E9d));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 52.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9155040003582885E22d + "'", double1 == 1.9155040003582885E22d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 1);
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        int[] intArray6 = new int[] { (byte) 1, (short) 10 };
        mersenneTwister3.setSeed(intArray6);
        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        mersenneTwister1.setSeed(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.multiply(dfp5);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp2.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getZero();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getZero();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.multiply(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getZero();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp2.dotrap((-1), "org.apache.commons.math.exception.MathRuntimeException: ", dfp14, dfp21);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp2.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp2.getOne();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.multiply(dfp5);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp2.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getZero();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getZero();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.multiply(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getZero();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp2.dotrap((-1), "org.apache.commons.math.exception.MathRuntimeException: ", dfp14, dfp21);
        java.lang.String str23 = dfp21.toString();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0." + "'", str23.equals("0."));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.power10K((int) 'a');
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        double double1 = org.apache.commons.math.util.FastMath.exp((-0.8813735870195429d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4142135623730951d + "'", double1 == 0.4142135623730951d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.multiply(dfp5);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp2.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getZero();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getZero();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.multiply(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getZero();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp2.dotrap((-1), "org.apache.commons.math.exception.MathRuntimeException: ", dfp14, dfp21);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp2.getZero();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp23.newInstance();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp23.newInstance((byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode29 = dfpField28.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField28.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField28.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        dfpField33.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.getSqr3Reciprocal();
        boolean boolean36 = dfp31.equals((java.lang.Object) dfpField33);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp23.multiply(dfp31);
        double double38 = dfp23.toDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + roundingMode29 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode29.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + Double.NEGATIVE_INFINITY + "'", double38 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        dfpField6.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getSqr3Reciprocal();
        boolean boolean9 = dfp4.equals((java.lang.Object) dfpField6);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.negate();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = mathIllegalArgumentException8.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable11, objArray17);
        org.apache.commons.math.exception.util.Localizable localizable19 = mathIllegalArgumentException18.getGeneralPattern();
        mathIllegalArgumentException8.addSuppressed((java.lang.Throwable) mathIllegalArgumentException18);
        org.apache.commons.math.exception.util.Localizable localizable21 = mathIllegalArgumentException18.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable22 = mathIllegalArgumentException18.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNull(localizable9);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNull(localizable19);
        org.junit.Assert.assertNull(localizable21);
        org.junit.Assert.assertNull(localizable22);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-32767), (long) 10000);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10000L + "'", long2 == 10000L);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5872139151569291d) + "'", double1 == (-0.5872139151569291d));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister();
        java.lang.Class<?> wildcardClass5 = mersenneTwister4.getClass();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable10, objArray16);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray16);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray16);
        org.apache.commons.math.exception.util.Localizable localizable20 = mathIllegalArgumentException19.getGeneralPattern();
        org.apache.commons.math.random.MersenneTwister mersenneTwister22 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        float float23 = mersenneTwister22.nextFloat();
        java.lang.Object[] objArray24 = new java.lang.Object[] { 0.68564963f, (short) 10, wildcardClass5, localizable20, float23 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray24);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException29 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException25, localizable26, localizable27, objArray28);
        java.lang.String str30 = mathRuntimeException29.toString();
        org.apache.commons.math.exception.util.Localizable localizable31 = mathRuntimeException29.getSpecificPattern();
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNull(localizable20);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.011451006f + "'", float23 == 0.011451006f);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str30.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNull(localizable31);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.multiply(dfp5);
        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        double double9 = mersenneTwister8.nextGaussian();
        double double10 = mersenneTwister8.nextDouble();
        boolean boolean11 = dfp6.equals((java.lang.Object) double10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp6.multiply((int) (short) 10);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getZero();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getZero();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.multiply(dfp19);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp16.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getZero();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getZero();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp28.multiply(dfp31);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.getZero();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp16.dotrap((-1), "org.apache.commons.math.exception.MathRuntimeException: ", dfp28, dfp35);
        boolean boolean37 = dfp13.greaterThan(dfp28);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp28.newInstance("0.");
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.866531296165219d + "'", double9 == 0.866531296165219d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0032884513038209384d + "'", double10 == 0.0032884513038209384d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(dfp39);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1071487177940904d + "'", double1 == 1.1071487177940904d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        int int2 = org.apache.commons.math.util.FastMath.min(32760, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (-1.5707963267912586d));
        java.lang.Number number3 = notStrictlyPositiveException2.getArgument();
        java.lang.Number number4 = notStrictlyPositiveException2.getArgument();
        java.lang.Number number5 = notStrictlyPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (-1.5707963267912586d) + "'", number3.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.5707963267912586d) + "'", number4.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        double double2 = org.apache.commons.math.util.FastMath.max(5.298292365610485d, (double) 0.011451006f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.298292365610485d + "'", double2 == 5.298292365610485d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.5395564933646284d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9969953215678263d + "'", double1 == 0.9969953215678263d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.multiply(dfp5);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp2.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance(1.4575601846855093d);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.multiply(dfp9);
        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        double double13 = mersenneTwister12.nextGaussian();
        double double14 = mersenneTwister12.nextDouble();
        boolean boolean15 = dfp10.equals((java.lang.Object) double14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp10.multiply((int) (short) 10);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getZero();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.getZero();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp20.multiply(dfp23);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp20.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getZero();
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.getZero();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp32.multiply(dfp35);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField38.getZero();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp20.dotrap((-1), "org.apache.commons.math.exception.MathRuntimeException: ", dfp32, dfp39);
        boolean boolean41 = dfp17.greaterThan(dfp32);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp3.newInstance(dfp32);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        dfpField44.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField44.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp32.newInstance(dfp46);
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField49.getZero();
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField52.getZero();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp50.multiply(dfp53);
        org.apache.commons.math.dfp.Dfp dfp57 = dfp50.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField61 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField61.getZero();
        org.apache.commons.math.dfp.DfpField dfpField64 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp65 = dfpField64.getZero();
        org.apache.commons.math.dfp.Dfp dfp66 = dfp62.multiply(dfp65);
        org.apache.commons.math.dfp.DfpField dfpField68 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp69 = dfpField68.getZero();
        org.apache.commons.math.dfp.Dfp dfp70 = dfp50.dotrap((-1), "org.apache.commons.math.exception.MathRuntimeException: ", dfp62, dfp69);
        org.apache.commons.math.dfp.Dfp dfp72 = dfp50.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp74 = dfp72.newInstance((-982170359));
        org.apache.commons.math.dfp.Dfp dfp75 = dfp32.remainder(dfp72);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.866531296165219d + "'", double13 == 0.866531296165219d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0032884513038209384d + "'", double14 == 0.0032884513038209384d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp75);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.8623188722876839d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 32760);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32760.000000000004d + "'", double1 == 32760.000000000004d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray9);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray9);
        java.lang.Throwable[] throwableArray12 = mathIllegalArgumentException11.getSuppressed();
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(throwableArray12);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.multiply(dfp9);
        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        double double13 = mersenneTwister12.nextGaussian();
        double double14 = mersenneTwister12.nextDouble();
        boolean boolean15 = dfp10.equals((java.lang.Object) double14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp10.multiply(10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp(dfp10);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        int int21 = dfpField20.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getZero();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getZero();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp25.multiply(dfp28);
        org.apache.commons.math.random.MersenneTwister mersenneTwister31 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        double double32 = mersenneTwister31.nextGaussian();
        double double33 = mersenneTwister31.nextDouble();
        boolean boolean34 = dfp29.equals((java.lang.Object) double33);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp29.multiply((int) (short) 10);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField38.getZero();
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField41.getZero();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp39.multiply(dfp42);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp39.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField50.getZero();
        org.apache.commons.math.dfp.DfpField dfpField53 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField53.getZero();
        org.apache.commons.math.dfp.Dfp dfp55 = dfp51.multiply(dfp54);
        org.apache.commons.math.dfp.DfpField dfpField57 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField57.getZero();
        org.apache.commons.math.dfp.Dfp dfp59 = dfp39.dotrap((-1), "org.apache.commons.math.exception.MathRuntimeException: ", dfp51, dfp58);
        boolean boolean60 = dfp36.greaterThan(dfp51);
        org.apache.commons.math.dfp.Dfp dfp61 = dfp22.newInstance(dfp51);
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField1.newDfp(dfp22);
        org.apache.commons.math.dfp.Dfp dfp63 = dfp22.getZero();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.866531296165219d + "'", double13 == 0.866531296165219d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0032884513038209384d + "'", double14 == 0.0032884513038209384d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 16 + "'", int21 == 16);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.866531296165219d + "'", double32 == 0.866531296165219d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0032884513038209384d + "'", double33 == 0.0032884513038209384d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0.011451006f, (java.lang.Number) (-1L), false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException6 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) (-1.5707963267912586d));
        java.lang.Number number10 = notStrictlyPositiveException9.getArgument();
        java.lang.Number number11 = notStrictlyPositiveException9.getMin();
        mathRuntimeException6.addSuppressed((java.lang.Throwable) notStrictlyPositiveException9);
        java.lang.Number number13 = notStrictlyPositiveException9.getMin();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1L) + "'", number5.equals((-1L)));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (-1.5707963267912586d) + "'", number10.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0 + "'", number11.equals(0));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0 + "'", number13.equals(0));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.multiply(dfp5);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp2.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp2.getTwo();
        int int11 = dfp2.intValue();
        double double12 = dfp2.toDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + Double.NEGATIVE_INFINITY + "'", double12 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 8);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 8L + "'", long1 == 8L);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister();
        java.lang.Class<?> wildcardClass5 = mersenneTwister4.getClass();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable10, objArray16);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray16);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray16);
        org.apache.commons.math.exception.util.Localizable localizable20 = mathIllegalArgumentException19.getGeneralPattern();
        org.apache.commons.math.random.MersenneTwister mersenneTwister22 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        float float23 = mersenneTwister22.nextFloat();
        java.lang.Object[] objArray24 = new java.lang.Object[] { 0.68564963f, (short) 10, wildcardClass5, localizable20, float23 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray24);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException29 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException25, localizable26, localizable27, objArray28);
        java.lang.Object[] objArray30 = mathIllegalArgumentException25.getArguments();
        java.lang.Throwable[] throwableArray31 = mathIllegalArgumentException25.getSuppressed();
        java.lang.Throwable[] throwableArray32 = mathIllegalArgumentException25.getSuppressed();
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNull(localizable20);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.011451006f + "'", float23 == 0.011451006f);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertNotNull(throwableArray32);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        int[] intArray4 = new int[] { (byte) 1, (short) 10 };
        mersenneTwister1.setSeed(intArray4);
        long long6 = mersenneTwister1.nextLong();
        double double7 = mersenneTwister1.nextGaussian();
        long long8 = mersenneTwister1.nextLong();
        long long9 = mersenneTwister1.nextLong();
        long long10 = mersenneTwister1.nextLong();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2015080886171156972L) + "'", long6 == (-2015080886171156972L));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.46314732482245285d + "'", double7 == 0.46314732482245285d);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1049191337521486288L + "'", long8 == 1049191337521486288L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2115988564729650894L + "'", long9 == 2115988564729650894L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 8965537915598411875L + "'", long10 == 8965537915598411875L);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 4.248291097914389d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.4575601846855093d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.11299430357383815d + "'", double1 == 0.11299430357383815d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.multiply(dfp5);
        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        double double9 = mersenneTwister8.nextGaussian();
        double double10 = mersenneTwister8.nextDouble();
        boolean boolean11 = dfp6.equals((java.lang.Object) double10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp6.multiply(10);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp6.newInstance((byte) 10);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.866531296165219d + "'", double9 == 0.866531296165219d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0032884513038209384d + "'", double10 == 0.0032884513038209384d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        int int4 = dfp3.log10();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = dfpField1.getRoundingMode();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 211235929750981552L);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        double double1 = org.apache.commons.math.util.FastMath.ceil(16.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 16.0d + "'", double1 == 16.0d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 4L, 10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3805063771123649d + "'", double2 == 0.3805063771123649d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        int int4 = dfp3.classify();
        org.apache.commons.math.dfp.Dfp dfp5 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp6 = dfp3.newInstance(dfp5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 10000.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) 0.32825363f, true);
    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test338");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        int int1 = mersenneTwister0.nextInt();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-600411813) + "'", int1 == (-600411813));
//    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        float float2 = org.apache.commons.math.util.FastMath.max(0.8907622f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.8907622f + "'", float2 == 0.8907622f);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7615941559557649d) + "'", double1 == (-0.7615941559557649d));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1622776601683795d + "'", double1 == 3.1622776601683795d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.ceil();
        boolean boolean8 = dfp6.equals((java.lang.Object) 2.0d);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.ceil();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.negate();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp5.negate();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.multiply(dfp5);
        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        double double9 = mersenneTwister8.nextGaussian();
        double double10 = mersenneTwister8.nextDouble();
        boolean boolean11 = dfp6.equals((java.lang.Object) double10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp6.multiply((int) (short) 10);
        int int14 = dfp13.log10K();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.866531296165219d + "'", double9 == 0.866531296165219d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0032884513038209384d + "'", double10 == 0.0032884513038209384d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 10000L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (byte) 1, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(32760);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField6 = dfp5.getField();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpField6);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.multiply(dfp5);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp2.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getZero();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getZero();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.multiply(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getZero();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp2.dotrap((-1), "org.apache.commons.math.exception.MathRuntimeException: ", dfp14, dfp21);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp2.getZero();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp23.newInstance();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp23.power10K((int) (byte) 100);
        double double27 = dfp23.toDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.NEGATIVE_INFINITY + "'", double27 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5574077246549023d + "'", double1 == 1.5574077246549023d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-4));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 4L + "'", long1 == 4L);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        double double1 = org.apache.commons.math.util.FastMath.cosh(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.multiply(dfp5);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.rint();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.rint();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp11 = dfp8.remainder(dfp10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 10L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1635934220));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
        org.junit.Assert.assertNotNull(dfpArray4);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.multiply(dfp9);
        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        double double13 = mersenneTwister12.nextGaussian();
        double double14 = mersenneTwister12.nextDouble();
        boolean boolean15 = dfp10.equals((java.lang.Object) double14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp10.multiply(10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp(dfp10);
        int int19 = dfp18.log10();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.866531296165219d + "'", double13 == 0.866531296165219d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0032884513038209384d + "'", double14 == 0.0032884513038209384d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-4) + "'", int19 == (-4));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 0);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        dfpField1.clearIEEEFlags();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) '4');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.multiply(dfp9);
        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        double double13 = mersenneTwister12.nextGaussian();
        double double14 = mersenneTwister12.nextDouble();
        boolean boolean15 = dfp10.equals((java.lang.Object) double14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp10.multiply(10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp(dfp10);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        int int21 = dfpField20.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getZero();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getZero();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp25.multiply(dfp28);
        org.apache.commons.math.random.MersenneTwister mersenneTwister31 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        double double32 = mersenneTwister31.nextGaussian();
        double double33 = mersenneTwister31.nextDouble();
        boolean boolean34 = dfp29.equals((java.lang.Object) double33);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp29.multiply((int) (short) 10);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField38.getZero();
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField41.getZero();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp39.multiply(dfp42);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp39.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField50.getZero();
        org.apache.commons.math.dfp.DfpField dfpField53 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField53.getZero();
        org.apache.commons.math.dfp.Dfp dfp55 = dfp51.multiply(dfp54);
        org.apache.commons.math.dfp.DfpField dfpField57 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField57.getZero();
        org.apache.commons.math.dfp.Dfp dfp59 = dfp39.dotrap((-1), "org.apache.commons.math.exception.MathRuntimeException: ", dfp51, dfp58);
        boolean boolean60 = dfp36.greaterThan(dfp51);
        org.apache.commons.math.dfp.Dfp dfp61 = dfp22.newInstance(dfp51);
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField1.newDfp(dfp22);
        org.apache.commons.math.dfp.Dfp dfp63 = new org.apache.commons.math.dfp.Dfp(dfp62);
        org.apache.commons.math.dfp.Dfp dfp65 = dfp62.newInstance(0);
        org.apache.commons.math.dfp.Dfp dfp66 = dfp62.getOne();
        org.apache.commons.math.dfp.Dfp dfp67 = dfp62.rint();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.866531296165219d + "'", double13 == 0.866531296165219d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0032884513038209384d + "'", double14 == 0.0032884513038209384d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 16 + "'", int21 == 16);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.866531296165219d + "'", double32 == 0.866531296165219d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0032884513038209384d + "'", double33 == 0.0032884513038209384d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp67);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.multiply(dfp5);
        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        double double9 = mersenneTwister8.nextGaussian();
        double double10 = mersenneTwister8.nextDouble();
        boolean boolean11 = dfp6.equals((java.lang.Object) double10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp6.multiply(10);
        int int14 = dfp13.intValue();
        int int15 = dfp13.intValue();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.866531296165219d + "'", double9 == 0.866531296165219d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0032884513038209384d + "'", double10 == 0.0032884513038209384d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 0, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getLn2();
        int int11 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 1);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 32767);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (-1.5707963267912586d));
        java.lang.Number number3 = notStrictlyPositiveException2.getArgument();
        java.lang.Number number4 = notStrictlyPositiveException2.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException2.getSpecificPattern();
        java.lang.Object[] objArray6 = notStrictlyPositiveException2.getArguments();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (-1.5707963267912586d) + "'", number3.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.5707963267912586d) + "'", number4.equals((-1.5707963267912586d)));
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertNotNull(objArray6);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister();
        java.lang.Class<?> wildcardClass5 = mersenneTwister4.getClass();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable10, objArray16);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray16);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray16);
        org.apache.commons.math.exception.util.Localizable localizable20 = mathIllegalArgumentException19.getGeneralPattern();
        org.apache.commons.math.random.MersenneTwister mersenneTwister22 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        float float23 = mersenneTwister22.nextFloat();
        java.lang.Object[] objArray24 = new java.lang.Object[] { 0.68564963f, (short) 10, wildcardClass5, localizable20, float23 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray24);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException29 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException25, localizable26, localizable27, objArray28);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException30 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException25);
        org.apache.commons.math.exception.util.Localizable localizable31 = mathIllegalArgumentException25.getSpecificPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException32 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException25);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNull(localizable20);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.011451006f + "'", float23 == 0.011451006f);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNull(localizable31);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.multiply(dfp5);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp2.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getZero();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getZero();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.multiply(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getZero();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp2.dotrap((-1), "org.apache.commons.math.exception.MathRuntimeException: ", dfp14, dfp21);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp2.getZero();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp23.newInstance();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp23.newInstance((byte) 1);
        java.lang.Object obj27 = null;
        boolean boolean28 = dfp26.equals(obj27);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 1);
        mersenneTwister1.setSeed((long) (-32767));
        mersenneTwister1.setSeed((int) (short) 100);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        dfpField1.setIEEEFlags(0);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray6);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.8907622435414719d, 22026.465794806718d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0440543269810254E-5d + "'", double2 == 4.0440543269810254E-5d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-4));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8813735870195432d + "'", double1 == 0.8813735870195432d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        dfpField6.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getSqr3Reciprocal();
        boolean boolean9 = dfp4.equals((java.lang.Object) dfpField6);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp4.power10((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        try {
            org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((-2015080886171156972L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.9342612293281634d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9775885558328918d + "'", double1 == 0.9775885558328918d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1350124506), (float) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.35012454E9f) + "'", float2 == (-1.35012454E9f));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.0d + "'", double1 == 97.0d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.multiply(dfp5);
        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        double double9 = mersenneTwister8.nextGaussian();
        double double10 = mersenneTwister8.nextDouble();
        boolean boolean11 = dfp6.equals((java.lang.Object) double10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp6.multiply((int) (short) 10);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getZero();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getZero();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.multiply(dfp19);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp16.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getZero();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getZero();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp28.multiply(dfp31);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.getZero();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp16.dotrap((-1), "org.apache.commons.math.exception.MathRuntimeException: ", dfp28, dfp35);
        boolean boolean37 = dfp13.greaterThan(dfp28);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp13.ceil();
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField40.getZero();
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField43.getZero();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp41.multiply(dfp44);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp41.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField52.getZero();
        org.apache.commons.math.dfp.DfpField dfpField55 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField55.getZero();
        org.apache.commons.math.dfp.Dfp dfp57 = dfp53.multiply(dfp56);
        org.apache.commons.math.dfp.DfpField dfpField59 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField59.getZero();
        org.apache.commons.math.dfp.Dfp dfp61 = dfp41.dotrap((-1), "org.apache.commons.math.exception.MathRuntimeException: ", dfp53, dfp60);
        org.apache.commons.math.dfp.Dfp dfp62 = dfp41.rint();
        org.apache.commons.math.dfp.DfpField dfpField64 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp65 = dfpField64.getZero();
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField67.getZero();
        org.apache.commons.math.dfp.Dfp dfp69 = dfp65.multiply(dfp68);
        org.apache.commons.math.dfp.Dfp dfp70 = dfp69.rint();
        org.apache.commons.math.dfp.Dfp dfp71 = dfp70.rint();
        org.apache.commons.math.dfp.Dfp dfp72 = dfp41.nextAfter(dfp71);
        org.apache.commons.math.dfp.DfpField dfpField74 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp75 = dfpField74.getZero();
        org.apache.commons.math.dfp.DfpField dfpField77 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp78 = dfpField77.getZero();
        org.apache.commons.math.dfp.Dfp dfp79 = dfp75.multiply(dfp78);
        org.apache.commons.math.dfp.Dfp dfp82 = dfp75.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp83 = dfp75.getTwo();
        org.apache.commons.math.dfp.Dfp dfp84 = org.apache.commons.math.dfp.Dfp.copysign(dfp71, dfp75);
        boolean boolean85 = dfp38.greaterThan(dfp75);
        org.apache.commons.math.dfp.Dfp dfp86 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp87 = dfp75.remainder(dfp86);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.866531296165219d + "'", double9 == 0.866531296165219d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0032884513038209384d + "'", double10 == 0.0032884513038209384d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertNotNull(dfp79);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertNotNull(dfp84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        int[] intArray4 = new int[] { (byte) 1, (short) 10 };
        mersenneTwister1.setSeed(intArray4);
        org.apache.commons.math.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3Reciprocal();
        dfpField1.setIEEEFlags((-982170359));
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        dfpField1.clearIEEEFlags();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 3, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp(0L);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray19);
        boolean boolean21 = dfp11.equals((java.lang.Object) localizable12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(32760);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getZero();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp8.multiply(dfp11);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp8.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getZero();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.getZero();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp20.multiply(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getZero();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp8.dotrap((-1), "org.apache.commons.math.exception.MathRuntimeException: ", dfp20, dfp27);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp8.getZero();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField1.newDfp(dfp29);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getZero();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp8.multiply(dfp11);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp8.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp8.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        dfpField18.clearIEEEFlags();
        int int20 = dfpField18.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField18.newDfp((long) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp23 = org.apache.commons.math.dfp.DfpField.computeLn(dfp5, dfp16, dfp22);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp16.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getZero();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getZero();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp27.multiply(dfp30);
        org.apache.commons.math.random.MersenneTwister mersenneTwister33 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        double double34 = mersenneTwister33.nextGaussian();
        double double35 = mersenneTwister33.nextDouble();
        boolean boolean36 = dfp31.equals((java.lang.Object) double35);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp31.multiply((int) (short) 10);
        boolean boolean39 = dfp38.isNaN();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp16.divide(dfp38);
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField42.getZero();
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.getZero();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp43.multiply(dfp46);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp43.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField54.getZero();
        org.apache.commons.math.dfp.DfpField dfpField57 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField57.getZero();
        org.apache.commons.math.dfp.Dfp dfp59 = dfp55.multiply(dfp58);
        org.apache.commons.math.dfp.DfpField dfpField61 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField61.getZero();
        org.apache.commons.math.dfp.Dfp dfp63 = dfp43.dotrap((-1), "org.apache.commons.math.exception.MathRuntimeException: ", dfp55, dfp62);
        org.apache.commons.math.dfp.Dfp dfp64 = dfp43.rint();
        org.apache.commons.math.dfp.DfpField dfpField66 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField66.getZero();
        org.apache.commons.math.dfp.DfpField dfpField69 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField69.getZero();
        org.apache.commons.math.dfp.Dfp dfp71 = dfp67.multiply(dfp70);
        org.apache.commons.math.dfp.Dfp dfp72 = dfp71.rint();
        org.apache.commons.math.dfp.Dfp dfp73 = dfp72.rint();
        org.apache.commons.math.dfp.Dfp dfp74 = dfp43.nextAfter(dfp73);
        org.apache.commons.math.dfp.DfpField dfpField76 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp77 = dfpField76.getZero();
        org.apache.commons.math.dfp.DfpField dfpField79 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp80 = dfpField79.getZero();
        org.apache.commons.math.dfp.Dfp dfp81 = dfp77.multiply(dfp80);
        org.apache.commons.math.dfp.Dfp dfp84 = dfp77.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp85 = dfp77.getTwo();
        org.apache.commons.math.dfp.Dfp dfp86 = org.apache.commons.math.dfp.Dfp.copysign(dfp73, dfp77);
        boolean boolean87 = dfp16.unequal(dfp73);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.866531296165219d + "'", double34 == 0.866531296165219d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0032884513038209384d + "'", double35 == 0.0032884513038209384d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertNotNull(dfp80);
        org.junit.Assert.assertNotNull(dfp81);
        org.junit.Assert.assertNotNull(dfp84);
        org.junit.Assert.assertNotNull(dfp85);
        org.junit.Assert.assertNotNull(dfp86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.multiply(dfp5);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.rint();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) (-1.5707963267912586d));
        java.lang.Number number11 = notStrictlyPositiveException10.getArgument();
        java.lang.Number number12 = notStrictlyPositiveException10.getArgument();
        boolean boolean13 = dfp6.equals((java.lang.Object) notStrictlyPositiveException10);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getZero();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getZero();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.multiply(dfp19);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp16.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getZero();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getZero();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp28.multiply(dfp31);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.getZero();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp16.dotrap((-1), "org.apache.commons.math.exception.MathRuntimeException: ", dfp28, dfp35);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp16.rint();
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField39.getZero();
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField42.getZero();
        org.apache.commons.math.dfp.Dfp dfp44 = dfp40.multiply(dfp43);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp44.rint();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp45.rint();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp16.nextAfter(dfp46);
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField49.getZero();
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField52.getZero();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp50.multiply(dfp53);
        org.apache.commons.math.dfp.Dfp dfp57 = dfp50.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField61 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField61.getZero();
        org.apache.commons.math.dfp.DfpField dfpField64 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp65 = dfpField64.getZero();
        org.apache.commons.math.dfp.Dfp dfp66 = dfp62.multiply(dfp65);
        org.apache.commons.math.dfp.DfpField dfpField68 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp69 = dfpField68.getZero();
        org.apache.commons.math.dfp.Dfp dfp70 = dfp50.dotrap((-1), "org.apache.commons.math.exception.MathRuntimeException: ", dfp62, dfp69);
        org.apache.commons.math.dfp.Dfp dfp71 = dfp50.getZero();
        org.apache.commons.math.dfp.Dfp dfp72 = dfp16.add(dfp71);
        org.apache.commons.math.dfp.Dfp dfp73 = dfp6.newInstance(dfp71);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (-1.5707963267912586d) + "'", number11.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.5707963267912586d) + "'", number12.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp73);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode11 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        dfpField10.setRoundingMode(roundingMode11);
        dfpField1.setRoundingMode(roundingMode11);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + roundingMode11 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode11.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        int int1 = org.apache.commons.math.util.FastMath.round(10.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (-1.5707963267912586d));
        java.lang.Number number3 = notStrictlyPositiveException2.getArgument();
        java.lang.Number number4 = notStrictlyPositiveException2.getArgument();
        java.lang.String str5 = notStrictlyPositiveException2.toString();
        org.apache.commons.math.exception.util.Localizable localizable6 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) (-1.5707963267912586d));
        java.lang.Number number10 = notStrictlyPositiveException9.getArgument();
        java.lang.Number number11 = notStrictlyPositiveException9.getArgument();
        java.lang.String str12 = notStrictlyPositiveException9.toString();
        org.apache.commons.math.exception.util.Localizable localizable13 = notStrictlyPositiveException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, localizable18, objArray24);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, localizable16, objArray24);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, objArray24);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException28 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException27);
        java.lang.Throwable[] throwableArray29 = mathIllegalArgumentException27.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable13, (java.lang.Object[]) throwableArray29);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException32 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable13, (java.lang.Number) (-0.6321205588285577d));
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException35 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable33, (java.lang.Number) (-1.5707963267912586d));
        java.lang.Number number36 = notStrictlyPositiveException35.getArgument();
        java.lang.Number number37 = notStrictlyPositiveException35.getArgument();
        java.lang.String str38 = notStrictlyPositiveException35.toString();
        org.apache.commons.math.exception.util.Localizable localizable39 = notStrictlyPositiveException35.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException42 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable40, (java.lang.Number) (-1.5707963267912586d));
        java.lang.Number number43 = notStrictlyPositiveException42.getArgument();
        java.lang.Number number44 = notStrictlyPositiveException42.getArgument();
        java.lang.String str45 = notStrictlyPositiveException42.toString();
        org.apache.commons.math.exception.util.Localizable localizable46 = notStrictlyPositiveException42.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable47 = null;
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        org.apache.commons.math.exception.util.Localizable localizable51 = null;
        java.lang.Object[] objArray57 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable50, localizable51, objArray57);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable48, localizable49, objArray57);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException60 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable47, objArray57);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException61 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException60);
        java.lang.Throwable[] throwableArray62 = mathIllegalArgumentException60.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable39, localizable46, (java.lang.Object[]) throwableArray62);
        java.lang.Object[] objArray64 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, localizable39, objArray64);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException66 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException65);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (-1.5707963267912586d) + "'", number3.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.5707963267912586d) + "'", number4.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: -1.571 is smaller than, or equal to, the minimum (0)" + "'", str5.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: -1.571 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (-1.5707963267912586d) + "'", number10.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (-1.5707963267912586d) + "'", number11.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: -1.571 is smaller than, or equal to, the minimum (0)" + "'", str12.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: -1.571 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + (-1.5707963267912586d) + "'", number36.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + (-1.5707963267912586d) + "'", number37.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: -1.571 is smaller than, or equal to, the minimum (0)" + "'", str38.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: -1.571 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable39.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + (-1.5707963267912586d) + "'", number43.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + number44 + "' != '" + (-1.5707963267912586d) + "'", number44.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: -1.571 is smaller than, or equal to, the minimum (0)" + "'", str45.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: -1.571 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable46 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable46.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertNotNull(throwableArray62);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        double double1 = org.apache.commons.math.util.FastMath.log(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6931471805599453d + "'", double1 == 0.6931471805599453d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        double double1 = org.apache.commons.math.util.FastMath.sin((-2.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9092974268256817d) + "'", double1 == (-0.9092974268256817d));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp3.newInstance();
        org.apache.commons.math.dfp.Dfp dfp5 = new org.apache.commons.math.dfp.Dfp(dfp4);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 60661410412606597L, (float) 97);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 6.0661409E16f + "'", float2 == 6.0661409E16f);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        dfpField1.clearIEEEFlags();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        int int7 = dfp6.intValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 1);
        mersenneTwister1.setSeed((long) (-32767));
        int int4 = mersenneTwister1.nextInt();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 73479844 + "'", int4 == 73479844);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 73479844, 0.9999999958776927d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.3479844E7d + "'", double2 == 7.3479844E7d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        dfpField1.clearIEEEFlags();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.negate();
        int int7 = dfp5.classify();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        dfpField1.clearIEEEFlags();
        int int3 = dfpField1.getRadixDigits();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        double double1 = org.apache.commons.math.util.FastMath.acosh(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3169578969248166d + "'", double1 == 1.3169578969248166d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 1);
        byte[] byteArray5 = new byte[] { (byte) 2, (byte) 2, (byte) 1 };
        mersenneTwister1.nextBytes(byteArray5);
        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        long long9 = mersenneTwister8.nextLong();
        float float10 = mersenneTwister8.nextFloat();
        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister((long) 1);
        byte[] byteArray16 = new byte[] { (byte) 2, (byte) 2, (byte) 1 };
        mersenneTwister12.nextBytes(byteArray16);
        mersenneTwister8.nextBytes(byteArray16);
        mersenneTwister1.nextBytes(byteArray16);
        double double20 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 211235929750981552L + "'", long9 == 211235929750981552L);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.68564963f + "'", float10 == 0.68564963f);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-2.4884135600096027d) + "'", double20 == (-2.4884135600096027d));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn5();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getE();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 10L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.multiply(dfp5);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp2.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getZero();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getZero();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.multiply(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getZero();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp2.dotrap((-1), "org.apache.commons.math.exception.MathRuntimeException: ", dfp14, dfp21);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp2.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp24.newInstance(0L);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp26.getZero();
        int int28 = dfp27.log10K();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 0, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP;
        dfpField1.setRoundingMode(roundingMode10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp((byte) 1, (byte) 100);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP));
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0.011451006f, (java.lang.Number) (-1L), false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException6 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) (-1.5707963267912586d));
        java.lang.Number number10 = notStrictlyPositiveException9.getArgument();
        java.lang.Number number11 = notStrictlyPositiveException9.getMin();
        mathRuntimeException6.addSuppressed((java.lang.Throwable) notStrictlyPositiveException9);
        boolean boolean13 = notStrictlyPositiveException9.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1L) + "'", number5.equals((-1L)));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (-1.5707963267912586d) + "'", number10.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0 + "'", number11.equals(0));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.multiply(dfp5);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp2.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getZero();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getZero();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.multiply(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getZero();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp2.dotrap((-1), "org.apache.commons.math.exception.MathRuntimeException: ", dfp14, dfp21);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp2.getZero();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp23.newInstance();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp23.newInstance((byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode29 = dfpField28.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField28.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField28.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        dfpField33.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.getSqr3Reciprocal();
        boolean boolean36 = dfp31.equals((java.lang.Object) dfpField33);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp23.multiply(dfp31);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp37.newInstance(97.00000000000001d);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + roundingMode29 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode29.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp39);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (-1.5707963267912586d));
        java.lang.Number number3 = notStrictlyPositiveException2.getArgument();
        java.lang.Number number4 = notStrictlyPositiveException2.getArgument();
        java.lang.String str5 = notStrictlyPositiveException2.toString();
        java.lang.Object[] objArray6 = notStrictlyPositiveException2.getArguments();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (-1.5707963267912586d) + "'", number3.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.5707963267912586d) + "'", number4.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: -1.571 is smaller than, or equal to, the minimum (0)" + "'", str5.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: -1.571 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray6);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.866531296165219d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.399526500525655d + "'", double1 == 1.399526500525655d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        dfpField1.setIEEEFlagsBits((int) (byte) -1);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = null;
        dfpField1.setRoundingMode(roundingMode5);
        org.junit.Assert.assertNotNull(dfp2);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.multiply(dfp9);
        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        double double13 = mersenneTwister12.nextGaussian();
        double double14 = mersenneTwister12.nextDouble();
        boolean boolean15 = dfp10.equals((java.lang.Object) double14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp10.multiply(10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp(dfp10);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        int int21 = dfpField20.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getZero();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getZero();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp25.multiply(dfp28);
        org.apache.commons.math.random.MersenneTwister mersenneTwister31 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        double double32 = mersenneTwister31.nextGaussian();
        double double33 = mersenneTwister31.nextDouble();
        boolean boolean34 = dfp29.equals((java.lang.Object) double33);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp29.multiply((int) (short) 10);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField38.getZero();
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField41.getZero();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp39.multiply(dfp42);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp39.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField50.getZero();
        org.apache.commons.math.dfp.DfpField dfpField53 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField53.getZero();
        org.apache.commons.math.dfp.Dfp dfp55 = dfp51.multiply(dfp54);
        org.apache.commons.math.dfp.DfpField dfpField57 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField57.getZero();
        org.apache.commons.math.dfp.Dfp dfp59 = dfp39.dotrap((-1), "org.apache.commons.math.exception.MathRuntimeException: ", dfp51, dfp58);
        boolean boolean60 = dfp36.greaterThan(dfp51);
        org.apache.commons.math.dfp.Dfp dfp61 = dfp22.newInstance(dfp51);
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField1.newDfp(dfp22);
        org.apache.commons.math.dfp.Dfp dfp63 = new org.apache.commons.math.dfp.Dfp(dfp62);
        org.apache.commons.math.dfp.Dfp dfp64 = dfp62.ceil();
        double[] doubleArray65 = dfp62.toSplitDouble();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.866531296165219d + "'", double13 == 0.866531296165219d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0032884513038209384d + "'", double14 == 0.0032884513038209384d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 16 + "'", int21 == 16);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.866531296165219d + "'", double32 == 0.866531296165219d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0032884513038209384d + "'", double33 == 0.0032884513038209384d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(doubleArray65);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.multiply(dfp9);
        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        double double13 = mersenneTwister12.nextGaussian();
        double double14 = mersenneTwister12.nextDouble();
        boolean boolean15 = dfp10.equals((java.lang.Object) double14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp10.multiply(10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp(dfp10);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        int int21 = dfpField20.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getZero();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getZero();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp25.multiply(dfp28);
        org.apache.commons.math.random.MersenneTwister mersenneTwister31 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        double double32 = mersenneTwister31.nextGaussian();
        double double33 = mersenneTwister31.nextDouble();
        boolean boolean34 = dfp29.equals((java.lang.Object) double33);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp29.multiply((int) (short) 10);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField38.getZero();
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField41.getZero();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp39.multiply(dfp42);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp39.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField50.getZero();
        org.apache.commons.math.dfp.DfpField dfpField53 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField53.getZero();
        org.apache.commons.math.dfp.Dfp dfp55 = dfp51.multiply(dfp54);
        org.apache.commons.math.dfp.DfpField dfpField57 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField57.getZero();
        org.apache.commons.math.dfp.Dfp dfp59 = dfp39.dotrap((-1), "org.apache.commons.math.exception.MathRuntimeException: ", dfp51, dfp58);
        boolean boolean60 = dfp36.greaterThan(dfp51);
        org.apache.commons.math.dfp.Dfp dfp61 = dfp22.newInstance(dfp51);
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField1.newDfp(dfp22);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp65 = dfpField1.getSqr3();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.866531296165219d + "'", double13 == 0.866531296165219d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0032884513038209384d + "'", double14 == 0.0032884513038209384d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 16 + "'", int21 == 16);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.866531296165219d + "'", double32 == 0.866531296165219d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0032884513038209384d + "'", double33 == 0.0032884513038209384d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.junit.Assert.assertNotNull(dfp3);
    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test418");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        java.lang.Class<?> wildcardClass1 = mersenneTwister0.getClass();
//        boolean boolean2 = mersenneTwister0.nextBoolean();
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(8.881784197001252E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.088887490341627E-14d + "'", double1 == 5.088887490341627E-14d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.multiply(dfp5);
        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        double double9 = mersenneTwister8.nextGaussian();
        double double10 = mersenneTwister8.nextDouble();
        boolean boolean11 = dfp6.equals((java.lang.Object) double10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp6.multiply((int) (short) 10);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getZero();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getZero();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.multiply(dfp19);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp16.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getZero();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getZero();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp28.multiply(dfp31);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.getZero();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp16.dotrap((-1), "org.apache.commons.math.exception.MathRuntimeException: ", dfp28, dfp35);
        boolean boolean37 = dfp13.greaterThan(dfp28);
        try {
            org.apache.commons.math.dfp.Dfp dfp39 = dfp28.newInstance("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.866531296165219d + "'", double9 == 0.866531296165219d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0032884513038209384d + "'", double10 == 0.0032884513038209384d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.9999344379479402d, (java.lang.Number) 32768, true);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.multiply(dfp5);
        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        double double9 = mersenneTwister8.nextGaussian();
        double double10 = mersenneTwister8.nextDouble();
        boolean boolean11 = dfp6.equals((java.lang.Object) double10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp6.multiply((int) (short) 10);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getZero();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getZero();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.multiply(dfp19);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp16.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getZero();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getZero();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp28.multiply(dfp31);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.getZero();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp16.dotrap((-1), "org.apache.commons.math.exception.MathRuntimeException: ", dfp28, dfp35);
        boolean boolean37 = dfp13.greaterThan(dfp28);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp13.ceil();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp38.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField41.getZero();
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField44.getZero();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp42.multiply(dfp45);
        org.apache.commons.math.random.MersenneTwister mersenneTwister48 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        double double49 = mersenneTwister48.nextGaussian();
        double double50 = mersenneTwister48.nextDouble();
        boolean boolean51 = dfp46.equals((java.lang.Object) double50);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp46.multiply(10);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp38.subtract(dfp46);
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField56.getZero();
        org.apache.commons.math.dfp.Dfp dfp58 = dfp46.add(dfp57);
        org.apache.commons.math.dfp.Dfp dfp60 = dfp58.newInstance(0L);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.866531296165219d + "'", double9 == 0.866531296165219d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0032884513038209384d + "'", double10 == 0.0032884513038209384d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.866531296165219d + "'", double49 == 0.866531296165219d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0032884513038209384d + "'", double50 == 0.0032884513038209384d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp60);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2();
        dfpField1.setIEEEFlags(0);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        dfpField1.clearIEEEFlags();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.negate();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        int int9 = dfpField8.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.getSqr3();
        boolean boolean11 = dfp5.greaterThan(dfp10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 16 + "'", int9 == 16);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (-1.5707963267912586d));
        java.lang.Number number3 = notStrictlyPositiveException2.getArgument();
        java.lang.Number number4 = notStrictlyPositiveException2.getArgument();
        java.lang.String str5 = notStrictlyPositiveException2.toString();
        org.apache.commons.math.exception.util.Localizable localizable6 = notStrictlyPositiveException2.getGeneralPattern();
        java.lang.Object[] objArray7 = notStrictlyPositiveException2.getArguments();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (-1.5707963267912586d) + "'", number3.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.5707963267912586d) + "'", number4.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: -1.571 is smaller than, or equal to, the minimum (0)" + "'", str5.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: -1.571 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance("hi!");
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.multiply(dfp5);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp2.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getZero();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getZero();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.multiply(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getZero();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp2.dotrap((-1), "org.apache.commons.math.exception.MathRuntimeException: ", dfp14, dfp21);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp2.getZero();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp23.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        dfpField26.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.getSqr3();
        int int29 = dfp28.classify();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp28.getOne();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp24.newInstance(dfp28);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 41);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 41L + "'", long1 == 41L);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 2, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        dfpField1.setIEEEFlagsBits(4);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = mathIllegalArgumentException8.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable11, objArray17);
        org.apache.commons.math.exception.util.Localizable localizable19 = mathIllegalArgumentException18.getGeneralPattern();
        mathIllegalArgumentException8.addSuppressed((java.lang.Throwable) mathIllegalArgumentException18);
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode24 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        org.apache.commons.math.random.MersenneTwister mersenneTwister27 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        long long28 = mersenneTwister27.nextLong();
        org.apache.commons.math.random.MersenneTwister mersenneTwister30 = new org.apache.commons.math.random.MersenneTwister((long) 1);
        byte[] byteArray34 = new byte[] { (byte) 2, (byte) 2, (byte) 1 };
        mersenneTwister30.nextBytes(byteArray34);
        java.lang.Object[] objArray36 = new java.lang.Object[] { 10, roundingMode24, (byte) 1, mersenneTwister27, mersenneTwister30 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException37 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException18, localizable21, localizable22, objArray36);
        java.lang.Throwable[] throwableArray38 = mathIllegalArgumentException18.getSuppressed();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNull(localizable9);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNull(localizable19);
        org.junit.Assert.assertTrue("'" + roundingMode24 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode24.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 211235929750981552L + "'", long28 == 211235929750981552L);
        org.junit.Assert.assertNotNull(byteArray34);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(throwableArray38);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        int int2 = org.apache.commons.math.util.FastMath.max((-982170359), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.154434690031884d + "'", double1 == 2.154434690031884d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 1);
        byte[] byteArray5 = new byte[] { (byte) 2, (byte) 2, (byte) 1 };
        mersenneTwister1.nextBytes(byteArray5);
        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        long long9 = mersenneTwister8.nextLong();
        float float10 = mersenneTwister8.nextFloat();
        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister((long) 1);
        byte[] byteArray16 = new byte[] { (byte) 2, (byte) 2, (byte) 1 };
        mersenneTwister12.nextBytes(byteArray16);
        mersenneTwister8.nextBytes(byteArray16);
        mersenneTwister1.nextBytes(byteArray16);
        mersenneTwister1.setSeed(10000L);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 211235929750981552L + "'", long9 == 211235929750981552L);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.68564963f + "'", float10 == 0.68564963f);
        org.junit.Assert.assertNotNull(byteArray16);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7921204236492381d) + "'", double1 == (-0.7921204236492381d));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        dfpField1.setIEEEFlags(0);
        dfpField1.clearIEEEFlags();
        int int6 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        int int3 = dfpField1.getRadixDigits();
        int int4 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.9521553682584589d), 1.1071487177940904d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1071487177940904d + "'", double2 == 1.1071487177940904d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        int int3 = dfp2.log10();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.multiply(dfp9);
        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        double double13 = mersenneTwister12.nextGaussian();
        double double14 = mersenneTwister12.nextDouble();
        boolean boolean15 = dfp10.equals((java.lang.Object) double14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp10.multiply((int) (short) 10);
        double double18 = dfp17.toDouble();
        org.apache.commons.math.dfp.Dfp dfp19 = org.apache.commons.math.dfp.Dfp.copysign(dfp2, dfp17);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.866531296165219d + "'", double13 == 0.866531296165219d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0032884513038209384d + "'", double14 == 0.0032884513038209384d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + Double.NEGATIVE_INFINITY + "'", double18 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.multiply(dfp9);
        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        double double13 = mersenneTwister12.nextGaussian();
        double double14 = mersenneTwister12.nextDouble();
        boolean boolean15 = dfp10.equals((java.lang.Object) double14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp10.multiply(10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp(dfp10);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        int int21 = dfpField20.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getZero();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getZero();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp25.multiply(dfp28);
        org.apache.commons.math.random.MersenneTwister mersenneTwister31 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        double double32 = mersenneTwister31.nextGaussian();
        double double33 = mersenneTwister31.nextDouble();
        boolean boolean34 = dfp29.equals((java.lang.Object) double33);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp29.multiply((int) (short) 10);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField38.getZero();
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField41.getZero();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp39.multiply(dfp42);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp39.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField50.getZero();
        org.apache.commons.math.dfp.DfpField dfpField53 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField53.getZero();
        org.apache.commons.math.dfp.Dfp dfp55 = dfp51.multiply(dfp54);
        org.apache.commons.math.dfp.DfpField dfpField57 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField57.getZero();
        org.apache.commons.math.dfp.Dfp dfp59 = dfp39.dotrap((-1), "org.apache.commons.math.exception.MathRuntimeException: ", dfp51, dfp58);
        boolean boolean60 = dfp36.greaterThan(dfp51);
        org.apache.commons.math.dfp.Dfp dfp61 = dfp22.newInstance(dfp51);
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField1.newDfp(dfp22);
        org.apache.commons.math.dfp.Dfp dfp63 = new org.apache.commons.math.dfp.Dfp(dfp62);
        org.apache.commons.math.dfp.Dfp dfp65 = dfp62.newInstance(0);
        int int66 = dfp62.intValue();
        org.apache.commons.math.dfp.Dfp dfp68 = dfp62.power10((-32767));
        org.apache.commons.math.dfp.Dfp dfp70 = dfp62.multiply((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.866531296165219d + "'", double13 == 0.866531296165219d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0032884513038209384d + "'", double14 == 0.0032884513038209384d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 16 + "'", int21 == 16);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.866531296165219d + "'", double32 == 0.866531296165219d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0032884513038209384d + "'", double33 == 0.0032884513038209384d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 2 + "'", int66 == 2);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp70);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
        java.lang.Number number2 = notStrictlyPositiveException1.getArgument();
        org.junit.Assert.assertNull(number2);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = mathIllegalArgumentException8.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable11, objArray17);
        org.apache.commons.math.exception.util.Localizable localizable19 = mathIllegalArgumentException18.getGeneralPattern();
        mathIllegalArgumentException8.addSuppressed((java.lang.Throwable) mathIllegalArgumentException18);
        java.lang.Throwable[] throwableArray21 = mathIllegalArgumentException8.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException25 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable23, (java.lang.Number) (-1.5707963267912586d));
        java.lang.Number number26 = notStrictlyPositiveException25.getArgument();
        java.lang.Number number27 = notStrictlyPositiveException25.getArgument();
        java.lang.String str28 = notStrictlyPositiveException25.toString();
        org.apache.commons.math.exception.util.Localizable localizable29 = notStrictlyPositiveException25.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException32 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable30, (java.lang.Number) (-1.5707963267912586d));
        java.lang.Number number33 = notStrictlyPositiveException32.getArgument();
        java.lang.Number number34 = notStrictlyPositiveException32.getArgument();
        java.lang.String str35 = notStrictlyPositiveException32.toString();
        org.apache.commons.math.exception.util.Localizable localizable36 = notStrictlyPositiveException32.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        java.lang.Object[] objArray47 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable40, localizable41, objArray47);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable38, localizable39, objArray47);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable37, objArray47);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException51 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException50);
        java.lang.Throwable[] throwableArray52 = mathIllegalArgumentException50.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException53 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable29, localizable36, (java.lang.Object[]) throwableArray52);
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        java.lang.Object[] objArray61 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable54, localizable55, objArray61);
        org.apache.commons.math.exception.util.Localizable localizable63 = mathIllegalArgumentException62.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable64 = null;
        org.apache.commons.math.exception.util.Localizable localizable65 = null;
        java.lang.Object[] objArray71 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException72 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable64, localizable65, objArray71);
        org.apache.commons.math.exception.util.Localizable localizable73 = mathIllegalArgumentException72.getGeneralPattern();
        mathIllegalArgumentException62.addSuppressed((java.lang.Throwable) mathIllegalArgumentException72);
        java.lang.Throwable[] throwableArray75 = mathIllegalArgumentException62.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException76 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, localizable36, (java.lang.Object[]) throwableArray75);
        mathIllegalArgumentException8.addSuppressed((java.lang.Throwable) mathIllegalArgumentException76);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNull(localizable9);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNull(localizable19);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + (-1.5707963267912586d) + "'", number26.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + (-1.5707963267912586d) + "'", number27.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: -1.571 is smaller than, or equal to, the minimum (0)" + "'", str28.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: -1.571 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + (-1.5707963267912586d) + "'", number33.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + (-1.5707963267912586d) + "'", number34.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: -1.571 is smaller than, or equal to, the minimum (0)" + "'", str35.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: -1.571 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(throwableArray52);
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNull(localizable63);
        org.junit.Assert.assertNotNull(objArray71);
        org.junit.Assert.assertNull(localizable73);
        org.junit.Assert.assertNotNull(throwableArray75);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp3.newInstance();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.newInstance((byte) 0, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp4.newInstance(22);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-600411813), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963267948966d) + "'", double2 == (-1.5707963267948966d));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        dfpField1.setRoundingMode(roundingMode2);
        dfpField1.setIEEEFlagsBits((int) (short) 100);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        long long2 = org.apache.commons.math.util.FastMath.min(4L, 2115988564729650894L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getOne();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.multiply(dfp5);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.rint();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.power10K(32412);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getZero();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getZero();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp12.multiply(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.rint();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.rint();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getZero();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getZero();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp21.multiply(dfp24);
        org.apache.commons.math.random.MersenneTwister mersenneTwister27 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        double double28 = mersenneTwister27.nextGaussian();
        double double29 = mersenneTwister27.nextDouble();
        boolean boolean30 = dfp25.equals((java.lang.Object) double29);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp25.multiply(10);
        int int33 = dfp32.intValue();
        boolean boolean34 = dfp17.lessThan(dfp32);
        boolean boolean35 = dfp9.equals((java.lang.Object) boolean34);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.866531296165219d + "'", double28 == 0.866531296165219d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0032884513038209384d + "'", double29 == 0.0032884513038209384d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 3, (byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = dfpField8.getRoundingMode();
        dfpField1.setRoundingMode(roundingMode9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp("hi!");
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode9.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0.011451006f, (java.lang.Number) (-1L), false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException6 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException4.getSpecificPattern();
        java.lang.Number number8 = numberIsTooSmallException4.getArgument();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1L) + "'", number5.equals((-1L)));
        org.junit.Assert.assertNull(localizable7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0.011451006f + "'", number8.equals(0.011451006f));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        dfpField1.clearIEEEFlags();
        int int3 = dfpField1.getIEEEFlags();
        java.lang.Class<?> wildcardClass4 = dfpField1.getClass();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getZero();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp8.multiply(dfp11);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp8.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp8.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        dfpField18.clearIEEEFlags();
        int int20 = dfpField18.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField18.newDfp((long) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp23 = org.apache.commons.math.dfp.DfpField.computeLn(dfp5, dfp16, dfp22);
        boolean boolean24 = dfp22.isNaN();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp22.newInstance();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dfp25);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getZero();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp8.multiply(dfp11);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp8.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp8.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        dfpField18.clearIEEEFlags();
        int int20 = dfpField18.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField18.newDfp((long) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp23 = org.apache.commons.math.dfp.DfpField.computeLn(dfp5, dfp16, dfp22);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp16.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getZero();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getZero();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp27.multiply(dfp30);
        org.apache.commons.math.random.MersenneTwister mersenneTwister33 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        double double34 = mersenneTwister33.nextGaussian();
        double double35 = mersenneTwister33.nextDouble();
        boolean boolean36 = dfp31.equals((java.lang.Object) double35);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp31.multiply((int) (short) 10);
        boolean boolean39 = dfp38.isNaN();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp16.divide(dfp38);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp40.rint();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.866531296165219d + "'", double34 == 0.866531296165219d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0032884513038209384d + "'", double35 == 0.0032884513038209384d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 0, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp((double) 10000L);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-2.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.9999999999999998d) + "'", double1 == (-1.9999999999999998d));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.930067261567154E14d + "'", double1 == 7.930067261567154E14d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException1 = new org.apache.commons.math.exception.MathRuntimeException(throwable0);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (-1.5707963267912586d));
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1.5401776706283436E45d, (java.lang.Number) (byte) 10, true);
        notStrictlyPositiveException2.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.99627207622075d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.141592653589798d + "'", double1 == 3.141592653589798d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.multiply(dfp5);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp2.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getZero();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getZero();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.multiply(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getZero();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp2.dotrap((-1), "org.apache.commons.math.exception.MathRuntimeException: ", dfp14, dfp21);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp2.getZero();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp23.newInstance();
        double[] doubleArray25 = dfp23.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(doubleArray25);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        float float2 = mersenneTwister1.nextFloat();
        mersenneTwister1.setSeed((-2015080886171156972L));
        double double5 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.011451006f + "'", float2 == 0.011451006f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.9665724694739952d) + "'", double5 == (-1.9665724694739952d));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 0, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP;
        dfpField1.setRoundingMode(roundingMode10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp13 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.newDfp(dfp13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP));
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 0, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.getTwo();
        org.apache.commons.math.dfp.Dfp dfp12 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp13 = org.apache.commons.math.dfp.Dfp.copysign(dfp11, dfp12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 2L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.multiply(dfp5);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp2.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getZero();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getZero();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.multiply(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getZero();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp2.dotrap((-1), "org.apache.commons.math.exception.MathRuntimeException: ", dfp14, dfp21);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp2.rint();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.getZero();
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getZero();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp26.multiply(dfp29);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.rint();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp31.rint();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp2.nextAfter(dfp32);
        org.apache.commons.math.dfp.DfpField dfpField34 = dfp33.getField();
        dfpField34.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray36 = dfpField34.getESplit();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfpField34);
        org.junit.Assert.assertNotNull(dfpArray36);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.multiply(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp5.getField();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getSqr3();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        dfpField1.clearIEEEFlags();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 3, (byte) 1);
        dfpField1.clearIEEEFlags();
        try {
            org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((-2015080886171156972L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) (-1.5707963267912586d));
        java.lang.Number number4 = notStrictlyPositiveException3.getArgument();
        java.lang.Number number5 = notStrictlyPositiveException3.getArgument();
        java.lang.String str6 = notStrictlyPositiveException3.toString();
        org.apache.commons.math.exception.util.Localizable localizable7 = notStrictlyPositiveException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) (-1.5707963267912586d));
        java.lang.Number number11 = notStrictlyPositiveException10.getArgument();
        java.lang.Number number12 = notStrictlyPositiveException10.getArgument();
        java.lang.String str13 = notStrictlyPositiveException10.toString();
        org.apache.commons.math.exception.util.Localizable localizable14 = notStrictlyPositiveException10.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray25 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable19, objArray25);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray25);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, objArray25);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException29 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException28);
        java.lang.Throwable[] throwableArray30 = mathIllegalArgumentException28.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable14, (java.lang.Object[]) throwableArray30);
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable32, localizable33, objArray39);
        org.apache.commons.math.exception.util.Localizable localizable41 = mathIllegalArgumentException40.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable42, localizable43, objArray49);
        org.apache.commons.math.exception.util.Localizable localizable51 = mathIllegalArgumentException50.getGeneralPattern();
        mathIllegalArgumentException40.addSuppressed((java.lang.Throwable) mathIllegalArgumentException50);
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode56 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        org.apache.commons.math.random.MersenneTwister mersenneTwister59 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        long long60 = mersenneTwister59.nextLong();
        org.apache.commons.math.random.MersenneTwister mersenneTwister62 = new org.apache.commons.math.random.MersenneTwister((long) 1);
        byte[] byteArray66 = new byte[] { (byte) 2, (byte) 2, (byte) 1 };
        mersenneTwister62.nextBytes(byteArray66);
        java.lang.Object[] objArray68 = new java.lang.Object[] { 10, roundingMode56, (byte) 1, mersenneTwister59, mersenneTwister62 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException69 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException50, localizable53, localizable54, objArray68);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException70 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable7, objArray68);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException74 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 32768.0d, true);
        boolean boolean75 = numberIsTooSmallException74.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.5707963267912586d) + "'", number4.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1.5707963267912586d) + "'", number5.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: -1.571 is smaller than, or equal to, the minimum (0)" + "'", str6.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: -1.571 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (-1.5707963267912586d) + "'", number11.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.5707963267912586d) + "'", number12.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: -1.571 is smaller than, or equal to, the minimum (0)" + "'", str13.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: -1.571 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNull(localizable41);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNull(localizable51);
        org.junit.Assert.assertTrue("'" + roundingMode56 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode56.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 211235929750981552L + "'", long60 == 211235929750981552L);
        org.junit.Assert.assertNotNull(byteArray66);
        org.junit.Assert.assertNotNull(objArray68);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.multiply(dfp9);
        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        double double13 = mersenneTwister12.nextGaussian();
        double double14 = mersenneTwister12.nextDouble();
        boolean boolean15 = dfp10.equals((java.lang.Object) double14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp10.multiply(10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp(dfp10);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        int int21 = dfpField20.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getZero();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getZero();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp25.multiply(dfp28);
        org.apache.commons.math.random.MersenneTwister mersenneTwister31 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        double double32 = mersenneTwister31.nextGaussian();
        double double33 = mersenneTwister31.nextDouble();
        boolean boolean34 = dfp29.equals((java.lang.Object) double33);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp29.multiply((int) (short) 10);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField38.getZero();
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField41.getZero();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp39.multiply(dfp42);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp39.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField50.getZero();
        org.apache.commons.math.dfp.DfpField dfpField53 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField53.getZero();
        org.apache.commons.math.dfp.Dfp dfp55 = dfp51.multiply(dfp54);
        org.apache.commons.math.dfp.DfpField dfpField57 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField57.getZero();
        org.apache.commons.math.dfp.Dfp dfp59 = dfp39.dotrap((-1), "org.apache.commons.math.exception.MathRuntimeException: ", dfp51, dfp58);
        boolean boolean60 = dfp36.greaterThan(dfp51);
        org.apache.commons.math.dfp.Dfp dfp61 = dfp22.newInstance(dfp51);
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField1.newDfp(dfp22);
        org.apache.commons.math.dfp.Dfp dfp63 = new org.apache.commons.math.dfp.Dfp(dfp62);
        org.apache.commons.math.dfp.Dfp dfp65 = dfp62.newInstance(0);
        org.apache.commons.math.dfp.Dfp dfp66 = dfp65.getOne();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.866531296165219d + "'", double13 == 0.866531296165219d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0032884513038209384d + "'", double14 == 0.0032884513038209384d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 16 + "'", int21 == 16);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.866531296165219d + "'", double32 == 0.866531296165219d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0032884513038209384d + "'", double33 == 0.0032884513038209384d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp66);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0.011451006f, (java.lang.Number) (-1L), false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        boolean boolean6 = numberIsTooSmallException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1L) + "'", number5.equals((-1L)));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.4530255085769369d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 25.956449653226162d + "'", double1 == 25.956449653226162d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 0, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP;
        dfpField1.setRoundingMode(roundingMode10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.newDfp((byte) 3);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP));
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = dfpField1.getRoundingMode();
        int int3 = dfpField1.getRadixDigits();
        dfpField1.setIEEEFlagsBits(32767);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, (-0.8813735870195429d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField1.setRoundingMode(roundingMode4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.multiply(dfp5);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp2.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getZero();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getZero();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.multiply(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getZero();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp2.dotrap((-1), "org.apache.commons.math.exception.MathRuntimeException: ", dfp14, dfp21);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp2.getZero();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp23.newInstance();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp23.newInstance((byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode29 = dfpField28.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField28.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField28.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        dfpField33.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.getSqr3Reciprocal();
        boolean boolean36 = dfp31.equals((java.lang.Object) dfpField33);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp23.multiply(dfp31);
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField39.getZero();
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField42.getZero();
        org.apache.commons.math.dfp.Dfp dfp44 = dfp40.multiply(dfp43);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp40.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField51.getZero();
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField54.getZero();
        org.apache.commons.math.dfp.Dfp dfp56 = dfp52.multiply(dfp55);
        org.apache.commons.math.dfp.DfpField dfpField58 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField58.getZero();
        org.apache.commons.math.dfp.Dfp dfp60 = dfp40.dotrap((-1), "org.apache.commons.math.exception.MathRuntimeException: ", dfp52, dfp59);
        org.apache.commons.math.dfp.DfpField dfpField62 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField62.getZero();
        org.apache.commons.math.dfp.DfpField dfpField65 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp66 = dfpField65.getZero();
        org.apache.commons.math.dfp.Dfp dfp67 = dfp63.multiply(dfp66);
        org.apache.commons.math.dfp.Dfp dfp70 = dfp63.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField74 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp75 = dfpField74.getZero();
        org.apache.commons.math.dfp.DfpField dfpField77 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp78 = dfpField77.getZero();
        org.apache.commons.math.dfp.Dfp dfp79 = dfp75.multiply(dfp78);
        org.apache.commons.math.dfp.DfpField dfpField81 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp82 = dfpField81.getZero();
        org.apache.commons.math.dfp.Dfp dfp83 = dfp63.dotrap((-1), "org.apache.commons.math.exception.MathRuntimeException: ", dfp75, dfp82);
        org.apache.commons.math.dfp.Dfp dfp84 = dfp63.rint();
        org.apache.commons.math.dfp.DfpField dfpField86 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp87 = dfpField86.getZero();
        org.apache.commons.math.dfp.DfpField dfpField89 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp90 = dfpField89.getZero();
        org.apache.commons.math.dfp.Dfp dfp91 = dfp87.multiply(dfp90);
        org.apache.commons.math.dfp.Dfp dfp92 = dfp91.rint();
        org.apache.commons.math.dfp.Dfp dfp93 = dfp92.rint();
        org.apache.commons.math.dfp.Dfp dfp94 = dfp63.nextAfter(dfp93);
        org.apache.commons.math.dfp.Dfp dfp95 = dfp40.nextAfter(dfp63);
        org.apache.commons.math.dfp.Dfp dfp96 = dfp23.add(dfp95);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + roundingMode29 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode29.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertNotNull(dfp79);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertNotNull(dfp84);
        org.junit.Assert.assertNotNull(dfp87);
        org.junit.Assert.assertNotNull(dfp90);
        org.junit.Assert.assertNotNull(dfp91);
        org.junit.Assert.assertNotNull(dfp92);
        org.junit.Assert.assertNotNull(dfp93);
        org.junit.Assert.assertNotNull(dfp94);
        org.junit.Assert.assertNotNull(dfp95);
        org.junit.Assert.assertNotNull(dfp96);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        double double1 = org.apache.commons.math.util.FastMath.log10(32768.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.515449934959718d + "'", double1 == 4.515449934959718d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3Reciprocal();
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) (-1.5707963267912586d));
        java.lang.Number number4 = notStrictlyPositiveException3.getArgument();
        java.lang.Number number5 = notStrictlyPositiveException3.getArgument();
        java.lang.String str6 = notStrictlyPositiveException3.toString();
        org.apache.commons.math.exception.util.Localizable localizable7 = notStrictlyPositiveException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) (-1.5707963267912586d));
        java.lang.Number number11 = notStrictlyPositiveException10.getArgument();
        java.lang.Number number12 = notStrictlyPositiveException10.getArgument();
        java.lang.String str13 = notStrictlyPositiveException10.toString();
        org.apache.commons.math.exception.util.Localizable localizable14 = notStrictlyPositiveException10.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray25 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable19, objArray25);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray25);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, objArray25);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException29 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException28);
        java.lang.Throwable[] throwableArray30 = mathIllegalArgumentException28.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable14, (java.lang.Object[]) throwableArray30);
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable32, localizable33, objArray39);
        org.apache.commons.math.exception.util.Localizable localizable41 = mathIllegalArgumentException40.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable42, localizable43, objArray49);
        org.apache.commons.math.exception.util.Localizable localizable51 = mathIllegalArgumentException50.getGeneralPattern();
        mathIllegalArgumentException40.addSuppressed((java.lang.Throwable) mathIllegalArgumentException50);
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode56 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        org.apache.commons.math.random.MersenneTwister mersenneTwister59 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        long long60 = mersenneTwister59.nextLong();
        org.apache.commons.math.random.MersenneTwister mersenneTwister62 = new org.apache.commons.math.random.MersenneTwister((long) 1);
        byte[] byteArray66 = new byte[] { (byte) 2, (byte) 2, (byte) 1 };
        mersenneTwister62.nextBytes(byteArray66);
        java.lang.Object[] objArray68 = new java.lang.Object[] { 10, roundingMode56, (byte) 1, mersenneTwister59, mersenneTwister62 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException69 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException50, localizable53, localizable54, objArray68);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException70 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable7, objArray68);
        org.apache.commons.math.dfp.DfpField dfpField72 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        dfpField72.clearIEEEFlags();
        int int74 = dfpField72.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray75 = dfpField72.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException76 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, (java.lang.Object[]) dfpArray75);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.5707963267912586d) + "'", number4.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1.5707963267912586d) + "'", number5.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: -1.571 is smaller than, or equal to, the minimum (0)" + "'", str6.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: -1.571 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (-1.5707963267912586d) + "'", number11.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.5707963267912586d) + "'", number12.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: -1.571 is smaller than, or equal to, the minimum (0)" + "'", str13.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: -1.571 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNull(localizable41);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNull(localizable51);
        org.junit.Assert.assertTrue("'" + roundingMode56 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode56.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 211235929750981552L + "'", long60 == 211235929750981552L);
        org.junit.Assert.assertNotNull(byteArray66);
        org.junit.Assert.assertNotNull(objArray68);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertNotNull(dfpArray75);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister();
        java.lang.Class<?> wildcardClass5 = mersenneTwister4.getClass();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable10, objArray16);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray16);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray16);
        org.apache.commons.math.exception.util.Localizable localizable20 = mathIllegalArgumentException19.getGeneralPattern();
        org.apache.commons.math.random.MersenneTwister mersenneTwister22 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        float float23 = mersenneTwister22.nextFloat();
        java.lang.Object[] objArray24 = new java.lang.Object[] { 0.68564963f, (short) 10, wildcardClass5, localizable20, float23 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray24);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException29 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException25, localizable26, localizable27, objArray28);
        java.lang.Object[] objArray30 = mathIllegalArgumentException25.getArguments();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException31 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException25);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNull(localizable20);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.011451006f + "'", float23 == 0.011451006f);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray30);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        double double2 = org.apache.commons.math.util.FastMath.pow(1048576.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        int int2 = org.apache.commons.math.util.FastMath.max(10000, (-606065961));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10000 + "'", int2 == 10000);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.multiply(dfp5);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.rint();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.rint();
        org.apache.commons.math.dfp.DfpField dfpField9 = dfp8.getField();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpField9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.5872139151569291d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8324875211176866d + "'", double1 == 0.8324875211176866d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.999329299739067d + "'", double1 == 0.999329299739067d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        double double1 = org.apache.commons.math.util.FastMath.asinh(25.956449653226162d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.949938158997635d + "'", double1 == 3.949938158997635d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        double double2 = mersenneTwister1.nextGaussian();
        boolean boolean3 = mersenneTwister1.nextBoolean();
        mersenneTwister1.setSeed(0L);
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        int[] intArray10 = new int[] { (byte) 1, (short) 10 };
        mersenneTwister7.setSeed(intArray10);
        java.lang.Class<?> wildcardClass12 = mersenneTwister7.getClass();
        org.apache.commons.math.random.MersenneTwister mersenneTwister14 = new org.apache.commons.math.random.MersenneTwister((long) 1);
        byte[] byteArray18 = new byte[] { (byte) 2, (byte) 2, (byte) 1 };
        mersenneTwister14.nextBytes(byteArray18);
        mersenneTwister7.nextBytes(byteArray18);
        mersenneTwister1.nextBytes(byteArray18);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.866531296165219d + "'", double2 == 0.866531296165219d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(byteArray18);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 3, (byte) -1);
        dfpField1.setIEEEFlagsBits((-1));
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-2.4884135600096027d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.04343100977344107d) + "'", double1 == (-0.04343100977344107d));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = mathIllegalArgumentException8.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable11, objArray17);
        org.apache.commons.math.exception.util.Localizable localizable19 = mathIllegalArgumentException18.getGeneralPattern();
        mathIllegalArgumentException8.addSuppressed((java.lang.Throwable) mathIllegalArgumentException18);
        java.lang.String str21 = mathIllegalArgumentException18.toString();
        org.apache.commons.math.exception.util.Localizable localizable22 = mathIllegalArgumentException18.getGeneralPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException23 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException18);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNull(localizable9);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNull(localizable19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: " + "'", str21.equals("org.apache.commons.math.exception.MathIllegalArgumentException: "));
        org.junit.Assert.assertNull(localizable22);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.multiply(dfp9);
        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        double double13 = mersenneTwister12.nextGaussian();
        double double14 = mersenneTwister12.nextDouble();
        boolean boolean15 = dfp10.equals((java.lang.Object) double14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp10.multiply(10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp(dfp10);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField1.getSqr3Reciprocal();
        int int20 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField1.newDfp(0.0d);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.866531296165219d + "'", double13 == 0.866531296165219d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0032884513038209384d + "'", double14 == 0.0032884513038209384d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getPi();
        dfpField1.setIEEEFlagsBits((int) (byte) 10);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) (-1.5707963267912586d));
        java.lang.Number number4 = notStrictlyPositiveException3.getArgument();
        java.lang.Number number5 = notStrictlyPositiveException3.getArgument();
        java.lang.String str6 = notStrictlyPositiveException3.toString();
        org.apache.commons.math.exception.util.Localizable localizable7 = notStrictlyPositiveException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) (-1.5707963267912586d));
        java.lang.Number number11 = notStrictlyPositiveException10.getArgument();
        java.lang.Number number12 = notStrictlyPositiveException10.getArgument();
        java.lang.String str13 = notStrictlyPositiveException10.toString();
        org.apache.commons.math.exception.util.Localizable localizable14 = notStrictlyPositiveException10.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray25 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable19, objArray25);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray25);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, objArray25);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException29 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException28);
        java.lang.Throwable[] throwableArray30 = mathIllegalArgumentException28.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable14, (java.lang.Object[]) throwableArray30);
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable32, localizable33, objArray39);
        org.apache.commons.math.exception.util.Localizable localizable41 = mathIllegalArgumentException40.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] { 1L, 100, 10L, 10.0f, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable42, localizable43, objArray49);
        org.apache.commons.math.exception.util.Localizable localizable51 = mathIllegalArgumentException50.getGeneralPattern();
        mathIllegalArgumentException40.addSuppressed((java.lang.Throwable) mathIllegalArgumentException50);
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode56 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        org.apache.commons.math.random.MersenneTwister mersenneTwister59 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        long long60 = mersenneTwister59.nextLong();
        org.apache.commons.math.random.MersenneTwister mersenneTwister62 = new org.apache.commons.math.random.MersenneTwister((long) 1);
        byte[] byteArray66 = new byte[] { (byte) 2, (byte) 2, (byte) 1 };
        mersenneTwister62.nextBytes(byteArray66);
        java.lang.Object[] objArray68 = new java.lang.Object[] { 10, roundingMode56, (byte) 1, mersenneTwister59, mersenneTwister62 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException69 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException50, localizable53, localizable54, objArray68);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException70 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable7, objArray68);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException74 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 32768.0d, true);
        java.lang.Number number75 = numberIsTooSmallException74.getMin();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.5707963267912586d) + "'", number4.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1.5707963267912586d) + "'", number5.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: -1.571 is smaller than, or equal to, the minimum (0)" + "'", str6.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: -1.571 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (-1.5707963267912586d) + "'", number11.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.5707963267912586d) + "'", number12.equals((-1.5707963267912586d)));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: -1.571 is smaller than, or equal to, the minimum (0)" + "'", str13.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: -1.571 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNull(localizable41);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNull(localizable51);
        org.junit.Assert.assertTrue("'" + roundingMode56 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode56.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 211235929750981552L + "'", long60 == 211235929750981552L);
        org.junit.Assert.assertNotNull(byteArray66);
        org.junit.Assert.assertNotNull(objArray68);
        org.junit.Assert.assertTrue("'" + number75 + "' != '" + 32768.0d + "'", number75.equals(32768.0d));
    }
}

