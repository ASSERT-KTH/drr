import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test01");
        double double1 = org.apache.commons.math.util.FastMath.cos(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test02");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        dfpField1.clearIEEEFlags();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test03");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test04");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getOne();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test05");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        float float2 = mersenneTwister1.nextFloat();
        mersenneTwister1.setSeed((long) 647325673);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.011451006f + "'", float2 == 0.011451006f);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test06");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getOne();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test07");
        double double1 = org.apache.commons.math.util.FastMath.sinh(3.949938158997635d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 25.956449653226162d + "'", double1 == 25.956449653226162d);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test08");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (byte) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0986122886681098d + "'", double1 == 1.0986122886681098d);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test09");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 4L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test10");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.multiply(dfp5);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp2.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getZero();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getZero();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.multiply(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getZero();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp2.dotrap((-1), "org.apache.commons.math.exception.MathRuntimeException: ", dfp14, dfp21);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getZero();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getZero();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp25.multiply(dfp28);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp25.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField36.getZero();
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField39.getZero();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp37.multiply(dfp40);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField43.getZero();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp25.dotrap((-1), "org.apache.commons.math.exception.MathRuntimeException: ", dfp37, dfp44);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp25.rint();
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField48.getZero();
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField51.getZero();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp49.multiply(dfp52);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp53.rint();
        org.apache.commons.math.dfp.Dfp dfp55 = dfp54.rint();
        org.apache.commons.math.dfp.Dfp dfp56 = dfp25.nextAfter(dfp55);
        org.apache.commons.math.dfp.Dfp dfp57 = dfp2.nextAfter(dfp25);
        org.apache.commons.math.dfp.DfpField dfpField59 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField59.getZero();
        org.apache.commons.math.dfp.DfpField dfpField62 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField62.getZero();
        org.apache.commons.math.dfp.Dfp dfp64 = dfp60.multiply(dfp63);
        org.apache.commons.math.dfp.Dfp dfp67 = dfp60.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField71 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp72 = dfpField71.getZero();
        org.apache.commons.math.dfp.DfpField dfpField74 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp75 = dfpField74.getZero();
        org.apache.commons.math.dfp.Dfp dfp76 = dfp72.multiply(dfp75);
        org.apache.commons.math.dfp.DfpField dfpField78 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp79 = dfpField78.getZero();
        org.apache.commons.math.dfp.Dfp dfp80 = dfp60.dotrap((-1), "org.apache.commons.math.exception.MathRuntimeException: ", dfp72, dfp79);
        org.apache.commons.math.dfp.Dfp dfp82 = dfp60.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp83 = dfp2.newInstance(dfp60);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertNotNull(dfp79);
        org.junit.Assert.assertNotNull(dfp80);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertNotNull(dfp83);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test11");
        double double1 = org.apache.commons.math.util.FastMath.exp((-1.9999999999999998d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.13533528323661273d + "'", double1 == 0.13533528323661273d);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test12");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getZero();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp8.multiply(dfp11);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp8.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp8.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        dfpField18.clearIEEEFlags();
        int int20 = dfpField18.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField18.newDfp((long) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp23 = org.apache.commons.math.dfp.DfpField.computeLn(dfp5, dfp16, dfp22);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp16.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getZero();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getZero();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp27.multiply(dfp30);
        org.apache.commons.math.random.MersenneTwister mersenneTwister33 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        double double34 = mersenneTwister33.nextGaussian();
        double double35 = mersenneTwister33.nextDouble();
        boolean boolean36 = dfp31.equals((java.lang.Object) double35);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp31.multiply((int) (short) 10);
        boolean boolean39 = dfp38.isNaN();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp16.divide(dfp38);
        int int41 = dfp40.log10K();
        int int42 = dfp40.log10();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.866531296165219d + "'", double34 == 0.866531296165219d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0032884513038209384d + "'", double35 == 0.0032884513038209384d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-4) + "'", int42 == (-4));
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test13");
        double double2 = org.apache.commons.math.util.FastMath.min((-0.04343100977344107d), 3.949938158997635d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.04343100977344107d) + "'", double2 == (-0.04343100977344107d));
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test14");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getZero();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getZero();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp7.multiply(dfp10);
        org.apache.commons.math.random.MersenneTwister mersenneTwister13 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        double double14 = mersenneTwister13.nextGaussian();
        double double15 = mersenneTwister13.nextDouble();
        boolean boolean16 = dfp11.equals((java.lang.Object) double15);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp11.multiply((int) (short) 10);
        boolean boolean19 = dfp18.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField21.getESplit();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.getLn2();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField21.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getZero();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getZero();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp28.multiply(dfp31);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp28.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp28.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        dfpField38.clearIEEEFlags();
        int int40 = dfpField38.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField38.newDfp((long) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp43 = org.apache.commons.math.dfp.DfpField.computeLn(dfp25, dfp36, dfp42);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp18.multiply(dfp25);
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField46.getZero();
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField49.getZero();
        org.apache.commons.math.dfp.Dfp dfp51 = dfp47.multiply(dfp50);
        org.apache.commons.math.random.MersenneTwister mersenneTwister53 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        double double54 = mersenneTwister53.nextGaussian();
        double double55 = mersenneTwister53.nextDouble();
        boolean boolean56 = dfp51.equals((java.lang.Object) double55);
        org.apache.commons.math.dfp.Dfp dfp58 = dfp51.multiply((int) (short) 10);
        org.apache.commons.math.dfp.DfpField dfpField60 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField60.getZero();
        org.apache.commons.math.dfp.DfpField dfpField63 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField63.getZero();
        org.apache.commons.math.dfp.Dfp dfp65 = dfp61.multiply(dfp64);
        org.apache.commons.math.dfp.Dfp dfp68 = dfp61.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField72 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField72.getZero();
        org.apache.commons.math.dfp.DfpField dfpField75 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp76 = dfpField75.getZero();
        org.apache.commons.math.dfp.Dfp dfp77 = dfp73.multiply(dfp76);
        org.apache.commons.math.dfp.DfpField dfpField79 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp80 = dfpField79.getZero();
        org.apache.commons.math.dfp.Dfp dfp81 = dfp61.dotrap((-1), "org.apache.commons.math.exception.MathRuntimeException: ", dfp73, dfp80);
        boolean boolean82 = dfp58.greaterThan(dfp73);
        org.apache.commons.math.dfp.Dfp dfp83 = dfp58.ceil();
        org.apache.commons.math.dfp.Dfp dfp84 = dfp2.dotrap((int) (short) 0, "org.apache.commons.math.exception.MathIllegalArgumentException: ", dfp18, dfp83);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.866531296165219d + "'", double14 == 0.866531296165219d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0032884513038209384d + "'", double15 == 0.0032884513038209384d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.866531296165219d + "'", double54 == 0.866531296165219d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0032884513038209384d + "'", double55 == 0.0032884513038209384d);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertNotNull(dfp80);
        org.junit.Assert.assertNotNull(dfp81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertNotNull(dfp84);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test15");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-1.350124506E9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test16");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField7.getRoundingMode();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = dfpField7.getRoundingMode();
        dfpField1.setRoundingMode(roundingMode9);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp(0.0d);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp((long) 0);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode9.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test17");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField7.getRoundingMode();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = dfpField7.getRoundingMode();
        dfpField1.setRoundingMode(roundingMode9);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp((int) (byte) 0);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode9.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test18");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode11 = dfpField10.getRoundingMode();
        dfpField1.setRoundingMode(roundingMode11);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + roundingMode11 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode11.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test19");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.multiply(dfp5);
        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        double double9 = mersenneTwister8.nextGaussian();
        double double10 = mersenneTwister8.nextDouble();
        boolean boolean11 = dfp6.equals((java.lang.Object) double10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp6.multiply((int) (short) 10);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getZero();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getZero();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.multiply(dfp19);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp16.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getZero();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getZero();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp28.multiply(dfp31);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.getZero();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp16.dotrap((-1), "org.apache.commons.math.exception.MathRuntimeException: ", dfp28, dfp35);
        boolean boolean37 = dfp13.greaterThan(dfp28);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp13.ceil();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp38.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField41.getZero();
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField44.getZero();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp42.multiply(dfp45);
        org.apache.commons.math.random.MersenneTwister mersenneTwister48 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        double double49 = mersenneTwister48.nextGaussian();
        double double50 = mersenneTwister48.nextDouble();
        boolean boolean51 = dfp46.equals((java.lang.Object) double50);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp46.multiply(10);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp38.subtract(dfp46);
        org.apache.commons.math.dfp.Dfp dfp56 = dfp38.multiply((int) (byte) 0);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.866531296165219d + "'", double9 == 0.866531296165219d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0032884513038209384d + "'", double10 == 0.0032884513038209384d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.866531296165219d + "'", double49 == 0.866531296165219d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0032884513038209384d + "'", double50 == 0.0032884513038209384d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp56);
    }
}

