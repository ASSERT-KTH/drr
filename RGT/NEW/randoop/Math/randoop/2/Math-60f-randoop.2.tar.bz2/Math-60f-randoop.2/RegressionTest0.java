import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.440892098500626E-16d) + "'", double1 == (-4.440892098500626E-16d));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-1), 10.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 10.0f, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        double double0 = org.apache.commons.math.special.Gamma.GAMMA;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.5772156649015329d + "'", double0 == 0.5772156649015329d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        double double1 = org.apache.commons.math.special.Gamma.digamma((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.600161852571429d + "'", double1 == 4.600161852571429d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        double double1 = org.apache.commons.math.util.FastMath.expm1(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22025.465794806718d + "'", double1 == 22025.465794806718d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        double double1 = org.apache.commons.math.util.FastMath.sinh(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.544137102816975d + "'", double1 == 7.544137102816975d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int1 = org.apache.commons.math.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.99822295029797d + "'", double1 == 2.99822295029797d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (short) 10, (float) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (short) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.302585092994046d + "'", double1 == 2.302585092994046d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1622776601683795d + "'", double1 == 3.1622776601683795d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.718281828459045d + "'", double2 == 2.718281828459045d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double double1 = org.apache.commons.math.special.Gamma.digamma((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.600161852571429d + "'", double1 == 4.600161852571429d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        org.apache.commons.math.distribution.ContinuousDistribution continuousDistribution1 = null;
        try {
            double double2 = randomDataImpl0.nextInversionDeviate(continuousDistribution1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        double double1 = org.apache.commons.math.util.FastMath.tan(22025.465794806718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.24503417392995128d) + "'", double1 == (-0.24503417392995128d));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8813735870195429d + "'", double1 == 0.8813735870195429d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        double double1 = org.apache.commons.math.util.FastMath.tanh(3.246216406046493d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9969748643467198d + "'", double1 == 0.9969748643467198d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-0.24503417392995128d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.2474935923416762d) + "'", double1 == (-0.2474935923416762d));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 'a', (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            double double3 = randomDataImpl0.nextBeta((double) (-1), 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.906");
        } catch (org.apache.commons.math.exception.MathUserException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.0d, (double) (-1));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        double double1 = org.apache.commons.math.special.Erf.erf(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.10516633568161556d + "'", double1 == 0.10516633568161556d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12.801827480081469d + "'", double1 == 12.801827480081469d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7853981633974483d + "'", double1 == 0.7853981633974483d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double double1 = org.apache.commons.math.special.Gamma.digamma(22025.465794806718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.999931897872345d + "'", double1 == 9.999931897872345d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 10.0f, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963267948966d) + "'", double1 == (-1.5707963267948966d));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        double double1 = org.apache.commons.math.util.FastMath.atan(12.801827480081469d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4928407777776485d + "'", double1 == 1.4928407777776485d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.5772156649015329d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5456928232039928d + "'", double1 == 0.5456928232039928d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.9969748643467198d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.710071082755576d + "'", double1 == 2.710071082755576d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(2.710071082755576d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6462293530233192d + "'", double1 == 1.6462293530233192d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017453292519943295d + "'", double1 == 0.017453292519943295d);
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test046");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution4 = null;
//        try {
//            int int5 = randomDataImpl0.nextInversionDeviate(integerDistribution4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.224782694852757d + "'", double3 == 3.224782694852757d);
//    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed();
        try {
            long long3 = randomDataImpl0.nextPoisson((double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((-0.2474935923416762d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2.718281828459045d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        double double1 = org.apache.commons.math.util.FastMath.sinh(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        double double1 = org.apache.commons.math.special.Erf.erf(0.017453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.019691932154573932d + "'", double1 == 0.019691932154573932d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.08656193300300513d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0015107907377931822d + "'", double1 == 0.0015107907377931822d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.00000000000001d + "'", double1 == 100.00000000000001d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.027712143770207958d + "'", double1 == 0.027712143770207958d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            double double3 = randomDataImpl0.nextBeta((double) 1L, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.136");
        } catch (org.apache.commons.math.exception.MathUserException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6321205588285577d) + "'", double1 == (-0.6321205588285577d));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable3, objArray4);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathIllegalArgumentException6.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNull(localizable7);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        double double1 = org.apache.commons.math.util.FastMath.tan(2.710071082755576d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.46046391868746567d) + "'", double1 == (-0.46046391868746567d));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        try {
            double double2 = normalDistributionImpl0.inverseCumulativeProbability((-1.5707963267948966d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -1.571 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test061");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double5 = randomDataImpl0.nextExponential(Double.NaN);
//        double double8 = randomDataImpl0.nextCauchy(0.019691932154573932d, 0.9969748643467198d);
//        try {
//            int int12 = randomDataImpl0.nextHypergeometric((int) ' ', (int) (byte) 100, (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of samples (-1)");
//        } catch (org.apache.commons.math.exception.NotPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.2889351844827956d + "'", double3 == 2.2889351844827956d);
//        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-2.401673038336264d) + "'", double8 == (-2.401673038336264d));
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        double double1 = org.apache.commons.math.util.FastMath.acos(2.99822295029797d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        double double0 = org.apache.commons.math.distribution.NormalDistributionImpl.DEFAULT_INVERSE_ABSOLUTE_ACCURACY;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-9d + "'", double0 == 1.0E-9d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        double double1 = org.apache.commons.math.util.FastMath.acos(3.207810091467445d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        double double2 = org.apache.commons.math.util.FastMath.max(7.206685735830315d, 4.600161852571429d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.206685735830315d + "'", double2 == 7.206685735830315d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0d);
        java.lang.String str2 = notStrictlyPositiveException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)" + "'", str2.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)"));
    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test068");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        try {
//            long long15 = randomDataImpl0.nextLong(10L, 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 10 is larger than, or equal to, the maximum (0): lower bound (10) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.183142170854268d + "'", double3 == 2.183142170854268d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.7572502518618904d + "'", double6 == 2.7572502518618904d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2L + "'", long8 == 2L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 8.355040650313446d + "'", double12 == 8.355040650313446d);
//    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double double1 = org.apache.commons.math.util.FastMath.cosh(7.112156832451546d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 613.3957458749095d + "'", double1 == 613.3957458749095d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        double double1 = org.apache.commons.math.util.FastMath.expm1(2.6508641820894225d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 13.166275598782555d + "'", double1 == 13.166275598782555d);
    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test071");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        try {
//            int[] intArray15 = randomDataImpl0.nextPermutation((int) (byte) -1, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than the maximum (-1): permutation size (0) exceeds permuation domain (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.2369762224573533d + "'", double3 == 2.2369762224573533d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.448748815590632d + "'", double6 == 3.448748815590632d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.7414771184410097d + "'", double12 == 0.7414771184410097d);
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-0.6321205588285577d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5961722400471147d) + "'", double1 == (-0.5961722400471147d));
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test073");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        double double11 = randomDataImpl0.nextGaussian(7.112156832451546d, 4.600161852571429d);
//        try {
//            int int15 = randomDataImpl0.nextHypergeometric(0, (int) ' ', (int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): population size (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.210798771718152d + "'", double3 == 2.210798771718152d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0536233706430633d + "'", double6 == 2.0536233706430633d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.018834570938575d + "'", double11 == 4.018834570938575d);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.027712143770207958d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        double double1 = org.apache.commons.math.util.FastMath.floor((-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.0d) + "'", double1 == (-2.0d));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 100L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        double double1 = org.apache.commons.math.special.Gamma.digamma((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5772156677920679d) + "'", double1 == (-0.5772156677920679d));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298292365610485d + "'", double1 == 5.298292365610485d);
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test081");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.09451824734254932d + "'", double0 == 0.09451824734254932d);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(1.787066582172498d, 0.0d, (double) 1L, (int) '4');
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        double double1 = org.apache.commons.math.util.FastMath.cosh(2.393527778424103d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.521684663007721d + "'", double1 == 5.521684663007721d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        int int2 = org.apache.commons.math.util.FastMath.min(1, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test085");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double5 = randomDataImpl0.nextExponential(Double.NaN);
//        try {
//            randomDataImpl0.setSecureAlgorithm("9913e0bd71", "hi!");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: hi!");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.434885723155256d + "'", double3 == 1.434885723155256d);
//        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        double double1 = org.apache.commons.math.util.FastMath.expm1(9.999931897872345d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22023.965796698492d + "'", double1 == 22023.965796698492d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-57.29577951308232d) + "'", double1 == (-57.29577951308232d));
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test088");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        java.lang.String str3 = randomDataImpl0.nextHexString((int) (short) 1);
//        try {
//            int int6 = randomDataImpl0.nextZipf((-1), (double) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): dimension (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9" + "'", str3.equals("9"));
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        double double1 = org.apache.commons.math.util.FastMath.acos(5.298292365610485d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298342365610589d + "'", double1 == 5.298342365610589d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        double double1 = org.apache.commons.math.util.FastMath.acosh(2.4053027645871077d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5245066427138134d + "'", double1 == 1.5245066427138134d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-4.440892098500626E-16d), (double) (byte) 0, (double) '4', (int) '#');
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.5772156649015329d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6511961857760066d + "'", double1 == 0.6511961857760066d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7853981633974483d + "'", double1 == 0.7853981633974483d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 22025.465794806718d, (java.lang.Number) 1.5430806348152437d, false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException(throwable0);
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("hi!", objArray7);
        java.lang.Class<?> wildcardClass9 = objArray7.getClass();
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException(throwable0, localizable2, objArray7);
        try {
            java.lang.String str11 = mathException10.getPattern();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        double double1 = org.apache.commons.math.util.FastMath.cos(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8390715290764524d) + "'", double1 == (-0.8390715290764524d));
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test101");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double3 = normalDistributionImpl2.getMean();
//        double double5 = normalDistributionImpl2.density((double) (short) 1);
//        double double6 = normalDistributionImpl2.sample();
//        double[] doubleArray8 = normalDistributionImpl2.sample((int) (short) 10);
//        try {
//            double double10 = normalDistributionImpl2.inverseCumulativeProbability((double) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 100 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.544137102816975d + "'", double3 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.01610846091529747d + "'", double5 == 0.01610846091529747d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 6.246946406970157d + "'", double6 == 6.246946406970157d);
//        org.junit.Assert.assertNotNull(doubleArray8);
//    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test102");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        try {
//            double double14 = randomDataImpl0.nextT((-0.6321205588285577d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.632 is smaller than, or equal to, the minimum (0): degrees of freedom (-0.632)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.217466873661722d + "'", double3 == 3.217466873661722d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.819452787489975d + "'", double6 == 2.819452787489975d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 8.948396828887773d + "'", double12 == 8.948396828887773d);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(613.3957458749095d, (-1.0d), 0.0015107907377931822d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): standard deviation (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        double double1 = org.apache.commons.math.util.FastMath.acosh(2.033012895896001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3358115530746422d + "'", double1 == 1.3358115530746422d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.9969748643467198d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.783883305402354d + "'", double1 == 0.783883305402354d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((-0.46046391868746567d), 2.3486094961442983d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test108");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution13 = null;
//        try {
//            int int14 = randomDataImpl0.nextInversionDeviate(integerDistribution13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.13884645915283d + "'", double3 == 3.13884645915283d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.855854449412839d + "'", double6 == 0.855854449412839d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 9.99866365112045d + "'", double12 == 9.99866365112045d);
//    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test109");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        double double11 = randomDataImpl0.nextGaussian(7.112156832451546d, 4.600161852571429d);
//        randomDataImpl0.reSeed();
//        try {
//            long long14 = randomDataImpl0.nextPoisson(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.156483039732968d + "'", double3 == 3.156483039732968d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.2939889685867871d + "'", double6 == 1.2939889685867871d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.957188688626701d + "'", double11 == 10.957188688626701d);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed();
        int int4 = randomDataImpl0.nextInt(0, (int) (short) 1);
        try {
            double double6 = randomDataImpl0.nextExponential(0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException(throwable0);
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("hi!", objArray7);
        java.lang.Class<?> wildcardClass9 = objArray7.getClass();
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException(throwable0, localizable2, objArray7);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException10);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test112");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        double double11 = randomDataImpl0.nextGaussian(7.112156832451546d, 4.600161852571429d);
//        randomDataImpl0.reSeed();
//        try {
//            randomDataImpl0.setSecureAlgorithm("9913e0bd71", "f");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: f");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.148899357003677d + "'", double3 == 3.148899357003677d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.986626140388455d + "'", double6 == 2.986626140388455d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 7.586448455016047d + "'", double11 == 7.586448455016047d);
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
        double double3 = normalDistributionImpl2.getMean();
        double double5 = normalDistributionImpl2.density((double) (short) 1);
        try {
            double double7 = normalDistributionImpl2.inverseCumulativeProbability(22023.965796698492d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 22,023.966 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.544137102816975d + "'", double3 == 7.544137102816975d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.01610846091529747d + "'", double5 == 0.01610846091529747d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        double double1 = org.apache.commons.math.util.FastMath.acos(2.3955599353509216d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
        double double3 = normalDistributionImpl2.getMean();
        double double5 = normalDistributionImpl2.density((double) (short) 1);
        double double7 = normalDistributionImpl2.cumulativeProbability(2.033012895896001d);
        try {
            double double10 = normalDistributionImpl2.cumulativeProbability(12.801827480081469d, 2.0198227150790538d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.544137102816975d + "'", double3 == 7.544137102816975d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.01610846091529747d + "'", double5 == 0.01610846091529747d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.04478154114589594d + "'", double7 == 0.04478154114589594d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.8390715290764524d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(2.710071082755576d, Double.NaN, 2.033012895896001d, (int) ' ');
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException(throwable0);
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("hi!", objArray7);
        java.lang.Class<?> wildcardClass9 = objArray7.getClass();
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException(throwable0, localizable2, objArray7);
        org.apache.commons.math.exception.util.Localizable localizable11 = mathException10.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(localizable11);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.04478154114589594d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.081725078478352d + "'", double1 == 3.081725078478352d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.1995416045736986d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6216710141531901d + "'", double1 == 0.6216710141531901d);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test121");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double3 = normalDistributionImpl2.getMean();
//        double double5 = normalDistributionImpl2.density((double) (short) 1);
//        double double6 = normalDistributionImpl2.sample();
//        double[] doubleArray8 = normalDistributionImpl2.sample((int) (short) 10);
//        try {
//            double double10 = normalDistributionImpl2.inverseCumulativeProbability((-0.8390715290764524d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -0.839 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.544137102816975d + "'", double3 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.01610846091529747d + "'", double5 == 0.01610846091529747d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 8.71632282192893d + "'", double6 == 8.71632282192893d);
//        org.junit.Assert.assertNotNull(doubleArray8);
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) (byte) 10, 0.8560818335760243d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.6824652258218002E-8d + "'", double2 == 2.6824652258218002E-8d);
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test123");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        double double11 = randomDataImpl0.nextCauchy(2.99822295029797d, 7.8726391065033505d);
//        try {
//            double double13 = randomDataImpl0.nextChiSquare(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.1195285168380256d + "'", double3 == 3.1195285168380256d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.7863173563945267d + "'", double6 == 3.7863173563945267d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2L + "'", long8 == 2L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.968228979462669d + "'", double11 == 10.968228979462669d);
//    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test124");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        try {
//            double double9 = randomDataImpl0.nextUniform(5.298292365610485d, 2.108232909743466d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 5.298 is larger than, or equal to, the maximum (2.108): lower bound (5.298) must be strictly less than upper bound (2.108)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0525801927256837d + "'", double3 == 3.0525801927256837d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.462803580839151d + "'", double6 == 3.462803580839151d);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            int int4 = randomDataImpl1.nextBinomial((int) (byte) -1, 3.1622776601683795d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of trials (-1)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed();
        try {
            int int4 = randomDataImpl0.nextSecureInt((int) (byte) 100, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (100): lower bound (100) must be strictly less than upper bound (100)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 1, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.369985073988086d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.110636508023106d + "'", double1 == 1.110636508023106d);
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test130");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        try {
//            double double6 = randomDataImpl0.nextGamma(0.0d, (-4.440892098500626E-16d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.060330420552521d + "'", double3 == 2.060330420552521d);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 2L, 0.4614290299912925d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9212587981384309d + "'", double2 == 0.9212587981384309d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        double double1 = org.apache.commons.math.util.FastMath.asin((-4.440892098500626E-16d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.440892098500626E-16d) + "'", double1 == (-4.440892098500626E-16d));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        double double1 = org.apache.commons.math.util.FastMath.tan(2.6824652258218002E-8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.682465225821801E-8d + "'", double1 == 2.682465225821801E-8d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        java.lang.Number number10 = numberIsTooLargeException3.getMax();
        java.lang.Number number11 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 2.718281828459045d + "'", number10.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 2.718281828459045d + "'", number11.equals(2.718281828459045d));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 7.8726391065033505d, (java.lang.Number) 2.718281828459045d, true);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.5772156649015329d, 0.5403023058681398d, 2.6508641820894225d);
        double double4 = normalDistributionImpl3.getMean();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5772156649015329d + "'", double4 == 0.5772156649015329d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(13.166275598782555d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2297948594237435d + "'", double1 == 0.2297948594237435d);
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test139");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double5 = randomDataImpl0.nextExponential(Double.NaN);
//        double double8 = randomDataImpl0.nextGamma((double) (byte) 1, (double) 10.0f);
//        try {
//            int int11 = randomDataImpl0.nextZipf(0, (double) 10.0f);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): dimension (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.4631221148561417d + "'", double3 == 3.4631221148561417d);
//        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.290171973928105d + "'", double8 == 4.290171973928105d);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (short) -1, (float) (-1L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        double double1 = org.apache.commons.math.util.FastMath.sinh(3.0649845072566633d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.693737673234912d + "'", double1 == 10.693737673234912d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.4172934084748632d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.348749002417799d + "'", double1 == 0.348749002417799d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0015107907377931822d, (-0.24503417392995128d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.24503417392995128d) + "'", double2 == (-0.24503417392995128d));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.01610846091529747d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9998702615489115d + "'", double1 == 0.9998702615489115d);
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test146");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        double double11 = randomDataImpl0.nextGaussian(7.112156832451546d, 4.600161852571429d);
//        try {
//            int int14 = randomDataImpl0.nextZipf((int) (short) 0, (double) 10L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): dimension (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.332330623983808d + "'", double3 == 3.332330623983808d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.4186656825102086d + "'", double6 == 2.4186656825102086d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.1488550377736697d + "'", double11 == 2.1488550377736697d);
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        long long2 = org.apache.commons.math.util.FastMath.max(10L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test149");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        java.lang.String str3 = randomDataImpl0.nextHexString((int) (short) 1);
//        randomDataImpl0.reSeed();
//        try {
//            double double6 = randomDataImpl0.nextT((double) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): degrees of freedom (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "6" + "'", str3.equals("6"));
//    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test150");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        java.lang.String str5 = randomDataImpl0.nextSecureHexString(10);
//        randomDataImpl0.reSeedSecure();
//        try {
//            double double9 = randomDataImpl0.nextUniform(1.1995416045736986d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 1.2 is larger than, or equal to, the maximum (0): lower bound (1.2) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.249488188075915d + "'", double3 == 3.249488188075915d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "c8764c44f7" + "'", str5.equals("c8764c44f7"));
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test152");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextF(2.718281828459045d, (double) 100);
//        try {
//            long long6 = randomDataImpl0.nextLong((long) (short) 0, (long) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (0): lower bound (0) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0851806039204894d + "'", double3 == 2.0851806039204894d);
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        double double2 = org.apache.commons.math.util.FastMath.atan2(7.164591543681963d, 1.4928407777776485d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3653718376654087d + "'", double2 == 1.3653718376654087d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        double double1 = org.apache.commons.math.util.FastMath.sin(2.1728127577639627d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8241953752072392d + "'", double1 == 0.8241953752072392d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.density(3.0649845072566633d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.003639155797242861d + "'", double2 == 0.003639155797242861d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.0015107907377931822d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(3.143276701259362d, 0.5403023058681398d, 10.448849566937042d, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (-1) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        double double1 = org.apache.commons.math.util.FastMath.acos(3.126895805850263d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(22025.465794806718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 384.416897404767d + "'", double1 == 384.416897404767d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        java.lang.Number number10 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 100L);
        java.lang.Class<?> wildcardClass14 = notStrictlyPositiveException13.getClass();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 2.718281828459045d + "'", number10.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        double double1 = org.apache.commons.math.util.FastMath.log1p(2.710071082755576d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3110510362081902d + "'", double1 == 1.3110510362081902d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 572.9577951308232d + "'", double1 == 572.9577951308232d);
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test163");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextF(2.718281828459045d, (double) 100);
//        randomDataImpl0.reSeed((long) 100);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.31103915499158813d + "'", double3 == 0.31103915499158813d);
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        double double1 = org.apache.commons.math.util.FastMath.atan(7.164591543681963d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.432116947405487d + "'", double1 == 1.432116947405487d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.4928407777776485d);
        java.lang.Number number2 = notStrictlyPositiveException1.getArgument();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 1.4928407777776485d + "'", number2.equals(1.4928407777776485d));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 10, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.605170185988092d + "'", double1 == 4.605170185988092d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 0, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.10516633568161556d + "'", double1 == 0.10516633568161556d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.6216710141531901d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8620369336917564d + "'", double1 == 1.8620369336917564d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        double double1 = org.apache.commons.math.util.FastMath.abs(2.0198227150790538d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0198227150790538d + "'", double1 == 2.0198227150790538d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        int int2 = org.apache.commons.math.util.FastMath.min((int) '#', (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        long long2 = org.apache.commons.math.util.FastMath.min((long) '4', (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.348749002417799d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.33555991049962286d + "'", double1 == 0.33555991049962286d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(22025.465794806718d, 9.096028753578256d, 26.369176630649168d, 10);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-1.0d), (double) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9999999999999999d) + "'", double2 == (-0.9999999999999999d));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-0.5961722400471147d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9067668286786221d) + "'", double1 == (-0.9067668286786221d));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.019691932154573932d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.019694478074841076d + "'", double1 == 0.019694478074841076d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        double double2 = org.apache.commons.math.util.FastMath.max(2.393527778424103d, 2.0198227150790538d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.393527778424103d + "'", double2 == 2.393527778424103d);
    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test181");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        randomDataImpl0.reSeed((long) 1);
//        try {
//            long long17 = randomDataImpl0.nextLong((long) 32, (long) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 32 is larger than, or equal to, the maximum (0): lower bound (32) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.6319434343032997d + "'", double3 == 2.6319434343032997d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.610818543598144d + "'", double6 == 2.610818543598144d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 7.480702000117753d + "'", double12 == 7.480702000117753d);
//    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test182");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double5 = randomDataImpl0.nextExponential(Double.NaN);
//        try {
//            java.lang.String str7 = randomDataImpl0.nextHexString((int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): length (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.6237798311203475d + "'", double3 == 2.6237798311203475d);
//        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (-1.0f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        java.lang.Number number2 = notStrictlyPositiveException1.getArgument();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + (-1.0d) + "'", number2.equals((-1.0d)));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        double double2 = org.apache.commons.math.util.FastMath.min(10.0d, (double) 32L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9333761944765003d + "'", double1 == 0.9333761944765003d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 2.0198227150790538d, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException4);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        double double1 = org.apache.commons.math.special.Gamma.digamma(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        double double1 = org.apache.commons.math.util.FastMath.expm1(5.298292365610485d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 198.99499987499382d + "'", double1 == 198.99499987499382d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        double double1 = org.apache.commons.math.special.Erf.erf(0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5551940451963508d + "'", double1 == 0.5551940451963508d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) 100);
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException2);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        int int2 = org.apache.commons.math.util.FastMath.max((int) ' ', (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test194");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        java.lang.String str5 = randomDataImpl0.nextSecureHexString(10);
//        int int8 = randomDataImpl0.nextPascal((int) (short) 1, 1.0E-9d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.552863873682405d + "'", double3 == 2.552863873682405d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "b0f617732c" + "'", str5.equals("b0f617732c"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 387632507 + "'", int8 == 387632507);
//    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test196");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double5 = randomDataImpl0.nextExponential(Double.NaN);
//        try {
//            int int8 = randomDataImpl0.nextBinomial((int) (byte) -1, (double) (short) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of trials (-1)");
//        } catch (org.apache.commons.math.exception.NotPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.4187405922557272d + "'", double3 == 2.4187405922557272d);
//        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
        double double3 = normalDistributionImpl2.getMean();
        double double5 = normalDistributionImpl2.density((double) (short) 1);
        double double7 = normalDistributionImpl2.cumulativeProbability(2.033012895896001d);
        double double9 = normalDistributionImpl2.cumulativeProbability(0.9333761944765003d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.544137102816975d + "'", double3 == 7.544137102816975d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.01610846091529747d + "'", double5 == 0.01610846091529747d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.04478154114589594d + "'", double7 == 0.04478154114589594d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.020852540299366507d + "'", double9 == 0.020852540299366507d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        java.lang.Number number10 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 2.718281828459045d + "'", number10.equals(2.718281828459045d));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        double double2 = org.apache.commons.math.util.FastMath.max(10.569181794623525d, (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.505149978319906d + "'", double1 == 1.505149978319906d);
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test203");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        java.lang.String str5 = randomDataImpl0.nextSecureHexString(10);
//        double double8 = randomDataImpl0.nextF((double) ' ', 9.992428484835056d);
//        try {
//            int int11 = randomDataImpl0.nextPascal((int) (byte) 0, (double) 21);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 21 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.3252696947735183d + "'", double3 == 2.3252696947735183d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dc10183e12" + "'", str5.equals("dc10183e12"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.1249119895920188d + "'", double8 == 1.1249119895920188d);
//    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6657737500283538d + "'", double1 == 0.6657737500283538d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 10.0f, (double) 11);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.34051064246566165d + "'", double2 == 0.34051064246566165d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        float float2 = org.apache.commons.math.util.FastMath.min((float) '4', (float) 11);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 11.0f + "'", float2 == 11.0f);
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test208");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        java.lang.String str5 = randomDataImpl0.nextSecureHexString(10);
//        double double8 = randomDataImpl0.nextF((double) ' ', 9.992428484835056d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution9 = null;
//        try {
//            int int10 = randomDataImpl0.nextInversionDeviate(integerDistribution9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.7952692089917943d + "'", double3 == 2.7952692089917943d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "5f19c35c7f" + "'", str5.equals("5f19c35c7f"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.178331495573801d + "'", double8 == 1.178331495573801d);
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test210");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        double double11 = randomDataImpl0.nextGaussian(7.112156832451546d, 4.600161852571429d);
//        try {
//            double double13 = randomDataImpl0.nextT(Double.NaN);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument -1 p = 0.122");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.811170850916503d + "'", double3 == 2.811170850916503d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.485894197261317d + "'", double6 == 3.485894197261317d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 7.841686988844069d + "'", double11 == 7.841686988844069d);
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        double double1 = org.apache.commons.math.util.FastMath.sin(2.108232909743466d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8590238068419813d + "'", double1 == 0.8590238068419813d);
    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test213");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextF(2.718281828459045d, (double) 100);
//        long long6 = randomDataImpl0.nextLong((long) 0, (long) (short) 1);
//        randomDataImpl0.reSeedSecure((long) (short) 10);
//        randomDataImpl0.reSeedSecure((long) ' ');
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.6005435158319935d + "'", double3 == 0.6005435158319935d);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (short) 100, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5607966601082315d + "'", double2 == 1.5607966601082315d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        java.lang.Number number10 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) (-6.816718961678583d), (java.lang.Number) 3.20459618189556d, (java.lang.Number) 5.169076857913174d);
        java.lang.Number number16 = outOfRangeException15.getLo();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 2.718281828459045d + "'", number10.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 3.20459618189556d + "'", number16.equals(3.20459618189556d));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) -1, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(1.5245066427138134d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9149059515984214d + "'", double1 == 0.9149059515984214d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.5772156649015329d, 0.5403023058681398d, 2.6508641820894225d);
        double double5 = normalDistributionImpl3.density(0.0d);
        normalDistributionImpl3.reseedRandomGenerator((long) 'a');
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.4172934084748632d + "'", double5 == 0.4172934084748632d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0E-9d, (java.lang.Number) 21, false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) (byte) 0);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        double double1 = org.apache.commons.math.util.FastMath.sinh(3.1933391164880165d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12.164315132131438d + "'", double1 == 12.164315132131438d);
    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test222");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        int int4 = randomDataImpl0.nextInt(0, (int) (short) 1);
//        try {
//            int int7 = randomDataImpl0.nextBinomial(100, (double) 387632507);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 387,632,507 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.0015107907377931822d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000011412445438d + "'", double1 == 1.0000011412445438d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        double double1 = org.apache.commons.math.util.FastMath.sin((-0.9999999999999999d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8414709848078964d) + "'", double1 == (-0.8414709848078964d));
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test225");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        double double11 = randomDataImpl0.nextGaussian(7.112156832451546d, 4.600161852571429d);
//        randomDataImpl0.reSeed(10L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.777718171589642d + "'", double3 == 2.777718171589642d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.3781918045926935d + "'", double6 == 0.3781918045926935d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 7.853107962480361d + "'", double11 == 7.853107962480361d);
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        double double1 = org.apache.commons.math.special.Erf.erf(3.550128012953764d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999994850018165d + "'", double1 == 0.9999994850018165d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.8813735870195429d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999999999999d + "'", double1 == 0.9999999999999999d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        int int2 = org.apache.commons.math.util.FastMath.min((int) '4', (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test229");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        double double11 = randomDataImpl0.nextGaussian(7.112156832451546d, 4.600161852571429d);
//        try {
//            long long14 = randomDataImpl0.nextSecureLong((long) 1, 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 1 is larger than, or equal to, the maximum (0): lower bound (1) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.691065126001866d + "'", double3 == 2.691065126001866d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.5407159957057683d + "'", double6 == 1.5407159957057683d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.3737863069645657d + "'", double11 == 2.3737863069645657d);
//    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        double double1 = org.apache.commons.math.special.Gamma.digamma(3.081725078478352d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9545562608278262d + "'", double1 == 0.9545562608278262d);
    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test231");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        java.lang.String str3 = randomDataImpl0.nextHexString((int) (short) 1);
//        try {
//            randomDataImpl0.setSecureAlgorithm("76b6a5e15f", "");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "e" + "'", str3.equals("e"));
//    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test232");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextF(2.718281828459045d, (double) 100);
//        long long6 = randomDataImpl0.nextLong((long) 0, (long) (short) 1);
//        try {
//            int int9 = randomDataImpl0.nextSecureInt((int) (short) 100, 35);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (35): lower bound (100) must be strictly less than upper bound (35)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.4548207924147385d + "'", double3 == 0.4548207924147385d);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test233");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        java.lang.String str3 = randomDataImpl0.nextHexString((int) (short) 1);
//        try {
//            int int6 = randomDataImpl0.nextBinomial((-1), 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of trials (-1)");
//        } catch (org.apache.commons.math.exception.NotPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "f" + "'", str3.equals("f"));
//    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        double double1 = org.apache.commons.math.util.FastMath.atanh(3.1933391164880165d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.6005435158319935d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5408190484372157d + "'", double1 == 0.5408190484372157d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(2.6824652258218002E-8d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        double double1 = org.apache.commons.math.util.FastMath.acosh(2.6508641820894225d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.630391949037867d + "'", double1 == 1.630391949037867d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        double double1 = org.apache.commons.math.util.FastMath.ulp(2.744220474423504d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        java.lang.Number number10 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooLargeException3.getGeneralPattern();
        java.lang.Number number12 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 2.718281828459045d + "'", number10.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 2.718281828459045d + "'", number12.equals(2.718281828459045d));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.6511961857760066d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(2.801622921646229d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5180674978483826d + "'", double1 == 0.5180674978483826d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        double double1 = org.apache.commons.math.util.FastMath.signum(7.544137102816975d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.61512051684126d + "'", double1 == 4.61512051684126d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        double double2 = org.apache.commons.math.util.FastMath.max(0.15597817735658048d, 7.513629774969273d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.513629774969273d + "'", double2 == 7.513629774969273d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 0, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        double double1 = org.apache.commons.math.special.Gamma.digamma(0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.777309158100993d) + "'", double1 == (-1.777309158100993d));
    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test249");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        java.lang.String str3 = randomDataImpl0.nextHexString((int) (short) 1);
//        randomDataImpl0.reSeed();
//        try {
//            double double7 = randomDataImpl0.nextUniform(4.605170185988092d, 2.302585092994046d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 4.605 is larger than, or equal to, the maximum (2.303): lower bound (4.605) must be strictly less than upper bound (2.303)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "f" + "'", str3.equals("f"));
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-1.777309158100993d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-101.83231364913647d) + "'", double1 == (-101.83231364913647d));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        double double2 = org.apache.commons.math.util.FastMath.max(0.027712143770207958d, 2.4055293024067956d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.4055293024067956d + "'", double2 == 2.4055293024067956d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.9556007738814948d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.016678379838837916d + "'", double1 == 0.016678379838837916d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-0.46046391868746567d), 5.521684663007721d, (-0.5124523569841605d), 11);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(10.0d, 0.0d, 0.5501178667265356d, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        try {
            double double3 = normalDistributionImpl0.cumulativeProbability(43.29757019802005d, 4.945510016043891d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.6005435158319935d, (-0.5772156677920679d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3422320186509582d + "'", double2 == 1.3422320186509582d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        double double1 = org.apache.commons.math.util.FastMath.abs(2.7809006500430664d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.7809006500430664d + "'", double1 == 2.7809006500430664d);
    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test258");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextF(2.718281828459045d, (double) 100);
//        long long6 = randomDataImpl0.nextLong((long) 0, (long) (short) 1);
//        randomDataImpl0.reSeedSecure((long) (short) 10);
//        try {
//            randomDataImpl0.setSecureAlgorithm("hi!", "");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.01250776758192613d + "'", double3 == 0.01250776758192613d);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0d);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            int int4 = randomDataImpl0.nextHypergeometric(0, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): population size (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test261");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        randomDataImpl0.reSeed((long) 100);
//        randomDataImpl0.reSeedSecure((long) ' ');
//        double double13 = randomDataImpl0.nextBeta(2.744220474423504d, 0.9212587981384309d);
//        try {
//            double double15 = randomDataImpl0.nextExponential(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.096138219340743d + "'", double3 == 2.096138219340743d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.140787918802146d + "'", double6 == 2.140787918802146d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.9026593890743758d + "'", double13 == 0.9026593890743758d);
//    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) '4');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 52L + "'", long1 == 52L);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        long long1 = org.apache.commons.math.util.FastMath.abs(1L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) 0);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) ' ');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 32.0f + "'", float1 == 32.0f);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(2.741061275761933d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.43926456659219254d + "'", double1 == 0.43926456659219254d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.9545562608278262d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9846166530555597d + "'", double1 == 0.9846166530555597d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(4.440892098500626E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1073424255447017E-8d + "'", double1 == 2.1073424255447017E-8d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        double double1 = org.apache.commons.math.util.FastMath.signum(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        double double2 = org.apache.commons.math.util.FastMath.min((-6.816718961678583d), 7.164591543681963d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-6.816718961678583d) + "'", double2 == (-6.816718961678583d));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(4.990120238769398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08709402823693159d + "'", double1 == 0.08709402823693159d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        double double1 = org.apache.commons.math.util.FastMath.abs(12.236072099935386d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12.236072099935386d + "'", double1 == 12.236072099935386d);
    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test275");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        java.lang.String str3 = randomDataImpl0.nextHexString((int) (short) 1);
//        try {
//            int int6 = randomDataImpl0.nextPascal(0, 2.6508641820894225d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 2.651 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "6" + "'", str3.equals("6"));
//    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 30.9570417874309d + "'", double1 == 30.9570417874309d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) '4');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        double double1 = org.apache.commons.math.special.Erf.erf(3.246216406046493d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999955854124133d + "'", double1 == 0.9999955854124133d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.2297948594237435d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3389294304545183d + "'", double1 == 1.3389294304545183d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
        double double4 = normalDistributionImpl2.inverseCumulativeProbability(0.5403023058681398d);
        normalDistributionImpl2.reseedRandomGenerator(0L);
        double double7 = normalDistributionImpl2.getMean();
        double[] doubleArray9 = normalDistributionImpl2.sample((int) ' ');
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.8726391065033505d + "'", double4 == 7.8726391065033505d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 7.544137102816975d + "'", double7 == 7.544137102816975d);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test282");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double5 = randomDataImpl0.nextExponential(Double.NaN);
//        double double8 = randomDataImpl0.nextCauchy(0.019691932154573932d, 0.9969748643467198d);
//        try {
//            double double11 = randomDataImpl0.nextUniform(12.164315132131438d, 0.10516633568161556d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 12.164 is larger than, or equal to, the maximum (0.105): lower bound (12.164) must be strictly less than upper bound (0.105)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.586102282317574d + "'", double3 == 3.586102282317574d);
//        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.30532059750733725d + "'", double8 == 0.30532059750733725d);
//    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        double double1 = org.apache.commons.math.util.FastMath.acosh(2.801622921646229d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6898558835492172d + "'", double1 == 1.6898558835492172d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        boolean boolean5 = numberIsTooSmallException4.getBoundIsAllowed();
        java.lang.Number number6 = numberIsTooSmallException4.getMin();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException4.getSpecificPattern();
        java.lang.String str8 = numberIsTooSmallException4.toString();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 22025.465794806718d + "'", number6.equals(22025.465794806718d));
        org.junit.Assert.assertNull(localizable7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 1 is smaller than the minimum (22,025.466)" + "'", str8.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 1 is smaller than the minimum (22,025.466)"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        int int2 = org.apache.commons.math.util.FastMath.max(1, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        double double1 = org.apache.commons.math.util.FastMath.sinh(2.393527778424103d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.430377658846085d + "'", double1 == 5.430377658846085d);
    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test287");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        double double11 = randomDataImpl0.nextCauchy(2.99822295029797d, 7.8726391065033505d);
//        int int14 = randomDataImpl0.nextSecureInt(10, 32);
//        try {
//            int[] intArray17 = randomDataImpl0.nextPermutation((int) (byte) -1, (int) 'a');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than the maximum (-1): permutation size (97) exceeds permuation domain (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.486829284401343d + "'", double3 == 3.486829284401343d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 6.012178327094535d + "'", double6 == 6.012178327094535d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-6.028654272682807d) + "'", double11 == (-6.028654272682807d));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 32 + "'", int14 == 32);
//    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.0d, (double) (-1), 0.0d, (int) (byte) -1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

//    @Test
//    public void test289() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test289");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        randomDataImpl0.reSeed((long) 1);
//        double double17 = randomDataImpl0.nextBeta((double) 10L, (double) 10);
//        randomDataImpl0.reSeed(2L);
//        try {
//            long long21 = randomDataImpl0.nextPoisson(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.681599358290434d + "'", double3 == 2.681599358290434d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.148451207788841d + "'", double6 == 4.148451207788841d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 10.415026585626324d + "'", double12 == 10.415026585626324d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.5693386188584106d + "'", double17 == 0.5693386188584106d);
//    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        float float2 = org.apache.commons.math.util.FastMath.min(32.0f, (-1.0f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        double double2 = org.apache.commons.math.util.FastMath.max(3.20459618189556d, 7.544137102816975d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.544137102816975d + "'", double2 == 7.544137102816975d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        int int1 = org.apache.commons.math.util.FastMath.abs(32);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 100.0f, (-2.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 99.99999999999999d + "'", double2 == 99.99999999999999d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.04478154114589594d, 2.7809006500430664d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.773537727299425E-4d + "'", double2 == 1.773537727299425E-4d);
    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test295");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double5 = randomDataImpl0.nextExponential(Double.NaN);
//        double double8 = randomDataImpl0.nextGamma((double) (byte) 1, (double) 10.0f);
//        randomDataImpl0.reSeedSecure((long) (byte) 100);
//        randomDataImpl0.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.6975094779926425d + "'", double3 == 2.6975094779926425d);
//        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 14.099207071263288d + "'", double8 == 14.099207071263288d);
//    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test296");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        try {
//            int int11 = randomDataImpl0.nextSecureInt((int) '#', 35);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 35 is larger than, or equal to, the maximum (35): lower bound (35) must be strictly less than upper bound (35)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.6997681007514815d + "'", double3 == 2.6997681007514815d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 5.755982297600987d + "'", double6 == 5.755982297600987d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        double double1 = org.apache.commons.math.special.Erf.erf(0.5772156649015329d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5856749831752239d + "'", double1 == 0.5856749831752239d);
    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test299");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        randomDataImpl0.reSeed((long) 100);
//        long long10 = randomDataImpl0.nextPoisson(0.6511961857760066d);
//        long long13 = randomDataImpl0.nextSecureLong((long) (short) 0, (long) (byte) 100);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.695635735574979d + "'", double3 == 2.695635735574979d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.7087461852015375d + "'", double6 == 0.7087461852015375d);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 30L + "'", long13 == 30L);
//    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test300");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextF(2.718281828459045d, (double) 100);
//        long long6 = randomDataImpl0.nextLong((long) 0, (long) (short) 1);
//        try {
//            long long9 = randomDataImpl0.nextSecureLong((long) (byte) 1, (long) (short) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 1 is larger than, or equal to, the maximum (1): lower bound (1) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.43369123871753656d + "'", double3 == 0.43369123871753656d);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (short) 100, 0.9333761944765003d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5614628358856486d + "'", double2 == 1.5614628358856486d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(3.20459618189556d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3657118231904856d + "'", double1 == 0.3657118231904856d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.9545562608278262d, 2.302585092994046d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.09226365410835027d + "'", double2 == 0.09226365410835027d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(4.522344075265816d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.484831582181765d + "'", double1 == 2.484831582181765d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        double double2 = org.apache.commons.math.util.FastMath.pow(3.1622776601683795d, 0.5436432847461893d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.8699140395997385d + "'", double2 == 1.8699140395997385d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.5180674978483826d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8390715290764524d) + "'", double1 == (-0.8390715290764524d));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.5772156649015329d, 0.5403023058681398d, 2.6508641820894225d);
        double double5 = normalDistributionImpl3.density((double) 1);
        double[] doubleArray7 = normalDistributionImpl3.sample((int) '#');
        double double9 = normalDistributionImpl3.inverseCumulativeProbability(0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5436432847461893d + "'", double5 == 0.5436432847461893d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + Double.NEGATIVE_INFINITY + "'", double9 == Double.NEGATIVE_INFINITY);
    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test309");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        java.lang.String str5 = randomDataImpl0.nextSecureHexString(10);
//        randomDataImpl0.reSeedSecure();
//        double double8 = randomDataImpl0.nextExponential(0.017453292519943295d);
//        randomDataImpl0.reSeedSecure();
//        try {
//            long long12 = randomDataImpl0.nextLong(30L, (long) (-1));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 30 is larger than, or equal to, the maximum (-1): lower bound (30) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.67068563918057d + "'", double3 == 2.67068563918057d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ce15d62d83" + "'", str5.equals("ce15d62d83"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.004456383671766597d + "'", double8 == 0.004456383671766597d);
//    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        java.lang.Number number10 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooLargeException3.getGeneralPattern();
        java.lang.Number number12 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, number12, (java.lang.Number) 5.337333612629559d, true);
        boolean boolean16 = numberIsTooLargeException15.getBoundIsAllowed();
        boolean boolean17 = numberIsTooLargeException15.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 2.718281828459045d + "'", number10.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.9999999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.821637045374455E-17d) + "'", double1 == (-4.821637045374455E-17d));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
        double double4 = normalDistributionImpl2.inverseCumulativeProbability(0.5403023058681398d);
        normalDistributionImpl2.reseedRandomGenerator(0L);
        double double7 = normalDistributionImpl2.getMean();
        double double8 = normalDistributionImpl2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.8726391065033505d + "'", double4 == 7.8726391065033505d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 7.544137102816975d + "'", double7 == 7.544137102816975d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.246216406046493d + "'", double8 == 3.246216406046493d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (short) 0, 4.440892098500626E-16d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test314");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        double double11 = randomDataImpl0.nextCauchy(4.600161852571429d, 2.6508641820894225d);
//        randomDataImpl0.reSeedSecure((long) (byte) 0);
//        double double16 = randomDataImpl0.nextGamma(3.550128012953764d, 10.569181794623525d);
//        try {
//            double double18 = randomDataImpl0.nextChiSquare((double) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.5 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.5661578683405892d + "'", double3 == 2.5661578683405892d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.5743554885264723d + "'", double6 == 2.5743554885264723d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.397017827984151d + "'", double11 == 4.397017827984151d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 27.782707593728237d + "'", double16 == 27.782707593728237d);
//    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5574077246549023d + "'", double1 == 1.5574077246549023d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException9);
        java.lang.Number number11 = numberIsTooLargeException4.getMax();
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Object[] objArray17 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("hi!", objArray17);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable12, objArray17);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable24, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException23.addSuppressed((java.lang.Throwable) numberIsTooSmallException28);
        java.lang.Number number30 = numberIsTooLargeException23.getMax();
        org.apache.commons.math.exception.util.Localizable localizable31 = numberIsTooLargeException23.getGeneralPattern();
        java.lang.Number number33 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException35 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable31, (java.lang.Number) (-0.46046391868746567d), number33, false);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException40 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable38, objArray39);
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException35, "6", objArray39);
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException(localizable12, objArray39);
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException42);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 2.718281828459045d + "'", number11.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 2.718281828459045d + "'", number30.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray39);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
        double double4 = normalDistributionImpl2.inverseCumulativeProbability(0.5403023058681398d);
        normalDistributionImpl2.reseedRandomGenerator(0L);
        try {
            double double8 = normalDistributionImpl2.inverseCumulativeProbability(4.097470561084089d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 4.097 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.8726391065033505d + "'", double4 == 7.8726391065033505d);
    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test318");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        java.lang.String str3 = randomDataImpl0.nextHexString((int) (short) 1);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double[] doubleArray6 = normalDistributionImpl4.sample((int) '#');
//        double double7 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        try {
//            int[] intArray10 = randomDataImpl0.nextPermutation((int) (short) 0, (int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than the maximum (0): permutation size (100) exceeds permuation domain (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "f" + "'", str3.equals("f"));
//        org.junit.Assert.assertNotNull(doubleArray6);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-2.393809497747816d) + "'", double7 == (-2.393809497747816d));
//    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
        double double4 = normalDistributionImpl2.inverseCumulativeProbability(0.5403023058681398d);
        normalDistributionImpl2.reseedRandomGenerator(0L);
        double double7 = normalDistributionImpl2.getMean();
        double double8 = normalDistributionImpl2.getMean();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.8726391065033505d + "'", double4 == 7.8726391065033505d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 7.544137102816975d + "'", double7 == 7.544137102816975d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 7.544137102816975d + "'", double8 == 7.544137102816975d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 21, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 21L + "'", long2 == 21L);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2.9217470313908858d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.8560818335760243d, 3.1804374774983803d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8560818335760244d + "'", double2 == 0.8560818335760244d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(384.416897404767d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1901.471065349969d + "'", double1 == 1901.471065349969d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(1.5607966601082315d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.11686640748183041d) + "'", double1 == (-0.11686640748183041d));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 100, 30L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        double double1 = org.apache.commons.math.util.FastMath.acos(4.160597058598435d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.440892098500626E-16d) + "'", double1 == (-4.440892098500626E-16d));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException5.addSuppressed((java.lang.Throwable) numberIsTooSmallException10);
        java.lang.Number number12 = numberIsTooLargeException5.getMax();
        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooLargeException5.getGeneralPattern();
        java.lang.Number number15 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable13, (java.lang.Number) (-0.46046391868746567d), number15, false);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException22 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable20, objArray21);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException17, "6", objArray21);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException24 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray21);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 2.718281828459045d + "'", number12.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray21);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        java.lang.Number number10 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooLargeException3.getGeneralPattern();
        java.lang.Number number13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) (-0.46046391868746567d), number13, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) 3.081725078478352d, (java.lang.Number) (-1.0d), true);
        java.lang.Number number20 = numberIsTooSmallException19.getArgument();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 2.718281828459045d + "'", number10.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 3.081725078478352d + "'", number20.equals(3.081725078478352d));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 32L, 0.003639155797242861d, 0.9545562608278262d, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (-1) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test332");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double5 = randomDataImpl0.nextExponential(Double.NaN);
//        double double8 = randomDataImpl0.nextUniform(0.9969748643467198d, 6.798056507791588d);
//        randomDataImpl0.reSeedSecure(100L);
//        try {
//            int int14 = randomDataImpl0.nextHypergeometric((int) (byte) 1, (int) (short) -1, 32);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of successes (-1)");
//        } catch (org.apache.commons.math.exception.NotPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.538353173223687d + "'", double3 == 2.538353173223687d);
//        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.1332151513643645d + "'", double8 == 3.1332151513643645d);
//    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.9999999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8414709848078964d + "'", double1 == 0.8414709848078964d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.9212587981384309d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray5);
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException("3d787e85ce", objArray5);
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException(localizable0, objArray5);
        try {
            java.lang.String str9 = mathException8.getPattern();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objArray5);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        long long1 = org.apache.commons.math.util.FastMath.round(1.110636508023106d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.5937799705969213d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8288317194933723d + "'", double1 == 0.8288317194933723d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.5772156649015329d, 0.5403023058681398d, 2.6508641820894225d);
        try {
            double double5 = normalDistributionImpl3.inverseCumulativeProbability(3.246216406046493d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 3.246 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        double double1 = org.apache.commons.math.util.FastMath.expm1(2.228145294313781d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.282633550559478d + "'", double1 == 8.282633550559478d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray3);
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException4);
        java.lang.Throwable throwable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, objArray16);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("3d787e85ce", objArray16);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException(localizable11, objArray16);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException(throwable9, "org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)", objArray16);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException21 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100, "76b6a5e15f", objArray16);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalArgumentException4, "28fc800164", objArray16);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalArgumentException4);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray16);
    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test341");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        java.lang.String str3 = randomDataImpl0.nextHexString((int) (short) 1);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double[] doubleArray6 = normalDistributionImpl4.sample((int) '#');
//        double double7 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        normalDistributionImpl4.reseedRandomGenerator((long) 52);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "6" + "'", str3.equals("6"));
//        org.junit.Assert.assertNotNull(doubleArray6);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0872677866930154d + "'", double7 == 0.0872677866930154d);
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        double double1 = org.apache.commons.math.util.FastMath.abs(1901.471065349969d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1901.471065349969d + "'", double1 == 1901.471065349969d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 11);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 11L + "'", long1 == 11L);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-1.0f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.09261919812827801d, (-0.11686640748183041d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        double double1 = org.apache.commons.math.special.Erf.erf(13.166275598782555d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test347");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        java.lang.String str5 = randomDataImpl0.nextSecureHexString(10);
//        try {
//            int int9 = randomDataImpl0.nextHypergeometric((int) (short) 1, 32, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 32 is larger than the maximum (1): number of successes (32) must be less than or equal to population size (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.8929802205461264d + "'", double3 == 2.8929802205461264d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "c2ef16a906" + "'", str5.equals("c2ef16a906"));
//    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) 100, (float) (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

//    @Test
//    public void test349() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test349");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.5772156649015329d, 0.5403023058681398d, 2.6508641820894225d);
//        double double5 = normalDistributionImpl3.density((double) 1);
//        double[] doubleArray7 = normalDistributionImpl3.sample((int) '#');
//        java.lang.Class<?> wildcardClass8 = normalDistributionImpl3.getClass();
//        double double9 = normalDistributionImpl3.sample();
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5436432847461893d + "'", double5 == 0.5436432847461893d);
//        org.junit.Assert.assertNotNull(doubleArray7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.8766614068337787d + "'", double9 == 0.8766614068337787d);
//    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException9);
        java.lang.Number number11 = numberIsTooLargeException4.getMax();
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Object[] objArray17 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("hi!", objArray17);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable12, objArray17);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException(localizable12, (java.lang.Number) (-4.821637045374455E-17d), (java.lang.Number) 3.199272643922325d, (java.lang.Number) 3.3801446234597954d);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 2.718281828459045d + "'", number11.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray17);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
        double double3 = normalDistributionImpl2.getMean();
        double double6 = normalDistributionImpl2.cumulativeProbability((double) (short) -1, 3.207810091467445d);
        double double7 = normalDistributionImpl2.getStandardDeviation();
        double double9 = normalDistributionImpl2.cumulativeProbability(26.369176630649168d);
        double double10 = normalDistributionImpl2.getMean();
        double double11 = normalDistributionImpl2.getMean();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.544137102816975d + "'", double3 == 7.544137102816975d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08656193300300513d + "'", double6 == 0.08656193300300513d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.246216406046493d + "'", double7 == 3.246216406046493d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.9999999966658358d + "'", double9 == 0.9999999966658358d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 7.544137102816975d + "'", double10 == 7.544137102816975d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 7.544137102816975d + "'", double11 == 7.544137102816975d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.5408190484372157d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7174129306640737d + "'", double1 == 0.7174129306640737d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        double double1 = org.apache.commons.math.util.FastMath.sin(2.682465225821801E-8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6824652258218006E-8d + "'", double1 == 2.6824652258218006E-8d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, objArray4);
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException5);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException6.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, objArray13);
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("3d787e85ce", objArray13);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)", objArray13);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException(5, localizable7, objArray13);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        double double2 = org.apache.commons.math.util.FastMath.atan2(384.416897404767d, 12.236072099935386d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5389768560166752d + "'", double2 == 1.5389768560166752d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.6686911626851704d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        double double1 = org.apache.commons.math.util.FastMath.atan((-0.8390715290764524d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6981152095798223d) + "'", double1 == (-0.6981152095798223d));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        double double1 = org.apache.commons.math.util.FastMath.tanh(2.302585092994046d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9801980198019802d + "'", double1 == 0.9801980198019802d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.056295965999692776d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.056295965999692776d + "'", double1 == 0.056295965999692776d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.9166830407440092d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 21);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 21.0f + "'", float1 == 21.0f);
    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test363");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        java.lang.String str3 = randomDataImpl0.nextHexString((int) (short) 1);
//        randomDataImpl0.reSeedSecure();
//        try {
//            long long7 = randomDataImpl0.nextLong((long) (byte) 1, (long) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 1 is larger than, or equal to, the maximum (-1): lower bound (1) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "8" + "'", str3.equals("8"));
//    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(5.337333612629559d, 2.688167673504861d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.337333612629558d + "'", double2 == 5.337333612629558d);
    }

//    @Test
//    public void test365() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test365");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        double double11 = randomDataImpl0.nextGaussian(7.112156832451546d, 4.600161852571429d);
//        randomDataImpl0.reSeed();
//        try {
//            long long15 = randomDataImpl0.nextSecureLong(52L, 21L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 52 is larger than, or equal to, the maximum (21): lower bound (52) must be strictly less than upper bound (21)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.8385839135278994d + "'", double3 == 2.8385839135278994d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 8.376546692717467d + "'", double6 == 8.376546692717467d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3L + "'", long8 == 3L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 8.332498299313352d + "'", double11 == 8.332498299313352d);
//    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(6.798056507791588d, 0.9556007738814948d, 5.430377658846085d, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (-1) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((-1.5707963267948966d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.9846166530555597d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6827011600613289d + "'", double1 == 1.6827011600613289d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException("hi!", objArray6);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray6);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException8);
        java.lang.Class<?> wildcardClass10 = mathIllegalArgumentException8.getClass();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        double double1 = org.apache.commons.math.util.FastMath.asinh(384.416897404767d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.644876506300128d + "'", double1 == 6.644876506300128d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(1.5069067361076696d, (double) (byte) -1);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0000000000000004d + "'", double1 == 2.0000000000000004d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(7.0556774532612865d, 5.871713382091761d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6352221186329476d + "'", double2 == 0.6352221186329476d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException("hi!", objArray6);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray6);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException8);
        java.lang.Object[] objArray10 = mathException9.getArguments();
        java.lang.String str11 = mathException9.toString();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.MathException: " + "'", str11.equals("org.apache.commons.math.MathException: "));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(2.7089894095686646d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.44200120958159506d + "'", double1 == 0.44200120958159506d);
    }

//    @Test
//    public void test376() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test376");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        double double11 = randomDataImpl0.nextGaussian(7.112156832451546d, 4.600161852571429d);
//        try {
//            int int14 = randomDataImpl0.nextPascal((int) (byte) 0, 1.3422320186509582d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 1.342 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.8072720453959303d + "'", double3 == 2.8072720453959303d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.4038803619750926d + "'", double6 == 2.4038803619750926d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 6.734252455987802d + "'", double11 == 6.734252455987802d);
//    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        java.lang.Number number3 = notStrictlyPositiveException1.getMin();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException1.getGeneralPattern();
        java.lang.Number number5 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3383347192042695E42d + "'", double1 == 1.3383347192042695E42d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.5241188901436967d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test380() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test380");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        java.lang.String str3 = randomDataImpl0.nextHexString((int) (short) 1);
//        randomDataImpl0.reSeedSecure();
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution5 = null;
//        try {
//            int int6 = randomDataImpl0.nextInversionDeviate(integerDistribution5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "d" + "'", str3.equals("d"));
//    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) 1, (float) 1L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        long long2 = org.apache.commons.math.util.FastMath.max(21L, (long) 32);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        double double1 = org.apache.commons.math.util.FastMath.sinh(26.369176630649168d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4156565652014502E11d + "'", double1 == 1.4156565652014502E11d);
    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test384");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        java.lang.String str5 = randomDataImpl0.nextSecureHexString(10);
//        randomDataImpl0.reSeedSecure();
//        double double8 = randomDataImpl0.nextExponential(0.017453292519943295d);
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeed((long) 100);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.019615807334041d + "'", double3 == 3.019615807334041d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "a941d16cb1" + "'", str5.equals("a941d16cb1"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.008059690786305607d + "'", double8 == 0.008059690786305607d);
//    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        long long1 = org.apache.commons.math.util.FastMath.round(2.604389633748831d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3L + "'", long1 == 3L);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.6511961857760066d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6511961857760066d + "'", double1 == 0.6511961857760066d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.4614290299912925d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        double double1 = org.apache.commons.math.util.FastMath.log(3.20459618189556d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1645860861459973d + "'", double1 == 1.1645860861459973d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-0.7382963518864856d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2851476301750329d + "'", double1 == 1.2851476301750329d);
    }

//    @Test
//    public void test391() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test391");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        double[] doubleArray14 = normalDistributionImpl11.sample(100);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.9424161792464414d + "'", double3 == 2.9424161792464414d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.269076108061911d + "'", double6 == 1.269076108061911d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.832318046605041d + "'", double12 == 4.832318046605041d);
//        org.junit.Assert.assertNotNull(doubleArray14);
//    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        double double1 = org.apache.commons.math.util.FastMath.log(2.7101422139079343d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9970011109715183d + "'", double1 == 0.9970011109715183d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 8.282633550559478d, (java.lang.Number) 0.08610676786594773d, false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.9970011109715183d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6521730507294445d + "'", double1 == 1.6521730507294445d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed();
        org.apache.commons.math.distribution.IntegerDistribution integerDistribution2 = null;
        try {
            int int3 = randomDataImpl0.nextInversionDeviate(integerDistribution2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 'a', (float) 387632507);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.87632512E8f + "'", float2 == 3.87632512E8f);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 0.5693386188584106d);
        double double3 = normalDistributionImpl2.getMean();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

//    @Test
//    public void test398() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test398");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        try {
//            int[] intArray11 = randomDataImpl0.nextPermutation(0, 21);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 21 is larger than the maximum (0): permutation size (21) exceeds permuation domain (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.7817126674257677d + "'", double3 == 2.7817126674257677d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.7833799059827171d + "'", double6 == 1.7833799059827171d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.9387528551808952d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException9);
        java.lang.Number number11 = numberIsTooLargeException4.getMax();
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Number number14 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, (java.lang.Number) (-0.46046391868746567d), number14, false);
        java.lang.Object[] objArray21 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray21);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException(localizable12, objArray21);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("9913e0bd71", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable25 = convergenceException24.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable25, (java.lang.Number) (-0.6321205588285577d), (java.lang.Number) 4.771725959280734d, true);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 2.718281828459045d + "'", number11.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(localizable25);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray3);
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException4);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable10, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException9.addSuppressed((java.lang.Throwable) numberIsTooSmallException14);
        java.lang.Number number16 = numberIsTooLargeException9.getMax();
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooLargeException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, objArray21);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, objArray21);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException27 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable17, (java.lang.Number) 0.0015107907377931822d, (java.lang.Number) (-0.5961722400471147d), true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException29 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable17, (java.lang.Number) 32L);
        java.lang.Throwable throwable32 = null;
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, objArray39);
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException("3d787e85ce", objArray39);
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException(localizable34, objArray39);
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException(throwable32, "org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)", objArray39);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException44 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100, "76b6a5e15f", objArray39);
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException5, localizable17, objArray39);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException49 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException54 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable50, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException49.addSuppressed((java.lang.Throwable) numberIsTooSmallException54);
        java.lang.Number number56 = numberIsTooLargeException49.getMax();
        org.apache.commons.math.exception.util.Localizable localizable57 = numberIsTooLargeException49.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException59 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable57, (java.lang.Number) 100L);
        java.lang.Object[] objArray60 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException61 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable57, objArray60);
        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable64 = mathException63.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable65 = null;
        org.apache.commons.math.exception.util.Localizable localizable66 = null;
        org.apache.commons.math.exception.util.Localizable localizable68 = null;
        java.lang.Object[] objArray69 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException70 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable68, objArray69);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException71 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable65, localizable66, objArray69);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException72 = new org.apache.commons.math.MaxIterationsExceededException((int) '#', localizable64, objArray69);
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException(localizable57, objArray69);
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException(localizable17, objArray69);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 2.718281828459045d + "'", number16.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertTrue("'" + number56 + "' != '" + 2.718281828459045d + "'", number56.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable57.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + localizable64 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable64.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray69);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        float float2 = org.apache.commons.math.util.FastMath.min(100.0f, 3.87632512E8f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        double double1 = org.apache.commons.math.util.FastMath.exp(4.605170185988092d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.00000000000004d + "'", double1 == 100.00000000000004d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.9387528551808952d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8373955877591496d + "'", double1 == 0.8373955877591496d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) 0, (float) 10L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        double double1 = org.apache.commons.math.util.FastMath.cos(3.174836522999019d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9994474734617785d) + "'", double1 == (-0.9994474734617785d));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.8813735870195429d, (java.lang.Number) 6.845205783271511d, (java.lang.Number) 0.9556007738814948d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        java.lang.Number number10 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray15);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray15);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 0.0015107907377931822d, (java.lang.Number) (-0.5961722400471147d), true);
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException("hi!", objArray28);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, localizable23, objArray28);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException30);
        java.lang.Object[] objArray32 = mathException31.getArguments();
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException(localizable11, objArray32);
        java.lang.Object[] objArray34 = mathException33.getArguments();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 2.718281828459045d + "'", number10.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray34);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        double double1 = org.apache.commons.math.special.Gamma.digamma((double) 111L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.70501893323266d + "'", double1 == 4.70501893323266d);
    }

//    @Test
//    public void test412() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test412");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        java.lang.String str3 = randomDataImpl0.nextHexString((int) (short) 1);
//        try {
//            long long6 = randomDataImpl0.nextLong(100L, (long) (short) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (1): lower bound (100) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "8" + "'", str3.equals("8"));
//    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        double double1 = org.apache.commons.math.special.Erf.erf((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8427007929497151d + "'", double1 == 0.8427007929497151d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(14.988122469658162d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.26159208578767884d + "'", double1 == 0.26159208578767884d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(8.06974200818588d, 10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.22743310590944654d + "'", double2 == 0.22743310590944654d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        int int1 = org.apache.commons.math.util.FastMath.round(3.87632512E8f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 387632512 + "'", int1 == 387632512);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 111L, 12.236072099935386d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0634557801337836E25d + "'", double2 == 1.0634557801337836E25d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        double double1 = org.apache.commons.math.util.FastMath.acosh(2.744220474423504d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6676601980875625d + "'", double1 == 1.6676601980875625d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        double double1 = org.apache.commons.math.util.FastMath.tanh(3.1627992970815084d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9964266069777534d + "'", double1 == 0.9964266069777534d);
    }

//    @Test
//    public void test420() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test420");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double5 = randomDataImpl0.nextExponential(Double.NaN);
//        double double8 = randomDataImpl0.nextGamma((double) (byte) 1, (double) 10.0f);
//        randomDataImpl0.reSeedSecure((long) (byte) 100);
//        double double13 = randomDataImpl0.nextF(3.5133004999316397d, 0.6511961857760066d);
//        double double16 = randomDataImpl0.nextGaussian(22025.465794806718d, 0.8590238068419813d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.657796346323199d + "'", double3 == 2.657796346323199d);
//        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 11.745934288778123d + "'", double8 == 11.745934288778123d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 31.424980954521963d + "'", double13 == 31.424980954521963d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 22025.05663502662d + "'", double16 == 22025.05663502662d);
//    }

//    @Test
//    public void test421() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test421");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        java.lang.String str5 = randomDataImpl0.nextSecureHexString(10);
//        randomDataImpl0.reSeed((long) 10);
//        try {
//            java.lang.String str9 = randomDataImpl0.nextSecureHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.659615404317621d + "'", double3 == 2.659615404317621d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "5fdc419544" + "'", str5.equals("5fdc419544"));
//    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.019694478074841076d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.4373348686781097E-4d + "'", double1 == 3.4373348686781097E-4d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(2.7809006500430664d, 2.801622921646229d, 0.6352221186329476d, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (1) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(2.108232909743466d, 4.074641927246987d, 100.00000000000004d, 10);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.9019588283731186d + "'", double4 == 0.9019588283731186d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
        double double4 = normalDistributionImpl2.inverseCumulativeProbability(0.5403023058681398d);
        normalDistributionImpl2.reseedRandomGenerator(0L);
        double double7 = normalDistributionImpl2.getMean();
        double double9 = normalDistributionImpl2.density(0.31103915499158813d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.8726391065033505d + "'", double4 == 7.8726391065033505d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 7.544137102816975d + "'", double7 == 7.544137102816975d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.01026738484769776d + "'", double9 == 0.01026738484769776d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 2.552863873682405d, number1, true);
    }

//    @Test
//    public void test427() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test427");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        double double11 = randomDataImpl0.nextGaussian(7.112156832451546d, 4.600161852571429d);
//        try {
//            double double14 = randomDataImpl0.nextF(0.0872677866930154d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.9273062319945793d + "'", double3 == 2.9273062319945793d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 5.012146529940533d + "'", double6 == 5.012146529940533d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 15.220842281005037d + "'", double11 == 15.220842281005037d);
//    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-6.816718961678583d), 0.9970011109715183d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-6.816718961678582d) + "'", double2 == (-6.816718961678582d));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.019694478074841076d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.916365013646377d + "'", double1 == 3.916365013646377d);
    }

//    @Test
//    public void test430() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test430");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        java.lang.String str5 = randomDataImpl0.nextSecureHexString(10);
//        randomDataImpl0.reSeed();
//        double double9 = randomDataImpl0.nextUniform(2.0198227150790538d, 10.693737673234912d);
//        double double12 = randomDataImpl0.nextCauchy(0.9999999966658358d, 1.9257114897742607d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.94139907257671d + "'", double3 == 2.94139907257671d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ec5bf1f27d" + "'", str5.equals("ec5bf1f27d"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 6.894970724176963d + "'", double9 == 6.894970724176963d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-0.02012092213614458d) + "'", double12 == (-0.02012092213614458d));
//    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        double double1 = org.apache.commons.math.util.FastMath.tan(2.9424161792464414d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.2018528129723343d) + "'", double1 == (-0.2018528129723343d));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        double double1 = org.apache.commons.math.util.FastMath.asinh(7.206685735830315d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6729355485239057d + "'", double1 == 2.6729355485239057d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException("hi!", objArray6);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray6);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException8);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathIllegalArgumentException8.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNull(localizable10);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.2179013918188908d, (-6.816718961678583d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.9647942139794674d + "'", double2 == 2.9647942139794674d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.016678379838837916d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3596.5509605926745d + "'", double1 == 3596.5509605926745d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.4928407777776485d);
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException3);
        java.lang.Throwable[] throwableArray5 = mathException4.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException(0, "0269e51c0f", (java.lang.Object[]) throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(3.4373348686781097E-4d, (-4.229123881020407d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.437334868678109E-4d + "'", double2 == 3.437334868678109E-4d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        double double1 = org.apache.commons.math.util.FastMath.atanh(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test440");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        randomDataImpl0.reSeed((long) 1);
//        double double17 = randomDataImpl0.nextCauchy(Double.NEGATIVE_INFINITY, 7.513629774969273d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.958276140683244d + "'", double3 == 2.958276140683244d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.447426064297152d + "'", double6 == 4.447426064297152d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.9403872825362933d + "'", double12 == 3.9403872825362933d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + Double.NEGATIVE_INFINITY + "'", double17 == Double.NEGATIVE_INFINITY);
//    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 4.097470561084089d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(4.6594147143427955d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.659414714342796d + "'", double1 == 4.659414714342796d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        double double1 = org.apache.commons.math.util.FastMath.floor(6.894970724176963d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.0d + "'", double1 == 6.0d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.3657118231904856d, 99.99999999999999d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1901.471065349969d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2737367544323206E-13d + "'", double1 == 2.2737367544323206E-13d);
    }

//    @Test
//    public void test446() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test446");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        java.lang.String str3 = randomDataImpl0.nextHexString((int) (short) 1);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double8 = normalDistributionImpl7.getMean();
//        double double10 = normalDistributionImpl7.density((double) (short) 1);
//        double double11 = normalDistributionImpl7.sample();
//        double[] doubleArray13 = normalDistributionImpl7.sample((int) (short) 10);
//        double double16 = normalDistributionImpl7.cumulativeProbability(2.0198227150790538d, (double) 100);
//        double double17 = normalDistributionImpl7.sample();
//        double double18 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        java.lang.String str20 = randomDataImpl0.nextSecureHexString(52);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "6" + "'", str3.equals("6"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 7.544137102816975d + "'", double8 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.01610846091529747d + "'", double10 == 0.01610846091529747d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 8.403128789365441d + "'", double11 == 8.403128789365441d);
//        org.junit.Assert.assertNotNull(doubleArray13);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.9556007738814948d + "'", double16 == 0.9556007738814948d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 7.846662424500936d + "'", double17 == 7.846662424500936d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 7.659793813137549d + "'", double18 == 7.659793813137549d);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0fa60f9c60a7c6d3e3a2c1196c0aba29e062e9b572fabcfafc55" + "'", str20.equals("0fa60f9c60a7c6d3e3a2c1196c0aba29e062e9b572fabcfafc55"));
//    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 0L, (float) 2L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.0d + "'", double1 == 32.0d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(12.801827480081469d, 31.424980954521963d);
    }

//    @Test
//    public void test450() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test450");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double5 = randomDataImpl0.nextExponential(Double.NaN);
//        double double8 = randomDataImpl0.nextUniform(0.9969748643467198d, 6.798056507791588d);
//        randomDataImpl0.reSeedSecure(100L);
//        double double12 = randomDataImpl0.nextT(1.432116947405487d);
//        int int15 = randomDataImpl0.nextZipf(10, 3.081725078478352d);
//        double double17 = randomDataImpl0.nextT(3.237011984115693d);
//        randomDataImpl0.reSeedSecure((long) 19);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.9135047301973307d + "'", double3 == 2.9135047301973307d);
//        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.9996224102941014d + "'", double8 == 3.9996224102941014d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.1356828912995087d + "'", double12 == 1.1356828912995087d);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-0.19563207552233094d) + "'", double17 == (-0.19563207552233094d));
//    }

//    @Test
//    public void test451() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test451");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double3 = normalDistributionImpl2.getMean();
//        double double5 = normalDistributionImpl2.density((double) (short) 1);
//        double double6 = normalDistributionImpl2.sample();
//        double double7 = normalDistributionImpl2.sample();
//        try {
//            double double10 = normalDistributionImpl2.cumulativeProbability(0.5551940451963508d, 0.34766712944793493d);
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.544137102816975d + "'", double3 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.01610846091529747d + "'", double5 == 0.01610846091529747d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 11.097253011577454d + "'", double6 == 11.097253011577454d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 15.793673832104322d + "'", double7 == 15.793673832104322d);
//    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        java.lang.Object[] objArray5 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException("hi!", objArray5);
        java.lang.Class<?> wildcardClass7 = objArray5.getClass();
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("b0f617732c", objArray5);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException8);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable15, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException14.addSuppressed((java.lang.Throwable) numberIsTooSmallException19);
        java.lang.Number number21 = numberIsTooLargeException14.getMax();
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooLargeException14.getGeneralPattern();
        java.lang.Object[] objArray27 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException("hi!", objArray27);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable22, objArray27);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException33 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException38 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable34, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException33.addSuppressed((java.lang.Throwable) numberIsTooSmallException38);
        java.lang.Number number40 = numberIsTooLargeException33.getMax();
        org.apache.commons.math.exception.util.Localizable localizable41 = numberIsTooLargeException33.getGeneralPattern();
        java.lang.Number number43 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException45 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable41, (java.lang.Number) (-0.46046391868746567d), number43, false);
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException50 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable48, objArray49);
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException45, "6", objArray49);
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException(localizable22, objArray49);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException56 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable22, (java.lang.Number) 0.9212587981384309d, (java.lang.Number) 1.5069067361076696d, true);
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException61 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable57, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        boolean boolean62 = numberIsTooSmallException61.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable63 = numberIsTooSmallException61.getSpecificPattern();
        java.lang.Object[] objArray64 = numberIsTooSmallException61.getArguments();
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException8, localizable22, objArray64);
        java.lang.Object[] objArray70 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException("hi!", objArray70);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException72 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, objArray70);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException76 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable22, (java.lang.Number) 3.022862605844216d, (java.lang.Number) 2.002844215635055d, false);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 2.718281828459045d + "'", number21.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + number40 + "' != '" + 2.718281828459045d + "'", number40.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable41.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNull(localizable63);
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(objArray70);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 2.0198227150790538d, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        java.lang.Number number6 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (byte) 1 + "'", number6.equals((byte) 1));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        double double1 = org.apache.commons.math.util.FastMath.log10(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        double double1 = org.apache.commons.math.util.FastMath.expm1(2.5083432919410233d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.284561260950033d + "'", double1 == 11.284561260950033d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        double double1 = org.apache.commons.math.util.FastMath.log1p(2.1073424255447017E-8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1073424033402416E-8d + "'", double1 == 2.1073424033402416E-8d);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100);
        org.apache.commons.math.exception.util.Localizable localizable2 = maxIterationsExceededException1.getSpecificPattern();
        int int3 = maxIterationsExceededException1.getMaxIterations();
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException1);
        int int5 = maxIterationsExceededException1.getMaxIterations();
        org.junit.Assert.assertNull(localizable2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
        try {
            double[] doubleArray4 = normalDistributionImpl2.sample((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): number of samples (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.7087461852015375d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7087461852015374d + "'", double2 == 0.7087461852015374d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        double double1 = org.apache.commons.math.util.FastMath.expm1(5.337333612629559d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 206.95747519668325d + "'", double1 == 206.95747519668325d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.5614628358856486d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        double double1 = org.apache.commons.math.util.FastMath.acosh(2.9898176418264275d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.75914027515019d + "'", double1 == 1.75914027515019d);
    }

//    @Test
//    public void test463() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test463");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 32L);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution4 = null;
//        try {
//            int int5 = randomDataImpl1.nextInversionDeviate(integerDistribution4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5333345193303082d + "'", double3 == 0.5333345193303082d);
//    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 9.57249448450651d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(4.605170185988092d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 263.856815596594d + "'", double1 == 263.856815596594d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 7.421477398171811d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.421477398171811d + "'", double2 == 7.421477398171811d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-0.8414709848078964d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test468() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test468");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        try {
//            double double11 = randomDataImpl0.nextCauchy((-0.6321205588285577d), 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): scale (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.047905278978734d + "'", double3 == 3.047905278978734d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.334344833006594d + "'", double6 == 4.334344833006594d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        double double1 = org.apache.commons.math.util.FastMath.log(1.269076108061911d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2382891617659135d + "'", double1 == 0.2382891617659135d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.0f, (java.lang.Number) 2.718281828459045d, true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        boolean boolean6 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 2.718281828459045d + "'", number5.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 10L, (-1.0f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(21);
        java.lang.String str2 = maxIterationsExceededException1.getPattern();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "maximal number of iterations ({0}) exceeded" + "'", str2.equals("maximal number of iterations ({0}) exceeded"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1555698629817919d + "'", double1 == 1.1555698629817919d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        java.lang.Number number10 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 100L);
        java.lang.Number number16 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) 2.5083432919410233d, (java.lang.Number) 10.693737673234912d, number16);
        java.lang.Number number18 = outOfRangeException17.getHi();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 2.718281828459045d + "'", number10.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNull(number18);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed();
        java.lang.String str3 = randomDataImpl0.nextHexString((int) (short) 1);
        randomDataImpl0.reSeed();
        try {
            double double6 = randomDataImpl0.nextChiSquare(0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "c" + "'", str3.equals("c"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.8560818335760244d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6554018057382806d + "'", double1 == 0.6554018057382806d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        java.lang.Number number10 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooLargeException3.getGeneralPattern();
        java.lang.Number number12 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, number12, (java.lang.Number) 5.337333612629559d, true);
        java.lang.Number number16 = numberIsTooLargeException15.getMax();
        boolean boolean17 = numberIsTooLargeException15.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 2.718281828459045d + "'", number10.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 5.337333612629559d + "'", number16.equals(5.337333612629559d));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException6.addSuppressed((java.lang.Throwable) numberIsTooSmallException11);
        java.lang.Number number13 = numberIsTooLargeException6.getMax();
        org.apache.commons.math.exception.util.Localizable localizable14 = numberIsTooLargeException6.getGeneralPattern();
        java.lang.Object[] objArray19 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException("hi!", objArray19);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException21 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable14, objArray19);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException25 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException30 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable26, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException25.addSuppressed((java.lang.Throwable) numberIsTooSmallException30);
        java.lang.Number number32 = numberIsTooLargeException25.getMax();
        org.apache.commons.math.exception.util.Localizable localizable33 = numberIsTooLargeException25.getGeneralPattern();
        java.lang.Number number35 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable33, (java.lang.Number) (-0.46046391868746567d), number35, false);
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        java.lang.Object[] objArray41 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException42 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable40, objArray41);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException37, "6", objArray41);
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException(localizable14, objArray41);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException45 = new org.apache.commons.math.MaxIterationsExceededException(123, "ce3f629aa2", objArray41);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 2.718281828459045d + "'", number13.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 2.718281828459045d + "'", number32.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable33.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray41);
    }

//    @Test
//    public void test480() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test480");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        java.lang.String str5 = randomDataImpl0.nextSecureHexString(10);
//        randomDataImpl0.reSeedSecure();
//        double double8 = randomDataImpl0.nextExponential(0.017453292519943295d);
//        int int11 = randomDataImpl0.nextPascal(32, 0.2297948594237435d);
//        try {
//            int int15 = randomDataImpl0.nextHypergeometric((int) (byte) -1, (-1), 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): population size (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0259708009053994d + "'", double3 == 3.0259708009053994d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "b268c696d4" + "'", str5.equals("b268c696d4"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.00690041042724225d + "'", double8 == 0.00690041042724225d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 93 + "'", int11 == 93);
//    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        int int2 = org.apache.commons.math.util.FastMath.max(0, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

//    @Test
//    public void test482() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test482");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        java.lang.String str5 = randomDataImpl0.nextSecureHexString(10);
//        randomDataImpl0.reSeed();
//        double double9 = randomDataImpl0.nextWeibull((double) 1.0f, 1.75914027515019d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.026562968104169d + "'", double3 == 3.026562968104169d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "5fe1a85406" + "'", str5.equals("5fe1a85406"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.9326729525622646d + "'", double9 == 1.9326729525622646d);
//    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        double double1 = org.apache.commons.math.util.FastMath.cosh(2.712952382754662d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.57002695467304d + "'", double1 == 7.57002695467304d);
    }

//    @Test
//    public void test484() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test484");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        double double11 = randomDataImpl0.nextCauchy((-21.46708637494148d), (double) 19);
//        randomDataImpl0.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0248610758062204d + "'", double3 == 3.0248610758062204d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.436514342835055d + "'", double6 == 1.436514342835055d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2L + "'", long8 == 2L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-39.578186787813436d) + "'", double11 == (-39.578186787813436d));
//    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.010063323450154593d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException5.addSuppressed((java.lang.Throwable) numberIsTooSmallException10);
        java.lang.Number number12 = numberIsTooLargeException5.getMax();
        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooLargeException5.getGeneralPattern();
        java.lang.Number number15 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable13, (java.lang.Number) (-0.46046391868746567d), number15, false);
        java.lang.Object[] objArray22 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException("hi!", objArray22);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException(localizable13, objArray22);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException("9913e0bd71", objArray22);
        org.apache.commons.math.exception.util.Localizable localizable26 = convergenceException25.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException(localizable28, objArray29);
        org.apache.commons.math.exception.util.Localizable localizable31 = convergenceException30.getGeneralPattern();
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException30);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException36 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException41 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable37, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException36.addSuppressed((java.lang.Throwable) numberIsTooSmallException41);
        java.lang.Number number43 = numberIsTooLargeException36.getMax();
        org.apache.commons.math.exception.util.Localizable localizable44 = numberIsTooLargeException36.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException48 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException53 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable49, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException48.addSuppressed((java.lang.Throwable) numberIsTooSmallException53);
        java.lang.Number number55 = numberIsTooLargeException48.getMax();
        org.apache.commons.math.exception.util.Localizable localizable56 = numberIsTooLargeException48.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException61 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable57, objArray60);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable56, objArray60);
        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException30, localizable44, objArray60);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException64 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable26, localizable27, objArray60);
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException("maximal number of iterations ({0}) exceeded", objArray60);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 2.718281828459045d + "'", number12.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(localizable26);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNull(localizable31);
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + 2.718281828459045d + "'", number43.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable44.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number55 + "' != '" + 2.718281828459045d + "'", number55.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable56 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable56.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray60);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        java.lang.Number number10 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 100L);
        java.lang.Object[] objArray14 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray14);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable18 = mathException17.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        java.lang.Object[] objArray23 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException24 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable22, objArray23);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, localizable20, objArray23);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) '#', localizable18, objArray23);
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException(localizable11, objArray23);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException29 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 0.9149059515984214d);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 2.718281828459045d + "'", number10.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray23);
    }

//    @Test
//    public void test488() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test488");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        randomDataImpl0.reSeed((long) 100);
//        int int11 = randomDataImpl0.nextZipf((int) ' ', 0.31103915499158813d);
//        double double14 = randomDataImpl0.nextWeibull(7.853107962480361d, 6.966171178609635d);
//        try {
//            long long17 = randomDataImpl0.nextSecureLong((long) 2147483647, (long) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 2,147,483,647 is larger than, or equal to, the maximum (0): lower bound (2,147,483,647) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.9985709501272786d + "'", double3 == 2.9985709501272786d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 5.218246276121185d + "'", double6 == 5.218246276121185d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 21 + "'", int11 == 21);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 5.734168005807173d + "'", double14 == 5.734168005807173d);
//    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        double double1 = org.apache.commons.math.special.Erf.erf(0.22743310590944654d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2522737922403927d + "'", double1 == 0.2522737922403927d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ');
        int int2 = maxIterationsExceededException1.getMaxIterations();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 2.710071082755576d, (java.lang.Number) (-0.5772156677920679d), false);
        maxIterationsExceededException1.addSuppressed((java.lang.Throwable) numberIsTooLargeException6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

//    @Test
//    public void test491() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test491");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        randomDataImpl0.reSeed((long) 1);
//        double double17 = randomDataImpl0.nextBeta(10.052870324770753d, 2.712952382754662d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.994557582808462d + "'", double3 == 2.994557582808462d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.527350318435212d + "'", double6 == 1.527350318435212d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 11.686539048606228d + "'", double12 == 11.686539048606228d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.8656890441941347d + "'", double17 == 0.8656890441941347d);
//    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(2.7809006500430664d, 0.0d, 1.9257114897742607d, 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
        double double3 = normalDistributionImpl2.getMean();
        double double4 = normalDistributionImpl2.getMean();
        double double5 = normalDistributionImpl2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.544137102816975d + "'", double3 == 7.544137102816975d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.544137102816975d + "'", double4 == 7.544137102816975d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.246216406046493d + "'", double5 == 3.246216406046493d);
    }

//    @Test
//    public void test494() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test494");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        double double11 = randomDataImpl0.nextCauchy(2.99822295029797d, 7.8726391065033505d);
//        randomDataImpl0.reSeed(111L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.991568925239926d + "'", double3 == 2.991568925239926d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.3219530538816453d + "'", double6 == 1.3219530538816453d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2L + "'", long8 == 2L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 11.054609886555099d + "'", double11 == 11.054609886555099d);
//    }

//    @Test
//    public void test495() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test495");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double5 = randomDataImpl0.nextExponential(Double.NaN);
//        double double8 = randomDataImpl0.nextUniform(0.9969748643467198d, 6.798056507791588d);
//        try {
//            double double11 = randomDataImpl0.nextGamma((double) 11.0f, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): beta");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.288297707957057d + "'", double3 == 3.288297707957057d);
//        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.149303405527249d + "'", double8 == 6.149303405527249d);
//    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(1.630391949037867d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8375502720561994d + "'", double1 == 0.8375502720561994d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 4.097470561084089d, (java.lang.Number) 2.5139994585534726d, (java.lang.Number) 7.164591543681963d);
        org.apache.commons.math.exception.util.Localizable localizable4 = outOfRangeException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNull(localizable5);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        long long2 = org.apache.commons.math.util.FastMath.max(100L, (long) 5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 2.0198227150790538d, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray11);
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException("3d787e85ce", objArray11);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException5, "fd4ecaf23f", objArray11);
        java.lang.String str15 = convergenceException5.getPattern();
        java.lang.String str16 = convergenceException5.getPattern();
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "{0}" + "'", str15.equals("{0}"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "{0}" + "'", str16.equals("{0}"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        double double1 = org.apache.commons.math.special.Gamma.digamma(2.302585092994046d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.601441425445969d + "'", double1 == 0.601441425445969d);
    }
}

