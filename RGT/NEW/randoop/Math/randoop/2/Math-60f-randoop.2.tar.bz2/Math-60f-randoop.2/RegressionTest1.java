import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException9);
        java.lang.Number number11 = numberIsTooLargeException4.getMax();
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Object[] objArray17 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("hi!", objArray17);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable12, objArray17);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable24, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException23.addSuppressed((java.lang.Throwable) numberIsTooSmallException28);
        java.lang.Number number30 = numberIsTooLargeException23.getMax();
        org.apache.commons.math.exception.util.Localizable localizable31 = numberIsTooLargeException23.getGeneralPattern();
        java.lang.Number number33 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException35 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable31, (java.lang.Number) (-0.46046391868746567d), number33, false);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException40 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable38, objArray39);
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException35, "6", objArray39);
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException(localizable12, objArray39);
        java.lang.Object[] objArray43 = null;
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException(localizable12, objArray43);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 2.718281828459045d + "'", number11.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 2.718281828459045d + "'", number30.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray39);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test003");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double5 = randomDataImpl0.nextExponential(Double.NaN);
//        double double8 = randomDataImpl0.nextGamma((double) (byte) 1, (double) 10.0f);
//        randomDataImpl0.reSeedSecure((long) (byte) 100);
//        java.lang.String str12 = randomDataImpl0.nextSecureHexString(11);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.3489941619972536d + "'", double3 == 3.3489941619972536d);
//        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.4529340028451903d + "'", double8 == 3.4529340028451903d);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "f782adf1f99" + "'", str12.equals("f782adf1f99"));
//    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        double double1 = org.apache.commons.math.special.Erf.erf(2.9434175377783776d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999685384675274d + "'", double1 == 0.9999685384675274d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException5.addSuppressed((java.lang.Throwable) numberIsTooSmallException10);
        java.lang.Number number12 = numberIsTooLargeException5.getMax();
        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooLargeException5.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException(localizable13, (java.lang.Number) (-6.816718961678583d), (java.lang.Number) 3.20459618189556d, (java.lang.Number) 5.169076857913174d);
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) outOfRangeException17);
        boolean boolean19 = notStrictlyPositiveException1.getBoundIsAllowed();
        boolean boolean20 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 2.718281828459045d + "'", number12.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test006");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double3 = normalDistributionImpl2.getMean();
//        double double5 = normalDistributionImpl2.density((double) (short) 1);
//        double double6 = normalDistributionImpl2.sample();
//        double[] doubleArray8 = normalDistributionImpl2.sample((int) (short) 10);
//        double double10 = normalDistributionImpl2.cumulativeProbability(0.0d);
//        double double13 = normalDistributionImpl2.cumulativeProbability(0.0d, 0.0d);
//        double double14 = normalDistributionImpl2.getStandardDeviation();
//        double[] doubleArray16 = normalDistributionImpl2.sample(35);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.544137102816975d + "'", double3 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.01610846091529747d + "'", double5 == 0.01610846091529747d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 11.88730720928903d + "'", double6 == 11.88730720928903d);
//        org.junit.Assert.assertNotNull(doubleArray8);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.010063323450154593d + "'", double10 == 0.010063323450154593d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.246216406046493d + "'", double14 == 3.246216406046493d);
//        org.junit.Assert.assertNotNull(doubleArray16);
//    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        randomDataImpl0.reSeed((long) 100);
//        double double11 = randomDataImpl0.nextWeibull((double) 11, 0.5764035919569829d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.2365580296009484d + "'", double3 == 3.2365580296009484d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.319471924789691d + "'", double6 == 1.319471924789691d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.589492451936513d + "'", double11 == 0.589492451936513d);
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        double double1 = org.apache.commons.math.util.FastMath.sinh(2.6975094779926425d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.387673218183934d + "'", double1 == 7.387673218183934d);
    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test009");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        randomDataImpl0.reSeed((long) 1);
//        double double17 = randomDataImpl0.nextBeta((double) 10L, (double) 10);
//        randomDataImpl0.reSeed(2L);
//        try {
//            int int22 = randomDataImpl0.nextPascal((int) 'a', 1.1356828912995087d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 1.136 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.2297066312439062d + "'", double3 == 3.2297066312439062d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0207033957944334d + "'", double6 == 2.0207033957944334d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 6.94120756672635d + "'", double12 == 6.94120756672635d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.5693386188584106d + "'", double17 == 0.5693386188584106d);
//    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException7.addSuppressed((java.lang.Throwable) numberIsTooSmallException12);
        java.lang.Number number14 = numberIsTooLargeException7.getMax();
        org.apache.commons.math.exception.util.Localizable localizable15 = numberIsTooLargeException7.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException17 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable15, (java.lang.Number) 100L);
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException21 = new org.apache.commons.math.exception.OutOfRangeException(localizable15, (java.lang.Number) 2.5083432919410233d, (java.lang.Number) 10.693737673234912d, number20);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException25 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException30 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable26, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException25.addSuppressed((java.lang.Throwable) numberIsTooSmallException30);
        java.lang.Number number32 = numberIsTooLargeException25.getMax();
        java.lang.Object[] objArray33 = numberIsTooLargeException25.getArguments();
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException(localizable15, objArray33);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, "76b6a5e15f", objArray33);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException(0, "6", objArray33);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 2.718281828459045d + "'", number14.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 2.718281828459045d + "'", number32.equals(2.718281828459045d));
        org.junit.Assert.assertNotNull(objArray33);
    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test011");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double3 = normalDistributionImpl2.getMean();
//        double double5 = normalDistributionImpl2.density((double) (short) 1);
//        double double6 = normalDistributionImpl2.sample();
//        double[] doubleArray8 = normalDistributionImpl2.sample((int) (short) 10);
//        double double11 = normalDistributionImpl2.cumulativeProbability(2.0198227150790538d, (double) 100);
//        double double12 = normalDistributionImpl2.sample();
//        double double15 = normalDistributionImpl2.cumulativeProbability((-0.5772156677920679d), 3.237011984115693d);
//        double double16 = normalDistributionImpl2.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.544137102816975d + "'", double3 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.01610846091529747d + "'", double5 == 0.01610846091529747d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 11.89913102853212d + "'", double6 == 11.89913102853212d);
//        org.junit.Assert.assertNotNull(doubleArray8);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.9556007738814948d + "'", double11 == 0.9556007738814948d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 5.840821914086438d + "'", double12 == 5.840821914086438d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.08610676786594773d + "'", double15 == 0.08610676786594773d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 3.246216406046493d + "'", double16 == 3.246216406046493d);
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable1, objArray2);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException7.addSuppressed((java.lang.Throwable) numberIsTooSmallException12);
        java.lang.Number number14 = numberIsTooLargeException7.getMax();
        org.apache.commons.math.exception.util.Localizable localizable15 = numberIsTooLargeException7.getGeneralPattern();
        java.lang.Number number17 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable15, (java.lang.Number) (-0.46046391868746567d), number17, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable15, (java.lang.Number) 3.081725078478352d, (java.lang.Number) (-1.0d), true);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException28 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException33 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable29, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException28.addSuppressed((java.lang.Throwable) numberIsTooSmallException33);
        java.lang.Number number35 = numberIsTooLargeException28.getMax();
        org.apache.commons.math.exception.util.Localizable localizable36 = numberIsTooLargeException28.getGeneralPattern();
        java.lang.Object[] objArray41 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException("hi!", objArray41);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException43 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable36, objArray41);
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException3, localizable15, objArray41);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException46 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable15, (java.lang.Number) 0.4172934084748632d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException50 = new org.apache.commons.math.exception.OutOfRangeException(localizable15, (java.lang.Number) 10.448849566937042d, (java.lang.Number) 0.22743310590944654d, (java.lang.Number) 1.8057249505690445d);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 2.718281828459045d + "'", number14.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + 2.718281828459045d + "'", number35.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray41);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        double double1 = org.apache.commons.math.util.FastMath.ceil(10.569181794623525d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.0d + "'", double1 == 11.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.10516633568161556d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.10536116277732267d + "'", double1 == 0.10536116277732267d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 4.097470561084089d, (java.lang.Number) 2.5139994585534726d, (java.lang.Number) 7.164591543681963d);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 7.164591543681963d + "'", number4.equals(7.164591543681963d));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        double double2 = org.apache.commons.math.util.FastMath.pow(7.853107962480361d, 3.550128012953764d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1504.915597929068d + "'", double2 == 1504.915597929068d);
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test018");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double5 = randomDataImpl0.nextExponential(Double.NaN);
//        double double8 = randomDataImpl0.nextCauchy(0.019691932154573932d, 0.9969748643467198d);
//        int int11 = randomDataImpl0.nextZipf((int) (short) 10, (double) (short) 100);
//        double double14 = randomDataImpl0.nextBeta(7.405543313738405d, 10.016590736881785d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.1172092010193513d + "'", double3 == 3.1172092010193513d);
//        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-16.22816855639514d) + "'", double8 == (-16.22816855639514d));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.32837532176813833d + "'", double14 == 0.32837532176813833d);
//    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.432116947405487d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9612343989590776d + "'", double1 == 0.9612343989590776d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.003639155797242861d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0036457855645136545d + "'", double1 == 0.0036457855645136545d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) 11);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.09516633568161556d + "'", double1 == 0.09516633568161556d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        java.lang.Number number10 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray15);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray15);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 0.0015107907377931822d, (java.lang.Number) (-0.5961722400471147d), true);
        java.lang.Number number22 = numberIsTooLargeException21.getMax();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 2.718281828459045d + "'", number10.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (-0.5961722400471147d) + "'", number22.equals((-0.5961722400471147d)));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        double double1 = org.apache.commons.math.util.FastMath.atan(3.1838110482628132d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2664644922268984d + "'", double1 == 1.2664644922268984d);
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test024");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double5 = randomDataImpl0.nextExponential(Double.NaN);
//        double double8 = randomDataImpl0.nextGamma(1.7012502421118005d, 1.7692003247117487d);
//        try {
//            double double11 = randomDataImpl0.nextBeta(7.405543313738405d, (-6.816718961678583d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.493");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.1458190327643d + "'", double3 == 3.1458190327643d);
//        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.963513606915901d + "'", double8 == 1.963513606915901d);
//    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 2.710071082755576d, (java.lang.Number) (-0.5772156677920679d), false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("maximal number of iterations ({0}) exceeded", objArray1);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0036457855645136545d, (-1.5707963267948966d), (-6.816718961678583d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.571 is smaller than, or equal to, the minimum (0): standard deviation (-1.571)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test028");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double3 = normalDistributionImpl2.getMean();
//        double double5 = normalDistributionImpl2.density((double) (short) 1);
//        double double6 = normalDistributionImpl2.sample();
//        double[] doubleArray8 = normalDistributionImpl2.sample((int) (short) 10);
//        double double11 = normalDistributionImpl2.cumulativeProbability(2.0198227150790538d, (double) 100);
//        double double12 = normalDistributionImpl2.sample();
//        double double15 = normalDistributionImpl2.cumulativeProbability((-0.5772156677920679d), 3.237011984115693d);
//        double double17 = normalDistributionImpl2.density(0.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.544137102816975d + "'", double3 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.01610846091529747d + "'", double5 == 0.01610846091529747d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 8.845455831739777d + "'", double6 == 8.845455831739777d);
//        org.junit.Assert.assertNotNull(doubleArray8);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.9556007738814948d + "'", double11 == 0.9556007738814948d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.232058081591713d + "'", double12 == 4.232058081591713d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.08610676786594773d + "'", double15 == 0.08610676786594773d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.008255573916615357d + "'", double17 == 0.008255573916615357d);
//    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull(0.5937799705969213d, 2.3781075965944165d);
//        double double6 = randomDataImpl0.nextCauchy(0.0d, 1.007794608978476d);
//        double double9 = randomDataImpl0.nextBeta((double) 32.0f, 0.6511961857760066d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.671764761750561d + "'", double3 == 5.671764761750561d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.3006670635755746d + "'", double6 == 1.3006670635755746d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.9904046736395155d + "'", double9 == 0.9904046736395155d);
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException(throwable0);
        java.lang.Class<?> wildcardClass2 = convergenceException1.getClass();
        org.apache.commons.math.exception.util.Localizable localizable3 = convergenceException1.getGeneralPattern();
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray4);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 19, (float) 21);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 21.0f + "'", float2 == 21.0f);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed();
        int int4 = randomDataImpl0.nextInt(0, (int) (short) 1);
        try {
            int int7 = randomDataImpl0.nextSecureInt(387632512, 387632512);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 387,632,512 is larger than, or equal to, the maximum (387,632,512): lower bound (387,632,512) must be strictly less than upper bound (387,632,512)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        int[] intArray3 = randomDataImpl0.nextPermutation(52, 35);
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        double double1 = org.apache.commons.math.util.FastMath.log10(2.839602315843011d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.45325752169194927d + "'", double1 == 0.45325752169194927d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 52);
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        java.lang.String str5 = randomDataImpl0.nextSecureHexString(10);
//        randomDataImpl0.reSeedSecure();
//        double double8 = randomDataImpl0.nextExponential(0.017453292519943295d);
//        try {
//            int int11 = randomDataImpl0.nextSecureInt((int) (byte) 10, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 10 is larger than, or equal to, the maximum (0): lower bound (10) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.9683033081245895d + "'", double3 == 2.9683033081245895d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "b8fb7c0a63" + "'", str5.equals("b8fb7c0a63"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.046903659731621944d + "'", double8 == 0.046903659731621944d);
//    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        java.lang.String str5 = randomDataImpl0.nextSecureHexString(10);
//        double double7 = randomDataImpl0.nextChiSquare(4.992376204308797d);
//        try {
//            double double10 = randomDataImpl0.nextUniform(1.5389768560166752d, 0.32837532176813833d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 1.539 is larger than, or equal to, the maximum (0.328): lower bound (1.539) must be strictly less than upper bound (0.328)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.964744312404912d + "'", double3 == 2.964744312404912d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2c983215dd" + "'", str5.equals("2c983215dd"));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.4874294339663976d + "'", double7 == 3.4874294339663976d);
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable1, objArray2);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException7.addSuppressed((java.lang.Throwable) numberIsTooSmallException12);
        java.lang.Number number14 = numberIsTooLargeException7.getMax();
        org.apache.commons.math.exception.util.Localizable localizable15 = numberIsTooLargeException7.getGeneralPattern();
        java.lang.Number number17 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable15, (java.lang.Number) (-0.46046391868746567d), number17, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable15, (java.lang.Number) 3.081725078478352d, (java.lang.Number) (-1.0d), true);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException28 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException33 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable29, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException28.addSuppressed((java.lang.Throwable) numberIsTooSmallException33);
        java.lang.Number number35 = numberIsTooLargeException28.getMax();
        org.apache.commons.math.exception.util.Localizable localizable36 = numberIsTooLargeException28.getGeneralPattern();
        java.lang.Object[] objArray41 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException("hi!", objArray41);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException43 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable36, objArray41);
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException3, localizable15, objArray41);
        java.lang.Object[] objArray45 = maxIterationsExceededException3.getArguments();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 2.718281828459045d + "'", number14.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + 2.718281828459045d + "'", number35.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(objArray45);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        double double1 = org.apache.commons.math.util.FastMath.sinh(206.95747519668325d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.7971650151439824E89d + "'", double1 == 3.7971650151439824E89d);
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test041");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        randomDataImpl0.reSeed((long) 100);
//        try {
//            double double11 = randomDataImpl0.nextWeibull(11.654663620414674d, (-0.11686640748183041d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.117 is smaller than, or equal to, the minimum (0): scale (-0.117)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.9854556452133214d + "'", double3 == 2.9854556452133214d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.6376873084441507d + "'", double6 == 0.6376873084441507d);
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException9);
        java.lang.Number number11 = numberIsTooLargeException4.getMax();
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable12, (java.lang.Number) 100L);
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray15);
        java.lang.Object[] objArray17 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException(32, localizable12, objArray17);
        java.lang.Throwable throwable19 = null;
        try {
            maxIterationsExceededException18.addSuppressed(throwable19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 2.718281828459045d + "'", number11.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        double double14 = randomDataImpl0.nextChiSquare(3.141592653589793d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.924892537901834d + "'", double3 == 2.924892537901834d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.9828244164651508d + "'", double6 == 0.9828244164651508d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.9348362480511847d + "'", double12 == 3.9348362480511847d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.7618724457455945d + "'", double14 == 1.7618724457455945d);
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
        double double3 = normalDistributionImpl2.getMean();
        double double6 = normalDistributionImpl2.cumulativeProbability((double) (short) -1, 3.207810091467445d);
        double double7 = normalDistributionImpl2.getStandardDeviation();
        try {
            double double9 = normalDistributionImpl2.inverseCumulativeProbability(2.126048628120582d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 2.126 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.544137102816975d + "'", double3 == 7.544137102816975d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08656193300300513d + "'", double6 == 0.08656193300300513d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.246216406046493d + "'", double7 == 3.246216406046493d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        int int2 = org.apache.commons.math.util.FastMath.min((int) '#', (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0d);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.6216710141531901d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4834571078418192d + "'", double1 == 0.4834571078418192d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        float float2 = org.apache.commons.math.util.FastMath.min(1.0f, (float) 32);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test049");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        double double11 = randomDataImpl0.nextCauchy(2.99822295029797d, 7.8726391065033505d);
//        int int14 = randomDataImpl0.nextSecureInt(10, 32);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl17 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double18 = normalDistributionImpl17.getMean();
//        double double21 = normalDistributionImpl17.cumulativeProbability((double) (short) -1, 3.207810091467445d);
//        double double22 = normalDistributionImpl17.getStandardDeviation();
//        double double24 = normalDistributionImpl17.cumulativeProbability(26.369176630649168d);
//        double double25 = normalDistributionImpl17.getMean();
//        double double27 = normalDistributionImpl17.cumulativeProbability(0.6729937998766822d);
//        double double28 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl17);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.9202722798040206d + "'", double3 == 2.9202722798040206d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.111539907647543d + "'", double6 == 4.111539907647543d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.8908074841597324d + "'", double11 == 0.8908074841597324d);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 30 + "'", int14 == 30);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 7.544137102816975d + "'", double18 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.08656193300300513d + "'", double21 == 0.08656193300300513d);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 3.246216406046493d + "'", double22 == 3.246216406046493d);
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.9999999966658358d + "'", double24 == 0.9999999966658358d);
//        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 7.544137102816975d + "'", double25 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.017144266906994998d + "'", double27 == 0.017144266906994998d);
//        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 9.011665803911592d + "'", double28 == 9.011665803911592d);
//    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test050");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.5772156649015329d, 0.5403023058681398d, 2.6508641820894225d);
//        double double5 = normalDistributionImpl3.density(0.0d);
//        double double8 = normalDistributionImpl3.cumulativeProbability(0.0d, 0.1873987292549381d);
//        double double9 = normalDistributionImpl3.sample();
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.4172934084748632d + "'", double5 == 0.4172934084748632d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.09261919812827801d + "'", double8 == 0.09261919812827801d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.7102622648798613d + "'", double9 == 0.7102622648798613d);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        double double1 = org.apache.commons.math.util.FastMath.cosh(5.871713382091761d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 177.4296412225003d + "'", double1 == 177.4296412225003d);
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        randomDataImpl0.reSeed((long) 1);
//        double double17 = randomDataImpl0.nextF(0.9387528551808952d, 2.758443714131805d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.93286633363472d + "'", double3 == 2.93286633363472d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.1818642387456366d + "'", double6 == 3.1818642387456366d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 11.118605879059844d + "'", double12 == 11.118605879059844d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.8630926212463297d + "'", double17 == 1.8630926212463297d);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.5245066427138134d, number1, (java.lang.Number) 2.864710569476565d);
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        randomDataImpl0.reSeed((long) 100);
//        int int11 = randomDataImpl0.nextZipf((int) ' ', 0.31103915499158813d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution12 = null;
//        try {
//            int int13 = randomDataImpl0.nextInversionDeviate(integerDistribution12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.9270895468503744d + "'", double3 == 2.9270895468503744d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.4498418108001524d + "'", double6 == 0.4498418108001524d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 21 + "'", int11 == 21);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.11686640748183041d), number1, true);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.9999685384675274d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable2 = mathException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable6, objArray7);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable4, objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) '#', localizable2, objArray7);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException10);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
        double double3 = normalDistributionImpl2.getMean();
        double double6 = normalDistributionImpl2.cumulativeProbability((double) (short) -1, 3.207810091467445d);
        double double7 = normalDistributionImpl2.getStandardDeviation();
        double double8 = normalDistributionImpl2.getStandardDeviation();
        normalDistributionImpl2.reseedRandomGenerator(0L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.544137102816975d + "'", double3 == 7.544137102816975d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08656193300300513d + "'", double6 == 0.08656193300300513d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.246216406046493d + "'", double7 == 3.246216406046493d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.246216406046493d + "'", double8 == 3.246216406046493d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.9969748643467198d, 7.421477398171811d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9969748643467199d + "'", double2 == 0.9969748643467199d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        double double1 = org.apache.commons.math.util.FastMath.abs(3.026562968104169d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.026562968104169d + "'", double1 == 3.026562968104169d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.017144266906994998d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.056435261286893d + "'", double1 == 4.056435261286893d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        long long1 = org.apache.commons.math.util.FastMath.round(2.126048628120582d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable1, objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = maxIterationsExceededException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = maxIterationsExceededException3.getSpecificPattern();
        int int6 = maxIterationsExceededException3.getMaxIterations();
        org.apache.commons.math.exception.util.Localizable localizable7 = maxIterationsExceededException3.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNull(localizable7);
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test064");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        double double11 = randomDataImpl0.nextCauchy(2.99822295029797d, 7.8726391065033505d);
//        int int14 = randomDataImpl0.nextSecureInt(10, 32);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl18 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.5772156649015329d, 0.5403023058681398d, 2.6508641820894225d);
//        double double20 = normalDistributionImpl18.cumulativeProbability(5.298342365610589d);
//        double double21 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl18);
//        double double22 = normalDistributionImpl18.sample();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.937902728712382d + "'", double3 == 2.937902728712382d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 5.597469078647064d + "'", double6 == 5.597469078647064d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2L + "'", long8 == 2L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 34.5319400310345d + "'", double11 == 34.5319400310345d);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 20 + "'", int14 == 20);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.5772156649015329d + "'", double21 == 0.5772156649015329d);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.2432461722919452d + "'", double22 == 1.2432461722919452d);
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.2072967164301227d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(Double.NaN, 1.1995416045736986d);
        double double4 = normalDistributionImpl2.cumulativeProbability(11.104025517642276d);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test068");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double5 = randomDataImpl0.nextExponential(Double.NaN);
//        double double8 = randomDataImpl0.nextCauchy(0.019691932154573932d, 0.9969748643467198d);
//        randomDataImpl0.reSeed();
//        try {
//            int[] intArray12 = randomDataImpl0.nextPermutation((int) ' ', (int) '#');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 35 is larger than the maximum (32): permutation size (35) exceeds permuation domain (32)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.9491918772518946d + "'", double3 == 2.9491918772518946d);
//        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-0.162143292761104d) + "'", double8 == (-0.162143292761104d));
//    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2.688167673504861d, (java.lang.Number) 1.5430806348152437d, false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 2.0198227150790538d, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException5.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException11.addSuppressed((java.lang.Throwable) numberIsTooSmallException16);
        java.lang.Number number18 = numberIsTooLargeException11.getMax();
        org.apache.commons.math.exception.util.Localizable localizable19 = numberIsTooLargeException11.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException(localizable19, (java.lang.Number) (-6.816718961678583d), (java.lang.Number) 3.20459618189556d, (java.lang.Number) 5.169076857913174d);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable24, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        boolean boolean29 = numberIsTooSmallException28.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable30 = numberIsTooSmallException28.getSpecificPattern();
        java.lang.Object[] objArray31 = numberIsTooSmallException28.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException(1, localizable19, objArray31);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException34 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        boolean boolean35 = notStrictlyPositiveException34.getBoundIsAllowed();
        java.lang.Number number36 = notStrictlyPositiveException34.getMin();
        org.apache.commons.math.exception.util.Localizable localizable37 = notStrictlyPositiveException34.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        java.lang.Object[] objArray40 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(localizable39, objArray40);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable37, localizable38, objArray40);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException43 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable19, objArray40);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 2.718281828459045d + "'", number18.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNull(localizable30);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 0 + "'", number36.equals(0));
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray40);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(387632512);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.9265751394698551d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, objArray7);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("3d787e85ce", objArray7);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("", objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException(123, "a941d16cb1", objArray7);
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 21);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5232132235179132d + "'", double1 == 1.5232132235179132d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException7.addSuppressed((java.lang.Throwable) numberIsTooSmallException12);
        java.lang.Number number14 = numberIsTooLargeException7.getMax();
        org.apache.commons.math.exception.util.Localizable localizable15 = numberIsTooLargeException7.getGeneralPattern();
        java.lang.Number number17 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable15, (java.lang.Number) (-0.46046391868746567d), number17, false);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable23, objArray24);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, localizable21, objArray24);
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException(localizable15, objArray24);
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException1, "da087b827c", objArray24);
        boolean boolean29 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 2.718281828459045d + "'", number14.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        double double1 = org.apache.commons.math.util.FastMath.asinh(198.99499987499382d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.98643319194182d + "'", double1 == 5.98643319194182d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException(localizable0, objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = convergenceException2.getGeneralPattern();
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException8.addSuppressed((java.lang.Throwable) numberIsTooSmallException13);
        java.lang.Number number15 = numberIsTooLargeException8.getMax();
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooLargeException8.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException20 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException25 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable21, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException20.addSuppressed((java.lang.Throwable) numberIsTooSmallException25);
        java.lang.Number number27 = numberIsTooLargeException20.getMax();
        org.apache.commons.math.exception.util.Localizable localizable28 = numberIsTooLargeException20.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable29, objArray32);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, objArray32);
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable16, objArray32);
        java.lang.Object[] objArray40 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException("hi!", objArray40);
        java.lang.Class<?> wildcardClass42 = objArray40.getClass();
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException(localizable16, objArray40);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException45 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 10);
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException();
        notStrictlyPositiveException45.addSuppressed((java.lang.Throwable) mathException46);
        org.apache.commons.math.exception.util.Localizable localizable48 = mathException46.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        java.lang.Object[] objArray52 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException53 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable49, objArray52);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException53);
        java.lang.Throwable throwable58 = null;
        org.apache.commons.math.exception.util.Localizable localizable60 = null;
        org.apache.commons.math.exception.util.Localizable localizable62 = null;
        java.lang.Object[] objArray65 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException66 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable62, objArray65);
        org.apache.commons.math.MathException mathException67 = new org.apache.commons.math.MathException("3d787e85ce", objArray65);
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException(localizable60, objArray65);
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException(throwable58, "org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)", objArray65);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException70 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100, "76b6a5e15f", objArray65);
        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalArgumentException53, "28fc800164", objArray65);
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException(localizable48, objArray65);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException76 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable48, (java.lang.Number) 0.9026593890743758d, (java.lang.Number) 2.9898176418264275d, false);
        java.lang.Throwable throwable77 = null;
        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException(throwable77);
        org.apache.commons.math.exception.util.Localizable localizable79 = null;
        java.lang.Object[] objArray84 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException85 = new org.apache.commons.math.MathException("hi!", objArray84);
        java.lang.Class<?> wildcardClass86 = objArray84.getClass();
        org.apache.commons.math.MathException mathException87 = new org.apache.commons.math.MathException(throwable77, localizable79, objArray84);
        org.apache.commons.math.MathException mathException88 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException43, localizable48, objArray84);
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 2.718281828459045d + "'", number15.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 2.718281828459045d + "'", number27.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable28.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertTrue("'" + localizable48 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable48.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(objArray84);
        org.junit.Assert.assertNotNull(wildcardClass86);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 10L, 10.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test079");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        java.lang.String str3 = randomDataImpl0.nextHexString((int) (short) 1);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double8 = normalDistributionImpl7.getMean();
//        double double10 = normalDistributionImpl7.density((double) (short) 1);
//        double double11 = normalDistributionImpl7.sample();
//        double[] doubleArray13 = normalDistributionImpl7.sample((int) (short) 10);
//        double double16 = normalDistributionImpl7.cumulativeProbability(2.0198227150790538d, (double) 100);
//        double double17 = normalDistributionImpl7.sample();
//        double double18 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        int int22 = randomDataImpl0.nextHypergeometric((int) (byte) 100, (int) (short) 1, (int) (short) 0);
//        java.lang.Class<?> wildcardClass23 = randomDataImpl0.getClass();
//        randomDataImpl0.reSeedSecure(111L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "7" + "'", str3.equals("7"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 7.544137102816975d + "'", double8 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.01610846091529747d + "'", double10 == 0.01610846091529747d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 5.923769104490098d + "'", double11 == 5.923769104490098d);
//        org.junit.Assert.assertNotNull(doubleArray13);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.9556007738814948d + "'", double16 == 0.9556007738814948d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 9.647953145086245d + "'", double17 == 9.647953145086245d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.715845934149969d + "'", double18 == 1.715845934149969d);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.34051064246566165d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (long) 30);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 35);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 35L + "'", long1 == 35L);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 100.0d, (java.lang.Number) 10, false);
        java.lang.Object[] objArray5 = numberIsTooSmallException4.getArguments();
        org.junit.Assert.assertNotNull(objArray5);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 40.33834359014497d, (java.lang.Number) (-1.5707963267948966d), (java.lang.Number) 0.8560818335760244d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 22025.465794806718d, (java.lang.Number) 100, (java.lang.Number) 1.0E-9d);
        java.lang.Number number4 = outOfRangeException3.getLo();
        java.lang.Number number5 = outOfRangeException3.getHi();
        java.lang.Number number6 = outOfRangeException3.getHi();
        org.apache.commons.math.exception.util.Localizable localizable7 = outOfRangeException3.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100 + "'", number4.equals(100));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.0E-9d + "'", number5.equals(1.0E-9d));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.0E-9d + "'", number6.equals(1.0E-9d));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.9994474734617785d), (java.lang.Number) 0.8590238068419813d, false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.03225555245128925d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.032249959518364485d + "'", double1 == 0.032249959518364485d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 10, 35L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(8.403128789365441d, 2.735241249684354d, 7.846662424500936d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 572.9577951308232d, (java.lang.Number) 0.5180674978483826d, (java.lang.Number) 0.9969748643467199d);
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test092");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        java.lang.String str3 = randomDataImpl0.nextHexString((int) (short) 1);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double8 = normalDistributionImpl7.getMean();
//        double double10 = normalDistributionImpl7.density((double) (short) 1);
//        double double11 = normalDistributionImpl7.sample();
//        double[] doubleArray13 = normalDistributionImpl7.sample((int) (short) 10);
//        double double16 = normalDistributionImpl7.cumulativeProbability(2.0198227150790538d, (double) 100);
//        double double17 = normalDistributionImpl7.sample();
//        double double18 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        int int22 = randomDataImpl0.nextHypergeometric((int) (byte) 100, (int) (short) 1, (int) (short) 0);
//        try {
//            randomDataImpl0.setSecureAlgorithm("b0f617732c", "5");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 5");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a" + "'", str3.equals("a"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 7.544137102816975d + "'", double8 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.01610846091529747d + "'", double10 == 0.01610846091529747d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 11.606779594979683d + "'", double11 == 11.606779594979683d);
//        org.junit.Assert.assertNotNull(doubleArray13);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.9556007738814948d + "'", double16 == 0.9556007738814948d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 7.291485392920092d + "'", double17 == 7.291485392920092d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 14.108790724723887d + "'", double18 == 14.108790724723887d);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(3.449231118107891d, (double) 28, 4.44356704113464d, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: Continued fraction convergents failed to converge (in less than 28 iterations) for value {1}");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 21);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.58257569495584d + "'", double1 == 4.58257569495584d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 4.097470561084089d, (java.lang.Number) 2.5139994585534726d, (java.lang.Number) 7.164591543681963d);
        org.apache.commons.math.exception.util.Localizable localizable4 = outOfRangeException3.getGeneralPattern();
        java.lang.Number number5 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 7.164591543681963d + "'", number5.equals(7.164591543681963d));
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test096");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        int int9 = randomDataImpl0.nextPascal(10, 0.0d);
//        try {
//            long long12 = randomDataImpl0.nextSecureLong((long) 0, 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (0): lower bound (0) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.421787695858936d + "'", double3 == 3.421787695858936d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.282601611601195d + "'", double6 == 3.282601611601195d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2147483647 + "'", int9 == 2147483647);
//    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test097");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double5 = randomDataImpl0.nextExponential(Double.NaN);
//        double double8 = randomDataImpl0.nextUniform(0.9969748643467198d, 6.798056507791588d);
//        randomDataImpl0.reSeedSecure(100L);
//        double double12 = randomDataImpl0.nextT(1.432116947405487d);
//        int int15 = randomDataImpl0.nextZipf(10, 3.081725078478352d);
//        try {
//            double double18 = randomDataImpl0.nextWeibull(0.0d, 0.6216710141531901d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): shape (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.407081913980833d + "'", double3 == 3.407081913980833d);
//        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.9103323029645076d + "'", double8 == 3.9103323029645076d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-0.014075980070429159d) + "'", double12 == (-0.014075980070429159d));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.5764035919569829d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6143207452169404d + "'", double1 == 0.6143207452169404d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException5.addSuppressed((java.lang.Throwable) numberIsTooSmallException10);
        java.lang.Number number12 = numberIsTooLargeException5.getMax();
        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooLargeException5.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException(localizable13, (java.lang.Number) (-6.816718961678583d), (java.lang.Number) 3.20459618189556d, (java.lang.Number) 5.169076857913174d);
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) outOfRangeException17);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException1);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 2.718281828459045d + "'", number12.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test100");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        int int4 = randomDataImpl0.nextInt(0, (int) (short) 1);
//        java.lang.String str6 = randomDataImpl0.nextSecureHexString(18);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "a8342ac9b04b49a40c" + "'", str6.equals("a8342ac9b04b49a40c"));
//    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test101");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        double double11 = randomDataImpl0.nextCauchy(4.600161852571429d, 2.6508641820894225d);
//        randomDataImpl0.reSeedSecure((long) (byte) 0);
//        double double16 = randomDataImpl0.nextGamma(3.550128012953764d, 10.569181794623525d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl19 = new org.apache.commons.math.distribution.NormalDistributionImpl(2.604389633748831d, 3.1838110482628132d);
//        double double20 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl19);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl21 = new org.apache.commons.math.random.RandomDataImpl();
//        double double24 = randomDataImpl21.nextWeibull((double) 10, 2.99822295029797d);
//        double double27 = randomDataImpl21.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long29 = randomDataImpl21.nextPoisson(0.7853981633974483d);
//        double double32 = randomDataImpl21.nextCauchy(2.99822295029797d, 7.8726391065033505d);
//        int int35 = randomDataImpl21.nextSecureInt(10, 32);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl39 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.5772156649015329d, 0.5403023058681398d, 2.6508641820894225d);
//        double double41 = normalDistributionImpl39.cumulativeProbability(5.298342365610589d);
//        double double42 = randomDataImpl21.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl39);
//        double double43 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl39);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.454014151010072d + "'", double3 == 3.454014151010072d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 5.36417277326742d + "'", double6 == 5.36417277326742d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2L + "'", long8 == 2L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 26.29328525265785d + "'", double11 == 26.29328525265785d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 28.751822217962214d + "'", double16 == 28.751822217962214d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.3258453440884944d + "'", double20 == 0.3258453440884944d);
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 3.452638893786545d + "'", double24 == 3.452638893786545d);
//        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 2.2996845100097607d + "'", double27 == 2.2996845100097607d);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
//        org.junit.Assert.assertTrue("'" + double32 + "' != '" + (-3.7345578885760555d) + "'", double32 == (-3.7345578885760555d));
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 32 + "'", int35 == 32);
//        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.5772156649015329d + "'", double42 == 0.5772156649015329d);
//        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.5772156649015329d + "'", double43 == 0.5772156649015329d);
//    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test102");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        double double11 = randomDataImpl0.nextCauchy((-21.46708637494148d), (double) 19);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution12 = null;
//        try {
//            int int13 = randomDataImpl0.nextInversionDeviate(integerDistribution12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.4577699849531145d + "'", double3 == 3.4577699849531145d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.863513188867044d + "'", double6 == 2.863513188867044d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-10.253761403906957d) + "'", double11 == (-10.253761403906957d));
//    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test103");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double5 = randomDataImpl0.nextExponential(Double.NaN);
//        double double8 = randomDataImpl0.nextUniform(0.9969748643467198d, 6.798056507791588d);
//        randomDataImpl0.reSeedSecure(100L);
//        int int13 = randomDataImpl0.nextZipf((int) '#', 2.0198227150790538d);
//        double double15 = randomDataImpl0.nextChiSquare(0.9970011109715183d);
//        long long18 = randomDataImpl0.nextSecureLong((long) (byte) -1, 0L);
//        int int21 = randomDataImpl0.nextZipf(20, 4.9E-324d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.4447344218459777d + "'", double3 == 3.4447344218459777d);
//        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.599330994072959d + "'", double8 == 4.599330994072959d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.09788459431897559d + "'", double15 == 0.09788459431897559d);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1L) + "'", long18 == (-1L));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        double double1 = org.apache.commons.math.util.FastMath.exp((-0.2018528129723343d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8172152025672164d + "'", double1 == 0.8172152025672164d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.3258453440884944d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException("hi!", objArray6);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray6);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException8);
        java.lang.Object[] objArray10 = mathException9.getArguments();
        java.lang.Class<?> wildcardClass11 = mathException9.getClass();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        boolean boolean15 = notStrictlyPositiveException14.getBoundIsAllowed();
        java.lang.Number number16 = notStrictlyPositiveException14.getMin();
        org.apache.commons.math.exception.util.Localizable localizable17 = notStrictlyPositiveException14.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException(localizable19, objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, localizable18, objArray20);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException9, "", objArray20);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 0 + "'", number16.equals(0));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray20);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(4.447426064297152d, 4.6594147143427955d, 3.199272643922325d, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (0) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        java.lang.Number number10 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooLargeException3.getGeneralPattern();
        java.lang.Number number13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) (-0.46046391868746567d), number13, false);
        java.lang.Throwable throwable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray23 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, objArray23);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException("3d787e85ce", objArray23);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException(localizable18, objArray23);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException(throwable16, "org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)", objArray23);
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException(localizable11, objArray23);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) (-1.5707963267948966d), (java.lang.Number) 2.735241249684354d, (java.lang.Number) 1.7692003247117487d);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 2.718281828459045d + "'", number10.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray23);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        java.lang.Number number3 = notStrictlyPositiveException1.getMin();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException(localizable6, objArray7);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable5, objArray7);
        java.lang.Throwable[] throwableArray10 = mathIllegalArgumentException9.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(throwableArray10);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooLargeException3.getSpecificPattern();
        java.lang.Number number11 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertNull(localizable10);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 2.718281828459045d + "'", number11.equals(2.718281828459045d));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(1.6521730507294445d, 3.5133004999316397d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.08799612325920542d + "'", double2 == 0.08799612325920542d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.6898558835492172d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        java.lang.String str3 = randomDataImpl0.nextHexString((int) (short) 1);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double8 = normalDistributionImpl7.getMean();
//        double double10 = normalDistributionImpl7.density((double) (short) 1);
//        double double11 = normalDistributionImpl7.sample();
//        double[] doubleArray13 = normalDistributionImpl7.sample((int) (short) 10);
//        double double16 = normalDistributionImpl7.cumulativeProbability(2.0198227150790538d, (double) 100);
//        double double17 = normalDistributionImpl7.sample();
//        double double18 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        int int22 = randomDataImpl0.nextHypergeometric((int) (byte) 100, (int) (short) 1, (int) (short) 0);
//        randomDataImpl0.reSeedSecure(52L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "d" + "'", str3.equals("d"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 7.544137102816975d + "'", double8 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.01610846091529747d + "'", double10 == 0.01610846091529747d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 5.33880213909624d + "'", double11 == 5.33880213909624d);
//        org.junit.Assert.assertNotNull(doubleArray13);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.9556007738814948d + "'", double16 == 0.9556007738814948d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 6.694072288474383d + "'", double17 == 6.694072288474383d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 4.884647329734806d + "'", double18 == 4.884647329734806d);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test114");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double5 = randomDataImpl0.nextExponential(Double.NaN);
//        double double8 = randomDataImpl0.nextGamma((double) (byte) 1, (double) 10.0f);
//        double double11 = randomDataImpl0.nextF(8.946773076383243d, (double) 'a');
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.579123598320471d + "'", double3 == 2.579123598320471d);
//        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.485003668205749d + "'", double8 == 2.485003668205749d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.4694765750314672d + "'", double11 == 0.4694765750314672d);
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 3.87632512E8f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.588420195597621d + "'", double1 == 8.588420195597621d);
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        java.lang.String str3 = randomDataImpl0.nextHexString((int) (short) 1);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double[] doubleArray6 = normalDistributionImpl4.sample((int) '#');
//        double double7 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        double double10 = randomDataImpl0.nextF(0.01610846091529747d, 4.097470561084089d);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "e" + "'", str3.equals("e"));
//        org.junit.Assert.assertNotNull(doubleArray6);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.10331777129782314d) + "'", double7 == (-0.10331777129782314d));
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0546426813733944E-9d + "'", double10 == 1.0546426813733944E-9d);
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        double double1 = org.apache.commons.math.util.FastMath.sin(4.948602600542174d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9722310422658634d) + "'", double1 == (-0.9722310422658634d));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(30);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        java.lang.Number number10 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray15);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray15);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 0.0015107907377931822d, (java.lang.Number) (-0.5961722400471147d), true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 32L);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException27 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) 0.0f, (java.lang.Number) 1.246879715040882d, true);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 2.718281828459045d + "'", number10.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray15);
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test120");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        java.lang.String str3 = randomDataImpl0.nextHexString((int) (short) 1);
//        long long5 = randomDataImpl0.nextPoisson((double) (byte) 100);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution6 = null;
//        try {
//            int int7 = randomDataImpl0.nextInversionDeviate(integerDistribution6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "6" + "'", str3.equals("6"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 123L + "'", long5 == 123L);
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test122");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        java.lang.String str3 = randomDataImpl0.nextHexString((int) (short) 1);
//        int int6 = randomDataImpl0.nextSecureInt(21, 100);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "6" + "'", str3.equals("6"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.5263725054070643d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test124");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.5772156649015329d, 0.5403023058681398d, 2.6508641820894225d);
//        double double5 = normalDistributionImpl3.density(0.0d);
//        double double6 = normalDistributionImpl3.sample();
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.4172934084748632d + "'", double5 == 0.4172934084748632d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.48184047903494054d + "'", double6 == 0.48184047903494054d);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        java.lang.Number number10 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) (-6.816718961678583d), (java.lang.Number) 3.20459618189556d, (java.lang.Number) 5.169076857913174d);
        java.lang.Number number16 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, number16, (java.lang.Number) 12.236072099935386d, (java.lang.Number) 0.017453292519943295d);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) (byte) 100, (java.lang.Number) 7.2766636539440555d, false);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 2.718281828459045d + "'", number10.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test126");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        randomDataImpl0.reSeed((long) 123);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.1969367550226755d + "'", double3 == 2.1969367550226755d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.569068852394782d + "'", double6 == 2.569068852394782d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 8.221182492214849d + "'", double12 == 8.221182492214849d);
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.3258453440884944d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(2.9647942139794674d, (-57.29577951308232d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -57.296 is smaller than, or equal to, the minimum (0): standard deviation (-57.296)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test129");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        double double8 = randomDataImpl0.nextT(2.758443714131805d);
//        try {
//            int[] intArray11 = randomDataImpl0.nextPermutation((-1), 59);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 59 is larger than the maximum (-1): permutation size (59) exceeds permuation domain (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.022466850175833d + "'", double3 == 3.022466850175833d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.175704217931374d + "'", double6 == 2.175704217931374d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.8238055881285128d + "'", double8 == 0.8238055881285128d);
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(2.758443714131805d, 0.6511961857760066d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.04289680733924889d + "'", double2 == 0.04289680733924889d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException9);
        java.lang.Number number11 = numberIsTooLargeException4.getMax();
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Number number14 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, (java.lang.Number) (-0.46046391868746567d), number14, false);
        java.lang.Object[] objArray21 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray21);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException(localizable12, objArray21);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("9913e0bd71", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable25 = convergenceException24.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException29 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException34 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable30, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException29.addSuppressed((java.lang.Throwable) numberIsTooSmallException34);
        java.lang.Number number36 = numberIsTooLargeException29.getMax();
        org.apache.commons.math.exception.util.Localizable localizable37 = numberIsTooLargeException29.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        java.lang.Object[] objArray41 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable38, objArray41);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException43 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable37, objArray41);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException47 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable37, (java.lang.Number) 0.0015107907377931822d, (java.lang.Number) (-0.5961722400471147d), true);
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        java.lang.Object[] objArray54 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException("hi!", objArray54);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable48, localizable49, objArray54);
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException56);
        java.lang.Object[] objArray58 = mathException57.getArguments();
        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException(localizable37, objArray58);
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException(localizable25, objArray58);
        java.lang.Object[] objArray61 = mathException60.getArguments();
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 2.718281828459045d + "'", number11.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(localizable25);
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 2.718281828459045d + "'", number36.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(objArray61);
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test132");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        double double11 = randomDataImpl0.nextCauchy(2.99822295029797d, 7.8726391065033505d);
//        int int14 = randomDataImpl0.nextSecureInt(10, 32);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution15 = null;
//        try {
//            int int16 = randomDataImpl0.nextInversionDeviate(integerDistribution15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.9943826950853834d + "'", double3 == 2.9943826950853834d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.9209603813968954d + "'", double6 == 1.9209603813968954d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0655852686151235d + "'", double11 == 4.0655852686151235d);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 16 + "'", int14 == 16);
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(11.745934288778123d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08886259462063964d + "'", double1 == 0.08886259462063964d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.9969748643467199d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.710071082755576d + "'", double1 == 1.710071082755576d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException(throwable0);
        java.lang.Class<?> wildcardClass2 = convergenceException1.getClass();
        org.apache.commons.math.exception.util.Localizable localizable3 = convergenceException1.getGeneralPattern();
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(2);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        double double1 = org.apache.commons.math.util.FastMath.tanh(5.430377658846085d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999616066900643d + "'", double1 == 0.9999616066900643d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 2.0198227150790538d, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable10, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException9.addSuppressed((java.lang.Throwable) numberIsTooSmallException14);
        java.lang.Number number16 = numberIsTooLargeException9.getMax();
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooLargeException9.getGeneralPattern();
        java.lang.Number number19 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) (-0.46046391868746567d), number19, false);
        java.lang.Object[] objArray26 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException("hi!", objArray26);
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException(localizable17, objArray26);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Throwable throwable30 = null;
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException("hi!", objArray38);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable32, localizable33, objArray38);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(throwable30, "4885561af9", objArray38);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, localizable29, objArray38);
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException47 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable43, (java.lang.Number) 2.0198227150790538d, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException47);
        org.apache.commons.math.exception.util.Localizable localizable51 = null;
        java.lang.Object[] objArray54 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException55 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable51, objArray54);
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException("3d787e85ce", objArray54);
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException48, "fd4ecaf23f", objArray54);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException63 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable64 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException68 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable64, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException63.addSuppressed((java.lang.Throwable) numberIsTooSmallException68);
        java.lang.Number number70 = numberIsTooLargeException63.getMax();
        org.apache.commons.math.exception.util.Localizable localizable71 = numberIsTooLargeException63.getGeneralPattern();
        java.lang.Number number73 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException75 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable71, (java.lang.Number) (-0.46046391868746567d), number73, false);
        java.lang.Object[] objArray80 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException81 = new org.apache.commons.math.MathException("hi!", objArray80);
        org.apache.commons.math.ConvergenceException convergenceException82 = new org.apache.commons.math.ConvergenceException(localizable71, objArray80);
        org.apache.commons.math.ConvergenceException convergenceException83 = new org.apache.commons.math.ConvergenceException("9913e0bd71", objArray80);
        org.apache.commons.math.ConvergenceException convergenceException84 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException48, "a", objArray80);
        org.apache.commons.math.MathException mathException85 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException4, localizable17, objArray80);
        org.apache.commons.math.exception.util.Localizable localizable86 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException90 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable86, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        boolean boolean91 = numberIsTooSmallException90.getBoundIsAllowed();
        java.lang.Number number92 = numberIsTooSmallException90.getMin();
        org.apache.commons.math.exception.util.Localizable localizable93 = numberIsTooSmallException90.getSpecificPattern();
        java.lang.Number number94 = numberIsTooSmallException90.getArgument();
        java.lang.Object[] objArray95 = numberIsTooSmallException90.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException96 = new org.apache.commons.math.ConvergenceException(localizable17, objArray95);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 2.718281828459045d + "'", number16.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertTrue("'" + number70 + "' != '" + 2.718281828459045d + "'", number70.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable71 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable71.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray80);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
        org.junit.Assert.assertTrue("'" + number92 + "' != '" + 22025.465794806718d + "'", number92.equals(22025.465794806718d));
        org.junit.Assert.assertNull(localizable93);
        org.junit.Assert.assertTrue("'" + number94 + "' != '" + 1L + "'", number94.equals(1L));
        org.junit.Assert.assertNotNull(objArray95);
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test139");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        randomDataImpl0.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.181459754860501d + "'", double3 == 3.181459754860501d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 6.057527014611798d + "'", double6 == 6.057527014611798d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        double double2 = org.apache.commons.math.util.FastMath.min(8.643285932567796d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(6.675641250747938d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1615758743811201d + "'", double1 == 0.1615758743811201d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        double double1 = org.apache.commons.math.util.FastMath.floor(4.059645095551947d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 0.9212587981384309d, (java.lang.Number) 2.7117670327966574d, (java.lang.Number) 18.642803738194953d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 2.710071082755576d, (java.lang.Number) (-0.5772156677920679d), false);
        java.lang.String str4 = numberIsTooLargeException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: 2.71 is larger than, or equal to, the maximum (-0.577)" + "'", str4.equals("org.apache.commons.math.exception.NumberIsTooLargeException: 2.71 is larger than, or equal to, the maximum (-0.577)"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(177.4296412225003d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.096731429964887d + "'", double1 == 3.096731429964887d);
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test146");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double3 = normalDistributionImpl2.getMean();
//        double double6 = normalDistributionImpl2.cumulativeProbability((double) (short) -1, 3.207810091467445d);
//        double double7 = normalDistributionImpl2.sample();
//        double double9 = normalDistributionImpl2.cumulativeProbability(2.393527778424103d);
//        double double11 = normalDistributionImpl2.cumulativeProbability(2.744220474423504d);
//        double double12 = normalDistributionImpl2.getStandardDeviation();
//        double double13 = normalDistributionImpl2.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.544137102816975d + "'", double3 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08656193300300513d + "'", double6 == 0.08656193300300513d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 8.042201189804961d + "'", double7 == 8.042201189804961d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.056295965999692776d + "'", double9 == 0.056295965999692776d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.06962111172915636d + "'", double11 == 0.06962111172915636d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.246216406046493d + "'", double12 == 3.246216406046493d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 3.246216406046493d + "'", double13 == 3.246216406046493d);
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(8.643285932567796d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.12264703694299059d + "'", double1 == 0.12264703694299059d);
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test148");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        double double11 = randomDataImpl0.nextGaussian(7.112156832451546d, 4.600161852571429d);
//        randomDataImpl0.reSeed();
//        long long15 = randomDataImpl0.nextSecureLong((long) 11, (long) (short) 100);
//        double double18 = randomDataImpl0.nextUniform(0.9545562608278262d, 12.236072099935386d);
//        try {
//            double double21 = randomDataImpl0.nextF(2.712952382754662d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.2035284064600495d + "'", double3 == 3.2035284064600495d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.8561739315649157d + "'", double6 == 1.8561739315649157d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.6639535709285154d) + "'", double11 == (-1.6639535709285154d));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 44L + "'", long15 == 44L);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 10.616781589720802d + "'", double18 == 10.616781589720802d);
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1);
        int int2 = maxIterationsExceededException1.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException(throwable0);
        java.lang.Class<?> wildcardClass2 = convergenceException1.getClass();
        org.apache.commons.math.exception.util.Localizable localizable3 = convergenceException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = convergenceException1.getSpecificPattern();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable4);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        double double1 = org.apache.commons.math.util.FastMath.floor(2.8300769035416784d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test152");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextF(2.718281828459045d, (double) 100);
//        long long6 = randomDataImpl0.nextLong((long) 0, (long) (short) 1);
//        long long8 = randomDataImpl0.nextPoisson(0.2522737922403927d);
//        randomDataImpl0.reSeed();
//        int int13 = randomDataImpl0.nextHypergeometric(2147483647, 387632512, 0);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.8745734993896739d + "'", double3 == 1.8745734993896739d);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.04289680733924889d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 10);
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException1);
        boolean boolean3 = notStrictlyPositiveException1.getBoundIsAllowed();
        java.lang.Number number4 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(6.966171178609635d, 0.0d, 0.0d, 35);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        java.lang.Number number10 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooLargeException3.getGeneralPattern();
        java.lang.Number number13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) (-0.46046391868746567d), number13, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) (short) 1, (java.lang.Number) 4.097470561084089d, (java.lang.Number) 1.110636508023106d);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 1.5607966601082315d);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException25 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) 387632507, (java.lang.Number) 4.70501893323266d, false);
        java.lang.Throwable throwable26 = null;
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Object[] objArray30 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException(localizable29, objArray30);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException("", objArray30);
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException(throwable26, "b0f617732c", objArray30);
        numberIsTooSmallException25.addSuppressed((java.lang.Throwable) convergenceException33);
        java.lang.String str35 = convergenceException33.getPattern();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 2.718281828459045d + "'", number10.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "b0f617732c" + "'", str35.equals("b0f617732c"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(5.298342365610589d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 303.5726559648473d + "'", double1 == 303.5726559648473d);
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test158");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextF(2.718281828459045d, (double) 100);
//        long long6 = randomDataImpl0.nextLong((long) 0, (long) (short) 1);
//        try {
//            int int10 = randomDataImpl0.nextHypergeometric((-1), (int) (short) 1, 59);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): population size (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.4855418961163869d + "'", double3 == 1.4855418961163869d);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        double double1 = org.apache.commons.math.util.FastMath.expm1(4.945510016043891d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 139.54251151156927d + "'", double1 == 139.54251151156927d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        double double1 = org.apache.commons.math.util.FastMath.acos(6.057527014611798d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
        double double4 = normalDistributionImpl2.inverseCumulativeProbability(0.5403023058681398d);
        normalDistributionImpl2.reseedRandomGenerator(0L);
        double double7 = normalDistributionImpl2.getMean();
        double double8 = normalDistributionImpl2.sample();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.8726391065033505d + "'", double4 == 7.8726391065033505d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 7.544137102816975d + "'", double7 == 7.544137102816975d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.149333100721371d + "'", double8 == 10.149333100721371d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        java.lang.Number number10 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray15);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray15);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 0.0015107907377931822d, (java.lang.Number) (-0.5961722400471147d), true);
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException("hi!", objArray28);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, localizable23, objArray28);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException30);
        java.lang.Object[] objArray32 = mathException31.getArguments();
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException(localizable11, objArray32);
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException33);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 2.718281828459045d + "'", number10.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray32);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        int int2 = org.apache.commons.math.util.FastMath.min(1, 19);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        double double1 = org.apache.commons.math.util.FastMath.ceil(3.1804374774983803d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        java.lang.Number number10 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooLargeException3.getGeneralPattern();
        java.lang.Number number13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) (-0.46046391868746567d), number13, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) 3.081725078478352d, (java.lang.Number) (-1.0d), true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 3.207810091467445d);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 3.143276701259362d);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException25 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 10);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException();
        notStrictlyPositiveException25.addSuppressed((java.lang.Throwable) mathException26);
        org.apache.commons.math.exception.util.Localizable localizable28 = mathException26.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException32 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable33, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException32.addSuppressed((java.lang.Throwable) numberIsTooSmallException37);
        java.lang.Number number39 = numberIsTooLargeException32.getMax();
        org.apache.commons.math.exception.util.Localizable localizable40 = numberIsTooLargeException32.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException42 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable40, (java.lang.Number) 100L);
        java.lang.Object[] objArray47 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException("hi!", objArray47);
        java.lang.Class<?> wildcardClass49 = objArray47.getClass();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, localizable40, objArray47);
        java.lang.Number number52 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException54 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable40, (java.lang.Number) 13.166275598782555d, number52, true);
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable56 = mathException55.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        java.lang.Object[] objArray62 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable59, objArray62);
        org.apache.commons.math.MathException mathException64 = new org.apache.commons.math.MathException("3d787e85ce", objArray62);
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)", objArray62);
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException54, localizable56, objArray62);
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException(localizable11, objArray62);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 2.718281828459045d + "'", number10.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + localizable28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable28.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + 2.718281828459045d + "'", number39.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable40.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertTrue("'" + localizable56 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable56.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray62);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.9604209204271249d, (java.lang.Number) 0L, (java.lang.Number) 0.2382891617659135d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException9);
        java.lang.Number number11 = numberIsTooLargeException4.getMax();
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Number number14 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, (java.lang.Number) (-0.46046391868746567d), number14, false);
        java.lang.Object[] objArray21 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray21);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException(localizable12, objArray21);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("9913e0bd71", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable25 = convergenceException24.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException(localizable27, objArray28);
        org.apache.commons.math.exception.util.Localizable localizable30 = convergenceException29.getGeneralPattern();
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException29);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException35 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException40 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable36, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException35.addSuppressed((java.lang.Throwable) numberIsTooSmallException40);
        java.lang.Number number42 = numberIsTooLargeException35.getMax();
        org.apache.commons.math.exception.util.Localizable localizable43 = numberIsTooLargeException35.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException47 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException52 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable48, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException47.addSuppressed((java.lang.Throwable) numberIsTooSmallException52);
        java.lang.Number number54 = numberIsTooLargeException47.getMax();
        org.apache.commons.math.exception.util.Localizable localizable55 = numberIsTooLargeException47.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        java.lang.Object[] objArray59 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException60 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable56, objArray59);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException61 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable55, objArray59);
        org.apache.commons.math.MathException mathException62 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException29, localizable43, objArray59);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable25, localizable26, objArray59);
        org.apache.commons.math.exception.util.Localizable localizable64 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException68 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable64, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        boolean boolean69 = numberIsTooSmallException68.getBoundIsAllowed();
        java.lang.Number number70 = numberIsTooSmallException68.getMin();
        org.apache.commons.math.exception.util.Localizable localizable71 = numberIsTooSmallException68.getSpecificPattern();
        java.lang.Number number72 = numberIsTooSmallException68.getArgument();
        java.lang.Object[] objArray73 = numberIsTooSmallException68.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException74 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable25, objArray73);
        java.lang.Class<?> wildcardClass75 = objArray73.getClass();
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 2.718281828459045d + "'", number11.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(localizable25);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNull(localizable30);
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 2.718281828459045d + "'", number42.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable43.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number54 + "' != '" + 2.718281828459045d + "'", number54.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable55.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + number70 + "' != '" + 22025.465794806718d + "'", number70.equals(22025.465794806718d));
        org.junit.Assert.assertNull(localizable71);
        org.junit.Assert.assertTrue("'" + number72 + "' != '" + 1L + "'", number72.equals(1L));
        org.junit.Assert.assertNotNull(objArray73);
        org.junit.Assert.assertNotNull(wildcardClass75);
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test168");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double3 = normalDistributionImpl2.getMean();
//        double double5 = normalDistributionImpl2.density((double) (short) 1);
//        double double6 = normalDistributionImpl2.sample();
//        double[] doubleArray8 = normalDistributionImpl2.sample((int) (short) 10);
//        double double11 = normalDistributionImpl2.cumulativeProbability(2.0198227150790538d, (double) 100);
//        double double12 = normalDistributionImpl2.sample();
//        try {
//            double[] doubleArray14 = normalDistributionImpl2.sample(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): number of samples (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.544137102816975d + "'", double3 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.01610846091529747d + "'", double5 == 0.01610846091529747d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 6.693776296423431d + "'", double6 == 6.693776296423431d);
//        org.junit.Assert.assertNotNull(doubleArray8);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.9556007738814948d + "'", double11 == 0.9556007738814948d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.6343525053273549d + "'", double12 == 1.6343525053273549d);
//    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test169");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        java.lang.String str3 = randomDataImpl0.nextHexString((int) (short) 1);
//        double double6 = randomDataImpl0.nextGamma(1.8630926212463297d, (double) 1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "7" + "'", str3.equals("7"));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0160451392402108d + "'", double6 == 1.0160451392402108d);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 32L, (java.lang.Number) 32.0d, true);
    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test171");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double5 = randomDataImpl0.nextExponential(Double.NaN);
//        double double8 = randomDataImpl0.nextGamma((double) (byte) 1, (double) 10.0f);
//        randomDataImpl0.reSeedSecure((long) (byte) 100);
//        try {
//            long long13 = randomDataImpl0.nextSecureLong(2L, 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 2 is larger than, or equal to, the maximum (0): lower bound (2) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.106701706349379d + "'", double3 == 2.106701706349379d);
//        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.20204150512333d + "'", double8 == 1.20204150512333d);
//    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(3.3162303076281536d, 0.9101775227561072d, 4.948602600542174d, 35);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.03254746429515247d + "'", double4 == 0.03254746429515247d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        double double2 = org.apache.commons.math.util.FastMath.max(11.104025517642276d, 0.5937799705969213d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11.104025517642276d + "'", double2 == 11.104025517642276d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        double double1 = org.apache.commons.math.util.FastMath.tanh(8.266406443196077d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999998678946032d + "'", double1 == 0.9999998678946032d);
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test175");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        java.lang.String str3 = randomDataImpl0.nextHexString((int) (short) 1);
//        long long5 = randomDataImpl0.nextPoisson((double) (byte) 100);
//        int int8 = randomDataImpl0.nextSecureInt(0, 5);
//        randomDataImpl0.reSeedSecure((long) 925392360);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4" + "'", str3.equals("4"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 83L + "'", long5 == 83L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 2.0198227150790538d, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable10, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException9.addSuppressed((java.lang.Throwable) numberIsTooSmallException14);
        java.lang.Number number16 = numberIsTooLargeException9.getMax();
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooLargeException9.getGeneralPattern();
        java.lang.Number number19 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) (-0.46046391868746567d), number19, false);
        java.lang.Object[] objArray26 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException("hi!", objArray26);
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException(localizable17, objArray26);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Throwable throwable30 = null;
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException("hi!", objArray38);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable32, localizable33, objArray38);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(throwable30, "4885561af9", objArray38);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, localizable29, objArray38);
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException47 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable43, (java.lang.Number) 2.0198227150790538d, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException47);
        org.apache.commons.math.exception.util.Localizable localizable51 = null;
        java.lang.Object[] objArray54 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException55 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable51, objArray54);
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException("3d787e85ce", objArray54);
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException48, "fd4ecaf23f", objArray54);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException63 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable64 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException68 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable64, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException63.addSuppressed((java.lang.Throwable) numberIsTooSmallException68);
        java.lang.Number number70 = numberIsTooLargeException63.getMax();
        org.apache.commons.math.exception.util.Localizable localizable71 = numberIsTooLargeException63.getGeneralPattern();
        java.lang.Number number73 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException75 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable71, (java.lang.Number) (-0.46046391868746567d), number73, false);
        java.lang.Object[] objArray80 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException81 = new org.apache.commons.math.MathException("hi!", objArray80);
        org.apache.commons.math.ConvergenceException convergenceException82 = new org.apache.commons.math.ConvergenceException(localizable71, objArray80);
        org.apache.commons.math.ConvergenceException convergenceException83 = new org.apache.commons.math.ConvergenceException("9913e0bd71", objArray80);
        org.apache.commons.math.ConvergenceException convergenceException84 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException48, "a", objArray80);
        org.apache.commons.math.MathException mathException85 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException4, localizable17, objArray80);
        java.lang.Class<?> wildcardClass86 = localizable17.getClass();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 2.718281828459045d + "'", number16.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertTrue("'" + number70 + "' != '" + 2.718281828459045d + "'", number70.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable71 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable71.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray80);
        org.junit.Assert.assertNotNull(wildcardClass86);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.01026738484769776d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.010267204459686558d + "'", double1 == 0.010267204459686558d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed();
        java.lang.String str3 = randomDataImpl0.nextHexString((int) (short) 1);
        try {
            java.lang.String str5 = randomDataImpl0.nextSecureHexString(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a" + "'", str3.equals("a"));
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test179");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextF(2.718281828459045d, (double) 100);
//        double double5 = randomDataImpl0.nextExponential(6.644876506300128d);
//        double double8 = randomDataImpl0.nextCauchy(2.7809006500430664d, (double) 10L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.117378876003064d + "'", double3 == 4.117378876003064d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.444667918657329d + "'", double5 == 10.444667918657329d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.538901786523918d + "'", double8 == 6.538901786523918d);
//    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        double double1 = org.apache.commons.math.util.FastMath.tan(2.2665426539981497d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1975433264545765d) + "'", double1 == (-1.1975433264545765d));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        java.lang.String str4 = numberIsTooSmallException3.toString();
        java.lang.Object[] objArray5 = numberIsTooSmallException3.getArguments();
        java.lang.Class<?> wildcardClass6 = objArray5.getClass();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (0)" + "'", str4.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        int int2 = org.apache.commons.math.util.FastMath.min((int) '#', 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 2.0198227150790538d, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, (java.lang.Number) 613.3957458749095d, (java.lang.Number) 0.6143207452169404d, (java.lang.Number) 32.0d);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test184");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        java.lang.String str3 = randomDataImpl0.nextHexString((int) (short) 1);
//        long long5 = randomDataImpl0.nextPoisson((double) (byte) 100);
//        int int8 = randomDataImpl0.nextSecureInt(0, 5);
//        try {
//            java.lang.String str10 = randomDataImpl0.nextSecureHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4" + "'", str3.equals("4"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107L + "'", long5 == 107L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
//    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException6.addSuppressed((java.lang.Throwable) numberIsTooSmallException11);
        java.lang.Number number13 = numberIsTooLargeException6.getMax();
        org.apache.commons.math.exception.util.Localizable localizable14 = numberIsTooLargeException6.getGeneralPattern();
        java.lang.Object[] objArray19 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException("hi!", objArray19);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException21 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable14, objArray19);
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray26 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable25, objArray26);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, localizable23, objArray26);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException(localizable14, objArray26);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException(0, "4", objArray26);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 2.718281828459045d + "'", number13.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray26);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.5614628358856486d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.009333355396802008d + "'", double1 == 0.009333355396802008d);
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test187");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double3 = normalDistributionImpl2.getMean();
//        double double6 = normalDistributionImpl2.cumulativeProbability((double) (short) -1, 3.207810091467445d);
//        double double7 = normalDistributionImpl2.getStandardDeviation();
//        double double8 = normalDistributionImpl2.getStandardDeviation();
//        double double9 = normalDistributionImpl2.sample();
//        double double10 = normalDistributionImpl2.getMean();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.544137102816975d + "'", double3 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08656193300300513d + "'", double6 == 0.08656193300300513d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.246216406046493d + "'", double7 == 3.246216406046493d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.246216406046493d + "'", double8 == 3.246216406046493d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 6.3883886228788604d + "'", double9 == 6.3883886228788604d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 7.544137102816975d + "'", double10 == 7.544137102816975d);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.8414709848078964d, (java.lang.Number) 21.0f, true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 2.0198227150790538d, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException10);
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, objArray17);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("3d787e85ce", objArray17);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException11, "fd4ecaf23f", objArray17);
        java.lang.Throwable[] throwableArray21 = convergenceException11.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3, "hi!", (java.lang.Object[]) throwableArray21);
        java.lang.Object[] objArray23 = numberIsTooLargeException3.getArguments();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertNotNull(objArray23);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException9);
        java.lang.Number number11 = numberIsTooLargeException4.getMax();
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, objArray16);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray16);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException27 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException22.addSuppressed((java.lang.Throwable) numberIsTooSmallException27);
        java.lang.Number number29 = numberIsTooLargeException22.getMax();
        org.apache.commons.math.exception.util.Localizable localizable30 = numberIsTooLargeException22.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException32 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable30, (java.lang.Number) 100L);
        java.lang.Number number35 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException36 = new org.apache.commons.math.exception.OutOfRangeException(localizable30, (java.lang.Number) 2.5083432919410233d, (java.lang.Number) 10.693737673234912d, number35);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException40 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException45 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable41, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException40.addSuppressed((java.lang.Throwable) numberIsTooSmallException45);
        java.lang.Number number47 = numberIsTooLargeException40.getMax();
        java.lang.Object[] objArray48 = numberIsTooLargeException40.getArguments();
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException(localizable30, objArray48);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException50 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable12, objArray48);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 2.718281828459045d + "'", number11.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 2.718281828459045d + "'", number29.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number47 + "' != '" + 2.718281828459045d + "'", number47.equals(2.718281828459045d));
        org.junit.Assert.assertNotNull(objArray48);
    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test190");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        double double11 = randomDataImpl0.nextGaussian(7.112156832451546d, 4.600161852571429d);
//        randomDataImpl0.reSeed();
//        long long15 = randomDataImpl0.nextSecureLong((long) 11, (long) (short) 100);
//        try {
//            long long18 = randomDataImpl0.nextLong((long) '#', 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 35 is larger than, or equal to, the maximum (0): lower bound (35) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.2283126193622613d + "'", double3 == 3.2283126193622613d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.1690443777272472d + "'", double6 == 1.1690443777272472d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2L + "'", long8 == 2L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 11.602745123257934d + "'", double11 == 11.602745123257934d);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 20L + "'", long15 == 20L);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getSpecificPattern();
        java.lang.Object[] objArray5 = numberIsTooLargeException3.getArguments();
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertNotNull(objArray5);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        java.lang.String str5 = randomDataImpl0.nextSecureHexString(10);
//        randomDataImpl0.reSeedSecure();
//        try {
//            double double8 = randomDataImpl0.nextChiSquare((double) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.2292112833961397d + "'", double3 == 3.2292112833961397d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "4c6a8c3fc4" + "'", str5.equals("4c6a8c3fc4"));
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.6352221186329476d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6352221186329476d + "'", double1 == 0.6352221186329476d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        double double2 = org.apache.commons.math.util.FastMath.pow(8.845455831739777d, 0.40903333932331004d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.4391591176639484d + "'", double2 == 2.4391591176639484d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        double double1 = org.apache.commons.math.util.FastMath.acos((-0.5772156677920679d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.186111192700351d + "'", double1 == 2.186111192700351d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        double double1 = org.apache.commons.math.util.FastMath.log(0.8766614068337787d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.13163444230581337d) + "'", double1 == (-0.13163444230581337d));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        double double1 = org.apache.commons.math.util.FastMath.atanh(3.096731429964887d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test198");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        double double11 = randomDataImpl0.nextGaussian(7.112156832451546d, 4.600161852571429d);
//        try {
//            randomDataImpl0.setSecureAlgorithm("3", "5");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 5");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.249688253373901d + "'", double3 == 3.249688253373901d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0435005247410933d + "'", double6 == 1.0435005247410933d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 12.868129018819836d + "'", double11 == 12.868129018819836d);
//    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        double double1 = org.apache.commons.math.util.FastMath.cos(4.599330994072959d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.11281728695855057d) + "'", double1 == (-0.11281728695855057d));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 20);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.6882538673612966d + "'", double1 == 3.6882538673612966d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        double double1 = org.apache.commons.math.util.FastMath.sinh(2.9496225359621646d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.523191906342346d + "'", double1 == 9.523191906342346d);
    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test202");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        java.lang.String str5 = randomDataImpl0.nextSecureHexString(10);
//        randomDataImpl0.reSeedSecure();
//        double double9 = randomDataImpl0.nextCauchy(0.5551940451963508d, 3.20459618189556d);
//        try {
//            int int12 = randomDataImpl0.nextZipf(0, 1.1356828912995087d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): dimension (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.248836354822636d + "'", double3 == 3.248836354822636d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "d50efd07a9" + "'", str5.equals("d50efd07a9"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.541035570536562d) + "'", double9 == (-1.541035570536562d));
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(10.693737673234912d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1866409317425067d + "'", double1 == 0.1866409317425067d);
    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test204");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        double double11 = randomDataImpl0.nextGaussian(7.112156832451546d, 4.600161852571429d);
//        randomDataImpl0.reSeed();
//        double double15 = randomDataImpl0.nextF(2.744220474423504d, 3.1080153191219937d);
//        try {
//            randomDataImpl0.setSecureAlgorithm("0269e51c0f", "org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.2425986497724826d + "'", double3 == 3.2425986497724826d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.05860490783666d + "'", double6 == 1.05860490783666d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 11.378393207174526d + "'", double11 == 11.378393207174526d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.7564854572883135d + "'", double15 == 4.7564854572883135d);
//    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test205");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        randomDataImpl0.reSeed();
//        double double12 = randomDataImpl0.nextGaussian(2.4053027645871077d, 2.758443714131805d);
//        randomDataImpl0.reSeed((-1L));
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution15 = null;
//        try {
//            int int16 = randomDataImpl0.nextInversionDeviate(integerDistribution15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.244262680699945d + "'", double3 == 3.244262680699945d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.8479162262840862d + "'", double6 == 3.8479162262840862d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.890136310104175d + "'", double12 == 4.890136310104175d);
//    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test206");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        java.lang.String str5 = randomDataImpl0.nextSecureHexString(10);
//        randomDataImpl0.reSeedSecure();
//        double double8 = randomDataImpl0.nextExponential(0.017453292519943295d);
//        java.lang.Class<?> wildcardClass9 = randomDataImpl0.getClass();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.2414167660574895d + "'", double3 == 3.2414167660574895d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "27a57da67a" + "'", str5.equals("27a57da67a"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.003307588267312668d + "'", double8 == 0.003307588267312668d);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 2.0198227150790538d, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException5.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException10.addSuppressed((java.lang.Throwable) numberIsTooSmallException15);
        java.lang.Number number17 = numberIsTooLargeException10.getMax();
        org.apache.commons.math.exception.util.Localizable localizable18 = numberIsTooLargeException10.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable18, (java.lang.Number) 100L);
        convergenceException5.addSuppressed((java.lang.Throwable) notStrictlyPositiveException20);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 2.718281828459045d + "'", number17.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-0.9722310422658634d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test209");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double5 = randomDataImpl0.nextExponential(Double.NaN);
//        double double8 = randomDataImpl0.nextUniform(0.9969748643467198d, 6.798056507791588d);
//        double double11 = randomDataImpl0.nextBeta((double) 111L, 0.09226365410835027d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.261817294378018d + "'", double3 == 3.261817294378018d);
//        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.3005176350797822d + "'", double8 == 2.3005176350797822d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.9999999989899152d + "'", double11 == 0.9999999989899152d);
//    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test210");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        randomDataImpl0.reSeed();
//        double double12 = randomDataImpl0.nextGaussian(2.4053027645871077d, 2.758443714131805d);
//        try {
//            randomDataImpl0.setSecureAlgorithm("{0}", "f");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: f");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.258884165682244d + "'", double3 == 3.258884165682244d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.931797813231154d + "'", double6 == 2.931797813231154d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 8.796426380085359d + "'", double12 == 8.796426380085359d);
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 10);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        java.lang.Number number3 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.1873987292549381d, 22023.965796698492d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        double double2 = org.apache.commons.math.util.FastMath.max(0.04478154114589594d, 8.845455831739777d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.845455831739777d + "'", double2 == 8.845455831739777d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 2.710071082755576d, (java.lang.Number) (-0.5772156677920679d), false);
        java.lang.Object[] objArray4 = numberIsTooLargeException3.getArguments();
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        double double2 = org.apache.commons.math.util.FastMath.atan2(13.166275598782555d, 1.505149978319906d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4569718741921796d + "'", double2 == 1.4569718741921796d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        double double1 = org.apache.commons.math.util.FastMath.cosh(43.29757019802005d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1832138897219988E18d + "'", double1 == 3.1832138897219988E18d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.3358115530746422d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.033012895896001d + "'", double1 == 2.033012895896001d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(2.710071082755576d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4428676690459036d + "'", double1 == 0.4428676690459036d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.1615758743811201d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.16157587438112012d + "'", double1 == 0.16157587438112012d);
    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test220");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        double double11 = randomDataImpl0.nextCauchy(4.600161852571429d, 2.6508641820894225d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double15 = normalDistributionImpl14.getMean();
//        double double18 = normalDistributionImpl14.cumulativeProbability((double) (short) -1, 3.207810091467445d);
//        normalDistributionImpl14.reseedRandomGenerator((long) 32);
//        double[] doubleArray22 = normalDistributionImpl14.sample((int) '4');
//        double double23 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.5654307555909273d + "'", double3 == 2.5654307555909273d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.9311602411743604d + "'", double6 == 0.9311602411743604d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.15271149799812456d + "'", double11 == 0.15271149799812456d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 7.544137102816975d + "'", double15 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.08656193300300513d + "'", double18 == 0.08656193300300513d);
//        org.junit.Assert.assertNotNull(doubleArray22);
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 9.38654379892744d + "'", double23 == 9.38654379892744d);
//    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        double double1 = org.apache.commons.math.util.FastMath.sin(2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 2.864710569476565d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-1.1975433264545765d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0143994595186303d) + "'", double1 == (-1.0143994595186303d));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        double double1 = org.apache.commons.math.special.Gamma.digamma(6.176287125823654d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.737583611831839d + "'", double1 == 1.737583611831839d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        double double2 = org.apache.commons.math.util.FastMath.min(4.646717088146518d, 0.7102622648798613d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7102622648798613d + "'", double2 == 0.7102622648798613d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.14135949203191606d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test227");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        java.lang.String str3 = randomDataImpl0.nextHexString((int) (short) 1);
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeed();
//        try {
//            long long8 = randomDataImpl0.nextSecureLong((long) 52, (long) 30);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 52 is larger than, or equal to, the maximum (30): lower bound (52) must be strictly less than upper bound (30)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "f" + "'", str3.equals("f"));
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        double double1 = org.apache.commons.math.util.FastMath.log1p(2.839602315843011d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.345368797654008d + "'", double1 == 1.345368797654008d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.2851476301750329d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.10895301971996973d + "'", double1 == 0.10895301971996973d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
        double double3 = normalDistributionImpl2.getMean();
        double double4 = normalDistributionImpl2.getMean();
        double double6 = normalDistributionImpl2.density(0.10516633568161556d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.544137102816975d + "'", double3 == 7.544137102816975d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.544137102816975d + "'", double4 == 7.544137102816975d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.008896454288790654d + "'", double6 == 0.008896454288790654d);
    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test231");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        try {
//            int int16 = randomDataImpl0.nextHypergeometric(59, (-1), (int) '#');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of successes (-1)");
//        } catch (org.apache.commons.math.exception.NotPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.319672764070298d + "'", double3 == 2.319672764070298d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.1796964691175307d + "'", double6 == 1.1796964691175307d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 11.308582352485516d + "'", double12 == 11.308582352485516d);
//    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.9999685384675274d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430436619484142d + "'", double1 == 1.5430436619484142d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.8745734993896739d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3691506489023308d + "'", double1 == 1.3691506489023308d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 11, (float) 21);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 21.0f + "'", float2 == 21.0f);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        java.lang.Number number10 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray15);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray15);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 0.0015107907377931822d, (java.lang.Number) (-0.5961722400471147d), true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 0.26159208578767884d);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 2.718281828459045d + "'", number10.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray15);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        double double1 = org.apache.commons.math.util.FastMath.exp(11.054609886555099d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 63234.78893716327d + "'", double1 == 63234.78893716327d);
    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test237");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        java.lang.String str5 = randomDataImpl0.nextSecureHexString(10);
//        double double8 = randomDataImpl0.nextF((double) ' ', 9.992428484835056d);
//        int int11 = randomDataImpl0.nextZipf((int) 'a', 0.8813735870195429d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.261950783640635d + "'", double3 == 3.261950783640635d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "67dccd013d" + "'", str5.equals("67dccd013d"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.6066924150400965d + "'", double8 == 0.6066924150400965d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 62 + "'", int11 == 62);
//    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException("hi!", objArray6);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray6);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException8);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathIllegalArgumentException8.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNull(localizable10);
    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test239");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        double double11 = randomDataImpl0.nextCauchy(2.99822295029797d, 7.8726391065033505d);
//        double double14 = randomDataImpl0.nextBeta(3.141592653589793d, (double) (byte) 1);
//        java.lang.String str16 = randomDataImpl0.nextHexString((int) (byte) 100);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.3109823929531217d + "'", double3 == 3.3109823929531217d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.8669615065665295d + "'", double6 == 1.8669615065665295d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 29.13496855883712d + "'", double11 == 29.13496855883712d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.9603024631207233d + "'", double14 == 0.9603024631207233d);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "be59f652329ee5ae703e72ef4bc24d33ba9022c98d45684d77d3e1bf0b7f098a620e0ec0de90dfa2073d72e8e1cebf344499" + "'", str16.equals("be59f652329ee5ae703e72ef4bc24d33ba9022c98d45684d77d3e1bf0b7f098a620e0ec0de90dfa2073d72e8e1cebf344499"));
//    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException9);
        java.lang.Number number11 = numberIsTooLargeException4.getMax();
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Number number14 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, (java.lang.Number) (-0.46046391868746567d), number14, false);
        java.lang.Object[] objArray21 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray21);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException(localizable12, objArray21);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("9913e0bd71", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable25 = convergenceException24.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable25, (java.lang.Number) 0, (java.lang.Number) 11L, false);
        java.lang.Object[] objArray30 = null;
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException(localizable25, objArray30);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 2.718281828459045d + "'", number11.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(localizable25);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.3389294304545183d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9732390880880308d + "'", double1 == 0.9732390880880308d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(Double.NaN, 1.1995416045736986d);
        normalDistributionImpl2.reseedRandomGenerator(30L);
    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test243");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        java.lang.String str3 = randomDataImpl0.nextHexString((int) (short) 1);
//        long long5 = randomDataImpl0.nextPoisson((double) (byte) 100);
//        try {
//            int int8 = randomDataImpl0.nextBinomial(1, (-0.9999999999999999d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -1 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "6" + "'", str3.equals("6"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 89L + "'", long5 == 89L);
//    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException(localizable0, objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = convergenceException2.getGeneralPattern();
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable10, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException9.addSuppressed((java.lang.Throwable) numberIsTooSmallException14);
        java.lang.Number number16 = numberIsTooLargeException9.getMax();
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooLargeException9.getGeneralPattern();
        java.lang.Object[] objArray22 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException("hi!", objArray22);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException24 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable17, objArray22);
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable28, objArray29);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable25, localizable26, objArray29);
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException(localizable17, objArray29);
        org.apache.commons.math.exception.util.Localizable localizable33 = mathException32.getGeneralPattern();
        mathException4.addSuppressed((java.lang.Throwable) mathException32);
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 2.718281828459045d + "'", number16.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + localizable33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable33.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test245");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        randomDataImpl0.reSeed((long) 100);
//        int int11 = randomDataImpl0.nextZipf((int) ' ', 0.31103915499158813d);
//        double double14 = randomDataImpl0.nextWeibull(7.853107962480361d, 6.966171178609635d);
//        double double16 = randomDataImpl0.nextT(4.884647329734806d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.2237574174385606d + "'", double3 == 3.2237574174385606d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.6819401563745116d + "'", double6 == 3.6819401563745116d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 21 + "'", int11 == 21);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 5.734168005807173d + "'", double14 == 5.734168005807173d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.4593779879481563d + "'", double16 == 0.4593779879481563d);
//    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test246");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double5 = randomDataImpl0.nextExponential(Double.NaN);
//        int int8 = randomDataImpl0.nextBinomial((int) (byte) 10, 0.1873987292549381d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.2210137116479087d + "'", double3 == 3.2210137116479087d);
//        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
//    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test247");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double5 = randomDataImpl0.nextExponential(Double.NaN);
//        double double8 = randomDataImpl0.nextUniform(0.9969748643467198d, 6.798056507791588d);
//        randomDataImpl0.reSeedSecure(100L);
//        int int13 = randomDataImpl0.nextZipf((int) '#', 2.0198227150790538d);
//        try {
//            int int16 = randomDataImpl0.nextBinomial(387632507, 3.201783986282681d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 3.202 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.219814934334331d + "'", double3 == 3.219814934334331d);
//        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.2928433752197512d + "'", double8 == 1.2928433752197512d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
//    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.08886259462063964d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3877787807814457E-17d + "'", double1 == 1.3877787807814457E-17d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        double double1 = org.apache.commons.math.util.FastMath.atan(3.2096651830614884d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.268768990309936d + "'", double1 == 1.268768990309936d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException9);
        java.lang.Number number11 = numberIsTooLargeException4.getMax();
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Number number14 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, (java.lang.Number) (-0.46046391868746567d), number14, false);
        java.lang.Object[] objArray21 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray21);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException(localizable12, objArray21);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("9913e0bd71", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable25 = convergenceException24.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable25, (java.lang.Number) 0, (java.lang.Number) 11L, false);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException33 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable25, (java.lang.Number) 3.0172641870720844d, (java.lang.Number) 1.450890170229621d, true);
        java.lang.Number number34 = numberIsTooLargeException33.getMax();
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 2.718281828459045d + "'", number11.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(localizable25);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + 1.450890170229621d + "'", number34.equals(1.450890170229621d));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(3.246216406046493d, 0.1866409317425067d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.2462164060464924d + "'", double2 == 3.2462164060464924d);
    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test253");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double3 = normalDistributionImpl2.getMean();
//        double double5 = normalDistributionImpl2.density((double) (short) 1);
//        double double6 = normalDistributionImpl2.sample();
//        double[] doubleArray8 = normalDistributionImpl2.sample((int) (short) 10);
//        double double11 = normalDistributionImpl2.cumulativeProbability(2.0198227150790538d, (double) 100);
//        normalDistributionImpl2.reseedRandomGenerator((long) (short) -1);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.544137102816975d + "'", double3 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.01610846091529747d + "'", double5 == 0.01610846091529747d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.629903839964593d + "'", double6 == 3.629903839964593d);
//        org.junit.Assert.assertNotNull(doubleArray8);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.9556007738814948d + "'", double11 == 0.9556007738814948d);
//    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, objArray10);
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("3d787e85ce", objArray10);
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException(localizable5, objArray10);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException(throwable3, "org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)", objArray10);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100, "76b6a5e15f", objArray10);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("ce3f629aa2", objArray10);
        java.lang.String str17 = mathException16.toString();
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.apache.commons.math.MathException: ce3f629aa2" + "'", str17.equals("org.apache.commons.math.MathException: ce3f629aa2"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(4.38337195581903d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 251.14871310443553d + "'", double1 == 251.14871310443553d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException(throwable0);
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("hi!", objArray7);
        java.lang.Class<?> wildcardClass9 = objArray7.getClass();
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException(throwable0, localizable2, objArray7);
        org.apache.commons.math.exception.util.Localizable localizable11 = mathException10.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(localizable11);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.32837532176813833d, 2.777718171589642d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3283753217681384d + "'", double2 == 0.3283753217681384d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(6.966171178609635d, 3.207810091467445d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.04651311928320406d + "'", double2 == 0.04651311928320406d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 22025.465794806718d, (java.lang.Number) 100, (java.lang.Number) 1.0E-9d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException8 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 22025.465794806718d, (java.lang.Number) 100, (java.lang.Number) 1.0E-9d);
        java.lang.Number number9 = outOfRangeException8.getLo();
        java.lang.Throwable[] throwableArray10 = outOfRangeException8.getSuppressed();
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, "org.apache.commons.math.MathException: ", (java.lang.Object[]) throwableArray10);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 100 + "'", number9.equals(100));
        org.junit.Assert.assertNotNull(throwableArray10);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable2, (java.lang.Number) 2.0198227150790538d, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException6);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, objArray13);
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("3d787e85ce", objArray13);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException7, "fd4ecaf23f", objArray13);
        java.lang.Throwable[] throwableArray17 = convergenceException7.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException(62, localizable1, (java.lang.Object[]) throwableArray17);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(throwableArray17);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        double double1 = org.apache.commons.math.util.FastMath.signum(2.126048628120582d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test262");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double5 = randomDataImpl0.nextExponential(Double.NaN);
//        double double8 = randomDataImpl0.nextCauchy(0.019691932154573932d, 0.9969748643467198d);
//        randomDataImpl0.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.1601626148908037d + "'", double3 == 3.1601626148908037d);
//        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05304502506572236d + "'", double8 == 0.05304502506572236d);
//    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        double double1 = org.apache.commons.math.util.FastMath.tanh(2.7089894095686646d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9911669766862701d + "'", double1 == 0.9911669766862701d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        int int2 = org.apache.commons.math.util.FastMath.min(30, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(1.787066582172498d, (-21.46708637494148d), 2.878361163192377d, 387632512);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        double double1 = org.apache.commons.math.special.Erf.erf((double) 30);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException(localizable0, objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = convergenceException2.getGeneralPattern();
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException8.addSuppressed((java.lang.Throwable) numberIsTooSmallException13);
        java.lang.Number number15 = numberIsTooLargeException8.getMax();
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooLargeException8.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException20 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException25 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable21, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException20.addSuppressed((java.lang.Throwable) numberIsTooSmallException25);
        java.lang.Number number27 = numberIsTooLargeException20.getMax();
        org.apache.commons.math.exception.util.Localizable localizable28 = numberIsTooLargeException20.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable29, objArray32);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, objArray32);
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable16, objArray32);
        java.lang.Object[] objArray40 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException("hi!", objArray40);
        java.lang.Class<?> wildcardClass42 = objArray40.getClass();
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException(localizable16, objArray40);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException45 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable16, (java.lang.Number) 19);
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 2.718281828459045d + "'", number15.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 2.718281828459045d + "'", number27.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable28.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(wildcardClass42);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(12.907794446714536d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12.907794446714538d + "'", double1 == 12.907794446714538d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.9604209204271249d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.853108231964106d + "'", double1 == 0.853108231964106d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(7.659793813137549d, 2.3005176350797822d, 0.5408190484372157d, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (-1) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test271");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextF(2.718281828459045d, (double) 100);
//        double double5 = randomDataImpl0.nextExponential(6.644876506300128d);
//        try {
//            double double8 = randomDataImpl0.nextGamma(0.0d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.17866116307947144d + "'", double3 == 0.17866116307947144d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 5.435559449532415d + "'", double5 == 5.435559449532415d);
//    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.8288317194933723d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 35, (long) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        long long1 = org.apache.commons.math.util.FastMath.round(2.5183587988880425d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3L + "'", long1 == 3L);
    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test275");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        java.lang.String str3 = randomDataImpl0.nextHexString((int) (short) 1);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double8 = normalDistributionImpl7.getMean();
//        double double10 = normalDistributionImpl7.density((double) (short) 1);
//        double double11 = normalDistributionImpl7.sample();
//        double[] doubleArray13 = normalDistributionImpl7.sample((int) (short) 10);
//        double double16 = normalDistributionImpl7.cumulativeProbability(2.0198227150790538d, (double) 100);
//        double double17 = normalDistributionImpl7.sample();
//        double double20 = normalDistributionImpl7.cumulativeProbability((-0.5772156677920679d), 3.237011984115693d);
//        double double21 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double24 = randomDataImpl0.nextGaussian((-0.6981152095798223d), 7.105427357601002E-15d);
//        randomDataImpl0.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "d" + "'", str3.equals("d"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 7.544137102816975d + "'", double8 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.01610846091529747d + "'", double10 == 0.01610846091529747d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.3376366091383556d + "'", double11 == 1.3376366091383556d);
//        org.junit.Assert.assertNotNull(doubleArray13);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.9556007738814948d + "'", double16 == 0.9556007738814948d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 3.807687643466501d + "'", double17 == 3.807687643466501d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.08610676786594773d + "'", double20 == 0.08610676786594773d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.8117957116341676d + "'", double21 == 3.8117957116341676d);
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-0.6981152095798154d) + "'", double24 == (-0.6981152095798154d));
//    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 3.143276701259362d, (java.lang.Number) 21.0f, false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 21.0f + "'", number4.equals(21.0f));
    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test277");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        try {
//            randomDataImpl0.setSecureAlgorithm("org.apache.commons.math.exception.NumberIsTooLargeException: 2.71 is larger than, or equal to, the maximum (-0.577)", "1c1cddb581");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 1c1cddb581");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.4501979725371488d + "'", double3 == 2.4501979725371488d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.8885057469853557d + "'", double6 == 1.8885057469853557d);
//    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2.9647942139794674d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test279");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double5 = randomDataImpl0.nextExponential(Double.NaN);
//        double double8 = randomDataImpl0.nextGamma((double) (byte) 1, (double) 10.0f);
//        try {
//            double double10 = randomDataImpl0.nextChiSquare(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.4408153153990995d + "'", double3 == 2.4408153153990995d);
//        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.321668728866164d + "'", double8 == 4.321668728866164d);
//    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException("hi!", objArray6);
        java.lang.Class<?> wildcardClass8 = objArray6.getClass();
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException("b0f617732c", objArray6);
        java.lang.Throwable[] throwableArray10 = convergenceException9.getSuppressed();
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(localizable0, (java.lang.Object[]) throwableArray10);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(throwableArray10);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 387632512, 2.839602315843011d);
        double double4 = normalDistributionImpl2.inverseCumulativeProbability(0.8375502720561994d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.876325147954168E8d + "'", double4 == 3.876325147954168E8d);
    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test282");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        double double11 = randomDataImpl0.nextCauchy(2.99822295029797d, 7.8726391065033505d);
//        int int14 = randomDataImpl0.nextSecureInt(10, 32);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl18 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.5772156649015329d, 0.5403023058681398d, 2.6508641820894225d);
//        double double20 = normalDistributionImpl18.cumulativeProbability(5.298342365610589d);
//        double double21 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl18);
//        double double22 = normalDistributionImpl18.getMean();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.3518024506837585d + "'", double3 == 3.3518024506837585d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.636565233568729d + "'", double6 == 2.636565233568729d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.9640695839924234d + "'", double11 == 1.9640695839924234d);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 11 + "'", int14 == 11);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.5772156649015329d + "'", double21 == 0.5772156649015329d);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.5772156649015329d + "'", double22 == 0.5772156649015329d);
//    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, 0.5401832317931035d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        double double1 = org.apache.commons.math.util.FastMath.exp(2.002844215635055d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.410102083286677d + "'", double1 == 7.410102083286677d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
        double double4 = normalDistributionImpl2.inverseCumulativeProbability(0.5403023058681398d);
        normalDistributionImpl2.reseedRandomGenerator(0L);
        double double7 = normalDistributionImpl2.getMean();
        double[] doubleArray9 = normalDistributionImpl2.sample(5);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.8726391065033505d + "'", double4 == 7.8726391065033505d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 7.544137102816975d + "'", double7 == 7.544137102816975d);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 22025.465794806718d, (java.lang.Number) 100, (java.lang.Number) 1.0E-9d);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, objArray10);
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("3d787e85ce", objArray10);
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException(localizable5, objArray10);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, "6", objArray10);
        org.apache.commons.math.exception.util.Localizable localizable15 = convergenceException14.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable15);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((-0.9067668286786221d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 117.70491530548317d + "'", double1 == 117.70491530548317d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 4.097470561084089d, (java.lang.Number) 2.5139994585534726d, (java.lang.Number) 7.164591543681963d);
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException10.addSuppressed((java.lang.Throwable) numberIsTooSmallException15);
        java.lang.Number number17 = numberIsTooLargeException10.getMax();
        org.apache.commons.math.exception.util.Localizable localizable18 = numberIsTooLargeException10.getGeneralPattern();
        java.lang.Object[] objArray23 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("hi!", objArray23);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable18, objArray23);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException(387632512, localizable5, objArray23);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException30 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 3.2384490559388395d, (java.lang.Number) 2.94139907257671d, true);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 2.718281828459045d + "'", number17.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray23);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(3.807687643466501d, 0.4694765750314672d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.8076876434665006d + "'", double2 == 3.8076876434665006d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.5772156649015329d, 0.5403023058681398d, 2.6508641820894225d);
        double double4 = normalDistributionImpl3.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5403023058681398d + "'", double4 == 0.5403023058681398d);
    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test291");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        java.lang.String str3 = randomDataImpl0.nextHexString((int) (short) 1);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double[] doubleArray6 = normalDistributionImpl4.sample((int) '#');
//        double double7 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        double double8 = normalDistributionImpl4.sample();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "d" + "'", str3.equals("d"));
//        org.junit.Assert.assertNotNull(doubleArray6);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.2851224030758651d) + "'", double7 == (-0.2851224030758651d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.5828903137529304d + "'", double8 == 0.5828903137529304d);
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.7012502421118005d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1937756972809659d + "'", double1 == 1.1937756972809659d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getSpecificPattern();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 2.718281828459045d + "'", number5.equals(2.718281828459045d));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 387632512, (float) 32L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        int int2 = org.apache.commons.math.util.FastMath.max(2147483647, 28);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, 99.99999999999999d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
        double double3 = normalDistributionImpl2.getMean();
        double double4 = normalDistributionImpl2.getMean();
        double[] doubleArray6 = normalDistributionImpl2.sample(52);
        double double9 = normalDistributionImpl2.cumulativeProbability(0.0d, 4.884647329734806d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.544137102816975d + "'", double3 == 7.544137102816975d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.544137102816975d + "'", double4 == 7.544137102816975d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.19625620247420483d + "'", double9 == 0.19625620247420483d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        long long2 = org.apache.commons.math.util.FastMath.min(2L, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 3.87632512E8f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 387632512L + "'", long1 == 387632512L);
    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test300");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        java.lang.String str3 = randomDataImpl0.nextHexString((int) (short) 1);
//        long long5 = randomDataImpl0.nextPoisson((double) (byte) 100);
//        int int8 = randomDataImpl0.nextSecureInt(0, 5);
//        try {
//            double double11 = randomDataImpl0.nextGaussian(9.223277148751583d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "d" + "'", str3.equals("d"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 116L + "'", long5 == 116L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
//    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.08610676786594773d, 0.31103915499158813d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.07667242456653145d + "'", double2 == 0.07667242456653145d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException5.addSuppressed((java.lang.Throwable) numberIsTooSmallException10);
        java.lang.Number number12 = numberIsTooLargeException5.getMax();
        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooLargeException5.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException15 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable13, (java.lang.Number) 100L);
        java.lang.Number number18 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable13, (java.lang.Number) 2.5083432919410233d, (java.lang.Number) 10.693737673234912d, number18);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable24, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException23.addSuppressed((java.lang.Throwable) numberIsTooSmallException28);
        java.lang.Number number30 = numberIsTooLargeException23.getMax();
        java.lang.Object[] objArray31 = numberIsTooLargeException23.getArguments();
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException(localizable13, objArray31);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, "76b6a5e15f", objArray31);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException35 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 10);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException();
        notStrictlyPositiveException35.addSuppressed((java.lang.Throwable) mathException36);
        org.apache.commons.math.exception.util.Localizable localizable38 = mathException36.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException42 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException47 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable43, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException42.addSuppressed((java.lang.Throwable) numberIsTooSmallException47);
        java.lang.Number number49 = numberIsTooLargeException42.getMax();
        org.apache.commons.math.exception.util.Localizable localizable50 = numberIsTooLargeException42.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException52 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable50, (java.lang.Number) 100L);
        java.lang.Object[] objArray57 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException("hi!", objArray57);
        java.lang.Class<?> wildcardClass59 = objArray57.getClass();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException60 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable38, localizable50, objArray57);
        org.apache.commons.math.exception.util.Localizable localizable63 = null;
        java.lang.Object[] objArray66 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException67 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable63, objArray66);
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException("3d787e85ce", objArray66);
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)", objArray66);
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException33, localizable38, objArray66);
        java.lang.String str71 = mathException70.toString();
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 2.718281828459045d + "'", number12.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 2.718281828459045d + "'", number30.equals(2.718281828459045d));
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + number49 + "' != '" + 2.718281828459045d + "'", number49.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable50 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable50.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertNotNull(wildcardClass59);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "org.apache.commons.math.MathException: -1" + "'", str71.equals("org.apache.commons.math.MathException: -1"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(21);
        java.lang.Object[] objArray8 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray8);
        java.lang.Class<?> wildcardClass10 = objArray8.getClass();
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException("b0f617732c", objArray8);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException11);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable18, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException17.addSuppressed((java.lang.Throwable) numberIsTooSmallException22);
        java.lang.Number number24 = numberIsTooLargeException17.getMax();
        org.apache.commons.math.exception.util.Localizable localizable25 = numberIsTooLargeException17.getGeneralPattern();
        java.lang.Object[] objArray30 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException("hi!", objArray30);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable25, objArray30);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException36 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException41 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable37, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException36.addSuppressed((java.lang.Throwable) numberIsTooSmallException41);
        java.lang.Number number43 = numberIsTooLargeException36.getMax();
        org.apache.commons.math.exception.util.Localizable localizable44 = numberIsTooLargeException36.getGeneralPattern();
        java.lang.Number number46 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException48 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable44, (java.lang.Number) (-0.46046391868746567d), number46, false);
        org.apache.commons.math.exception.util.Localizable localizable51 = null;
        java.lang.Object[] objArray52 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException53 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable51, objArray52);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException48, "6", objArray52);
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException(localizable25, objArray52);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException59 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable25, (java.lang.Number) 0.9212587981384309d, (java.lang.Number) 1.5069067361076696d, true);
        org.apache.commons.math.exception.util.Localizable localizable60 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException64 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable60, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        boolean boolean65 = numberIsTooSmallException64.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable66 = numberIsTooSmallException64.getSpecificPattern();
        java.lang.Object[] objArray67 = numberIsTooSmallException64.getArguments();
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException11, localizable25, objArray67);
        java.lang.Object[] objArray73 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException74 = new org.apache.commons.math.MathException("hi!", objArray73);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException75 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable25, objArray73);
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException1, "4885561af9", objArray73);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 2.718281828459045d + "'", number24.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable25.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + 2.718281828459045d + "'", number43.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable44.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNull(localizable66);
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertNotNull(objArray73);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 5);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 74.20321057778875d + "'", double1 == 74.20321057778875d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (-1));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        java.lang.Number number10 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 100L);
        java.lang.Object[] objArray14 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray14);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException19 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable20, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException19.addSuppressed((java.lang.Throwable) numberIsTooSmallException24);
        java.lang.Number number26 = numberIsTooLargeException19.getMax();
        org.apache.commons.math.exception.util.Localizable localizable27 = numberIsTooLargeException19.getGeneralPattern();
        java.lang.Number number29 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException31 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable27, (java.lang.Number) (-0.46046391868746567d), number29, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException35 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable27, (java.lang.Number) 3.081725078478352d, (java.lang.Number) (-1.0d), true);
        java.lang.Object[] objArray41 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException("hi!", objArray41);
        java.lang.Class<?> wildcardClass43 = objArray41.getClass();
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException("b0f617732c", objArray41);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException47 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100);
        org.apache.commons.math.exception.util.Localizable localizable48 = maxIterationsExceededException47.getSpecificPattern();
        java.lang.Throwable[] throwableArray49 = maxIterationsExceededException47.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException44, "9913e0bd71", (java.lang.Object[]) throwableArray49);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException51 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable27, (java.lang.Object[]) throwableArray49);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 2.718281828459045d + "'", number10.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 2.718281828459045d + "'", number26.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNull(localizable48);
        org.junit.Assert.assertNotNull(throwableArray49);
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test307");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        double double11 = randomDataImpl0.nextCauchy(4.600161852571429d, 2.6508641820894225d);
//        randomDataImpl0.reSeedSecure((long) (byte) 0);
//        double double16 = randomDataImpl0.nextGamma(3.550128012953764d, 10.569181794623525d);
//        randomDataImpl0.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.5657056712731765d + "'", double3 == 2.5657056712731765d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.1374188391496705d + "'", double6 == 2.1374188391496705d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 5.803071574818634d + "'", double11 == 5.803071574818634d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 23.22061669322307d + "'", double16 == 23.22061669322307d);
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        double double2 = org.apache.commons.math.util.FastMath.min(6.176287125823654d, 1.1645860861459973d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1645860861459973d + "'", double2 == 1.1645860861459973d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException9);
        java.lang.Number number11 = numberIsTooLargeException4.getMax();
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Number number14 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, (java.lang.Number) (-0.46046391868746567d), number14, false);
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException21 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable19, objArray20);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException16, "6", objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray20);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 2.718281828459045d + "'", number11.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray20);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        double double1 = org.apache.commons.math.util.FastMath.cosh(11.88730720928903d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 72704.60679997572d + "'", double1 == 72704.60679997572d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
        double double4 = normalDistributionImpl2.inverseCumulativeProbability(0.5403023058681398d);
        normalDistributionImpl2.reseedRandomGenerator(0L);
        double double9 = normalDistributionImpl2.cumulativeProbability(1.269076108061911d, 2.946712156221019d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.8726391065033505d + "'", double4 == 7.8726391065033505d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05173673650470184d + "'", double9 == 0.05173673650470184d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 19);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 4.111539907647543d, (java.lang.Number) 0.12264703694299059d, false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        double double1 = org.apache.commons.math.util.FastMath.signum((-0.5772156677920679d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException(throwable0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(6.0d, (-2.0d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -2 is smaller than, or equal to, the minimum (0): standard deviation (-2)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test317");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextF(2.718281828459045d, (double) 100);
//        long long6 = randomDataImpl0.nextLong((long) 0, (long) (short) 1);
//        long long8 = randomDataImpl0.nextPoisson(0.2522737922403927d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double13 = normalDistributionImpl11.inverseCumulativeProbability(0.5403023058681398d);
//        double double14 = normalDistributionImpl11.getMean();
//        double double15 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        try {
//            double double17 = normalDistributionImpl11.inverseCumulativeProbability((double) 52);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 52 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.21958998917829203d + "'", double3 == 0.21958998917829203d);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 7.8726391065033505d + "'", double13 == 7.8726391065033505d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 7.544137102816975d + "'", double14 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 13.013356206471643d + "'", double15 == 13.013356206471643d);
//    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test318");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextF(2.718281828459045d, (double) 100);
//        long long6 = randomDataImpl0.nextLong((long) 0, (long) (short) 1);
//        randomDataImpl0.reSeedSecure((long) (short) 10);
//        randomDataImpl0.reSeedSecure();
//        long long12 = randomDataImpl0.nextSecureLong((long) 10, 100L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.21383390037635347d + "'", double3 == 0.21383390037635347d);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 84L + "'", long12 == 84L);
//    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.5772156649015329d, 0.5403023058681398d, 2.6508641820894225d);
        double double5 = normalDistributionImpl3.density((double) 1);
        double double8 = normalDistributionImpl3.cumulativeProbability(0.31103915499158813d, 0.8241953752072392d);
        double double11 = normalDistributionImpl3.cumulativeProbability(2.002844215635055d, 3.1627992970815084d);
        double double14 = normalDistributionImpl3.cumulativeProbability(3.629903839964593d, 12.907794446714538d);
        try {
            double double17 = normalDistributionImpl3.cumulativeProbability(8.537502815727784d, 3.144066555180827d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5436432847461893d + "'", double5 == 0.5436432847461893d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.36507322719752666d + "'", double8 == 0.36507322719752666d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0041619020825574005d + "'", double11 == 0.0041619020825574005d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 8.024106823434352E-9d + "'", double14 == 8.024106823434352E-9d);
    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test320");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        java.lang.String str3 = randomDataImpl0.nextHexString((int) (short) 1);
//        long long5 = randomDataImpl0.nextPoisson((double) (byte) 100);
//        int int8 = randomDataImpl0.nextSecureInt(0, 5);
//        try {
//            double double10 = randomDataImpl0.nextExponential(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "6" + "'", str3.equals("6"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 90L + "'", long5 == 90L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
//    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 19);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 19L + "'", long1 == 19L);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        java.lang.Number number10 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooLargeException3.getGeneralPattern();
        java.lang.Number number13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) (-0.46046391868746567d), number13, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) (short) 1, (java.lang.Number) 4.097470561084089d, (java.lang.Number) 1.110636508023106d);
        java.lang.Number number20 = outOfRangeException19.getHi();
        java.lang.Number number21 = outOfRangeException19.getLo();
        java.lang.Number number22 = outOfRangeException19.getLo();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 2.718281828459045d + "'", number10.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 1.110636508023106d + "'", number20.equals(1.110636508023106d));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 4.097470561084089d + "'", number21.equals(4.097470561084089d));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 4.097470561084089d + "'", number22.equals(4.097470561084089d));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 100L, (double) 21.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 21.0d + "'", double2 == 21.0d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 35L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.428182669496151d) + "'", double1 == (-0.428182669496151d));
    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test325");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double3 = normalDistributionImpl2.getMean();
//        double double6 = normalDistributionImpl2.cumulativeProbability((double) (short) -1, 3.207810091467445d);
//        double double7 = normalDistributionImpl2.sample();
//        double double9 = normalDistributionImpl2.cumulativeProbability(2.393527778424103d);
//        double double11 = normalDistributionImpl2.cumulativeProbability(2.744220474423504d);
//        double double13 = normalDistributionImpl2.density(0.0d);
//        normalDistributionImpl2.reseedRandomGenerator(31L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.544137102816975d + "'", double3 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08656193300300513d + "'", double6 == 0.08656193300300513d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 8.197338447673923d + "'", double7 == 8.197338447673923d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.056295965999692776d + "'", double9 == 0.056295965999692776d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.06962111172915636d + "'", double11 == 0.06962111172915636d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.008255573916615357d + "'", double13 == 0.008255573916615357d);
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        double double1 = org.apache.commons.math.util.FastMath.cos(11.371042845999844d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.36670848605868245d + "'", double1 == 0.36670848605868245d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        int int1 = org.apache.commons.math.util.FastMath.abs(2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 35, (float) 19L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 19.0f + "'", float2 == 19.0f);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        int int2 = org.apache.commons.math.util.FastMath.min(1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.9603024631207233d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        java.lang.Number number10 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooLargeException3.getGeneralPattern();
        java.lang.Number number13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) (-0.46046391868746567d), number13, false);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable18, objArray19);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException15, "6", objArray19);
        org.apache.commons.math.exception.util.Localizable localizable22 = mathException21.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 2.718281828459045d + "'", number10.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNull(localizable22);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException9);
        java.lang.Number number11 = numberIsTooLargeException4.getMax();
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Object[] objArray17 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("hi!", objArray17);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable12, objArray17);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable24, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException23.addSuppressed((java.lang.Throwable) numberIsTooSmallException28);
        java.lang.Number number30 = numberIsTooLargeException23.getMax();
        org.apache.commons.math.exception.util.Localizable localizable31 = numberIsTooLargeException23.getGeneralPattern();
        java.lang.Number number33 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException35 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable31, (java.lang.Number) (-0.46046391868746567d), number33, false);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException40 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable38, objArray39);
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException35, "6", objArray39);
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException(localizable12, objArray39);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException44 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable12, (java.lang.Number) 3L);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 2.718281828459045d + "'", number11.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 2.718281828459045d + "'", number30.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray39);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.5772156649015329d, 0.5403023058681398d, 2.6508641820894225d);
        double double5 = normalDistributionImpl3.density(0.0d);
        double double7 = normalDistributionImpl3.density(2.302585092994046d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.4172934084748632d + "'", double5 == 0.4172934084748632d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.004507444232417268d + "'", double7 == 0.004507444232417268d);
    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test334");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double4 = normalDistributionImpl2.inverseCumulativeProbability(0.5403023058681398d);
//        double double5 = normalDistributionImpl2.sample();
//        try {
//            double double7 = normalDistributionImpl2.inverseCumulativeProbability(3.4447344218459777d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 3.445 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.8726391065033505d + "'", double4 == 7.8726391065033505d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 6.055007489107323d + "'", double5 == 6.055007489107323d);
//    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test335");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double3 = normalDistributionImpl2.getMean();
//        double double6 = normalDistributionImpl2.cumulativeProbability((double) (short) -1, 3.207810091467445d);
//        double double7 = normalDistributionImpl2.getStandardDeviation();
//        double double8 = normalDistributionImpl2.getStandardDeviation();
//        double double9 = normalDistributionImpl2.sample();
//        double double10 = normalDistributionImpl2.getStandardDeviation();
//        double double13 = normalDistributionImpl2.cumulativeProbability(11.0d, (double) 30);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.544137102816975d + "'", double3 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08656193300300513d + "'", double6 == 0.08656193300300513d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.246216406046493d + "'", double7 == 3.246216406046493d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.246216406046493d + "'", double8 == 3.246216406046493d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 7.14696918132399d + "'", double9 == 7.14696918132399d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.246216406046493d + "'", double10 == 3.246216406046493d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.14353261024745223d + "'", double13 == 0.14353261024745223d);
//    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test336");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        double double11 = randomDataImpl0.nextWeibull(43.29757019802005d, 2.496597880203421d);
//        int int14 = randomDataImpl0.nextZipf(28, 1.6686911626851704d);
//        try {
//            int int17 = randomDataImpl0.nextPascal(0, 8.845455831739777d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 8.845 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.863232513974684d + "'", double3 == 2.863232513974684d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.7567106008201943d + "'", double6 == 1.7567106008201943d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3L + "'", long8 == 3L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.5253636521676746d + "'", double11 == 2.5253636521676746d);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException9);
        java.lang.Number number11 = numberIsTooLargeException4.getMax();
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math.exception.OutOfRangeException(localizable12, (java.lang.Number) (-6.816718961678583d), (java.lang.Number) 3.20459618189556d, (java.lang.Number) 5.169076857913174d);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        boolean boolean22 = numberIsTooSmallException21.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooSmallException21.getSpecificPattern();
        java.lang.Object[] objArray24 = numberIsTooSmallException21.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException(1, localizable12, objArray24);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException30 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException35 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable31, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException30.addSuppressed((java.lang.Throwable) numberIsTooSmallException35);
        java.lang.Number number37 = numberIsTooLargeException30.getMax();
        org.apache.commons.math.exception.util.Localizable localizable38 = numberIsTooLargeException30.getGeneralPattern();
        java.lang.Number number40 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable38, (java.lang.Number) (-0.46046391868746567d), number40, false);
        java.lang.Object[] objArray47 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException("hi!", objArray47);
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException(localizable38, objArray47);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException53 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable38, (java.lang.Number) 0.5693386188584106d, (java.lang.Number) 6.503243247425703d, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException57 = new org.apache.commons.math.exception.OutOfRangeException(localizable38, (java.lang.Number) 5.851367096347552d, (java.lang.Number) (-10.668007286810909d), (java.lang.Number) 0.8375502720561994d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException61 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable62 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException66 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable62, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException61.addSuppressed((java.lang.Throwable) numberIsTooSmallException66);
        java.lang.Number number68 = numberIsTooLargeException61.getMax();
        org.apache.commons.math.exception.util.Localizable localizable69 = numberIsTooLargeException61.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable70 = null;
        java.lang.Object[] objArray73 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException74 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable70, objArray73);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException75 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable69, objArray73);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException76 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', localizable38, objArray73);
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException(localizable12, objArray73);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 2.718281828459045d + "'", number11.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(localizable23);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + 2.718281828459045d + "'", number37.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertTrue("'" + number68 + "' != '" + 2.718281828459045d + "'", number68.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable69 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable69.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray73);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
        double double3 = normalDistributionImpl2.getMean();
        double double6 = normalDistributionImpl2.cumulativeProbability((double) (short) -1, 3.207810091467445d);
        normalDistributionImpl2.reseedRandomGenerator((long) 32);
        double[] doubleArray10 = normalDistributionImpl2.sample((int) '4');
        double double11 = normalDistributionImpl2.getMean();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.544137102816975d + "'", double3 == 7.544137102816975d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08656193300300513d + "'", double6 == 0.08656193300300513d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 7.544137102816975d + "'", double11 == 7.544137102816975d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.5614628358856486d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5614628358856488d + "'", double1 == 1.5614628358856488d);
    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test340");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        java.lang.String str3 = randomDataImpl0.nextHexString((int) (short) 1);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double8 = normalDistributionImpl7.getMean();
//        double double10 = normalDistributionImpl7.density((double) (short) 1);
//        double double11 = normalDistributionImpl7.sample();
//        double[] doubleArray13 = normalDistributionImpl7.sample((int) (short) 10);
//        double double16 = normalDistributionImpl7.cumulativeProbability(2.0198227150790538d, (double) 100);
//        double double17 = normalDistributionImpl7.sample();
//        double double18 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        int int22 = randomDataImpl0.nextHypergeometric((int) (byte) 100, (int) (short) 1, (int) (short) 0);
//        java.lang.Class<?> wildcardClass23 = randomDataImpl0.getClass();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl26 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double27 = normalDistributionImpl26.getMean();
//        double double29 = normalDistributionImpl26.density((double) (short) 1);
//        double double30 = normalDistributionImpl26.sample();
//        double[] doubleArray32 = normalDistributionImpl26.sample((int) (short) 10);
//        double double35 = normalDistributionImpl26.cumulativeProbability(2.0198227150790538d, (double) 100);
//        double double36 = normalDistributionImpl26.getStandardDeviation();
//        double double38 = normalDistributionImpl26.cumulativeProbability(2.4946330620091928d);
//        normalDistributionImpl26.reseedRandomGenerator(21L);
//        double double41 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl26);
//        double double44 = randomDataImpl0.nextUniform(2.9319866970800237d, (double) 111L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "6" + "'", str3.equals("6"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 7.544137102816975d + "'", double8 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.01610846091529747d + "'", double10 == 0.01610846091529747d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.012726058683150576d + "'", double11 == 0.012726058683150576d);
//        org.junit.Assert.assertNotNull(doubleArray13);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.9556007738814948d + "'", double16 == 0.9556007738814948d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 4.01123023511272d + "'", double17 == 4.01123023511272d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 6.899365658706347d + "'", double18 == 6.899365658706347d);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 7.544137102816975d + "'", double27 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.01610846091529747d + "'", double29 == 0.01610846091529747d);
//        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 7.0548392074379835d + "'", double30 == 7.0548392074379835d);
//        org.junit.Assert.assertNotNull(doubleArray32);
//        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.9556007738814948d + "'", double35 == 0.9556007738814948d);
//        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 3.246216406046493d + "'", double36 == 3.246216406046493d);
//        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.059912988687569446d + "'", double38 == 0.059912988687569446d);
//        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 7.059576168907255d + "'", double41 == 7.059576168907255d);
//        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 64.45112538076715d + "'", double44 == 64.45112538076715d);
//    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test341");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        randomDataImpl0.reSeed((long) 100);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution9 = null;
//        try {
//            int int10 = randomDataImpl0.nextInversionDeviate(integerDistribution9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.819130168307636d + "'", double3 == 2.819130168307636d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 5.284322342473654d + "'", double6 == 5.284322342473654d);
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.9212587981384309d, (java.lang.Number) 2.126048628120582d, false);
        java.lang.Object[] objArray9 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("hi!", objArray9);
        java.lang.Class<?> wildcardClass11 = objArray9.getClass();
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException("b0f617732c", objArray9);
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException12);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException18 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable19, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException18.addSuppressed((java.lang.Throwable) numberIsTooSmallException23);
        java.lang.Number number25 = numberIsTooLargeException18.getMax();
        org.apache.commons.math.exception.util.Localizable localizable26 = numberIsTooLargeException18.getGeneralPattern();
        java.lang.Object[] objArray31 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException("hi!", objArray31);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable26, objArray31);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException37 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable38, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException37.addSuppressed((java.lang.Throwable) numberIsTooSmallException42);
        java.lang.Number number44 = numberIsTooLargeException37.getMax();
        org.apache.commons.math.exception.util.Localizable localizable45 = numberIsTooLargeException37.getGeneralPattern();
        java.lang.Number number47 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException49 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable45, (java.lang.Number) (-0.46046391868746567d), number47, false);
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        java.lang.Object[] objArray53 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException54 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable52, objArray53);
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException49, "6", objArray53);
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException(localizable26, objArray53);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException60 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable26, (java.lang.Number) 0.9212587981384309d, (java.lang.Number) 1.5069067361076696d, true);
        org.apache.commons.math.exception.util.Localizable localizable61 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException65 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable61, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        boolean boolean66 = numberIsTooSmallException65.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable67 = numberIsTooSmallException65.getSpecificPattern();
        java.lang.Object[] objArray68 = numberIsTooSmallException65.getArguments();
        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException12, localizable26, objArray68);
        java.lang.Object[] objArray74 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException75 = new org.apache.commons.math.MathException("hi!", objArray74);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException76 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable26, objArray74);
        java.lang.Throwable throwable79 = null;
        org.apache.commons.math.exception.util.Localizable localizable81 = null;
        org.apache.commons.math.exception.util.Localizable localizable83 = null;
        java.lang.Object[] objArray86 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException87 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable83, objArray86);
        org.apache.commons.math.MathException mathException88 = new org.apache.commons.math.MathException("3d787e85ce", objArray86);
        org.apache.commons.math.MathException mathException89 = new org.apache.commons.math.MathException(localizable81, objArray86);
        org.apache.commons.math.ConvergenceException convergenceException90 = new org.apache.commons.math.ConvergenceException(throwable79, "org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)", objArray86);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException91 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100, "76b6a5e15f", objArray86);
        org.apache.commons.math.MathException mathException92 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException3, localizable26, objArray86);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException96 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable26, (java.lang.Number) 6.043628353622122d, (java.lang.Number) 1.9182380284293927d, false);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 2.718281828459045d + "'", number25.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable26.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertTrue("'" + number44 + "' != '" + 2.718281828459045d + "'", number44.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertNull(localizable67);
        org.junit.Assert.assertNotNull(objArray68);
        org.junit.Assert.assertNotNull(objArray74);
        org.junit.Assert.assertNotNull(objArray86);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0015107907377931822d, 2.371020486983107d, 0.26159208578767884d, 52);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.9999555864695281d + "'", double4 == 0.9999555864695281d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable1 = mathException0.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        boolean boolean4 = notStrictlyPositiveException3.getBoundIsAllowed();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable10, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException9.addSuppressed((java.lang.Throwable) numberIsTooSmallException14);
        java.lang.Number number16 = numberIsTooLargeException9.getMax();
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooLargeException9.getGeneralPattern();
        java.lang.Number number19 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) (-0.46046391868746567d), number19, false);
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray26 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable25, objArray26);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, localizable23, objArray26);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException(localizable17, objArray26);
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException3, "da087b827c", objArray26);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException(localizable1, objArray26);
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 2.718281828459045d + "'", number16.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray26);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 10);
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException();
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) mathException2);
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException2.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException8.addSuppressed((java.lang.Throwable) numberIsTooSmallException13);
        java.lang.Number number15 = numberIsTooLargeException8.getMax();
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooLargeException8.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable16, (java.lang.Number) 100L);
        java.lang.Object[] objArray23 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("hi!", objArray23);
        java.lang.Class<?> wildcardClass25 = objArray23.getClass();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable16, objArray23);
        java.lang.Number number28 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException30 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable16, (java.lang.Number) 13.166275598782555d, number28, true);
        boolean boolean31 = numberIsTooLargeException30.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 2.718281828459045d + "'", number15.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test346");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double3 = normalDistributionImpl2.getMean();
//        double double5 = normalDistributionImpl2.density((double) (short) 1);
//        double double6 = normalDistributionImpl2.sample();
//        double[] doubleArray8 = normalDistributionImpl2.sample((int) (short) 10);
//        double double11 = normalDistributionImpl2.cumulativeProbability(2.0198227150790538d, (double) 100);
//        double double12 = normalDistributionImpl2.getStandardDeviation();
//        double double14 = normalDistributionImpl2.cumulativeProbability(2.4946330620091928d);
//        normalDistributionImpl2.reseedRandomGenerator(21L);
//        double double17 = normalDistributionImpl2.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.544137102816975d + "'", double3 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.01610846091529747d + "'", double5 == 0.01610846091529747d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.9631624139620918d + "'", double6 == 0.9631624139620918d);
//        org.junit.Assert.assertNotNull(doubleArray8);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.9556007738814948d + "'", double11 == 0.9556007738814948d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.246216406046493d + "'", double12 == 3.246216406046493d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.059912988687569446d + "'", double14 == 0.059912988687569446d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 3.246216406046493d + "'", double17 == 3.246216406046493d);
//    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test347");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        java.lang.String str3 = randomDataImpl0.nextHexString((int) (short) 1);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double8 = normalDistributionImpl7.getMean();
//        double double10 = normalDistributionImpl7.density((double) (short) 1);
//        double double11 = normalDistributionImpl7.sample();
//        double[] doubleArray13 = normalDistributionImpl7.sample((int) (short) 10);
//        double double16 = normalDistributionImpl7.cumulativeProbability(2.0198227150790538d, (double) 100);
//        double double17 = normalDistributionImpl7.sample();
//        double double18 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        int int22 = randomDataImpl0.nextHypergeometric((int) (byte) 100, (int) (short) 1, (int) (short) 0);
//        int int25 = randomDataImpl0.nextSecureInt(10, 18);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "d" + "'", str3.equals("d"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 7.544137102816975d + "'", double8 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.01610846091529747d + "'", double10 == 0.01610846091529747d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 7.097869371046026d + "'", double11 == 7.097869371046026d);
//        org.junit.Assert.assertNotNull(doubleArray13);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.9556007738814948d + "'", double16 == 0.9556007738814948d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 10.447555242965597d + "'", double17 == 10.447555242965597d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 6.2481881298373345d + "'", double18 == 6.2481881298373345d);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 18 + "'", int25 == 18);
//    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(1.5614628358856486d, 3.0172641870720844d, 3.176317849530518d, 123);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.11948708557021279d + "'", double4 == 0.11948708557021279d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 59);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1006052018952572E25d + "'", double1 == 2.1006052018952572E25d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) 5);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 5.0f + "'", float2 == 5.0f);
    }

//    @Test
//    public void test351() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test351");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        randomDataImpl0.reSeed((long) 100);
//        try {
//            int int11 = randomDataImpl0.nextZipf((int) (byte) 100, (double) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): exponent (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.891613579624678d + "'", double3 == 2.891613579624678d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.2374163988994193d + "'", double6 == 1.2374163988994193d);
//    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test352");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        java.lang.String str5 = randomDataImpl0.nextSecureHexString(10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl8 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double9 = normalDistributionImpl8.getMean();
//        double double11 = normalDistributionImpl8.density((double) (short) 1);
//        double double12 = normalDistributionImpl8.sample();
//        double[] doubleArray14 = normalDistributionImpl8.sample((int) (short) 10);
//        double double16 = normalDistributionImpl8.cumulativeProbability(0.9964266069777534d);
//        double double17 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl8);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.888400393777551d + "'", double3 == 2.888400393777551d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "de82c872a1" + "'", str5.equals("de82c872a1"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 7.544137102816975d + "'", double9 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.01610846091529747d + "'", double11 == 0.01610846091529747d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 7.4061180779943045d + "'", double12 == 7.4061180779943045d);
//        org.junit.Assert.assertNotNull(doubleArray14);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.02184627784430887d + "'", double16 == 0.02184627784430887d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 7.225875866947306d + "'", double17 == 7.225875866947306d);
//    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        double double1 = org.apache.commons.math.util.FastMath.atan(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2182829050172777d + "'", double1 == 1.2182829050172777d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        double double1 = org.apache.commons.math.util.FastMath.cos(2.636565233568729d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8751612080869949d) + "'", double1 == (-0.8751612080869949d));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 22025.465794806718d, (java.lang.Number) 100, (java.lang.Number) 1.0E-9d);
        java.lang.Number number4 = outOfRangeException3.getLo();
        java.lang.Number number5 = outOfRangeException3.getHi();
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException3.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100 + "'", number4.equals(100));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.0E-9d + "'", number5.equals(1.0E-9d));
        org.junit.Assert.assertNull(localizable6);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.8373955877591496d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.11754303905182883d + "'", double1 == 0.11754303905182883d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 3.143276701259362d);
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException2);
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException(localizable5, objArray6);
        java.lang.Object[] objArray8 = convergenceException7.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException(localizable4, objArray8);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray8);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.019694478074841076d, 3.237011984115693d, 8.643285932567796d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.6462293530233192d, (-0.7382963518864856d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.646229353023319d + "'", double2 == 1.646229353023319d);
    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test360");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextF(2.718281828459045d, (double) 100);
//        long long6 = randomDataImpl0.nextLong((long) 0, (long) (short) 1);
//        randomDataImpl0.reSeedSecure((long) (short) 10);
//        randomDataImpl0.reSeedSecure();
//        double double12 = randomDataImpl0.nextWeibull(0.009333355396802008d, 7.410102083286677d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.7994226563579161d + "'", double3 == 0.7994226563579161d);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 5.267482572352624E-94d + "'", double12 == 5.267482572352624E-94d);
//    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test361");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        int int9 = randomDataImpl0.nextPascal(10, 0.0d);
//        randomDataImpl0.reSeed();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.8984643541554194d + "'", double3 == 2.8984643541554194d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.8868120267111586d + "'", double6 == 2.8868120267111586d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2147483647 + "'", int9 == 2147483647);
//    }

//    @Test
//    public void test362() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test362");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        java.lang.String str3 = randomDataImpl0.nextHexString((int) (short) 1);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double8 = normalDistributionImpl7.getMean();
//        double double10 = normalDistributionImpl7.density((double) (short) 1);
//        double double11 = normalDistributionImpl7.sample();
//        double[] doubleArray13 = normalDistributionImpl7.sample((int) (short) 10);
//        double double16 = normalDistributionImpl7.cumulativeProbability(2.0198227150790538d, (double) 100);
//        double double17 = normalDistributionImpl7.sample();
//        double double18 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        int int22 = randomDataImpl0.nextHypergeometric((int) (byte) 100, (int) (short) 1, (int) (short) 0);
//        java.lang.Class<?> wildcardClass23 = randomDataImpl0.getClass();
//        double double25 = randomDataImpl0.nextChiSquare(9.999931897872345d);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2" + "'", str3.equals("2"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 7.544137102816975d + "'", double8 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.01610846091529747d + "'", double10 == 0.01610846091529747d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 8.197882265619114d + "'", double11 == 8.197882265619114d);
//        org.junit.Assert.assertNotNull(doubleArray13);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.9556007738814948d + "'", double16 == 0.9556007738814948d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 7.806762508610953d + "'", double17 == 7.806762508610953d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 7.615778202433291d + "'", double18 == 7.615778202433291d);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 9.236661382725945d + "'", double25 == 9.236661382725945d);
//    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test363");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        java.lang.String str3 = randomDataImpl0.nextHexString((int) (short) 1);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double8 = normalDistributionImpl7.getMean();
//        double double10 = normalDistributionImpl7.density((double) (short) 1);
//        double double11 = normalDistributionImpl7.sample();
//        double[] doubleArray13 = normalDistributionImpl7.sample((int) (short) 10);
//        double double16 = normalDistributionImpl7.cumulativeProbability(2.0198227150790538d, (double) 100);
//        double double17 = normalDistributionImpl7.sample();
//        double double18 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        int int22 = randomDataImpl0.nextHypergeometric((int) (byte) 100, (int) (short) 1, (int) (short) 0);
//        java.lang.Class<?> wildcardClass23 = randomDataImpl0.getClass();
//        try {
//            int int26 = randomDataImpl0.nextSecureInt((int) (short) 10, (int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 10 is larger than, or equal to, the maximum (0): lower bound (10) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "f" + "'", str3.equals("f"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 7.544137102816975d + "'", double8 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.01610846091529747d + "'", double10 == 0.01610846091529747d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 9.537686620942878d + "'", double11 == 9.537686620942878d);
//        org.junit.Assert.assertNotNull(doubleArray13);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.9556007738814948d + "'", double16 == 0.9556007738814948d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 4.548387619173982d + "'", double17 == 4.548387619173982d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 7.783643026845233d + "'", double18 == 7.783643026845233d);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 2147483647, (float) 32);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

//    @Test
//    public void test365() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test365");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        java.lang.String str3 = randomDataImpl0.nextHexString((int) (short) 1);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double8 = normalDistributionImpl7.getMean();
//        double double10 = normalDistributionImpl7.density((double) (short) 1);
//        double double11 = normalDistributionImpl7.sample();
//        double[] doubleArray13 = normalDistributionImpl7.sample((int) (short) 10);
//        double double16 = normalDistributionImpl7.cumulativeProbability(2.0198227150790538d, (double) 100);
//        double double17 = normalDistributionImpl7.sample();
//        double double20 = normalDistributionImpl7.cumulativeProbability((-0.5772156677920679d), 3.237011984115693d);
//        double double21 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double24 = randomDataImpl0.nextGaussian((-0.6981152095798223d), 7.105427357601002E-15d);
//        randomDataImpl0.reSeedSecure(19L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "c" + "'", str3.equals("c"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 7.544137102816975d + "'", double8 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.01610846091529747d + "'", double10 == 0.01610846091529747d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 7.967126935004871d + "'", double11 == 7.967126935004871d);
//        org.junit.Assert.assertNotNull(doubleArray13);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.9556007738814948d + "'", double16 == 0.9556007738814948d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 5.25666691140124d + "'", double17 == 5.25666691140124d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.08610676786594773d + "'", double20 == 0.08610676786594773d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 7.758798806102013d + "'", double21 == 7.758798806102013d);
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-0.6981152095798289d) + "'", double24 == (-0.6981152095798289d));
//    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.9964266069777534d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8788445579531531d + "'", double1 == 0.8788445579531531d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        java.lang.Number number10 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray15);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray15);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 0.0015107907377931822d, (java.lang.Number) (-0.5961722400471147d), true);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException25 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 1.710071082755576d, (java.lang.Number) 0.010267204459686558d, true);
        java.lang.Number number26 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException29 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, number26, (java.lang.Number) 0.4694765750314672d, true);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 2.718281828459045d + "'", number10.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray15);
    }

//    @Test
//    public void test368() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test368");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double3 = normalDistributionImpl2.getMean();
//        double double5 = normalDistributionImpl2.density((double) (short) 1);
//        double double6 = normalDistributionImpl2.sample();
//        double[] doubleArray8 = normalDistributionImpl2.sample((int) (short) 10);
//        double double11 = normalDistributionImpl2.cumulativeProbability(2.0198227150790538d, (double) 100);
//        double double12 = normalDistributionImpl2.getStandardDeviation();
//        double[] doubleArray14 = normalDistributionImpl2.sample((int) (short) 10);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.544137102816975d + "'", double3 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.01610846091529747d + "'", double5 == 0.01610846091529747d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 6.980090524599304d + "'", double6 == 6.980090524599304d);
//        org.junit.Assert.assertNotNull(doubleArray8);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.9556007738814948d + "'", double11 == 0.9556007738814948d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.246216406046493d + "'", double12 == 3.246216406046493d);
//        org.junit.Assert.assertNotNull(doubleArray14);
//    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        int int1 = org.apache.commons.math.util.FastMath.abs(11);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 11 + "'", int1 == 11);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(2.7101422139079343d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.7101422139079347d + "'", double1 == 2.7101422139079347d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException5.addSuppressed((java.lang.Throwable) numberIsTooSmallException10);
        java.lang.Number number12 = numberIsTooLargeException5.getMax();
        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooLargeException5.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException(localizable13, (java.lang.Number) (-6.816718961678583d), (java.lang.Number) 3.20459618189556d, (java.lang.Number) 5.169076857913174d);
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) outOfRangeException17);
        org.apache.commons.math.exception.util.Localizable localizable19 = notStrictlyPositiveException1.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 2.718281828459045d + "'", number12.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        java.lang.Object[] objArray4 = new java.lang.Object[] { 3.550128012953764d, 2.99822295029797d, 2.657796346323199d };
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.MathException: ", objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 10);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException();
        notStrictlyPositiveException8.addSuppressed((java.lang.Throwable) mathException9);
        org.apache.commons.math.exception.util.Localizable localizable11 = mathException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray15);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException16);
        java.lang.Throwable throwable21 = null;
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable25, objArray28);
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException("3d787e85ce", objArray28);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException(localizable23, objArray28);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException(throwable21, "org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)", objArray28);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100, "76b6a5e15f", objArray28);
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalArgumentException16, "28fc800164", objArray28);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException(localizable11, objArray28);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException5, localizable6, objArray28);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException40 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 4.097470561084089d, (java.lang.Number) 2.5139994585534726d, (java.lang.Number) 7.164591543681963d);
        org.apache.commons.math.exception.util.Localizable localizable41 = outOfRangeException40.getGeneralPattern();
        java.lang.Object[] objArray42 = null;
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException5, localizable41, objArray42);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertTrue("'" + localizable41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable41.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException(throwable0, "a", objArray2);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable1 = mathException0.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) 1.0E-9d, (java.lang.Number) 11.745934288778123d, (java.lang.Number) 0.9732390880880308d);
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.4928407777776485d);
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException1);
        java.lang.Object[] objArray3 = mathException2.getArguments();
        org.junit.Assert.assertNotNull(objArray3);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.10516633568161556d, (java.lang.Number) 3.141592653589793d, true);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException("hi!", objArray6);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray6);
        org.apache.commons.math.exception.util.Localizable localizable9 = mathIllegalArgumentException8.getSpecificPattern();
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException8);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException10);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNull(localizable9);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (short) 100, (float) 5);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 5.0f + "'", float2 == 5.0f);
    }

//    @Test
//    public void test380() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test380");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        double double14 = randomDataImpl0.nextExponential(2.552863873682405d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl17 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double18 = normalDistributionImpl17.getMean();
//        double double20 = normalDistributionImpl17.density((double) (short) 1);
//        double double21 = normalDistributionImpl17.sample();
//        double[] doubleArray23 = normalDistributionImpl17.sample((int) (short) 10);
//        double double26 = normalDistributionImpl17.cumulativeProbability(2.0198227150790538d, (double) 100);
//        double double27 = normalDistributionImpl17.getStandardDeviation();
//        double double29 = normalDistributionImpl17.cumulativeProbability(1.5430806348152437d);
//        double double30 = normalDistributionImpl17.getMean();
//        double double31 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl17);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.870318069436151d + "'", double3 == 2.870318069436151d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.1514648583081606d + "'", double6 == 1.1514648583081606d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 8.567126248950885d + "'", double12 == 8.567126248950885d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 5.787074910857689d + "'", double14 == 5.787074910857689d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 7.544137102816975d + "'", double18 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.01610846091529747d + "'", double20 == 0.01610846091529747d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 6.51773218494931d + "'", double21 == 6.51773218494931d);
//        org.junit.Assert.assertNotNull(doubleArray23);
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.9556007738814948d + "'", double26 == 0.9556007738814948d);
//        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.246216406046493d + "'", double27 == 3.246216406046493d);
//        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.03225555245128925d + "'", double29 == 0.03225555245128925d);
//        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 7.544137102816975d + "'", double30 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 5.26634335140779d + "'", double31 == 5.26634335140779d);
//    }

//    @Test
//    public void test381() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test381");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        double double11 = randomDataImpl0.nextCauchy(2.99822295029797d, 7.8726391065033505d);
//        double double14 = randomDataImpl0.nextGamma(3.211168364943453d, 2.710071082755576d);
//        randomDataImpl0.reSeed((-1L));
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.8082235498355277d + "'", double3 == 2.8082235498355277d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.2939883657776017d + "'", double6 == 2.2939883657776017d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-2.3358683238927944d) + "'", double11 == (-2.3358683238927944d));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.326747468465881d + "'", double14 == 4.326747468465881d);
//    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.34051064246566165d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        double double1 = org.apache.commons.math.util.FastMath.abs(8.484825935570662d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.484825935570662d + "'", double1 == 8.484825935570662d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 0, 10.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.0000011412445438d, 8.197882265619114d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.000001141244544d + "'", double2 == 1.000001141244544d);
    }

//    @Test
//    public void test386() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test386");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        randomDataImpl0.reSeed((long) 1);
//        try {
//            randomDataImpl0.setSecureAlgorithm("7", "");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.800860304887219d + "'", double3 == 2.800860304887219d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.453360331938984d + "'", double6 == 3.453360331938984d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 8.32179435337992d + "'", double12 == 8.32179435337992d);
//    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.6686911626851704d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2848367924233d + "'", double1 == 1.2848367924233d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        java.lang.Object[] objArray5 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException("hi!", objArray5);
        java.lang.Class<?> wildcardClass7 = objArray5.getClass();
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("b0f617732c", objArray5);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException8);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable15, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException14.addSuppressed((java.lang.Throwable) numberIsTooSmallException19);
        java.lang.Number number21 = numberIsTooLargeException14.getMax();
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooLargeException14.getGeneralPattern();
        java.lang.Object[] objArray27 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException("hi!", objArray27);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable22, objArray27);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException33 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException38 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable34, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException33.addSuppressed((java.lang.Throwable) numberIsTooSmallException38);
        java.lang.Number number40 = numberIsTooLargeException33.getMax();
        org.apache.commons.math.exception.util.Localizable localizable41 = numberIsTooLargeException33.getGeneralPattern();
        java.lang.Number number43 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException45 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable41, (java.lang.Number) (-0.46046391868746567d), number43, false);
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException50 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable48, objArray49);
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException45, "6", objArray49);
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException(localizable22, objArray49);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException56 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable22, (java.lang.Number) 0.9212587981384309d, (java.lang.Number) 1.5069067361076696d, true);
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException61 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable57, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        boolean boolean62 = numberIsTooSmallException61.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable63 = numberIsTooSmallException61.getSpecificPattern();
        java.lang.Object[] objArray64 = numberIsTooSmallException61.getArguments();
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException8, localizable22, objArray64);
        org.apache.commons.math.exception.util.Localizable localizable66 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException70 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable71 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException75 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable71, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException70.addSuppressed((java.lang.Throwable) numberIsTooSmallException75);
        java.lang.Number number77 = numberIsTooLargeException70.getMax();
        org.apache.commons.math.exception.util.Localizable localizable78 = numberIsTooLargeException70.getGeneralPattern();
        java.lang.Number number80 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException82 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable78, (java.lang.Number) (-0.46046391868746567d), number80, false);
        org.apache.commons.math.exception.util.Localizable localizable83 = null;
        org.apache.commons.math.exception.util.Localizable localizable84 = null;
        org.apache.commons.math.exception.util.Localizable localizable86 = null;
        java.lang.Object[] objArray87 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException88 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable86, objArray87);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException89 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable83, localizable84, objArray87);
        org.apache.commons.math.MathException mathException90 = new org.apache.commons.math.MathException(localizable78, objArray87);
        java.lang.Object[] objArray91 = new java.lang.Object[] { mathException90 };
        org.apache.commons.math.ConvergenceException convergenceException92 = new org.apache.commons.math.ConvergenceException(localizable66, objArray91);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException93 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, objArray91);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 2.718281828459045d + "'", number21.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + number40 + "' != '" + 2.718281828459045d + "'", number40.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable41.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNull(localizable63);
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertTrue("'" + number77 + "' != '" + 2.718281828459045d + "'", number77.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable78 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable78.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray87);
        org.junit.Assert.assertNotNull(objArray91);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        double double2 = org.apache.commons.math.util.FastMath.pow(6.2481881298373345d, (double) 111L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.131595612849155E88d + "'", double2 == 2.131595612849155E88d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray5);
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException("3d787e85ce", objArray5);
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)", objArray5);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException13.addSuppressed((java.lang.Throwable) numberIsTooSmallException18);
        java.lang.Number number20 = numberIsTooLargeException13.getMax();
        org.apache.commons.math.exception.util.Localizable localizable21 = numberIsTooLargeException13.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable21, (java.lang.Number) 100L);
        java.lang.Object[] objArray24 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable21, objArray24);
        java.lang.Object[] objArray26 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException(32, localizable21, objArray26);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException29 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 10);
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException();
        notStrictlyPositiveException29.addSuppressed((java.lang.Throwable) mathException30);
        org.apache.commons.math.exception.util.Localizable localizable32 = mathException30.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException36 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException41 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable37, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException36.addSuppressed((java.lang.Throwable) numberIsTooSmallException41);
        java.lang.Number number43 = numberIsTooLargeException36.getMax();
        org.apache.commons.math.exception.util.Localizable localizable44 = numberIsTooLargeException36.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException46 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable44, (java.lang.Number) 100L);
        java.lang.Object[] objArray51 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException("hi!", objArray51);
        java.lang.Class<?> wildcardClass53 = objArray51.getClass();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException54 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable32, localizable44, objArray51);
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException8, localizable21, objArray51);
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException55);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 2.718281828459045d + "'", number20.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + 2.718281828459045d + "'", number43.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable44.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(wildcardClass53);
    }

//    @Test
//    public void test391() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test391");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        java.lang.String str3 = randomDataImpl0.nextHexString((int) (short) 1);
//        long long5 = randomDataImpl0.nextPoisson((double) (byte) 100);
//        int int8 = randomDataImpl0.nextSecureInt(0, 5);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution9 = null;
//        try {
//            int int10 = randomDataImpl0.nextInversionDeviate(integerDistribution9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9" + "'", str3.equals("9"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 103L + "'", long5 == 103L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.0E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.999999995E-10d + "'", double1 == 9.999999995E-10d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(2.3352939229261884d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3267237890202268d + "'", double1 == 1.3267237890202268d);
    }

//    @Test
//    public void test394() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test394");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        java.lang.String str5 = randomDataImpl0.nextSecureHexString(10);
//        randomDataImpl0.reSeed();
//        double double9 = randomDataImpl0.nextCauchy(7.14696918132399d, 2.4974224112688534d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.996355051893909d + "'", double3 == 2.996355051893909d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "c17d3f5d67" + "'", str5.equals("c17d3f5d67"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 8.221930353831837d + "'", double9 == 8.221930353831837d);
//    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) 1, (float) 59);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.0634557801337836E25d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
        double double4 = normalDistributionImpl2.inverseCumulativeProbability(0.5403023058681398d);
        double double5 = normalDistributionImpl2.getMean();
        java.lang.Class<?> wildcardClass6 = normalDistributionImpl2.getClass();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.8726391065033505d + "'", double4 == 7.8726391065033505d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 7.544137102816975d + "'", double5 == 7.544137102816975d);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 3.0454957620747787d, number1, false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        java.lang.Number number5 = numberIsTooLargeException3.getArgument();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 3.0454957620747787d + "'", number5.equals(3.0454957620747787d));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        double double1 = org.apache.commons.math.util.FastMath.asin(2.991568925239926d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double[] doubleArray2 = normalDistributionImpl0.sample((int) '#');
        try {
            double double5 = normalDistributionImpl0.cumulativeProbability(0.840495348171328d, (-0.428182669496151d));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException5.addSuppressed((java.lang.Throwable) numberIsTooSmallException10);
        java.lang.Number number12 = numberIsTooLargeException5.getMax();
        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooLargeException5.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, objArray17);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable13, (java.lang.Number) 0.0015107907377931822d, (java.lang.Number) (-0.5961722400471147d), true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException25 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable13, (java.lang.Number) 32L);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException27 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 10);
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException();
        notStrictlyPositiveException27.addSuppressed((java.lang.Throwable) mathException28);
        org.apache.commons.math.exception.util.Localizable localizable30 = mathException28.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        java.lang.Object[] objArray34 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable31, objArray34);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException35);
        java.lang.Throwable throwable40 = null;
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        java.lang.Object[] objArray47 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable44, objArray47);
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException("3d787e85ce", objArray47);
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException(localizable42, objArray47);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException(throwable40, "org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)", objArray47);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException52 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100, "76b6a5e15f", objArray47);
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalArgumentException35, "28fc800164", objArray47);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException(localizable30, objArray47);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException55 = new org.apache.commons.math.MaxIterationsExceededException(100, localizable13, objArray47);
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException("5fe1a85406", objArray47);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 2.718281828459045d + "'", number12.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(objArray47);
    }

//    @Test
//    public void test402() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test402");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        double double11 = randomDataImpl0.nextWeibull(43.29757019802005d, 2.496597880203421d);
//        double double14 = randomDataImpl0.nextGamma((double) '4', 0.1053020545734041d);
//        double double16 = randomDataImpl0.nextChiSquare((double) '#');
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.9692912455653464d + "'", double3 == 2.9692912455653464d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.3853290579439834d + "'", double6 == 2.3853290579439834d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.2854939286019356d + "'", double11 == 2.2854939286019356d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 6.522991411704608d + "'", double14 == 6.522991411704608d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 35.13880099599937d + "'", double16 == 35.13880099599937d);
//    }

//    @Test
//    public void test403() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test403");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double3 = normalDistributionImpl2.getMean();
//        double double5 = normalDistributionImpl2.density((double) (short) 1);
//        double double6 = normalDistributionImpl2.sample();
//        double[] doubleArray8 = normalDistributionImpl2.sample((int) (short) 10);
//        double double10 = normalDistributionImpl2.cumulativeProbability(0.0d);
//        double double13 = normalDistributionImpl2.cumulativeProbability(0.0d, 0.0d);
//        double double14 = normalDistributionImpl2.getMean();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.544137102816975d + "'", double3 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.01610846091529747d + "'", double5 == 0.01610846091529747d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 12.23124110666124d + "'", double6 == 12.23124110666124d);
//        org.junit.Assert.assertNotNull(doubleArray8);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.010063323450154593d + "'", double10 == 0.010063323450154593d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 7.544137102816975d + "'", double14 == 7.544137102816975d);
//    }

//    @Test
//    public void test404() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test404");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        java.lang.String str3 = randomDataImpl0.nextHexString((int) (short) 1);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double[] doubleArray6 = normalDistributionImpl4.sample((int) '#');
//        double double7 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        double double8 = normalDistributionImpl4.getMean();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "f" + "'", str3.equals("f"));
//        org.junit.Assert.assertNotNull(doubleArray6);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.08614616193002529d) + "'", double7 == (-0.08614616193002529d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
//    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        java.lang.Object[] objArray4 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException("hi!", objArray4);
        java.lang.Object[] objArray6 = mathException5.getArguments();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(objArray6);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        double double1 = org.apache.commons.math.util.FastMath.acosh(3.807687643466501d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.012462192457592d + "'", double1 == 2.012462192457592d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.9212587981384309d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        java.lang.Number number10 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooLargeException3.getGeneralPattern();
        java.lang.Number number13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) (-0.46046391868746567d), number13, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) (short) 1, (java.lang.Number) 4.097470561084089d, (java.lang.Number) 1.110636508023106d);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 1.5607966601082315d);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException25 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) 387632507, (java.lang.Number) 4.70501893323266d, false);
        org.apache.commons.math.exception.util.Localizable localizable26 = numberIsTooSmallException25.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 2.718281828459045d + "'", number10.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + localizable26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable26.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 2.0198227150790538d, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray11);
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException("3d787e85ce", objArray11);
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException(localizable6, objArray11);
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException(localizable5, objArray11);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 0.008059690786305607d, (java.lang.Number) 0.45325752169194927d, false);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray11);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        double double2 = org.apache.commons.math.util.FastMath.min(0.8373955877591496d, 4.059645095551947d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8373955877591496d + "'", double2 == 0.8373955877591496d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((-0.02012092213614458d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test412() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test412");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double5 = randomDataImpl0.nextExponential(Double.NaN);
//        double double8 = randomDataImpl0.nextCauchy(0.019691932154573932d, 0.9969748643467198d);
//        double double11 = randomDataImpl0.nextGamma(5.474767681802112d, 0.08656193300300513d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.9889205451825474d + "'", double3 == 2.9889205451825474d);
//        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.460014230065573d) + "'", double8 == (-1.460014230065573d));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.6359738495750866d + "'", double11 == 0.6359738495750866d);
//    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        java.lang.Object[] objArray5 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException("hi!", objArray5);
        java.lang.Class<?> wildcardClass7 = objArray5.getClass();
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("b0f617732c", objArray5);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException8);
        java.lang.String str10 = convergenceException9.toString();
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.ConvergenceException: b0f617732c" + "'", str10.equals("org.apache.commons.math.ConvergenceException: b0f617732c"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException("hi!", objArray6);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray6);
        org.apache.commons.math.exception.util.Localizable localizable9 = mathIllegalArgumentException8.getSpecificPattern();
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException8);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable15, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException14.addSuppressed((java.lang.Throwable) numberIsTooSmallException19);
        java.lang.Number number21 = numberIsTooLargeException14.getMax();
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooLargeException14.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray26 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, objArray26);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, objArray26);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException32 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable22, (java.lang.Number) 0.0015107907377931822d, (java.lang.Number) (-0.5961722400471147d), true);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException("hi!", objArray39);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, localizable34, objArray39);
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException41);
        java.lang.Object[] objArray43 = mathException42.getArguments();
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException(localizable22, objArray43);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException48 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable22, (java.lang.Number) 3.87632512E8f, (java.lang.Number) 10L, false);
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        java.lang.Object[] objArray51 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException(localizable50, objArray51);
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException("", objArray51);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException10, localizable22, objArray51);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNull(localizable9);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 2.718281828459045d + "'", number21.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(objArray51);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.6462293530233192d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9731357410834788d + "'", double1 == 0.9731357410834788d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        int int2 = org.apache.commons.math.util.FastMath.min(62, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.8414709848078964d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.319776824715853d + "'", double1 == 2.319776824715853d);
    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test418");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double3 = normalDistributionImpl2.getMean();
//        double double5 = normalDistributionImpl2.density((double) (short) 1);
//        double double6 = normalDistributionImpl2.sample();
//        double[] doubleArray8 = normalDistributionImpl2.sample((int) (short) 10);
//        double double11 = normalDistributionImpl2.cumulativeProbability(2.0198227150790538d, (double) 100);
//        double double12 = normalDistributionImpl2.getStandardDeviation();
//        double double14 = normalDistributionImpl2.cumulativeProbability(2.4946330620091928d);
//        double double15 = normalDistributionImpl2.sample();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.544137102816975d + "'", double3 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.01610846091529747d + "'", double5 == 0.01610846091529747d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 6.283326700043944d + "'", double6 == 6.283326700043944d);
//        org.junit.Assert.assertNotNull(doubleArray8);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.9556007738814948d + "'", double11 == 0.9556007738814948d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.246216406046493d + "'", double12 == 3.246216406046493d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.059912988687569446d + "'", double14 == 0.059912988687569446d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 6.039949110721368d + "'", double15 == 6.039949110721368d);
//    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 2.0198227150790538d, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        java.lang.String str7 = numberIsTooSmallException4.toString();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 2.02 is smaller than, or equal to, the minimum (1)" + "'", str7.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 2.02 is smaller than, or equal to, the minimum (1)"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 84L, (java.lang.Number) 1901.471065349969d, (java.lang.Number) 1.8630926212463297d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        double double1 = org.apache.commons.math.util.FastMath.exp(3.394747856306624d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 29.807136845769318d + "'", double1 == 29.807136845769318d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.0506110756905938d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.31682749837822693d + "'", double1 == 0.31682749837822693d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.5693386188584106d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5148733909695399d + "'", double1 == 0.5148733909695399d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException9);
        java.lang.Number number11 = numberIsTooLargeException4.getMax();
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Object[] objArray17 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("hi!", objArray17);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable12, objArray17);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable24, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException23.addSuppressed((java.lang.Throwable) numberIsTooSmallException28);
        java.lang.Number number30 = numberIsTooLargeException23.getMax();
        org.apache.commons.math.exception.util.Localizable localizable31 = numberIsTooLargeException23.getGeneralPattern();
        java.lang.Number number33 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException35 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable31, (java.lang.Number) (-0.46046391868746567d), number33, false);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException40 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable38, objArray39);
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException35, "6", objArray39);
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException(localizable12, objArray39);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException46 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable12, (java.lang.Number) 0.9212587981384309d, (java.lang.Number) 1.5069067361076696d, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException50 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, (java.lang.Number) (-0.08614616193002529d), (java.lang.Number) 0.11948708557021279d, true);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 2.718281828459045d + "'", number11.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 2.718281828459045d + "'", number30.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray39);
    }

//    @Test
//    public void test425() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test425");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        randomDataImpl0.reSeed((long) 100);
//        int int11 = randomDataImpl0.nextZipf((int) ' ', 0.31103915499158813d);
//        double double14 = randomDataImpl0.nextWeibull(7.853107962480361d, 6.966171178609635d);
//        double double17 = randomDataImpl0.nextCauchy(0.0d, 12.164315132131438d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.805862343362102d + "'", double3 == 2.805862343362102d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 6.438607834080236d + "'", double6 == 6.438607834080236d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 21 + "'", int11 == 21);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 5.734168005807173d + "'", double14 == 5.734168005807173d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 7.048208525632352d + "'", double17 == 7.048208525632352d);
//    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        double double1 = org.apache.commons.math.util.FastMath.sin(4.204744929640411d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8738922053215283d) + "'", double1 == (-0.8738922053215283d));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        double double2 = org.apache.commons.math.util.FastMath.min(0.11754303905182883d, 2.671098070241836d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.11754303905182883d + "'", double2 == 0.11754303905182883d);
    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test428");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double3 = normalDistributionImpl2.getMean();
//        double double5 = normalDistributionImpl2.density((double) (short) 1);
//        double double6 = normalDistributionImpl2.sample();
//        double[] doubleArray8 = normalDistributionImpl2.sample((int) (short) 10);
//        double double11 = normalDistributionImpl2.cumulativeProbability(2.0198227150790538d, (double) 100);
//        double double12 = normalDistributionImpl2.sample();
//        double double15 = normalDistributionImpl2.cumulativeProbability((-0.5772156677920679d), 3.237011984115693d);
//        double double16 = normalDistributionImpl2.sample();
//        double double17 = normalDistributionImpl2.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.544137102816975d + "'", double3 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.01610846091529747d + "'", double5 == 0.01610846091529747d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 6.7845896738735885d + "'", double6 == 6.7845896738735885d);
//        org.junit.Assert.assertNotNull(doubleArray8);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.9556007738814948d + "'", double11 == 0.9556007738814948d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 6.9059004644397355d + "'", double12 == 6.9059004644397355d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.08610676786594773d + "'", double15 == 0.08610676786594773d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 11.853539321800488d + "'", double16 == 11.853539321800488d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 3.246216406046493d + "'", double17 == 3.246216406046493d);
//    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        boolean boolean5 = numberIsTooSmallException4.getBoundIsAllowed();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException10.addSuppressed((java.lang.Throwable) numberIsTooSmallException15);
        java.lang.Number number17 = numberIsTooLargeException10.getMax();
        org.apache.commons.math.exception.util.Localizable localizable18 = numberIsTooLargeException10.getGeneralPattern();
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable18, (java.lang.Number) (-0.46046391868746567d), number20, false);
        java.lang.Object[] objArray27 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException("hi!", objArray27);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException(localizable18, objArray27);
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        java.lang.Throwable throwable31 = null;
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException("hi!", objArray39);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, localizable34, objArray39);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(throwable31, "4885561af9", objArray39);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException43 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable30, objArray39);
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4, "a941d16cb1", objArray39);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 2.718281828459045d + "'", number17.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray39);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0d);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 10);
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException();
        notStrictlyPositiveException4.addSuppressed((java.lang.Throwable) mathException5);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException5.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException11.addSuppressed((java.lang.Throwable) numberIsTooSmallException16);
        java.lang.Number number18 = numberIsTooLargeException11.getMax();
        org.apache.commons.math.exception.util.Localizable localizable19 = numberIsTooLargeException11.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable19, (java.lang.Number) 100L);
        java.lang.Object[] objArray26 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException("hi!", objArray26);
        java.lang.Class<?> wildcardClass28 = objArray26.getClass();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable19, objArray26);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException32 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        boolean boolean33 = notStrictlyPositiveException32.getBoundIsAllowed();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException38 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException43 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable39, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException38.addSuppressed((java.lang.Throwable) numberIsTooSmallException43);
        java.lang.Number number45 = numberIsTooLargeException38.getMax();
        org.apache.commons.math.exception.util.Localizable localizable46 = numberIsTooLargeException38.getGeneralPattern();
        java.lang.Number number48 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException50 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable46, (java.lang.Number) (-0.46046391868746567d), number48, false);
        org.apache.commons.math.exception.util.Localizable localizable51 = null;
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        java.lang.Object[] objArray55 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException56 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable54, objArray55);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException57 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable51, localizable52, objArray55);
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException(localizable46, objArray55);
        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException32, "da087b827c", objArray55);
        org.apache.commons.math.ConvergenceException convergenceException60 = new org.apache.commons.math.ConvergenceException("3", objArray55);
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException1, localizable7, objArray55);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 2.718281828459045d + "'", number18.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + number45 + "' != '" + 2.718281828459045d + "'", number45.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable46 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable46.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray55);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(5.98643319194182d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.764361872508687d + "'", double1 == 4.764361872508687d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        double double1 = org.apache.commons.math.util.FastMath.exp(7.059576168907255d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1163.9517422772497d + "'", double1 == 1163.9517422772497d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        double double2 = org.apache.commons.math.util.FastMath.pow(4.440892098500626E-16d, (-0.428182669496151d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3747030.120921867d + "'", double2 == 3747030.120921867d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232874703393d + "'", double1 == 11013.232874703393d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        double double1 = org.apache.commons.math.util.FastMath.exp(2.6824652258218002E-8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000268246527d + "'", double1 == 1.0000000268246527d);
    }

//    @Test
//    public void test436() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test436");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        java.lang.String str5 = randomDataImpl0.nextSecureHexString(10);
//        randomDataImpl0.reSeed();
//        double double9 = randomDataImpl0.nextUniform(2.0198227150790538d, 10.693737673234912d);
//        double double12 = randomDataImpl0.nextF(0.5937799705969213d, (double) 10);
//        double double15 = randomDataImpl0.nextCauchy((-21.46708637494148d), (double) 59);
//        int int18 = randomDataImpl0.nextPascal((int) ' ', 0.5436432847461893d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.9566543648229024d + "'", double3 == 2.9566543648229024d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9a68f74198" + "'", str5.equals("9a68f74198"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 7.058674424749569d + "'", double9 == 7.058674424749569d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.4413948732523768d + "'", double12 == 0.4413948732523768d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.262220055845038d + "'", double15 == 4.262220055845038d);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 31 + "'", int18 == 31);
//    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(22023.965796698492d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 148.4047364362017d + "'", double1 == 148.4047364362017d);
    }

//    @Test
//    public void test438() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test438");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextF(2.718281828459045d, (double) 100);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double7 = normalDistributionImpl6.getMean();
//        double double10 = normalDistributionImpl6.cumulativeProbability((double) (short) -1, 3.207810091467445d);
//        double double11 = normalDistributionImpl6.getStandardDeviation();
//        double double13 = normalDistributionImpl6.cumulativeProbability(26.369176630649168d);
//        double double14 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.9393753132164342d + "'", double3 == 0.9393753132164342d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 7.544137102816975d + "'", double7 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.08656193300300513d + "'", double10 == 0.08656193300300513d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.246216406046493d + "'", double11 == 3.246216406046493d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.9999999966658358d + "'", double13 == 0.9999999966658358d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 9.209654244869128d + "'", double14 == 9.209654244869128d);
//    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.15271149799812456d, (-10.668007286810909d), 0.9969748643467199d, 3);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        double double1 = org.apache.commons.math.special.Erf.erf(1.1514648583081606d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8965635510852885d + "'", double1 == 0.8965635510852885d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        boolean boolean5 = numberIsTooSmallException4.getBoundIsAllowed();
        java.lang.Number number6 = numberIsTooSmallException4.getMin();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException4.getSpecificPattern();
        java.lang.Object[] objArray8 = numberIsTooSmallException4.getArguments();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 22025.465794806718d + "'", number6.equals(22025.465794806718d));
        org.junit.Assert.assertNull(localizable7);
        org.junit.Assert.assertNotNull(objArray8);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 22025.465794806718d, (java.lang.Number) 100, (java.lang.Number) 1.0E-9d);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, objArray10);
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("3d787e85ce", objArray10);
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException(localizable5, objArray10);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, "6", objArray10);
        java.lang.Number number15 = outOfRangeException3.getHi();
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1.0E-9d + "'", number15.equals(1.0E-9d));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        double double1 = org.apache.commons.math.util.FastMath.tan((-3.7345578885760555d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6738587656107425d) + "'", double1 == (-0.6738587656107425d));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        double double2 = org.apache.commons.math.util.FastMath.max(3.1330901301230067d, 10.444667918657329d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.444667918657329d + "'", double2 == 10.444667918657329d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 10, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.2432461722919452d, (java.lang.Number) 2.319776824715853d, (java.lang.Number) 0.10536116277732267d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        double double1 = org.apache.commons.math.util.FastMath.acos(11.284561260950033d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(2.1969367550226755d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2999875255257967d + "'", double1 == 1.2999875255257967d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        java.lang.Number number10 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray15);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray15);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 0.0015107907377931822d, (java.lang.Number) (-0.5961722400471147d), true);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException25 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException30 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable26, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException25.addSuppressed((java.lang.Throwable) numberIsTooSmallException30);
        java.lang.Number number32 = numberIsTooLargeException25.getMax();
        org.apache.commons.math.exception.util.Localizable localizable33 = numberIsTooLargeException25.getGeneralPattern();
        java.lang.Number number35 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable33, (java.lang.Number) (-0.46046391868746567d), number35, false);
        java.lang.Object[] objArray42 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException("hi!", objArray42);
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException(localizable33, objArray42);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException48 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable33, (java.lang.Number) 0.5693386188584106d, (java.lang.Number) 6.503243247425703d, false);
        java.lang.Throwable throwable49 = null;
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException(throwable49);
        java.lang.Class<?> wildcardClass51 = convergenceException50.getClass();
        org.apache.commons.math.exception.util.Localizable localizable52 = convergenceException50.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException56 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        java.lang.String str57 = numberIsTooSmallException56.toString();
        java.lang.Object[] objArray58 = numberIsTooSmallException56.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, localizable52, objArray58);
        org.apache.commons.math.ConvergenceException convergenceException60 = new org.apache.commons.math.ConvergenceException(localizable11, objArray58);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 2.718281828459045d + "'", number10.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 2.718281828459045d + "'", number32.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable33.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertTrue("'" + localizable52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable52.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (0)" + "'", str57.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray58);
    }

//    @Test
//    public void test450() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test450");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double5 = randomDataImpl0.nextExponential(Double.NaN);
//        double double8 = randomDataImpl0.nextGamma((double) (byte) 1, (double) 10.0f);
//        randomDataImpl0.reSeedSecure((long) (byte) 100);
//        java.lang.String str12 = randomDataImpl0.nextSecureHexString(28);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.937511882511868d + "'", double3 == 2.937511882511868d);
//        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 9.652689198689359d + "'", double8 == 9.652689198689359d);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "b952ebc08ff54c758b0ac3bcffa5" + "'", str12.equals("b952ebc08ff54c758b0ac3bcffa5"));
//    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        java.lang.Number number3 = notStrictlyPositiveException1.getMin();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException(localizable6, objArray7);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable5, objArray7);
        java.lang.Object[] objArray10 = mathIllegalArgumentException9.getArguments();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray10);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 0.008255573916615357d, true);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        int int2 = org.apache.commons.math.util.FastMath.max(18, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        double double1 = org.apache.commons.math.special.Erf.erf(0.3283753217681384d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3576336764413698d + "'", double1 == 0.3576336764413698d);
    }

//    @Test
//    public void test455() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test455");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        randomDataImpl0.reSeed((long) 1);
//        double double17 = randomDataImpl0.nextBeta((double) 10L, (double) 10);
//        randomDataImpl0.reSeed(2L);
//        double double22 = randomDataImpl0.nextGaussian((double) 5, 0.6511961857760066d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.8749424811386843d + "'", double3 == 2.8749424811386843d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.3049025335344298d + "'", double6 == 2.3049025335344298d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.596989607981265d + "'", double12 == 4.596989607981265d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.5693386188584106d + "'", double17 == 0.5693386188584106d);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 5.179589808965144d + "'", double22 == 5.179589808965144d);
//    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.7087461852015375d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7877193267724799d + "'", double1 == 0.7877193267724799d);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException9);
        java.lang.Number number11 = numberIsTooLargeException4.getMax();
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable12, (java.lang.Number) 100L);
        java.lang.Number number17 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable12, (java.lang.Number) 2.5083432919410233d, (java.lang.Number) 10.693737673234912d, number17);
        java.lang.Number number19 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable12, number19);
        java.lang.Throwable throwable21 = null;
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(throwable21);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException("hi!", objArray28);
        java.lang.Class<?> wildcardClass30 = objArray28.getClass();
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException(throwable21, localizable23, objArray28);
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Object[] objArray36 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, objArray36);
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException31, localizable32, objArray36);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException39 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, localizable12, objArray36);
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException44 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable40, (java.lang.Number) 2.0198227150790538d, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException44);
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        java.lang.Object[] objArray51 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException52 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable48, objArray51);
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException("3d787e85ce", objArray51);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException45, "fd4ecaf23f", objArray51);
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException(localizable12, objArray51);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException59 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, (java.lang.Number) 2.126048628120582d, (java.lang.Number) 0.9999999999999999d, true);
        org.apache.commons.math.exception.util.Localizable localizable60 = numberIsTooSmallException59.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 2.718281828459045d + "'", number11.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertTrue("'" + localizable60 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable60.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 2.9217470313908858d, (java.lang.Number) 2.671098070241836d, (java.lang.Number) Double.POSITIVE_INFINITY);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        double double1 = org.apache.commons.math.util.FastMath.signum(6.694072288474383d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test460");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        int int4 = randomDataImpl0.nextInt(0, (int) (short) 1);
//        double double7 = randomDataImpl0.nextF(9.209654244869128d, 1.269076108061911d);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.437683005020742d + "'", double7 == 2.437683005020742d);
//    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 14, 2L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 10);
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException("hi!", objArray10);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable5, objArray10);
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException12);
        java.lang.Object[] objArray14 = mathException13.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, objArray18);
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException19);
        org.apache.commons.math.exception.util.Localizable localizable21 = mathException20.getGeneralPattern();
        java.lang.Object[] objArray22 = null;
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException(localizable21, objArray22);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable26, objArray29);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException("3d787e85ce", objArray29);
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException(localizable24, objArray29);
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException13, localizable21, objArray29);
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException1, localizable3, objArray29);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray29);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 11.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11.0d + "'", double2 == 11.0d);
    }

//    @Test
//    public void test464() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test464");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double5 = randomDataImpl0.nextExponential(Double.NaN);
//        double double8 = randomDataImpl0.nextCauchy(0.019691932154573932d, 0.9969748643467198d);
//        org.apache.commons.math.distribution.ContinuousDistribution continuousDistribution9 = null;
//        try {
//            double double10 = randomDataImpl0.nextInversionDeviate(continuousDistribution9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.165748307926729d + "'", double3 == 3.165748307926729d);
//        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.667796627427087d + "'", double8 == 6.667796627427087d);
//    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        double double1 = org.apache.commons.math.util.FastMath.floor((-0.02012092213614458d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("hi!", objArray7);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, localizable2, objArray7);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException("76b6a5e15f", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) 2.0198227150790538d, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooSmallException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, objArray22);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("3d787e85ce", objArray22);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException(localizable17, objArray22);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException(localizable16, objArray22);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException31 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException36 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable32, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException31.addSuppressed((java.lang.Throwable) numberIsTooSmallException36);
        java.lang.Number number38 = numberIsTooLargeException31.getMax();
        org.apache.commons.math.exception.util.Localizable localizable39 = numberIsTooLargeException31.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        java.lang.Object[] objArray43 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException44 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable40, objArray43);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException45 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable39, objArray43);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException49 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable39, (java.lang.Number) 0.0015107907377931822d, (java.lang.Number) (-0.5961722400471147d), true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException51 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable39, (java.lang.Number) 32L);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException53 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 10);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException();
        notStrictlyPositiveException53.addSuppressed((java.lang.Throwable) mathException54);
        org.apache.commons.math.exception.util.Localizable localizable56 = mathException54.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException61 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable57, objArray60);
        org.apache.commons.math.MathException mathException62 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException61);
        java.lang.Throwable throwable66 = null;
        org.apache.commons.math.exception.util.Localizable localizable68 = null;
        org.apache.commons.math.exception.util.Localizable localizable70 = null;
        java.lang.Object[] objArray73 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException74 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable70, objArray73);
        org.apache.commons.math.MathException mathException75 = new org.apache.commons.math.MathException("3d787e85ce", objArray73);
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException(localizable68, objArray73);
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException(throwable66, "org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)", objArray73);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException78 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100, "76b6a5e15f", objArray73);
        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalArgumentException61, "28fc800164", objArray73);
        org.apache.commons.math.ConvergenceException convergenceException80 = new org.apache.commons.math.ConvergenceException(localizable56, objArray73);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException81 = new org.apache.commons.math.MaxIterationsExceededException(100, localizable39, objArray73);
        org.apache.commons.math.ConvergenceException convergenceException82 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException10, localizable16, objArray73);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException86 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable16, (java.lang.Number) 0.348749002417799d, (java.lang.Number) 3.2599328220069594d, true);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + 2.718281828459045d + "'", number38.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable39.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertTrue("'" + localizable56 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable56.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(objArray73);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.3267237890202268d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test468() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test468");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextF(2.718281828459045d, (double) 100);
//        long long6 = randomDataImpl0.nextLong((long) 0, (long) (short) 1);
//        long long8 = randomDataImpl0.nextPoisson(0.2522737922403927d);
//        randomDataImpl0.reSeed();
//        double double11 = randomDataImpl0.nextChiSquare(3.026562968104169d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.3580107368658227d + "'", double3 == 1.3580107368658227d);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0362123549252455d + "'", double11 == 4.0362123549252455d);
//    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 10, (long) 59);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("hi!", objArray7);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, localizable2, objArray7);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException("76b6a5e15f", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) 2.0198227150790538d, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooSmallException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, objArray22);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("3d787e85ce", objArray22);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException(localizable17, objArray22);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException(localizable16, objArray22);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException31 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException36 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable32, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException31.addSuppressed((java.lang.Throwable) numberIsTooSmallException36);
        java.lang.Number number38 = numberIsTooLargeException31.getMax();
        org.apache.commons.math.exception.util.Localizable localizable39 = numberIsTooLargeException31.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        java.lang.Object[] objArray43 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException44 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable40, objArray43);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException45 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable39, objArray43);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException49 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable39, (java.lang.Number) 0.0015107907377931822d, (java.lang.Number) (-0.5961722400471147d), true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException51 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable39, (java.lang.Number) 32L);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException53 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 10);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException();
        notStrictlyPositiveException53.addSuppressed((java.lang.Throwable) mathException54);
        org.apache.commons.math.exception.util.Localizable localizable56 = mathException54.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException61 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable57, objArray60);
        org.apache.commons.math.MathException mathException62 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException61);
        java.lang.Throwable throwable66 = null;
        org.apache.commons.math.exception.util.Localizable localizable68 = null;
        org.apache.commons.math.exception.util.Localizable localizable70 = null;
        java.lang.Object[] objArray73 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException74 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable70, objArray73);
        org.apache.commons.math.MathException mathException75 = new org.apache.commons.math.MathException("3d787e85ce", objArray73);
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException(localizable68, objArray73);
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException(throwable66, "org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)", objArray73);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException78 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100, "76b6a5e15f", objArray73);
        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalArgumentException61, "28fc800164", objArray73);
        org.apache.commons.math.ConvergenceException convergenceException80 = new org.apache.commons.math.ConvergenceException(localizable56, objArray73);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException81 = new org.apache.commons.math.MaxIterationsExceededException(100, localizable39, objArray73);
        org.apache.commons.math.ConvergenceException convergenceException82 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException10, localizable16, objArray73);
        java.lang.Object[] objArray83 = convergenceException82.getArguments();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + 2.718281828459045d + "'", number38.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable39.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertTrue("'" + localizable56 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable56.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(objArray73);
        org.junit.Assert.assertNotNull(objArray83);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(5.597469078647064d, 3.3801446234597954d, 6.959823011942314d, 52);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.09062867452297892d + "'", double4 == 0.09062867452297892d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        java.lang.Number number10 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray15);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray15);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 0.0015107907377931822d, (java.lang.Number) (-0.5961722400471147d), true);
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable22, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        boolean boolean27 = numberIsTooSmallException26.getBoundIsAllowed();
        java.lang.Number number28 = numberIsTooSmallException26.getMin();
        org.apache.commons.math.exception.util.Localizable localizable29 = numberIsTooSmallException26.getSpecificPattern();
        java.lang.Number number30 = numberIsTooSmallException26.getArgument();
        java.lang.Object[] objArray31 = numberIsTooSmallException26.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException(localizable11, objArray31);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException("hi!", objArray39);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, localizable34, objArray39);
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException41);
        java.lang.Object[] objArray43 = mathException42.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        java.lang.Object[] objArray47 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable44, objArray47);
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException48);
        org.apache.commons.math.exception.util.Localizable localizable50 = mathException49.getGeneralPattern();
        java.lang.Object[] objArray51 = null;
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException(localizable50, objArray51);
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        java.lang.Object[] objArray58 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable55, objArray58);
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException("3d787e85ce", objArray58);
        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException(localizable53, objArray58);
        org.apache.commons.math.MathException mathException62 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException42, localizable50, objArray58);
        java.lang.Object[] objArray67 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException("hi!", objArray67);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException69 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable50, objArray67);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 2.718281828459045d + "'", number10.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 22025.465794806718d + "'", number28.equals(22025.465794806718d));
        org.junit.Assert.assertNull(localizable29);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 1L + "'", number30.equals(1L));
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertTrue("'" + localizable50 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable50.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(objArray67);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(2.3781075965944165d, 0.0d, (-0.8414709848078964d), 31);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(3.261817294378018d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8060501915445257d + "'", double1 == 1.8060501915445257d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        java.lang.Number number10 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooLargeException3.getGeneralPattern();
        java.lang.Class<?> wildcardClass12 = numberIsTooLargeException3.getClass();
        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooLargeException3.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 2.718281828459045d + "'", number10.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.2851476301750329d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8578503848234681d + "'", double1 == 0.8578503848234681d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException9);
        java.lang.Number number11 = numberIsTooLargeException4.getMax();
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Number number14 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, (java.lang.Number) (-0.46046391868746567d), number14, false);
        java.lang.Object[] objArray21 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray21);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException(localizable12, objArray21);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("9913e0bd71", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable25 = convergenceException24.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException(localizable27, objArray28);
        org.apache.commons.math.exception.util.Localizable localizable30 = convergenceException29.getGeneralPattern();
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException29);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException35 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException40 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable36, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException35.addSuppressed((java.lang.Throwable) numberIsTooSmallException40);
        java.lang.Number number42 = numberIsTooLargeException35.getMax();
        org.apache.commons.math.exception.util.Localizable localizable43 = numberIsTooLargeException35.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException47 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException52 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable48, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException47.addSuppressed((java.lang.Throwable) numberIsTooSmallException52);
        java.lang.Number number54 = numberIsTooLargeException47.getMax();
        org.apache.commons.math.exception.util.Localizable localizable55 = numberIsTooLargeException47.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        java.lang.Object[] objArray59 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException60 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable56, objArray59);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException61 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable55, objArray59);
        org.apache.commons.math.MathException mathException62 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException29, localizable43, objArray59);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable25, localizable26, objArray59);
        java.lang.Number number64 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException67 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable25, number64, (java.lang.Number) 100.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable68 = null;
        org.apache.commons.math.exception.util.Localizable localizable69 = null;
        org.apache.commons.math.exception.util.Localizable localizable71 = null;
        java.lang.Object[] objArray74 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException75 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable71, objArray74);
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException("3d787e85ce", objArray74);
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException(localizable69, objArray74);
        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException67, localizable68, objArray74);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 2.718281828459045d + "'", number11.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(localizable25);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNull(localizable30);
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 2.718281828459045d + "'", number42.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable43.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number54 + "' != '" + 2.718281828459045d + "'", number54.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable55.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNotNull(objArray74);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.9964266069777534d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.002073138951270259d + "'", double1 == 0.002073138951270259d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) 1.3691506489023308d, true);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(8.197882265619114d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.197882265619116d + "'", double1 == 8.197882265619116d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.20749212811249568d, 2.5183587988880425d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.08220612467130392d + "'", double2 == 0.08220612467130392d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        double double1 = org.apache.commons.math.util.FastMath.asin(9.223277148751583d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        java.lang.Number number10 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray15);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray15);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 0.0015107907377931822d, (java.lang.Number) (-0.5961722400471147d), true);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException25 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 1.710071082755576d, (java.lang.Number) 0.010267204459686558d, true);
        java.lang.Class<?> wildcardClass26 = numberIsTooLargeException25.getClass();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 2.718281828459045d + "'", number10.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(wildcardClass26);
    }

//    @Test
//    public void test484() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test484");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        double double11 = randomDataImpl0.nextCauchy(4.600161852571429d, 2.6508641820894225d);
//        randomDataImpl0.reSeedSecure((long) (byte) 0);
//        double double16 = randomDataImpl0.nextF(3.3489941619972536d, (double) 30);
//        try {
//            double double19 = randomDataImpl0.nextF(0.004507444232417268d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.2192760340361923d + "'", double3 == 3.2192760340361923d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.800959872279871d + "'", double6 == 1.800959872279871d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.4783794912374897d + "'", double11 == 1.4783794912374897d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.3218559746561429d + "'", double16 == 0.3218559746561429d);
//    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException(throwable0);
        java.lang.Class<?> wildcardClass2 = convergenceException1.getClass();
        org.apache.commons.math.exception.util.Localizable localizable3 = convergenceException1.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable3, (java.lang.Number) 5.521684663007721d);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        boolean boolean5 = numberIsTooSmallException4.getBoundIsAllowed();
        java.lang.Number number6 = numberIsTooSmallException4.getMin();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException4.getSpecificPattern();
        java.lang.Number number8 = numberIsTooSmallException4.getArgument();
        java.lang.Object[] objArray9 = numberIsTooSmallException4.getArguments();
        java.lang.Object[] objArray10 = numberIsTooSmallException4.getArguments();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 22025.465794806718d + "'", number6.equals(22025.465794806718d));
        org.junit.Assert.assertNull(localizable7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1L + "'", number8.equals(1L));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray10);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        java.lang.Number number10 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooLargeException3.getGeneralPattern();
        java.lang.Number number13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) (-0.46046391868746567d), number13, false);
        java.lang.Object[] objArray20 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException("hi!", objArray20);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(localizable11, objArray20);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) 0.5693386188584106d, (java.lang.Number) 6.503243247425703d, false);
        java.lang.Throwable throwable27 = null;
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException(throwable27);
        java.lang.Class<?> wildcardClass29 = convergenceException28.getClass();
        org.apache.commons.math.exception.util.Localizable localizable30 = convergenceException28.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException34 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        java.lang.String str35 = numberIsTooSmallException34.toString();
        java.lang.Object[] objArray36 = numberIsTooSmallException34.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable30, objArray36);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException(localizable38, objArray39);
        org.apache.commons.math.exception.util.Localizable localizable41 = convergenceException40.getGeneralPattern();
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException40);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException46 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable47 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException51 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable47, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException46.addSuppressed((java.lang.Throwable) numberIsTooSmallException51);
        java.lang.Number number53 = numberIsTooLargeException46.getMax();
        org.apache.commons.math.exception.util.Localizable localizable54 = numberIsTooLargeException46.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException58 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException63 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable59, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException58.addSuppressed((java.lang.Throwable) numberIsTooSmallException63);
        java.lang.Number number65 = numberIsTooLargeException58.getMax();
        org.apache.commons.math.exception.util.Localizable localizable66 = numberIsTooLargeException58.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable67 = null;
        java.lang.Object[] objArray70 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException71 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable67, objArray70);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException72 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable66, objArray70);
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException40, localizable54, objArray70);
        org.apache.commons.math.MathException mathException74 = new org.apache.commons.math.MathException(localizable30, objArray70);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 2.718281828459045d + "'", number10.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (0)" + "'", str35.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNull(localizable41);
        org.junit.Assert.assertTrue("'" + number53 + "' != '" + 2.718281828459045d + "'", number53.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable54 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable54.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number65 + "' != '" + 2.718281828459045d + "'", number65.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable66 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable66.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray70);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1L), (java.lang.Number) 0.09261919812827801d, false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 4.097470561084089d, (java.lang.Number) 2.5139994585534726d, (java.lang.Number) 7.164591543681963d);
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException10.addSuppressed((java.lang.Throwable) numberIsTooSmallException15);
        java.lang.Number number17 = numberIsTooLargeException10.getMax();
        org.apache.commons.math.exception.util.Localizable localizable18 = numberIsTooLargeException10.getGeneralPattern();
        java.lang.Object[] objArray23 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("hi!", objArray23);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable18, objArray23);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException(387632512, localizable5, objArray23);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException30 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        maxIterationsExceededException26.addSuppressed((java.lang.Throwable) numberIsTooLargeException30);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException35 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException40 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable36, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException35.addSuppressed((java.lang.Throwable) numberIsTooSmallException40);
        java.lang.Number number42 = numberIsTooLargeException35.getMax();
        org.apache.commons.math.exception.util.Localizable localizable43 = numberIsTooLargeException35.getGeneralPattern();
        java.lang.Number number45 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException47 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable43, (java.lang.Number) (-0.46046391868746567d), number45, false);
        java.lang.Object[] objArray52 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException("hi!", objArray52);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException(localizable43, objArray52);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException58 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable43, (java.lang.Number) 0.5693386188584106d, (java.lang.Number) 6.503243247425703d, false);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException63 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable64 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException68 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable64, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException63.addSuppressed((java.lang.Throwable) numberIsTooSmallException68);
        java.lang.Number number70 = numberIsTooLargeException63.getMax();
        org.apache.commons.math.exception.util.Localizable localizable71 = numberIsTooLargeException63.getGeneralPattern();
        java.lang.Number number73 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException75 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable71, (java.lang.Number) (-0.46046391868746567d), number73, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException79 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable71, (java.lang.Number) 3.081725078478352d, (java.lang.Number) (-1.0d), true);
        org.apache.commons.math.exception.util.Localizable localizable80 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException84 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable80, (java.lang.Number) 2.0198227150790538d, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.exception.util.Localizable localizable85 = numberIsTooSmallException84.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable86 = null;
        org.apache.commons.math.exception.util.Localizable localizable88 = null;
        java.lang.Object[] objArray91 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException92 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable88, objArray91);
        org.apache.commons.math.MathException mathException93 = new org.apache.commons.math.MathException("3d787e85ce", objArray91);
        org.apache.commons.math.MathException mathException94 = new org.apache.commons.math.MathException(localizable86, objArray91);
        org.apache.commons.math.MathException mathException95 = new org.apache.commons.math.MathException(localizable85, objArray91);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException96 = new org.apache.commons.math.MaxIterationsExceededException((-1), localizable71, objArray91);
        org.apache.commons.math.ConvergenceException convergenceException97 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException30, localizable43, objArray91);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 2.718281828459045d + "'", number17.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 2.718281828459045d + "'", number42.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable43.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertTrue("'" + number70 + "' != '" + 2.718281828459045d + "'", number70.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable71 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable71.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + localizable85 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable85.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray91);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        int int2 = org.apache.commons.math.util.FastMath.min(2, 62);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        java.lang.Object[] objArray4 = new java.lang.Object[] { 3.550128012953764d, 2.99822295029797d, 2.657796346323199d };
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.MathException: ", objArray4);
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException5);
        org.junit.Assert.assertNotNull(objArray4);
    }

//    @Test
//    public void test492() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test492");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        java.lang.String str5 = randomDataImpl0.nextSecureHexString(10);
//        try {
//            double double8 = randomDataImpl0.nextGaussian(0.0d, (-0.19563207552233094d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.196 is smaller than, or equal to, the minimum (0): standard deviation (-0.196)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0088659180962694d + "'", double3 == 3.0088659180962694d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "f9ed6e8112" + "'", str5.equals("f9ed6e8112"));
//    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.20749212811249568d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.20901059379242845d + "'", double1 == 0.20901059379242845d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        double double1 = org.apache.commons.math.util.FastMath.cos(3.9996224102941014d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6539293350921606d) + "'", double1 == (-0.6539293350921606d));
    }

//    @Test
//    public void test495() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test495");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        java.lang.String str3 = randomDataImpl0.nextHexString((int) (short) 1);
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "8" + "'", str3.equals("8"));
//    }

//    @Test
//    public void test496() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test496");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextGaussian(3596.5509605926745d, 2.679253032980602d);
//        int int9 = randomDataImpl0.nextBinomial(30, 0.4834571078418192d);
//        try {
//            java.lang.String str11 = randomDataImpl0.nextSecureHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.277928795837115d + "'", double3 == 3.277928795837115d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3598.4594262769615d + "'", double6 == 3598.4594262769615d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 12 + "'", int9 == 12);
//    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.5772156649015329d, 0.5403023058681398d, 2.6508641820894225d);
        double double5 = normalDistributionImpl3.density((double) 1);
        double[] doubleArray7 = normalDistributionImpl3.sample((int) '#');
        java.lang.Class<?> wildcardClass8 = normalDistributionImpl3.getClass();
        double double10 = normalDistributionImpl3.cumulativeProbability((double) 11);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5436432847461893d + "'", double5 == 0.5436432847461893d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        double double1 = org.apache.commons.math.util.FastMath.exp(9.223277148751583d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10130.208188923982d + "'", double1 == 10130.208188923982d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        double double2 = org.apache.commons.math.util.FastMath.max(3.0172641870720844d, (double) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 1, (java.lang.Number) 2.302585092994046d, false);
        java.lang.Number number5 = numberIsTooSmallException4.getArgument();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 1 + "'", number5.equals((short) 1));
    }
}

