import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.9969748643467198d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9969748643467198d + "'", double1 == 0.9969748643467198d);
    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test002");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        java.lang.String str3 = randomDataImpl0.nextHexString((int) (short) 1);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double8 = normalDistributionImpl7.getMean();
//        double double10 = normalDistributionImpl7.density((double) (short) 1);
//        double double11 = normalDistributionImpl7.sample();
//        double[] doubleArray13 = normalDistributionImpl7.sample((int) (short) 10);
//        double double16 = normalDistributionImpl7.cumulativeProbability(2.0198227150790538d, (double) 100);
//        double double17 = normalDistributionImpl7.sample();
//        double double18 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        int int22 = randomDataImpl0.nextHypergeometric((int) (byte) 100, (int) (short) 1, (int) (short) 0);
//        java.lang.Class<?> wildcardClass23 = randomDataImpl0.getClass();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl26 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double27 = normalDistributionImpl26.getMean();
//        double double29 = normalDistributionImpl26.density((double) (short) 1);
//        double double30 = normalDistributionImpl26.sample();
//        double[] doubleArray32 = normalDistributionImpl26.sample((int) (short) 10);
//        double double35 = normalDistributionImpl26.cumulativeProbability(2.0198227150790538d, (double) 100);
//        double double36 = normalDistributionImpl26.getStandardDeviation();
//        double double38 = normalDistributionImpl26.cumulativeProbability(2.4946330620091928d);
//        normalDistributionImpl26.reseedRandomGenerator(21L);
//        double double41 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl26);
//        double double42 = normalDistributionImpl26.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "d" + "'", str3.equals("d"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 7.544137102816975d + "'", double8 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.01610846091529747d + "'", double10 == 0.01610846091529747d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.078511683669594d + "'", double11 == 10.078511683669594d);
//        org.junit.Assert.assertNotNull(doubleArray13);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.9556007738814948d + "'", double16 == 0.9556007738814948d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 12.472589032283635d + "'", double17 == 12.472589032283635d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 11.846024578209981d + "'", double18 == 11.846024578209981d);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 7.544137102816975d + "'", double27 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.01610846091529747d + "'", double29 == 0.01610846091529747d);
//        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 10.195227906358404d + "'", double30 == 10.195227906358404d);
//        org.junit.Assert.assertNotNull(doubleArray32);
//        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.9556007738814948d + "'", double35 == 0.9556007738814948d);
//        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 3.246216406046493d + "'", double36 == 3.246216406046493d);
//        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.059912988687569446d + "'", double38 == 0.059912988687569446d);
//        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 3.8398472019810224d + "'", double41 == 3.8398472019810224d);
//        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 3.246216406046493d + "'", double42 == 3.246216406046493d);
//    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 10);
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException();
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) mathException2);
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException2.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException8.addSuppressed((java.lang.Throwable) numberIsTooSmallException13);
        java.lang.Number number15 = numberIsTooLargeException8.getMax();
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooLargeException8.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable16, (java.lang.Number) 100L);
        java.lang.Object[] objArray23 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("hi!", objArray23);
        java.lang.Class<?> wildcardClass25 = objArray23.getClass();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable16, objArray23);
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException28 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, number27);
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable31, objArray32);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException37 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable38, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException37.addSuppressed((java.lang.Throwable) numberIsTooSmallException42);
        java.lang.Number number44 = numberIsTooLargeException37.getMax();
        org.apache.commons.math.exception.util.Localizable localizable45 = numberIsTooLargeException37.getGeneralPattern();
        java.lang.Number number47 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException49 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable45, (java.lang.Number) (-0.46046391868746567d), number47, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException53 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable45, (java.lang.Number) 3.081725078478352d, (java.lang.Number) (-1.0d), true);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException58 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException63 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable59, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException58.addSuppressed((java.lang.Throwable) numberIsTooSmallException63);
        java.lang.Number number65 = numberIsTooLargeException58.getMax();
        org.apache.commons.math.exception.util.Localizable localizable66 = numberIsTooLargeException58.getGeneralPattern();
        java.lang.Object[] objArray71 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException72 = new org.apache.commons.math.MathException("hi!", objArray71);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException73 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable66, objArray71);
        org.apache.commons.math.MathException mathException74 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException33, localizable45, objArray71);
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException("28fc800164", objArray71);
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException(localizable4, objArray71);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 2.718281828459045d + "'", number15.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + number44 + "' != '" + 2.718281828459045d + "'", number44.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number65 + "' != '" + 2.718281828459045d + "'", number65.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable66 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable66.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray71);
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test004");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double5 = randomDataImpl0.nextExponential(Double.NaN);
//        double double8 = randomDataImpl0.nextGamma(0.07667242456653145d, 2.9785182458240125d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.2285504031440055d + "'", double3 == 3.2285504031440055d);
//        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.657915108914173E-5d + "'", double8 == 6.657915108914173E-5d);
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.017144266906994998d);
    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test006");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double5 = randomDataImpl0.nextExponential(Double.NaN);
//        double double8 = randomDataImpl0.nextGamma((double) (byte) 1, (double) 10.0f);
//        double double11 = randomDataImpl0.nextF(1.1995416045736986d, 0.01610846091529747d);
//        randomDataImpl0.reSeed();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.2234355207435805d + "'", double3 == 3.2234355207435805d);
//        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 11.757720180599012d + "'", double8 == 11.757720180599012d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 588.2767707514694d + "'", double11 == 588.2767707514694d);
//    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test007");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double5 = randomDataImpl0.nextExponential(Double.NaN);
//        double double8 = randomDataImpl0.nextUniform(0.9969748643467198d, 6.798056507791588d);
//        randomDataImpl0.reSeedSecure(100L);
//        int int13 = randomDataImpl0.nextZipf((int) '#', 2.0198227150790538d);
//        double double15 = randomDataImpl0.nextChiSquare(0.9970011109715183d);
//        try {
//            int int18 = randomDataImpl0.nextBinomial(10, (double) 2);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 2 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.2249821501370937d + "'", double3 == 3.2249821501370937d);
//        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 5.099821438892764d + "'", double8 == 5.099821438892764d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.6477299404584671d + "'", double15 == 0.6477299404584671d);
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 100, 20);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (short) 10, number1, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        double double1 = org.apache.commons.math.special.Gamma.digamma(0.348749002417799d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.982668147740755d) + "'", double1 == (-2.982668147740755d));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        float float2 = org.apache.commons.math.util.FastMath.min(19.0f, 10.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        double double2 = org.apache.commons.math.util.FastMath.max(1.7810326922016206d, 2.8984643541554194d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.8984643541554194d + "'", double2 == 2.8984643541554194d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.5614628358856488d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5614628358856488d + "'", double1 == 1.5614628358856488d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 10, 74.20321057778875d, 5.923769104490098d, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: Continued fraction convergents failed to converge (in less than 74.203 iterations) for value {1}");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.2432461722919452d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException9);
        java.lang.Number number11 = numberIsTooLargeException4.getMax();
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math.exception.OutOfRangeException(localizable12, (java.lang.Number) (-6.816718961678583d), (java.lang.Number) 3.20459618189556d, (java.lang.Number) 5.169076857913174d);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        boolean boolean22 = numberIsTooSmallException21.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooSmallException21.getSpecificPattern();
        java.lang.Object[] objArray24 = numberIsTooSmallException21.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException(1, localizable12, objArray24);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException29 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.0f, (java.lang.Number) 2.718281828459045d, true);
        boolean boolean30 = numberIsTooLargeException29.getBoundIsAllowed();
        maxIterationsExceededException25.addSuppressed((java.lang.Throwable) numberIsTooLargeException29);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 2.718281828459045d + "'", number11.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(localizable23);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test017");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        java.lang.String str3 = randomDataImpl0.nextHexString((int) (short) 1);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double8 = normalDistributionImpl7.getMean();
//        double double10 = normalDistributionImpl7.density((double) (short) 1);
//        double double11 = normalDistributionImpl7.sample();
//        double[] doubleArray13 = normalDistributionImpl7.sample((int) (short) 10);
//        double double16 = normalDistributionImpl7.cumulativeProbability(2.0198227150790538d, (double) 100);
//        double double17 = normalDistributionImpl7.sample();
//        double double18 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        int int22 = randomDataImpl0.nextHypergeometric((int) (byte) 100, (int) (short) 1, (int) (short) 0);
//        java.lang.Class<?> wildcardClass23 = randomDataImpl0.getClass();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl26 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double27 = normalDistributionImpl26.getMean();
//        double double29 = normalDistributionImpl26.density((double) (short) 1);
//        double double30 = normalDistributionImpl26.sample();
//        double[] doubleArray32 = normalDistributionImpl26.sample((int) (short) 10);
//        double double35 = normalDistributionImpl26.cumulativeProbability(2.0198227150790538d, (double) 100);
//        double double36 = normalDistributionImpl26.getStandardDeviation();
//        double double38 = normalDistributionImpl26.cumulativeProbability(2.4946330620091928d);
//        normalDistributionImpl26.reseedRandomGenerator(21L);
//        double double41 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl26);
//        randomDataImpl0.reSeed();
//        try {
//            double double44 = randomDataImpl0.nextT((-0.5961722400471147d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.596 is smaller than, or equal to, the minimum (0): degrees of freedom (-0.596)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "b" + "'", str3.equals("b"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 7.544137102816975d + "'", double8 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.01610846091529747d + "'", double10 == 0.01610846091529747d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 11.666612484178751d + "'", double11 == 11.666612484178751d);
//        org.junit.Assert.assertNotNull(doubleArray13);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.9556007738814948d + "'", double16 == 0.9556007738814948d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 6.685503763071427d + "'", double17 == 6.685503763071427d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 9.919987061867294d + "'", double18 == 9.919987061867294d);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 7.544137102816975d + "'", double27 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.01610846091529747d + "'", double29 == 0.01610846091529747d);
//        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 7.6439192047926285d + "'", double30 == 7.6439192047926285d);
//        org.junit.Assert.assertNotNull(doubleArray32);
//        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.9556007738814948d + "'", double35 == 0.9556007738814948d);
//        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 3.246216406046493d + "'", double36 == 3.246216406046493d);
//        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.059912988687569446d + "'", double38 == 0.059912988687569446d);
//        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 8.797554293380191d + "'", double41 == 8.797554293380191d);
//    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test018");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double3 = normalDistributionImpl2.getMean();
//        double double5 = normalDistributionImpl2.density((double) (short) 1);
//        double double6 = normalDistributionImpl2.sample();
//        double[] doubleArray8 = normalDistributionImpl2.sample((int) (short) 10);
//        double double11 = normalDistributionImpl2.cumulativeProbability(2.0198227150790538d, (double) 100);
//        double double12 = normalDistributionImpl2.getStandardDeviation();
//        double double14 = normalDistributionImpl2.cumulativeProbability(2.4946330620091928d);
//        normalDistributionImpl2.reseedRandomGenerator(21L);
//        double double17 = normalDistributionImpl2.getMean();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.544137102816975d + "'", double3 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.01610846091529747d + "'", double5 == 0.01610846091529747d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 9.779233584009777d + "'", double6 == 9.779233584009777d);
//        org.junit.Assert.assertNotNull(doubleArray8);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.9556007738814948d + "'", double11 == 0.9556007738814948d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.246216406046493d + "'", double12 == 3.246216406046493d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.059912988687569446d + "'", double14 == 0.059912988687569446d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 7.544137102816975d + "'", double17 == 7.544137102816975d);
//    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        double double1 = org.apache.commons.math.util.FastMath.tan(5.734168005807173d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6117539339169925d) + "'", double1 == (-0.6117539339169925d));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        double double1 = org.apache.commons.math.util.FastMath.atanh(7.152687870583286d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 10.626321166078844d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        double double1 = org.apache.commons.math.special.Erf.erf(4.019808360419707d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999869085883d + "'", double1 == 0.9999999869085883d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 21, (long) 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 21L + "'", long2 == 21L);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.5401832317931035d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.43190139103161207d + "'", double1 == 0.43190139103161207d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray6);
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("3d787e85ce", objArray6);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)", objArray6);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable15, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException14.addSuppressed((java.lang.Throwable) numberIsTooSmallException19);
        java.lang.Number number21 = numberIsTooLargeException14.getMax();
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooLargeException14.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException24 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable22, (java.lang.Number) 100L);
        java.lang.Object[] objArray25 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, objArray25);
        java.lang.Object[] objArray27 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException(32, localizable22, objArray27);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException30 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 10);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException();
        notStrictlyPositiveException30.addSuppressed((java.lang.Throwable) mathException31);
        org.apache.commons.math.exception.util.Localizable localizable33 = mathException31.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException37 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable38, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException37.addSuppressed((java.lang.Throwable) numberIsTooSmallException42);
        java.lang.Number number44 = numberIsTooLargeException37.getMax();
        org.apache.commons.math.exception.util.Localizable localizable45 = numberIsTooLargeException37.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException47 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable45, (java.lang.Number) 100L);
        java.lang.Object[] objArray52 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException("hi!", objArray52);
        java.lang.Class<?> wildcardClass54 = objArray52.getClass();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException55 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, localizable45, objArray52);
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException9, localizable22, objArray52);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException61 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable62 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException66 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable62, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException61.addSuppressed((java.lang.Throwable) numberIsTooSmallException66);
        java.lang.Number number68 = numberIsTooLargeException61.getMax();
        org.apache.commons.math.exception.util.Localizable localizable69 = numberIsTooLargeException61.getGeneralPattern();
        java.lang.Number number71 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException73 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable69, (java.lang.Number) (-0.46046391868746567d), number71, false);
        org.apache.commons.math.exception.util.Localizable localizable76 = null;
        java.lang.Object[] objArray77 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException78 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable76, objArray77);
        org.apache.commons.math.MathException mathException79 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException73, "6", objArray77);
        org.apache.commons.math.MathException mathException80 = new org.apache.commons.math.MathException("aa2def9f6e", objArray77);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException81 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, objArray77);
        org.apache.commons.math.exception.util.Localizable localizable82 = null;
        java.lang.Object[] objArray85 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException86 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable82, objArray85);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException87 = new org.apache.commons.math.MaxIterationsExceededException(59, localizable22, objArray85);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 2.718281828459045d + "'", number21.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + localizable33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable33.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + number44 + "' != '" + 2.718281828459045d + "'", number44.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertTrue("'" + number68 + "' != '" + 2.718281828459045d + "'", number68.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable69 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable69.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray77);
        org.junit.Assert.assertNotNull(objArray85);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.787066582172498d, (java.lang.Number) 1.787066582172498d, (java.lang.Number) 2.4053027645871077d);
        java.lang.Number number4 = outOfRangeException3.getLo();
        java.lang.Number number5 = outOfRangeException3.getHi();
        java.lang.Number number6 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.787066582172498d + "'", number4.equals(1.787066582172498d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 2.4053027645871077d + "'", number5.equals(2.4053027645871077d));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.787066582172498d + "'", number6.equals(1.787066582172498d));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) 387632507);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.2780206022282715E9d + "'", double1 == 7.2780206022282715E9d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(2.4946330620091928d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.280916140616418d + "'", double1 == 0.280916140616418d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.9604209204271249d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        int int2 = org.apache.commons.math.util.FastMath.max(20, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getSpecificPattern();
        org.junit.Assert.assertNull(localizable1);
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test032");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        double double11 = randomDataImpl0.nextCauchy(2.99822295029797d, 7.8726391065033505d);
//        try {
//            randomDataImpl0.setSecureAlgorithm("org.apache.commons.math.exception.NumberIsTooSmallException: 2.02 is smaller than, or equal to, the minimum (1)", "");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.1972288689895527d + "'", double3 == 3.1972288689895527d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.8883553634188426d + "'", double6 == 1.8883553634188426d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 5.743214756908578d + "'", double11 == 5.743214756908578d);
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 8.845455831739777d, (java.lang.Number) 6.176287125823654d, true);
        java.lang.Class<?> wildcardClass4 = numberIsTooLargeException3.getClass();
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test034");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        double double11 = randomDataImpl0.nextWeibull(43.29757019802005d, 2.496597880203421d);
//        double double14 = randomDataImpl0.nextGamma((double) '4', 0.1053020545734041d);
//        long long17 = randomDataImpl0.nextSecureLong(0L, (long) 30);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.2204811915823863d + "'", double3 == 3.2204811915823863d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.4517482776428494d + "'", double6 == 3.4517482776428494d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.524761735101839d + "'", double11 == 2.524761735101839d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 5.289402380247466d + "'", double14 == 5.289402380247466d);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 8L + "'", long17 == 8L);
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0d);
        java.lang.Number number2 = notStrictlyPositiveException1.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException1.getSpecificPattern();
        java.lang.Number number4 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 1.0d + "'", number2.equals(1.0d));
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException5.addSuppressed((java.lang.Throwable) numberIsTooSmallException10);
        java.lang.Number number12 = numberIsTooLargeException5.getMax();
        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooLargeException5.getGeneralPattern();
        java.lang.Number number15 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable13, (java.lang.Number) (-0.46046391868746567d), number15, false);
        java.lang.Object[] objArray22 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException("hi!", objArray22);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException(localizable13, objArray22);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException("9913e0bd71", objArray22);
        org.apache.commons.math.exception.util.Localizable localizable26 = convergenceException25.getGeneralPattern();
        java.lang.Object[] objArray33 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException("hi!", objArray33);
        java.lang.Class<?> wildcardClass35 = objArray33.getClass();
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException("3d787e85ce", objArray33);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException25, "4885561af9", objArray33);
        java.lang.Throwable[] throwableArray38 = convergenceException25.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.ConvergenceException: b0f617732c", (java.lang.Object[]) throwableArray38);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 2.718281828459045d + "'", number12.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(localizable26);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(throwableArray38);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(9.999999995E-10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.000000001E18d + "'", double1 == 1.000000001E18d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        long long1 = org.apache.commons.math.util.FastMath.round(0.20749212811249568d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 2.710071082755576d, (java.lang.Number) 7.544137102816975d, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getSpecificPattern();
        java.lang.Throwable[] throwableArray6 = numberIsTooSmallException4.getSuppressed();
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100);
        org.apache.commons.math.exception.util.Localizable localizable2 = maxIterationsExceededException1.getSpecificPattern();
        int int3 = maxIterationsExceededException1.getMaxIterations();
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException1);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 2.0198227150790538d, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException9);
        org.apache.commons.math.exception.util.Localizable localizable11 = convergenceException10.getGeneralPattern();
        mathException4.addSuppressed((java.lang.Throwable) convergenceException10);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException16 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException16.addSuppressed((java.lang.Throwable) numberIsTooSmallException21);
        java.lang.Number number23 = numberIsTooLargeException16.getMax();
        org.apache.commons.math.exception.util.Localizable localizable24 = numberIsTooLargeException16.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException26 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable24, (java.lang.Number) 100L);
        java.lang.Number number29 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException30 = new org.apache.commons.math.exception.OutOfRangeException(localizable24, (java.lang.Number) 2.5083432919410233d, (java.lang.Number) 10.693737673234912d, number29);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException34 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException39 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable35, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException34.addSuppressed((java.lang.Throwable) numberIsTooSmallException39);
        java.lang.Number number41 = numberIsTooLargeException34.getMax();
        java.lang.Object[] objArray42 = numberIsTooLargeException34.getArguments();
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException(localizable24, objArray42);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException48 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException53 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable49, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException48.addSuppressed((java.lang.Throwable) numberIsTooSmallException53);
        java.lang.Number number55 = numberIsTooLargeException48.getMax();
        org.apache.commons.math.exception.util.Localizable localizable56 = numberIsTooLargeException48.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException61 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable57, objArray60);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable56, objArray60);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException66 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable56, (java.lang.Number) 0.0015107907377931822d, (java.lang.Number) (-0.5961722400471147d), true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException68 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable56, (java.lang.Number) 32L);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException70 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 10);
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException();
        notStrictlyPositiveException70.addSuppressed((java.lang.Throwable) mathException71);
        org.apache.commons.math.exception.util.Localizable localizable73 = mathException71.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable74 = null;
        java.lang.Object[] objArray77 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException78 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable74, objArray77);
        org.apache.commons.math.MathException mathException79 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException78);
        java.lang.Throwable throwable83 = null;
        org.apache.commons.math.exception.util.Localizable localizable85 = null;
        org.apache.commons.math.exception.util.Localizable localizable87 = null;
        java.lang.Object[] objArray90 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException91 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable87, objArray90);
        org.apache.commons.math.MathException mathException92 = new org.apache.commons.math.MathException("3d787e85ce", objArray90);
        org.apache.commons.math.MathException mathException93 = new org.apache.commons.math.MathException(localizable85, objArray90);
        org.apache.commons.math.ConvergenceException convergenceException94 = new org.apache.commons.math.ConvergenceException(throwable83, "org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)", objArray90);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException95 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100, "76b6a5e15f", objArray90);
        org.apache.commons.math.ConvergenceException convergenceException96 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalArgumentException78, "28fc800164", objArray90);
        org.apache.commons.math.ConvergenceException convergenceException97 = new org.apache.commons.math.ConvergenceException(localizable73, objArray90);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException98 = new org.apache.commons.math.MaxIterationsExceededException(100, localizable56, objArray90);
        org.apache.commons.math.MathException mathException99 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException10, localizable24, objArray90);
        org.junit.Assert.assertNull(localizable2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 2.718281828459045d + "'", number23.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number41 + "' != '" + 2.718281828459045d + "'", number41.equals(2.718281828459045d));
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + number55 + "' != '" + 2.718281828459045d + "'", number55.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable56 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable56.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertTrue("'" + localizable73 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable73.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray77);
        org.junit.Assert.assertNotNull(objArray90);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.1555698629817919d, number1, true);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.9999555864695281d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7181611026471753d + "'", double1 == 1.7181611026471753d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException(localizable0, objArray1);
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2);
        try {
            java.lang.String str4 = convergenceException2.getPattern();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objArray1);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        java.lang.Number number10 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooLargeException3.getGeneralPattern();
        java.lang.Number number13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) (-0.46046391868746567d), number13, false);
        java.lang.Object[] objArray20 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException("hi!", objArray20);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(localizable11, objArray20);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Throwable throwable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException("hi!", objArray32);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable26, localizable27, objArray32);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException(throwable24, "4885561af9", objArray32);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable23, objArray32);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException40 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) 6.9059004644397355d, (java.lang.Number) (-21.46708637494148d), false);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 2.718281828459045d + "'", number10.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray32);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        double double1 = org.apache.commons.math.util.FastMath.ulp(206.95747519668325d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.8421709430404007E-14d + "'", double1 == 2.8421709430404007E-14d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray5);
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException6);
        org.apache.commons.math.exception.util.Localizable localizable8 = mathException7.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray14);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("3d787e85ce", objArray14);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)", objArray14);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray14);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "f", objArray14);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray14);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        int int1 = org.apache.commons.math.util.FastMath.abs(35);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable10, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException9.addSuppressed((java.lang.Throwable) numberIsTooSmallException14);
        java.lang.Number number16 = numberIsTooLargeException9.getMax();
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooLargeException9.getGeneralPattern();
        java.lang.Number number19 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) (-0.46046391868746567d), number19, false);
        java.lang.Object[] objArray26 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException("hi!", objArray26);
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException(localizable17, objArray26);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException("9913e0bd71", objArray26);
        org.apache.commons.math.exception.util.Localizable localizable30 = convergenceException29.getGeneralPattern();
        java.lang.Object[] objArray37 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException("hi!", objArray37);
        java.lang.Class<?> wildcardClass39 = objArray37.getClass();
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException("3d787e85ce", objArray37);
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException29, "4885561af9", objArray37);
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException3, "9913e0bd71", objArray37);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException44 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 2147483647);
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.exception.util.Localizable localizable47 = null;
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        java.lang.Object[] objArray50 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException51 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable49, objArray50);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException52 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable46, localizable47, objArray50);
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException44, "5", objArray50);
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException59 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable55, (java.lang.Number) 2.0198227150790538d, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.exception.util.Localizable localizable60 = numberIsTooSmallException59.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable61 = null;
        org.apache.commons.math.exception.util.Localizable localizable63 = null;
        java.lang.Object[] objArray66 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException67 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable63, objArray66);
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException("3d787e85ce", objArray66);
        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException(localizable61, objArray66);
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException(localizable60, objArray66);
        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException44, "{0}", objArray66);
        mathException42.addSuppressed((java.lang.Throwable) convergenceException71);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 2.718281828459045d + "'", number16.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(localizable30);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertTrue("'" + localizable60 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable60.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray66);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.5772156649015329d, 0.5403023058681398d, 2.6508641820894225d);
        double double5 = normalDistributionImpl3.density((double) 1);
        double[] doubleArray7 = normalDistributionImpl3.sample((int) '#');
        try {
            double double10 = normalDistributionImpl3.cumulativeProbability(3.0172641870720844d, 0.1873987292549381d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5436432847461893d + "'", double5 == 0.5436432847461893d);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test050");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        java.lang.String str3 = randomDataImpl0.nextHexString((int) (short) 1);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double8 = normalDistributionImpl7.getMean();
//        double double10 = normalDistributionImpl7.density((double) (short) 1);
//        double double11 = normalDistributionImpl7.sample();
//        double[] doubleArray13 = normalDistributionImpl7.sample((int) (short) 10);
//        double double16 = normalDistributionImpl7.cumulativeProbability(2.0198227150790538d, (double) 100);
//        double double17 = normalDistributionImpl7.sample();
//        double double18 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double19 = normalDistributionImpl7.getStandardDeviation();
//        double double20 = normalDistributionImpl7.sample();
//        double double22 = normalDistributionImpl7.cumulativeProbability(1.246879715040882d);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a" + "'", str3.equals("a"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 7.544137102816975d + "'", double8 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.01610846091529747d + "'", double10 == 0.01610846091529747d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0908729088719129d + "'", double11 == 0.0908729088719129d);
//        org.junit.Assert.assertNotNull(doubleArray13);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.9556007738814948d + "'", double16 == 0.9556007738814948d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 3.79289821794196d + "'", double17 == 3.79289821794196d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 6.454962237663698d + "'", double18 == 6.454962237663698d);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 3.246216406046493d + "'", double19 == 3.246216406046493d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 10.439683689091122d + "'", double20 == 10.439683689091122d);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.02619737902617647d + "'", double22 == 0.02619737902617647d);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 10);
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException();
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) mathException2);
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException2.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException8.addSuppressed((java.lang.Throwable) numberIsTooSmallException13);
        java.lang.Number number15 = numberIsTooLargeException8.getMax();
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooLargeException8.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable16, (java.lang.Number) 100L);
        java.lang.Object[] objArray23 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("hi!", objArray23);
        java.lang.Class<?> wildcardClass25 = objArray23.getClass();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable16, objArray23);
        java.lang.Object[] objArray27 = mathIllegalArgumentException26.getArguments();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 2.718281828459045d + "'", number15.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(objArray27);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        double double1 = org.apache.commons.math.special.Erf.erf(11.371042845999844d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 30L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0686474581523463E13d + "'", double1 == 1.0686474581523463E13d);
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test054");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        double double11 = randomDataImpl0.nextCauchy(2.99822295029797d, 7.8726391065033505d);
//        double double14 = randomDataImpl0.nextCauchy(1.630391949037867d, 1.630391949037867d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.6869378607965673d + "'", double3 == 2.6869378607965673d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.7437927787198464d + "'", double6 == 0.7437927787198464d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2L + "'", long8 == 2L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.754578236431101d + "'", double11 == 10.754578236431101d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.392200290757567d + "'", double14 == 4.392200290757567d);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        double double1 = org.apache.commons.math.util.FastMath.log10(2.9210062771113665d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4655324902538988d + "'", double1 == 0.4655324902538988d);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test056");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        double double11 = randomDataImpl0.nextCauchy(2.99822295029797d, 7.8726391065033505d);
//        double double14 = randomDataImpl0.nextBeta(3.141592653589793d, (double) (byte) 1);
//        double double17 = randomDataImpl0.nextCauchy(5.298292365610485d, (double) (short) 1);
//        long long20 = randomDataImpl0.nextLong(3L, (long) 925392360);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.397998475912597d + "'", double3 == 2.397998475912597d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.6571473246540406d + "'", double6 == 0.6571473246540406d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2L + "'", long8 == 2L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-212.81518684037093d) + "'", double11 == (-212.81518684037093d));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.6319470868938127d + "'", double14 == 0.6319470868938127d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 7.088713201519386d + "'", double17 == 7.088713201519386d);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 801118814L + "'", long20 == 801118814L);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        boolean boolean5 = numberIsTooSmallException4.getBoundIsAllowed();
        java.lang.Number number6 = numberIsTooSmallException4.getMin();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException4.getSpecificPattern();
        java.lang.Number number8 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 22025.465794806718d + "'", number6.equals(22025.465794806718d));
        org.junit.Assert.assertNull(localizable7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 22025.465794806718d + "'", number8.equals(22025.465794806718d));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 3.143276701259362d, (java.lang.Number) 21.0f, false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3);
        java.lang.Number number6 = numberIsTooLargeException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 21.0f + "'", number4.equals(21.0f));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 3.143276701259362d + "'", number6.equals(3.143276701259362d));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        long long1 = org.apache.commons.math.util.FastMath.abs(387632512L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 387632512L + "'", long1 == 387632512L);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 2.1073424033402416E-8d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        double double1 = org.apache.commons.math.special.Gamma.digamma(3.0599180390625618d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9461755519916604d + "'", double1 == 0.9461755519916604d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        java.lang.Object[] objArray5 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException("hi!", objArray5);
        java.lang.Class<?> wildcardClass7 = objArray5.getClass();
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("b0f617732c", objArray5);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException8);
        org.apache.commons.math.exception.util.Localizable localizable10 = convergenceException9.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.2179013918188908d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5421182087135736d + "'", double1 == 1.5421182087135736d);
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test064");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        double double11 = randomDataImpl0.nextCauchy(2.99822295029797d, 7.8726391065033505d);
//        try {
//            double double14 = randomDataImpl0.nextCauchy(2.7089894095686646d, (-1.6294490804086532d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.629 is smaller than, or equal to, the minimum (0): scale (-1.629)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.4078807658399337d + "'", double3 == 2.4078807658399337d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.287156853676686d + "'", double6 == 2.287156853676686d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 8.435649505236343d + "'", double11 == 8.435649505236343d);
//    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test065");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        java.lang.String str3 = randomDataImpl0.nextHexString((int) (short) 1);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double8 = normalDistributionImpl7.getMean();
//        double double10 = normalDistributionImpl7.density((double) (short) 1);
//        double double11 = normalDistributionImpl7.sample();
//        double[] doubleArray13 = normalDistributionImpl7.sample((int) (short) 10);
//        double double16 = normalDistributionImpl7.cumulativeProbability(2.0198227150790538d, (double) 100);
//        double double17 = normalDistributionImpl7.sample();
//        double double18 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        int int22 = randomDataImpl0.nextHypergeometric((int) (byte) 100, (int) (short) 1, (int) (short) 0);
//        double double24 = randomDataImpl0.nextChiSquare(1.6676601980875625d);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "7" + "'", str3.equals("7"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 7.544137102816975d + "'", double8 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.01610846091529747d + "'", double10 == 0.01610846091529747d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 12.289826479507207d + "'", double11 == 12.289826479507207d);
//        org.junit.Assert.assertNotNull(doubleArray13);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.9556007738814948d + "'", double16 == 0.9556007738814948d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 9.371504324156469d + "'", double17 == 9.371504324156469d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 3.464850144516505d + "'", double18 == 3.464850144516505d);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.077802307550664d + "'", double24 == 1.077802307550664d);
//    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test066");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double5 = randomDataImpl0.nextExponential(Double.NaN);
//        double double8 = randomDataImpl0.nextGamma(1.7012502421118005d, 1.7692003247117487d);
//        randomDataImpl0.reSeedSecure((long) 925392360);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.451733848178984d + "'", double3 == 2.451733848178984d);
//        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.2272995136839935d + "'", double8 == 4.2272995136839935d);
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException9);
        java.lang.Number number11 = numberIsTooLargeException4.getMax();
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Number number14 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, (java.lang.Number) (-0.46046391868746567d), number14, false);
        java.lang.Object[] objArray21 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray21);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException(localizable12, objArray21);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("9913e0bd71", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable25 = convergenceException24.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException29 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException34 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable30, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException29.addSuppressed((java.lang.Throwable) numberIsTooSmallException34);
        java.lang.Number number36 = numberIsTooLargeException29.getMax();
        org.apache.commons.math.exception.util.Localizable localizable37 = numberIsTooLargeException29.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        java.lang.Object[] objArray41 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable38, objArray41);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException43 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable37, objArray41);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException47 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable37, (java.lang.Number) 0.0015107907377931822d, (java.lang.Number) (-0.5961722400471147d), true);
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        java.lang.Object[] objArray54 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException("hi!", objArray54);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable48, localizable49, objArray54);
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException56);
        java.lang.Object[] objArray58 = mathException57.getArguments();
        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException(localizable37, objArray58);
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException(localizable25, objArray58);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException62 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100);
        org.apache.commons.math.exception.util.Localizable localizable63 = maxIterationsExceededException62.getSpecificPattern();
        java.lang.Throwable[] throwableArray64 = maxIterationsExceededException62.getSuppressed();
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException(localizable25, (java.lang.Object[]) throwableArray64);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 2.718281828459045d + "'", number11.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(localizable25);
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 2.718281828459045d + "'", number36.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNull(localizable63);
        org.junit.Assert.assertNotNull(throwableArray64);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.710071082755576d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test069");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double5 = randomDataImpl0.nextExponential(Double.NaN);
//        double double8 = randomDataImpl0.nextCauchy(0.019691932154573932d, 0.9969748643467198d);
//        int int11 = randomDataImpl0.nextZipf((int) (short) 10, (double) (short) 100);
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeedSecure(11L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.8364493690441774d + "'", double3 == 2.8364493690441774d);
//        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-2.2964866319876176d) + "'", double8 == (-2.2964866319876176d));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        java.lang.Number number3 = notStrictlyPositiveException1.getMin();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException1.getGeneralPattern();
        java.lang.Throwable throwable5 = null;
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException(throwable5);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException("hi!", objArray12);
        java.lang.Class<?> wildcardClass14 = objArray12.getClass();
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException(throwable5, localizable7, objArray12);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, objArray20);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException15, localizable16, objArray20);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException(localizable4, objArray20);
        org.apache.commons.math.exception.util.Localizable localizable24 = mathException23.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException28 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable24, (java.lang.Number) 1.6898558835492172d, (java.lang.Number) 8.537502815727784d, false);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException32 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable33, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException32.addSuppressed((java.lang.Throwable) numberIsTooSmallException37);
        java.lang.Number number39 = numberIsTooLargeException32.getMax();
        org.apache.commons.math.exception.util.Localizable localizable40 = numberIsTooLargeException32.getGeneralPattern();
        java.lang.Number number42 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException44 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable40, (java.lang.Number) (-0.46046391868746567d), number42, false);
        java.lang.Object[] objArray49 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("hi!", objArray49);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException(localizable40, objArray49);
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        java.lang.Throwable throwable53 = null;
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        java.lang.Object[] objArray61 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException62 = new org.apache.commons.math.MathException("hi!", objArray61);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable55, localizable56, objArray61);
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException(throwable53, "4885561af9", objArray61);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable40, localizable52, objArray61);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException67 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        boolean boolean68 = notStrictlyPositiveException67.getBoundIsAllowed();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException73 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable74 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException78 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable74, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException73.addSuppressed((java.lang.Throwable) numberIsTooSmallException78);
        java.lang.Number number80 = numberIsTooLargeException73.getMax();
        org.apache.commons.math.exception.util.Localizable localizable81 = numberIsTooLargeException73.getGeneralPattern();
        java.lang.Number number83 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException85 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable81, (java.lang.Number) (-0.46046391868746567d), number83, false);
        org.apache.commons.math.exception.util.Localizable localizable86 = null;
        org.apache.commons.math.exception.util.Localizable localizable87 = null;
        org.apache.commons.math.exception.util.Localizable localizable89 = null;
        java.lang.Object[] objArray90 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException91 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable89, objArray90);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException92 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable86, localizable87, objArray90);
        org.apache.commons.math.MathException mathException93 = new org.apache.commons.math.MathException(localizable81, objArray90);
        org.apache.commons.math.MathException mathException94 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException67, "da087b827c", objArray90);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException95 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable40, objArray90);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + 2.718281828459045d + "'", number39.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable40.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + number80 + "' != '" + 2.718281828459045d + "'", number80.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable81 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable81.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray90);
    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test071");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        randomDataImpl0.reSeed((long) 1);
//        double double17 = randomDataImpl0.nextBeta((double) 10L, (double) 10);
//        randomDataImpl0.reSeed(2L);
//        randomDataImpl0.reSeedSecure();
//        double double23 = randomDataImpl0.nextCauchy(6.845205783271511d, 2.186111192700351d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.710123106849761d + "'", double3 == 2.710123106849761d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.4236281649087417d + "'", double6 == 3.4236281649087417d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 10.506666378033502d + "'", double12 == 10.506666378033502d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.5693386188584106d + "'", double17 == 0.5693386188584106d);
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 8.786566153618883d + "'", double23 == 8.786566153618883d);
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.04651311928320406d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0010819301719414d + "'", double1 == 1.0010819301719414d);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test073");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextF(2.718281828459045d, (double) 100);
//        double double6 = randomDataImpl0.nextGaussian(6.894970724176963d, 0.9969748643467198d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.4534959713498088d + "'", double3 == 0.4534959713498088d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 7.808677459767716d + "'", double6 == 7.808677459767716d);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        double double1 = org.apache.commons.math.util.FastMath.tanh(2.1969367550226755d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9755958833104668d + "'", double1 == 0.9755958833104668d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) 100, 8L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray5);
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException("3d787e85ce", objArray5);
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)", objArray5);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException13.addSuppressed((java.lang.Throwable) numberIsTooSmallException18);
        java.lang.Number number20 = numberIsTooLargeException13.getMax();
        org.apache.commons.math.exception.util.Localizable localizable21 = numberIsTooLargeException13.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable21, (java.lang.Number) 100L);
        java.lang.Object[] objArray24 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable21, objArray24);
        java.lang.Object[] objArray26 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException(32, localizable21, objArray26);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException29 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 10);
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException();
        notStrictlyPositiveException29.addSuppressed((java.lang.Throwable) mathException30);
        org.apache.commons.math.exception.util.Localizable localizable32 = mathException30.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException36 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException41 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable37, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException36.addSuppressed((java.lang.Throwable) numberIsTooSmallException41);
        java.lang.Number number43 = numberIsTooLargeException36.getMax();
        org.apache.commons.math.exception.util.Localizable localizable44 = numberIsTooLargeException36.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException46 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable44, (java.lang.Number) 100L);
        java.lang.Object[] objArray51 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException("hi!", objArray51);
        java.lang.Class<?> wildcardClass53 = objArray51.getClass();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException54 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable32, localizable44, objArray51);
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException8, localizable21, objArray51);
        java.lang.Throwable throwable56 = null;
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException(throwable56);
        java.lang.Class<?> wildcardClass58 = convergenceException57.getClass();
        org.apache.commons.math.exception.util.Localizable localizable59 = convergenceException57.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable60 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException64 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable60, (java.lang.Number) 2.0198227150790538d, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException64);
        org.apache.commons.math.exception.util.Localizable localizable68 = null;
        java.lang.Object[] objArray71 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException72 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable68, objArray71);
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException("3d787e85ce", objArray71);
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException65, "fd4ecaf23f", objArray71);
        org.apache.commons.math.MathException mathException75 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException8, localizable59, objArray71);
        java.lang.Throwable[] throwableArray76 = convergenceException8.getSuppressed();
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 2.718281828459045d + "'", number20.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + 2.718281828459045d + "'", number43.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable44.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertTrue("'" + localizable59 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable59.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray71);
        org.junit.Assert.assertNotNull(throwableArray76);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test077");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        double double11 = randomDataImpl0.nextCauchy(4.600161852571429d, 2.6508641820894225d);
//        randomDataImpl0.reSeedSecure((long) (byte) 0);
//        double double16 = randomDataImpl0.nextGamma(3.550128012953764d, 10.569181794623525d);
//        randomDataImpl0.reSeed(32L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.9392679268154454d + "'", double3 == 2.9392679268154454d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.9645120761396837d + "'", double6 == 1.9645120761396837d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 11.261451621734327d + "'", double11 == 11.261451621734327d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 51.69778295737613d + "'", double16 == 51.69778295737613d);
//    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test078");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double5 = randomDataImpl0.nextExponential(Double.NaN);
//        double double8 = randomDataImpl0.nextUniform(0.9969748643467198d, 6.798056507791588d);
//        randomDataImpl0.reSeedSecure(100L);
//        double double12 = randomDataImpl0.nextT(1.432116947405487d);
//        double double14 = randomDataImpl0.nextExponential(7.544137102816975d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl17 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double18 = normalDistributionImpl17.getMean();
//        double double21 = normalDistributionImpl17.cumulativeProbability((double) (short) -1, 3.207810091467445d);
//        double double22 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl17);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.9388304381460704d + "'", double3 == 2.9388304381460704d);
//        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 5.719041460929805d + "'", double8 == 5.719041460929805d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.21897454941119796d + "'", double12 == 0.21897454941119796d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 33.01025325614428d + "'", double14 == 33.01025325614428d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 7.544137102816975d + "'", double18 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.08656193300300513d + "'", double21 == 0.08656193300300513d);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 4.699141218316469d + "'", double22 == 4.699141218316469d);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.7087461852015374d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6098899963501203d + "'", double1 == 0.6098899963501203d);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test080");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        int int4 = randomDataImpl0.nextInt(0, (int) (short) 1);
//        double double7 = randomDataImpl0.nextUniform(1.110636508023106d, 5.298342365610589d);
//        double double10 = randomDataImpl0.nextGaussian(3.876325147954168E8d, 1.3376366091383556d);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.710910712426604d + "'", double7 == 2.710910712426604d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.876325136090846E8d + "'", double10 == 3.876325136090846E8d);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.5772156649015329d, 0.5403023058681398d, 2.6508641820894225d);
        double double5 = normalDistributionImpl3.density(0.0d);
        double double7 = normalDistributionImpl3.cumulativeProbability(0.0d);
        double double10 = normalDistributionImpl3.cumulativeProbability(0.0d, 4.47650203055108d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.4172934084748632d + "'", double5 == 0.4172934084748632d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.1426881343454347d + "'", double7 == 0.1426881343454347d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.8573118656542993d + "'", double10 == 0.8573118656542993d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(2.5083432919410233d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3587169437393838d + "'", double1 == 1.3587169437393838d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 100, (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        boolean boolean4 = notStrictlyPositiveException3.getBoundIsAllowed();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable10, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException9.addSuppressed((java.lang.Throwable) numberIsTooSmallException14);
        java.lang.Number number16 = numberIsTooLargeException9.getMax();
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooLargeException9.getGeneralPattern();
        java.lang.Number number19 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) (-0.46046391868746567d), number19, false);
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray26 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable25, objArray26);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, localizable23, objArray26);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException(localizable17, objArray26);
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException3, "da087b827c", objArray26);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException("3", objArray26);
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException("9a68f74198", objArray26);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 2.718281828459045d + "'", number16.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray26);
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test085");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        double double11 = randomDataImpl0.nextCauchy(2.99822295029797d, 7.8726391065033505d);
//        double double14 = randomDataImpl0.nextBeta(3.141592653589793d, (double) (byte) 1);
//        randomDataImpl0.reSeed();
//        double double18 = randomDataImpl0.nextGamma(0.21419267745949014d, (double) 30);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.9444409591906195d + "'", double3 == 2.9444409591906195d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.8156302161577274d + "'", double6 == 1.8156302161577274d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.155602771743112d + "'", double11 == 3.155602771743112d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.7331927095395625d + "'", double14 == 0.7331927095395625d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.4394052574230232d + "'", double18 == 1.4394052574230232d);
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.5083197524199957d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.47028123724907345d + "'", double1 == 0.47028123724907345d);
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test087");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double5 = randomDataImpl0.nextExponential(Double.NaN);
//        double double8 = randomDataImpl0.nextGamma((double) (byte) 1, (double) 10.0f);
//        double double10 = randomDataImpl0.nextChiSquare(0.3576336764413698d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.945314655646571d + "'", double3 == 2.945314655646571d);
//        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.5924811175972875d + "'", double8 == 0.5924811175972875d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.9000042445892624d + "'", double10 == 1.9000042445892624d);
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        double double1 = org.apache.commons.math.util.FastMath.acosh(3.3489941619972536d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8787326768989563d + "'", double1 == 1.8787326768989563d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        java.lang.Number number10 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooLargeException3.getGeneralPattern();
        java.lang.Number number13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) (-0.46046391868746567d), number13, false);
        java.lang.Throwable throwable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray23 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, objArray23);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException("3d787e85ce", objArray23);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException(localizable18, objArray23);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException(throwable16, "org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)", objArray23);
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException(localizable11, objArray23);
        java.lang.Class<?> wildcardClass29 = localizable11.getClass();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException33 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 0.34766712944793493d, (java.lang.Number) 1.3691506489023308d, true);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 2.718281828459045d + "'", number10.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(wildcardClass29);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.5607966601082315d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.4928407777776485d);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        java.lang.Number number3 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
        double double3 = normalDistributionImpl2.getMean();
        double double6 = normalDistributionImpl2.cumulativeProbability((double) (short) -1, 3.207810091467445d);
        double double7 = normalDistributionImpl2.getStandardDeviation();
        double double8 = normalDistributionImpl2.getMean();
        try {
            double double10 = normalDistributionImpl2.inverseCumulativeProbability(1.5245066427138134d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 1.525 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.544137102816975d + "'", double3 == 7.544137102816975d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08656193300300513d + "'", double6 == 0.08656193300300513d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.246216406046493d + "'", double7 == 3.246216406046493d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 7.544137102816975d + "'", double8 == 7.544137102816975d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        java.lang.Number number10 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooLargeException3.getGeneralPattern();
        java.lang.Number number13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) (-0.46046391868746567d), number13, false);
        java.lang.Object[] objArray20 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException("hi!", objArray20);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(localizable11, objArray20);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Throwable throwable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException("hi!", objArray32);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable26, localizable27, objArray32);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException(throwable24, "4885561af9", objArray32);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable23, objArray32);
        java.lang.Object[] objArray37 = null;
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException(localizable23, objArray37);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException44 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException49 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable45, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException44.addSuppressed((java.lang.Throwable) numberIsTooSmallException49);
        java.lang.Number number51 = numberIsTooLargeException44.getMax();
        org.apache.commons.math.exception.util.Localizable localizable52 = numberIsTooLargeException44.getGeneralPattern();
        java.lang.Object[] objArray57 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException("hi!", objArray57);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException59 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable52, objArray57);
        org.apache.commons.math.exception.util.Localizable localizable60 = null;
        org.apache.commons.math.exception.util.Localizable localizable61 = null;
        org.apache.commons.math.exception.util.Localizable localizable63 = null;
        java.lang.Object[] objArray64 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException65 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable63, objArray64);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException66 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable60, localizable61, objArray64);
        org.apache.commons.math.MathException mathException67 = new org.apache.commons.math.MathException(localizable52, objArray64);
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException38, "83487134f3", objArray64);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 2.718281828459045d + "'", number10.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + number51 + "' != '" + 2.718281828459045d + "'", number51.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable52.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertNotNull(objArray64);
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test094");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        randomDataImpl0.reSeed((long) 1);
//        double double16 = randomDataImpl0.nextT(3.019615807334041d);
//        java.lang.String str18 = randomDataImpl0.nextSecureHexString(19);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.9176073790599064d + "'", double3 == 2.9176073790599064d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.7138587492517865d + "'", double6 == 2.7138587492517865d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 7.007383343599696d + "'", double12 == 7.007383343599696d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.6922667593910462d + "'", double16 == 0.6922667593910462d);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ab4f7e54984ffc8983b" + "'", str18.equals("ab4f7e54984ffc8983b"));
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException4 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100);
        org.apache.commons.math.exception.util.Localizable localizable5 = maxIterationsExceededException4.getSpecificPattern();
        java.lang.Throwable[] throwableArray6 = maxIterationsExceededException4.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("76b6a5e15f", (java.lang.Object[]) throwableArray6);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "2", (java.lang.Object[]) throwableArray6);
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException5.addSuppressed((java.lang.Throwable) numberIsTooSmallException10);
        java.lang.Number number12 = numberIsTooLargeException5.getMax();
        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooLargeException5.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, objArray17);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable13, (java.lang.Number) 0.0015107907377931822d, (java.lang.Number) (-0.5961722400471147d), true);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException27 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException32 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable28, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException27.addSuppressed((java.lang.Throwable) numberIsTooSmallException32);
        java.lang.Number number34 = numberIsTooLargeException27.getMax();
        org.apache.commons.math.exception.util.Localizable localizable35 = numberIsTooLargeException27.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, objArray39);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable35, objArray39);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException45 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable35, (java.lang.Number) 0.0015107907377931822d, (java.lang.Number) (-0.5961722400471147d), true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException47 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable35, (java.lang.Number) 32L);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException51 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException56 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable52, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException51.addSuppressed((java.lang.Throwable) numberIsTooSmallException56);
        java.lang.Number number58 = numberIsTooLargeException51.getMax();
        org.apache.commons.math.exception.util.Localizable localizable59 = numberIsTooLargeException51.getGeneralPattern();
        java.lang.Number number61 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException63 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable59, (java.lang.Number) (-0.46046391868746567d), number61, false);
        java.lang.Object[] objArray68 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException("hi!", objArray68);
        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException(localizable59, objArray68);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException74 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable59, (java.lang.Number) 0.5693386188584106d, (java.lang.Number) 6.503243247425703d, false);
        java.lang.Throwable throwable75 = null;
        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException(throwable75);
        java.lang.Class<?> wildcardClass77 = convergenceException76.getClass();
        org.apache.commons.math.exception.util.Localizable localizable78 = convergenceException76.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException82 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        java.lang.String str83 = numberIsTooSmallException82.toString();
        java.lang.Object[] objArray84 = numberIsTooSmallException82.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException85 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable59, localizable78, objArray84);
        org.apache.commons.math.MathException mathException86 = new org.apache.commons.math.MathException(localizable35, objArray84);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException87 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, objArray84);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException88 = new org.apache.commons.math.MaxIterationsExceededException(925392360, "72ea90a65b", objArray84);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 2.718281828459045d + "'", number12.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + 2.718281828459045d + "'", number34.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable35.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertTrue("'" + number58 + "' != '" + 2.718281828459045d + "'", number58.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable59 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable59.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray68);
        org.junit.Assert.assertNotNull(wildcardClass77);
        org.junit.Assert.assertTrue("'" + localizable78 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable78.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (0)" + "'", str83.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray84);
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test097");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        int int4 = randomDataImpl0.nextInt(0, (int) (short) 1);
//        double double7 = randomDataImpl0.nextUniform(1.110636508023106d, 5.298342365610589d);
//        double double10 = randomDataImpl0.nextGaussian(0.06962111172915636d, 0.8590238068419813d);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.302278239761405d + "'", double7 == 2.302278239761405d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-0.7432425464425072d) + "'", double10 == (-0.7432425464425072d));
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 3.0454957620747787d, number1, false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException3.getSpecificPattern();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(localizable6);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test100");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        java.lang.String str3 = randomDataImpl0.nextHexString((int) (short) 1);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double[] doubleArray6 = normalDistributionImpl4.sample((int) '#');
//        double double7 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        try {
//            int[] intArray10 = randomDataImpl0.nextPermutation(0, 11);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 11 is larger than the maximum (0): permutation size (11) exceeds permuation domain (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "6" + "'", str3.equals("6"));
//        org.junit.Assert.assertNotNull(doubleArray6);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.7927855432452467d) + "'", double7 == (-0.7927855432452467d));
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        double double1 = org.apache.commons.math.util.FastMath.atanh(5.430377658846085d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100);
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable2);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("hi!", objArray9);
        java.lang.Class<?> wildcardClass11 = objArray9.getClass();
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException(throwable2, localizable4, objArray9);
        maxIterationsExceededException1.addSuppressed((java.lang.Throwable) mathException12);
        java.lang.String str14 = maxIterationsExceededException1.getPattern();
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "maximal number of iterations ({0}) exceeded" + "'", str14.equals("maximal number of iterations ({0}) exceeded"));
    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test103");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        randomDataImpl0.reSeed((long) 100);
//        long long10 = randomDataImpl0.nextPoisson(0.6511961857760066d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double14 = normalDistributionImpl13.getMean();
//        double double16 = normalDistributionImpl13.density((double) (short) 1);
//        double double17 = normalDistributionImpl13.sample();
//        double double18 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        int int21 = randomDataImpl0.nextInt(10, 21);
//        try {
//            int int24 = randomDataImpl0.nextSecureInt(32, 5);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 32 is larger than, or equal to, the maximum (5): lower bound (32) must be strictly less than upper bound (5)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.1306030710574233d + "'", double3 == 3.1306030710574233d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.566619665518355d + "'", double6 == 1.566619665518355d);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 7.544137102816975d + "'", double14 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.01610846091529747d + "'", double16 == 0.01610846091529747d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 12.041881284390822d + "'", double17 == 12.041881284390822d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 8.946773076383243d + "'", double18 == 8.946773076383243d);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 19 + "'", int21 == 19);
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.3877787807814457E-17d, (java.lang.Number) 0.05173673650470184d, false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0015107907377931822d, 0.40903333932331004d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.07017792465704646d + "'", double2 == 0.07017792465704646d);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test106");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        double double11 = randomDataImpl0.nextCauchy(2.99822295029797d, 7.8726391065033505d);
//        double double14 = randomDataImpl0.nextGamma(3.211168364943453d, 2.710071082755576d);
//        try {
//            int int17 = randomDataImpl0.nextSecureInt(0, (int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (0): lower bound (0) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.129415096689643d + "'", double3 == 3.129415096689643d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.1121845402939354d + "'", double6 == 3.1121845402939354d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.8691158886168715d + "'", double11 == 4.8691158886168715d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.501369796235595d + "'", double14 == 4.501369796235595d);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 0L, (float) (short) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray1 = convergenceException0.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable5, objArray6);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException11.addSuppressed((java.lang.Throwable) numberIsTooSmallException16);
        java.lang.Number number18 = numberIsTooLargeException11.getMax();
        org.apache.commons.math.exception.util.Localizable localizable19 = numberIsTooLargeException11.getGeneralPattern();
        java.lang.Number number21 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable19, (java.lang.Number) (-0.46046391868746567d), number21, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException27 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable19, (java.lang.Number) 3.081725078478352d, (java.lang.Number) (-1.0d), true);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException32 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable33, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException32.addSuppressed((java.lang.Throwable) numberIsTooSmallException37);
        java.lang.Number number39 = numberIsTooLargeException32.getMax();
        org.apache.commons.math.exception.util.Localizable localizable40 = numberIsTooLargeException32.getGeneralPattern();
        java.lang.Object[] objArray45 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException("hi!", objArray45);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException47 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable40, objArray45);
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException7, localizable19, objArray45);
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException("28fc800164", objArray45);
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException0, "org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)", objArray45);
        java.lang.Object[] objArray51 = mathException50.getArguments();
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 2.718281828459045d + "'", number18.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + 2.718281828459045d + "'", number39.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable40.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(objArray51);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        double double1 = org.apache.commons.math.util.FastMath.abs(3.9348362480511847d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.9348362480511847d + "'", double1 == 3.9348362480511847d);
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test110");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        randomDataImpl0.reSeed((long) 1);
//        long long17 = randomDataImpl0.nextLong((long) 2, 25L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.151275784719915d + "'", double3 == 3.151275784719915d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.999924405095252d + "'", double6 == 4.999924405095252d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 11.692603637812763d + "'", double12 == 11.692603637812763d);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 19L + "'", long17 == 19L);
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        double double2 = org.apache.commons.math.util.FastMath.min((-0.2851224030758651d), (-16.22816855639514d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-16.22816855639514d) + "'", double2 == (-16.22816855639514d));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 30, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
        double double4 = normalDistributionImpl2.inverseCumulativeProbability(0.5403023058681398d);
        normalDistributionImpl2.reseedRandomGenerator(0L);
        double double7 = normalDistributionImpl2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.8726391065033505d + "'", double4 == 7.8726391065033505d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.246216406046493d + "'", double7 == 3.246216406046493d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 3, (java.lang.Number) 177.4296412225003d, false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        java.lang.Number number10 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooLargeException3.getGeneralPattern();
        java.lang.Number number13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) (-0.46046391868746567d), number13, false);
        java.lang.Object[] objArray20 = new java.lang.Object[] { 100.0d, 3.1622776601683795d, 1 };
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException("hi!", objArray20);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(localizable11, objArray20);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) 0.5693386188584106d, (java.lang.Number) 6.503243247425703d, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException30 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) 0.5456928232039928d, (java.lang.Number) 6.894970724176963d, true);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException30);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 2.718281828459045d + "'", number10.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray20);
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test117");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        java.lang.String str5 = randomDataImpl0.nextSecureHexString(10);
//        long long8 = randomDataImpl0.nextSecureLong((long) (byte) -1, 2L);
//        int int11 = randomDataImpl0.nextSecureInt(11, 2147483647);
//        double double14 = randomDataImpl0.nextCauchy(0.0d, 1.9182380284293927d);
//        randomDataImpl0.reSeedSecure();
//        double double18 = randomDataImpl0.nextBeta(2.9898176418264275d, 6.522991411704608d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.160264353644778d + "'", double3 == 3.160264353644778d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "7c503ce6b4" + "'", str5.equals("7c503ce6b4"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2L + "'", long8 == 2L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 402746292 + "'", int11 == 402746292);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.410158035838988d + "'", double14 == 10.410158035838988d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.35314279292628975d + "'", double18 == 0.35314279292628975d);
//    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test118");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        java.lang.String str5 = randomDataImpl0.nextSecureHexString(10);
//        randomDataImpl0.reSeedSecure();
//        double double8 = randomDataImpl0.nextExponential(0.017453292519943295d);
//        int int11 = randomDataImpl0.nextPascal(32, 0.2297948594237435d);
//        randomDataImpl0.reSeedSecure(84L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.091686159517643d + "'", double3 == 3.091686159517643d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "f16c5f6bed" + "'", str5.equals("f16c5f6bed"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.004300901965233558d + "'", double8 == 0.004300901965233558d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 94 + "'", int11 == 94);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        double double1 = org.apache.commons.math.util.FastMath.sin(7.659793813137549d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9812047191078033d + "'", double1 == 0.9812047191078033d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 2147483647);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable6, objArray7);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable4, objArray7);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException1, "5", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) 2.0198227150790538d, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException15);
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException16.getGeneralPattern();
        mathException10.addSuppressed((java.lang.Throwable) convergenceException16);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        double double1 = org.apache.commons.math.util.FastMath.cosh(7.827080916361512d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1253.7995937606624d + "'", double1 == 1253.7995937606624d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        int int2 = org.apache.commons.math.util.FastMath.max(387632512, 18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 387632512 + "'", int2 == 387632512);
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test123");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        long long8 = randomDataImpl0.nextPoisson(0.7853981633974483d);
//        double double11 = randomDataImpl0.nextCauchy(2.99822295029797d, 7.8726391065033505d);
//        double double14 = randomDataImpl0.nextBeta(3.141592653589793d, (double) (byte) 1);
//        double double17 = randomDataImpl0.nextCauchy(5.298292365610485d, (double) (short) 1);
//        try {
//            int int21 = randomDataImpl0.nextHypergeometric(14, 20, 97);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 20 is larger than the maximum (14): number of successes (20) must be less than or equal to population size (14)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0881256640115966d + "'", double3 == 3.0881256640115966d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.215505574713654d + "'", double6 == 2.215505574713654d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.4691233495189335d + "'", double11 == 3.4691233495189335d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.9971093242162691d + "'", double14 == 0.9971093242162691d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 10.612511534265389d + "'", double17 == 10.612511534265389d);
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 35L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test125");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double4 = normalDistributionImpl2.inverseCumulativeProbability(0.5403023058681398d);
//        double double5 = normalDistributionImpl2.sample();
//        try {
//            double double7 = normalDistributionImpl2.inverseCumulativeProbability(5.3071366681126335d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 5.307 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.8726391065033505d + "'", double4 == 7.8726391065033505d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 11.46557558680294d + "'", double5 == 11.46557558680294d);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        double double2 = org.apache.commons.math.util.FastMath.min(1.0d, 6.039949110721368d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException9);
        java.lang.Number number11 = numberIsTooLargeException4.getMax();
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Number number14 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, (java.lang.Number) (-0.46046391868746567d), number14, false);
        java.lang.Throwable throwable17 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable21, objArray24);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException("3d787e85ce", objArray24);
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException(localizable19, objArray24);
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException(throwable17, "org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)", objArray24);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException(localizable12, objArray24);
        java.lang.Class<?> wildcardClass30 = localizable12.getClass();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException34 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.787066582172498d, (java.lang.Number) 1.787066582172498d, (java.lang.Number) 2.4053027645871077d);
        java.lang.Number number35 = outOfRangeException34.getLo();
        java.lang.Number number36 = outOfRangeException34.getHi();
        org.apache.commons.math.exception.util.Localizable localizable37 = outOfRangeException34.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        java.lang.Object[] objArray43 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException44 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable40, objArray43);
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException("3d787e85ce", objArray43);
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException("", objArray43);
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException(localizable37, objArray43);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable12, objArray43);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 2.718281828459045d + "'", number11.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + 1.787066582172498d + "'", number35.equals(1.787066582172498d));
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 2.4053027645871077d + "'", number36.equals(2.4053027645871077d));
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray43);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.783883305402354d, 30.9570417874309d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7838833054023541d + "'", double2 == 0.7838833054023541d);
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test129");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double5 = randomDataImpl0.nextExponential(Double.NaN);
//        double double8 = randomDataImpl0.nextGamma((double) (byte) 1, (double) 10.0f);
//        int int11 = randomDataImpl0.nextInt((int) (short) 1, 52);
//        int int14 = randomDataImpl0.nextSecureInt((int) (short) -1, 402746292);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.1163623616144855d + "'", double3 == 3.1163623616144855d);
//        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.182243998928765d + "'", double8 == 4.182243998928765d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 32 + "'", int11 == 32);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 19071639 + "'", int14 == 19071639);
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.3653718376654087d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.086232534765517d + "'", double1 == 2.086232534765517d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(6.9059004644397355d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9043207728559441d + "'", double1 == 1.9043207728559441d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-4.440892098500626E-16d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        double double1 = org.apache.commons.math.util.FastMath.ulp(2.1969367550226755d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test134");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        java.lang.String str3 = randomDataImpl0.nextHexString((int) (short) 1);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double8 = normalDistributionImpl7.getMean();
//        double double10 = normalDistributionImpl7.density((double) (short) 1);
//        double double11 = normalDistributionImpl7.sample();
//        double[] doubleArray13 = normalDistributionImpl7.sample((int) (short) 10);
//        double double16 = normalDistributionImpl7.cumulativeProbability(2.0198227150790538d, (double) 100);
//        double double17 = normalDistributionImpl7.sample();
//        double double20 = normalDistributionImpl7.cumulativeProbability((-0.5772156677920679d), 3.237011984115693d);
//        double double21 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double23 = normalDistributionImpl7.density(3.2365580296009484d);
//        double double24 = normalDistributionImpl7.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "c" + "'", str3.equals("c"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 7.544137102816975d + "'", double8 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.01610846091529747d + "'", double10 == 0.01610846091529747d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 11.61609440612084d + "'", double11 == 11.61609440612084d);
//        org.junit.Assert.assertNotNull(doubleArray13);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.9556007738814948d + "'", double16 == 0.9556007738814948d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-1.5779795679117d) + "'", double17 == (-1.5779795679117d));
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.08610676786594773d + "'", double20 == 0.08610676786594773d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 9.19795505514334d + "'", double21 == 9.19795505514334d);
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.05095401028350602d + "'", double23 == 0.05095401028350602d);
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 3.246216406046493d + "'", double24 == 3.246216406046493d);
//    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.9969748643467199d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8398326491967667d + "'", double1 == 0.8398326491967667d);
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test136");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextF(2.718281828459045d, (double) 100);
//        int int6 = randomDataImpl0.nextSecureInt((int) (byte) 0, 10);
//        long long8 = randomDataImpl0.nextPoisson((double) 32.0f);
//        randomDataImpl0.reSeedSecure(801118814L);
//        long long13 = randomDataImpl0.nextLong((long) 10, (long) 100);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.2092546988880915d + "'", double3 == 1.2092546988880915d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 29L + "'", long8 == 29L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 48L + "'", long13 == 48L);
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.44200120958159506d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.5772156649015329d, 0.5403023058681398d, 2.6508641820894225d);
        double double5 = normalDistributionImpl3.density((double) 1);
        double[] doubleArray7 = normalDistributionImpl3.sample((int) '#');
        double double9 = normalDistributionImpl3.cumulativeProbability(5.146947373638317d);
        double double10 = normalDistributionImpl3.getStandardDeviation();
        double double13 = normalDistributionImpl3.cumulativeProbability(0.0d, 4.990120238769398d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5436432847461893d + "'", double5 == 0.5436432847461893d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.5403023058681398d + "'", double10 == 0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.8573118656545651d + "'", double13 == 0.8573118656545651d);
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test139");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double5 = randomDataImpl0.nextExponential(Double.NaN);
//        double double8 = randomDataImpl0.nextUniform(0.9969748643467198d, 6.798056507791588d);
//        randomDataImpl0.reSeedSecure(100L);
//        int int13 = randomDataImpl0.nextZipf((int) '#', 2.0198227150790538d);
//        double double15 = randomDataImpl0.nextChiSquare(0.9970011109715183d);
//        long long18 = randomDataImpl0.nextSecureLong((long) (byte) -1, 0L);
//        int int21 = randomDataImpl0.nextBinomial(123, 0.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.044354527141664d + "'", double3 == 3.044354527141664d);
//        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0863884183023358d + "'", double8 == 1.0863884183023358d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.54078162692063d + "'", double15 == 0.54078162692063d);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("", objArray1);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException6.addSuppressed((java.lang.Throwable) numberIsTooSmallException11);
        java.lang.Number number13 = numberIsTooLargeException6.getMax();
        org.apache.commons.math.exception.util.Localizable localizable14 = numberIsTooLargeException6.getGeneralPattern();
        java.lang.Number number16 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) (-0.46046391868746567d), number16, false);
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable21, objArray22);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException18, "6", objArray22);
        convergenceException2.addSuppressed((java.lang.Throwable) numberIsTooSmallException18);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 2.718281828459045d + "'", number13.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray22);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 2.0198227150790538d, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        java.lang.String str7 = convergenceException6.getPattern();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{0}" + "'", str7.equals("{0}"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        double double1 = org.apache.commons.math.util.FastMath.cos(12.164315132131438d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9202586063407863d + "'", double1 == 0.9202586063407863d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        long long1 = org.apache.commons.math.util.FastMath.round(0.34051064246566165d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test144");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double5 = randomDataImpl0.nextExponential(Double.NaN);
//        double double8 = randomDataImpl0.nextCauchy(0.019691932154573932d, 0.9969748643467198d);
//        try {
//            int[] intArray11 = randomDataImpl0.nextPermutation(2, (int) '4');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 52 is larger than the maximum (2): permutation size (52) exceeds permuation domain (2)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.058024385351899d + "'", double3 == 3.058024385351899d);
//        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.3182423917386563d + "'", double8 == 1.3182423917386563d);
//    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        double double1 = org.apache.commons.math.util.FastMath.atan(2.002844215635055d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1077169144303824d + "'", double1 == 1.1077169144303824d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 5.871713382091761d, number1, false);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 5.871713382091761d + "'", number4.equals(5.871713382091761d));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) 2.718281828459045d, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 1L, (java.lang.Number) 22025.465794806718d, true);
        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException9);
        java.lang.Number number11 = numberIsTooLargeException4.getMax();
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, objArray16);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray16);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable12, (java.lang.Number) 0.0015107907377931822d, (java.lang.Number) (-0.5961722400471147d), true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException24 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable12, (java.lang.Number) 32L);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException26 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 10);
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException();
        notStrictlyPositiveException26.addSuppressed((java.lang.Throwable) mathException27);
        org.apache.commons.math.exception.util.Localizable localizable29 = mathException27.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        java.lang.Object[] objArray33 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable30, objArray33);
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException34);
        java.lang.Throwable throwable39 = null;
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        java.lang.Object[] objArray46 = new java.lang.Object[] { (-1.0d), (-1L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable43, objArray46);
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException("3d787e85ce", objArray46);
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException(localizable41, objArray46);
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException(throwable39, "org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)", objArray46);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException51 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100, "76b6a5e15f", objArray46);
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalArgumentException34, "28fc800164", objArray46);
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException(localizable29, objArray46);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException54 = new org.apache.commons.math.MaxIterationsExceededException(100, localizable12, objArray46);
        org.apache.commons.math.exception.util.Localizable localizable55 = maxIterationsExceededException54.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 2.718281828459045d + "'", number11.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertTrue("'" + localizable55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable55.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test148");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        java.lang.String str3 = randomDataImpl0.nextHexString((int) (short) 1);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double8 = normalDistributionImpl7.getMean();
//        double double10 = normalDistributionImpl7.density((double) (short) 1);
//        double double11 = normalDistributionImpl7.sample();
//        double[] doubleArray13 = normalDistributionImpl7.sample((int) (short) 10);
//        double double16 = normalDistributionImpl7.cumulativeProbability(2.0198227150790538d, (double) 100);
//        double double17 = normalDistributionImpl7.sample();
//        double double18 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        int int22 = randomDataImpl0.nextHypergeometric((int) (byte) 100, (int) (short) 1, (int) (short) 0);
//        java.lang.Class<?> wildcardClass23 = randomDataImpl0.getClass();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl26 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
//        double double27 = normalDistributionImpl26.getMean();
//        double double29 = normalDistributionImpl26.density((double) (short) 1);
//        double double30 = normalDistributionImpl26.sample();
//        double[] doubleArray32 = normalDistributionImpl26.sample((int) (short) 10);
//        double double35 = normalDistributionImpl26.cumulativeProbability(2.0198227150790538d, (double) 100);
//        double double36 = normalDistributionImpl26.getStandardDeviation();
//        double double38 = normalDistributionImpl26.cumulativeProbability(2.4946330620091928d);
//        normalDistributionImpl26.reseedRandomGenerator(21L);
//        double double41 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl26);
//        randomDataImpl0.reSeed();
//        double double45 = randomDataImpl0.nextF((double) 84L, 4.447426064297152d);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "5" + "'", str3.equals("5"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 7.544137102816975d + "'", double8 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.01610846091529747d + "'", double10 == 0.01610846091529747d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.190102115104095d + "'", double11 == 4.190102115104095d);
//        org.junit.Assert.assertNotNull(doubleArray13);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.9556007738814948d + "'", double16 == 0.9556007738814948d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 7.4963410017996095d + "'", double17 == 7.4963410017996095d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 8.922313350003042d + "'", double18 == 8.922313350003042d);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 7.544137102816975d + "'", double27 == 7.544137102816975d);
//        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.01610846091529747d + "'", double29 == 0.01610846091529747d);
//        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 9.512013481501333d + "'", double30 == 9.512013481501333d);
//        org.junit.Assert.assertNotNull(doubleArray32);
//        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.9556007738814948d + "'", double35 == 0.9556007738814948d);
//        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 3.246216406046493d + "'", double36 == 3.246216406046493d);
//        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.059912988687569446d + "'", double38 == 0.059912988687569446d);
//        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 8.149215906188639d + "'", double41 == 8.149215906188639d);
//        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.6049451450118561d + "'", double45 == 1.6049451450118561d);
//    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test149");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        java.lang.String str5 = randomDataImpl0.nextSecureHexString(10);
//        double double7 = randomDataImpl0.nextChiSquare(4.992376204308797d);
//        try {
//            int[] intArray10 = randomDataImpl0.nextPermutation(0, 19);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 19 is larger than the maximum (0): permutation size (19) exceeds permuation domain (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.022626313946874d + "'", double3 == 3.022626313946874d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "fda58889cc" + "'", str5.equals("fda58889cc"));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.785182668301526d + "'", double7 == 4.785182668301526d);
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.544137102816975d, 3.246216406046493d);
        double double3 = normalDistributionImpl2.getMean();
        double double6 = normalDistributionImpl2.cumulativeProbability((double) (short) -1, 3.207810091467445d);
        double double7 = normalDistributionImpl2.getStandardDeviation();
        double double8 = normalDistributionImpl2.getStandardDeviation();
        double double10 = normalDistributionImpl2.cumulativeProbability((double) 'a');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.544137102816975d + "'", double3 == 7.544137102816975d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08656193300300513d + "'", double6 == 0.08656193300300513d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.246216406046493d + "'", double7 == 3.246216406046493d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.246216406046493d + "'", double8 == 3.246216406046493d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test151");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull((double) 10, 2.99822295029797d);
//        double double6 = randomDataImpl0.nextWeibull(1.787066582172498d, 3.1622776601683795d);
//        randomDataImpl0.reSeed((long) 100);
//        long long10 = randomDataImpl0.nextPoisson(0.6511961857760066d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution11 = null;
//        try {
//            int int12 = randomDataImpl0.nextInversionDeviate(integerDistribution11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.019232566511583d + "'", double3 == 3.019232566511583d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.003158769421065d + "'", double6 == 2.003158769421065d);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//    }
//}

