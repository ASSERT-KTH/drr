import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException1 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 1);
        int int2 = maxEvaluationsExceededException1.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable12 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("hi!", objArray18);
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException(localizable12, objArray18);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException21 = new org.apache.commons.math.linear.MatrixIndexException("", objArray18);
        java.util.NoSuchElementException noSuchElementException22 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("hi!", objArray18);
        boolean boolean24 = array2DRowRealMatrix7.equals((java.lang.Object) objArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix7);
        java.lang.String str26 = array2DRowRealMatrix2.toString();
        double[][] doubleArray27 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray27);
        double double31 = blockRealMatrix30.getNorm();
        double[] doubleArray33 = null;
        try {
            blockRealMatrix30.setColumn(1, doubleArray33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(noSuchElementException22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str26.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        double[][] doubleArray2 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (short) -1, 0);
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException8 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 100, "", objArray7);
        org.apache.commons.math.exception.Localizable localizable9 = functionEvaluationException8.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable11 = null;
        org.apache.commons.math.exception.Localizable localizable15 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray21);
        org.apache.commons.math.MathRuntimeException mathRuntimeException23 = new org.apache.commons.math.MathRuntimeException(localizable15, objArray21);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException24 = new org.apache.commons.math.linear.MatrixIndexException("", objArray21);
        java.util.NoSuchElementException noSuchElementException25 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray21);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException("hi!", objArray21);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, localizable11, objArray21);
        java.lang.UnsupportedOperationException unsupportedOperationException28 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException(localizable9, objArray21);
        org.apache.commons.math.exception.Localizable localizable31 = null;
        java.lang.Object[] objArray37 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException("hi!", objArray37);
        org.apache.commons.math.MathRuntimeException mathRuntimeException39 = new org.apache.commons.math.MathRuntimeException(localizable31, objArray37);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException40 = new org.apache.commons.math.linear.MatrixIndexException("", objArray37);
        org.apache.commons.math.MathRuntimeException mathRuntimeException41 = new org.apache.commons.math.MathRuntimeException("hi!", objArray37);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException42 = new org.apache.commons.math.MaxEvaluationsExceededException(0, localizable9, objArray37);
        org.apache.commons.math.exception.Localizable localizable43 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("hi!", objArray49);
        org.apache.commons.math.MathRuntimeException mathRuntimeException51 = new org.apache.commons.math.MathRuntimeException(localizable43, objArray49);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException52 = new org.apache.commons.math.FunctionEvaluationException((double) 36, localizable9, objArray49);
        org.apache.commons.math.exception.Localizable localizable53 = null;
        java.lang.Object[] objArray59 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException("hi!", objArray59);
        org.apache.commons.math.MathRuntimeException mathRuntimeException61 = new org.apache.commons.math.MathRuntimeException(localizable53, objArray59);
        java.lang.RuntimeException runtimeException62 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) mathRuntimeException61);
        java.lang.Object[] objArray63 = mathRuntimeException61.getArguments();
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException64 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) 100, localizable9, objArray63);
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException("", objArray63);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException66 = new org.apache.commons.math.linear.InvalidMatrixException("{0}", objArray63);
        java.lang.IllegalArgumentException illegalArgumentException67 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((java.lang.Throwable) invalidMatrixException66);
        java.lang.Object[] objArray68 = invalidMatrixException66.getArguments();
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(noSuchElementException25);
        org.junit.Assert.assertNotNull(unsupportedOperationException28);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNotNull(runtimeException62);
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertNotNull(illegalArgumentException67);
        org.junit.Assert.assertNotNull(objArray68);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        boolean boolean5 = array2DRowRealMatrix2.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.copy();
        java.lang.String str7 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.MatrixUtils.checkRowIndex((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix2, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str7.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable12 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("hi!", objArray18);
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException(localizable12, objArray18);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException21 = new org.apache.commons.math.linear.MatrixIndexException("", objArray18);
        java.util.NoSuchElementException noSuchElementException22 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("hi!", objArray18);
        boolean boolean24 = array2DRowRealMatrix7.equals((java.lang.Object) objArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix7);
        java.lang.String str26 = array2DRowRealMatrix2.toString();
        double[][] doubleArray27 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray27);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int34 = array2DRowRealMatrix33.getRowDimension();
        java.lang.String str35 = array2DRowRealMatrix33.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int39 = array2DRowRealMatrix38.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable43 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("hi!", objArray49);
        org.apache.commons.math.MathRuntimeException mathRuntimeException51 = new org.apache.commons.math.MathRuntimeException(localizable43, objArray49);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException52 = new org.apache.commons.math.linear.MatrixIndexException("", objArray49);
        java.util.NoSuchElementException noSuchElementException53 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray49);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException("hi!", objArray49);
        boolean boolean55 = array2DRowRealMatrix38.equals((java.lang.Object) objArray49);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = array2DRowRealMatrix33.multiply(array2DRowRealMatrix38);
        java.lang.String str57 = array2DRowRealMatrix33.toString();
        double[][] doubleArray58 = array2DRowRealMatrix33.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray58, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix61 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray58);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix62 = blockRealMatrix30.multiply(blockRealMatrix61);
        double double63 = blockRealMatrix61.getFrobeniusNorm();
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix68 = blockRealMatrix61.getSubMatrix((int) '#', (int) (short) 0, (int) (short) 0, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 35 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(noSuchElementException22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str26.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str35.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(noSuchElementException53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str57.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(blockRealMatrix62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math.exception.Localizable localizable1 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("hi!", objArray7);
        org.apache.commons.math.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.MathRuntimeException(localizable1, objArray7);
        java.lang.RuntimeException runtimeException10 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) mathRuntimeException9);
        java.lang.Throwable[] throwableArray11 = runtimeException10.getSuppressed();
        org.apache.commons.math.optimization.OptimizationException optimizationException12 = new org.apache.commons.math.optimization.OptimizationException("", (java.lang.Object[]) throwableArray11);
        org.apache.commons.math.exception.Localizable localizable16 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException("hi!", objArray22);
        org.apache.commons.math.MathRuntimeException mathRuntimeException24 = new org.apache.commons.math.MathRuntimeException(localizable16, objArray22);
        java.lang.RuntimeException runtimeException25 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) mathRuntimeException24);
        java.lang.Throwable[] throwableArray26 = runtimeException25.getSuppressed();
        org.apache.commons.math.optimization.OptimizationException optimizationException27 = new org.apache.commons.math.optimization.OptimizationException("", (java.lang.Object[]) throwableArray26);
        java.io.EOFException eOFException28 = org.apache.commons.math.MathRuntimeException.createEOFException("", (java.lang.Object[]) throwableArray26);
        org.apache.commons.math.MathRuntimeException mathRuntimeException29 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) optimizationException12, "hi!", (java.lang.Object[]) throwableArray26);
        java.lang.String str30 = optimizationException12.toString();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(runtimeException10);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(runtimeException25);
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertNotNull(eOFException28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.apache.commons.math.optimization.OptimizationException: " + "'", str30.equals("org.apache.commons.math.optimization.OptimizationException: "));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getColumnDimension();
        boolean boolean4 = array2DRowRealMatrix2.isSquare();
        int int5 = array2DRowRealMatrix2.getRowDimension();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor6 = null;
        try {
            double double7 = array2DRowRealMatrix2.walkInColumnOrder(realMatrixChangingVisitor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        boolean boolean5 = array2DRowRealMatrix2.equals((java.lang.Object) (byte) 0);
        int int6 = array2DRowRealMatrix2.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int10 = array2DRowRealMatrix9.getRowDimension();
        boolean boolean12 = array2DRowRealMatrix9.equals((java.lang.Object) (byte) 0);
        array2DRowRealMatrix9.luDecompose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int17 = array2DRowRealMatrix16.getRowDimension();
        boolean boolean19 = array2DRowRealMatrix16.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.copy();
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix9.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int26 = array2DRowRealMatrix25.getRowDimension();
        java.lang.String str27 = array2DRowRealMatrix25.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int31 = array2DRowRealMatrix30.getRowDimension();
        boolean boolean33 = array2DRowRealMatrix30.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix34 = array2DRowRealMatrix30.copy();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = array2DRowRealMatrix25.subtract(array2DRowRealMatrix30);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = array2DRowRealMatrix16.multiply(array2DRowRealMatrix35);
        double[] doubleArray38 = new double[] { Double.NaN };
        double[] doubleArray40 = new double[] { Double.NaN };
        double[] doubleArray42 = new double[] { Double.NaN };
        double[] doubleArray44 = new double[] { Double.NaN };
        double[][] doubleArray45 = new double[][] { doubleArray38, doubleArray40, doubleArray42, doubleArray44 };
        double[][] doubleArray46 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray45);
        try {
            array2DRowRealMatrix35.setSubMatrix(doubleArray46, 36, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 36 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str27.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 10 + "'", int31 == 10);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(realMatrix34);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix35);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 100, "", objArray4);
        org.apache.commons.math.exception.Localizable localizable6 = functionEvaluationException5.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable7 = null;
        org.apache.commons.math.exception.Localizable localizable10 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("hi!", objArray16);
        org.apache.commons.math.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.MathRuntimeException(localizable10, objArray16);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException19 = new org.apache.commons.math.linear.MatrixIndexException("", objArray16);
        java.util.NoSuchElementException noSuchElementException20 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray16);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException(localizable7, objArray16);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException22 = new org.apache.commons.math.linear.InvalidMatrixException(localizable6, objArray16);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException(1000, "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}", objArray16);
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(noSuchElementException20);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException4 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 100, "", objArray3);
        org.apache.commons.math.exception.Localizable localizable5 = functionEvaluationException4.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable7 = null;
        org.apache.commons.math.exception.Localizable localizable11 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("hi!", objArray17);
        org.apache.commons.math.MathRuntimeException mathRuntimeException19 = new org.apache.commons.math.MathRuntimeException(localizable11, objArray17);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException20 = new org.apache.commons.math.linear.MatrixIndexException("", objArray17);
        java.util.NoSuchElementException noSuchElementException21 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray17);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException("hi!", objArray17);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, localizable7, objArray17);
        java.lang.UnsupportedOperationException unsupportedOperationException24 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException(localizable5, objArray17);
        java.lang.Object[] objArray28 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 100, "", objArray28);
        org.apache.commons.math.exception.Localizable localizable30 = functionEvaluationException29.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable32 = null;
        org.apache.commons.math.exception.Localizable localizable36 = null;
        java.lang.Object[] objArray42 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException("hi!", objArray42);
        org.apache.commons.math.MathRuntimeException mathRuntimeException44 = new org.apache.commons.math.MathRuntimeException(localizable36, objArray42);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException45 = new org.apache.commons.math.linear.MatrixIndexException("", objArray42);
        java.util.NoSuchElementException noSuchElementException46 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray42);
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException("hi!", objArray42);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, localizable32, objArray42);
        java.lang.UnsupportedOperationException unsupportedOperationException49 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException(localizable30, objArray42);
        org.apache.commons.math.exception.Localizable localizable52 = null;
        java.lang.Object[] objArray58 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException("hi!", objArray58);
        org.apache.commons.math.MathRuntimeException mathRuntimeException60 = new org.apache.commons.math.MathRuntimeException(localizable52, objArray58);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException61 = new org.apache.commons.math.linear.MatrixIndexException("", objArray58);
        org.apache.commons.math.MathRuntimeException mathRuntimeException62 = new org.apache.commons.math.MathRuntimeException("hi!", objArray58);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException63 = new org.apache.commons.math.MaxEvaluationsExceededException(0, localizable30, objArray58);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException64 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable5, objArray58);
        org.apache.commons.math.exception.Localizable localizable65 = null;
        java.lang.Object[] objArray71 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException72 = new org.apache.commons.math.MathException("hi!", objArray71);
        org.apache.commons.math.MathRuntimeException mathRuntimeException73 = new org.apache.commons.math.MathRuntimeException(localizable65, objArray71);
        java.lang.Object[] objArray74 = mathRuntimeException73.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException(localizable5, objArray74);
        org.apache.commons.math.exception.Localizable localizable78 = null;
        java.lang.Object[] objArray84 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException85 = new org.apache.commons.math.MathException("hi!", objArray84);
        org.apache.commons.math.MathRuntimeException mathRuntimeException86 = new org.apache.commons.math.MathRuntimeException(localizable78, objArray84);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException87 = new org.apache.commons.math.linear.MatrixIndexException("", objArray84);
        java.util.NoSuchElementException noSuchElementException88 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray84);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException89 = new org.apache.commons.math.MaxEvaluationsExceededException(1, localizable5, objArray84);
        org.apache.commons.math.exception.Localizable localizable90 = null;
        double[][] doubleArray94 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (byte) 10, 10);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException95 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("a {0}x{1} matrix was provided instead of a square matrix", (java.lang.Object[]) doubleArray94);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException96 = new org.apache.commons.math.linear.MatrixIndexException(localizable90, (java.lang.Object[]) doubleArray94);
        org.apache.commons.math.MathException mathException97 = new org.apache.commons.math.MathException(localizable5, (java.lang.Object[]) doubleArray94);
        java.lang.Throwable[] throwableArray98 = mathException97.getSuppressed();
        org.junit.Assert.assertNotNull(localizable5);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(noSuchElementException21);
        org.junit.Assert.assertNotNull(unsupportedOperationException24);
        org.junit.Assert.assertNotNull(localizable30);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(noSuchElementException46);
        org.junit.Assert.assertNotNull(unsupportedOperationException49);
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException64);
        org.junit.Assert.assertNotNull(objArray71);
        org.junit.Assert.assertNotNull(objArray74);
        org.junit.Assert.assertNotNull(objArray84);
        org.junit.Assert.assertNotNull(noSuchElementException88);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException95);
        org.junit.Assert.assertNotNull(throwableArray98);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.apache.commons.math.exception.Localizable localizable2 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray8);
        org.apache.commons.math.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.MathRuntimeException(localizable2, objArray8);
        java.lang.RuntimeException runtimeException11 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) mathRuntimeException10);
        java.lang.Throwable[] throwableArray12 = runtimeException11.getSuppressed();
        org.apache.commons.math.exception.Localizable localizable13 = null;
        org.apache.commons.math.exception.Localizable localizable14 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException("hi!", objArray20);
        org.apache.commons.math.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.MathRuntimeException(localizable14, objArray20);
        java.lang.RuntimeException runtimeException23 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) mathRuntimeException22);
        java.lang.Throwable[] throwableArray24 = runtimeException23.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) runtimeException11, localizable13, (java.lang.Object[]) throwableArray24);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException(0, "", (java.lang.Object[]) throwableArray24);
        java.lang.IllegalArgumentException illegalArgumentException27 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((java.lang.Throwable) maxIterationsExceededException26);
        java.lang.Object[] objArray31 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException32 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 100, "", objArray31);
        org.apache.commons.math.exception.Localizable localizable33 = functionEvaluationException32.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable34 = null;
        org.apache.commons.math.exception.Localizable localizable37 = null;
        java.lang.Object[] objArray43 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException("hi!", objArray43);
        org.apache.commons.math.MathRuntimeException mathRuntimeException45 = new org.apache.commons.math.MathRuntimeException(localizable37, objArray43);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException46 = new org.apache.commons.math.linear.MatrixIndexException("", objArray43);
        org.apache.commons.math.MathRuntimeException mathRuntimeException47 = new org.apache.commons.math.MathRuntimeException("hi!", objArray43);
        double[] doubleArray49 = new double[] { ' ' };
        org.apache.commons.math.exception.Localizable localizable50 = null;
        org.apache.commons.math.exception.Localizable localizable53 = null;
        java.lang.Object[] objArray59 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException("hi!", objArray59);
        org.apache.commons.math.MathRuntimeException mathRuntimeException61 = new org.apache.commons.math.MathRuntimeException(localizable53, objArray59);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException62 = new org.apache.commons.math.linear.MatrixIndexException("", objArray59);
        java.util.NoSuchElementException noSuchElementException63 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray59);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException64 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathRuntimeException47, doubleArray49, localizable50, objArray59);
        org.apache.commons.math.MathRuntimeException mathRuntimeException65 = new org.apache.commons.math.MathRuntimeException(localizable34, objArray59);
        java.lang.ArithmeticException arithmeticException66 = org.apache.commons.math.MathRuntimeException.createArithmeticException(localizable33, objArray59);
        org.apache.commons.math.exception.Localizable localizable71 = null;
        java.lang.Object[] objArray77 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException("hi!", objArray77);
        org.apache.commons.math.MathRuntimeException mathRuntimeException79 = new org.apache.commons.math.MathRuntimeException(localizable71, objArray77);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException80 = new org.apache.commons.math.linear.MatrixIndexException("", objArray77);
        java.util.NoSuchElementException noSuchElementException81 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray77);
        org.apache.commons.math.ConvergenceException convergenceException82 = new org.apache.commons.math.ConvergenceException("hi!", objArray77);
        java.lang.IllegalArgumentException illegalArgumentException83 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray77);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException84 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException26, (double) 10L, localizable33, objArray77);
        org.apache.commons.math.ConvergenceException convergenceException85 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException26);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(runtimeException11);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(runtimeException23);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNotNull(illegalArgumentException27);
        org.junit.Assert.assertNotNull(localizable33);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNotNull(noSuchElementException63);
        org.junit.Assert.assertNotNull(arithmeticException66);
        org.junit.Assert.assertNotNull(objArray77);
        org.junit.Assert.assertNotNull(noSuchElementException81);
        org.junit.Assert.assertNotNull(illegalArgumentException83);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getColumnDimension();
        boolean boolean4 = array2DRowRealMatrix2.isSquare();
        int int5 = array2DRowRealMatrix2.getRowDimension();
        try {
            org.apache.commons.math.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix2, 36, (int) (byte) 100, (int) 'a', 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 36 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        array2DRowRealMatrix2.luDecompose();
        double double6 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix7 = array2DRowRealMatrix2.copy();
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl8 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix2);
        org.apache.commons.math.linear.DecompositionSolver decompositionSolver9 = lUDecompositionImpl8.getSolver();
        double double10 = lUDecompositionImpl8.getDeterminant();
        double double11 = lUDecompositionImpl8.getDeterminant();
        int[] intArray12 = lUDecompositionImpl8.getPivot();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(decompositionSolver9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(intArray12);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 10);
        try {
            double[] doubleArray4 = blockRealMatrix2.getRow((-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index -1 out of allowed range [0, 51]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix5 = array2DRowRealMatrix2.createMatrix(10, (int) (short) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix7 = array2DRowRealMatrix2.scalarAdd((double) 100);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = array2DRowRealMatrix2.scalarAdd((double) 'a');
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix2.getSubMatrix(1, 0, 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: initial row 1 after final row 0");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(realMatrix9);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException3 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 100, "", objArray2);
        org.apache.commons.math.exception.Localizable localizable4 = functionEvaluationException3.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable5 = null;
        org.apache.commons.math.exception.Localizable localizable8 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("hi!", objArray14);
        org.apache.commons.math.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.MathRuntimeException(localizable8, objArray14);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException17 = new org.apache.commons.math.linear.MatrixIndexException("", objArray14);
        java.util.NoSuchElementException noSuchElementException18 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray14);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException(localizable5, objArray14);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException20 = new org.apache.commons.math.linear.InvalidMatrixException(localizable4, objArray14);
        java.lang.Object[] objArray21 = null;
        java.lang.NullPointerException nullPointerException22 = org.apache.commons.math.MathRuntimeException.createNullPointerException(localizable4, objArray21);
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(noSuchElementException18);
        org.junit.Assert.assertNotNull(nullPointerException22);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.apache.commons.math.exception.Localizable localizable2 = null;
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException8 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 100, "", objArray7);
        org.apache.commons.math.exception.Localizable localizable9 = functionEvaluationException8.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable11 = null;
        org.apache.commons.math.exception.Localizable localizable15 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray21);
        org.apache.commons.math.MathRuntimeException mathRuntimeException23 = new org.apache.commons.math.MathRuntimeException(localizable15, objArray21);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException24 = new org.apache.commons.math.linear.MatrixIndexException("", objArray21);
        java.util.NoSuchElementException noSuchElementException25 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray21);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException("hi!", objArray21);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, localizable11, objArray21);
        java.lang.UnsupportedOperationException unsupportedOperationException28 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException(localizable9, objArray21);
        org.apache.commons.math.exception.Localizable localizable31 = null;
        java.lang.Object[] objArray37 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException("hi!", objArray37);
        org.apache.commons.math.MathRuntimeException mathRuntimeException39 = new org.apache.commons.math.MathRuntimeException(localizable31, objArray37);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException40 = new org.apache.commons.math.linear.MatrixIndexException("", objArray37);
        org.apache.commons.math.MathRuntimeException mathRuntimeException41 = new org.apache.commons.math.MathRuntimeException("hi!", objArray37);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException42 = new org.apache.commons.math.MaxEvaluationsExceededException(0, localizable9, objArray37);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException43 = new org.apache.commons.math.linear.InvalidMatrixException("", objArray37);
        org.apache.commons.math.MathRuntimeException mathRuntimeException44 = new org.apache.commons.math.MathRuntimeException(localizable2, objArray37);
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException("Array2DRowRealMatrix{}", objArray37);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException46 = new org.apache.commons.math.linear.MatrixIndexException("org.apache.commons.math.FunctionEvaluationException: hi!", objArray37);
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(noSuchElementException25);
        org.junit.Assert.assertNotNull(unsupportedOperationException28);
        org.junit.Assert.assertNotNull(objArray37);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable12 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("hi!", objArray18);
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException(localizable12, objArray18);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException21 = new org.apache.commons.math.linear.MatrixIndexException("", objArray18);
        java.util.NoSuchElementException noSuchElementException22 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("hi!", objArray18);
        boolean boolean24 = array2DRowRealMatrix7.equals((java.lang.Object) objArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix7);
        java.lang.String str26 = array2DRowRealMatrix2.toString();
        double[][] doubleArray27 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray27);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int34 = array2DRowRealMatrix33.getRowDimension();
        java.lang.String str35 = array2DRowRealMatrix33.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int39 = array2DRowRealMatrix38.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable43 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("hi!", objArray49);
        org.apache.commons.math.MathRuntimeException mathRuntimeException51 = new org.apache.commons.math.MathRuntimeException(localizable43, objArray49);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException52 = new org.apache.commons.math.linear.MatrixIndexException("", objArray49);
        java.util.NoSuchElementException noSuchElementException53 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray49);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException("hi!", objArray49);
        boolean boolean55 = array2DRowRealMatrix38.equals((java.lang.Object) objArray49);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = array2DRowRealMatrix33.multiply(array2DRowRealMatrix38);
        java.lang.String str57 = array2DRowRealMatrix33.toString();
        double[][] doubleArray58 = array2DRowRealMatrix33.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray58, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix61 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray58);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix62 = blockRealMatrix30.multiply(blockRealMatrix61);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor63 = null;
        try {
            double double68 = blockRealMatrix62.walkInOptimizedOrder(realMatrixChangingVisitor63, (int) 'a', (int) '#', 0, 36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 97 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(noSuchElementException22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str26.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str35.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(noSuchElementException53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str57.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(blockRealMatrix62);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException6 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 100, "", objArray5);
        org.apache.commons.math.exception.Localizable localizable7 = functionEvaluationException6.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable10 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("hi!", objArray16);
        org.apache.commons.math.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.MathRuntimeException(localizable10, objArray16);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException19 = new org.apache.commons.math.linear.MatrixIndexException("", objArray16);
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException("hi!", objArray16);
        java.lang.IllegalArgumentException illegalArgumentException21 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException(localizable7, objArray16);
        org.apache.commons.math.exception.Localizable localizable25 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException("hi!", objArray31);
        org.apache.commons.math.MathRuntimeException mathRuntimeException33 = new org.apache.commons.math.MathRuntimeException(localizable25, objArray31);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException34 = new org.apache.commons.math.linear.MatrixIndexException("", objArray31);
        java.util.NoSuchElementException noSuchElementException35 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray31);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException("hi!", objArray31);
        java.lang.UnsupportedOperationException unsupportedOperationException37 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException(localizable7, objArray31);
        double[][] doubleArray40 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(10, (int) ' ');
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix42 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray40, false);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException43 = new org.apache.commons.math.MaxEvaluationsExceededException(10, localizable7, (java.lang.Object[]) doubleArray40);
        java.util.NoSuchElementException noSuchElementException44 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("org.apache.commons.math.FunctionEvaluationException: hi!", (java.lang.Object[]) doubleArray40);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException45 = new org.apache.commons.math.linear.InvalidMatrixException("{0}", (java.lang.Object[]) doubleArray40);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(illegalArgumentException21);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(noSuchElementException35);
        org.junit.Assert.assertNotNull(unsupportedOperationException37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(noSuchElementException44);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.apache.commons.math.exception.Localizable localizable2 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray8);
        org.apache.commons.math.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.MathRuntimeException(localizable2, objArray8);
        java.lang.RuntimeException runtimeException11 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) mathRuntimeException10);
        java.lang.Throwable[] throwableArray12 = runtimeException11.getSuppressed();
        java.io.IOException iOException13 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) runtimeException11);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) iOException13);
        org.apache.commons.math.exception.Localizable localizable15 = convergenceException14.getLocalizablePattern();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int19 = array2DRowRealMatrix18.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable23 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException("hi!", objArray29);
        org.apache.commons.math.MathRuntimeException mathRuntimeException31 = new org.apache.commons.math.MathRuntimeException(localizable23, objArray29);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException32 = new org.apache.commons.math.linear.MatrixIndexException("", objArray29);
        java.util.NoSuchElementException noSuchElementException33 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray29);
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException("hi!", objArray29);
        boolean boolean35 = array2DRowRealMatrix18.equals((java.lang.Object) objArray29);
        java.lang.UnsupportedOperationException unsupportedOperationException36 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException(localizable15, objArray29);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', "org.apache.commons.math.optimization.OptimizationException: ", objArray29);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(runtimeException11);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(iOException13);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable15.equals(org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(noSuchElementException33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(unsupportedOperationException36);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        boolean boolean5 = array2DRowRealMatrix2.equals((java.lang.Object) (byte) 0);
        array2DRowRealMatrix2.luDecompose();
        double[] doubleArray7 = new double[] {};
        double[] doubleArray14 = new double[] { (-1), (byte) 100, 0L, (-1L), (byte) 1, (-1.0f) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair16 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray7, doubleArray14, false);
        double[] doubleArray17 = vectorialPointValuePair16.getValue();
        double[] doubleArray18 = vectorialPointValuePair16.getValueRef();
        org.apache.commons.math.linear.RealVector realVector19 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray18);
        try {
            org.apache.commons.math.linear.RealVector realVector20 = array2DRowRealMatrix2.preMultiply(realVector19);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector19);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable12 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("hi!", objArray18);
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException(localizable12, objArray18);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException21 = new org.apache.commons.math.linear.MatrixIndexException("", objArray18);
        java.util.NoSuchElementException noSuchElementException22 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("hi!", objArray18);
        boolean boolean24 = array2DRowRealMatrix7.equals((java.lang.Object) objArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix7);
        java.lang.String str26 = array2DRowRealMatrix2.toString();
        double[][] doubleArray27 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray27);
        org.apache.commons.math.linear.RealMatrix realMatrix32 = blockRealMatrix30.scalarMultiply((double) 10);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor33 = null;
        try {
            double double34 = blockRealMatrix30.walkInColumnOrder(realMatrixChangingVisitor33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(noSuchElementException22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str26.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix32);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        boolean boolean5 = array2DRowRealMatrix2.equals((java.lang.Object) (byte) 0);
        array2DRowRealMatrix2.luDecompose();
        org.apache.commons.math.linear.RealMatrix realMatrix8 = array2DRowRealMatrix2.getColumnMatrix((int) (short) 0);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix10 = array2DRowRealMatrix2.getRowMatrix((int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 52 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(realMatrix8);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int5 = array2DRowRealMatrix4.getRowDimension();
        java.lang.String str6 = array2DRowRealMatrix4.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int10 = array2DRowRealMatrix9.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable14 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException("hi!", objArray20);
        org.apache.commons.math.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.MathRuntimeException(localizable14, objArray20);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException23 = new org.apache.commons.math.linear.MatrixIndexException("", objArray20);
        java.util.NoSuchElementException noSuchElementException24 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray20);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException("hi!", objArray20);
        boolean boolean26 = array2DRowRealMatrix9.equals((java.lang.Object) objArray20);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = array2DRowRealMatrix4.multiply(array2DRowRealMatrix9);
        java.lang.String str28 = array2DRowRealMatrix4.toString();
        double[][] doubleArray29 = array2DRowRealMatrix4.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray29);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException33 = new org.apache.commons.math.MaxEvaluationsExceededException(1000, "a {0}x{1} matrix was provided instead of a square matrix", (java.lang.Object[]) doubleArray29);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str6.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(noSuchElementException24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str28.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor3 = null;
        try {
            double double4 = array2DRowRealMatrix2.walkInColumnOrder(realMatrixChangingVisitor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        levenbergMarquardtOptimizer0.setQRRankingThreshold((double) (short) 100);
        levenbergMarquardtOptimizer0.setParRelativeTolerance((double) 2147483647);
        int int6 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        levenbergMarquardtOptimizer0.setParRelativeTolerance((double) (byte) 10);
        levenbergMarquardtOptimizer0.setCostRelativeTolerance((double) 52);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix(52, (int) (short) 100);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor3 = null;
        try {
            double double8 = array2DRowRealMatrix2.walkInRowOrder(realMatrixPreservingVisitor3, (-1), (int) (short) 0, (int) (byte) -1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index -1 out of allowed range [0, 51]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix5 = array2DRowRealMatrix2.createMatrix(10, (int) (short) 100);
        try {
            double double6 = array2DRowRealMatrix2.getDeterminant();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 52x1 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix5);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        array2DRowRealMatrix2.luDecompose();
        double double6 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix7 = array2DRowRealMatrix2.copy();
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl8 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix2);
        org.apache.commons.math.linear.DecompositionSolver decompositionSolver9 = lUDecompositionImpl8.getSolver();
        double double10 = lUDecompositionImpl8.getDeterminant();
        org.apache.commons.math.linear.RealMatrix realMatrix11 = lUDecompositionImpl8.getP();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(decompositionSolver9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNull(realMatrix11);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.apache.commons.math.exception.Localizable localizable3 = null;
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 100, "", objArray8);
        org.apache.commons.math.exception.Localizable localizable10 = functionEvaluationException9.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable12 = null;
        org.apache.commons.math.exception.Localizable localizable16 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException("hi!", objArray22);
        org.apache.commons.math.MathRuntimeException mathRuntimeException24 = new org.apache.commons.math.MathRuntimeException(localizable16, objArray22);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException25 = new org.apache.commons.math.linear.MatrixIndexException("", objArray22);
        java.util.NoSuchElementException noSuchElementException26 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray22);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException("hi!", objArray22);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, localizable12, objArray22);
        java.lang.UnsupportedOperationException unsupportedOperationException29 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException(localizable10, objArray22);
        org.apache.commons.math.exception.Localizable localizable32 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException("hi!", objArray38);
        org.apache.commons.math.MathRuntimeException mathRuntimeException40 = new org.apache.commons.math.MathRuntimeException(localizable32, objArray38);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException41 = new org.apache.commons.math.linear.MatrixIndexException("", objArray38);
        org.apache.commons.math.MathRuntimeException mathRuntimeException42 = new org.apache.commons.math.MathRuntimeException("hi!", objArray38);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException43 = new org.apache.commons.math.MaxEvaluationsExceededException(0, localizable10, objArray38);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException44 = new org.apache.commons.math.linear.InvalidMatrixException("", objArray38);
        org.apache.commons.math.MathRuntimeException mathRuntimeException45 = new org.apache.commons.math.MathRuntimeException(localizable3, objArray38);
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException("Array2DRowRealMatrix{}", objArray38);
        org.apache.commons.math.optimization.OptimizationException optimizationException47 = new org.apache.commons.math.optimization.OptimizationException("java.io.IOException: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH", objArray38);
        java.util.NoSuchElementException noSuchElementException48 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("org.apache.commons.math.FunctionEvaluationException: hi!", objArray38);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(noSuchElementException26);
        org.junit.Assert.assertNotNull(unsupportedOperationException29);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(noSuchElementException48);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}", "a {0}x{1} matrix was provided instead of a square matrix", "org.apache.commons.math.ConvergenceException: hi!", "org.apache.commons.math.optimization.OptimizationException: ", "org.apache.commons.math.FunctionEvaluationException: hi!" };
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix7 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable7 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("hi!", objArray13);
        org.apache.commons.math.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.MathRuntimeException(localizable7, objArray13);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException16 = new org.apache.commons.math.linear.MatrixIndexException("", objArray13);
        java.util.NoSuchElementException noSuchElementException17 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray13);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("hi!", objArray13);
        boolean boolean19 = array2DRowRealMatrix2.equals((java.lang.Object) objArray13);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl20 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix2);
        org.apache.commons.math.linear.RealMatrix realMatrix22 = array2DRowRealMatrix2.getRowMatrix(0);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor23 = null;
        try {
            double double24 = array2DRowRealMatrix2.walkInColumnOrder(realMatrixChangingVisitor23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(noSuchElementException17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(realMatrix22);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        java.lang.String[] strArray3 = new java.lang.String[] { "a {0}x{1} matrix was provided instead of a square matrix", "org.apache.commons.math.optimization.OptimizationException: -1", "org.apache.commons.math.MathException: " };
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix4 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(strArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.lang.Object[] objArray5 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException("hi!", objArray5);
        org.apache.commons.math.exception.Localizable localizable7 = null;
        org.apache.commons.math.exception.Localizable localizable10 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("hi!", objArray16);
        org.apache.commons.math.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.MathRuntimeException(localizable10, objArray16);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException19 = new org.apache.commons.math.linear.MatrixIndexException("", objArray16);
        java.util.NoSuchElementException noSuchElementException20 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray16);
        org.apache.commons.math.MathRuntimeException mathRuntimeException21 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) mathException6, localizable7, objArray16);
        java.lang.Object[] objArray25 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException26 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 100, "", objArray25);
        org.apache.commons.math.exception.Localizable localizable27 = functionEvaluationException26.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable30 = null;
        java.lang.Object[] objArray36 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException("hi!", objArray36);
        org.apache.commons.math.MathRuntimeException mathRuntimeException38 = new org.apache.commons.math.MathRuntimeException(localizable30, objArray36);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException39 = new org.apache.commons.math.linear.MatrixIndexException("", objArray36);
        org.apache.commons.math.MathRuntimeException mathRuntimeException40 = new org.apache.commons.math.MathRuntimeException("hi!", objArray36);
        java.lang.IllegalArgumentException illegalArgumentException41 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException(localizable27, objArray36);
        org.apache.commons.math.exception.Localizable localizable45 = null;
        java.lang.Object[] objArray51 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException("hi!", objArray51);
        org.apache.commons.math.MathRuntimeException mathRuntimeException53 = new org.apache.commons.math.MathRuntimeException(localizable45, objArray51);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException54 = new org.apache.commons.math.linear.MatrixIndexException("", objArray51);
        java.util.NoSuchElementException noSuchElementException55 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray51);
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException("hi!", objArray51);
        java.lang.UnsupportedOperationException unsupportedOperationException57 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException(localizable27, objArray51);
        double[][] doubleArray60 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(10, (int) ' ');
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix62 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray60, false);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException63 = new org.apache.commons.math.MaxEvaluationsExceededException(10, localizable27, (java.lang.Object[]) doubleArray60);
        java.lang.Object[] objArray69 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException("hi!", objArray69);
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException((java.lang.Throwable) mathRuntimeException21, localizable27, objArray69);
        java.lang.Object[] objArray72 = null;
        java.util.NoSuchElementException noSuchElementException73 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException(localizable27, objArray72);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(noSuchElementException20);
        org.junit.Assert.assertNotNull(localizable27);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(illegalArgumentException41);
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(noSuchElementException55);
        org.junit.Assert.assertNotNull(unsupportedOperationException57);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(objArray69);
        org.junit.Assert.assertNotNull(noSuchElementException73);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        double[] doubleArray6 = new double[] { (short) -1, 0, (byte) 10, 10, 1.0d, 0 };
        org.apache.commons.math.linear.RealMatrix realMatrix7 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray6);
        java.lang.Object[] objArray9 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6, "", objArray9);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException10, (double) 0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        levenbergMarquardtOptimizer0.setQRRankingThreshold((double) (short) 100);
        levenbergMarquardtOptimizer0.setParRelativeTolerance((double) 2147483647);
        int int6 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        levenbergMarquardtOptimizer0.setOrthoTolerance((double) 1000);
        int int9 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        int int10 = levenbergMarquardtOptimizer0.getEvaluations();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2147483647 + "'", int9 == 2147483647);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        int int2 = levenbergMarquardtOptimizer0.getMaxIterations();
        int int3 = levenbergMarquardtOptimizer0.getIterations();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1000 + "'", int2 == 1000);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        java.lang.Object[] objArray1 = null;
        java.lang.ArithmeticException arithmeticException2 = org.apache.commons.math.MathRuntimeException.createArithmeticException("org.apache.commons.math.ConvergenceException: hi!", objArray1);
        org.junit.Assert.assertNotNull(arithmeticException2);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray8 = new double[] { (-1), (byte) 100, 0L, (-1L), (byte) 1, (-1.0f) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair10 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray1, doubleArray8, false);
        double[] doubleArray11 = new double[] {};
        double[] doubleArray18 = new double[] { (-1), (byte) 100, 0L, (-1L), (byte) 1, (-1.0f) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair20 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray11, doubleArray18, false);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair21 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray8, doubleArray11);
        double[] doubleArray22 = vectorialPointValuePair21.getPoint();
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair24 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray0, doubleArray22, false);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.math.BigDecimal[] bigDecimalArray0 = null;
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix1 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(bigDecimalArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable12 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("hi!", objArray18);
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException(localizable12, objArray18);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException21 = new org.apache.commons.math.linear.MatrixIndexException("", objArray18);
        java.util.NoSuchElementException noSuchElementException22 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("hi!", objArray18);
        boolean boolean24 = array2DRowRealMatrix7.equals((java.lang.Object) objArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix7);
        java.lang.String str26 = array2DRowRealMatrix2.toString();
        double[][] doubleArray27 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray27);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int34 = array2DRowRealMatrix33.getRowDimension();
        java.lang.String str35 = array2DRowRealMatrix33.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int39 = array2DRowRealMatrix38.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable43 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("hi!", objArray49);
        org.apache.commons.math.MathRuntimeException mathRuntimeException51 = new org.apache.commons.math.MathRuntimeException(localizable43, objArray49);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException52 = new org.apache.commons.math.linear.MatrixIndexException("", objArray49);
        java.util.NoSuchElementException noSuchElementException53 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray49);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException("hi!", objArray49);
        boolean boolean55 = array2DRowRealMatrix38.equals((java.lang.Object) objArray49);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = array2DRowRealMatrix33.multiply(array2DRowRealMatrix38);
        java.lang.String str57 = array2DRowRealMatrix33.toString();
        double[][] doubleArray58 = array2DRowRealMatrix33.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray58, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix61 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray58);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix62 = blockRealMatrix30.multiply(blockRealMatrix61);
        double double63 = blockRealMatrix61.getFrobeniusNorm();
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix65 = blockRealMatrix61.getColumnMatrix(2147483647);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 2,147,483,647 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(noSuchElementException22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str26.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str35.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(noSuchElementException53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str57.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(blockRealMatrix62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getRowDimension();
        boolean boolean10 = array2DRowRealMatrix7.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix11 = array2DRowRealMatrix7.copy();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix7);
        org.apache.commons.math.exception.Localizable localizable15 = null;
        org.apache.commons.math.exception.Localizable localizable17 = null;
        org.apache.commons.math.exception.Localizable localizable20 = null;
        java.lang.Object[] objArray26 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException("hi!", objArray26);
        org.apache.commons.math.MathRuntimeException mathRuntimeException28 = new org.apache.commons.math.MathRuntimeException(localizable20, objArray26);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException29 = new org.apache.commons.math.linear.MatrixIndexException("", objArray26);
        java.util.NoSuchElementException noSuchElementException30 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray26);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException31 = new org.apache.commons.math.FunctionEvaluationException(1.0d, localizable17, objArray26);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100, localizable15, objArray26);
        double[] doubleArray33 = new double[] {};
        double[] doubleArray40 = new double[] { (-1), (byte) 100, 0L, (-1L), (byte) 1, (-1.0f) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair42 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray33, doubleArray40, false);
        double[] doubleArray43 = vectorialPointValuePair42.getValue();
        org.apache.commons.math.exception.Localizable localizable45 = null;
        java.lang.Object[] objArray51 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException("hi!", objArray51);
        org.apache.commons.math.MathRuntimeException mathRuntimeException53 = new org.apache.commons.math.MathRuntimeException(localizable45, objArray51);
        java.lang.RuntimeException runtimeException54 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) mathRuntimeException53);
        java.lang.Throwable[] throwableArray55 = runtimeException54.getSuppressed();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException56 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException32, doubleArray43, "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}", (java.lang.Object[]) throwableArray55);
        org.apache.commons.math.linear.BigMatrix bigMatrix57 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray43);
        org.apache.commons.math.linear.RealMatrix realMatrix58 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray43);
        try {
            array2DRowRealMatrix7.setColumn(52, doubleArray43);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 52 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(noSuchElementException30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(runtimeException54);
        org.junit.Assert.assertNotNull(throwableArray55);
        org.junit.Assert.assertNotNull(bigMatrix57);
        org.junit.Assert.assertNotNull(realMatrix58);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getRowDimension();
        boolean boolean10 = array2DRowRealMatrix7.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix11 = array2DRowRealMatrix7.copy();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix7);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl13 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix2);
        double double14 = array2DRowRealMatrix2.getDeterminant();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        java.lang.Throwable throwable0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray8 = new double[] { (-1), (byte) 100, 0L, (-1L), (byte) 1, (-1.0f) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair10 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray1, doubleArray8, false);
        double[] doubleArray11 = vectorialPointValuePair10.getValue();
        double[] doubleArray12 = vectorialPointValuePair10.getPointRef();
        java.lang.Throwable throwable14 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException(throwable14, 1.0d);
        org.apache.commons.math.exception.Localizable localizable17 = null;
        org.apache.commons.math.exception.Localizable localizable19 = null;
        org.apache.commons.math.exception.Localizable localizable23 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException("hi!", objArray29);
        org.apache.commons.math.MathRuntimeException mathRuntimeException31 = new org.apache.commons.math.MathRuntimeException(localizable23, objArray29);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException32 = new org.apache.commons.math.linear.MatrixIndexException("", objArray29);
        java.util.NoSuchElementException noSuchElementException33 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray29);
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException("hi!", objArray29);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, localizable19, objArray29);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) functionEvaluationException16, localizable17, objArray29);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException37 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray12, "hi!", objArray29);
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (byte) 10, 10);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException43 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("a {0}x{1} matrix was provided instead of a square matrix", (java.lang.Object[]) doubleArray42);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException(doubleArray12, "", (java.lang.Object[]) doubleArray42);
        double[][] doubleArray45 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(noSuchElementException33);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException43);
        org.junit.Assert.assertNotNull(doubleArray45);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor3 = null;
        try {
            double double8 = array2DRowRealMatrix2.walkInOptimizedOrder(realMatrixChangingVisitor3, (int) (byte) 10, (int) (byte) 10, (int) (short) -1, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 10 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable12 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("hi!", objArray18);
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException(localizable12, objArray18);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException21 = new org.apache.commons.math.linear.MatrixIndexException("", objArray18);
        java.util.NoSuchElementException noSuchElementException22 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("hi!", objArray18);
        boolean boolean24 = array2DRowRealMatrix7.equals((java.lang.Object) objArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix7);
        java.lang.String str26 = array2DRowRealMatrix2.toString();
        double[][] doubleArray27 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray27);
        double[][] doubleArray34 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(10, (int) ' ');
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray34, false);
        org.apache.commons.math.linear.RealVector realVector38 = array2DRowRealMatrix36.getColumnVector(100);
        try {
            blockRealMatrix30.setRowVector(100, realVector38);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(noSuchElementException22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str26.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realVector38);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable12 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("hi!", objArray18);
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException(localizable12, objArray18);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException21 = new org.apache.commons.math.linear.MatrixIndexException("", objArray18);
        java.util.NoSuchElementException noSuchElementException22 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("hi!", objArray18);
        boolean boolean24 = array2DRowRealMatrix7.equals((java.lang.Object) objArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix7);
        java.lang.String str26 = array2DRowRealMatrix2.toString();
        double[][] doubleArray27 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray27);
        double double31 = blockRealMatrix30.getNorm();
        double[] doubleArray33 = new double[] {};
        double[] doubleArray40 = new double[] { (-1), (byte) 100, 0L, (-1L), (byte) 1, (-1.0f) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair42 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray33, doubleArray40, false);
        double[] doubleArray43 = vectorialPointValuePair42.getPointRef();
        double[] doubleArray44 = null;
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair45 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray43, doubleArray44);
        try {
            blockRealMatrix30.setColumn((-1), doubleArray44);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index -1 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(noSuchElementException22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str26.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable12 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("hi!", objArray18);
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException(localizable12, objArray18);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException21 = new org.apache.commons.math.linear.MatrixIndexException("", objArray18);
        java.util.NoSuchElementException noSuchElementException22 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("hi!", objArray18);
        boolean boolean24 = array2DRowRealMatrix7.equals((java.lang.Object) objArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix7);
        java.lang.String str26 = array2DRowRealMatrix2.toString();
        double[][] doubleArray27 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray27);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int34 = array2DRowRealMatrix33.getRowDimension();
        java.lang.String str35 = array2DRowRealMatrix33.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int39 = array2DRowRealMatrix38.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable43 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("hi!", objArray49);
        org.apache.commons.math.MathRuntimeException mathRuntimeException51 = new org.apache.commons.math.MathRuntimeException(localizable43, objArray49);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException52 = new org.apache.commons.math.linear.MatrixIndexException("", objArray49);
        java.util.NoSuchElementException noSuchElementException53 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray49);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException("hi!", objArray49);
        boolean boolean55 = array2DRowRealMatrix38.equals((java.lang.Object) objArray49);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = array2DRowRealMatrix33.multiply(array2DRowRealMatrix38);
        java.lang.String str57 = array2DRowRealMatrix33.toString();
        double[][] doubleArray58 = array2DRowRealMatrix33.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray58, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix61 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray58);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix62 = blockRealMatrix30.multiply(blockRealMatrix61);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor63 = null;
        try {
            double double64 = blockRealMatrix61.walkInOptimizedOrder(realMatrixChangingVisitor63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(noSuchElementException22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str26.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str35.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(noSuchElementException53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str57.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(blockRealMatrix62);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable12 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("hi!", objArray18);
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException(localizable12, objArray18);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException21 = new org.apache.commons.math.linear.MatrixIndexException("", objArray18);
        java.util.NoSuchElementException noSuchElementException22 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("hi!", objArray18);
        boolean boolean24 = array2DRowRealMatrix7.equals((java.lang.Object) objArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix7);
        java.lang.String str26 = array2DRowRealMatrix2.toString();
        double[][] doubleArray27 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray27);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int34 = array2DRowRealMatrix33.getRowDimension();
        java.lang.String str35 = array2DRowRealMatrix33.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int39 = array2DRowRealMatrix38.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable43 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("hi!", objArray49);
        org.apache.commons.math.MathRuntimeException mathRuntimeException51 = new org.apache.commons.math.MathRuntimeException(localizable43, objArray49);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException52 = new org.apache.commons.math.linear.MatrixIndexException("", objArray49);
        java.util.NoSuchElementException noSuchElementException53 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray49);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException("hi!", objArray49);
        boolean boolean55 = array2DRowRealMatrix38.equals((java.lang.Object) objArray49);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = array2DRowRealMatrix33.multiply(array2DRowRealMatrix38);
        java.lang.String str57 = array2DRowRealMatrix33.toString();
        double[][] doubleArray58 = array2DRowRealMatrix33.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray58, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix61 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray58);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix62 = blockRealMatrix30.multiply(blockRealMatrix61);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor63 = null;
        try {
            double double68 = blockRealMatrix30.walkInOptimizedOrder(realMatrixPreservingVisitor63, (int) (byte) 1, 36, (int) 'a', (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 36 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(noSuchElementException22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str26.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str35.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(noSuchElementException53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str57.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(blockRealMatrix62);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.apache.commons.math.exception.Localizable localizable1 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("hi!", objArray11);
        org.apache.commons.math.MathRuntimeException mathRuntimeException13 = new org.apache.commons.math.MathRuntimeException(localizable5, objArray11);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException14 = new org.apache.commons.math.linear.MatrixIndexException("", objArray11);
        java.util.NoSuchElementException noSuchElementException15 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray11);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException("hi!", objArray11);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, localizable1, objArray11);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException17);
        double[] doubleArray24 = new double[] { 0, (short) -1, '#', (short) 100, 1.0d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathException18, doubleArray24);
        java.lang.IllegalArgumentException illegalArgumentException26 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((java.lang.Throwable) mathException18);
        java.lang.String str27 = mathException18.getPattern();
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(noSuchElementException15);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(illegalArgumentException26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "{0}" + "'", str27.equals("{0}"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        boolean boolean5 = array2DRowRealMatrix2.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix7 = array2DRowRealMatrix2.scalarMultiply((double) 0.0f);
        try {
            double[] doubleArray9 = array2DRowRealMatrix2.getRow((-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index -1 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(realMatrix7);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        boolean boolean5 = array2DRowRealMatrix2.equals((java.lang.Object) (byte) 0);
        int int6 = array2DRowRealMatrix2.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int10 = array2DRowRealMatrix9.getRowDimension();
        boolean boolean12 = array2DRowRealMatrix9.equals((java.lang.Object) (byte) 0);
        array2DRowRealMatrix9.luDecompose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int17 = array2DRowRealMatrix16.getRowDimension();
        boolean boolean19 = array2DRowRealMatrix16.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.copy();
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix9.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int26 = array2DRowRealMatrix25.getRowDimension();
        boolean boolean28 = array2DRowRealMatrix25.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = array2DRowRealMatrix22.add(array2DRowRealMatrix25);
        double double30 = array2DRowRealMatrix25.getNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix32 = array2DRowRealMatrix25.getRowMatrix(0);
        org.apache.commons.math.linear.RealMatrix realMatrix33 = array2DRowRealMatrix25.transpose();
        array2DRowRealMatrix25.luDecompose();
        int[] intArray41 = new int[] { 2147483647, (byte) 10, (byte) 100, (short) 100, (byte) 1, 'a' };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int45 = array2DRowRealMatrix44.getRowDimension();
        java.lang.String str46 = array2DRowRealMatrix44.toString();
        array2DRowRealMatrix44.luDecompose();
        double double48 = array2DRowRealMatrix44.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix49 = array2DRowRealMatrix44.copy();
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl50 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix44);
        int[] intArray51 = lUDecompositionImpl50.getPivot();
        try {
            org.apache.commons.math.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix25, intArray41, intArray51);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 2,147,483,647 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix32);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 10 + "'", int45 == 10);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str46.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix49);
        org.junit.Assert.assertNotNull(intArray51);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        boolean boolean5 = array2DRowRealMatrix2.equals((java.lang.Object) (byte) 0);
        int int6 = array2DRowRealMatrix2.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int10 = array2DRowRealMatrix9.getRowDimension();
        boolean boolean12 = array2DRowRealMatrix9.equals((java.lang.Object) (byte) 0);
        array2DRowRealMatrix9.luDecompose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int17 = array2DRowRealMatrix16.getRowDimension();
        boolean boolean19 = array2DRowRealMatrix16.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.copy();
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix9.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int26 = array2DRowRealMatrix25.getRowDimension();
        boolean boolean28 = array2DRowRealMatrix25.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = array2DRowRealMatrix22.add(array2DRowRealMatrix25);
        int int30 = array2DRowRealMatrix25.getRowDimension();
        int int31 = array2DRowRealMatrix25.getRowDimension();
        double[] doubleArray32 = new double[] {};
        double[] doubleArray39 = new double[] { (-1), (byte) 100, 0L, (-1L), (byte) 1, (-1.0f) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair41 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray32, doubleArray39, false);
        double[] doubleArray42 = vectorialPointValuePair41.getValue();
        double[] doubleArray43 = vectorialPointValuePair41.getValueRef();
        org.apache.commons.math.linear.RealVector realVector44 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray43);
        try {
            double[] doubleArray45 = array2DRowRealMatrix25.preMultiply(doubleArray43);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 10 + "'", int30 == 10);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 10 + "'", int31 == 10);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(realVector44);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException3 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 100, "", objArray2);
        org.apache.commons.math.exception.Localizable localizable4 = functionEvaluationException3.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable6 = null;
        org.apache.commons.math.exception.Localizable localizable10 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("hi!", objArray16);
        org.apache.commons.math.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.MathRuntimeException(localizable10, objArray16);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException19 = new org.apache.commons.math.linear.MatrixIndexException("", objArray16);
        java.util.NoSuchElementException noSuchElementException20 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray16);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException("hi!", objArray16);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException22 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, localizable6, objArray16);
        java.lang.UnsupportedOperationException unsupportedOperationException23 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException(localizable4, objArray16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int27 = array2DRowRealMatrix26.getColumnDimension();
        double[][] doubleArray28 = array2DRowRealMatrix26.getDataRef();
        org.apache.commons.math.MathRuntimeException mathRuntimeException29 = new org.apache.commons.math.MathRuntimeException(localizable4, (java.lang.Object[]) doubleArray28);
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(noSuchElementException20);
        org.junit.Assert.assertNotNull(unsupportedOperationException23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        java.lang.String str1 = array2DRowRealMatrix0.toString();
        double double2 = array2DRowRealMatrix0.getNorm();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor3 = null;
        try {
            double double8 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixChangingVisitor3, 0, (int) (short) 10, (int) '4', (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 0 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Array2DRowRealMatrix{}" + "'", str1.equals("Array2DRowRealMatrix{}"));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setMaxEvaluations(52);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.apache.commons.math.exception.Localizable localizable4 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException("hi!", objArray10);
        org.apache.commons.math.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.MathRuntimeException(localizable4, objArray10);
        java.lang.RuntimeException runtimeException13 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) mathRuntimeException12);
        java.lang.Throwable[] throwableArray14 = runtimeException13.getSuppressed();
        org.apache.commons.math.exception.Localizable localizable15 = null;
        org.apache.commons.math.exception.Localizable localizable16 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException("hi!", objArray22);
        org.apache.commons.math.MathRuntimeException mathRuntimeException24 = new org.apache.commons.math.MathRuntimeException(localizable16, objArray22);
        java.lang.RuntimeException runtimeException25 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) mathRuntimeException24);
        java.lang.Throwable[] throwableArray26 = runtimeException25.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) runtimeException13, localizable15, (java.lang.Object[]) throwableArray26);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException(0, "", (java.lang.Object[]) throwableArray26);
        java.text.ParseException parseException29 = org.apache.commons.math.MathRuntimeException.createParseException((int) ' ', "org.apache.commons.math.optimization.OptimizationException: ", (java.lang.Object[]) throwableArray26);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(runtimeException13);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(runtimeException25);
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertNotNull(parseException29);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.apache.commons.math.exception.Localizable localizable4 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException("hi!", objArray10);
        org.apache.commons.math.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.MathRuntimeException(localizable4, objArray10);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException13 = new org.apache.commons.math.linear.MatrixIndexException("", objArray10);
        java.util.NoSuchElementException noSuchElementException14 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray10);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("hi!", objArray10);
        java.lang.IllegalArgumentException illegalArgumentException16 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray10);
        java.lang.Object[] objArray20 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException21 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 100, "", objArray20);
        org.apache.commons.math.exception.Localizable localizable22 = functionEvaluationException21.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable24 = null;
        org.apache.commons.math.exception.Localizable localizable28 = null;
        java.lang.Object[] objArray34 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException("hi!", objArray34);
        org.apache.commons.math.MathRuntimeException mathRuntimeException36 = new org.apache.commons.math.MathRuntimeException(localizable28, objArray34);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException37 = new org.apache.commons.math.linear.MatrixIndexException("", objArray34);
        java.util.NoSuchElementException noSuchElementException38 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray34);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException("hi!", objArray34);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException40 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, localizable24, objArray34);
        java.lang.UnsupportedOperationException unsupportedOperationException41 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException(localizable22, objArray34);
        org.apache.commons.math.exception.Localizable localizable44 = null;
        java.lang.Object[] objArray50 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException("hi!", objArray50);
        org.apache.commons.math.MathRuntimeException mathRuntimeException52 = new org.apache.commons.math.MathRuntimeException(localizable44, objArray50);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException53 = new org.apache.commons.math.linear.MatrixIndexException("", objArray50);
        org.apache.commons.math.MathRuntimeException mathRuntimeException54 = new org.apache.commons.math.MathRuntimeException("hi!", objArray50);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException55 = new org.apache.commons.math.MaxEvaluationsExceededException(0, localizable22, objArray50);
        org.apache.commons.math.exception.Localizable localizable57 = null;
        org.apache.commons.math.exception.Localizable localizable61 = null;
        java.lang.Object[] objArray67 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException("hi!", objArray67);
        org.apache.commons.math.MathRuntimeException mathRuntimeException69 = new org.apache.commons.math.MathRuntimeException(localizable61, objArray67);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException70 = new org.apache.commons.math.linear.MatrixIndexException("", objArray67);
        java.util.NoSuchElementException noSuchElementException71 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray67);
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException("hi!", objArray67);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException73 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, localizable57, objArray67);
        org.apache.commons.math.MathException mathException74 = new org.apache.commons.math.MathException((java.lang.Throwable) illegalArgumentException16, localizable22, objArray67);
        org.apache.commons.math.exception.Localizable localizable80 = null;
        java.lang.Object[] objArray86 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException87 = new org.apache.commons.math.MathException("hi!", objArray86);
        org.apache.commons.math.MathRuntimeException mathRuntimeException88 = new org.apache.commons.math.MathRuntimeException(localizable80, objArray86);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException89 = new org.apache.commons.math.linear.MatrixIndexException("", objArray86);
        java.util.NoSuchElementException noSuchElementException90 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray86);
        org.apache.commons.math.ConvergenceException convergenceException91 = new org.apache.commons.math.ConvergenceException("hi!", objArray86);
        java.text.ParseException parseException92 = org.apache.commons.math.MathRuntimeException.createParseException(0, "hi!", objArray86);
        java.lang.IllegalStateException illegalStateException93 = org.apache.commons.math.MathRuntimeException.createIllegalStateException(localizable22, objArray86);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(noSuchElementException14);
        org.junit.Assert.assertNotNull(illegalArgumentException16);
        org.junit.Assert.assertNotNull(localizable22);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(noSuchElementException38);
        org.junit.Assert.assertNotNull(unsupportedOperationException41);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertNotNull(noSuchElementException71);
        org.junit.Assert.assertNotNull(objArray86);
        org.junit.Assert.assertNotNull(noSuchElementException90);
        org.junit.Assert.assertNotNull(parseException92);
        org.junit.Assert.assertNotNull(illegalStateException93);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.apache.commons.math.exception.Localizable localizable2 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray8);
        org.apache.commons.math.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.MathRuntimeException(localizable2, objArray8);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException11 = new org.apache.commons.math.linear.MatrixIndexException("", objArray8);
        org.apache.commons.math.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.MathRuntimeException("hi!", objArray8);
        double[] doubleArray14 = new double[] { ' ' };
        org.apache.commons.math.exception.Localizable localizable15 = null;
        org.apache.commons.math.exception.Localizable localizable18 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException("hi!", objArray24);
        org.apache.commons.math.MathRuntimeException mathRuntimeException26 = new org.apache.commons.math.MathRuntimeException(localizable18, objArray24);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException27 = new org.apache.commons.math.linear.MatrixIndexException("", objArray24);
        java.util.NoSuchElementException noSuchElementException28 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray24);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathRuntimeException12, doubleArray14, localizable15, objArray24);
        java.lang.Object[] objArray30 = mathRuntimeException12.getArguments();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(noSuchElementException28);
        org.junit.Assert.assertNotNull(objArray30);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable12 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("hi!", objArray18);
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException(localizable12, objArray18);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException21 = new org.apache.commons.math.linear.MatrixIndexException("", objArray18);
        java.util.NoSuchElementException noSuchElementException22 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("hi!", objArray18);
        boolean boolean24 = array2DRowRealMatrix7.equals((java.lang.Object) objArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix7);
        java.lang.String str26 = array2DRowRealMatrix2.toString();
        double[][] doubleArray27 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray27);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int34 = array2DRowRealMatrix33.getRowDimension();
        java.lang.String str35 = array2DRowRealMatrix33.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int39 = array2DRowRealMatrix38.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable43 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("hi!", objArray49);
        org.apache.commons.math.MathRuntimeException mathRuntimeException51 = new org.apache.commons.math.MathRuntimeException(localizable43, objArray49);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException52 = new org.apache.commons.math.linear.MatrixIndexException("", objArray49);
        java.util.NoSuchElementException noSuchElementException53 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray49);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException("hi!", objArray49);
        boolean boolean55 = array2DRowRealMatrix38.equals((java.lang.Object) objArray49);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = array2DRowRealMatrix33.multiply(array2DRowRealMatrix38);
        java.lang.String str57 = array2DRowRealMatrix33.toString();
        double[][] doubleArray58 = array2DRowRealMatrix33.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray58, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix61 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray58);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix62 = blockRealMatrix30.multiply(blockRealMatrix61);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix64 = blockRealMatrix61.getColumnMatrix(0);
        try {
            org.apache.commons.math.linear.RealVector realVector66 = blockRealMatrix64.getColumnVector((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 97 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(noSuchElementException22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str26.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str35.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(noSuchElementException53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str57.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(blockRealMatrix62);
        org.junit.Assert.assertNotNull(blockRealMatrix64);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        java.lang.String str1 = array2DRowRealMatrix0.toString();
        double double2 = array2DRowRealMatrix0.getNorm();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) '4', (int) (short) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = array2DRowRealMatrix5.createMatrix(10, (int) (short) 100);
        try {
            org.apache.commons.math.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix0, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix5);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Array2DRowRealMatrix{}" + "'", str1.equals("Array2DRowRealMatrix{}"));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix8);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        boolean boolean1 = array2DRowRealMatrix0.isSingular();
        boolean boolean2 = array2DRowRealMatrix0.isSingular();
        boolean boolean3 = array2DRowRealMatrix0.isSquare();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix8 = array2DRowRealMatrix0.getSubMatrix((int) '4', 100, 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 52 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        java.lang.Object[] objArray6 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException("hi!", objArray6);
        org.apache.commons.math.optimization.OptimizationException optimizationException8 = new org.apache.commons.math.optimization.OptimizationException("org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", objArray6);
        org.junit.Assert.assertNotNull(objArray6);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable12 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("hi!", objArray18);
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException(localizable12, objArray18);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException21 = new org.apache.commons.math.linear.MatrixIndexException("", objArray18);
        java.util.NoSuchElementException noSuchElementException22 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("hi!", objArray18);
        boolean boolean24 = array2DRowRealMatrix7.equals((java.lang.Object) objArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix7);
        java.lang.String str26 = array2DRowRealMatrix2.toString();
        double[][] doubleArray27 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray27);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int34 = array2DRowRealMatrix33.getRowDimension();
        java.lang.String str35 = array2DRowRealMatrix33.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int39 = array2DRowRealMatrix38.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable43 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("hi!", objArray49);
        org.apache.commons.math.MathRuntimeException mathRuntimeException51 = new org.apache.commons.math.MathRuntimeException(localizable43, objArray49);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException52 = new org.apache.commons.math.linear.MatrixIndexException("", objArray49);
        java.util.NoSuchElementException noSuchElementException53 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray49);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException("hi!", objArray49);
        boolean boolean55 = array2DRowRealMatrix38.equals((java.lang.Object) objArray49);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = array2DRowRealMatrix33.multiply(array2DRowRealMatrix38);
        java.lang.String str57 = array2DRowRealMatrix33.toString();
        double[][] doubleArray58 = array2DRowRealMatrix33.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray58, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix61 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray58);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix62 = blockRealMatrix30.multiply(blockRealMatrix61);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix64 = blockRealMatrix62.scalarAdd((double) 0);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor65 = null;
        try {
            double double70 = blockRealMatrix62.walkInRowOrder(realMatrixPreservingVisitor65, 0, (int) (byte) 10, 2147483647, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 10 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(noSuchElementException22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str26.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str35.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(noSuchElementException53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str57.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(blockRealMatrix62);
        org.junit.Assert.assertNotNull(blockRealMatrix64);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        java.lang.Object obj0 = null;
        java.io.ObjectInputStream objectInputStream2 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.deserializeRealVector(obj0, "", objectInputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        boolean boolean5 = array2DRowRealMatrix2.equals((java.lang.Object) (byte) 0);
        int int6 = array2DRowRealMatrix2.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int10 = array2DRowRealMatrix9.getRowDimension();
        boolean boolean12 = array2DRowRealMatrix9.equals((java.lang.Object) (byte) 0);
        array2DRowRealMatrix9.luDecompose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int17 = array2DRowRealMatrix16.getRowDimension();
        boolean boolean19 = array2DRowRealMatrix16.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.copy();
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix9.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int26 = array2DRowRealMatrix25.getRowDimension();
        java.lang.String str27 = array2DRowRealMatrix25.toString();
        array2DRowRealMatrix25.luDecompose();
        org.apache.commons.math.linear.RealMatrix realMatrix29 = array2DRowRealMatrix25.copy();
        double double30 = array2DRowRealMatrix25.getDeterminant();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix25);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor32 = null;
        try {
            double double33 = array2DRowRealMatrix2.walkInRowOrder(realMatrixPreservingVisitor32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str27.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix31);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.apache.commons.math.linear.RealMatrix realMatrix2 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(36, 10);
        org.junit.Assert.assertNotNull(realMatrix2);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.apache.commons.math.exception.Localizable localizable3 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("hi!", objArray9);
        org.apache.commons.math.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.MathRuntimeException(localizable3, objArray9);
        java.lang.RuntimeException runtimeException12 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) mathRuntimeException11);
        java.lang.Throwable[] throwableArray13 = runtimeException12.getSuppressed();
        org.apache.commons.math.optimization.OptimizationException optimizationException14 = new org.apache.commons.math.optimization.OptimizationException("", (java.lang.Object[]) throwableArray13);
        java.io.EOFException eOFException15 = org.apache.commons.math.MathRuntimeException.createEOFException("", (java.lang.Object[]) throwableArray13);
        java.lang.NullPointerException nullPointerException16 = org.apache.commons.math.MathRuntimeException.createNullPointerException("java.io.IOException: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH", (java.lang.Object[]) throwableArray13);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(runtimeException12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(eOFException15);
        org.junit.Assert.assertNotNull(nullPointerException16);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException4 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 100, "", objArray3);
        org.apache.commons.math.exception.Localizable localizable5 = functionEvaluationException4.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable6 = null;
        org.apache.commons.math.exception.Localizable localizable9 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("hi!", objArray15);
        org.apache.commons.math.MathRuntimeException mathRuntimeException17 = new org.apache.commons.math.MathRuntimeException(localizable9, objArray15);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException18 = new org.apache.commons.math.linear.MatrixIndexException("", objArray15);
        java.util.NoSuchElementException noSuchElementException19 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray15);
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException(localizable6, objArray15);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException21 = new org.apache.commons.math.linear.InvalidMatrixException(localizable5, objArray15);
        double[][] doubleArray24 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (byte) 10, 10);
        org.apache.commons.math.linear.BigMatrix bigMatrix25 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(doubleArray24);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException29 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 10, localizable5, (java.lang.Object[]) doubleArray24);
        org.junit.Assert.assertNotNull(localizable5);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(noSuchElementException19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(bigMatrix25);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable12 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("hi!", objArray18);
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException(localizable12, objArray18);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException21 = new org.apache.commons.math.linear.MatrixIndexException("", objArray18);
        java.util.NoSuchElementException noSuchElementException22 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("hi!", objArray18);
        boolean boolean24 = array2DRowRealMatrix7.equals((java.lang.Object) objArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix7);
        java.lang.String str26 = array2DRowRealMatrix2.toString();
        double[][] doubleArray27 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray27);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int34 = array2DRowRealMatrix33.getRowDimension();
        java.lang.String str35 = array2DRowRealMatrix33.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int39 = array2DRowRealMatrix38.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable43 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("hi!", objArray49);
        org.apache.commons.math.MathRuntimeException mathRuntimeException51 = new org.apache.commons.math.MathRuntimeException(localizable43, objArray49);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException52 = new org.apache.commons.math.linear.MatrixIndexException("", objArray49);
        java.util.NoSuchElementException noSuchElementException53 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray49);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException("hi!", objArray49);
        boolean boolean55 = array2DRowRealMatrix38.equals((java.lang.Object) objArray49);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = array2DRowRealMatrix33.multiply(array2DRowRealMatrix38);
        java.lang.String str57 = array2DRowRealMatrix33.toString();
        double[][] doubleArray58 = array2DRowRealMatrix33.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray58, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix61 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray58);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix62 = blockRealMatrix30.multiply(blockRealMatrix61);
        double double63 = blockRealMatrix61.getFrobeniusNorm();
        org.apache.commons.math.linear.RealVector realVector65 = blockRealMatrix61.getColumnVector(0);
        try {
            blockRealMatrix61.multiplyEntry(1, 2147483647, (double) (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (1, 2,147,483,647) in a 10x10 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(noSuchElementException22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str26.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str35.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(noSuchElementException53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str57.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(blockRealMatrix62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(realVector65);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        boolean boolean5 = array2DRowRealMatrix2.equals((java.lang.Object) (byte) 0);
        int int6 = array2DRowRealMatrix2.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int10 = array2DRowRealMatrix9.getRowDimension();
        boolean boolean12 = array2DRowRealMatrix9.equals((java.lang.Object) (byte) 0);
        array2DRowRealMatrix9.luDecompose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int17 = array2DRowRealMatrix16.getRowDimension();
        boolean boolean19 = array2DRowRealMatrix16.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.copy();
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix9.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int26 = array2DRowRealMatrix25.getRowDimension();
        boolean boolean28 = array2DRowRealMatrix25.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = array2DRowRealMatrix22.add(array2DRowRealMatrix25);
        double double30 = array2DRowRealMatrix25.getNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix32 = array2DRowRealMatrix25.getRowMatrix(0);
        org.apache.commons.math.linear.RealMatrix realMatrix33 = array2DRowRealMatrix25.transpose();
        array2DRowRealMatrix25.luDecompose();
        try {
            array2DRowRealMatrix25.multiplyEntry((int) (byte) 100, (-1), (double) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (100, -1) in a 10x10 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix32);
        org.junit.Assert.assertNotNull(realMatrix33);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        boolean boolean5 = array2DRowRealMatrix2.equals((java.lang.Object) (byte) 0);
        int int6 = array2DRowRealMatrix2.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int10 = array2DRowRealMatrix9.getRowDimension();
        boolean boolean12 = array2DRowRealMatrix9.equals((java.lang.Object) (byte) 0);
        array2DRowRealMatrix9.luDecompose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int17 = array2DRowRealMatrix16.getRowDimension();
        boolean boolean19 = array2DRowRealMatrix16.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.copy();
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix9.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int26 = array2DRowRealMatrix25.getRowDimension();
        boolean boolean28 = array2DRowRealMatrix25.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = array2DRowRealMatrix22.add(array2DRowRealMatrix25);
        double double30 = array2DRowRealMatrix25.getNorm();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int34 = array2DRowRealMatrix33.getRowDimension();
        java.lang.String str35 = array2DRowRealMatrix33.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int39 = array2DRowRealMatrix38.getRowDimension();
        boolean boolean41 = array2DRowRealMatrix38.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix42 = array2DRowRealMatrix38.copy();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = array2DRowRealMatrix33.subtract(array2DRowRealMatrix38);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int47 = array2DRowRealMatrix46.getRowDimension();
        java.lang.String str48 = array2DRowRealMatrix46.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix51 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int52 = array2DRowRealMatrix51.getRowDimension();
        boolean boolean54 = array2DRowRealMatrix51.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix55 = array2DRowRealMatrix51.copy();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = array2DRowRealMatrix46.subtract(array2DRowRealMatrix51);
        org.apache.commons.math.linear.RealMatrix realMatrix57 = array2DRowRealMatrix38.multiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix46);
        org.apache.commons.math.linear.RealMatrix realMatrix58 = array2DRowRealMatrix25.add(realMatrix57);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix61 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int62 = array2DRowRealMatrix61.getRowDimension();
        java.lang.String str63 = array2DRowRealMatrix61.toString();
        array2DRowRealMatrix61.luDecompose();
        double double65 = array2DRowRealMatrix61.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix66 = array2DRowRealMatrix61.copy();
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl67 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix61);
        int[] intArray68 = lUDecompositionImpl67.getPivot();
        int[] intArray75 = new int[] { 2147483647, 1, (byte) 100, (short) -1, (byte) -1, (byte) 100 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix78 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int79 = array2DRowRealMatrix78.getColumnDimension();
        double[][] doubleArray80 = array2DRowRealMatrix78.getDataRef();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix81 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray80);
        try {
            array2DRowRealMatrix25.copySubMatrix(intArray68, intArray75, doubleArray80);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 2,147,483,647 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str35.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(realMatrix42);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix43);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 10 + "'", int47 == 10);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str48.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 10 + "'", int52 == 10);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(realMatrix55);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix56);
        org.junit.Assert.assertNotNull(realMatrix57);
        org.junit.Assert.assertNotNull(realMatrix58);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 10 + "'", int62 == 10);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str63.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix66);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 10 + "'", int79 == 10);
        org.junit.Assert.assertNotNull(doubleArray80);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray7 = new double[] { (-1), (byte) 100, 0L, (-1L), (byte) 1, (-1.0f) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair9 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray0, doubleArray7, false);
        org.apache.commons.math.exception.Localizable localizable11 = null;
        org.apache.commons.math.exception.Localizable localizable14 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException("hi!", objArray20);
        org.apache.commons.math.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.MathRuntimeException(localizable14, objArray20);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException23 = new org.apache.commons.math.linear.MatrixIndexException("", objArray20);
        java.util.NoSuchElementException noSuchElementException24 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray20);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException(1.0d, localizable11, objArray20);
        double[] doubleArray26 = functionEvaluationException25.getArgument();
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair28 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray0, doubleArray26, true);
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix29 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(noSuchElementException24);
        org.junit.Assert.assertNotNull(doubleArray26);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException6 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 100, "", objArray5);
        org.apache.commons.math.exception.Localizable localizable7 = functionEvaluationException6.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable9 = null;
        org.apache.commons.math.exception.Localizable localizable13 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException("hi!", objArray19);
        org.apache.commons.math.MathRuntimeException mathRuntimeException21 = new org.apache.commons.math.MathRuntimeException(localizable13, objArray19);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException22 = new org.apache.commons.math.linear.MatrixIndexException("", objArray19);
        java.util.NoSuchElementException noSuchElementException23 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray19);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("hi!", objArray19);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, localizable9, objArray19);
        java.lang.UnsupportedOperationException unsupportedOperationException26 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException(localizable7, objArray19);
        org.apache.commons.math.exception.Localizable localizable29 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException("hi!", objArray35);
        org.apache.commons.math.MathRuntimeException mathRuntimeException37 = new org.apache.commons.math.MathRuntimeException(localizable29, objArray35);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException38 = new org.apache.commons.math.linear.MatrixIndexException("", objArray35);
        org.apache.commons.math.MathRuntimeException mathRuntimeException39 = new org.apache.commons.math.MathRuntimeException("hi!", objArray35);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException40 = new org.apache.commons.math.MaxEvaluationsExceededException(0, localizable7, objArray35);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException41 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}", objArray35);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(noSuchElementException23);
        org.junit.Assert.assertNotNull(unsupportedOperationException26);
        org.junit.Assert.assertNotNull(objArray35);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getRowDimension();
        boolean boolean10 = array2DRowRealMatrix7.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix11 = array2DRowRealMatrix7.copy();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix7);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor13 = null;
        try {
            double double14 = array2DRowRealMatrix7.walkInOptimizedOrder(realMatrixPreservingVisitor13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable12 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("hi!", objArray18);
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException(localizable12, objArray18);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException21 = new org.apache.commons.math.linear.MatrixIndexException("", objArray18);
        java.util.NoSuchElementException noSuchElementException22 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("hi!", objArray18);
        boolean boolean24 = array2DRowRealMatrix7.equals((java.lang.Object) objArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix7);
        java.lang.String str26 = array2DRowRealMatrix2.toString();
        double[][] doubleArray27 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray27);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int34 = array2DRowRealMatrix33.getRowDimension();
        java.lang.String str35 = array2DRowRealMatrix33.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int39 = array2DRowRealMatrix38.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable43 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("hi!", objArray49);
        org.apache.commons.math.MathRuntimeException mathRuntimeException51 = new org.apache.commons.math.MathRuntimeException(localizable43, objArray49);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException52 = new org.apache.commons.math.linear.MatrixIndexException("", objArray49);
        java.util.NoSuchElementException noSuchElementException53 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray49);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException("hi!", objArray49);
        boolean boolean55 = array2DRowRealMatrix38.equals((java.lang.Object) objArray49);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = array2DRowRealMatrix33.multiply(array2DRowRealMatrix38);
        java.lang.String str57 = array2DRowRealMatrix33.toString();
        double[][] doubleArray58 = array2DRowRealMatrix33.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray58, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix61 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray58);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix62 = blockRealMatrix30.multiply(blockRealMatrix61);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix64 = blockRealMatrix62.scalarAdd((double) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix67 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix((int) (byte) 100, (int) (byte) 100);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix68 = blockRealMatrix64.multiply(realMatrix67);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(noSuchElementException22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str26.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str35.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(noSuchElementException53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str57.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(blockRealMatrix62);
        org.junit.Assert.assertNotNull(blockRealMatrix64);
        org.junit.Assert.assertNotNull(realMatrix67);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getRowDimension();
        boolean boolean10 = array2DRowRealMatrix7.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix11 = array2DRowRealMatrix7.copy();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix7);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int16 = array2DRowRealMatrix15.getRowDimension();
        java.lang.String str17 = array2DRowRealMatrix15.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int21 = array2DRowRealMatrix20.getRowDimension();
        boolean boolean23 = array2DRowRealMatrix20.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix24 = array2DRowRealMatrix20.copy();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix20);
        org.apache.commons.math.linear.RealMatrix realMatrix26 = array2DRowRealMatrix7.multiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix15);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl28 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix7, (double) (short) 10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int32 = array2DRowRealMatrix31.getRowDimension();
        boolean boolean34 = array2DRowRealMatrix31.equals((java.lang.Object) (byte) 0);
        int int35 = array2DRowRealMatrix31.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int39 = array2DRowRealMatrix38.getRowDimension();
        boolean boolean41 = array2DRowRealMatrix38.equals((java.lang.Object) (byte) 0);
        array2DRowRealMatrix38.luDecompose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix45 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int46 = array2DRowRealMatrix45.getRowDimension();
        boolean boolean48 = array2DRowRealMatrix45.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix49 = array2DRowRealMatrix45.copy();
        org.apache.commons.math.linear.RealMatrix realMatrix50 = array2DRowRealMatrix38.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix45);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix51 = array2DRowRealMatrix31.subtract(array2DRowRealMatrix45);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix54 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int55 = array2DRowRealMatrix54.getRowDimension();
        boolean boolean57 = array2DRowRealMatrix54.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = array2DRowRealMatrix51.add(array2DRowRealMatrix54);
        double double59 = array2DRowRealMatrix54.getNorm();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix60 = array2DRowRealMatrix7.solve((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix54);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.SingularMatrixException; message: matrix is singular");
        } catch (org.apache.commons.math.linear.SingularMatrixException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str17.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(realMatrix24);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 10 + "'", int32 == 10);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 10 + "'", int35 == 10);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 10 + "'", int46 == 10);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(realMatrix49);
        org.junit.Assert.assertNotNull(realMatrix50);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix51);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 10 + "'", int55 == 10);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        boolean boolean5 = array2DRowRealMatrix2.equals((java.lang.Object) (byte) 0);
        int int6 = array2DRowRealMatrix2.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int10 = array2DRowRealMatrix9.getRowDimension();
        boolean boolean12 = array2DRowRealMatrix9.equals((java.lang.Object) (byte) 0);
        array2DRowRealMatrix9.luDecompose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int17 = array2DRowRealMatrix16.getRowDimension();
        boolean boolean19 = array2DRowRealMatrix16.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.copy();
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix9.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int26 = array2DRowRealMatrix25.getRowDimension();
        boolean boolean28 = array2DRowRealMatrix25.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = array2DRowRealMatrix22.add(array2DRowRealMatrix25);
        double double30 = array2DRowRealMatrix25.getNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix32 = array2DRowRealMatrix25.getRowMatrix(0);
        org.apache.commons.math.linear.RealMatrix realMatrix33 = array2DRowRealMatrix25.transpose();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor34 = null;
        try {
            double double35 = array2DRowRealMatrix25.walkInOptimizedOrder(realMatrixPreservingVisitor34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix32);
        org.junit.Assert.assertNotNull(realMatrix33);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.math.BigDecimal bigDecimal0 = null;
        java.math.BigDecimal[] bigDecimalArray1 = new java.math.BigDecimal[] { bigDecimal0 };
        org.apache.commons.math.linear.BigMatrix bigMatrix2 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(bigDecimalArray1);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int6 = array2DRowRealMatrix5.getRowDimension();
        java.lang.String str7 = array2DRowRealMatrix5.toString();
        array2DRowRealMatrix5.luDecompose();
        double double9 = array2DRowRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix11 = array2DRowRealMatrix5.getRowMatrix(0);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix5.getColumnMatrix((int) (short) 1);
        try {
            org.apache.commons.math.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math.linear.AnyMatrix) bigMatrix2, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix5);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigDecimalArray1);
        org.junit.Assert.assertNotNull(bigMatrix2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str7.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(realMatrix13);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getRowDimension();
        boolean boolean10 = array2DRowRealMatrix7.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix11 = array2DRowRealMatrix7.copy();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix7);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int16 = array2DRowRealMatrix15.getRowDimension();
        java.lang.String str17 = array2DRowRealMatrix15.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int21 = array2DRowRealMatrix20.getRowDimension();
        boolean boolean23 = array2DRowRealMatrix20.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix24 = array2DRowRealMatrix20.copy();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix20);
        org.apache.commons.math.linear.RealMatrix realMatrix26 = array2DRowRealMatrix7.multiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix15);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl28 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix7, (double) (short) 10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int32 = array2DRowRealMatrix31.getRowDimension();
        java.lang.String str33 = array2DRowRealMatrix31.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int37 = array2DRowRealMatrix36.getRowDimension();
        boolean boolean39 = array2DRowRealMatrix36.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix40 = array2DRowRealMatrix36.copy();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = array2DRowRealMatrix31.subtract(array2DRowRealMatrix36);
        org.apache.commons.math.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix7, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix41);
        java.lang.String str43 = array2DRowRealMatrix7.toString();
        java.io.ObjectOutputStream objectOutputStream44 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.serializeRealMatrix((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix7, objectOutputStream44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str17.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(realMatrix24);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 10 + "'", int32 == 10);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str33.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 10 + "'", int37 == 10);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(realMatrix40);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix41);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str43.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        boolean boolean5 = array2DRowRealMatrix2.equals((java.lang.Object) (byte) 0);
        array2DRowRealMatrix2.luDecompose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int10 = array2DRowRealMatrix9.getRowDimension();
        boolean boolean12 = array2DRowRealMatrix9.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.copy();
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix2.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix9);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int18 = array2DRowRealMatrix17.getRowDimension();
        java.lang.String str19 = array2DRowRealMatrix17.toString();
        array2DRowRealMatrix17.luDecompose();
        double double21 = array2DRowRealMatrix17.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix22 = array2DRowRealMatrix17.copy();
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl23 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix17);
        int[] intArray24 = lUDecompositionImpl23.getPivot();
        int[] intArray29 = new int[] { ' ', 1, (byte) 1, 0 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int33 = array2DRowRealMatrix32.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable37 = null;
        java.lang.Object[] objArray43 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException("hi!", objArray43);
        org.apache.commons.math.MathRuntimeException mathRuntimeException45 = new org.apache.commons.math.MathRuntimeException(localizable37, objArray43);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException46 = new org.apache.commons.math.linear.MatrixIndexException("", objArray43);
        java.util.NoSuchElementException noSuchElementException47 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray43);
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException("hi!", objArray43);
        boolean boolean49 = array2DRowRealMatrix32.equals((java.lang.Object) objArray43);
        double[][] doubleArray50 = array2DRowRealMatrix32.getDataRef();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix52 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray50, true);
        double[][] doubleArray53 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray50);
        try {
            array2DRowRealMatrix9.copySubMatrix(intArray24, intArray29, doubleArray50);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 32 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str19.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 10 + "'", int33 == 10);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(noSuchElementException47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray53);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable12 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("hi!", objArray18);
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException(localizable12, objArray18);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException21 = new org.apache.commons.math.linear.MatrixIndexException("", objArray18);
        java.util.NoSuchElementException noSuchElementException22 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("hi!", objArray18);
        boolean boolean24 = array2DRowRealMatrix7.equals((java.lang.Object) objArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix7);
        java.lang.String str26 = array2DRowRealMatrix2.toString();
        double[][] doubleArray27 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray27);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int34 = array2DRowRealMatrix33.getRowDimension();
        java.lang.String str35 = array2DRowRealMatrix33.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int39 = array2DRowRealMatrix38.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable43 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("hi!", objArray49);
        org.apache.commons.math.MathRuntimeException mathRuntimeException51 = new org.apache.commons.math.MathRuntimeException(localizable43, objArray49);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException52 = new org.apache.commons.math.linear.MatrixIndexException("", objArray49);
        java.util.NoSuchElementException noSuchElementException53 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray49);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException("hi!", objArray49);
        boolean boolean55 = array2DRowRealMatrix38.equals((java.lang.Object) objArray49);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = array2DRowRealMatrix33.multiply(array2DRowRealMatrix38);
        java.lang.String str57 = array2DRowRealMatrix33.toString();
        double[][] doubleArray58 = array2DRowRealMatrix33.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray58, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix61 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray58);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix62 = blockRealMatrix30.multiply(blockRealMatrix61);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix64 = blockRealMatrix62.scalarAdd((double) 0);
        double double65 = blockRealMatrix62.getNorm();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(noSuchElementException22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str26.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str35.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(noSuchElementException53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str57.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(blockRealMatrix62);
        org.junit.Assert.assertNotNull(blockRealMatrix64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable12 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("hi!", objArray18);
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException(localizable12, objArray18);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException21 = new org.apache.commons.math.linear.MatrixIndexException("", objArray18);
        java.util.NoSuchElementException noSuchElementException22 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("hi!", objArray18);
        boolean boolean24 = array2DRowRealMatrix7.equals((java.lang.Object) objArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix7);
        java.lang.String str26 = array2DRowRealMatrix2.toString();
        double[][] doubleArray27 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray27);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int34 = array2DRowRealMatrix33.getRowDimension();
        java.lang.String str35 = array2DRowRealMatrix33.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int39 = array2DRowRealMatrix38.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable43 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("hi!", objArray49);
        org.apache.commons.math.MathRuntimeException mathRuntimeException51 = new org.apache.commons.math.MathRuntimeException(localizable43, objArray49);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException52 = new org.apache.commons.math.linear.MatrixIndexException("", objArray49);
        java.util.NoSuchElementException noSuchElementException53 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray49);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException("hi!", objArray49);
        boolean boolean55 = array2DRowRealMatrix38.equals((java.lang.Object) objArray49);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = array2DRowRealMatrix33.multiply(array2DRowRealMatrix38);
        java.lang.String str57 = array2DRowRealMatrix33.toString();
        double[][] doubleArray58 = array2DRowRealMatrix33.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray58, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix61 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray58);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix62 = blockRealMatrix30.multiply(blockRealMatrix61);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix64 = blockRealMatrix62.scalarAdd((double) 0);
        org.apache.commons.math.exception.Localizable localizable66 = null;
        org.apache.commons.math.exception.Localizable localizable67 = null;
        java.lang.Object[] objArray73 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException74 = new org.apache.commons.math.MathException("hi!", objArray73);
        org.apache.commons.math.MathRuntimeException mathRuntimeException75 = new org.apache.commons.math.MathRuntimeException(localizable67, objArray73);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException76 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable66, objArray73);
        java.lang.Object[] objArray79 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException80 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException76, (double) 'a', "", objArray79);
        org.apache.commons.math.exception.Localizable localizable82 = null;
        org.apache.commons.math.exception.Localizable localizable85 = null;
        java.lang.Object[] objArray91 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException92 = new org.apache.commons.math.MathException("hi!", objArray91);
        org.apache.commons.math.MathRuntimeException mathRuntimeException93 = new org.apache.commons.math.MathRuntimeException(localizable85, objArray91);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException94 = new org.apache.commons.math.linear.MatrixIndexException("", objArray91);
        java.util.NoSuchElementException noSuchElementException95 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray91);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException96 = new org.apache.commons.math.FunctionEvaluationException(1.0d, localizable82, objArray91);
        double[] doubleArray97 = functionEvaluationException96.getArgument();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException98 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException80, doubleArray97);
        try {
            double[] doubleArray99 = blockRealMatrix64.operate(doubleArray97);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(noSuchElementException22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str26.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str35.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(noSuchElementException53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str57.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(blockRealMatrix62);
        org.junit.Assert.assertNotNull(blockRealMatrix64);
        org.junit.Assert.assertNotNull(objArray73);
        org.junit.Assert.assertNotNull(objArray91);
        org.junit.Assert.assertNotNull(noSuchElementException95);
        org.junit.Assert.assertNotNull(doubleArray97);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        java.math.BigDecimal[] bigDecimalArray0 = new java.math.BigDecimal[] {};
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix1 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(bigDecimalArray0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigDecimalArray0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getColumnDimension();
        double[][] doubleArray4 = array2DRowRealMatrix2.getDataRef();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) '4', (int) (short) 1);
        boolean boolean8 = array2DRowRealMatrix2.equals((java.lang.Object) (short) 1);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int13 = array2DRowRealMatrix12.getRowDimension();
        boolean boolean15 = array2DRowRealMatrix12.equals((java.lang.Object) (byte) 0);
        int int16 = array2DRowRealMatrix12.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int20 = array2DRowRealMatrix19.getRowDimension();
        boolean boolean22 = array2DRowRealMatrix19.equals((java.lang.Object) (byte) 0);
        array2DRowRealMatrix19.luDecompose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int27 = array2DRowRealMatrix26.getRowDimension();
        boolean boolean29 = array2DRowRealMatrix26.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = array2DRowRealMatrix26.copy();
        org.apache.commons.math.linear.RealMatrix realMatrix31 = array2DRowRealMatrix19.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix26);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix12.subtract(array2DRowRealMatrix26);
        org.apache.commons.math.linear.RealMatrix realMatrix34 = array2DRowRealMatrix12.scalarMultiply((double) (short) 0);
        try {
            array2DRowRealMatrix2.setColumnMatrix((int) (short) 0, (org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.InvalidMatrixException; message: dimensions mismatch: got 10x10 but expected 10x1");
        } catch (org.apache.commons.math.linear.InvalidMatrixException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(realMatrix31);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
        org.junit.Assert.assertNotNull(realMatrix34);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.apache.commons.math.linear.AnyMatrix anyMatrix0 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.checkRowIndex(anyMatrix0, 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable12 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("hi!", objArray18);
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException(localizable12, objArray18);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException21 = new org.apache.commons.math.linear.MatrixIndexException("", objArray18);
        java.util.NoSuchElementException noSuchElementException22 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("hi!", objArray18);
        boolean boolean24 = array2DRowRealMatrix7.equals((java.lang.Object) objArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix7);
        java.lang.String str26 = array2DRowRealMatrix2.toString();
        double[][] doubleArray27 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray27);
        double double31 = blockRealMatrix30.getNorm();
        double[] doubleArray33 = new double[] {};
        double[] doubleArray40 = new double[] { (-1), (byte) 100, 0L, (-1L), (byte) 1, (-1.0f) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair42 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray33, doubleArray40, false);
        double[] doubleArray43 = vectorialPointValuePair42.getValue();
        double[] doubleArray44 = new double[] {};
        double[] doubleArray51 = new double[] { (-1), (byte) 100, 0L, (-1L), (byte) 1, (-1.0f) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair53 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray44, doubleArray51, false);
        double[] doubleArray54 = vectorialPointValuePair53.getPointRef();
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair56 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray43, doubleArray54, true);
        org.apache.commons.math.linear.RealVector realVector57 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray43);
        try {
            blockRealMatrix30.setColumnVector((int) (byte) 1, realVector57);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.InvalidMatrixException; message: dimensions mismatch: got 6x1 but expected 10x1");
        } catch (org.apache.commons.math.linear.InvalidMatrixException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(noSuchElementException22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str26.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(realVector57);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        boolean boolean5 = array2DRowRealMatrix2.equals((java.lang.Object) (byte) 0);
        int int6 = array2DRowRealMatrix2.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int10 = array2DRowRealMatrix9.getRowDimension();
        boolean boolean12 = array2DRowRealMatrix9.equals((java.lang.Object) (byte) 0);
        array2DRowRealMatrix9.luDecompose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int17 = array2DRowRealMatrix16.getRowDimension();
        boolean boolean19 = array2DRowRealMatrix16.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.copy();
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix9.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int26 = array2DRowRealMatrix25.getRowDimension();
        boolean boolean28 = array2DRowRealMatrix25.equals((java.lang.Object) (byte) 0);
        int int29 = array2DRowRealMatrix25.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int33 = array2DRowRealMatrix32.getRowDimension();
        boolean boolean35 = array2DRowRealMatrix32.equals((java.lang.Object) (byte) 0);
        array2DRowRealMatrix32.luDecompose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int40 = array2DRowRealMatrix39.getRowDimension();
        boolean boolean42 = array2DRowRealMatrix39.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix43 = array2DRowRealMatrix39.copy();
        org.apache.commons.math.linear.RealMatrix realMatrix44 = array2DRowRealMatrix32.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix39);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix45 = array2DRowRealMatrix25.subtract(array2DRowRealMatrix39);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int49 = array2DRowRealMatrix48.getRowDimension();
        boolean boolean51 = array2DRowRealMatrix48.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix52 = array2DRowRealMatrix45.add(array2DRowRealMatrix48);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int56 = array2DRowRealMatrix55.getRowDimension();
        boolean boolean58 = array2DRowRealMatrix55.equals((java.lang.Object) (byte) 0);
        int int59 = array2DRowRealMatrix55.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix62 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int63 = array2DRowRealMatrix62.getRowDimension();
        boolean boolean65 = array2DRowRealMatrix62.equals((java.lang.Object) (byte) 0);
        array2DRowRealMatrix62.luDecompose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int70 = array2DRowRealMatrix69.getRowDimension();
        boolean boolean72 = array2DRowRealMatrix69.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix73 = array2DRowRealMatrix69.copy();
        org.apache.commons.math.linear.RealMatrix realMatrix74 = array2DRowRealMatrix62.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix69);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix75 = array2DRowRealMatrix55.subtract(array2DRowRealMatrix69);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix76 = array2DRowRealMatrix52.multiply(array2DRowRealMatrix69);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix77 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix76);
        java.lang.String str78 = array2DRowRealMatrix76.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 10 + "'", int33 == 10);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 10 + "'", int40 == 10);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix45);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 10 + "'", int49 == 10);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix52);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 10 + "'", int56 == 10);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 10 + "'", int59 == 10);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 10 + "'", int63 == 10);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 10 + "'", int70 == 10);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(realMatrix73);
        org.junit.Assert.assertNotNull(realMatrix74);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix75);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix76);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix77);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str78.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        array2DRowRealMatrix2.luDecompose();
        double double6 = array2DRowRealMatrix2.getFrobeniusNorm();
        int int7 = array2DRowRealMatrix2.getRowDimension();
        double[][] doubleArray8 = array2DRowRealMatrix2.getData();
        try {
            array2DRowRealMatrix2.multiplyEntry(36, (int) '4', (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (36, 52) in a 10x10 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int4 = array2DRowRealMatrix3.getColumnDimension();
        double[][] doubleArray5 = array2DRowRealMatrix3.getDataRef();
        org.apache.commons.math.linear.BigMatrix bigMatrix6 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(doubleArray5);
        try {
            array2DRowRealMatrix0.setSubMatrix(doubleArray5, (int) '#', 10);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalStateException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(bigMatrix6);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        levenbergMarquardtOptimizer0.setQRRankingThreshold((double) (short) 100);
        levenbergMarquardtOptimizer0.setParRelativeTolerance((double) 2147483647);
        levenbergMarquardtOptimizer0.setOrthoTolerance((double) (short) 100);
        levenbergMarquardtOptimizer0.setMaxIterations((int) (short) 1);
        levenbergMarquardtOptimizer0.setMaxIterations((int) (short) 0);
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker14 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker((double) '4', (double) '4');
        levenbergMarquardtOptimizer0.setConvergenceChecker((org.apache.commons.math.optimization.VectorialConvergenceChecker) simpleVectorialValueChecker14);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray7 = new double[] { (-1), (byte) 100, 0L, (-1L), (byte) 1, (-1.0f) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair9 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray0, doubleArray7, false);
        double[] doubleArray10 = vectorialPointValuePair9.getValue();
        org.apache.commons.math.linear.RealVector realVector11 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realVector11);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix(36, (int) (short) 1);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable7 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("hi!", objArray13);
        org.apache.commons.math.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.MathRuntimeException(localizable7, objArray13);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException16 = new org.apache.commons.math.linear.MatrixIndexException("", objArray13);
        java.util.NoSuchElementException noSuchElementException17 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray13);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("hi!", objArray13);
        boolean boolean19 = array2DRowRealMatrix2.equals((java.lang.Object) objArray13);
        double[][] doubleArray20 = array2DRowRealMatrix2.getDataRef();
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl22 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix2, (double) 1L);
        int[] intArray23 = lUDecompositionImpl22.getPivot();
        org.apache.commons.math.linear.DecompositionSolver decompositionSolver24 = lUDecompositionImpl22.getSolver();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(noSuchElementException17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(decompositionSolver24);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        double[][] doubleArray1 = array2DRowRealMatrix0.getDataRef();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor2 = null;
        try {
            double double7 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixChangingVisitor2, (int) (byte) 1, (int) (short) 10, (int) (byte) 100, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 1 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNull(doubleArray1);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException4 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 100, "", objArray3);
        org.apache.commons.math.exception.Localizable localizable5 = functionEvaluationException4.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable7 = null;
        org.apache.commons.math.exception.Localizable localizable11 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("hi!", objArray17);
        org.apache.commons.math.MathRuntimeException mathRuntimeException19 = new org.apache.commons.math.MathRuntimeException(localizable11, objArray17);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException20 = new org.apache.commons.math.linear.MatrixIndexException("", objArray17);
        java.util.NoSuchElementException noSuchElementException21 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray17);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException("hi!", objArray17);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, localizable7, objArray17);
        java.lang.UnsupportedOperationException unsupportedOperationException24 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException(localizable5, objArray17);
        java.lang.Object[] objArray28 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 100, "", objArray28);
        org.apache.commons.math.exception.Localizable localizable30 = functionEvaluationException29.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable32 = null;
        org.apache.commons.math.exception.Localizable localizable36 = null;
        java.lang.Object[] objArray42 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException("hi!", objArray42);
        org.apache.commons.math.MathRuntimeException mathRuntimeException44 = new org.apache.commons.math.MathRuntimeException(localizable36, objArray42);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException45 = new org.apache.commons.math.linear.MatrixIndexException("", objArray42);
        java.util.NoSuchElementException noSuchElementException46 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray42);
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException("hi!", objArray42);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, localizable32, objArray42);
        java.lang.UnsupportedOperationException unsupportedOperationException49 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException(localizable30, objArray42);
        org.apache.commons.math.exception.Localizable localizable52 = null;
        java.lang.Object[] objArray58 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException("hi!", objArray58);
        org.apache.commons.math.MathRuntimeException mathRuntimeException60 = new org.apache.commons.math.MathRuntimeException(localizable52, objArray58);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException61 = new org.apache.commons.math.linear.MatrixIndexException("", objArray58);
        org.apache.commons.math.MathRuntimeException mathRuntimeException62 = new org.apache.commons.math.MathRuntimeException("hi!", objArray58);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException63 = new org.apache.commons.math.MaxEvaluationsExceededException(0, localizable30, objArray58);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException64 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable5, objArray58);
        org.apache.commons.math.exception.Localizable localizable65 = null;
        java.lang.Object[] objArray71 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException72 = new org.apache.commons.math.MathException("hi!", objArray71);
        org.apache.commons.math.MathRuntimeException mathRuntimeException73 = new org.apache.commons.math.MathRuntimeException(localizable65, objArray71);
        java.lang.Object[] objArray74 = mathRuntimeException73.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException(localizable5, objArray74);
        org.apache.commons.math.exception.Localizable localizable78 = null;
        java.lang.Object[] objArray84 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException85 = new org.apache.commons.math.MathException("hi!", objArray84);
        org.apache.commons.math.MathRuntimeException mathRuntimeException86 = new org.apache.commons.math.MathRuntimeException(localizable78, objArray84);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException87 = new org.apache.commons.math.linear.MatrixIndexException("", objArray84);
        java.util.NoSuchElementException noSuchElementException88 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray84);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException89 = new org.apache.commons.math.MaxEvaluationsExceededException(1, localizable5, objArray84);
        org.apache.commons.math.exception.Localizable localizable90 = null;
        double[][] doubleArray94 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (byte) 10, 10);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException95 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("a {0}x{1} matrix was provided instead of a square matrix", (java.lang.Object[]) doubleArray94);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException96 = new org.apache.commons.math.linear.MatrixIndexException(localizable90, (java.lang.Object[]) doubleArray94);
        org.apache.commons.math.MathException mathException97 = new org.apache.commons.math.MathException(localizable5, (java.lang.Object[]) doubleArray94);
        java.lang.Object[] objArray98 = null;
        java.util.ConcurrentModificationException concurrentModificationException99 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException(localizable5, objArray98);
        org.junit.Assert.assertNotNull(localizable5);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(noSuchElementException21);
        org.junit.Assert.assertNotNull(unsupportedOperationException24);
        org.junit.Assert.assertNotNull(localizable30);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(noSuchElementException46);
        org.junit.Assert.assertNotNull(unsupportedOperationException49);
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException64);
        org.junit.Assert.assertNotNull(objArray71);
        org.junit.Assert.assertNotNull(objArray74);
        org.junit.Assert.assertNotNull(objArray84);
        org.junit.Assert.assertNotNull(noSuchElementException88);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException95);
        org.junit.Assert.assertNotNull(concurrentModificationException99);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        double[] doubleArray2 = new double[] { Double.NaN };
        double[] doubleArray4 = new double[] { Double.NaN };
        double[] doubleArray6 = new double[] { Double.NaN };
        double[] doubleArray8 = new double[] { Double.NaN };
        double[][] doubleArray9 = new double[][] { doubleArray2, doubleArray4, doubleArray6, doubleArray8 };
        double[][] doubleArray10 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray9);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9, true);
        org.apache.commons.math.optimization.OptimizationException optimizationException13 = new org.apache.commons.math.optimization.OptimizationException("", (java.lang.Object[]) doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test099");
//        org.apache.commons.math.exception.Localizable localizable0 = null;
//        org.apache.commons.math.exception.Localizable localizable1 = null;
//        java.lang.Object[] objArray7 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
//        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("hi!", objArray7);
//        org.apache.commons.math.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.MathRuntimeException(localizable1, objArray7);
//        java.lang.RuntimeException runtimeException10 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) mathRuntimeException9);
//        java.lang.Throwable[] throwableArray11 = runtimeException10.getSuppressed();
//        java.io.IOException iOException12 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) runtimeException10);
//        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) iOException12);
//        org.apache.commons.math.exception.Localizable localizable14 = convergenceException13.getLocalizablePattern();
//        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
//        int int18 = array2DRowRealMatrix17.getColumnDimension();
//        org.apache.commons.math.exception.Localizable localizable22 = null;
//        java.lang.Object[] objArray28 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
//        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException("hi!", objArray28);
//        org.apache.commons.math.MathRuntimeException mathRuntimeException30 = new org.apache.commons.math.MathRuntimeException(localizable22, objArray28);
//        org.apache.commons.math.linear.MatrixIndexException matrixIndexException31 = new org.apache.commons.math.linear.MatrixIndexException("", objArray28);
//        java.util.NoSuchElementException noSuchElementException32 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray28);
//        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException("hi!", objArray28);
//        boolean boolean34 = array2DRowRealMatrix17.equals((java.lang.Object) objArray28);
//        java.lang.UnsupportedOperationException unsupportedOperationException35 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException(localizable14, objArray28);
//        java.lang.Object[] objArray40 = null;
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException41 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 100, "", objArray40);
//        org.apache.commons.math.exception.Localizable localizable42 = functionEvaluationException41.getLocalizablePattern();
//        org.apache.commons.math.exception.Localizable localizable44 = null;
//        org.apache.commons.math.exception.Localizable localizable48 = null;
//        java.lang.Object[] objArray54 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
//        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException("hi!", objArray54);
//        org.apache.commons.math.MathRuntimeException mathRuntimeException56 = new org.apache.commons.math.MathRuntimeException(localizable48, objArray54);
//        org.apache.commons.math.linear.MatrixIndexException matrixIndexException57 = new org.apache.commons.math.linear.MatrixIndexException("", objArray54);
//        java.util.NoSuchElementException noSuchElementException58 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray54);
//        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException("hi!", objArray54);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException60 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, localizable44, objArray54);
//        java.lang.UnsupportedOperationException unsupportedOperationException61 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException(localizable42, objArray54);
//        org.apache.commons.math.exception.Localizable localizable64 = null;
//        java.lang.Object[] objArray70 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
//        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException("hi!", objArray70);
//        org.apache.commons.math.MathRuntimeException mathRuntimeException72 = new org.apache.commons.math.MathRuntimeException(localizable64, objArray70);
//        org.apache.commons.math.linear.MatrixIndexException matrixIndexException73 = new org.apache.commons.math.linear.MatrixIndexException("", objArray70);
//        org.apache.commons.math.MathRuntimeException mathRuntimeException74 = new org.apache.commons.math.MathRuntimeException("hi!", objArray70);
//        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException75 = new org.apache.commons.math.MaxEvaluationsExceededException(0, localizable42, objArray70);
//        org.apache.commons.math.exception.Localizable localizable76 = null;
//        java.lang.Object[] objArray82 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
//        org.apache.commons.math.MathException mathException83 = new org.apache.commons.math.MathException("hi!", objArray82);
//        org.apache.commons.math.MathRuntimeException mathRuntimeException84 = new org.apache.commons.math.MathRuntimeException(localizable76, objArray82);
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException85 = new org.apache.commons.math.FunctionEvaluationException((double) 36, localizable42, objArray82);
//        org.apache.commons.math.linear.MatrixIndexException matrixIndexException86 = new org.apache.commons.math.linear.MatrixIndexException(localizable14, objArray82);
//        try {
//            java.lang.ArithmeticException arithmeticException87 = org.apache.commons.math.MathRuntimeException.createArithmeticException(localizable0, objArray82);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(objArray7);
//        org.junit.Assert.assertNotNull(runtimeException10);
//        org.junit.Assert.assertNotNull(throwableArray11);
//        org.junit.Assert.assertNotNull(iOException12);
//        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable14.equals(org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
//        org.junit.Assert.assertNotNull(objArray28);
//        org.junit.Assert.assertNotNull(noSuchElementException32);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(unsupportedOperationException35);
//        org.junit.Assert.assertNotNull(localizable42);
//        org.junit.Assert.assertNotNull(objArray54);
//        org.junit.Assert.assertNotNull(noSuchElementException58);
//        org.junit.Assert.assertNotNull(unsupportedOperationException61);
//        org.junit.Assert.assertNotNull(objArray70);
//        org.junit.Assert.assertNotNull(objArray82);
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        levenbergMarquardtOptimizer0.setCostRelativeTolerance((double) 10L);
        int int4 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        levenbergMarquardtOptimizer0.setMaxIterations(52);
        try {
            double[] doubleArray7 = levenbergMarquardtOptimizer0.guessParametersErrors();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.optimization.OptimizationException; message: no degrees of freedom (0 measurements, 0 parameters)");
        } catch (org.apache.commons.math.optimization.OptimizationException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.apache.commons.math.exception.Localizable localizable1 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("hi!", objArray11);
        org.apache.commons.math.MathRuntimeException mathRuntimeException13 = new org.apache.commons.math.MathRuntimeException(localizable5, objArray11);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException14 = new org.apache.commons.math.linear.MatrixIndexException("", objArray11);
        java.util.NoSuchElementException noSuchElementException15 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray11);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException("hi!", objArray11);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, localizable1, objArray11);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException17);
        double[] doubleArray24 = new double[] { 0, (short) -1, '#', (short) 100, 1.0d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathException18, doubleArray24);
        double[] doubleArray28 = new double[] {};
        double[] doubleArray35 = new double[] { (-1), (byte) 100, 0L, (-1L), (byte) 1, (-1.0f) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair37 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray28, doubleArray35, false);
        double[] doubleArray38 = vectorialPointValuePair37.getPoint();
        org.apache.commons.math.exception.Localizable localizable39 = null;
        org.apache.commons.math.exception.Localizable localizable40 = null;
        java.lang.Object[] objArray46 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException("hi!", objArray46);
        org.apache.commons.math.MathRuntimeException mathRuntimeException48 = new org.apache.commons.math.MathRuntimeException(localizable40, objArray46);
        java.lang.RuntimeException runtimeException49 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) mathRuntimeException48);
        java.lang.Throwable[] throwableArray50 = runtimeException49.getSuppressed();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException51 = new org.apache.commons.math.FunctionEvaluationException(doubleArray38, localizable39, (java.lang.Object[]) throwableArray50);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException52 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException25, (double) (byte) 1, "", (java.lang.Object[]) throwableArray50);
        java.io.IOException iOException53 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) functionEvaluationException25);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(noSuchElementException15);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(runtimeException49);
        org.junit.Assert.assertNotNull(throwableArray50);
        org.junit.Assert.assertNotNull(iOException53);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math.exception.Localizable localizable4 = null;
        org.apache.commons.math.exception.Localizable localizable6 = null;
        org.apache.commons.math.exception.Localizable localizable9 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("hi!", objArray15);
        org.apache.commons.math.MathRuntimeException mathRuntimeException17 = new org.apache.commons.math.MathRuntimeException(localizable9, objArray15);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException18 = new org.apache.commons.math.linear.MatrixIndexException("", objArray15);
        java.util.NoSuchElementException noSuchElementException19 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray15);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException(1.0d, localizable6, objArray15);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException21 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100, localizable4, objArray15);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException(throwable1, "hi!", objArray15);
        java.lang.ArithmeticException arithmeticException23 = org.apache.commons.math.MathRuntimeException.createArithmeticException("org.apache.commons.math.ConvergenceException: hi!", objArray15);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(noSuchElementException19);
        org.junit.Assert.assertNotNull(arithmeticException23);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable12 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("hi!", objArray18);
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException(localizable12, objArray18);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException21 = new org.apache.commons.math.linear.MatrixIndexException("", objArray18);
        java.util.NoSuchElementException noSuchElementException22 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("hi!", objArray18);
        boolean boolean24 = array2DRowRealMatrix7.equals((java.lang.Object) objArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix7);
        java.lang.String str26 = array2DRowRealMatrix2.toString();
        double[][] doubleArray27 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray27);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int34 = array2DRowRealMatrix33.getRowDimension();
        java.lang.String str35 = array2DRowRealMatrix33.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int39 = array2DRowRealMatrix38.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable43 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("hi!", objArray49);
        org.apache.commons.math.MathRuntimeException mathRuntimeException51 = new org.apache.commons.math.MathRuntimeException(localizable43, objArray49);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException52 = new org.apache.commons.math.linear.MatrixIndexException("", objArray49);
        java.util.NoSuchElementException noSuchElementException53 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray49);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException("hi!", objArray49);
        boolean boolean55 = array2DRowRealMatrix38.equals((java.lang.Object) objArray49);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = array2DRowRealMatrix33.multiply(array2DRowRealMatrix38);
        java.lang.String str57 = array2DRowRealMatrix33.toString();
        double[][] doubleArray58 = array2DRowRealMatrix33.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray58, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix61 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray58);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix62 = blockRealMatrix30.multiply(blockRealMatrix61);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix64 = blockRealMatrix61.getColumnMatrix(0);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int69 = array2DRowRealMatrix68.getRowDimension();
        boolean boolean71 = array2DRowRealMatrix68.equals((java.lang.Object) (byte) 0);
        int int72 = array2DRowRealMatrix68.getRowDimension();
        try {
            blockRealMatrix61.setColumnMatrix((int) (short) 10, (org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix68);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 10 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(noSuchElementException22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str26.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str35.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(noSuchElementException53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str57.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(blockRealMatrix62);
        org.junit.Assert.assertNotNull(blockRealMatrix64);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 10 + "'", int69 == 10);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 10 + "'", int72 == 10);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getRowDimension();
        boolean boolean10 = array2DRowRealMatrix7.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix11 = array2DRowRealMatrix7.copy();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix7);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int16 = array2DRowRealMatrix15.getRowDimension();
        boolean boolean18 = array2DRowRealMatrix15.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix15);
        java.io.ObjectOutputStream objectOutputStream20 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.serializeRealMatrix((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix2, objectOutputStream20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix19);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.apache.commons.math.exception.Localizable localizable0 = null;
        double[][] doubleArray4 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (byte) 10, 10);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException5 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("a {0}x{1} matrix was provided instead of a square matrix", (java.lang.Object[]) doubleArray4);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException6 = new org.apache.commons.math.linear.MatrixIndexException(localizable0, (java.lang.Object[]) doubleArray4);
        double[][] doubleArray7 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray4);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException5);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable12 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("hi!", objArray18);
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException(localizable12, objArray18);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException21 = new org.apache.commons.math.linear.MatrixIndexException("", objArray18);
        java.util.NoSuchElementException noSuchElementException22 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("hi!", objArray18);
        boolean boolean24 = array2DRowRealMatrix7.equals((java.lang.Object) objArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix7);
        java.lang.String str26 = array2DRowRealMatrix2.toString();
        double[][] doubleArray27 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray27);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int34 = array2DRowRealMatrix33.getRowDimension();
        java.lang.String str35 = array2DRowRealMatrix33.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int39 = array2DRowRealMatrix38.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable43 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("hi!", objArray49);
        org.apache.commons.math.MathRuntimeException mathRuntimeException51 = new org.apache.commons.math.MathRuntimeException(localizable43, objArray49);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException52 = new org.apache.commons.math.linear.MatrixIndexException("", objArray49);
        java.util.NoSuchElementException noSuchElementException53 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray49);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException("hi!", objArray49);
        boolean boolean55 = array2DRowRealMatrix38.equals((java.lang.Object) objArray49);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = array2DRowRealMatrix33.multiply(array2DRowRealMatrix38);
        java.lang.String str57 = array2DRowRealMatrix33.toString();
        double[][] doubleArray58 = array2DRowRealMatrix33.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray58, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix61 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray58);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix62 = blockRealMatrix30.multiply(blockRealMatrix61);
        double[][] doubleArray66 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(10, (int) ' ');
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray66, false);
        org.apache.commons.math.linear.RealVector realVector70 = array2DRowRealMatrix68.getColumnVector(100);
        try {
            blockRealMatrix30.setColumnVector((int) (short) 100, realVector70);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 100 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(noSuchElementException22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str26.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str35.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(noSuchElementException53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str57.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(blockRealMatrix62);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(realVector70);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.apache.commons.math.exception.Localizable localizable1 = null;
        org.apache.commons.math.exception.Localizable localizable5 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("hi!", objArray11);
        org.apache.commons.math.MathRuntimeException mathRuntimeException13 = new org.apache.commons.math.MathRuntimeException(localizable5, objArray11);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException14 = new org.apache.commons.math.linear.MatrixIndexException("", objArray11);
        java.util.NoSuchElementException noSuchElementException15 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray11);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException("hi!", objArray11);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, localizable1, objArray11);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException17);
        double[] doubleArray24 = new double[] { 0, (short) -1, '#', (short) 100, 1.0d };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathException18, doubleArray24);
        org.apache.commons.math.MathRuntimeException mathRuntimeException26 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) functionEvaluationException25);
        java.io.IOException iOException27 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) mathRuntimeException26);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(noSuchElementException15);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(iOException27);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray7 = new double[] { (-1), (byte) 100, 0L, (-1L), (byte) 1, (-1.0f) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair9 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray0, doubleArray7, false);
        double[] doubleArray10 = vectorialPointValuePair9.getPoint();
        double[] doubleArray11 = vectorialPointValuePair9.getValue();
        org.apache.commons.math.linear.BigMatrix bigMatrix12 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(doubleArray11);
        double[] doubleArray13 = null;
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair14 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray11, doubleArray13);
        double[] doubleArray15 = vectorialPointValuePair14.getValue();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(bigMatrix12);
        org.junit.Assert.assertNull(doubleArray15);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable12 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("hi!", objArray18);
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException(localizable12, objArray18);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException21 = new org.apache.commons.math.linear.MatrixIndexException("", objArray18);
        java.util.NoSuchElementException noSuchElementException22 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("hi!", objArray18);
        boolean boolean24 = array2DRowRealMatrix7.equals((java.lang.Object) objArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix7);
        java.lang.String str26 = array2DRowRealMatrix2.toString();
        double[][] doubleArray27 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray27);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int34 = array2DRowRealMatrix33.getRowDimension();
        java.lang.String str35 = array2DRowRealMatrix33.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int39 = array2DRowRealMatrix38.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable43 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("hi!", objArray49);
        org.apache.commons.math.MathRuntimeException mathRuntimeException51 = new org.apache.commons.math.MathRuntimeException(localizable43, objArray49);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException52 = new org.apache.commons.math.linear.MatrixIndexException("", objArray49);
        java.util.NoSuchElementException noSuchElementException53 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray49);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException("hi!", objArray49);
        boolean boolean55 = array2DRowRealMatrix38.equals((java.lang.Object) objArray49);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = array2DRowRealMatrix33.multiply(array2DRowRealMatrix38);
        java.lang.String str57 = array2DRowRealMatrix33.toString();
        double[][] doubleArray58 = array2DRowRealMatrix33.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray58, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix61 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray58);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix62 = blockRealMatrix30.multiply(blockRealMatrix61);
        double double63 = blockRealMatrix61.getFrobeniusNorm();
        org.apache.commons.math.linear.RealVector realVector65 = blockRealMatrix61.getColumnVector(0);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int69 = array2DRowRealMatrix68.getColumnDimension();
        double[][] doubleArray70 = array2DRowRealMatrix68.getDataRef();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix71 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray70);
        double[][] doubleArray72 = array2DRowRealMatrix71.getDataRef();
        org.apache.commons.math.linear.RealMatrix realMatrix73 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray72);
        try {
            blockRealMatrix61.setSubMatrix(doubleArray72, (int) (short) 1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 10 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(noSuchElementException22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str26.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str35.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(noSuchElementException53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str57.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(blockRealMatrix62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(realVector65);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 10 + "'", int69 == 10);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(realMatrix73);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        double[][] doubleArray0 = null;
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        boolean boolean5 = array2DRowRealMatrix2.equals((java.lang.Object) (byte) 0);
        int int6 = array2DRowRealMatrix2.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int10 = array2DRowRealMatrix9.getRowDimension();
        boolean boolean12 = array2DRowRealMatrix9.equals((java.lang.Object) (byte) 0);
        array2DRowRealMatrix9.luDecompose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int17 = array2DRowRealMatrix16.getRowDimension();
        boolean boolean19 = array2DRowRealMatrix16.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.copy();
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix9.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int26 = array2DRowRealMatrix25.getRowDimension();
        java.lang.String str27 = array2DRowRealMatrix25.toString();
        array2DRowRealMatrix25.luDecompose();
        org.apache.commons.math.linear.RealMatrix realMatrix29 = array2DRowRealMatrix25.copy();
        double double30 = array2DRowRealMatrix25.getDeterminant();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix25);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor32 = null;
        try {
            double double37 = array2DRowRealMatrix25.walkInColumnOrder(realMatrixChangingVisitor32, 2147483647, 100, (int) (short) -1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 2,147,483,647 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str27.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix31);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        boolean boolean5 = array2DRowRealMatrix2.equals((java.lang.Object) (byte) 0);
        int int6 = array2DRowRealMatrix2.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int10 = array2DRowRealMatrix9.getRowDimension();
        boolean boolean12 = array2DRowRealMatrix9.equals((java.lang.Object) (byte) 0);
        array2DRowRealMatrix9.luDecompose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int17 = array2DRowRealMatrix16.getRowDimension();
        boolean boolean19 = array2DRowRealMatrix16.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.copy();
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix9.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int26 = array2DRowRealMatrix25.getRowDimension();
        boolean boolean28 = array2DRowRealMatrix25.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = array2DRowRealMatrix22.add(array2DRowRealMatrix25);
        org.apache.commons.math.exception.Localizable localizable32 = null;
        org.apache.commons.math.exception.Localizable localizable34 = null;
        org.apache.commons.math.exception.Localizable localizable37 = null;
        java.lang.Object[] objArray43 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException("hi!", objArray43);
        org.apache.commons.math.MathRuntimeException mathRuntimeException45 = new org.apache.commons.math.MathRuntimeException(localizable37, objArray43);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException46 = new org.apache.commons.math.linear.MatrixIndexException("", objArray43);
        java.util.NoSuchElementException noSuchElementException47 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray43);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException48 = new org.apache.commons.math.FunctionEvaluationException(1.0d, localizable34, objArray43);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException49 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100, localizable32, objArray43);
        double[] doubleArray50 = new double[] {};
        double[] doubleArray57 = new double[] { (-1), (byte) 100, 0L, (-1L), (byte) 1, (-1.0f) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair59 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray50, doubleArray57, false);
        double[] doubleArray60 = vectorialPointValuePair59.getValue();
        org.apache.commons.math.exception.Localizable localizable62 = null;
        java.lang.Object[] objArray68 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException("hi!", objArray68);
        org.apache.commons.math.MathRuntimeException mathRuntimeException70 = new org.apache.commons.math.MathRuntimeException(localizable62, objArray68);
        java.lang.RuntimeException runtimeException71 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) mathRuntimeException70);
        java.lang.Throwable[] throwableArray72 = runtimeException71.getSuppressed();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException73 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException49, doubleArray60, "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}", (java.lang.Object[]) throwableArray72);
        double[] doubleArray74 = new double[] {};
        double[] doubleArray81 = new double[] { (-1), (byte) 100, 0L, (-1L), (byte) 1, (-1.0f) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair83 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray74, doubleArray81, false);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair84 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray60, doubleArray81);
        double[] doubleArray85 = vectorialPointValuePair84.getPointRef();
        double[] doubleArray86 = vectorialPointValuePair84.getValue();
        try {
            array2DRowRealMatrix22.setColumn((int) '4', doubleArray86);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 52 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix29);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(noSuchElementException47);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(objArray68);
        org.junit.Assert.assertNotNull(runtimeException71);
        org.junit.Assert.assertNotNull(throwableArray72);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray86);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        boolean boolean5 = array2DRowRealMatrix2.equals((java.lang.Object) (byte) 0);
        int int6 = array2DRowRealMatrix2.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int10 = array2DRowRealMatrix9.getRowDimension();
        boolean boolean12 = array2DRowRealMatrix9.equals((java.lang.Object) (byte) 0);
        array2DRowRealMatrix9.luDecompose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int17 = array2DRowRealMatrix16.getRowDimension();
        boolean boolean19 = array2DRowRealMatrix16.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.copy();
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix9.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int26 = array2DRowRealMatrix25.getRowDimension();
        boolean boolean28 = array2DRowRealMatrix25.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = array2DRowRealMatrix22.add(array2DRowRealMatrix25);
        double double30 = array2DRowRealMatrix25.getNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix32 = array2DRowRealMatrix25.getRowMatrix(0);
        org.apache.commons.math.linear.RealMatrix realMatrix33 = array2DRowRealMatrix25.transpose();
        array2DRowRealMatrix25.luDecompose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int42 = array2DRowRealMatrix41.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable46 = null;
        java.lang.Object[] objArray52 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException("hi!", objArray52);
        org.apache.commons.math.MathRuntimeException mathRuntimeException54 = new org.apache.commons.math.MathRuntimeException(localizable46, objArray52);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException55 = new org.apache.commons.math.linear.MatrixIndexException("", objArray52);
        java.util.NoSuchElementException noSuchElementException56 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray52);
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException("hi!", objArray52);
        boolean boolean58 = array2DRowRealMatrix41.equals((java.lang.Object) objArray52);
        double[][] doubleArray59 = array2DRowRealMatrix41.getDataRef();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix61 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray59, true);
        try {
            array2DRowRealMatrix25.copySubMatrix((int) (byte) -1, (int) (short) -1, 0, (int) (short) 10, doubleArray59);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index -1 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix32);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 10 + "'", int42 == 10);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(noSuchElementException56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(doubleArray59);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        array2DRowRealMatrix2.luDecompose();
        double double6 = array2DRowRealMatrix2.getFrobeniusNorm();
        int int7 = array2DRowRealMatrix2.getRowDimension();
        double[][] doubleArray8 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int12 = array2DRowRealMatrix11.getRowDimension();
        boolean boolean14 = array2DRowRealMatrix11.equals((java.lang.Object) (byte) 0);
        int int15 = array2DRowRealMatrix11.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int19 = array2DRowRealMatrix18.getRowDimension();
        boolean boolean21 = array2DRowRealMatrix18.equals((java.lang.Object) (byte) 0);
        array2DRowRealMatrix18.luDecompose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int26 = array2DRowRealMatrix25.getRowDimension();
        boolean boolean28 = array2DRowRealMatrix25.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix29 = array2DRowRealMatrix25.copy();
        org.apache.commons.math.linear.RealMatrix realMatrix30 = array2DRowRealMatrix18.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix25);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = array2DRowRealMatrix11.subtract(array2DRowRealMatrix25);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int35 = array2DRowRealMatrix34.getRowDimension();
        boolean boolean37 = array2DRowRealMatrix34.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = array2DRowRealMatrix31.add(array2DRowRealMatrix34);
        org.apache.commons.math.linear.RealMatrix realMatrix39 = array2DRowRealMatrix2.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix31);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 10 + "'", int35 == 10);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix38);
        org.junit.Assert.assertNotNull(realMatrix39);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable12 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("hi!", objArray18);
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException(localizable12, objArray18);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException21 = new org.apache.commons.math.linear.MatrixIndexException("", objArray18);
        java.util.NoSuchElementException noSuchElementException22 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("hi!", objArray18);
        boolean boolean24 = array2DRowRealMatrix7.equals((java.lang.Object) objArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix7);
        java.lang.String str26 = array2DRowRealMatrix2.toString();
        double[][] doubleArray27 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray27);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int34 = array2DRowRealMatrix33.getRowDimension();
        java.lang.String str35 = array2DRowRealMatrix33.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int39 = array2DRowRealMatrix38.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable43 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("hi!", objArray49);
        org.apache.commons.math.MathRuntimeException mathRuntimeException51 = new org.apache.commons.math.MathRuntimeException(localizable43, objArray49);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException52 = new org.apache.commons.math.linear.MatrixIndexException("", objArray49);
        java.util.NoSuchElementException noSuchElementException53 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray49);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException("hi!", objArray49);
        boolean boolean55 = array2DRowRealMatrix38.equals((java.lang.Object) objArray49);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = array2DRowRealMatrix33.multiply(array2DRowRealMatrix38);
        java.lang.String str57 = array2DRowRealMatrix33.toString();
        double[][] doubleArray58 = array2DRowRealMatrix33.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray58, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix61 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray58);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix62 = blockRealMatrix30.multiply(blockRealMatrix61);
        double double63 = blockRealMatrix61.getFrobeniusNorm();
        org.apache.commons.math.linear.RealVector realVector65 = blockRealMatrix61.getColumnVector(0);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int69 = array2DRowRealMatrix68.getColumnDimension();
        boolean boolean70 = array2DRowRealMatrix68.isSquare();
        org.apache.commons.math.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix61, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix68);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(noSuchElementException22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str26.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str35.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(noSuchElementException53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str57.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(blockRealMatrix62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(realVector65);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 10 + "'", int69 == 10);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        array2DRowRealMatrix2.luDecompose();
        double double6 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix7 = array2DRowRealMatrix2.copy();
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl8 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix2);
        org.apache.commons.math.linear.DecompositionSolver decompositionSolver9 = lUDecompositionImpl8.getSolver();
        int[] intArray10 = lUDecompositionImpl8.getPivot();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(decompositionSolver9);
        org.junit.Assert.assertNotNull(intArray10);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.apache.commons.math.exception.Localizable localizable0 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException("hi!", objArray6);
        org.apache.commons.math.MathRuntimeException mathRuntimeException8 = new org.apache.commons.math.MathRuntimeException(localizable0, objArray6);
        java.lang.RuntimeException runtimeException9 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) mathRuntimeException8);
        java.lang.Throwable[] throwableArray10 = runtimeException9.getSuppressed();
        java.io.IOException iOException11 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) runtimeException9);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) iOException11);
        double[] doubleArray13 = new double[] {};
        double[] doubleArray20 = new double[] { (-1), (byte) 100, 0L, (-1L), (byte) 1, (-1.0f) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair22 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray13, doubleArray20, false);
        double[] doubleArray23 = vectorialPointValuePair22.getPoint();
        org.apache.commons.math.exception.Localizable localizable24 = null;
        org.apache.commons.math.exception.Localizable localizable25 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException("hi!", objArray31);
        org.apache.commons.math.MathRuntimeException mathRuntimeException33 = new org.apache.commons.math.MathRuntimeException(localizable25, objArray31);
        java.lang.RuntimeException runtimeException34 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) mathRuntimeException33);
        java.lang.Throwable[] throwableArray35 = runtimeException34.getSuppressed();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException(doubleArray23, localizable24, (java.lang.Object[]) throwableArray35);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException37 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException12, doubleArray23);
        org.apache.commons.math.exception.Localizable localizable39 = null;
        java.lang.Object[] objArray45 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException("hi!", objArray45);
        org.apache.commons.math.MathRuntimeException mathRuntimeException47 = new org.apache.commons.math.MathRuntimeException(localizable39, objArray45);
        java.lang.RuntimeException runtimeException48 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) mathRuntimeException47);
        java.lang.Throwable[] throwableArray49 = runtimeException48.getSuppressed();
        org.apache.commons.math.optimization.OptimizationException optimizationException50 = new org.apache.commons.math.optimization.OptimizationException("", (java.lang.Object[]) throwableArray49);
        double[] doubleArray51 = new double[] {};
        double[] doubleArray58 = new double[] { (-1), (byte) 100, 0L, (-1L), (byte) 1, (-1.0f) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair60 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray51, doubleArray58, false);
        org.apache.commons.math.exception.Localizable localizable65 = null;
        org.apache.commons.math.exception.Localizable localizable66 = null;
        java.lang.Object[] objArray72 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException("hi!", objArray72);
        org.apache.commons.math.MathRuntimeException mathRuntimeException74 = new org.apache.commons.math.MathRuntimeException(localizable66, objArray72);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException75 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable65, objArray72);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException76 = new org.apache.commons.math.FunctionEvaluationException((double) (byte) -1, "hi!", objArray72);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException77 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) optimizationException50, doubleArray58, "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}", objArray72);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair78 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray23, doubleArray58);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException79 = new org.apache.commons.math.FunctionEvaluationException(doubleArray58);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(runtimeException9);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(iOException11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(runtimeException34);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(runtimeException48);
        org.junit.Assert.assertNotNull(throwableArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(objArray72);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable12 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("hi!", objArray18);
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException(localizable12, objArray18);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException21 = new org.apache.commons.math.linear.MatrixIndexException("", objArray18);
        java.util.NoSuchElementException noSuchElementException22 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("hi!", objArray18);
        boolean boolean24 = array2DRowRealMatrix7.equals((java.lang.Object) objArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix7);
        java.lang.String str26 = array2DRowRealMatrix2.toString();
        double[][] doubleArray27 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray27);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix30.getColumnMatrix((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 10 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(noSuchElementException22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str26.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException(throwable0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable12 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("hi!", objArray18);
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException(localizable12, objArray18);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException21 = new org.apache.commons.math.linear.MatrixIndexException("", objArray18);
        java.util.NoSuchElementException noSuchElementException22 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("hi!", objArray18);
        boolean boolean24 = array2DRowRealMatrix7.equals((java.lang.Object) objArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix7);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor26 = null;
        try {
            double double27 = array2DRowRealMatrix25.walkInRowOrder(realMatrixPreservingVisitor26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(noSuchElementException22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.apache.commons.math.exception.Localizable localizable2 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray8);
        org.apache.commons.math.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.MathRuntimeException(localizable2, objArray8);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException11 = new org.apache.commons.math.linear.MatrixIndexException("", objArray8);
        org.apache.commons.math.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.MathRuntimeException("hi!", objArray8);
        double[] doubleArray14 = new double[] { ' ' };
        org.apache.commons.math.exception.Localizable localizable15 = null;
        org.apache.commons.math.exception.Localizable localizable18 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException("hi!", objArray24);
        org.apache.commons.math.MathRuntimeException mathRuntimeException26 = new org.apache.commons.math.MathRuntimeException(localizable18, objArray24);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException27 = new org.apache.commons.math.linear.MatrixIndexException("", objArray24);
        java.util.NoSuchElementException noSuchElementException28 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray24);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathRuntimeException12, doubleArray14, localizable15, objArray24);
        double[] doubleArray36 = new double[] { (short) -1, 0, (byte) 10, 10, 1.0d, 0 };
        org.apache.commons.math.linear.RealMatrix realMatrix37 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray36);
        java.lang.Object[] objArray44 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException("hi!", objArray44);
        org.apache.commons.math.exception.Localizable localizable46 = null;
        org.apache.commons.math.exception.Localizable localizable49 = null;
        java.lang.Object[] objArray55 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException("hi!", objArray55);
        org.apache.commons.math.MathRuntimeException mathRuntimeException57 = new org.apache.commons.math.MathRuntimeException(localizable49, objArray55);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException58 = new org.apache.commons.math.linear.MatrixIndexException("", objArray55);
        java.util.NoSuchElementException noSuchElementException59 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray55);
        org.apache.commons.math.MathRuntimeException mathRuntimeException60 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) mathException45, localizable46, objArray55);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException61 = new org.apache.commons.math.FunctionEvaluationException(doubleArray36, "", objArray55);
        mathRuntimeException12.addSuppressed((java.lang.Throwable) functionEvaluationException61);
        java.lang.String str63 = mathRuntimeException12.getPattern();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(noSuchElementException28);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(noSuchElementException59);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "hi!" + "'", str63.equals("hi!"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        levenbergMarquardtOptimizer0.setQRRankingThreshold((double) (short) 100);
        levenbergMarquardtOptimizer0.setParRelativeTolerance((double) 2147483647);
        int int6 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        levenbergMarquardtOptimizer0.setOrthoTolerance((double) (short) 100);
        int int9 = levenbergMarquardtOptimizer0.getIterations();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable12 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("hi!", objArray18);
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException(localizable12, objArray18);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException21 = new org.apache.commons.math.linear.MatrixIndexException("", objArray18);
        java.util.NoSuchElementException noSuchElementException22 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("hi!", objArray18);
        boolean boolean24 = array2DRowRealMatrix7.equals((java.lang.Object) objArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix7);
        java.lang.String str26 = array2DRowRealMatrix2.toString();
        double[][] doubleArray27 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray27);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int34 = array2DRowRealMatrix33.getRowDimension();
        java.lang.String str35 = array2DRowRealMatrix33.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int39 = array2DRowRealMatrix38.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable43 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("hi!", objArray49);
        org.apache.commons.math.MathRuntimeException mathRuntimeException51 = new org.apache.commons.math.MathRuntimeException(localizable43, objArray49);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException52 = new org.apache.commons.math.linear.MatrixIndexException("", objArray49);
        java.util.NoSuchElementException noSuchElementException53 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray49);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException("hi!", objArray49);
        boolean boolean55 = array2DRowRealMatrix38.equals((java.lang.Object) objArray49);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = array2DRowRealMatrix33.multiply(array2DRowRealMatrix38);
        java.lang.String str57 = array2DRowRealMatrix33.toString();
        double[][] doubleArray58 = array2DRowRealMatrix33.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray58, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix61 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray58);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix62 = blockRealMatrix30.multiply(blockRealMatrix61);
        try {
            double[] doubleArray64 = blockRealMatrix61.getColumn((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 10 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(noSuchElementException22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str26.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str35.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(noSuchElementException53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str57.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(blockRealMatrix62);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        java.lang.String str1 = array2DRowRealMatrix0.toString();
        int int2 = array2DRowRealMatrix0.getColumnDimension();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor3 = null;
        try {
            double double8 = array2DRowRealMatrix0.walkInRowOrder(realMatrixChangingVisitor3, 0, 1000, 10, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 0 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Array2DRowRealMatrix{}" + "'", str1.equals("Array2DRowRealMatrix{}"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable12 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("hi!", objArray18);
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException(localizable12, objArray18);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException21 = new org.apache.commons.math.linear.MatrixIndexException("", objArray18);
        java.util.NoSuchElementException noSuchElementException22 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("hi!", objArray18);
        boolean boolean24 = array2DRowRealMatrix7.equals((java.lang.Object) objArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix7);
        java.lang.String str26 = array2DRowRealMatrix2.toString();
        double[][] doubleArray27 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray27);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int34 = array2DRowRealMatrix33.getRowDimension();
        java.lang.String str35 = array2DRowRealMatrix33.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int39 = array2DRowRealMatrix38.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable43 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("hi!", objArray49);
        org.apache.commons.math.MathRuntimeException mathRuntimeException51 = new org.apache.commons.math.MathRuntimeException(localizable43, objArray49);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException52 = new org.apache.commons.math.linear.MatrixIndexException("", objArray49);
        java.util.NoSuchElementException noSuchElementException53 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray49);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException("hi!", objArray49);
        boolean boolean55 = array2DRowRealMatrix38.equals((java.lang.Object) objArray49);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = array2DRowRealMatrix33.multiply(array2DRowRealMatrix38);
        java.lang.String str57 = array2DRowRealMatrix33.toString();
        double[][] doubleArray58 = array2DRowRealMatrix33.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray58, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix61 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray58);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix62 = blockRealMatrix30.multiply(blockRealMatrix61);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix64 = blockRealMatrix62.scalarAdd((double) 0);
        try {
            blockRealMatrix62.setEntry((int) 'a', (int) (byte) 100, (double) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (97, 100) in a 10x10 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(noSuchElementException22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str26.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str35.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(noSuchElementException53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str57.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(blockRealMatrix62);
        org.junit.Assert.assertNotNull(blockRealMatrix64);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.apache.commons.math.exception.Localizable localizable0 = null;
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int4 = array2DRowRealMatrix3.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable8 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("hi!", objArray14);
        org.apache.commons.math.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.MathRuntimeException(localizable8, objArray14);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException17 = new org.apache.commons.math.linear.MatrixIndexException("", objArray14);
        java.util.NoSuchElementException noSuchElementException18 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray14);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException("hi!", objArray14);
        boolean boolean20 = array2DRowRealMatrix3.equals((java.lang.Object) objArray14);
        org.apache.commons.math.optimization.OptimizationException optimizationException21 = new org.apache.commons.math.optimization.OptimizationException(localizable0, objArray14);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(noSuchElementException18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.apache.commons.math.exception.Localizable localizable2 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("hi!", objArray8);
        org.apache.commons.math.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.MathRuntimeException(localizable2, objArray8);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException11 = new org.apache.commons.math.linear.MatrixIndexException("", objArray8);
        org.apache.commons.math.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.MathRuntimeException("hi!", objArray8);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException14 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathRuntimeException12, (double) (-1L));
        double[] doubleArray15 = functionEvaluationException14.getArgument();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException3 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 100, "", objArray2);
        org.apache.commons.math.exception.Localizable localizable4 = functionEvaluationException3.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable5 = null;
        org.apache.commons.math.exception.Localizable localizable8 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("hi!", objArray14);
        org.apache.commons.math.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.MathRuntimeException(localizable8, objArray14);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException17 = new org.apache.commons.math.linear.MatrixIndexException("", objArray14);
        java.util.NoSuchElementException noSuchElementException18 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray14);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException(localizable5, objArray14);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException20 = new org.apache.commons.math.linear.InvalidMatrixException(localizable4, objArray14);
        java.lang.Object[] objArray21 = invalidMatrixException20.getArguments();
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(noSuchElementException18);
        org.junit.Assert.assertNotNull(objArray21);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        levenbergMarquardtOptimizer0.setQRRankingThreshold((double) (short) 100);
        levenbergMarquardtOptimizer0.setParRelativeTolerance((double) 2147483647);
        int int6 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        levenbergMarquardtOptimizer0.setOrthoTolerance((double) (short) 100);
        double double9 = levenbergMarquardtOptimizer0.getRMS();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.apache.commons.math.exception.Localizable localizable4 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException("hi!", objArray10);
        org.apache.commons.math.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.MathRuntimeException(localizable4, objArray10);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException13 = new org.apache.commons.math.linear.MatrixIndexException("", objArray10);
        java.util.NoSuchElementException noSuchElementException14 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray10);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("hi!", objArray10);
        java.lang.IllegalArgumentException illegalArgumentException16 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray10);
        double[] doubleArray17 = new double[] {};
        double[] doubleArray24 = new double[] { (-1), (byte) 100, 0L, (-1L), (byte) 1, (-1.0f) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair26 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray17, doubleArray24, false);
        double[] doubleArray27 = vectorialPointValuePair26.getValue();
        double[] doubleArray28 = vectorialPointValuePair26.getValueRef();
        double[] doubleArray29 = null;
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair30 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray28, doubleArray29);
        org.apache.commons.math.linear.RealMatrix realMatrix31 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(doubleArray28);
        org.apache.commons.math.linear.BigMatrix bigMatrix32 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray28);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        array2DRowRealMatrix36.luDecompose();
        double[][] doubleArray38 = array2DRowRealMatrix36.getData();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException39 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) illegalArgumentException16, doubleArray28, "{0}", (java.lang.Object[]) doubleArray38);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(noSuchElementException14);
        org.junit.Assert.assertNotNull(illegalArgumentException16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realMatrix31);
        org.junit.Assert.assertNotNull(bigMatrix32);
        org.junit.Assert.assertNotNull(doubleArray38);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        double[] doubleArray1 = new double[] {};
        double[] doubleArray8 = new double[] { (-1), (byte) 100, 0L, (-1L), (byte) 1, (-1.0f) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair10 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray1, doubleArray8, false);
        double[] doubleArray11 = vectorialPointValuePair10.getPoint();
        org.apache.commons.math.exception.Localizable localizable12 = null;
        org.apache.commons.math.exception.Localizable localizable13 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException("hi!", objArray19);
        org.apache.commons.math.MathRuntimeException mathRuntimeException21 = new org.apache.commons.math.MathRuntimeException(localizable13, objArray19);
        java.lang.RuntimeException runtimeException22 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) mathRuntimeException21);
        java.lang.Throwable[] throwableArray23 = runtimeException22.getSuppressed();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException24 = new org.apache.commons.math.FunctionEvaluationException(doubleArray11, localizable12, (java.lang.Object[]) throwableArray23);
        java.io.EOFException eOFException25 = org.apache.commons.math.MathRuntimeException.createEOFException("org.apache.commons.math.ConvergenceException: hi!", (java.lang.Object[]) throwableArray23);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(runtimeException22);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(eOFException25);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException1 = new org.apache.commons.math.FunctionEvaluationException((-1.0d));
        java.lang.String str2 = functionEvaluationException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math.FunctionEvaluationException: evaluation failed for argument = -1" + "'", str2.equals("org.apache.commons.math.FunctionEvaluationException: evaluation failed for argument = -1"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        double[][] doubleArray2 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(10, (int) ' ');
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2, false);
        double double5 = array2DRowRealMatrix4.getFrobeniusNorm();
        double[][] doubleArray6 = array2DRowRealMatrix4.getDataRef();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int10 = array2DRowRealMatrix9.getRowDimension();
        boolean boolean12 = array2DRowRealMatrix9.equals((java.lang.Object) (byte) 0);
        int int13 = array2DRowRealMatrix9.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int17 = array2DRowRealMatrix16.getRowDimension();
        boolean boolean19 = array2DRowRealMatrix16.equals((java.lang.Object) (byte) 0);
        array2DRowRealMatrix16.luDecompose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int24 = array2DRowRealMatrix23.getRowDimension();
        boolean boolean26 = array2DRowRealMatrix23.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix27 = array2DRowRealMatrix23.copy();
        org.apache.commons.math.linear.RealMatrix realMatrix28 = array2DRowRealMatrix16.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix23);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = array2DRowRealMatrix9.subtract(array2DRowRealMatrix23);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int33 = array2DRowRealMatrix32.getRowDimension();
        boolean boolean35 = array2DRowRealMatrix32.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = array2DRowRealMatrix29.add(array2DRowRealMatrix32);
        double double37 = array2DRowRealMatrix32.getNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix39 = array2DRowRealMatrix32.getRowMatrix(0);
        org.apache.commons.math.linear.RealMatrix realMatrix40 = array2DRowRealMatrix32.transpose();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix41 = array2DRowRealMatrix4.multiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix32);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix29);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 10 + "'", int33 == 10);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix39);
        org.junit.Assert.assertNotNull(realMatrix40);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        boolean boolean5 = array2DRowRealMatrix2.equals((java.lang.Object) (byte) 0);
        int int6 = array2DRowRealMatrix2.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int10 = array2DRowRealMatrix9.getRowDimension();
        boolean boolean12 = array2DRowRealMatrix9.equals((java.lang.Object) (byte) 0);
        array2DRowRealMatrix9.luDecompose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int17 = array2DRowRealMatrix16.getRowDimension();
        boolean boolean19 = array2DRowRealMatrix16.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.copy();
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix9.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int26 = array2DRowRealMatrix25.getRowDimension();
        boolean boolean28 = array2DRowRealMatrix25.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = array2DRowRealMatrix22.add(array2DRowRealMatrix25);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int33 = array2DRowRealMatrix32.getRowDimension();
        boolean boolean35 = array2DRowRealMatrix32.equals((java.lang.Object) (byte) 0);
        int int36 = array2DRowRealMatrix32.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int40 = array2DRowRealMatrix39.getRowDimension();
        boolean boolean42 = array2DRowRealMatrix39.equals((java.lang.Object) (byte) 0);
        array2DRowRealMatrix39.luDecompose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int47 = array2DRowRealMatrix46.getRowDimension();
        boolean boolean49 = array2DRowRealMatrix46.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix50 = array2DRowRealMatrix46.copy();
        org.apache.commons.math.linear.RealMatrix realMatrix51 = array2DRowRealMatrix39.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix46);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix52 = array2DRowRealMatrix32.subtract(array2DRowRealMatrix46);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = array2DRowRealMatrix29.multiply(array2DRowRealMatrix46);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor54 = null;
        try {
            double double59 = array2DRowRealMatrix46.walkInRowOrder(realMatrixChangingVisitor54, (int) (short) -1, 0, (int) (short) 100, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index -1 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix29);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 10 + "'", int33 == 10);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 10 + "'", int40 == 10);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 10 + "'", int47 == 10);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(realMatrix50);
        org.junit.Assert.assertNotNull(realMatrix51);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix52);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix53);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException7 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 100, "", objArray6);
        org.apache.commons.math.exception.Localizable localizable8 = functionEvaluationException7.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable11 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("hi!", objArray17);
        org.apache.commons.math.MathRuntimeException mathRuntimeException19 = new org.apache.commons.math.MathRuntimeException(localizable11, objArray17);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException20 = new org.apache.commons.math.linear.MatrixIndexException("", objArray17);
        org.apache.commons.math.MathRuntimeException mathRuntimeException21 = new org.apache.commons.math.MathRuntimeException("hi!", objArray17);
        java.lang.IllegalArgumentException illegalArgumentException22 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException(localizable8, objArray17);
        org.apache.commons.math.exception.Localizable localizable26 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException("hi!", objArray32);
        org.apache.commons.math.MathRuntimeException mathRuntimeException34 = new org.apache.commons.math.MathRuntimeException(localizable26, objArray32);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException35 = new org.apache.commons.math.linear.MatrixIndexException("", objArray32);
        java.util.NoSuchElementException noSuchElementException36 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray32);
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException("hi!", objArray32);
        java.lang.UnsupportedOperationException unsupportedOperationException38 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException(localizable8, objArray32);
        double[][] doubleArray41 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(10, (int) ' ');
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray41, false);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException44 = new org.apache.commons.math.MaxEvaluationsExceededException(10, localizable8, (java.lang.Object[]) doubleArray41);
        java.util.NoSuchElementException noSuchElementException45 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("org.apache.commons.math.FunctionEvaluationException: hi!", (java.lang.Object[]) doubleArray41);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException46 = new org.apache.commons.math.MaxEvaluationsExceededException((int) 'a', "org.apache.commons.math.FunctionEvaluationException: evaluation failed for argument = -1", (java.lang.Object[]) doubleArray41);
        org.junit.Assert.assertNotNull(localizable8);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(illegalArgumentException22);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(noSuchElementException36);
        org.junit.Assert.assertNotNull(unsupportedOperationException38);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(noSuchElementException45);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray7 = new double[] { (-1), (byte) 100, 0L, (-1L), (byte) 1, (-1.0f) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair9 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray0, doubleArray7, false);
        double[] doubleArray10 = vectorialPointValuePair9.getPoint();
        org.apache.commons.math.exception.Localizable localizable11 = null;
        org.apache.commons.math.exception.Localizable localizable12 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("hi!", objArray18);
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException(localizable12, objArray18);
        java.lang.RuntimeException runtimeException21 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) mathRuntimeException20);
        java.lang.Throwable[] throwableArray22 = runtimeException21.getSuppressed();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException23 = new org.apache.commons.math.FunctionEvaluationException(doubleArray10, localizable11, (java.lang.Object[]) throwableArray22);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray31 = new double[] { (-1), (byte) 100, 0L, (-1L), (byte) 1, (-1.0f) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair33 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray24, doubleArray31, false);
        double[] doubleArray34 = vectorialPointValuePair33.getValue();
        double[] doubleArray35 = vectorialPointValuePair33.getValue();
        org.apache.commons.math.linear.BigMatrix bigMatrix36 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(doubleArray35);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair37 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray10, doubleArray35);
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix38 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(doubleArray10);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(runtimeException21);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(bigMatrix36);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        boolean boolean5 = array2DRowRealMatrix2.equals((java.lang.Object) (byte) 0);
        int int6 = array2DRowRealMatrix2.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int10 = array2DRowRealMatrix9.getRowDimension();
        boolean boolean12 = array2DRowRealMatrix9.equals((java.lang.Object) (byte) 0);
        array2DRowRealMatrix9.luDecompose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int17 = array2DRowRealMatrix16.getRowDimension();
        boolean boolean19 = array2DRowRealMatrix16.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.copy();
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix9.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int26 = array2DRowRealMatrix25.getRowDimension();
        boolean boolean28 = array2DRowRealMatrix25.equals((java.lang.Object) (byte) 0);
        int int29 = array2DRowRealMatrix25.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int33 = array2DRowRealMatrix32.getRowDimension();
        boolean boolean35 = array2DRowRealMatrix32.equals((java.lang.Object) (byte) 0);
        array2DRowRealMatrix32.luDecompose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int40 = array2DRowRealMatrix39.getRowDimension();
        boolean boolean42 = array2DRowRealMatrix39.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix43 = array2DRowRealMatrix39.copy();
        org.apache.commons.math.linear.RealMatrix realMatrix44 = array2DRowRealMatrix32.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix39);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix45 = array2DRowRealMatrix25.subtract(array2DRowRealMatrix39);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int49 = array2DRowRealMatrix48.getRowDimension();
        boolean boolean51 = array2DRowRealMatrix48.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix52 = array2DRowRealMatrix45.add(array2DRowRealMatrix48);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int56 = array2DRowRealMatrix55.getRowDimension();
        boolean boolean58 = array2DRowRealMatrix55.equals((java.lang.Object) (byte) 0);
        int int59 = array2DRowRealMatrix55.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix62 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int63 = array2DRowRealMatrix62.getRowDimension();
        boolean boolean65 = array2DRowRealMatrix62.equals((java.lang.Object) (byte) 0);
        array2DRowRealMatrix62.luDecompose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int70 = array2DRowRealMatrix69.getRowDimension();
        boolean boolean72 = array2DRowRealMatrix69.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix73 = array2DRowRealMatrix69.copy();
        org.apache.commons.math.linear.RealMatrix realMatrix74 = array2DRowRealMatrix62.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix69);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix75 = array2DRowRealMatrix55.subtract(array2DRowRealMatrix69);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix76 = array2DRowRealMatrix52.multiply(array2DRowRealMatrix69);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix77 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix76);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor78 = null;
        try {
            double double79 = array2DRowRealMatrix77.walkInRowOrder(realMatrixChangingVisitor78);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 10 + "'", int33 == 10);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 10 + "'", int40 == 10);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix45);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 10 + "'", int49 == 10);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix52);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 10 + "'", int56 == 10);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 10 + "'", int59 == 10);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 10 + "'", int63 == 10);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 10 + "'", int70 == 10);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(realMatrix73);
        org.junit.Assert.assertNotNull(realMatrix74);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix75);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix76);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix77);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable12 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("hi!", objArray18);
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException(localizable12, objArray18);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException21 = new org.apache.commons.math.linear.MatrixIndexException("", objArray18);
        java.util.NoSuchElementException noSuchElementException22 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("hi!", objArray18);
        boolean boolean24 = array2DRowRealMatrix7.equals((java.lang.Object) objArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix7);
        java.lang.String str26 = array2DRowRealMatrix2.toString();
        double[][] doubleArray27 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray27);
        double double31 = blockRealMatrix30.getNorm();
        double[] doubleArray33 = blockRealMatrix30.getRow(0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(noSuchElementException22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str26.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 10);
        org.apache.commons.math.linear.RealMatrix realMatrix3 = null;
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.add(realMatrix3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable12 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("hi!", objArray18);
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException(localizable12, objArray18);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException21 = new org.apache.commons.math.linear.MatrixIndexException("", objArray18);
        java.util.NoSuchElementException noSuchElementException22 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("hi!", objArray18);
        boolean boolean24 = array2DRowRealMatrix7.equals((java.lang.Object) objArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix7);
        java.lang.String str26 = array2DRowRealMatrix2.toString();
        double[][] doubleArray27 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray27);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int34 = array2DRowRealMatrix33.getRowDimension();
        java.lang.String str35 = array2DRowRealMatrix33.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int39 = array2DRowRealMatrix38.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable43 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("hi!", objArray49);
        org.apache.commons.math.MathRuntimeException mathRuntimeException51 = new org.apache.commons.math.MathRuntimeException(localizable43, objArray49);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException52 = new org.apache.commons.math.linear.MatrixIndexException("", objArray49);
        java.util.NoSuchElementException noSuchElementException53 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray49);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException("hi!", objArray49);
        boolean boolean55 = array2DRowRealMatrix38.equals((java.lang.Object) objArray49);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = array2DRowRealMatrix33.multiply(array2DRowRealMatrix38);
        java.lang.String str57 = array2DRowRealMatrix33.toString();
        double[][] doubleArray58 = array2DRowRealMatrix33.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray58, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix61 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray58);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix62 = blockRealMatrix30.multiply(blockRealMatrix61);
        org.apache.commons.math.linear.RealMatrix realMatrix64 = blockRealMatrix62.scalarMultiply((double) 100.0f);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix66 = blockRealMatrix62.getRowMatrix(52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 52 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(noSuchElementException22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str26.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str35.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(noSuchElementException53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str57.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(blockRealMatrix62);
        org.junit.Assert.assertNotNull(realMatrix64);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        int int2 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        int int3 = levenbergMarquardtOptimizer0.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1000 + "'", int3 == 1000);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        levenbergMarquardtOptimizer0.setQRRankingThreshold((double) (short) 100);
        levenbergMarquardtOptimizer0.setParRelativeTolerance((double) 2147483647);
        int int6 = levenbergMarquardtOptimizer0.getMaxIterations();
        int int7 = levenbergMarquardtOptimizer0.getJacobianEvaluations();
        int int8 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1000 + "'", int6 == 1000);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable12 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("hi!", objArray18);
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException(localizable12, objArray18);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException21 = new org.apache.commons.math.linear.MatrixIndexException("", objArray18);
        java.util.NoSuchElementException noSuchElementException22 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("hi!", objArray18);
        boolean boolean24 = array2DRowRealMatrix7.equals((java.lang.Object) objArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix7);
        java.lang.String str26 = array2DRowRealMatrix2.toString();
        double[][] doubleArray27 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray27);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int34 = array2DRowRealMatrix33.getRowDimension();
        java.lang.String str35 = array2DRowRealMatrix33.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int39 = array2DRowRealMatrix38.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable43 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("hi!", objArray49);
        org.apache.commons.math.MathRuntimeException mathRuntimeException51 = new org.apache.commons.math.MathRuntimeException(localizable43, objArray49);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException52 = new org.apache.commons.math.linear.MatrixIndexException("", objArray49);
        java.util.NoSuchElementException noSuchElementException53 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray49);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException("hi!", objArray49);
        boolean boolean55 = array2DRowRealMatrix38.equals((java.lang.Object) objArray49);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = array2DRowRealMatrix33.multiply(array2DRowRealMatrix38);
        java.lang.String str57 = array2DRowRealMatrix33.toString();
        double[][] doubleArray58 = array2DRowRealMatrix33.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray58, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix61 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray58);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix62 = blockRealMatrix30.multiply(blockRealMatrix61);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix64 = blockRealMatrix61.getColumnMatrix(0);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor65 = null;
        try {
            double double70 = blockRealMatrix64.walkInOptimizedOrder(realMatrixPreservingVisitor65, (int) '4', 100, 2147483647, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 52 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(noSuchElementException22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str26.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str35.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(noSuchElementException53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str57.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(blockRealMatrix62);
        org.junit.Assert.assertNotNull(blockRealMatrix64);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        boolean boolean5 = array2DRowRealMatrix2.equals((java.lang.Object) (byte) 0);
        array2DRowRealMatrix2.luDecompose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int10 = array2DRowRealMatrix9.getRowDimension();
        boolean boolean12 = array2DRowRealMatrix9.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.copy();
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix2.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix9);
        int int15 = array2DRowRealMatrix2.getColumnDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int19 = array2DRowRealMatrix18.getRowDimension();
        java.lang.String str20 = array2DRowRealMatrix18.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int24 = array2DRowRealMatrix23.getRowDimension();
        boolean boolean26 = array2DRowRealMatrix23.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix27 = array2DRowRealMatrix23.copy();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = array2DRowRealMatrix18.subtract(array2DRowRealMatrix23);
        org.apache.commons.math.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix2, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix23);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor30 = null;
        try {
            double double35 = array2DRowRealMatrix2.walkInColumnOrder(realMatrixChangingVisitor30, 10, (-1), 2147483647, 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 10 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str20.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix28);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable7 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("hi!", objArray13);
        org.apache.commons.math.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.MathRuntimeException(localizable7, objArray13);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException16 = new org.apache.commons.math.linear.MatrixIndexException("", objArray13);
        java.util.NoSuchElementException noSuchElementException17 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray13);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("hi!", objArray13);
        boolean boolean19 = array2DRowRealMatrix2.equals((java.lang.Object) objArray13);
        double[][] doubleArray20 = array2DRowRealMatrix2.getDataRef();
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl22 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix2, (double) 1L);
        org.apache.commons.math.exception.Localizable localizable25 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException("hi!", objArray31);
        org.apache.commons.math.MathRuntimeException mathRuntimeException33 = new org.apache.commons.math.MathRuntimeException(localizable25, objArray31);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException34 = new org.apache.commons.math.linear.MatrixIndexException("", objArray31);
        org.apache.commons.math.MathRuntimeException mathRuntimeException35 = new org.apache.commons.math.MathRuntimeException("hi!", objArray31);
        double[] doubleArray37 = new double[] { ' ' };
        org.apache.commons.math.exception.Localizable localizable38 = null;
        org.apache.commons.math.exception.Localizable localizable41 = null;
        java.lang.Object[] objArray47 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException("hi!", objArray47);
        org.apache.commons.math.MathRuntimeException mathRuntimeException49 = new org.apache.commons.math.MathRuntimeException(localizable41, objArray47);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException50 = new org.apache.commons.math.linear.MatrixIndexException("", objArray47);
        java.util.NoSuchElementException noSuchElementException51 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray47);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException52 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathRuntimeException35, doubleArray37, localizable38, objArray47);
        double[] doubleArray53 = functionEvaluationException52.getArgument();
        org.apache.commons.math.linear.RealMatrix realMatrix54 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray53);
        try {
            double[] doubleArray55 = array2DRowRealMatrix2.operate(doubleArray53);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(noSuchElementException17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(noSuchElementException51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(realMatrix54);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker0 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        double[] doubleArray2 = new double[] {};
        double[] doubleArray9 = new double[] { (-1), (byte) 100, 0L, (-1L), (byte) 1, (-1.0f) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair11 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray2, doubleArray9, false);
        double[] doubleArray12 = vectorialPointValuePair11.getPointRef();
        double[] doubleArray13 = null;
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair14 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray12, doubleArray13);
        org.apache.commons.math.exception.Localizable localizable15 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray21);
        org.apache.commons.math.MathRuntimeException mathRuntimeException23 = new org.apache.commons.math.MathRuntimeException(localizable15, objArray21);
        java.lang.RuntimeException runtimeException24 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) mathRuntimeException23);
        java.lang.Throwable[] throwableArray25 = runtimeException24.getSuppressed();
        java.io.IOException iOException26 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) runtimeException24);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) iOException26);
        double[] doubleArray28 = new double[] {};
        double[] doubleArray35 = new double[] { (-1), (byte) 100, 0L, (-1L), (byte) 1, (-1.0f) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair37 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray28, doubleArray35, false);
        double[] doubleArray38 = vectorialPointValuePair37.getPoint();
        org.apache.commons.math.exception.Localizable localizable39 = null;
        org.apache.commons.math.exception.Localizable localizable40 = null;
        java.lang.Object[] objArray46 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException("hi!", objArray46);
        org.apache.commons.math.MathRuntimeException mathRuntimeException48 = new org.apache.commons.math.MathRuntimeException(localizable40, objArray46);
        java.lang.RuntimeException runtimeException49 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) mathRuntimeException48);
        java.lang.Throwable[] throwableArray50 = runtimeException49.getSuppressed();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException51 = new org.apache.commons.math.FunctionEvaluationException(doubleArray38, localizable39, (java.lang.Object[]) throwableArray50);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException52 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException27, doubleArray38);
        org.apache.commons.math.exception.Localizable localizable54 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException("hi!", objArray60);
        org.apache.commons.math.MathRuntimeException mathRuntimeException62 = new org.apache.commons.math.MathRuntimeException(localizable54, objArray60);
        java.lang.RuntimeException runtimeException63 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) mathRuntimeException62);
        java.lang.Throwable[] throwableArray64 = runtimeException63.getSuppressed();
        org.apache.commons.math.optimization.OptimizationException optimizationException65 = new org.apache.commons.math.optimization.OptimizationException("", (java.lang.Object[]) throwableArray64);
        double[] doubleArray66 = new double[] {};
        double[] doubleArray73 = new double[] { (-1), (byte) 100, 0L, (-1L), (byte) 1, (-1.0f) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair75 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray66, doubleArray73, false);
        org.apache.commons.math.exception.Localizable localizable80 = null;
        org.apache.commons.math.exception.Localizable localizable81 = null;
        java.lang.Object[] objArray87 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException88 = new org.apache.commons.math.MathException("hi!", objArray87);
        org.apache.commons.math.MathRuntimeException mathRuntimeException89 = new org.apache.commons.math.MathRuntimeException(localizable81, objArray87);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException90 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable80, objArray87);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException91 = new org.apache.commons.math.FunctionEvaluationException((double) (byte) -1, "hi!", objArray87);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException92 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) optimizationException65, doubleArray73, "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}", objArray87);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair93 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray38, doubleArray73);
        try {
            boolean boolean94 = simpleVectorialValueChecker0.converged((int) (short) 100, vectorialPointValuePair14, vectorialPointValuePair93);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(runtimeException24);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(iOException26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(runtimeException49);
        org.junit.Assert.assertNotNull(throwableArray50);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(runtimeException63);
        org.junit.Assert.assertNotNull(throwableArray64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(objArray87);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        java.lang.String str1 = array2DRowRealMatrix0.toString();
        int int2 = array2DRowRealMatrix0.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable5 = null;
        org.apache.commons.math.exception.Localizable localizable7 = null;
        org.apache.commons.math.exception.Localizable localizable10 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("hi!", objArray16);
        org.apache.commons.math.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.MathRuntimeException(localizable10, objArray16);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException19 = new org.apache.commons.math.linear.MatrixIndexException("", objArray16);
        java.util.NoSuchElementException noSuchElementException20 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray16);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException21 = new org.apache.commons.math.FunctionEvaluationException(1.0d, localizable7, objArray16);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException22 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100, localizable5, objArray16);
        double[] doubleArray23 = new double[] {};
        double[] doubleArray30 = new double[] { (-1), (byte) 100, 0L, (-1L), (byte) 1, (-1.0f) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair32 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray23, doubleArray30, false);
        double[] doubleArray33 = vectorialPointValuePair32.getValue();
        org.apache.commons.math.exception.Localizable localizable35 = null;
        java.lang.Object[] objArray41 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException("hi!", objArray41);
        org.apache.commons.math.MathRuntimeException mathRuntimeException43 = new org.apache.commons.math.MathRuntimeException(localizable35, objArray41);
        java.lang.RuntimeException runtimeException44 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) mathRuntimeException43);
        java.lang.Throwable[] throwableArray45 = runtimeException44.getSuppressed();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException46 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException22, doubleArray33, "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}", (java.lang.Object[]) throwableArray45);
        org.apache.commons.math.linear.BigMatrix bigMatrix47 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray33);
        try {
            array2DRowRealMatrix0.setRow((int) (short) 100, doubleArray33);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Array2DRowRealMatrix{}" + "'", str1.equals("Array2DRowRealMatrix{}"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(noSuchElementException20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(runtimeException44);
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertNotNull(bigMatrix47);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray7 = new double[] { (-1), (byte) 100, 0L, (-1L), (byte) 1, (-1.0f) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair9 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray0, doubleArray7, false);
        org.apache.commons.math.exception.Localizable localizable11 = null;
        org.apache.commons.math.exception.Localizable localizable14 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException("hi!", objArray20);
        org.apache.commons.math.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.MathRuntimeException(localizable14, objArray20);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException23 = new org.apache.commons.math.linear.MatrixIndexException("", objArray20);
        java.util.NoSuchElementException noSuchElementException24 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray20);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException(1.0d, localizable11, objArray20);
        double[] doubleArray26 = functionEvaluationException25.getArgument();
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair28 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray0, doubleArray26, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int33 = array2DRowRealMatrix32.getRowDimension();
        java.lang.String str34 = array2DRowRealMatrix32.toString();
        array2DRowRealMatrix32.luDecompose();
        double double36 = array2DRowRealMatrix32.getFrobeniusNorm();
        int int37 = array2DRowRealMatrix32.getRowDimension();
        double[][] doubleArray38 = array2DRowRealMatrix32.getData();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException39 = new org.apache.commons.math.FunctionEvaluationException(doubleArray0, "java.io.IOException: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH", (java.lang.Object[]) doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(noSuchElementException24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 10 + "'", int33 == 10);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str34.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 10 + "'", int37 == 10);
        org.junit.Assert.assertNotNull(doubleArray38);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getRowDimension();
        boolean boolean10 = array2DRowRealMatrix7.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix11 = array2DRowRealMatrix7.copy();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix7);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int16 = array2DRowRealMatrix15.getRowDimension();
        java.lang.String str17 = array2DRowRealMatrix15.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int21 = array2DRowRealMatrix20.getRowDimension();
        boolean boolean23 = array2DRowRealMatrix20.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix24 = array2DRowRealMatrix20.copy();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix20);
        org.apache.commons.math.linear.RealMatrix realMatrix26 = array2DRowRealMatrix7.multiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix15);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl28 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix7, (double) (short) 10);
        int[] intArray29 = lUDecompositionImpl28.getPivot();
        int[] intArray30 = lUDecompositionImpl28.getPivot();
        org.apache.commons.math.linear.RealMatrix realMatrix31 = lUDecompositionImpl28.getL();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str17.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(realMatrix24);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNull(realMatrix31);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray7 = new double[] { (-1), (byte) 100, 0L, (-1L), (byte) 1, (-1.0f) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair9 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray0, doubleArray7, false);
        double[] doubleArray10 = vectorialPointValuePair9.getPoint();
        org.apache.commons.math.exception.Localizable localizable14 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException("hi!", objArray20);
        org.apache.commons.math.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.MathRuntimeException(localizable14, objArray20);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException23 = new org.apache.commons.math.linear.MatrixIndexException("", objArray20);
        org.apache.commons.math.MathRuntimeException mathRuntimeException24 = new org.apache.commons.math.MathRuntimeException("hi!", objArray20);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException(doubleArray10, "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}", objArray20);
        org.apache.commons.math.exception.Localizable localizable28 = null;
        java.lang.Object[] objArray34 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException("hi!", objArray34);
        org.apache.commons.math.MathRuntimeException mathRuntimeException36 = new org.apache.commons.math.MathRuntimeException(localizable28, objArray34);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException37 = new org.apache.commons.math.linear.MatrixIndexException("", objArray34);
        org.apache.commons.math.MathRuntimeException mathRuntimeException38 = new org.apache.commons.math.MathRuntimeException("hi!", objArray34);
        double[] doubleArray40 = new double[] { ' ' };
        org.apache.commons.math.exception.Localizable localizable41 = null;
        org.apache.commons.math.exception.Localizable localizable44 = null;
        java.lang.Object[] objArray50 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException("hi!", objArray50);
        org.apache.commons.math.MathRuntimeException mathRuntimeException52 = new org.apache.commons.math.MathRuntimeException(localizable44, objArray50);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException53 = new org.apache.commons.math.linear.MatrixIndexException("", objArray50);
        java.util.NoSuchElementException noSuchElementException54 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray50);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException55 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathRuntimeException38, doubleArray40, localizable41, objArray50);
        double[] doubleArray56 = functionEvaluationException55.getArgument();
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair57 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray10, doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(noSuchElementException54);
        org.junit.Assert.assertNotNull(doubleArray56);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable7 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("hi!", objArray13);
        org.apache.commons.math.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.MathRuntimeException(localizable7, objArray13);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException16 = new org.apache.commons.math.linear.MatrixIndexException("", objArray13);
        java.util.NoSuchElementException noSuchElementException17 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray13);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("hi!", objArray13);
        boolean boolean19 = array2DRowRealMatrix2.equals((java.lang.Object) objArray13);
        double[][] doubleArray20 = array2DRowRealMatrix2.getDataRef();
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl22 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix2, (double) 1L);
        org.apache.commons.math.linear.RealMatrix realMatrix23 = lUDecompositionImpl22.getP();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(noSuchElementException17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNull(realMatrix23);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.apache.commons.math.exception.Localizable localizable0 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException("hi!", objArray6);
        org.apache.commons.math.MathRuntimeException mathRuntimeException8 = new org.apache.commons.math.MathRuntimeException(localizable0, objArray6);
        java.lang.RuntimeException runtimeException9 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) mathRuntimeException8);
        java.lang.Throwable[] throwableArray10 = runtimeException9.getSuppressed();
        java.io.IOException iOException11 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) runtimeException9);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) iOException11);
        org.apache.commons.math.exception.Localizable localizable13 = convergenceException12.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable17 = null;
        org.apache.commons.math.exception.Localizable localizable19 = null;
        org.apache.commons.math.exception.Localizable localizable22 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException("hi!", objArray28);
        org.apache.commons.math.MathRuntimeException mathRuntimeException30 = new org.apache.commons.math.MathRuntimeException(localizable22, objArray28);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException31 = new org.apache.commons.math.linear.MatrixIndexException("", objArray28);
        java.util.NoSuchElementException noSuchElementException32 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray28);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException33 = new org.apache.commons.math.FunctionEvaluationException(1.0d, localizable19, objArray28);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException34 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100, localizable17, objArray28);
        double[] doubleArray35 = new double[] {};
        double[] doubleArray42 = new double[] { (-1), (byte) 100, 0L, (-1L), (byte) 1, (-1.0f) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair44 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray35, doubleArray42, false);
        double[] doubleArray45 = vectorialPointValuePair44.getValue();
        org.apache.commons.math.exception.Localizable localizable47 = null;
        java.lang.Object[] objArray53 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException("hi!", objArray53);
        org.apache.commons.math.MathRuntimeException mathRuntimeException55 = new org.apache.commons.math.MathRuntimeException(localizable47, objArray53);
        java.lang.RuntimeException runtimeException56 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) mathRuntimeException55);
        java.lang.Throwable[] throwableArray57 = runtimeException56.getSuppressed();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException58 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) maxIterationsExceededException34, doubleArray45, "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}", (java.lang.Object[]) throwableArray57);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException59 = new org.apache.commons.math.MaxEvaluationsExceededException((int) ' ', "org.apache.commons.math.MathException: ", (java.lang.Object[]) throwableArray57);
        java.lang.IllegalArgumentException illegalArgumentException60 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException(localizable13, (java.lang.Object[]) throwableArray57);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(runtimeException9);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(iOException11);
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable13.equals(org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(noSuchElementException32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(runtimeException56);
        org.junit.Assert.assertNotNull(throwableArray57);
        org.junit.Assert.assertNotNull(illegalArgumentException60);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable12 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("hi!", objArray18);
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException(localizable12, objArray18);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException21 = new org.apache.commons.math.linear.MatrixIndexException("", objArray18);
        java.util.NoSuchElementException noSuchElementException22 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("hi!", objArray18);
        boolean boolean24 = array2DRowRealMatrix7.equals((java.lang.Object) objArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix7);
        java.lang.String str26 = array2DRowRealMatrix2.toString();
        double[][] doubleArray27 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray27);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int34 = array2DRowRealMatrix33.getRowDimension();
        java.lang.String str35 = array2DRowRealMatrix33.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int39 = array2DRowRealMatrix38.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable43 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("hi!", objArray49);
        org.apache.commons.math.MathRuntimeException mathRuntimeException51 = new org.apache.commons.math.MathRuntimeException(localizable43, objArray49);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException52 = new org.apache.commons.math.linear.MatrixIndexException("", objArray49);
        java.util.NoSuchElementException noSuchElementException53 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray49);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException("hi!", objArray49);
        boolean boolean55 = array2DRowRealMatrix38.equals((java.lang.Object) objArray49);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = array2DRowRealMatrix33.multiply(array2DRowRealMatrix38);
        java.lang.String str57 = array2DRowRealMatrix33.toString();
        double[][] doubleArray58 = array2DRowRealMatrix33.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray58, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix61 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray58);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix62 = blockRealMatrix30.multiply(blockRealMatrix61);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix64 = blockRealMatrix61.getColumnMatrix(0);
        double[] doubleArray66 = blockRealMatrix64.getRow((int) (byte) 0);
        try {
            blockRealMatrix64.multiplyEntry((int) 'a', (int) (short) -1, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (97, -1) in a 10x1 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(noSuchElementException22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str26.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str35.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(noSuchElementException53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str57.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(blockRealMatrix62);
        org.junit.Assert.assertNotNull(blockRealMatrix64);
        org.junit.Assert.assertNotNull(doubleArray66);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        java.lang.String str1 = array2DRowRealMatrix0.toString();
        int int2 = array2DRowRealMatrix0.getColumnDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int10 = array2DRowRealMatrix9.getRowDimension();
        java.lang.String str11 = array2DRowRealMatrix9.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int15 = array2DRowRealMatrix14.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable19 = null;
        java.lang.Object[] objArray25 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException("hi!", objArray25);
        org.apache.commons.math.MathRuntimeException mathRuntimeException27 = new org.apache.commons.math.MathRuntimeException(localizable19, objArray25);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException28 = new org.apache.commons.math.linear.MatrixIndexException("", objArray25);
        java.util.NoSuchElementException noSuchElementException29 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray25);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException("hi!", objArray25);
        boolean boolean31 = array2DRowRealMatrix14.equals((java.lang.Object) objArray25);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix9.multiply(array2DRowRealMatrix14);
        java.lang.String str33 = array2DRowRealMatrix9.toString();
        double[][] doubleArray34 = array2DRowRealMatrix9.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray34, false);
        double[][] doubleArray37 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray34);
        try {
            array2DRowRealMatrix0.copySubMatrix(52, (int) (byte) 100, 0, (int) (byte) 10, doubleArray37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 52 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Array2DRowRealMatrix{}" + "'", str1.equals("Array2DRowRealMatrix{}"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str11.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(noSuchElementException29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str33.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        boolean boolean5 = array2DRowRealMatrix2.equals((java.lang.Object) (byte) 0);
        array2DRowRealMatrix2.luDecompose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int10 = array2DRowRealMatrix9.getRowDimension();
        boolean boolean12 = array2DRowRealMatrix9.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix9.copy();
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix2.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix9);
        int int15 = array2DRowRealMatrix2.getColumnDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int19 = array2DRowRealMatrix18.getRowDimension();
        java.lang.String str20 = array2DRowRealMatrix18.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int24 = array2DRowRealMatrix23.getRowDimension();
        boolean boolean26 = array2DRowRealMatrix23.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix27 = array2DRowRealMatrix23.copy();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = array2DRowRealMatrix18.subtract(array2DRowRealMatrix23);
        org.apache.commons.math.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix2, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix23);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int33 = array2DRowRealMatrix32.getRowDimension();
        java.lang.String str34 = array2DRowRealMatrix32.toString();
        array2DRowRealMatrix32.luDecompose();
        double double36 = array2DRowRealMatrix32.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix38 = array2DRowRealMatrix32.getRowMatrix(0);
        org.apache.commons.math.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix2, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix32);
        org.apache.commons.math.linear.RealMatrix realMatrix40 = array2DRowRealMatrix2.copy();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str20.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix28);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 10 + "'", int33 == 10);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str34.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertNotNull(realMatrix40);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable12 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("hi!", objArray18);
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException(localizable12, objArray18);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException21 = new org.apache.commons.math.linear.MatrixIndexException("", objArray18);
        java.util.NoSuchElementException noSuchElementException22 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("hi!", objArray18);
        boolean boolean24 = array2DRowRealMatrix7.equals((java.lang.Object) objArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix7);
        java.lang.String str26 = array2DRowRealMatrix2.toString();
        double[][] doubleArray27 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray27);
        org.apache.commons.math.linear.RealMatrix realMatrix32 = blockRealMatrix30.scalarMultiply((double) 10);
        double double33 = blockRealMatrix30.getFrobeniusNorm();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int37 = array2DRowRealMatrix36.getRowDimension();
        java.lang.String str38 = array2DRowRealMatrix36.toString();
        array2DRowRealMatrix36.luDecompose();
        double double40 = array2DRowRealMatrix36.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix41 = array2DRowRealMatrix36.copy();
        double double42 = array2DRowRealMatrix36.getTrace();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix43 = blockRealMatrix30.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix36);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor44 = null;
        try {
            double double49 = blockRealMatrix30.walkInRowOrder(realMatrixChangingVisitor44, 0, (int) (short) 100, (int) (byte) 0, 2147483647);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(noSuchElementException22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str26.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 10 + "'", int37 == 10);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str38.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix43);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        double double2 = levenbergMarquardtOptimizer0.getRMS();
        double double3 = levenbergMarquardtOptimizer0.getRMS();
        levenbergMarquardtOptimizer0.setOrthoTolerance((double) 2147483647);
        int int6 = levenbergMarquardtOptimizer0.getIterations();
        int int7 = levenbergMarquardtOptimizer0.getEvaluations();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.apache.commons.math.exception.Localizable localizable1 = null;
        org.apache.commons.math.exception.Localizable localizable4 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException("hi!", objArray10);
        org.apache.commons.math.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.MathRuntimeException(localizable4, objArray10);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException13 = new org.apache.commons.math.linear.MatrixIndexException("", objArray10);
        java.util.NoSuchElementException noSuchElementException14 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException(1.0d, localizable1, objArray10);
        java.lang.Object[] objArray19 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 100, "", objArray19);
        org.apache.commons.math.exception.Localizable localizable21 = functionEvaluationException20.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable24 = null;
        java.lang.Object[] objArray30 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException("hi!", objArray30);
        org.apache.commons.math.MathRuntimeException mathRuntimeException32 = new org.apache.commons.math.MathRuntimeException(localizable24, objArray30);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException33 = new org.apache.commons.math.linear.MatrixIndexException("", objArray30);
        org.apache.commons.math.MathRuntimeException mathRuntimeException34 = new org.apache.commons.math.MathRuntimeException("hi!", objArray30);
        java.lang.IllegalArgumentException illegalArgumentException35 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException(localizable21, objArray30);
        java.lang.Object[] objArray36 = null;
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException37 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable21, objArray36);
        org.apache.commons.math.linear.SingularMatrixException singularMatrixException38 = new org.apache.commons.math.linear.SingularMatrixException();
        java.lang.Object[] objArray39 = singularMatrixException38.getArguments();
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException40 = new org.apache.commons.math.linear.InvalidMatrixException(localizable21, objArray39);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) functionEvaluationException15, "org.apache.commons.math.optimization.OptimizationException: ", objArray39);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(noSuchElementException14);
        org.junit.Assert.assertNotNull(localizable21);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(illegalArgumentException35);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException37);
        org.junit.Assert.assertNotNull(objArray39);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable12 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("hi!", objArray18);
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException(localizable12, objArray18);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException21 = new org.apache.commons.math.linear.MatrixIndexException("", objArray18);
        java.util.NoSuchElementException noSuchElementException22 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("hi!", objArray18);
        boolean boolean24 = array2DRowRealMatrix7.equals((java.lang.Object) objArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix7);
        java.lang.String str26 = array2DRowRealMatrix2.toString();
        double[][] doubleArray27 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray27);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int34 = array2DRowRealMatrix33.getRowDimension();
        java.lang.String str35 = array2DRowRealMatrix33.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int39 = array2DRowRealMatrix38.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable43 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("hi!", objArray49);
        org.apache.commons.math.MathRuntimeException mathRuntimeException51 = new org.apache.commons.math.MathRuntimeException(localizable43, objArray49);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException52 = new org.apache.commons.math.linear.MatrixIndexException("", objArray49);
        java.util.NoSuchElementException noSuchElementException53 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray49);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException("hi!", objArray49);
        boolean boolean55 = array2DRowRealMatrix38.equals((java.lang.Object) objArray49);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = array2DRowRealMatrix33.multiply(array2DRowRealMatrix38);
        java.lang.String str57 = array2DRowRealMatrix33.toString();
        double[][] doubleArray58 = array2DRowRealMatrix33.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray58, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix61 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray58);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix62 = blockRealMatrix30.multiply(blockRealMatrix61);
        org.apache.commons.math.linear.RealMatrix realMatrix64 = blockRealMatrix62.scalarMultiply((double) (-1L));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(noSuchElementException22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str26.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str35.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(noSuchElementException53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str57.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(blockRealMatrix62);
        org.junit.Assert.assertNotNull(realMatrix64);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        boolean boolean5 = array2DRowRealMatrix2.equals((java.lang.Object) (byte) 0);
        int int6 = array2DRowRealMatrix2.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int10 = array2DRowRealMatrix9.getRowDimension();
        boolean boolean12 = array2DRowRealMatrix9.equals((java.lang.Object) (byte) 0);
        array2DRowRealMatrix9.luDecompose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int17 = array2DRowRealMatrix16.getRowDimension();
        boolean boolean19 = array2DRowRealMatrix16.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.copy();
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix9.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int26 = array2DRowRealMatrix25.getRowDimension();
        boolean boolean28 = array2DRowRealMatrix25.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = array2DRowRealMatrix22.add(array2DRowRealMatrix25);
        double double30 = array2DRowRealMatrix25.getNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix32 = array2DRowRealMatrix25.getRowMatrix(0);
        org.apache.commons.math.linear.RealMatrix realMatrix33 = array2DRowRealMatrix25.transpose();
        double[] doubleArray34 = new double[] {};
        double[] doubleArray41 = new double[] { (-1), (byte) 100, 0L, (-1L), (byte) 1, (-1.0f) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair43 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray34, doubleArray41, false);
        double[] doubleArray44 = vectorialPointValuePair43.getValue();
        double[] doubleArray45 = new double[] {};
        double[] doubleArray52 = new double[] { (-1), (byte) 100, 0L, (-1L), (byte) 1, (-1.0f) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair54 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray45, doubleArray52, false);
        double[] doubleArray55 = vectorialPointValuePair54.getPointRef();
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair57 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray44, doubleArray55, true);
        double[] doubleArray58 = vectorialPointValuePair57.getValueRef();
        try {
            double[] doubleArray59 = array2DRowRealMatrix25.preMultiply(doubleArray58);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix32);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray58);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable7 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("hi!", objArray13);
        org.apache.commons.math.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.MathRuntimeException(localizable7, objArray13);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException16 = new org.apache.commons.math.linear.MatrixIndexException("", objArray13);
        java.util.NoSuchElementException noSuchElementException17 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray13);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("hi!", objArray13);
        boolean boolean19 = array2DRowRealMatrix2.equals((java.lang.Object) objArray13);
        double[][] doubleArray20 = array2DRowRealMatrix2.getDataRef();
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl22 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix2, (double) 1L);
        org.apache.commons.math.linear.RealMatrix realMatrix24 = array2DRowRealMatrix2.scalarAdd((double) (short) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix26 = array2DRowRealMatrix2.scalarAdd((double) (short) 0);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor27 = null;
        try {
            double double28 = array2DRowRealMatrix2.walkInRowOrder(realMatrixChangingVisitor27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(noSuchElementException17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realMatrix24);
        org.junit.Assert.assertNotNull(realMatrix26);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setMaxIterations((-1));
        int int3 = levenbergMarquardtOptimizer0.getEvaluations();
        levenbergMarquardtOptimizer0.setOrthoTolerance((double) 10.0f);
        double double6 = levenbergMarquardtOptimizer0.getChiSquare();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        array2DRowRealMatrix2.luDecompose();
        double double6 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix7 = array2DRowRealMatrix2.copy();
        org.apache.commons.math.linear.RealMatrix realMatrix9 = array2DRowRealMatrix2.scalarAdd((double) 0.0f);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = null;
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix11 = array2DRowRealMatrix2.solve(realMatrix10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(realMatrix9);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        boolean boolean5 = array2DRowRealMatrix2.equals((java.lang.Object) (byte) 0);
        array2DRowRealMatrix2.luDecompose();
        int int7 = array2DRowRealMatrix2.getRowDimension();
        int int8 = array2DRowRealMatrix2.getRowDimension();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        array2DRowRealMatrix2.luDecompose();
        double double6 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix7 = array2DRowRealMatrix2.copy();
        java.lang.String str8 = array2DRowRealMatrix2.toString();
        try {
            double double11 = array2DRowRealMatrix2.getEntry((-1), (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (-1, 100) in a 10x10 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str8.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable12 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("hi!", objArray18);
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException(localizable12, objArray18);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException21 = new org.apache.commons.math.linear.MatrixIndexException("", objArray18);
        java.util.NoSuchElementException noSuchElementException22 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("hi!", objArray18);
        boolean boolean24 = array2DRowRealMatrix7.equals((java.lang.Object) objArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix7);
        java.lang.String str26 = array2DRowRealMatrix7.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(noSuchElementException22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str26.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.apache.commons.math.exception.Localizable localizable1 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("hi!", objArray7);
        org.apache.commons.math.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.MathRuntimeException(localizable1, objArray7);
        java.lang.RuntimeException runtimeException10 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) mathRuntimeException9);
        java.lang.Throwable[] throwableArray11 = runtimeException10.getSuppressed();
        java.io.IOException iOException12 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) runtimeException10);
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) iOException12);
        java.lang.Throwable[] throwableArray14 = iOException12.getSuppressed();
        java.lang.IllegalArgumentException illegalArgumentException15 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded", (java.lang.Object[]) throwableArray14);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(runtimeException10);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(iOException12);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(illegalArgumentException15);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getRowDimension();
        boolean boolean10 = array2DRowRealMatrix7.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix11 = array2DRowRealMatrix7.copy();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix7);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl13 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix2);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int17 = array2DRowRealMatrix16.getColumnDimension();
        double[][] doubleArray18 = array2DRowRealMatrix16.getDataRef();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix19);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int24 = array2DRowRealMatrix23.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable28 = null;
        java.lang.Object[] objArray34 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException("hi!", objArray34);
        org.apache.commons.math.MathRuntimeException mathRuntimeException36 = new org.apache.commons.math.MathRuntimeException(localizable28, objArray34);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException37 = new org.apache.commons.math.linear.MatrixIndexException("", objArray34);
        java.util.NoSuchElementException noSuchElementException38 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray34);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException("hi!", objArray34);
        boolean boolean40 = array2DRowRealMatrix23.equals((java.lang.Object) objArray34);
        double[][] doubleArray41 = array2DRowRealMatrix23.getDataRef();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix42 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix23);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(noSuchElementException38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix42);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        boolean boolean5 = array2DRowRealMatrix2.equals((java.lang.Object) (byte) 0);
        int int6 = array2DRowRealMatrix2.getColumnDimension();
        org.apache.commons.math.linear.RealMatrix realMatrix8 = array2DRowRealMatrix2.scalarAdd((double) 0L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(realMatrix8);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        java.lang.String[] strArray4 = new java.lang.String[] { "org.apache.commons.math.MathException: ", "hi!", "Array2DRowRealMatrix{}", "org.apache.commons.math.ConvergenceException: hi!" };
        java.lang.String[] strArray9 = new java.lang.String[] { "org.apache.commons.math.MathException: ", "hi!", "Array2DRowRealMatrix{}", "org.apache.commons.math.ConvergenceException: hi!" };
        java.lang.String[][] strArray10 = new java.lang.String[][] { strArray4, strArray9 };
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix11 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(strArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getRowDimension();
        boolean boolean10 = array2DRowRealMatrix7.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix11 = array2DRowRealMatrix7.copy();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix7);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int16 = array2DRowRealMatrix15.getRowDimension();
        java.lang.String str17 = array2DRowRealMatrix15.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int21 = array2DRowRealMatrix20.getRowDimension();
        boolean boolean23 = array2DRowRealMatrix20.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix24 = array2DRowRealMatrix20.copy();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix20);
        org.apache.commons.math.linear.RealMatrix realMatrix26 = array2DRowRealMatrix7.multiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix15);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl28 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix7, (double) (short) 10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int32 = array2DRowRealMatrix31.getRowDimension();
        java.lang.String str33 = array2DRowRealMatrix31.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int37 = array2DRowRealMatrix36.getRowDimension();
        boolean boolean39 = array2DRowRealMatrix36.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix40 = array2DRowRealMatrix36.copy();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = array2DRowRealMatrix31.subtract(array2DRowRealMatrix36);
        org.apache.commons.math.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix7, (org.apache.commons.math.linear.AnyMatrix) array2DRowRealMatrix41);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl44 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix41, (double) (short) 0);
        org.apache.commons.math.linear.DecompositionSolver decompositionSolver45 = lUDecompositionImpl44.getSolver();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str17.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(realMatrix24);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 10 + "'", int32 == 10);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str33.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 10 + "'", int37 == 10);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(realMatrix40);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix41);
        org.junit.Assert.assertNotNull(decompositionSolver45);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException3 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 100, "", objArray2);
        org.apache.commons.math.exception.Localizable localizable4 = functionEvaluationException3.getLocalizablePattern();
        double[] doubleArray13 = new double[] { (short) -1, 0, (byte) 10, 10, 1.0d, 0 };
        org.apache.commons.math.linear.RealMatrix realMatrix14 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray13);
        java.lang.Object[] objArray21 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray21);
        org.apache.commons.math.exception.Localizable localizable23 = null;
        org.apache.commons.math.exception.Localizable localizable26 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException("hi!", objArray32);
        org.apache.commons.math.MathRuntimeException mathRuntimeException34 = new org.apache.commons.math.MathRuntimeException(localizable26, objArray32);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException35 = new org.apache.commons.math.linear.MatrixIndexException("", objArray32);
        java.util.NoSuchElementException noSuchElementException36 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray32);
        org.apache.commons.math.MathRuntimeException mathRuntimeException37 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) mathException22, localizable23, objArray32);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException38 = new org.apache.commons.math.FunctionEvaluationException(doubleArray13, "", objArray32);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException39 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException3, (double) 1L, "Array2DRowRealMatrix{}", objArray32);
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(noSuchElementException36);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 10);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.getRowMatrix((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, 51]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable7 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("hi!", objArray13);
        org.apache.commons.math.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.MathRuntimeException(localizable7, objArray13);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException16 = new org.apache.commons.math.linear.MatrixIndexException("", objArray13);
        java.util.NoSuchElementException noSuchElementException17 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray13);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("hi!", objArray13);
        boolean boolean19 = array2DRowRealMatrix2.equals((java.lang.Object) objArray13);
        try {
            org.apache.commons.math.linear.RealVector realVector21 = array2DRowRealMatrix2.getRowVector((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index -1 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(noSuchElementException17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        boolean boolean5 = array2DRowRealMatrix2.equals((java.lang.Object) (byte) 0);
        array2DRowRealMatrix2.luDecompose();
        int int7 = array2DRowRealMatrix2.getRowDimension();
        try {
            org.apache.commons.math.linear.RealVector realVector9 = array2DRowRealMatrix2.getColumnVector((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 100 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        boolean boolean5 = array2DRowRealMatrix2.equals((java.lang.Object) (byte) 0);
        int int6 = array2DRowRealMatrix2.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int10 = array2DRowRealMatrix9.getRowDimension();
        boolean boolean12 = array2DRowRealMatrix9.equals((java.lang.Object) (byte) 0);
        array2DRowRealMatrix9.luDecompose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int17 = array2DRowRealMatrix16.getRowDimension();
        boolean boolean19 = array2DRowRealMatrix16.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.copy();
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix9.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int26 = array2DRowRealMatrix25.getRowDimension();
        boolean boolean28 = array2DRowRealMatrix25.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = array2DRowRealMatrix22.add(array2DRowRealMatrix25);
        int int30 = array2DRowRealMatrix25.getRowDimension();
        array2DRowRealMatrix25.luDecompose();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 10 + "'", int30 == 10);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        double[][] doubleArray4 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (byte) 10, 10);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException5 = new org.apache.commons.math.MaxEvaluationsExceededException(2147483647, "a {0}x{1} matrix was provided instead of a square matrix", (java.lang.Object[]) doubleArray4);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray4);
        double[][] doubleArray7 = blockRealMatrix6.getData();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException4 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 100, "", objArray3);
        org.apache.commons.math.exception.Localizable localizable5 = functionEvaluationException4.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable7 = null;
        org.apache.commons.math.exception.Localizable localizable11 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("hi!", objArray17);
        org.apache.commons.math.MathRuntimeException mathRuntimeException19 = new org.apache.commons.math.MathRuntimeException(localizable11, objArray17);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException20 = new org.apache.commons.math.linear.MatrixIndexException("", objArray17);
        java.util.NoSuchElementException noSuchElementException21 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray17);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException("hi!", objArray17);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, localizable7, objArray17);
        java.lang.UnsupportedOperationException unsupportedOperationException24 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException(localizable5, objArray17);
        java.lang.Object[] objArray28 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 100, "", objArray28);
        org.apache.commons.math.exception.Localizable localizable30 = functionEvaluationException29.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable32 = null;
        org.apache.commons.math.exception.Localizable localizable36 = null;
        java.lang.Object[] objArray42 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException("hi!", objArray42);
        org.apache.commons.math.MathRuntimeException mathRuntimeException44 = new org.apache.commons.math.MathRuntimeException(localizable36, objArray42);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException45 = new org.apache.commons.math.linear.MatrixIndexException("", objArray42);
        java.util.NoSuchElementException noSuchElementException46 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray42);
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException("hi!", objArray42);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, localizable32, objArray42);
        java.lang.UnsupportedOperationException unsupportedOperationException49 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException(localizable30, objArray42);
        org.apache.commons.math.exception.Localizable localizable52 = null;
        java.lang.Object[] objArray58 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException("hi!", objArray58);
        org.apache.commons.math.MathRuntimeException mathRuntimeException60 = new org.apache.commons.math.MathRuntimeException(localizable52, objArray58);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException61 = new org.apache.commons.math.linear.MatrixIndexException("", objArray58);
        org.apache.commons.math.MathRuntimeException mathRuntimeException62 = new org.apache.commons.math.MathRuntimeException("hi!", objArray58);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException63 = new org.apache.commons.math.MaxEvaluationsExceededException(0, localizable30, objArray58);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException64 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable5, objArray58);
        org.apache.commons.math.exception.Localizable localizable65 = null;
        java.lang.Object[] objArray71 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException72 = new org.apache.commons.math.MathException("hi!", objArray71);
        org.apache.commons.math.MathRuntimeException mathRuntimeException73 = new org.apache.commons.math.MathRuntimeException(localizable65, objArray71);
        java.lang.Object[] objArray74 = mathRuntimeException73.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException(localizable5, objArray74);
        org.apache.commons.math.exception.Localizable localizable78 = null;
        java.lang.Object[] objArray84 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException85 = new org.apache.commons.math.MathException("hi!", objArray84);
        org.apache.commons.math.MathRuntimeException mathRuntimeException86 = new org.apache.commons.math.MathRuntimeException(localizable78, objArray84);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException87 = new org.apache.commons.math.linear.MatrixIndexException("", objArray84);
        java.util.NoSuchElementException noSuchElementException88 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray84);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException89 = new org.apache.commons.math.MaxEvaluationsExceededException(1, localizable5, objArray84);
        org.apache.commons.math.exception.Localizable localizable90 = null;
        double[][] doubleArray94 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (byte) 10, 10);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException95 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("a {0}x{1} matrix was provided instead of a square matrix", (java.lang.Object[]) doubleArray94);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException96 = new org.apache.commons.math.linear.MatrixIndexException(localizable90, (java.lang.Object[]) doubleArray94);
        org.apache.commons.math.MathException mathException97 = new org.apache.commons.math.MathException(localizable5, (java.lang.Object[]) doubleArray94);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix98 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray94);
        double[][] doubleArray99 = array2DRowRealMatrix98.getDataRef();
        org.junit.Assert.assertNotNull(localizable5);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(noSuchElementException21);
        org.junit.Assert.assertNotNull(unsupportedOperationException24);
        org.junit.Assert.assertNotNull(localizable30);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(noSuchElementException46);
        org.junit.Assert.assertNotNull(unsupportedOperationException49);
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException64);
        org.junit.Assert.assertNotNull(objArray71);
        org.junit.Assert.assertNotNull(objArray74);
        org.junit.Assert.assertNotNull(objArray84);
        org.junit.Assert.assertNotNull(noSuchElementException88);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException95);
        org.junit.Assert.assertNotNull(doubleArray99);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        boolean boolean5 = array2DRowRealMatrix2.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl7 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix2, (double) 2147483647);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = lUDecompositionImpl7.getU();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(realMatrix8);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException1 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        boolean boolean5 = array2DRowRealMatrix2.equals((java.lang.Object) (byte) 0);
        int int6 = array2DRowRealMatrix2.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int10 = array2DRowRealMatrix9.getRowDimension();
        boolean boolean12 = array2DRowRealMatrix9.equals((java.lang.Object) (byte) 0);
        array2DRowRealMatrix9.luDecompose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int17 = array2DRowRealMatrix16.getRowDimension();
        boolean boolean19 = array2DRowRealMatrix16.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.copy();
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix9.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int26 = array2DRowRealMatrix25.getRowDimension();
        boolean boolean28 = array2DRowRealMatrix25.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = array2DRowRealMatrix22.add(array2DRowRealMatrix25);
        double double30 = array2DRowRealMatrix25.getNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix32 = array2DRowRealMatrix25.getRowMatrix(0);
        org.apache.commons.math.linear.RealMatrix realMatrix33 = array2DRowRealMatrix25.transpose();
        array2DRowRealMatrix25.luDecompose();
        org.apache.commons.math.linear.RealMatrix realMatrix36 = array2DRowRealMatrix25.scalarAdd((double) (-1L));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix32);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(realMatrix36);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        java.lang.Object[] objArray5 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException("hi!", objArray5);
        org.apache.commons.math.exception.Localizable localizable7 = null;
        org.apache.commons.math.exception.Localizable localizable10 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("hi!", objArray16);
        org.apache.commons.math.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.MathRuntimeException(localizable10, objArray16);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException19 = new org.apache.commons.math.linear.MatrixIndexException("", objArray16);
        java.util.NoSuchElementException noSuchElementException20 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray16);
        org.apache.commons.math.MathRuntimeException mathRuntimeException21 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) mathException6, localizable7, objArray16);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException23 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathRuntimeException21, (double) 100);
        java.lang.IllegalArgumentException illegalArgumentException24 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((java.lang.Throwable) functionEvaluationException23);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(noSuchElementException20);
        org.junit.Assert.assertNotNull(illegalArgumentException24);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        levenbergMarquardtOptimizer0.setQRRankingThreshold((double) (short) 100);
        levenbergMarquardtOptimizer0.setParRelativeTolerance((double) 2147483647);
        int int6 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        int int7 = levenbergMarquardtOptimizer0.getEvaluations();
        int int8 = levenbergMarquardtOptimizer0.getJacobianEvaluations();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        array2DRowRealMatrix2.luDecompose();
        double double6 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix8 = array2DRowRealMatrix2.getRowMatrix(0);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = array2DRowRealMatrix2.getColumnMatrix((int) (short) 1);
        int int11 = array2DRowRealMatrix2.getRowDimension();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("hi!", objArray1);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int5 = array2DRowRealMatrix4.getRowDimension();
        java.lang.String str6 = array2DRowRealMatrix4.toString();
        array2DRowRealMatrix4.luDecompose();
        double double8 = array2DRowRealMatrix4.getFrobeniusNorm();
        int int9 = array2DRowRealMatrix4.getRowDimension();
        double[][] doubleArray10 = array2DRowRealMatrix4.getData();
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math.linear.BlockRealMatrix(0, 1000, doubleArray10, false);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str6.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable12 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("hi!", objArray18);
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException(localizable12, objArray18);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException21 = new org.apache.commons.math.linear.MatrixIndexException("", objArray18);
        java.util.NoSuchElementException noSuchElementException22 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("hi!", objArray18);
        boolean boolean24 = array2DRowRealMatrix7.equals((java.lang.Object) objArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix7);
        java.lang.String str26 = array2DRowRealMatrix2.toString();
        double[][] doubleArray27 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray27);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int34 = array2DRowRealMatrix33.getRowDimension();
        java.lang.String str35 = array2DRowRealMatrix33.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int39 = array2DRowRealMatrix38.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable43 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("hi!", objArray49);
        org.apache.commons.math.MathRuntimeException mathRuntimeException51 = new org.apache.commons.math.MathRuntimeException(localizable43, objArray49);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException52 = new org.apache.commons.math.linear.MatrixIndexException("", objArray49);
        java.util.NoSuchElementException noSuchElementException53 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray49);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException("hi!", objArray49);
        boolean boolean55 = array2DRowRealMatrix38.equals((java.lang.Object) objArray49);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = array2DRowRealMatrix33.multiply(array2DRowRealMatrix38);
        java.lang.String str57 = array2DRowRealMatrix33.toString();
        double[][] doubleArray58 = array2DRowRealMatrix33.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray58, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix61 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray58);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix62 = blockRealMatrix30.multiply(blockRealMatrix61);
        double double63 = blockRealMatrix61.getFrobeniusNorm();
        org.apache.commons.math.linear.RealVector realVector65 = blockRealMatrix61.getColumnVector(0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix68 = blockRealMatrix61.createMatrix(36, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(noSuchElementException22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str26.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str35.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(noSuchElementException53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str57.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(blockRealMatrix62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(realVector65);
        org.junit.Assert.assertNotNull(blockRealMatrix68);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException1 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 0);
        java.lang.String str2 = maxEvaluationsExceededException1.toString();
        java.io.IOException iOException3 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) maxEvaluationsExceededException1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded" + "'", str2.equals("org.apache.commons.math.MaxEvaluationsExceededException: maximal number of evaluations (0) exceeded"));
        org.junit.Assert.assertNotNull(iOException3);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        boolean boolean5 = array2DRowRealMatrix2.equals((java.lang.Object) (byte) 0);
        int int6 = array2DRowRealMatrix2.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int10 = array2DRowRealMatrix9.getRowDimension();
        boolean boolean12 = array2DRowRealMatrix9.equals((java.lang.Object) (byte) 0);
        array2DRowRealMatrix9.luDecompose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int17 = array2DRowRealMatrix16.getRowDimension();
        boolean boolean19 = array2DRowRealMatrix16.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.copy();
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix9.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int26 = array2DRowRealMatrix25.getRowDimension();
        boolean boolean28 = array2DRowRealMatrix25.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = array2DRowRealMatrix22.add(array2DRowRealMatrix25);
        double double30 = array2DRowRealMatrix25.getNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix32 = array2DRowRealMatrix25.getRowMatrix(0);
        org.apache.commons.math.linear.RealMatrix realMatrix34 = array2DRowRealMatrix25.scalarAdd((double) 10);
        double[] doubleArray36 = null;
        try {
            array2DRowRealMatrix25.setColumn(2147483647, doubleArray36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 2,147,483,647 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix32);
        org.junit.Assert.assertNotNull(realMatrix34);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        array2DRowRealMatrix2.luDecompose();
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.copy();
        try {
            double[] doubleArray8 = array2DRowRealMatrix2.getRow((int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 52 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(realMatrix6);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable12 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("hi!", objArray18);
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException(localizable12, objArray18);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException21 = new org.apache.commons.math.linear.MatrixIndexException("", objArray18);
        java.util.NoSuchElementException noSuchElementException22 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("hi!", objArray18);
        boolean boolean24 = array2DRowRealMatrix7.equals((java.lang.Object) objArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix7);
        java.lang.String str26 = array2DRowRealMatrix2.toString();
        double[][] doubleArray27 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray27);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int34 = array2DRowRealMatrix33.getRowDimension();
        java.lang.String str35 = array2DRowRealMatrix33.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int39 = array2DRowRealMatrix38.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable43 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("hi!", objArray49);
        org.apache.commons.math.MathRuntimeException mathRuntimeException51 = new org.apache.commons.math.MathRuntimeException(localizable43, objArray49);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException52 = new org.apache.commons.math.linear.MatrixIndexException("", objArray49);
        java.util.NoSuchElementException noSuchElementException53 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray49);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException("hi!", objArray49);
        boolean boolean55 = array2DRowRealMatrix38.equals((java.lang.Object) objArray49);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = array2DRowRealMatrix33.multiply(array2DRowRealMatrix38);
        java.lang.String str57 = array2DRowRealMatrix33.toString();
        double[][] doubleArray58 = array2DRowRealMatrix33.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray58, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix61 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray58);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix62 = blockRealMatrix30.multiply(blockRealMatrix61);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix64 = blockRealMatrix61.getColumnMatrix(0);
        try {
            double[] doubleArray66 = blockRealMatrix61.getRow(100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(noSuchElementException22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str26.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str35.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(noSuchElementException53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str57.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(blockRealMatrix62);
        org.junit.Assert.assertNotNull(blockRealMatrix64);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10);
        int int2 = maxIterationsExceededException1.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray7 = new double[] { (-1), (byte) 100, 0L, (-1L), (byte) 1, (-1.0f) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair9 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray0, doubleArray7, false);
        double[] doubleArray10 = vectorialPointValuePair9.getPoint();
        org.apache.commons.math.exception.Localizable localizable11 = null;
        org.apache.commons.math.exception.Localizable localizable12 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("hi!", objArray18);
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException(localizable12, objArray18);
        java.lang.RuntimeException runtimeException21 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) mathRuntimeException20);
        java.lang.Throwable[] throwableArray22 = runtimeException21.getSuppressed();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException23 = new org.apache.commons.math.FunctionEvaluationException(doubleArray10, localizable11, (java.lang.Object[]) throwableArray22);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(runtimeException21);
        org.junit.Assert.assertNotNull(throwableArray22);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        boolean boolean5 = array2DRowRealMatrix2.equals((java.lang.Object) (byte) 0);
        int int6 = array2DRowRealMatrix2.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int10 = array2DRowRealMatrix9.getRowDimension();
        boolean boolean12 = array2DRowRealMatrix9.equals((java.lang.Object) (byte) 0);
        array2DRowRealMatrix9.luDecompose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int17 = array2DRowRealMatrix16.getRowDimension();
        boolean boolean19 = array2DRowRealMatrix16.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.copy();
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix9.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int26 = array2DRowRealMatrix25.getRowDimension();
        java.lang.String str27 = array2DRowRealMatrix25.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int31 = array2DRowRealMatrix30.getRowDimension();
        boolean boolean33 = array2DRowRealMatrix30.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix34 = array2DRowRealMatrix30.copy();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = array2DRowRealMatrix25.subtract(array2DRowRealMatrix30);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = array2DRowRealMatrix16.multiply(array2DRowRealMatrix35);
        org.apache.commons.math.linear.RealMatrix realMatrix38 = array2DRowRealMatrix36.getColumnMatrix((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str27.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 10 + "'", int31 == 10);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(realMatrix34);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix35);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix36);
        org.junit.Assert.assertNotNull(realMatrix38);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        java.lang.Object[] objArray5 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException("hi!", objArray5);
        org.apache.commons.math.exception.Localizable localizable7 = null;
        org.apache.commons.math.exception.Localizable localizable10 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("hi!", objArray16);
        org.apache.commons.math.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.MathRuntimeException(localizable10, objArray16);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException19 = new org.apache.commons.math.linear.MatrixIndexException("", objArray16);
        java.util.NoSuchElementException noSuchElementException20 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray16);
        org.apache.commons.math.MathRuntimeException mathRuntimeException21 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) mathException6, localizable7, objArray16);
        org.apache.commons.math.optimization.OptimizationException optimizationException22 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) mathRuntimeException21);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathRuntimeException21);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(noSuchElementException20);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.apache.commons.math.linear.AnyMatrix anyMatrix0 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.checkSubMatrixIndex(anyMatrix0, 36, 0, 1000, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable12 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("hi!", objArray18);
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException(localizable12, objArray18);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException21 = new org.apache.commons.math.linear.MatrixIndexException("", objArray18);
        java.util.NoSuchElementException noSuchElementException22 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("hi!", objArray18);
        boolean boolean24 = array2DRowRealMatrix7.equals((java.lang.Object) objArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix7);
        java.lang.String str26 = array2DRowRealMatrix2.toString();
        double[][] doubleArray27 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray27);
        double double31 = blockRealMatrix30.getNorm();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor32 = null;
        try {
            double double37 = blockRealMatrix30.walkInOptimizedOrder(realMatrixChangingVisitor32, (int) (short) 1, 0, (int) (short) 1, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: initial row 1 after final row 0");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(noSuchElementException22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str26.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException4 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 100, "", objArray3);
        org.apache.commons.math.exception.Localizable localizable5 = functionEvaluationException4.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable7 = null;
        org.apache.commons.math.exception.Localizable localizable11 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("hi!", objArray17);
        org.apache.commons.math.MathRuntimeException mathRuntimeException19 = new org.apache.commons.math.MathRuntimeException(localizable11, objArray17);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException20 = new org.apache.commons.math.linear.MatrixIndexException("", objArray17);
        java.util.NoSuchElementException noSuchElementException21 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray17);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException("hi!", objArray17);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, localizable7, objArray17);
        java.lang.UnsupportedOperationException unsupportedOperationException24 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException(localizable5, objArray17);
        java.lang.Object[] objArray28 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 100, "", objArray28);
        org.apache.commons.math.exception.Localizable localizable30 = functionEvaluationException29.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable32 = null;
        org.apache.commons.math.exception.Localizable localizable36 = null;
        java.lang.Object[] objArray42 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException("hi!", objArray42);
        org.apache.commons.math.MathRuntimeException mathRuntimeException44 = new org.apache.commons.math.MathRuntimeException(localizable36, objArray42);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException45 = new org.apache.commons.math.linear.MatrixIndexException("", objArray42);
        java.util.NoSuchElementException noSuchElementException46 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray42);
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException("hi!", objArray42);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, localizable32, objArray42);
        java.lang.UnsupportedOperationException unsupportedOperationException49 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException(localizable30, objArray42);
        org.apache.commons.math.exception.Localizable localizable52 = null;
        java.lang.Object[] objArray58 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException("hi!", objArray58);
        org.apache.commons.math.MathRuntimeException mathRuntimeException60 = new org.apache.commons.math.MathRuntimeException(localizable52, objArray58);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException61 = new org.apache.commons.math.linear.MatrixIndexException("", objArray58);
        org.apache.commons.math.MathRuntimeException mathRuntimeException62 = new org.apache.commons.math.MathRuntimeException("hi!", objArray58);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException63 = new org.apache.commons.math.MaxEvaluationsExceededException(0, localizable30, objArray58);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException64 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable5, objArray58);
        org.apache.commons.math.exception.Localizable localizable65 = null;
        java.lang.Object[] objArray71 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException72 = new org.apache.commons.math.MathException("hi!", objArray71);
        org.apache.commons.math.MathRuntimeException mathRuntimeException73 = new org.apache.commons.math.MathRuntimeException(localizable65, objArray71);
        java.lang.Object[] objArray74 = mathRuntimeException73.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException(localizable5, objArray74);
        org.apache.commons.math.exception.Localizable localizable78 = null;
        java.lang.Object[] objArray84 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException85 = new org.apache.commons.math.MathException("hi!", objArray84);
        org.apache.commons.math.MathRuntimeException mathRuntimeException86 = new org.apache.commons.math.MathRuntimeException(localizable78, objArray84);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException87 = new org.apache.commons.math.linear.MatrixIndexException("", objArray84);
        java.util.NoSuchElementException noSuchElementException88 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray84);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException89 = new org.apache.commons.math.MaxEvaluationsExceededException(1, localizable5, objArray84);
        org.apache.commons.math.exception.Localizable localizable90 = null;
        double[][] doubleArray94 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (byte) 10, 10);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException95 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("a {0}x{1} matrix was provided instead of a square matrix", (java.lang.Object[]) doubleArray94);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException96 = new org.apache.commons.math.linear.MatrixIndexException(localizable90, (java.lang.Object[]) doubleArray94);
        org.apache.commons.math.MathException mathException97 = new org.apache.commons.math.MathException(localizable5, (java.lang.Object[]) doubleArray94);
        org.apache.commons.math.linear.BigMatrix bigMatrix98 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(doubleArray94);
        org.junit.Assert.assertNotNull(localizable5);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(noSuchElementException21);
        org.junit.Assert.assertNotNull(unsupportedOperationException24);
        org.junit.Assert.assertNotNull(localizable30);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(noSuchElementException46);
        org.junit.Assert.assertNotNull(unsupportedOperationException49);
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException64);
        org.junit.Assert.assertNotNull(objArray71);
        org.junit.Assert.assertNotNull(objArray74);
        org.junit.Assert.assertNotNull(objArray84);
        org.junit.Assert.assertNotNull(noSuchElementException88);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException95);
        org.junit.Assert.assertNotNull(bigMatrix98);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray7 = new double[] { (-1), (byte) 100, 0L, (-1L), (byte) 1, (-1.0f) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair9 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray0, doubleArray7, false);
        double[] doubleArray10 = vectorialPointValuePair9.getPoint();
        double[] doubleArray11 = vectorialPointValuePair9.getValue();
        double[] doubleArray12 = new double[] {};
        double[] doubleArray19 = new double[] { (-1), (byte) 100, 0L, (-1L), (byte) 1, (-1.0f) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair21 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray12, doubleArray19, false);
        org.apache.commons.math.exception.Localizable localizable23 = null;
        org.apache.commons.math.exception.Localizable localizable26 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException("hi!", objArray32);
        org.apache.commons.math.MathRuntimeException mathRuntimeException34 = new org.apache.commons.math.MathRuntimeException(localizable26, objArray32);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException35 = new org.apache.commons.math.linear.MatrixIndexException("", objArray32);
        java.util.NoSuchElementException noSuchElementException36 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray32);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException37 = new org.apache.commons.math.FunctionEvaluationException(1.0d, localizable23, objArray32);
        double[] doubleArray38 = functionEvaluationException37.getArgument();
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair40 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray12, doubleArray38, true);
        double[] doubleArray41 = vectorialPointValuePair40.getValueRef();
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair42 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray11, doubleArray41);
        org.apache.commons.math.linear.RealMatrix realMatrix43 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(doubleArray41);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl45 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix43, (double) (-1.0f));
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(noSuchElementException36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realMatrix43);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException3 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 100, "", objArray2);
        org.apache.commons.math.exception.Localizable localizable4 = functionEvaluationException3.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable5 = null;
        org.apache.commons.math.exception.Localizable localizable8 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("hi!", objArray14);
        org.apache.commons.math.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.MathRuntimeException(localizable8, objArray14);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException17 = new org.apache.commons.math.linear.MatrixIndexException("", objArray14);
        org.apache.commons.math.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.MathRuntimeException("hi!", objArray14);
        double[] doubleArray20 = new double[] { ' ' };
        org.apache.commons.math.exception.Localizable localizable21 = null;
        org.apache.commons.math.exception.Localizable localizable24 = null;
        java.lang.Object[] objArray30 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException("hi!", objArray30);
        org.apache.commons.math.MathRuntimeException mathRuntimeException32 = new org.apache.commons.math.MathRuntimeException(localizable24, objArray30);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException33 = new org.apache.commons.math.linear.MatrixIndexException("", objArray30);
        java.util.NoSuchElementException noSuchElementException34 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray30);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException35 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathRuntimeException18, doubleArray20, localizable21, objArray30);
        org.apache.commons.math.MathRuntimeException mathRuntimeException36 = new org.apache.commons.math.MathRuntimeException(localizable5, objArray30);
        java.lang.ArithmeticException arithmeticException37 = org.apache.commons.math.MathRuntimeException.createArithmeticException(localizable4, objArray30);
        org.apache.commons.math.exception.Localizable localizable40 = null;
        java.lang.Object[] objArray45 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException46 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 100, "", objArray45);
        org.apache.commons.math.exception.Localizable localizable47 = functionEvaluationException46.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable49 = null;
        org.apache.commons.math.exception.Localizable localizable53 = null;
        java.lang.Object[] objArray59 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException("hi!", objArray59);
        org.apache.commons.math.MathRuntimeException mathRuntimeException61 = new org.apache.commons.math.MathRuntimeException(localizable53, objArray59);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException62 = new org.apache.commons.math.linear.MatrixIndexException("", objArray59);
        java.util.NoSuchElementException noSuchElementException63 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray59);
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException("hi!", objArray59);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException65 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, localizable49, objArray59);
        java.lang.UnsupportedOperationException unsupportedOperationException66 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException(localizable47, objArray59);
        org.apache.commons.math.exception.Localizable localizable69 = null;
        java.lang.Object[] objArray75 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException("hi!", objArray75);
        org.apache.commons.math.MathRuntimeException mathRuntimeException77 = new org.apache.commons.math.MathRuntimeException(localizable69, objArray75);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException78 = new org.apache.commons.math.linear.MatrixIndexException("", objArray75);
        org.apache.commons.math.MathRuntimeException mathRuntimeException79 = new org.apache.commons.math.MathRuntimeException("hi!", objArray75);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException80 = new org.apache.commons.math.MaxEvaluationsExceededException(0, localizable47, objArray75);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException81 = new org.apache.commons.math.linear.InvalidMatrixException("", objArray75);
        org.apache.commons.math.MathRuntimeException mathRuntimeException82 = new org.apache.commons.math.MathRuntimeException(localizable40, objArray75);
        org.apache.commons.math.MathException mathException83 = new org.apache.commons.math.MathException("Array2DRowRealMatrix{}", objArray75);
        org.apache.commons.math.optimization.OptimizationException optimizationException84 = new org.apache.commons.math.optimization.OptimizationException("java.io.IOException: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH", objArray75);
        java.lang.ArithmeticException arithmeticException85 = org.apache.commons.math.MathRuntimeException.createArithmeticException(localizable4, objArray75);
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(noSuchElementException34);
        org.junit.Assert.assertNotNull(arithmeticException37);
        org.junit.Assert.assertNotNull(localizable47);
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNotNull(noSuchElementException63);
        org.junit.Assert.assertNotNull(unsupportedOperationException66);
        org.junit.Assert.assertNotNull(objArray75);
        org.junit.Assert.assertNotNull(arithmeticException85);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getRowDimension();
        boolean boolean10 = array2DRowRealMatrix7.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix11 = array2DRowRealMatrix7.copy();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix7);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl13 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix2);
        double double14 = lUDecompositionImpl13.getDeterminant();
        org.apache.commons.math.linear.RealMatrix realMatrix15 = lUDecompositionImpl13.getL();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNull(realMatrix15);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        levenbergMarquardtOptimizer0.setQRRankingThreshold((double) (short) 100);
        levenbergMarquardtOptimizer0.setParRelativeTolerance((double) 2147483647);
        int int6 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        levenbergMarquardtOptimizer0.setOrthoTolerance((double) 1000);
        int int9 = levenbergMarquardtOptimizer0.getMaxIterations();
        int int10 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        int int11 = levenbergMarquardtOptimizer0.getIterations();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1000 + "'", int9 == 1000);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable12 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("hi!", objArray18);
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException(localizable12, objArray18);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException21 = new org.apache.commons.math.linear.MatrixIndexException("", objArray18);
        java.util.NoSuchElementException noSuchElementException22 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("hi!", objArray18);
        boolean boolean24 = array2DRowRealMatrix7.equals((java.lang.Object) objArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix7);
        java.lang.String str26 = array2DRowRealMatrix2.toString();
        double[][] doubleArray27 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray27);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int34 = array2DRowRealMatrix33.getRowDimension();
        java.lang.String str35 = array2DRowRealMatrix33.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int39 = array2DRowRealMatrix38.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable43 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("hi!", objArray49);
        org.apache.commons.math.MathRuntimeException mathRuntimeException51 = new org.apache.commons.math.MathRuntimeException(localizable43, objArray49);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException52 = new org.apache.commons.math.linear.MatrixIndexException("", objArray49);
        java.util.NoSuchElementException noSuchElementException53 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray49);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException("hi!", objArray49);
        boolean boolean55 = array2DRowRealMatrix38.equals((java.lang.Object) objArray49);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = array2DRowRealMatrix33.multiply(array2DRowRealMatrix38);
        java.lang.String str57 = array2DRowRealMatrix33.toString();
        double[][] doubleArray58 = array2DRowRealMatrix33.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray58, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix61 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray58);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix62 = blockRealMatrix30.multiply(blockRealMatrix61);
        double double63 = blockRealMatrix61.getFrobeniusNorm();
        org.apache.commons.math.linear.RealVector realVector65 = blockRealMatrix61.getColumnVector(0);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        array2DRowRealMatrix68.luDecompose();
        double[][] doubleArray70 = array2DRowRealMatrix68.getData();
        try {
            blockRealMatrix61.setSubMatrix(doubleArray70, (int) '4', (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 52 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(noSuchElementException22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str26.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str35.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(noSuchElementException53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str57.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(blockRealMatrix62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(realVector65);
        org.junit.Assert.assertNotNull(doubleArray70);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int7 = array2DRowRealMatrix6.getColumnDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix8);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        boolean boolean5 = array2DRowRealMatrix2.equals((java.lang.Object) (byte) 0);
        int int6 = array2DRowRealMatrix2.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int10 = array2DRowRealMatrix9.getRowDimension();
        boolean boolean12 = array2DRowRealMatrix9.equals((java.lang.Object) (byte) 0);
        array2DRowRealMatrix9.luDecompose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int17 = array2DRowRealMatrix16.getRowDimension();
        boolean boolean19 = array2DRowRealMatrix16.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.copy();
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix9.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int26 = array2DRowRealMatrix25.getRowDimension();
        boolean boolean28 = array2DRowRealMatrix25.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = array2DRowRealMatrix22.add(array2DRowRealMatrix25);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor30 = null;
        try {
            double double35 = array2DRowRealMatrix22.walkInOptimizedOrder(realMatrixPreservingVisitor30, 10, (int) (short) 0, (-1), (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 10 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix29);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        boolean boolean5 = array2DRowRealMatrix2.equals((java.lang.Object) (byte) 0);
        int int6 = array2DRowRealMatrix2.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int10 = array2DRowRealMatrix9.getRowDimension();
        boolean boolean12 = array2DRowRealMatrix9.equals((java.lang.Object) (byte) 0);
        array2DRowRealMatrix9.luDecompose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int17 = array2DRowRealMatrix16.getRowDimension();
        boolean boolean19 = array2DRowRealMatrix16.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.copy();
        org.apache.commons.math.linear.RealMatrix realMatrix21 = array2DRowRealMatrix9.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int26 = array2DRowRealMatrix25.getRowDimension();
        boolean boolean28 = array2DRowRealMatrix25.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = array2DRowRealMatrix22.add(array2DRowRealMatrix25);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int33 = array2DRowRealMatrix32.getRowDimension();
        boolean boolean35 = array2DRowRealMatrix32.equals((java.lang.Object) (byte) 0);
        int int36 = array2DRowRealMatrix32.getRowDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int40 = array2DRowRealMatrix39.getRowDimension();
        boolean boolean42 = array2DRowRealMatrix39.equals((java.lang.Object) (byte) 0);
        array2DRowRealMatrix39.luDecompose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int47 = array2DRowRealMatrix46.getRowDimension();
        boolean boolean49 = array2DRowRealMatrix46.equals((java.lang.Object) (byte) 0);
        org.apache.commons.math.linear.RealMatrix realMatrix50 = array2DRowRealMatrix46.copy();
        org.apache.commons.math.linear.RealMatrix realMatrix51 = array2DRowRealMatrix39.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix46);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix52 = array2DRowRealMatrix32.subtract(array2DRowRealMatrix46);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = array2DRowRealMatrix29.multiply(array2DRowRealMatrix46);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor54 = null;
        try {
            double double55 = array2DRowRealMatrix46.walkInRowOrder(realMatrixPreservingVisitor54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix29);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 10 + "'", int33 == 10);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 10 + "'", int40 == 10);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 10 + "'", int47 == 10);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(realMatrix50);
        org.junit.Assert.assertNotNull(realMatrix51);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix52);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix53);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable12 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("hi!", objArray18);
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException(localizable12, objArray18);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException21 = new org.apache.commons.math.linear.MatrixIndexException("", objArray18);
        java.util.NoSuchElementException noSuchElementException22 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("hi!", objArray18);
        boolean boolean24 = array2DRowRealMatrix7.equals((java.lang.Object) objArray18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix7);
        java.lang.String str26 = array2DRowRealMatrix2.toString();
        double[][] doubleArray27 = array2DRowRealMatrix2.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray27);
        org.apache.commons.math.linear.RealVector realVector32 = blockRealMatrix30.getColumnVector((int) (byte) 0);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix34 = blockRealMatrix30.getColumnMatrix(52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: column index 52 out of allowed range [0, 9]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(noSuchElementException22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str26.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realVector32);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray7 = new double[] { (-1), (byte) 100, 0L, (-1L), (byte) 1, (-1.0f) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair9 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray0, doubleArray7, false);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray17 = new double[] { (-1), (byte) 100, 0L, (-1L), (byte) 1, (-1.0f) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair19 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray10, doubleArray17, false);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair20 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray7, doubleArray10);
        double[] doubleArray21 = vectorialPointValuePair20.getValueRef();
        double[] doubleArray22 = vectorialPointValuePair20.getPoint();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int27 = array2DRowRealMatrix26.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable31 = null;
        java.lang.Object[] objArray37 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException("hi!", objArray37);
        org.apache.commons.math.MathRuntimeException mathRuntimeException39 = new org.apache.commons.math.MathRuntimeException(localizable31, objArray37);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException40 = new org.apache.commons.math.linear.MatrixIndexException("", objArray37);
        java.util.NoSuchElementException noSuchElementException41 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray37);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException("hi!", objArray37);
        boolean boolean43 = array2DRowRealMatrix26.equals((java.lang.Object) objArray37);
        double[][] doubleArray44 = array2DRowRealMatrix26.getDataRef();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray44, true);
        double[][] doubleArray47 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray44);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException48 = new org.apache.commons.math.FunctionEvaluationException(doubleArray22, "org.apache.commons.math.MathException: ", (java.lang.Object[]) doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(noSuchElementException41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getRowDimension();
        java.lang.String str4 = array2DRowRealMatrix2.toString();
        array2DRowRealMatrix2.luDecompose();
        double double6 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix8 = array2DRowRealMatrix2.getRowMatrix(0);
        double double9 = array2DRowRealMatrix2.getDeterminant();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor10 = null;
        try {
            double double11 = array2DRowRealMatrix2.walkInOptimizedOrder(realMatrixChangingVisitor10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str4.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker2 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker((double) ' ', (double) (byte) -1);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        java.lang.Throwable throwable0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray8 = new double[] { (-1), (byte) 100, 0L, (-1L), (byte) 1, (-1.0f) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair10 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray1, doubleArray8, false);
        double[] doubleArray11 = vectorialPointValuePair10.getValue();
        double[] doubleArray12 = vectorialPointValuePair10.getPointRef();
        java.lang.Throwable throwable14 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException(throwable14, 1.0d);
        org.apache.commons.math.exception.Localizable localizable17 = null;
        org.apache.commons.math.exception.Localizable localizable19 = null;
        org.apache.commons.math.exception.Localizable localizable23 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException("hi!", objArray29);
        org.apache.commons.math.MathRuntimeException mathRuntimeException31 = new org.apache.commons.math.MathRuntimeException(localizable23, objArray29);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException32 = new org.apache.commons.math.linear.MatrixIndexException("", objArray29);
        java.util.NoSuchElementException noSuchElementException33 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray29);
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException("hi!", objArray29);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, localizable19, objArray29);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) functionEvaluationException16, localizable17, objArray29);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException37 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray12, "hi!", objArray29);
        double[][] doubleArray42 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (byte) 10, 10);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException43 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("a {0}x{1} matrix was provided instead of a square matrix", (java.lang.Object[]) doubleArray42);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException(doubleArray12, "", (java.lang.Object[]) doubleArray42);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException45 = new org.apache.commons.math.FunctionEvaluationException(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(noSuchElementException33);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException43);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        levenbergMarquardtOptimizer0.setQRRankingThreshold((double) (short) 100);
        levenbergMarquardtOptimizer0.setParRelativeTolerance((double) 2147483647);
        int int6 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        levenbergMarquardtOptimizer0.setParRelativeTolerance((double) (byte) 10);
        double double9 = levenbergMarquardtOptimizer0.getRMS();
        int int10 = levenbergMarquardtOptimizer0.getIterations();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable7 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("hi!", objArray13);
        org.apache.commons.math.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.MathRuntimeException(localizable7, objArray13);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException16 = new org.apache.commons.math.linear.MatrixIndexException("", objArray13);
        java.util.NoSuchElementException noSuchElementException17 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray13);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("hi!", objArray13);
        boolean boolean19 = array2DRowRealMatrix2.equals((java.lang.Object) objArray13);
        double[][] doubleArray20 = array2DRowRealMatrix2.getDataRef();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20, true);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor23 = null;
        try {
            double double24 = array2DRowRealMatrix22.walkInRowOrder(realMatrixChangingVisitor23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(noSuchElementException17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 10);
        org.apache.commons.math.linear.RealMatrix realMatrix4 = blockRealMatrix2.scalarMultiply(0.0d);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int8 = array2DRowRealMatrix7.getRowDimension();
        java.lang.String str9 = array2DRowRealMatrix7.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int13 = array2DRowRealMatrix12.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable17 = null;
        java.lang.Object[] objArray23 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("hi!", objArray23);
        org.apache.commons.math.MathRuntimeException mathRuntimeException25 = new org.apache.commons.math.MathRuntimeException(localizable17, objArray23);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException26 = new org.apache.commons.math.linear.MatrixIndexException("", objArray23);
        java.util.NoSuchElementException noSuchElementException27 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray23);
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException("hi!", objArray23);
        boolean boolean29 = array2DRowRealMatrix12.equals((java.lang.Object) objArray23);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = array2DRowRealMatrix7.multiply(array2DRowRealMatrix12);
        java.lang.String str31 = array2DRowRealMatrix7.toString();
        double[][] doubleArray32 = array2DRowRealMatrix7.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray32, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray32);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int39 = array2DRowRealMatrix38.getRowDimension();
        java.lang.String str40 = array2DRowRealMatrix38.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int44 = array2DRowRealMatrix43.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable48 = null;
        java.lang.Object[] objArray54 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException("hi!", objArray54);
        org.apache.commons.math.MathRuntimeException mathRuntimeException56 = new org.apache.commons.math.MathRuntimeException(localizable48, objArray54);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException57 = new org.apache.commons.math.linear.MatrixIndexException("", objArray54);
        java.util.NoSuchElementException noSuchElementException58 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray54);
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException("hi!", objArray54);
        boolean boolean60 = array2DRowRealMatrix43.equals((java.lang.Object) objArray54);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix61 = array2DRowRealMatrix38.multiply(array2DRowRealMatrix43);
        java.lang.String str62 = array2DRowRealMatrix38.toString();
        double[][] doubleArray63 = array2DRowRealMatrix38.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray63, false);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix66 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray63);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix67 = blockRealMatrix35.multiply(blockRealMatrix66);
        double double68 = blockRealMatrix66.getFrobeniusNorm();
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix69 = blockRealMatrix2.add(blockRealMatrix66);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(realMatrix4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str9.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(noSuchElementException27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str31.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str40.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 10 + "'", int44 == 10);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(noSuchElementException58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix61);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str62.equals("Array2DRowRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(blockRealMatrix67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        java.lang.String[][] strArray0 = new java.lang.String[][] {};
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix1 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(strArray0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int3 = array2DRowRealMatrix2.getColumnDimension();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor4 = null;
        try {
            double double5 = array2DRowRealMatrix2.walkInOptimizedOrder(realMatrixChangingVisitor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        double[] doubleArray1 = new double[] { Double.NaN };
        double[] doubleArray3 = new double[] { Double.NaN };
        double[] doubleArray5 = new double[] { Double.NaN };
        double[] doubleArray7 = new double[] { Double.NaN };
        double[][] doubleArray8 = new double[][] { doubleArray1, doubleArray3, doubleArray5, doubleArray7 };
        double[][] doubleArray9 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray8);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray8, true);
        try {
            array2DRowRealMatrix11.setEntry((int) (short) 100, 0, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (100, 0) in a 4x1 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        levenbergMarquardtOptimizer0.setQRRankingThreshold((double) (short) 100);
        levenbergMarquardtOptimizer0.setParRelativeTolerance((double) 2147483647);
        int int6 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        levenbergMarquardtOptimizer0.setParRelativeTolerance((double) (byte) 10);
        levenbergMarquardtOptimizer0.setOrthoTolerance((double) 10);
        levenbergMarquardtOptimizer0.setParRelativeTolerance((double) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.apache.commons.math.exception.Localizable localizable0 = null;
        org.apache.commons.math.exception.Localizable localizable3 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("hi!", objArray9);
        org.apache.commons.math.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.MathRuntimeException(localizable3, objArray9);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException12 = new org.apache.commons.math.linear.MatrixIndexException("", objArray9);
        org.apache.commons.math.MathRuntimeException mathRuntimeException13 = new org.apache.commons.math.MathRuntimeException("hi!", objArray9);
        double[] doubleArray15 = new double[] { ' ' };
        org.apache.commons.math.exception.Localizable localizable16 = null;
        org.apache.commons.math.exception.Localizable localizable19 = null;
        java.lang.Object[] objArray25 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException("hi!", objArray25);
        org.apache.commons.math.MathRuntimeException mathRuntimeException27 = new org.apache.commons.math.MathRuntimeException(localizable19, objArray25);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException28 = new org.apache.commons.math.linear.MatrixIndexException("", objArray25);
        java.util.NoSuchElementException noSuchElementException29 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray25);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException30 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathRuntimeException13, doubleArray15, localizable16, objArray25);
        org.apache.commons.math.MathRuntimeException mathRuntimeException31 = new org.apache.commons.math.MathRuntimeException(localizable0, objArray25);
        java.lang.Object[] objArray32 = mathRuntimeException31.getArguments();
        java.lang.Object[] objArray33 = mathRuntimeException31.getArguments();
        double[] doubleArray34 = new double[] {};
        double[] doubleArray41 = new double[] { (-1), (byte) 100, 0L, (-1L), (byte) 1, (-1.0f) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair43 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray34, doubleArray41, false);
        double[] doubleArray44 = vectorialPointValuePair43.getPoint();
        double[] doubleArray45 = vectorialPointValuePair43.getValue();
        org.apache.commons.math.exception.Localizable localizable46 = null;
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 10);
        int int50 = array2DRowRealMatrix49.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable54 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] { (-1), (short) 0, (short) 1, 0 };
        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException("hi!", objArray60);
        org.apache.commons.math.MathRuntimeException mathRuntimeException62 = new org.apache.commons.math.MathRuntimeException(localizable54, objArray60);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException63 = new org.apache.commons.math.linear.MatrixIndexException("", objArray60);
        java.util.NoSuchElementException noSuchElementException64 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("", objArray60);
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException("hi!", objArray60);
        boolean boolean66 = array2DRowRealMatrix49.equals((java.lang.Object) objArray60);
        double[][] doubleArray67 = array2DRowRealMatrix49.getDataRef();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray67, true);
        double[][] doubleArray70 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray67);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException71 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathRuntimeException31, doubleArray45, localizable46, (java.lang.Object[]) doubleArray70);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(noSuchElementException29);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 10 + "'", int50 == 10);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(noSuchElementException64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray70);
    }
}

