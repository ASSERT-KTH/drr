import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test001");
        double double2 = org.apache.commons.math.util.FastMath.atan2(100.0d, 0.7249085520219886d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5635473682486538d + "'", double2 == 1.5635473682486538d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test002");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, (-37), (-755673343));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test003");
        double double1 = org.apache.commons.math.util.FastMath.abs(6.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.0d + "'", double1 == 6.0d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test004");
        double double1 = org.apache.commons.math.util.FastMath.ceil(5.622625746075033E67d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.622625746075033E67d + "'", double1 == 5.622625746075033E67d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test005");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.42404354048E11d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.42404354048E11d + "'", double1 == 1.42404354048E11d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test006");
        int int2 = org.apache.commons.math.util.FastMath.max((-1080582108), 779127710);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 779127710 + "'", int2 == 779127710);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test007");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(212.75275683459444d, 0, (-1105975869));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test008");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 99.50000000000001d, (java.lang.Number) 2.993222846126381d, (int) (byte) 0, orderDirection9, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 141.43549766589715d, (java.lang.Number) 3500.0f, (-1352038911), orderDirection9, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-2.4492935982947064E-16d), (java.lang.Number) 1L, 888019239, orderDirection9, false);
        java.lang.Number number16 = nonMonotonousSequenceException15.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 1L + "'", number16.equals(1L));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test009");
        double double1 = org.apache.commons.math.util.FastMath.acos(1882560.5211597665d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test010");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 1407088129);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.384185791015625E-7d + "'", double1 == 2.384185791015625E-7d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test011");
        int int1 = org.apache.commons.math.util.FastMath.abs(913450316);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 913450316 + "'", int1 == 913450316);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test012");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.0907187537628569d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9440892412430648d + "'", double1 == 0.9440892412430648d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test013");
        long long2 = org.apache.commons.math.util.FastMath.min(1162674021347622912L, (long) 32);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test014");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-0.10491011977356592d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3877787807814457E-17d + "'", double1 == 1.3877787807814457E-17d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test015");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 2.718281828459045d);
        double[] doubleArray24 = new double[] { 888019042, (-42L), 1904.9409439665053d };
        double[] doubleArray31 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, (double) (-1.0f));
        double[] doubleArray40 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, (double) (-1.0f));
        double[] doubleArray49 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, (double) (-1.0f));
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray49);
        double[] doubleArray59 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray59, (double) (-1.0f));
        double double62 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray49, doubleArray59);
        double[] doubleArray64 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, (double) (short) 1);
        double double65 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray49);
        double[] doubleArray67 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, (double) 1L);
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray49);
        double[] doubleArray75 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray77 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray75, (double) (-1.0f));
        double[] doubleArray84 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray86 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray84, (double) (-1.0f));
        double double87 = org.apache.commons.math.util.MathUtils.distance1(doubleArray75, doubleArray84);
        double[] doubleArray89 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray75, (double) 1);
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray75);
        double double91 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray24, doubleArray33);
        try {
            double double92 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray24);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 141.43549766589717d + "'", double65 == 141.43549766589717d);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 8.88019042005E8d + "'", double91 == 8.88019042005E8d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test016");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection3, false);
        java.lang.String str6 = nonMonotonousSequenceException5.toString();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection11, false);
        boolean boolean14 = nonMonotonousSequenceException13.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1L, (java.lang.Number) 100, 0);
        nonMonotonousSequenceException13.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        boolean boolean20 = nonMonotonousSequenceException18.getStrict();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        java.lang.Number number22 = nonMonotonousSequenceException5.getArgument();
        java.lang.Number number23 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (100 < 0)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (100 < 0)"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 100.0f + "'", number7.equals(100.0f));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (short) 0 + "'", number22.equals((short) 0));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (short) 0 + "'", number23.equals((short) 0));
        org.junit.Assert.assertTrue("'" + orderDirection24 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection24.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test017");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 10);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (int) (short) 10);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger9);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (int) (short) 10);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger13);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger10, (java.lang.Number) 10.0f, 1399733633);
        java.lang.String str20 = nonMonotonousSequenceException19.toString();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 1,399,733,632 and 1,399,733,633 are not strictly increasing (10 >= 1)" + "'", str20.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 1,399,733,632 and 1,399,733,633 are not strictly increasing (10 >= 1)"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test018");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 37);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 37 + "'", int1 == 37);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test019");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 2.718281828459045d);
        double[] doubleArray27 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) (-1.0f));
        double[] doubleArray36 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) (-1.0f));
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray36);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 2.718281828459045d);
        double double42 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray27);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, 10.0d);
        double[] doubleArray51 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, (double) (-1.0f));
        double[] doubleArray60 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) (-1.0f));
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray51, doubleArray60);
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, 2.718281828459045d);
        double[] doubleArray72 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray74 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray72, (double) (-1.0f));
        double[] doubleArray81 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray83 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray81, (double) (-1.0f));
        double double84 = org.apache.commons.math.util.MathUtils.distance1(doubleArray72, doubleArray81);
        double[] doubleArray86 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray72, 2.718281828459045d);
        double double87 = org.apache.commons.math.util.MathUtils.distance(doubleArray65, doubleArray72);
        double[] doubleArray89 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray65, 10.0d);
        double[] doubleArray91 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray89, 57.29577951308232d);
        double[] doubleArray93 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray91, 8938.141604040842d);
        boolean boolean94 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray93);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 139.51318994987582d + "'", double42 == 139.51318994987582d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 139.51318994987582d + "'", double87 == 139.51318994987582d);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test020");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(0, 1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test021");
        int int1 = org.apache.commons.math.util.MathUtils.sign(37);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test022");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1989426017, 1079574565);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 909851452 + "'", int2 == 909851452);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test023");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 'a');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 97L + "'", long1 == 97L);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test024");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-1067909120), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1067909120 + "'", int2 == 1067909120);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test025");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (-1884947935));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test026");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(37.17058140016013d, 8.88018845E8d, 1.665201168491711d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test027");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 56190271540L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test028");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52.0f, (java.lang.Number) 108L, 1080582145);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection8, false);
        boolean boolean11 = nonMonotonousSequenceException10.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1L, (java.lang.Number) 100, 0);
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        boolean boolean17 = nonMonotonousSequenceException15.getStrict();
        java.lang.Number number18 = nonMonotonousSequenceException15.getPrevious();
        java.lang.Number number19 = nonMonotonousSequenceException15.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52.0f, (java.lang.Number) 108L, 1080582145);
        boolean boolean25 = nonMonotonousSequenceException24.getStrict();
        nonMonotonousSequenceException15.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException24);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 108L + "'", number4.equals(108L));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 100 + "'", number18.equals(100));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 1L + "'", number19.equals(1L));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test029");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.0d, (int) (byte) 10, 1083461632);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test030");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 0, 195);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test031");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 530L, (-3.7315666758872256E7d), (double) (-42.0f));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test032");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 7400, 5730.0d, (double) 68L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test033");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.9850853666260323d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.833319283448138d + "'", double1 == 0.833319283448138d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test034");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 200.0f, (java.lang.Number) 108L, 52);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test035");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        java.lang.Class<?> wildcardClass4 = orderDirection3.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97, (java.lang.Number) 572.9577951308232d, (int) (byte) 0, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection10, false);
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException6.getSuppressed();
        java.lang.Number number15 = nonMonotonousSequenceException6.getArgument();
        int int16 = nonMonotonousSequenceException6.getIndex();
        java.lang.Class<?> wildcardClass17 = nonMonotonousSequenceException6.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException6.getDirection();
        java.lang.Number number19 = nonMonotonousSequenceException6.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 97 + "'", number15.equals(97));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 572.9577951308232d + "'", number19.equals(572.9577951308232d));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test036");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1L, (java.lang.Number) 100, 0);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        boolean boolean12 = nonMonotonousSequenceException10.getStrict();
        java.lang.Number number13 = nonMonotonousSequenceException10.getPrevious();
        java.lang.Number number14 = nonMonotonousSequenceException10.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException10.getDirection();
        java.lang.Throwable[] throwableArray16 = nonMonotonousSequenceException10.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 100 + "'", number13.equals(100));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 1L + "'", number14.equals(1L));
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray16);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test037");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray16 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) (-1.0f));
        double[] doubleArray25 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) (-1.0f));
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray25);
        double[] doubleArray35 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) (-1.0f));
        double double38 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray25, doubleArray35);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) (short) 1);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray40);
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 0.9999999958776927d);
        double[] doubleArray50 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, (double) (-1.0f));
        double[] doubleArray59 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray59, (double) (-1.0f));
        double double62 = org.apache.commons.math.util.MathUtils.distance1(doubleArray50, doubleArray59);
        double[] doubleArray69 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray71 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray69, (double) (-1.0f));
        double double72 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray59, doubleArray69);
        int int73 = org.apache.commons.math.util.MathUtils.hash(doubleArray59);
        double double74 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 141.43549766589717d + "'", double9 == 141.43549766589717d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1989426017 + "'", int73 == 1989426017);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test038");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(5.99147079704939d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 200.00249998437533d + "'", double1 == 200.00249998437533d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test039");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9155040003582885E22d + "'", double1 == 1.9155040003582885E22d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test040");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 13201L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test041");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-42L), (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test042");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, 197, 888019239);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test043");
        double double1 = org.apache.commons.math.util.FastMath.atan(5.286736667635593d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3838523794153534d + "'", double1 == 1.3838523794153534d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test044");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 13201L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.488047863280759d + "'", double1 == 9.488047863280759d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test045");
        int int2 = org.apache.commons.math.util.MathUtils.pow(74285528, 3900);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test046");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test047");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.08139081311424569d, number1, (-97));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test048");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.5175544230390033d, (java.lang.Number) 2.96086850281557E-68d, 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test049");
        double double1 = org.apache.commons.math.util.FastMath.rint(4.653960350157523d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.0d + "'", double1 == 5.0d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test050");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 1067909120, (long) 68);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1067909188L + "'", long2 == 1067909188L);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test051");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 2L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4161468365471424d) + "'", double1 == (-0.4161468365471424d));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test052");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1, (double) 346568599);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test053");
        double double1 = org.apache.commons.math.util.FastMath.log(37.17058140016013d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.6155176258376285d + "'", double1 == 3.6155176258376285d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test054");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(2, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 200 + "'", int2 == 200);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test055");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-1105975906));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test056");
        long long1 = org.apache.commons.math.util.MathUtils.sign(530L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test057");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, 1080582145);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test058");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-2048582795), 3260811333912044985L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2048582795L) + "'", long2 == (-2048582795L));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test059");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        java.lang.Class<?> wildcardClass4 = orderDirection3.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97, (java.lang.Number) 572.9577951308232d, (int) (byte) 0, orderDirection3, false);
        int int7 = nonMonotonousSequenceException6.getIndex();
        boolean boolean8 = nonMonotonousSequenceException6.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test060");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(5.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 74.20994852478785d + "'", double1 == 74.20994852478785d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test061");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-454785511));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test062");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((-2048582795), 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2048582795 + "'", int2 == 2048582795);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test063");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1989426017, (-1105975869L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test064");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.027415567780803774d + "'", double1 == 0.027415567780803774d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test065");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(5.286736667635593d, (double) (-1.88494797E9f), (double) (-984724751));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test066");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        java.lang.Class<?> wildcardClass4 = orderDirection3.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97, (java.lang.Number) 572.9577951308232d, (int) (byte) 0, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection10, false);
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException6.getSuppressed();
        java.lang.String str15 = nonMonotonousSequenceException6.toString();
        java.lang.Throwable[] throwableArray16 = nonMonotonousSequenceException6.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.2250738585072014E-308d, (java.lang.Number) Float.NaN, 32);
        int int21 = nonMonotonousSequenceException20.getIndex();
        java.lang.Number number22 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number22, (java.lang.Number) 4.248699261236361d, (-1352038911));
        nonMonotonousSequenceException20.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException25);
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException20);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = nonMonotonousSequenceException6.getDirection();
        java.lang.String str30 = nonMonotonousSequenceException6.toString();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (572.958 > 97)" + "'", str15.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (572.958 > 97)"));
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 32 + "'", int21 == 32);
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection29.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (572.958 > 97)" + "'", str30.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (572.958 > 97)"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test067");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.8324875211176866d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6730380541113077d + "'", double1 == 0.6730380541113077d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test068");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5440211108893698d) + "'", double1 == (-0.5440211108893698d));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test069");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 200L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 200 + "'", int1 == 200);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test070");
        long long2 = org.apache.commons.math.util.FastMath.min(1080582108L, (-888018845L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-888018845L) + "'", long2 == (-888018845L));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test071");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-53), 52L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-53L) + "'", long2 == (-53L));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test072");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(4.248291097914389d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0611383015009905d + "'", double1 == 2.0611383015009905d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test073");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(6.556615209031034E195d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.097292886533767E97d + "'", double1 == 8.097292886533767E97d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test074");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 779127710);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8222161315358034d + "'", double1 == 0.8222161315358034d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test075");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-893328343));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test076");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 2.718281828459045d);
        double[] doubleArray27 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) (-1.0f));
        double[] doubleArray36 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) (-1.0f));
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray36);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 2.718281828459045d);
        double double42 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray27);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (-0.9999999999999999d));
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) 99.0f);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) 1989426017);
        double double49 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 139.51318994987582d + "'", double42 == 139.51318994987582d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 70.0105713446191d + "'", double49 == 70.0105713446191d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test077");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(1260L, 2L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1260L + "'", long2 == 1260L);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test078");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 52);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test079");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-1.3428067497052016d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test080");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-1105975869));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test081");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 21);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test082");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(9, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test083");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (-2048582795));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test084");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(21, (-984724751));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test085");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(1352038911, (int) (short) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test086");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 2.718281828459045d);
        double[] doubleArray27 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) (-1.0f));
        double[] doubleArray36 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) (-1.0f));
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray36);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 2.718281828459045d);
        double double42 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray27);
        double[] doubleArray43 = null;
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray43);
        double[] doubleArray51 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, (double) (-1.0f));
        double[] doubleArray60 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) (-1.0f));
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray51, doubleArray60);
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, 2.718281828459045d);
        double double66 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray65);
        java.lang.Number number68 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection73 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        java.lang.Class<?> wildcardClass74 = orderDirection73.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException76 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97, (java.lang.Number) 572.9577951308232d, (int) (byte) 0, orderDirection73, false);
        int int77 = nonMonotonousSequenceException76.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection78 = nonMonotonousSequenceException76.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection79 = nonMonotonousSequenceException76.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException81 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 197, number68, 9603, orderDirection79, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection79, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not increasing (0.014 > -0.014)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 139.51318994987582d + "'", double42 == 139.51318994987582d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection73 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection73.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass74);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection78 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection78.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection79 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection79.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test087");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(200);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test088");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8.948422304476766d, (java.lang.Number) 0.9998219848673034d, 1624620833, orderDirection3, false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test089");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 1260L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test090");
        int int2 = org.apache.commons.math.util.FastMath.max((int) '4', (-1105975869));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test091");
        double double1 = org.apache.commons.math.util.FastMath.atanh(961.1859962243583d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test092");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 97, 1.5707963215550047d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test093");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1987797057, 53L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1471607487) + "'", int2 == (-1471607487));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test094");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-286962687));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test095");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 2.718281828459045d);
        double[] doubleArray27 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) (-1.0f));
        double[] doubleArray36 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) (-1.0f));
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray36);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 2.718281828459045d);
        double double42 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray27);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, 10.0d);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, 57.29577951308232d);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, 8938.141604040842d);
        double[] doubleArray55 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray57 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray55, (double) (-1.0f));
        double[] doubleArray64 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray64, (double) (-1.0f));
        double double67 = org.apache.commons.math.util.MathUtils.distance1(doubleArray55, doubleArray64);
        double[] doubleArray74 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray76 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray74, (double) (-1.0f));
        double[] doubleArray83 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray85 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray83, (double) (-1.0f));
        double double86 = org.apache.commons.math.util.MathUtils.distance1(doubleArray74, doubleArray83);
        double[] doubleArray88 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray74, 2.718281828459045d);
        boolean boolean89 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray64, doubleArray74);
        double double90 = org.apache.commons.math.util.MathUtils.distance1(doubleArray48, doubleArray74);
        int int91 = org.apache.commons.math.util.MathUtils.hash(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 139.51318994987582d + "'", double42 == 139.51318994987582d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 8912.904436121658d + "'", double90 == 8912.904436121658d);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 1989426017 + "'", int91 == 1989426017);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test096");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.0411381226745244d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test097");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(9603, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9603 + "'", int2 == 9603);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test098");
        int int2 = org.apache.commons.math.util.FastMath.min(210, 1989426017);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 210 + "'", int2 == 210);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test099");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 80L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.00365494560708d + "'", double1 == 9.00365494560708d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test100");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, 1260L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test101");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.0f), (java.lang.Number) 4.594700892207039d, (int) (byte) -1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test102");
        java.lang.Number number3 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection9, false);
        boolean boolean12 = nonMonotonousSequenceException11.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1L, (java.lang.Number) 100, 0);
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        boolean boolean18 = nonMonotonousSequenceException16.getStrict();
        java.lang.String str19 = nonMonotonousSequenceException16.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = nonMonotonousSequenceException16.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number3, (java.lang.Number) 37.17058140016013d, 1, orderDirection20, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 65.99621212121211d, (java.lang.Number) 0.5112998429212577d, (int) (byte) 10, orderDirection20, false);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (100 >= 1)" + "'", str19.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (100 >= 1)"));
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection20.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test103");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 151882303972620L, (-1080582045));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test104");
        long long2 = org.apache.commons.math.util.MathUtils.pow(888019042L, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test105");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.5745243133045663d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test106");
        double double1 = org.apache.commons.math.util.FastMath.ceil(4354.479242994256d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4355.0d + "'", double1 == 4355.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test107");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-2072794013720961303L), 200);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test108");
        double double1 = org.apache.commons.math.util.FastMath.cos(4.573022699008911d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.13891556834722926d) + "'", double1 == (-0.13891556834722926d));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test109");
        long long1 = org.apache.commons.math.util.MathUtils.sign(4L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test110");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 369282464560880L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test111");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(1.57079632551141d, (double) 888019042L, 2.2737367544323206E-13d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test112");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-841025708), 1407088129);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test113");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray15);
        java.lang.Class<?> wildcardClass20 = doubleArray6.getClass();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 141.43549766589717d + "'", double18 == 141.43549766589717d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test114");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((int) 'a', (-97));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test115");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1167939852);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test116");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-1105975869), (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1105975869L + "'", long2 == 1105975869L);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test117");
        int[] intArray0 = new int[] {};
        int[] intArray5 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int6 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray5);
        int[] intArray13 = new int[] { (byte) 0, (byte) 10, '#', (short) -1, (short) 1, 97 };
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray13);
        int[] intArray15 = new int[] {};
        int[] intArray20 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray20);
        int[] intArray27 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double28 = org.apache.commons.math.util.MathUtils.distance(intArray15, intArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray27);
        int[] intArray30 = new int[] {};
        int[] intArray35 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int36 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray35);
        int[] intArray41 = new int[] { (byte) 1, '4', '#', 'a' };
        int int42 = org.apache.commons.math.util.MathUtils.distance1(intArray35, intArray41);
        int[] intArray43 = new int[] {};
        int[] intArray48 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int49 = org.apache.commons.math.util.MathUtils.distanceInf(intArray43, intArray48);
        int[] intArray55 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double56 = org.apache.commons.math.util.MathUtils.distance(intArray43, intArray55);
        int int57 = org.apache.commons.math.util.MathUtils.distanceInf(intArray41, intArray55);
        double double58 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray41);
        int[] intArray59 = new int[] {};
        int[] intArray64 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int65 = org.apache.commons.math.util.MathUtils.distanceInf(intArray59, intArray64);
        int[] intArray72 = new int[] { (byte) 0, (byte) 10, '#', (short) -1, (short) 1, 97 };
        int int73 = org.apache.commons.math.util.MathUtils.distance1(intArray64, intArray72);
        double double74 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray72);
        int[] intArray75 = new int[] {};
        int[] intArray80 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int81 = org.apache.commons.math.util.MathUtils.distanceInf(intArray75, intArray80);
        int[] intArray82 = new int[] {};
        int[] intArray87 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int88 = org.apache.commons.math.util.MathUtils.distanceInf(intArray82, intArray87);
        double double89 = org.apache.commons.math.util.MathUtils.distance(intArray80, intArray87);
        try {
            double double90 = org.apache.commons.math.util.MathUtils.distance(intArray72, intArray80);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 56 + "'", int14 == 56);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 121.51131634543344d + "'", double29 == 121.51131634543344d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 195 + "'", int42 == 195);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 65 + "'", int57 == 65);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 117.12813496338103d + "'", double58 == 117.12813496338103d);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 56 + "'", int73 == 56);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 38.02630668366309d + "'", double74 == 38.02630668366309d);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertNotNull(intArray87);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 0 + "'", int88 == 0);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test118");
        double double1 = org.apache.commons.math.util.FastMath.acosh(6.3508120580348555d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.535473003775098d + "'", double1 == 2.535473003775098d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test119");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) (-1.0f));
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray7);
        double[] doubleArray17 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) (-1.0f));
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray17);
        double[] doubleArray28 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, (double) (-1.0f));
        double[] doubleArray37 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, (double) (-1.0f));
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray37);
        double[] doubleArray47 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, (double) (-1.0f));
        double double50 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray37, doubleArray47);
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, (double) (short) 1);
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray37);
        double[] doubleArray60 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) (-1.0f));
        double[] doubleArray69 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray71 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray69, (double) (-1.0f));
        double double72 = org.apache.commons.math.util.MathUtils.distance1(doubleArray60, doubleArray69);
        double[] doubleArray79 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray81 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray79, (double) (-1.0f));
        double double82 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray69, doubleArray79);
        double[] doubleArray84 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray69, (double) (short) 1);
        double double85 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray37, doubleArray69);
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray69);
        int int87 = org.apache.commons.math.util.MathUtils.hash(doubleArray7);
        int int88 = org.apache.commons.math.util.MathUtils.hash(doubleArray7);
        try {
            double double89 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 141.43549766589717d + "'", double10 == 141.43549766589717d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 141.43549766589717d + "'", double20 == 141.43549766589717d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 141.43549766589717d + "'", double53 == 141.43549766589717d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 1989426017 + "'", int87 == 1989426017);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 1989426017 + "'", int88 == 1989426017);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test120");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0f, (java.lang.Number) 64512240L, 63);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        java.lang.Class<?> wildcardClass6 = nonMonotonousSequenceException3.getClass();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test121");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-10));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999999958776927d) + "'", double1 == (-0.9999999958776927d));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test122");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 2.718281828459045d);
        double[] doubleArray27 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) (-1.0f));
        double[] doubleArray36 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) (-1.0f));
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray36);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 2.718281828459045d);
        double double42 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray27);
        double[] doubleArray49 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, (double) (-1.0f));
        double double52 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray49);
        double[] doubleArray59 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray59, (double) (-1.0f));
        double double62 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray59);
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray49, doubleArray59);
        double double64 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray49);
        double[] doubleArray71 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray73 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray71, (double) (-1.0f));
        double double74 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray73);
        double[] doubleArray76 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray73, (double) 1105975906);
        double double77 = org.apache.commons.math.util.MathUtils.distance(doubleArray27, doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 139.51318994987582d + "'", double42 == 139.51318994987582d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 141.43549766589717d + "'", double52 == 141.43549766589717d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 141.43549766589717d + "'", double62 == 141.43549766589717d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.7071774883294859d + "'", double74 == 0.7071774883294859d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 142.14267515422665d + "'", double77 == 142.14267515422665d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test123");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) 1);
        double[] doubleArray27 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) (-1.0f));
        double[] doubleArray36 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) (-1.0f));
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray36);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 2.718281828459045d);
        double[] doubleArray48 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray48, (double) (-1.0f));
        double[] doubleArray57 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray57, (double) (-1.0f));
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray48, doubleArray57);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray48, 2.718281828459045d);
        double double63 = org.apache.commons.math.util.MathUtils.distance(doubleArray41, doubleArray48);
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, (-0.9999999999999999d));
        double[] doubleArray72 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray74 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray72, (double) (-1.0f));
        double double75 = org.apache.commons.math.util.MathUtils.distance(doubleArray41, doubleArray72);
        double double76 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray41);
        double double77 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 139.51318994987582d + "'", double63 == 139.51318994987582d);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 139.51318994987582d + "'", double75 == 139.51318994987582d);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 98.64085908577049d + "'", double76 == 98.64085908577049d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 1.9223077160213498d + "'", double77 == 1.9223077160213498d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test124");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 99, (long) (-893328343));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 893328442L + "'", long2 == 893328442L);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test125");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test126");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 10);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (int) (short) 10);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 36);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 62L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
    }
}

