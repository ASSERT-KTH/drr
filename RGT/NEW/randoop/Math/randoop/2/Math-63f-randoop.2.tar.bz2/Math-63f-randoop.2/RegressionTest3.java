import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 20L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.044522437723423d + "'", double1 == 3.044522437723423d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 100, (-1105975906));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1105975906) + "'", int2 == (-1105975906));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        int[] intArray0 = new int[] {};
        int[] intArray5 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int6 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray5);
        int[] intArray12 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray12);
        int[] intArray14 = new int[] {};
        int[] intArray19 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int20 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray19);
        int[] intArray27 = new int[] { (byte) 0, (byte) 10, '#', (short) -1, (short) 1, 97 };
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray27);
        int[] intArray29 = new int[] {};
        int[] intArray34 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int35 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray34);
        int[] intArray41 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double42 = org.apache.commons.math.util.MathUtils.distance(intArray29, intArray41);
        double double43 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray41);
        int[] intArray44 = new int[] {};
        int[] intArray49 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int50 = org.apache.commons.math.util.MathUtils.distanceInf(intArray44, intArray49);
        int[] intArray55 = new int[] { (byte) 1, '4', '#', 'a' };
        int int56 = org.apache.commons.math.util.MathUtils.distance1(intArray49, intArray55);
        int[] intArray57 = new int[] {};
        int[] intArray62 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int63 = org.apache.commons.math.util.MathUtils.distanceInf(intArray57, intArray62);
        int[] intArray69 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double70 = org.apache.commons.math.util.MathUtils.distance(intArray57, intArray69);
        int int71 = org.apache.commons.math.util.MathUtils.distanceInf(intArray55, intArray69);
        double double72 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray55);
        int int73 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray19);
        int[] intArray74 = new int[] {};
        int[] intArray79 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int80 = org.apache.commons.math.util.MathUtils.distanceInf(intArray74, intArray79);
        int[] intArray81 = new int[] {};
        int[] intArray86 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int87 = org.apache.commons.math.util.MathUtils.distanceInf(intArray81, intArray86);
        int[] intArray92 = new int[] { (byte) 1, '4', '#', 'a' };
        int int93 = org.apache.commons.math.util.MathUtils.distance1(intArray86, intArray92);
        double double94 = org.apache.commons.math.util.MathUtils.distance(intArray79, intArray92);
        java.lang.Class<?> wildcardClass95 = intArray92.getClass();
        int int96 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray92);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 56 + "'", int28 == 56);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 121.51131634543344d + "'", double43 == 121.51131634543344d);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 195 + "'", int56 == 195);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 65 + "'", int71 == 65);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 117.12813496338103d + "'", double72 == 117.12813496338103d);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertNotNull(intArray79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertNotNull(intArray86);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 0 + "'", int87 == 0);
        org.junit.Assert.assertNotNull(intArray92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 195 + "'", int93 == 195);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 117.12813496338103d + "'", double94 == 117.12813496338103d);
        org.junit.Assert.assertNotNull(wildcardClass95);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 0 + "'", int96 == 0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        java.lang.Number number7 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, number7, 0, orderDirection9, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52L, (java.lang.Number) 13L, 1989426017, orderDirection9, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8.960719776347302d, (java.lang.Number) 8.960719776347302d, (int) (byte) 100, orderDirection9, false);
        java.lang.Number number16 = nonMonotonousSequenceException15.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 8.960719776347302d + "'", number16.equals(8.960719776347302d));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, (double) (-279932959), 6.685426572281104E184d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 1.1752011936438014d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 197);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 197 + "'", int1 == 197);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 200L, (double) 1352038911, (int) ' ');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.1932800462173283d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7853981613362947d + "'", double1 == 0.7853981613362947d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) 0);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (int) (short) 10);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (int) (byte) 100);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 53);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) 0);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (int) (short) 10);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, (int) (byte) 100);
        java.math.BigInteger bigInteger17 = null;
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (long) 0);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, (int) (short) 10);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (int) (byte) 100);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, bigInteger21);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger21);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, 32L);
        try {
            java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger27);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.9850853666260323d, 0.7071774883294859d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9850853666260323d + "'", double2 == 0.9850853666260323d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((-4.503599627370496E15d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        double double1 = org.apache.commons.math.util.FastMath.abs(2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(21, 2138030283);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1967593473L, (double) 142404354048L, 0.5853129205049546d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        double double1 = org.apache.commons.math.util.FastMath.log(1.0333147966386297E40d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 92.13617560368711d + "'", double1 == 92.13617560368711d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 35, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 31500);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1079574628, (float) 3900);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3900.0f + "'", float2 == 3900.0f);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 0.01f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7453292129831807E-4d + "'", double1 == 1.7453292129831807E-4d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(0L, (long) (-1884947935));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.7071774883294858d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        long long2 = org.apache.commons.math.util.MathUtils.pow(100L, (long) 1079574628);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.0E194d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        double double1 = org.apache.commons.math.util.FastMath.expm1(4.594700892207039d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.95853185248363d + "'", double1 == 97.95853185248363d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        double double1 = org.apache.commons.math.util.FastMath.exp(5729.5779513082325d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 6.6854265722811046E184d, (java.lang.Number) 38.02630668366309d, 20532231);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(37.17058140016013d, 9.995649622311774E8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 37.17058140016014d + "'", double2 == 37.17058140016014d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        double double1 = org.apache.commons.math.util.FastMath.log1p(53.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.9889840465642745d + "'", double1 == 3.9889840465642745d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.5d, 9.995649622311774E8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-29.896725090594288d) + "'", double2 == (-29.896725090594288d));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 200L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 200.0f + "'", float1 == 200.0f);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 1300L, 3.4657359027997265d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1300.0d + "'", double2 == 1300.0d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-1105975869), 63);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1624620833);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-1105975869), (-968000650), 197);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        java.lang.Class<?> wildcardClass4 = orderDirection3.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97, (java.lang.Number) 572.9577951308232d, (int) (byte) 0, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection10, false);
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException6.getSuppressed();
        java.lang.Class<?> wildcardClass15 = nonMonotonousSequenceException6.getClass();
        java.lang.Number number16 = nonMonotonousSequenceException6.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 572.9577951308232d + "'", number16.equals(572.9577951308232d));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1105975869), 21);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 354302819);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-888018845), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        int int2 = org.apache.commons.math.util.FastMath.max(779127810, 779127810);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 779127810 + "'", int2 == 779127810);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(100.0d, 100.00000000000001d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-1884947935));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        double double2 = org.apache.commons.math.util.FastMath.atan2(9.913041577021816E86d, 0.022126756261955736d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.5018338600483341d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0450786944038692d + "'", double1 == 1.0450786944038692d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.5872139151569291d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8324875211176866d + "'", double1 == 0.8324875211176866d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (-893328343));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-893328343) + "'", int2 == (-893328343));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) (-37L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray25 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) (-1.0f));
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray25);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (short) 1);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (1 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(2.7182818284590446d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.04744296790374203d + "'", double1 == 0.04744296790374203d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-893328343));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 8.9332832E8f + "'", float1 == 8.9332832E8f);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        int[] intArray0 = new int[] {};
        int[] intArray5 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int6 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray5);
        int[] intArray7 = new int[] {};
        int[] intArray12 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int13 = org.apache.commons.math.util.MathUtils.distanceInf(intArray7, intArray12);
        int[] intArray14 = new int[] {};
        int[] intArray19 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int20 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray19);
        int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray7, intArray14);
        int[] intArray22 = new int[] {};
        int[] intArray27 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int28 = org.apache.commons.math.util.MathUtils.distanceInf(intArray22, intArray27);
        int[] intArray29 = new int[] {};
        int[] intArray34 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int35 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray34);
        int int36 = org.apache.commons.math.util.MathUtils.distanceInf(intArray22, intArray29);
        int int37 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray22);
        int int38 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray22);
        int[] intArray39 = new int[] {};
        int[] intArray44 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int45 = org.apache.commons.math.util.MathUtils.distanceInf(intArray39, intArray44);
        int[] intArray52 = new int[] { (byte) 0, (byte) 10, '#', (short) -1, (short) 1, 97 };
        int int53 = org.apache.commons.math.util.MathUtils.distance1(intArray44, intArray52);
        int[] intArray54 = new int[] {};
        int[] intArray59 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int60 = org.apache.commons.math.util.MathUtils.distanceInf(intArray54, intArray59);
        int[] intArray66 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double67 = org.apache.commons.math.util.MathUtils.distance(intArray54, intArray66);
        double double68 = org.apache.commons.math.util.MathUtils.distance(intArray44, intArray66);
        int[] intArray69 = new int[] {};
        int[] intArray74 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int75 = org.apache.commons.math.util.MathUtils.distanceInf(intArray69, intArray74);
        int[] intArray80 = new int[] { (byte) 1, '4', '#', 'a' };
        int int81 = org.apache.commons.math.util.MathUtils.distance1(intArray74, intArray80);
        int[] intArray82 = new int[] {};
        int[] intArray87 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int88 = org.apache.commons.math.util.MathUtils.distanceInf(intArray82, intArray87);
        int[] intArray94 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double95 = org.apache.commons.math.util.MathUtils.distance(intArray82, intArray94);
        int int96 = org.apache.commons.math.util.MathUtils.distanceInf(intArray80, intArray94);
        double double97 = org.apache.commons.math.util.MathUtils.distance(intArray44, intArray80);
        int int98 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray80);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 56 + "'", int53 == 56);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 121.51131634543344d + "'", double68 == 121.51131634543344d);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 195 + "'", int81 == 195);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertNotNull(intArray87);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 0 + "'", int88 == 0);
        org.junit.Assert.assertNotNull(intArray94);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 0.0d + "'", double95 == 0.0d);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 65 + "'", int96 == 65);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 117.12813496338103d + "'", double97 == 117.12813496338103d);
        org.junit.Assert.assertTrue("'" + int98 + "' != '" + 0 + "'", int98 == 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 4.248699261236361d, (-1352038911));
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        int int5 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,352,038,912 and -1,352,038,911 are not strictly increasing (4.249 >= null)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,352,038,912 and -1,352,038,911 are not strictly increasing (4.249 >= null)"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1352038911) + "'", int5 == (-1352038911));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, number1, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNull(number6);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-1080582045), 1105975906);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (byte) 10, (long) (-301454334));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3014543340L) + "'", long2 == (-3014543340L));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(1.5707963215550047d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        long long1 = org.apache.commons.math.util.MathUtils.sign(64512240L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        double double1 = org.apache.commons.math.util.FastMath.sin(6.283185307179587d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.432490598706545E-16d + "'", double1 == 6.432490598706545E-16d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 80L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0, 3900);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.4422495703074083d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4422495703074083d + "'", double1 == 1.4422495703074083d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 104L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 104.0d + "'", double1 == 104.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.6932056354284859d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6932056354284858d + "'", double2 == 0.6932056354284858d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 195, (double) (-10.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 195.0d + "'", double2 == 195.0d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-12.245600189892365d), 100.50000000000001d, 1.0187171445731638d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) '4', (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 2.718281828459045d);
        double[] doubleArray27 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) (-1.0f));
        double[] doubleArray36 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) (-1.0f));
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray36);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 2.718281828459045d);
        double double42 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray27);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (-0.9999999999999999d));
        double[] doubleArray51 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, (double) (-1.0f));
        double[] doubleArray60 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) (-1.0f));
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray51, doubleArray60);
        double[] doubleArray70 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray72 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray70, (double) (-1.0f));
        double double73 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray60, doubleArray70);
        double[] doubleArray75 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) (short) 1);
        double double76 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray44, doubleArray60);
        double[] doubleArray83 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray85 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray83, (double) (-1.0f));
        double double86 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray85);
        double[] doubleArray88 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray85, (double) 1105975906);
        double double89 = org.apache.commons.math.util.MathUtils.distance(doubleArray60, doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 139.51318994987582d + "'", double42 == 139.51318994987582d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 100.50000000000001d + "'", double76 == 100.50000000000001d);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.7071774883294859d + "'", double86 == 0.7071774883294859d);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 142.14267515422665d + "'", double89 == 142.14267515422665d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8414709848078965d + "'", double1 == 0.8414709848078965d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        int[] intArray0 = new int[] {};
        int[] intArray5 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int6 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray5);
        int[] intArray7 = new int[] {};
        int[] intArray12 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int13 = org.apache.commons.math.util.MathUtils.distanceInf(intArray7, intArray12);
        int int14 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray7);
        int[] intArray15 = null;
        double double16 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray15);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        long long1 = org.apache.commons.math.util.FastMath.round(0.010050166858404251d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double[] doubleArray24 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) (-1.0f));
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray24);
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray24);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, 4.143134726391533d);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24, orderDirection32, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 141.43549766589717d + "'", double28 == 141.43549766589717d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(4.573022699008911d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 2L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 32, 97);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-37), (float) (-454785511));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-4.54785504E8f) + "'", float2 == (-4.54785504E8f));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        double double1 = org.apache.commons.math.util.FastMath.ulp(2.225073858507202E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        float float2 = org.apache.commons.math.util.FastMath.max(63.0f, (float) 3900);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3900.0f + "'", float2 == 3900.0f);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.46198022462000077d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(349.9541180407703d, (-0.9991050130774393d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 349.95411804077025d + "'", double2 == 349.95411804077025d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(0L, (long) 888019042);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 888019042L + "'", long2 == 888019042L);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-5.118394377331518E10d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5.1183943773E10d) + "'", double1 == (-5.1183943773E10d));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 1300L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.570027096177388d + "'", double1 == 1.570027096177388d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(100, 1399733633);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (byte) -1, 279932959L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1L), (java.lang.Number) 0.5018338600483341d, 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1L, (java.lang.Number) 100, 0);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        int int10 = nonMonotonousSequenceException3.getIndex();
        boolean boolean11 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0.502 >= -1)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0.502 >= -1)"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-43L), (int) (byte) 100);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 1079574628);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.570796325868606d + "'", double1 == 1.570796325868606d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(13260L, 59L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 13201L + "'", long2 == 13201L);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 14776336, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray25 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) (-1.0f));
        double[] doubleArray34 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, (double) (-1.0f));
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray34);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, 2.718281828459045d);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray25);
        java.lang.Class<?> wildcardClass41 = doubleArray15.getClass();
        java.lang.Class<?> wildcardClass42 = doubleArray15.getClass();
        double[] doubleArray49 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, (double) (-1.0f));
        double double52 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray51);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray15, doubleArray51);
        double[] doubleArray55 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, 0.44014302249602794d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.7071774883294859d + "'", double52 == 0.7071774883294859d);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(doubleArray55);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 13L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 104L, 97.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 10);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (int) (byte) 100);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 53);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 0);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (int) (short) 10);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (int) (byte) 100);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) 0);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (int) (short) 10);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (int) (byte) 100);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger20);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, bigInteger20);
        java.math.BigInteger bigInteger25 = null;
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, (long) 0);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (int) (short) 10);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, (int) (byte) 100);
        java.math.BigInteger bigInteger32 = null;
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, (long) 0);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, (int) (short) 10);
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, (int) (byte) 100);
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, bigInteger36);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, bigInteger39);
        try {
            java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (-1105975906));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(bigInteger40);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-1105975879L), 1080582145);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3260811333912044985L + "'", long2 == 3260811333912044985L);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        double double1 = org.apache.commons.math.util.FastMath.cos(4.930380657631324E-32d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        int[] intArray0 = new int[] {};
        int[] intArray5 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int6 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray5);
        int[] intArray7 = new int[] {};
        int[] intArray12 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int13 = org.apache.commons.math.util.MathUtils.distanceInf(intArray7, intArray12);
        int[] intArray19 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double20 = org.apache.commons.math.util.MathUtils.distance(intArray7, intArray19);
        int[] intArray21 = new int[] {};
        int[] intArray26 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int27 = org.apache.commons.math.util.MathUtils.distanceInf(intArray21, intArray26);
        int[] intArray32 = new int[] { (byte) 1, '4', '#', 'a' };
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray32);
        int[] intArray34 = new int[] {};
        int[] intArray39 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int40 = org.apache.commons.math.util.MathUtils.distanceInf(intArray34, intArray39);
        int[] intArray46 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double47 = org.apache.commons.math.util.MathUtils.distance(intArray34, intArray46);
        int int48 = org.apache.commons.math.util.MathUtils.distanceInf(intArray32, intArray46);
        int int49 = org.apache.commons.math.util.MathUtils.distanceInf(intArray19, intArray46);
        double double50 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray19);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 195 + "'", int33 == 195);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 65 + "'", int48 == 65);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        int int2 = org.apache.commons.math.util.FastMath.min(0, 53);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) -1, (java.lang.Number) Float.NaN, (int) (byte) 10, orderDirection6, false);
        java.lang.Number number11 = nonMonotonousSequenceException10.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (short) -1 + "'", number11.equals((short) -1));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(32, (-301454334));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.8842131779592965E7d, (-3.0d), 9);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-1080582108));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1080582108L + "'", long1 == 1080582108L);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 99);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        double double1 = org.apache.commons.math.util.FastMath.log1p(98.64085908577049d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.601572312253344d + "'", double1 == 4.601572312253344d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        int[] intArray5 = new int[] { (short) 0, 63, (short) 10, 10, 779127810 };
        int[] intArray6 = new int[] {};
        int[] intArray11 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int12 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray11);
        int[] intArray18 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double19 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray18);
        int[] intArray20 = new int[] {};
        int[] intArray25 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int26 = org.apache.commons.math.util.MathUtils.distanceInf(intArray20, intArray25);
        int[] intArray31 = new int[] { (byte) 1, '4', '#', 'a' };
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray25, intArray31);
        int[] intArray33 = new int[] {};
        int[] intArray38 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int39 = org.apache.commons.math.util.MathUtils.distanceInf(intArray33, intArray38);
        int[] intArray45 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double46 = org.apache.commons.math.util.MathUtils.distance(intArray33, intArray45);
        int int47 = org.apache.commons.math.util.MathUtils.distanceInf(intArray31, intArray45);
        int int48 = org.apache.commons.math.util.MathUtils.distanceInf(intArray18, intArray45);
        int int49 = org.apache.commons.math.util.MathUtils.distanceInf(intArray5, intArray45);
        int[] intArray50 = new int[] {};
        int[] intArray55 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int56 = org.apache.commons.math.util.MathUtils.distanceInf(intArray50, intArray55);
        int[] intArray62 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double63 = org.apache.commons.math.util.MathUtils.distance(intArray50, intArray62);
        int[] intArray64 = new int[] {};
        int[] intArray69 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int70 = org.apache.commons.math.util.MathUtils.distanceInf(intArray64, intArray69);
        int[] intArray75 = new int[] { (byte) 1, '4', '#', 'a' };
        int int76 = org.apache.commons.math.util.MathUtils.distance1(intArray69, intArray75);
        int[] intArray77 = new int[] {};
        int[] intArray82 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int83 = org.apache.commons.math.util.MathUtils.distanceInf(intArray77, intArray82);
        int[] intArray89 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double90 = org.apache.commons.math.util.MathUtils.distance(intArray77, intArray89);
        int int91 = org.apache.commons.math.util.MathUtils.distanceInf(intArray75, intArray89);
        int int92 = org.apache.commons.math.util.MathUtils.distanceInf(intArray62, intArray89);
        double double93 = org.apache.commons.math.util.MathUtils.distance(intArray45, intArray62);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 195 + "'", int32 == 195);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 65 + "'", int47 == 65);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 779127710 + "'", int49 == 779127710);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 195 + "'", int76 == 195);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
        org.junit.Assert.assertNotNull(intArray89);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 65 + "'", int91 == 65);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 0.0d + "'", double93 == 0.0d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 33610500);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.36105E7f + "'", float1 == 3.36105E7f);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(100, (int) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 161700.0d + "'", double2 == 161700.0d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(1.9826083154044198E87d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 1080582108L, 99.99999999999999d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 99.99999999999999d + "'", double2 == 99.99999999999999d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        double double1 = org.apache.commons.math.util.FastMath.sinh(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        int int1 = org.apache.commons.math.util.MathUtils.hash(5.298292365610485d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-841025708) + "'", int1 == (-841025708));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        double double1 = org.apache.commons.math.util.FastMath.abs(5.298342365610589d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298342365610589d + "'", double1 == 5.298342365610589d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(268.0d, 2.7501303671488815d, (double) (-69));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1105975906, 1352038911);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-2072794013720961303L), (float) (-42L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-42.0f) + "'", float2 == (-42.0f));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 1162674021347622912L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 10);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (int) (byte) 100);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 9603);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 0);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (int) (short) 10);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (int) (byte) 100);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 53);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (long) 0);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (int) (short) 10);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (int) (byte) 100);
        java.math.BigInteger bigInteger25 = null;
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, (long) 0);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (int) (short) 10);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, (int) (byte) 100);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, bigInteger29);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, bigInteger29);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 32L);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger36);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.5707963215550047d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.5091784665994994d + "'", double1 == 2.5091784665994994d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        double double1 = org.apache.commons.math.util.FastMath.ulp(5.818647867496961d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 1080582108L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.080582108E9d + "'", double1 == 1.080582108E9d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((-1352038911), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        java.lang.Class<?> wildcardClass4 = orderDirection3.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97, (java.lang.Number) 572.9577951308232d, (int) (byte) 0, orderDirection3, false);
        java.lang.Number number7 = nonMonotonousSequenceException6.getArgument();
        java.lang.Number number8 = nonMonotonousSequenceException6.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException6.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 97 + "'", number7.equals(97));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 97 + "'", number8.equals(97));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.0625d, 0.0d, 0.012652378577065889d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 1987797057);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        double double1 = org.apache.commons.math.util.FastMath.rint((-1.1354487784640475d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        int int1 = org.apache.commons.math.util.FastMath.abs((-37));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 37 + "'", int1 == 37);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(13, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 1079574528);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.384185791015625E-7d + "'", double1 == 2.384185791015625E-7d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1L, (java.lang.Number) 100, 0);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        java.lang.Throwable[] throwableArray12 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(throwableArray12);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(1.2413882881933434E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6653345369377348E-16d + "'", double1 == 1.6653345369377348E-16d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-2L), (-5547412656154738688L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, 1075970048, 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 10);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (int) (short) 10);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 59L);
        try {
            java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (int) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (byte) 10, (long) (-53));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 530L + "'", long2 == 530L);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        double double1 = org.apache.commons.math.util.FastMath.sinh(6.3508120580348555d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 286.4780249007855d + "'", double1 == 286.4780249007855d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.9999999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999999999999d + "'", double1 == 0.9999999999999999d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        double double1 = org.apache.commons.math.util.MathUtils.sign(8.960719776347302d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.6931471784987917d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 17.44475315305432d, number1, (-841025708));
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.6729530497092316d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.960016809947024d + "'", double1 == 1.960016809947024d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        long long2 = org.apache.commons.math.util.FastMath.min(80L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        int[] intArray0 = null;
        int[] intArray1 = new int[] {};
        int[] intArray6 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray6);
        int[] intArray14 = new int[] { (byte) 0, (byte) 10, '#', (short) -1, (short) 1, 97 };
        int int15 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray14);
        int[] intArray16 = new int[] {};
        int[] intArray21 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int22 = org.apache.commons.math.util.MathUtils.distanceInf(intArray16, intArray21);
        int[] intArray28 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray16, intArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray28);
        int[] intArray31 = new int[] {};
        int[] intArray36 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int37 = org.apache.commons.math.util.MathUtils.distanceInf(intArray31, intArray36);
        int[] intArray42 = new int[] { (byte) 1, '4', '#', 'a' };
        int int43 = org.apache.commons.math.util.MathUtils.distance1(intArray36, intArray42);
        int[] intArray44 = new int[] {};
        int[] intArray49 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int50 = org.apache.commons.math.util.MathUtils.distanceInf(intArray44, intArray49);
        int[] intArray56 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double57 = org.apache.commons.math.util.MathUtils.distance(intArray44, intArray56);
        int int58 = org.apache.commons.math.util.MathUtils.distanceInf(intArray42, intArray56);
        int int59 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray42);
        try {
            double double60 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 56 + "'", int15 == 56);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 121.51131634543344d + "'", double30 == 121.51131634543344d);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 195 + "'", int43 == 195);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 65 + "'", int58 == 65);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 195 + "'", int59 == 195);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        float float2 = org.apache.commons.math.util.FastMath.min(3.36105E7f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        double double2 = org.apache.commons.math.util.FastMath.max(3.0d, 0.3726544820459676d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.4515827052894548d, 1.665201168491711d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-1884947935));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (-2138028915L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(1.0d, (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        java.lang.Class<?> wildcardClass4 = orderDirection3.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97, (java.lang.Number) 572.9577951308232d, (int) (byte) 0, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection10, false);
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException12.getSuppressed();
        java.lang.String str15 = nonMonotonousSequenceException12.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection22, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException26 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) -1, (java.lang.Number) Float.NaN, (int) (byte) 10, orderDirection22, false);
        java.lang.String str27 = nonMonotonousSequenceException26.toString();
        nonMonotonousSequenceException12.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException26);
        java.lang.String str29 = nonMonotonousSequenceException26.toString();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (100 < 0)" + "'", str15.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (100 < 0)"));
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not decreasing (� < -1)" + "'", str27.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not decreasing (� < -1)"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not decreasing (� < -1)" + "'", str29.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not decreasing (� < -1)"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 3500);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3500L + "'", long1 == 3500L);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-984724751), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-984724751L) + "'", long2 == (-984724751L));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        long long2 = org.apache.commons.math.util.MathUtils.pow(888019095L, (long) 9);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3661163857576232023L + "'", long2 == 3661163857576232023L);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-2072794013720961147L), (float) (-3014543340L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-3.01454336E9f) + "'", float2 == (-3.01454336E9f));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        long long2 = org.apache.commons.math.util.FastMath.max(57270853685L, (-6625612056500271398L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 57270853685L + "'", long2 == 57270853685L);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.0d, 0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        double double1 = org.apache.commons.math.util.FastMath.rint((-4.503599627370496E15d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.503599627370496E15d) + "'", double1 == (-4.503599627370496E15d));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 10);
        try {
            java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (-69));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        double double1 = org.apache.commons.math.util.FastMath.asinh(221206.6960055904d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 13.000000000010218d + "'", double1 == 13.000000000010218d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.8928831862356974d, (-0.7568024953079282d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0895288524039841d + "'", double2 == 1.0895288524039841d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        long long2 = org.apache.commons.math.util.FastMath.min(52L, (long) (-10));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-10L) + "'", long2 == (-10L));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 3900.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 53, (long) (-1105975869));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-58616721057L) + "'", long2 == (-58616721057L));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection3, false);
        java.lang.String str6 = nonMonotonousSequenceException5.toString();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1L), (java.lang.Number) 0.5018338600483341d, 0);
        java.lang.String str12 = nonMonotonousSequenceException11.toString();
        java.lang.Class<?> wildcardClass13 = nonMonotonousSequenceException11.getClass();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        boolean boolean15 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (100 < 0)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (100 < 0)"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (100 < 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (100 < 0)"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0.502 >= -1)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0.502 >= -1)"));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(37, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3700 + "'", int2 == 3700);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        int[] intArray0 = new int[] {};
        int[] intArray5 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int6 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray5);
        int[] intArray13 = new int[] { (byte) 0, (byte) 10, '#', (short) -1, (short) 1, 97 };
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray13);
        int[] intArray15 = new int[] {};
        int[] intArray20 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray20);
        int[] intArray27 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double28 = org.apache.commons.math.util.MathUtils.distance(intArray15, intArray27);
        try {
            double double29 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 56 + "'", int14 == 56);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        int int7 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 156L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.622625746075033E67d + "'", double1 == 5.622625746075033E67d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-2138030215));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 2.718281828459045d);
        double[] doubleArray27 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) (-1.0f));
        double[] doubleArray36 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) (-1.0f));
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray36);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 2.718281828459045d);
        double double42 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray27);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, 117.12813496338103d);
        int int45 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 139.51318994987582d + "'", double42 == 139.51318994987582d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1281864422) + "'", int45 == (-1281864422));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 52, 0, 1078820864);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        double double1 = org.apache.commons.math.util.FastMath.log(4.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3862943611198906d + "'", double1 == 1.3862943611198906d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-42L), (java.lang.Number) 1.7540558982543015d, (-1080582045));
        int int4 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1080582045) + "'", int4 == (-1080582045));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        int int2 = org.apache.commons.math.util.MathUtils.pow(3700, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1586495488 + "'", int2 == 1586495488);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(13.000000000010218d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 221206.6960055903d + "'", double1 == 221206.6960055903d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 6.451224E7f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(6.3508120580348555d, (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.1754060290174277d + "'", double2 == 3.1754060290174277d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1989426017);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 20532231);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 17.530653633889553d + "'", double1 == 17.530653633889553d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        double double2 = org.apache.commons.math.util.FastMath.min(2.7501303671488815d, 5730.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.7501303671488815d + "'", double2 == 2.7501303671488815d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 363.7393755555636d + "'", double1 == 363.7393755555636d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-1079574396L), (long) 33610500);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 12L + "'", long2 == 12L);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1624620833);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-69L), 195, 36);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        double double1 = org.apache.commons.math.util.FastMath.ulp(4.594700892207039d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 'a', (long) 3500);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3597L + "'", long2 == 3597L);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((-6.053272382792838d), 100.00000000000001d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.76087783926013d + "'", double2 == 100.76087783926013d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(2.6780404899442747d, (double) 197.0f, 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 53);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        double double1 = org.apache.commons.math.util.MathUtils.sign(2.7501303671488815d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        double double1 = org.apache.commons.math.util.FastMath.cos(2.4830062883006265d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7908581651269111d) + "'", double1 == (-0.7908581651269111d));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.9850853666260323d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1729268973851292d + "'", double1 == 0.1729268973851292d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-1281864422));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.28186445E9f + "'", float1 == 1.28186445E9f);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (byte) 10, (-1105975869));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1105975879 + "'", int2 == 1105975879);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 2L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0000000000000004d + "'", double1 == 2.0000000000000004d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.6929693744344998d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.12186934340514759d) + "'", double1 == (-0.12186934340514759d));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 12L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4849066497880004d + "'", double1 == 2.4849066497880004d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 1624620833L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray15);
        double[] doubleArray26 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) (-1.0f));
        double[] doubleArray35 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) (-1.0f));
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray35);
        double[] doubleArray45 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (double) (-1.0f));
        double double48 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray35, doubleArray45);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) (short) 1);
        double double51 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray58 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, (double) (-1.0f));
        double[] doubleArray67 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray69 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray67, (double) (-1.0f));
        double double70 = org.apache.commons.math.util.MathUtils.distance1(doubleArray58, doubleArray67);
        double[] doubleArray77 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray79 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray77, (double) (-1.0f));
        double double80 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray67, doubleArray77);
        double[] doubleArray82 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray67, (double) (short) 1);
        double double83 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray35, doubleArray67);
        double double84 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray35);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException88 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0f, (java.lang.Number) 64512240L, 63);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection89 = nonMonotonousSequenceException88.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15, orderDirection89, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not increasing (1 > -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 141.43549766589717d + "'", double18 == 141.43549766589717d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 141.43549766589717d + "'", double51 == 141.43549766589717d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection89 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection89.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.lcm((-5547412656154738688L), 5L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        double double1 = org.apache.commons.math.util.FastMath.asinh(3628800.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 15.797559753635479d + "'", double1 == 15.797559753635479d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-3014543340L), (double) (-8.8801882E8f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.01454334E9d) + "'", double2 == (-3.01454334E9d));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-968000650), (-69));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        double double1 = org.apache.commons.math.util.FastMath.signum(3.9889840465642745d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        double double1 = org.apache.commons.math.util.FastMath.ulp(27.479027144466286d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.552713678800501E-15d + "'", double1 == 3.552713678800501E-15d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 63, 0.9999999999999999d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.16814692820413768d + "'", double2 == 0.16814692820413768d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-968004150));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-968000650), 1080582145);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2048582795) + "'", int2 == (-2048582795));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        int int2 = org.apache.commons.math.util.FastMath.min((-454785511), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-454785511) + "'", int2 == (-454785511));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (short) 1, 37);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37 + "'", int2 == 37);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) (byte) 1, (-888018845));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-888018844) + "'", int2 == (-888018844));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 195, 35L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 230L + "'", long2 == 230L);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.5813788799911153d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1105975906, (-37));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 20532231);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(13260L, (long) 3700);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 16960L + "'", long2 == 16960L);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(1.8842131779592965E7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        java.lang.Class<?> wildcardClass7 = orderDirection6.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97, (java.lang.Number) 572.9577951308232d, (int) (byte) 0, orderDirection6, false);
        int int10 = nonMonotonousSequenceException9.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException9.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException9.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 197, number1, 9603, orderDirection12, true);
        boolean boolean15 = nonMonotonousSequenceException14.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(52);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((-0.9899924966004454d), 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(53.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.42404354048E11d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 25.681936411643644d + "'", double1 == 25.681936411643644d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-301454334));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        int int2 = org.apache.commons.math.util.FastMath.max(1079574528, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1079574528 + "'", int2 == 1079574528);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-279932959), 1987797057, 888019239);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-37));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 37.0d + "'", double1 == 37.0d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.5813788799911153d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        java.lang.Class<?> wildcardClass4 = orderDirection3.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97, (java.lang.Number) 572.9577951308232d, (int) (byte) 0, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection10, false);
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException6.getSuppressed();
        java.lang.String str15 = nonMonotonousSequenceException6.toString();
        java.lang.Throwable[] throwableArray16 = nonMonotonousSequenceException6.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.2250738585072014E-308d, (java.lang.Number) Float.NaN, 32);
        int int21 = nonMonotonousSequenceException20.getIndex();
        java.lang.Number number22 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number22, (java.lang.Number) 4.248699261236361d, (-1352038911));
        nonMonotonousSequenceException20.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException25);
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException20);
        java.lang.Number number28 = nonMonotonousSequenceException20.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (572.958 > 97)" + "'", str15.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (572.958 > 97)"));
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 32 + "'", int21 == 32);
        org.junit.Assert.assertEquals((float) number28, Float.NaN, 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(3.552713678800501E-15d, (double) 100L, 36);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 200.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 200.00000000000003d + "'", double1 == 200.00000000000003d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 0.01f, 5729.5779513082325d, 0.39912428462176963d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        int[] intArray0 = new int[] {};
        int[] intArray5 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int6 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray5);
        int[] intArray7 = new int[] {};
        int[] intArray12 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int13 = org.apache.commons.math.util.MathUtils.distanceInf(intArray7, intArray12);
        int int14 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray7);
        int[] intArray15 = new int[] {};
        int[] intArray20 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray20);
        int[] intArray27 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double28 = org.apache.commons.math.util.MathUtils.distance(intArray15, intArray27);
        int[] intArray29 = new int[] {};
        int[] intArray34 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int35 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray34);
        int[] intArray40 = new int[] { (byte) 1, '4', '#', 'a' };
        int int41 = org.apache.commons.math.util.MathUtils.distance1(intArray34, intArray40);
        int[] intArray42 = new int[] {};
        int[] intArray47 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int48 = org.apache.commons.math.util.MathUtils.distanceInf(intArray42, intArray47);
        int[] intArray54 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double55 = org.apache.commons.math.util.MathUtils.distance(intArray42, intArray54);
        int int56 = org.apache.commons.math.util.MathUtils.distanceInf(intArray40, intArray54);
        int int57 = org.apache.commons.math.util.MathUtils.distanceInf(intArray27, intArray54);
        int int58 = org.apache.commons.math.util.MathUtils.distanceInf(intArray7, intArray27);
        int[] intArray59 = new int[] {};
        int[] intArray64 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int65 = org.apache.commons.math.util.MathUtils.distanceInf(intArray59, intArray64);
        int[] intArray66 = new int[] {};
        int[] intArray71 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int72 = org.apache.commons.math.util.MathUtils.distanceInf(intArray66, intArray71);
        int int73 = org.apache.commons.math.util.MathUtils.distanceInf(intArray59, intArray66);
        int int74 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray66);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 195 + "'", int41 == 195);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 65 + "'", int56 == 65);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(3.9889840465642745d, 2.524630659933467d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(4.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 27.28991719712775d + "'", double1 == 27.28991719712775d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.9160150401636142d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 888019095L, (double) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.88019095E8d + "'", double2 == 8.88019095E8d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(2138030215, 14776336);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        double double1 = org.apache.commons.math.util.MathUtils.sign(200.00000000000003d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 1624620833, (long) 99);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 14621587497L + "'", long2 == 14621587497L);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.03494495037239d, (java.lang.Number) 0.6360918687915654d, (int) (short) 1);
        int int4 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        double double1 = org.apache.commons.math.util.FastMath.abs(4.882801922586371d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.882801922586371d + "'", double1 == 4.882801922586371d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.0411381226745244d, (double) ' ', 162.2340596929131d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        java.lang.Class<?> wildcardClass4 = orderDirection3.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97, (java.lang.Number) 572.9577951308232d, (int) (byte) 0, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection10, false);
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException12.getSuppressed();
        int int15 = nonMonotonousSequenceException12.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 31500);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31500 + "'", int2 == 31500);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection11, false);
        boolean boolean14 = nonMonotonousSequenceException13.getStrict();
        java.lang.String str15 = nonMonotonousSequenceException13.toString();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        java.lang.Class<?> wildcardClass17 = nonMonotonousSequenceException13.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException13.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = nonMonotonousSequenceException13.getDirection();
        java.lang.Class<?> wildcardClass20 = orderDirection19.getClass();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (100 < 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (100 < 0)"));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (100 < 0)" + "'", str15.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (100 < 0)"));
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray25 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) (-1.0f));
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray25);
        double[] doubleArray35 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) (-1.0f));
        double[] doubleArray44 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, (double) (-1.0f));
        double[] doubleArray53 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray55 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, (double) (-1.0f));
        double double56 = org.apache.commons.math.util.MathUtils.distance1(doubleArray44, doubleArray53);
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray53);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray37, doubleArray53);
        double double59 = org.apache.commons.math.util.MathUtils.distance(doubleArray25, doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 141.43549766589717d + "'", double57 == 141.43549766589717d);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 142.14267515422665d + "'", double59 == 142.14267515422665d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray15);
        double[] doubleArray26 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) (-1.0f));
        double[] doubleArray35 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) (-1.0f));
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray35);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, 2.718281828459045d);
        double[] doubleArray47 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, (double) (-1.0f));
        double[] doubleArray56 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray56, (double) (-1.0f));
        double double59 = org.apache.commons.math.util.MathUtils.distance1(doubleArray47, doubleArray56);
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, 2.718281828459045d);
        double double62 = org.apache.commons.math.util.MathUtils.distance(doubleArray40, doubleArray47);
        double double63 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        double double64 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray40);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection68 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException70 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection68, false);
        java.lang.Throwable[] throwableArray71 = nonMonotonousSequenceException70.getSuppressed();
        java.lang.String str72 = nonMonotonousSequenceException70.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection76 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException78 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection76, false);
        boolean boolean79 = nonMonotonousSequenceException78.getStrict();
        java.lang.String str80 = nonMonotonousSequenceException78.toString();
        nonMonotonousSequenceException70.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException78);
        java.lang.Class<?> wildcardClass82 = nonMonotonousSequenceException78.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection83 = nonMonotonousSequenceException78.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray40, orderDirection83, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not decreasing (-0.014 < 1.359)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 141.43549766589717d + "'", double18 == 141.43549766589717d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 139.51318994987582d + "'", double62 == 139.51318994987582d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 1.9223077160213498d + "'", double63 == 1.9223077160213498d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 201.22735253497177d + "'", double64 == 201.22735253497177d);
        org.junit.Assert.assertTrue("'" + orderDirection68 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection68.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray71);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (100 < 0)" + "'", str72.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (100 < 0)"));
        org.junit.Assert.assertTrue("'" + orderDirection76 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection76.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (100 < 0)" + "'", str80.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (100 < 0)"));
        org.junit.Assert.assertNotNull(wildcardClass82);
        org.junit.Assert.assertTrue("'" + orderDirection83 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection83.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-42L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, (double) 1105975906);
        double[] doubleArray18 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) (-1.0f));
        double[] doubleArray27 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) (-1.0f));
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray27);
        double[] doubleArray37 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, (double) (-1.0f));
        double double40 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray27, doubleArray37);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) (short) 1);
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 0.9440892412430648d);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.7071774883294859d + "'", double9 == 0.7071774883294859d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 141.43549766589717d + "'", double43 == 141.43549766589717d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) (-1.0f));
        double[] doubleArray16 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) (-1.0f));
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray16);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, 2.718281828459045d);
        double[] doubleArray28 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, (double) (-1.0f));
        double[] doubleArray37 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, (double) (-1.0f));
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray37);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, 2.718281828459045d);
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray21, doubleArray28);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, (-0.9999999999999999d));
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 139.51318994987582d + "'", double43 == 139.51318994987582d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(65.99621212121211d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1518511953597423d + "'", double1 == 1.1518511953597423d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        int int2 = org.apache.commons.math.util.MathUtils.pow(97, 104L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-755673343) + "'", int2 == (-755673343));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-454785511L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.54785511E8d + "'", double1 == 4.54785511E8d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1300L, (float) 36);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 36.0f + "'", float2 == 36.0f);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        double double2 = org.apache.commons.math.util.FastMath.pow(13.000000000010218d, (-0.4254879871148926d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3357611821453924d + "'", double2 == 0.3357611821453924d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1L, (java.lang.Number) 100, 0);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        boolean boolean12 = nonMonotonousSequenceException10.getStrict();
        java.lang.Number number13 = nonMonotonousSequenceException10.getPrevious();
        java.lang.Number number14 = nonMonotonousSequenceException10.getArgument();
        java.lang.String str15 = nonMonotonousSequenceException10.toString();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 100 + "'", number13.equals(100));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 1L + "'", number14.equals(1L));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (100 >= 1)" + "'", str15.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (100 >= 1)"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(2138030283, (-97));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        int int2 = org.apache.commons.math.util.FastMath.max(2138030283, 1080582145);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2138030283 + "'", int2 == 2138030283);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        double double2 = org.apache.commons.math.util.FastMath.min(1.5539694636287837d, 4.641588833612779d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5539694636287837d + "'", double2 == 1.5539694636287837d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((-454785511L), (long) (-454785511));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test268");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double[] doubleArray24 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) (-1.0f));
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray24);
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray24);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, 4.143134726391533d);
        double[] doubleArray38 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, (double) (-1.0f));
        double[] doubleArray47 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, (double) (-1.0f));
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray47);
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, 2.718281828459045d);
        double[] doubleArray59 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray59, (double) (-1.0f));
        double[] doubleArray68 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray70 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray68, (double) (-1.0f));
        double double71 = org.apache.commons.math.util.MathUtils.distance1(doubleArray59, doubleArray68);
        double[] doubleArray73 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray59, 2.718281828459045d);
        double double74 = org.apache.commons.math.util.MathUtils.distance(doubleArray52, doubleArray59);
        double[] doubleArray76 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray52, (-0.9999999999999999d));
        double[] doubleArray78 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray52, (double) 99.0f);
        double[] doubleArray80 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray78, (double) 1989426017);
        double double81 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray78);
        double[] doubleArray88 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray90 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray88, (double) (-1.0f));
        double double91 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray88);
        double double92 = org.apache.commons.math.util.MathUtils.distance(doubleArray24, doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 141.43549766589717d + "'", double28 == 141.43549766589717d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 139.51318994987582d + "'", double74 == 139.51318994987582d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 103.02000000000001d + "'", double81 == 103.02000000000001d);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 141.43549766589717d + "'", double91 == 141.43549766589717d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test269");
        double[] doubleArray0 = null;
        double[] doubleArray1 = null;
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test270");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(2.384185791015625E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.384185791015625E-7d + "'", double1 == 2.384185791015625E-7d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        int[] intArray0 = new int[] {};
        int[] intArray5 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int6 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray5);
        int[] intArray7 = new int[] {};
        int[] intArray12 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int13 = org.apache.commons.math.util.MathUtils.distanceInf(intArray7, intArray12);
        int int14 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray7);
        int[] intArray15 = new int[] {};
        int[] intArray20 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray20);
        int[] intArray28 = new int[] { (byte) 0, (byte) 10, '#', (short) -1, (short) 1, 97 };
        int int29 = org.apache.commons.math.util.MathUtils.distance1(intArray20, intArray28);
        int[] intArray30 = new int[] {};
        int[] intArray35 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int36 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray35);
        int[] intArray42 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double43 = org.apache.commons.math.util.MathUtils.distance(intArray30, intArray42);
        double double44 = org.apache.commons.math.util.MathUtils.distance(intArray20, intArray42);
        int[] intArray45 = new int[] {};
        int[] intArray50 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int51 = org.apache.commons.math.util.MathUtils.distanceInf(intArray45, intArray50);
        int[] intArray56 = new int[] { (byte) 1, '4', '#', 'a' };
        int int57 = org.apache.commons.math.util.MathUtils.distance1(intArray50, intArray56);
        int[] intArray58 = new int[] {};
        int[] intArray63 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int64 = org.apache.commons.math.util.MathUtils.distanceInf(intArray58, intArray63);
        int[] intArray70 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double71 = org.apache.commons.math.util.MathUtils.distance(intArray58, intArray70);
        int int72 = org.apache.commons.math.util.MathUtils.distanceInf(intArray56, intArray70);
        double double73 = org.apache.commons.math.util.MathUtils.distance(intArray20, intArray56);
        double double74 = org.apache.commons.math.util.MathUtils.distance(intArray7, intArray56);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 56 + "'", int29 == 56);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 121.51131634543344d + "'", double44 == 121.51131634543344d);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 195 + "'", int57 == 195);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 65 + "'", int72 == 65);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 117.12813496338103d + "'", double73 == 117.12813496338103d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test272");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 2.718281828459045d);
        double[] doubleArray27 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) (-1.0f));
        double[] doubleArray36 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) (-1.0f));
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray36);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 2.718281828459045d);
        double double42 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray27);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (-0.9999999999999999d));
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) 99.0f);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) 1989426017);
        double[] doubleArray55 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray57 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray55, (double) (-1.0f));
        double[] doubleArray64 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray64, (double) (-1.0f));
        double double67 = org.apache.commons.math.util.MathUtils.distance1(doubleArray55, doubleArray64);
        double[] doubleArray69 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray55, 2.718281828459045d);
        double[] doubleArray76 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray78 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray76, (double) (-1.0f));
        double[] doubleArray85 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray87 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray85, (double) (-1.0f));
        double double88 = org.apache.commons.math.util.MathUtils.distance1(doubleArray76, doubleArray85);
        double[] doubleArray90 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray76, 2.718281828459045d);
        double double91 = org.apache.commons.math.util.MathUtils.distance(doubleArray69, doubleArray76);
        double[] doubleArray93 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray69, 10.0d);
        double[] doubleArray95 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray93, 57.29577951308232d);
        double double96 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray46, doubleArray95);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 139.51318994987582d + "'", double42 == 139.51318994987582d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 139.51318994987582d + "'", double91 == 139.51318994987582d);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertNotNull(doubleArray95);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 20.852110243458846d + "'", double96 == 20.852110243458846d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        double double1 = org.apache.commons.math.util.FastMath.rint(5.286736667635593d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.0d + "'", double1 == 5.0d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 156);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test275");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 32.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.948148009134034E13d + "'", double1 == 3.948148009134034E13d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-1281864422));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test277");
        double double1 = org.apache.commons.math.util.FastMath.log1p(104.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.653960350157523d + "'", double1 == 4.653960350157523d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        long long1 = org.apache.commons.math.util.FastMath.round(52.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 52L + "'", long1 == 52L);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.010050166858404251d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.010050336046872888d + "'", double1 == 0.010050336046872888d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test280");
        int int1 = org.apache.commons.math.util.MathUtils.hash(4.573022699008911d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 913450316 + "'", int1 == 913450316);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        java.lang.Class<?> wildcardClass4 = orderDirection3.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97, (java.lang.Number) 572.9577951308232d, (int) (byte) 0, orderDirection3, false);
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException6.getSuppressed();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException6.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) Float.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(37, 1079574528);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1079574565 + "'", int2 == 1079574565);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        double double2 = org.apache.commons.math.util.FastMath.pow(3.4965075614664802d, 1.352038910391644E9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 52, 1.0496616655455318d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.012266489340167615d + "'", double2 == 0.012266489340167615d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-1080582045));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test289");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(913450316, 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.13450316E8d + "'", double2 == 9.13450316E8d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test290");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 10, (long) 65);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test291");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 210, 20L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 190L + "'", long2 == 190L);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 1399733633L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 37413.01421965357d + "'", double1 == 37413.01421965357d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test293");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(1989426017, (-100L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(1.7763568394002505E-15d, (-53));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.9721522630525295E-31d + "'", double2 == 1.9721522630525295E-31d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-888018845), (-968000650));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test296");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(5.206879716514544E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.206879716514545E22d + "'", double1 == 5.206879716514545E22d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test297");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) ' ');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test298");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 97.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(5.818647867496961d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.818647867496962d + "'", double1 == 5.818647867496962d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test300");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double[] doubleArray24 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) (-1.0f));
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray24);
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray24);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, 4.143134726391533d);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, 10.423955077173417d);
        double[] doubleArray40 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, (double) (-1.0f));
        double[] doubleArray49 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, (double) (-1.0f));
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray49);
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, 2.718281828459045d);
        double[] doubleArray61 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray61, (double) (-1.0f));
        double[] doubleArray70 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray72 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray70, (double) (-1.0f));
        double double73 = org.apache.commons.math.util.MathUtils.distance1(doubleArray61, doubleArray70);
        double[] doubleArray75 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray61, 2.718281828459045d);
        double double76 = org.apache.commons.math.util.MathUtils.distance(doubleArray54, doubleArray61);
        double[] doubleArray78 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray54, 117.12813496338103d);
        double double79 = org.apache.commons.math.util.MathUtils.distance1(doubleArray33, doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 141.43549766589717d + "'", double28 == 141.43549766589717d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 139.51318994987582d + "'", double76 == 139.51318994987582d);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 7.85978671368866d + "'", double79 == 7.85978671368866d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1352038911, 1105975906);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-286962687) + "'", int2 == (-286962687));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        double double1 = org.apache.commons.math.util.FastMath.log10(8.853665407629286d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9471231053584359d + "'", double1 == 0.9471231053584359d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test303");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(3.948148009134034E13d, 1624620833, 20532231);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection3, false);
        java.lang.String str6 = nonMonotonousSequenceException5.toString();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1L), (java.lang.Number) 0.5018338600483341d, 0);
        java.lang.String str12 = nonMonotonousSequenceException11.toString();
        java.lang.Class<?> wildcardClass13 = nonMonotonousSequenceException11.getClass();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        java.lang.Number number15 = nonMonotonousSequenceException11.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (100 < 0)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (100 < 0)"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (100 < 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (100 < 0)"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0.502 >= -1)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0.502 >= -1)"));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 0.5018338600483341d + "'", number15.equals(0.5018338600483341d));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test305");
        double double1 = org.apache.commons.math.util.FastMath.log10(99.99999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 68, (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 68L + "'", long2 == 68L);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test307");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(102.70899308565303d, 0.9850853666260323d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.1780281707796547d + "'", double2 == 2.1780281707796547d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test308");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(9.995649622311774E8d, (double) 0.01f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test309");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-1105975906), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1105975906 + "'", int2 == 1105975906);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test310");
        double double1 = org.apache.commons.math.util.FastMath.signum((-5.118394377331518E10d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test311");
        float float1 = org.apache.commons.math.util.FastMath.abs(1.39973363E9f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.39973363E9f + "'", float1 == 1.39973363E9f);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test312");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        java.lang.Class<?> wildcardClass4 = orderDirection3.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97, (java.lang.Number) 572.9577951308232d, (int) (byte) 0, orderDirection3, false);
        int int7 = nonMonotonousSequenceException6.getIndex();
        int int8 = nonMonotonousSequenceException6.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection12, false);
        java.lang.String str15 = nonMonotonousSequenceException14.toString();
        java.lang.Number number16 = nonMonotonousSequenceException14.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection20, false);
        boolean boolean23 = nonMonotonousSequenceException22.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1L, (java.lang.Number) 100, 0);
        nonMonotonousSequenceException22.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException27);
        boolean boolean29 = nonMonotonousSequenceException27.getStrict();
        nonMonotonousSequenceException14.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException27);
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException27);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (100 < 0)" + "'", str15.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (100 < 0)"));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 100.0f + "'", number16.equals(100.0f));
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection20.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test313");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-1), 530L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-530L) + "'", long2 == (-530L));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test314");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-454785511));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test315");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(76.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4354.479242994256d + "'", double1 == 4354.479242994256d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test316");
        double double1 = org.apache.commons.math.util.FastMath.signum(3781.30441839558d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test317");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) 1, (float) 3500L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3500.0f + "'", float2 == 3500.0f);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test318");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1167939852, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test319");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) ' ');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test320");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(4.158638853279167d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.0d + "'", double1 == 32.0d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test321");
        long long2 = org.apache.commons.math.util.FastMath.max((-1079574396L), (long) (-2138030215));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1079574396L) + "'", long2 == (-1079574396L));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test322");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, (double) (-10.0f));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test323");
        int[] intArray0 = new int[] {};
        int[] intArray5 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int6 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray5);
        int[] intArray7 = new int[] {};
        int[] intArray12 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int13 = org.apache.commons.math.util.MathUtils.distanceInf(intArray7, intArray12);
        int[] intArray20 = new int[] { (byte) 0, (byte) 10, '#', (short) -1, (short) 1, 97 };
        int int21 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray20);
        int[] intArray22 = new int[] {};
        int[] intArray27 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int28 = org.apache.commons.math.util.MathUtils.distanceInf(intArray22, intArray27);
        int[] intArray34 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double35 = org.apache.commons.math.util.MathUtils.distance(intArray22, intArray34);
        double double36 = org.apache.commons.math.util.MathUtils.distance(intArray12, intArray34);
        int[] intArray37 = new int[] {};
        int[] intArray42 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int43 = org.apache.commons.math.util.MathUtils.distanceInf(intArray37, intArray42);
        int[] intArray48 = new int[] { (byte) 1, '4', '#', 'a' };
        int int49 = org.apache.commons.math.util.MathUtils.distance1(intArray42, intArray48);
        int[] intArray50 = new int[] {};
        int[] intArray55 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int56 = org.apache.commons.math.util.MathUtils.distanceInf(intArray50, intArray55);
        int[] intArray62 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double63 = org.apache.commons.math.util.MathUtils.distance(intArray50, intArray62);
        int int64 = org.apache.commons.math.util.MathUtils.distanceInf(intArray48, intArray62);
        double double65 = org.apache.commons.math.util.MathUtils.distance(intArray12, intArray48);
        int[] intArray66 = new int[] {};
        int[] intArray71 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int72 = org.apache.commons.math.util.MathUtils.distanceInf(intArray66, intArray71);
        int[] intArray77 = new int[] { (byte) 1, '4', '#', 'a' };
        int int78 = org.apache.commons.math.util.MathUtils.distance1(intArray71, intArray77);
        int[] intArray79 = new int[] {};
        int[] intArray84 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int85 = org.apache.commons.math.util.MathUtils.distanceInf(intArray79, intArray84);
        int[] intArray91 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double92 = org.apache.commons.math.util.MathUtils.distance(intArray79, intArray91);
        int int93 = org.apache.commons.math.util.MathUtils.distanceInf(intArray77, intArray91);
        int int94 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray91);
        int int95 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray91);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 56 + "'", int21 == 56);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 121.51131634543344d + "'", double36 == 121.51131634543344d);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 195 + "'", int49 == 195);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 65 + "'", int64 == 65);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 117.12813496338103d + "'", double65 == 117.12813496338103d);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 195 + "'", int78 == 195);
        org.junit.Assert.assertNotNull(intArray79);
        org.junit.Assert.assertNotNull(intArray84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
        org.junit.Assert.assertNotNull(intArray91);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 65 + "'", int93 == 65);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 197 + "'", int94 == 197);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 197 + "'", int95 == 197);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test324");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(69L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test325");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 10);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (int) (byte) 100);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 53);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 0);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (int) (short) 10);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (int) (byte) 100);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) 0);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (int) (short) 10);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (int) (byte) 100);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger20);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, bigInteger20);
        java.math.BigInteger bigInteger25 = null;
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, (long) 0);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (int) (short) 10);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, (int) (byte) 100);
        java.math.BigInteger bigInteger32 = null;
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, (long) 0);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, (int) (short) 10);
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, (int) (byte) 100);
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, bigInteger36);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, bigInteger39);
        try {
            java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger39, (-1105975879L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(bigInteger40);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test326");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) (-1.0f));
        double[] doubleArray16 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) (-1.0f));
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray16);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, 2.718281828459045d);
        double[] doubleArray28 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, (double) (-1.0f));
        double[] doubleArray37 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, (double) (-1.0f));
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray37);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, 2.718281828459045d);
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray21, doubleArray28);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, 10.0d);
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, 57.29577951308232d);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, 8938.141604040842d);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 139.51318994987582d + "'", double43 == 139.51318994987582d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test327");
        double double1 = org.apache.commons.math.util.FastMath.tan((-9.889466189365882d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.501301452122687d) + "'", double1 == (-0.501301452122687d));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test328");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1987797057, (double) (-454785511L), (double) (-2L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test329");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test330");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0f, (java.lang.Number) 64512240L, 63);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        int int6 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 63 + "'", int6 == 63);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test331");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1079574565, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1079574565 + "'", int2 == 1079574565);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test332");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-893328343), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test333");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-286962687));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test334");
        double double1 = org.apache.commons.math.util.FastMath.floor(9.848857801796104d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.0d + "'", double1 == 9.0d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test335");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-53), 913450316);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test336");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.570027096177388d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test337");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 3260811333912044985L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.6911894063113416E16d + "'", double1 == 5.6911894063113416E16d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test338");
        double double2 = org.apache.commons.math.util.FastMath.pow(20.852110243458846d, 1.556798099474812d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 113.14887287996874d + "'", double2 == 113.14887287996874d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test339");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-4125825972L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test340");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-2072794013720961147L), (double) (-10));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.830280554398157E-184d + "'", double2 == 6.830280554398157E-184d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test341");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 9603, (-9218868437227405312L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test342");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(52L, (long) (-69));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test343");
        double double2 = org.apache.commons.math.util.FastMath.min(0.9972233523474408d, 0.08139081311424569d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.08139081311424569d + "'", double2 == 0.08139081311424569d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test344");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1L), (java.lang.Number) 0.5018338600483341d, 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Class<?> wildcardClass5 = nonMonotonousSequenceException3.getClass();
        java.lang.Number number6 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0.502 >= -1)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0.502 >= -1)"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.5018338600483341d + "'", number6.equals(0.5018338600483341d));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test345");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 2.718281828459045d);
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray28 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, (double) (-1.0f));
        double[] doubleArray37 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, (double) (-1.0f));
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray37);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, 2.718281828459045d);
        double[] doubleArray49 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, (double) (-1.0f));
        double[] doubleArray58 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, (double) (-1.0f));
        double double61 = org.apache.commons.math.util.MathUtils.distance1(doubleArray49, doubleArray58);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, 2.718281828459045d);
        double double64 = org.apache.commons.math.util.MathUtils.distance(doubleArray42, doubleArray49);
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray42, 10.0d);
        double[] doubleArray68 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray66, 57.29577951308232d);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 141.43549766589717d + "'", double21 == 141.43549766589717d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 139.51318994987582d + "'", double64 == 139.51318994987582d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test346");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-2072794013720961303L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test347");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 1105975879);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.823993931490484d + "'", double1 == 20.823993931490484d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test348");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.0478873995271376d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test349");
        double double1 = org.apache.commons.math.util.FastMath.signum(5.286736667635593d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test350");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(913450316, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test351");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-0.5486677646162761d), 1.4603914750271216d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.3593834400241171d) + "'", double2 == (-0.3593834400241171d));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test352");
        double double1 = org.apache.commons.math.util.FastMath.acos((-6.6256120565002711E18d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test353");
        int int2 = org.apache.commons.math.util.FastMath.min(31500, (-301454334));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-301454334) + "'", int2 == (-301454334));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test354");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (-888018845L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test355");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-984724751L), (long) 14776336);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-14550623788292336L) + "'", long2 == (-14550623788292336L));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test356");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1884947935), (float) 1987797057);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.88494797E9f) + "'", float2 == (-1.88494797E9f));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test357");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 99.50000000000001d, (java.lang.Number) 2.993222846126381d, (int) (byte) 0, orderDirection9, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 141.43549766589715d, (java.lang.Number) 3500.0f, (-1352038911), orderDirection9, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 3.4657359027997265d, (-1352038911), orderDirection9, true);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test358");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.556798099474812d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test359");
        double double1 = org.apache.commons.math.util.FastMath.cos(20.37562652865567d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0447108096889517d + "'", double1 == 0.0447108096889517d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test360");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) (-62));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.219178334370727E26d + "'", double1 == 4.219178334370727E26d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test361");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 197, (double) 3500.0f, (double) (-1080582108));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test362");
        float float2 = org.apache.commons.math.util.FastMath.max(1.0f, (float) (-100L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-100.0f) + "'", float2 == (-100.0f));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test363");
        double double1 = org.apache.commons.math.util.FastMath.expm1(32.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.896296018267969E13d + "'", double1 == 7.896296018267969E13d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test364");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) ' ');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 32.0f + "'", float1 == 32.0f);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test365");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(9.848857801796104d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1718949962020731d + "'", double1 == 0.1718949962020731d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test366");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 1624620833);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.90168747252309d + "'", double1 == 21.90168747252309d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test367");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(99, 156);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test368");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(97, (-69));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test369");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 36, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1260L + "'", long2 == 1260L);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test370");
        float float1 = org.apache.commons.math.util.MathUtils.sign((-4.54785504E8f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test371");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 2.225073858507202E-308d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test372");
        double double1 = org.apache.commons.math.util.FastMath.cos(43.66827237527655d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9510980675063472d + "'", double1 == 0.9510980675063472d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test373");
        double double2 = org.apache.commons.math.util.FastMath.atan2(268.0d, (-0.9991050130774393d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5745243133045663d + "'", double2 == 1.5745243133045663d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test374");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) (-100L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1067909120) + "'", int1 == (-1067909120));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test375");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 9.848857801796104d, (java.lang.Number) 4.248699261236361d, 100, orderDirection6, true);
        int int11 = nonMonotonousSequenceException10.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1L, (java.lang.Number) 100, 0);
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test376");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(961.1859962243583d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 961.1859962243584d + "'", double1 == 961.1859962243584d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test377");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 1079574628);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test378");
        double double2 = org.apache.commons.math.util.FastMath.min(349.9541180407703d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test379");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 2.718281828459045d);
        double[] doubleArray27 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) (-1.0f));
        double[] doubleArray36 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) (-1.0f));
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray36);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 2.718281828459045d);
        double double42 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray27);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (-0.9999999999999999d));
        double[] doubleArray51 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, (double) (-1.0f));
        double[] doubleArray60 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) (-1.0f));
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray51, doubleArray60);
        double[] doubleArray70 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray72 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray70, (double) (-1.0f));
        double double73 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray60, doubleArray70);
        double[] doubleArray75 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) (short) 1);
        double double76 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray44, doubleArray60);
        double[] doubleArray83 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray85 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray83, (double) (-1.0f));
        double[] doubleArray92 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray94 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray92, (double) (-1.0f));
        double double95 = org.apache.commons.math.util.MathUtils.distance1(doubleArray83, doubleArray92);
        double[] doubleArray97 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray83, 2.718281828459045d);
        double double98 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray83);
        double double99 = org.apache.commons.math.util.MathUtils.distance(doubleArray60, doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 139.51318994987582d + "'", double42 == 139.51318994987582d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 100.50000000000001d + "'", double76 == 100.50000000000001d);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 0.0d + "'", double95 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray97);
        org.junit.Assert.assertTrue("'" + double98 + "' != '" + 141.43549766589717d + "'", double98 == 141.43549766589717d);
        org.junit.Assert.assertTrue("'" + double99 + "' != '" + 0.0d + "'", double99 == 0.0d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test380");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (-4125825972L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test381");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1L, (-2L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2L) + "'", long2 == (-2L));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test382");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-1105975869), (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1105975869L) + "'", long2 == (-1105975869L));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test383");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.16814692820413768d, (double) 2138030215, (double) (-2138030215));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test384");
        int int2 = org.apache.commons.math.util.FastMath.min(1080582144, (-454785511));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-454785511) + "'", int2 == (-454785511));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test385");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1252588625290418901L), (java.lang.Number) 99.00000000000001d, (-2048582795));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test386");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-1105975869), 1987797057);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test387");
        long long1 = org.apache.commons.math.util.MathUtils.sign(13201L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test388");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(63, 1399733633);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test389");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) (-1.0f));
        double[] doubleArray16 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) (-1.0f));
        double[] doubleArray25 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) (-1.0f));
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray25);
        double[] doubleArray35 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) (-1.0f));
        double double38 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray25, doubleArray35);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) (short) 1);
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) 1L);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray9, doubleArray25);
        double[] doubleArray51 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, (double) (-1.0f));
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray51);
        double[] doubleArray61 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray61, (double) (-1.0f));
        double double64 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray61);
        double double65 = org.apache.commons.math.util.MathUtils.distance1(doubleArray51, doubleArray61);
        double double66 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray25, doubleArray51);
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 141.43549766589717d + "'", double41 == 141.43549766589717d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 141.43549766589717d + "'", double54 == 141.43549766589717d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 141.43549766589717d + "'", double64 == 141.43549766589717d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test390");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-301454334), (-279932959));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test391");
        int int2 = org.apache.commons.math.util.MathUtils.pow(888019239, 279932959L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 346568599 + "'", int2 == 346568599);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test392");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1399733633, 4L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1407088129 + "'", int2 == 1407088129);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test393");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(32856.879462298304d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1882560.5211597665d + "'", double1 == 1882560.5211597665d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test394");
        long long1 = org.apache.commons.math.util.FastMath.abs(1624620886L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1624620886L + "'", long1 == 1624620886L);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test395");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 195, 230L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 425L + "'", long2 == 425L);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test396");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) -1, (java.lang.Number) Float.NaN, (int) (byte) 10, orderDirection6, false);
        java.lang.Number number11 = nonMonotonousSequenceException10.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException10.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertEquals((float) number11, Float.NaN, 0);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test397");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 10);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (int) (short) 10);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger9);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (int) (short) 10);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) 0);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (int) (short) 10);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger20);
        java.math.BigInteger bigInteger22 = null;
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (long) 0);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, (int) (short) 10);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, bigInteger24);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger28);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test398");
        long long1 = org.apache.commons.math.util.MathUtils.factorial(1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test399");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-1105975869));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test400");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(20532231, 2138030215);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test401");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 10);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (int) (short) 10);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger9);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (int) (short) 10);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger13);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger10, (java.lang.Number) 10.0f, 1399733633);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 82.83038029612084d, (java.lang.Number) 6.691673596021348E41d, (-10));
        nonMonotonousSequenceException19.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException23);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test402");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        java.lang.Class<?> wildcardClass4 = orderDirection3.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97, (java.lang.Number) 572.9577951308232d, (int) (byte) 0, orderDirection3, false);
        int int7 = nonMonotonousSequenceException6.getIndex();
        java.lang.String str8 = nonMonotonousSequenceException6.toString();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (572.958 > 97)" + "'", str8.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (572.958 > 97)"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test403");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) -1, (java.lang.Number) Float.NaN, (int) (byte) 10, orderDirection6, false);
        java.lang.String str11 = nonMonotonousSequenceException10.toString();
        boolean boolean12 = nonMonotonousSequenceException10.getStrict();
        java.lang.Number number13 = nonMonotonousSequenceException10.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        java.lang.Class<?> wildcardClass18 = orderDirection17.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97, (java.lang.Number) 572.9577951308232d, (int) (byte) 0, orderDirection17, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException26 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection24, false);
        nonMonotonousSequenceException20.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException26);
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException20);
        int int29 = nonMonotonousSequenceException10.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not decreasing (� < -1)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not decreasing (� < -1)"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertEquals((float) number13, Float.NaN, 0);
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + orderDirection24 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection24.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test404");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 68L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.404276049931741E29d + "'", double1 == 3.404276049931741E29d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test405");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-0.1726037463d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.17175799972022923d) + "'", double1 == (-0.17175799972022923d));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test406");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.0d + "'", double1 == 97.0d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test407");
        double double1 = org.apache.commons.math.util.FastMath.exp(13260.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test408");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test409");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1080582108), 1075970048);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test410");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-1080582108));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test411");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(9.848857801796104d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.848857801796106d + "'", double1 == 9.848857801796106d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test412");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray25 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) (-1.0f));
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray25);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (short) 1);
        double double31 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, 0.9440892412430648d);
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) 59L);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 141.43549766589717d + "'", double31 == 141.43549766589717d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test413");
        double double2 = org.apache.commons.math.util.FastMath.min(203.70643862336212d, 0.3357611821453924d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3357611821453924d + "'", double2 == 0.3357611821453924d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test414");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(0L, 1300L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1300L) + "'", long2 == (-1300L));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test415");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(3700);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test416");
        double double1 = org.apache.commons.math.util.FastMath.exp((-0.9499601814350958d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3867564232336413d + "'", double1 == 0.3867564232336413d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test417");
        double double1 = org.apache.commons.math.util.FastMath.sinh(117.12813496338103d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.6903936519909362E50d + "'", double1 == 3.6903936519909362E50d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test418");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (byte) 100, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test419");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-2138030215), 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test420");
        int int1 = org.apache.commons.math.util.MathUtils.hash(1300.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1083461632 + "'", int1 == 1083461632);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test421");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(63, 52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.15790256823E11d + "'", double2 == 6.15790256823E11d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test422");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(0L, 1560L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1560L) + "'", long2 == (-1560L));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test423");
        java.lang.Number number10 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, number10, 0, orderDirection12, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52L, (java.lang.Number) 13L, 1989426017, orderDirection12, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8.960719776347302d, (java.lang.Number) 8.960719776347302d, (int) (byte) 100, orderDirection12, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5.288241522117258d, (java.lang.Number) 9.0d, (int) ' ', orderDirection12, false);
        boolean boolean21 = nonMonotonousSequenceException20.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test424");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(963641344, (-1080582108));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test425");
        int int1 = org.apache.commons.math.util.FastMath.abs(13);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test426");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1399733633L, 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.39973363E9f + "'", float2 == 1.39973363E9f);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test427");
        double double1 = org.apache.commons.math.util.FastMath.asinh(200.00000000000003d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.99147079704939d + "'", double1 == 5.99147079704939d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test428");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 2.718281828459045d);
        double[] doubleArray27 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) (-1.0f));
        double[] doubleArray36 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) (-1.0f));
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray36);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 2.718281828459045d);
        double double42 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray27);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, 10.0d);
        int int45 = org.apache.commons.math.util.MathUtils.hash(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 139.51318994987582d + "'", double42 == 139.51318994987582d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 354302819 + "'", int45 == 354302819);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test429");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.0d, 156);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test430");
        int int1 = org.apache.commons.math.util.MathUtils.sign(53);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test431");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 346568599);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test432");
        java.lang.Number number10 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, number10, 0, orderDirection12, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.665201168491711d, (java.lang.Number) 0.6931471784987917d, (-1), orderDirection12, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.6569141418449421d), (java.lang.Number) 1.1102230246251565E-16d, (int) (short) 10, orderDirection12, true);
        java.lang.Class<?> wildcardClass19 = orderDirection12.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.641588833612779d, (java.lang.Number) 0.0f, 779127810, orderDirection12, false);
        java.lang.Number number22 = nonMonotonousSequenceException21.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 4.641588833612779d + "'", number22.equals(4.641588833612779d));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test433");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) ' ', 354302819);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 354302851 + "'", int2 == 354302851);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test434");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (short) -1, 1080582145);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test435");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(52L, (long) 1080582145);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 56190271540L + "'", long2 == 56190271540L);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test436");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test437");
        double double1 = org.apache.commons.math.util.FastMath.atan(75.69676347110223d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5575864907744197d + "'", double1 == 1.5575864907744197d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test438");
        double double1 = org.apache.commons.math.util.FastMath.sinh(4.944515159673473E42d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test439");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test440");
        double double1 = org.apache.commons.math.util.MathUtils.sign(2.6780404899442747d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test441");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray25 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) (-1.0f));
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray25);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (short) 1);
        double double31 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) 1L);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        java.lang.Class<?> wildcardClass35 = doubleArray33.getClass();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 141.43549766589717d + "'", double31 == 141.43549766589717d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.7071774883294859d + "'", double34 == 0.7071774883294859d);
        org.junit.Assert.assertNotNull(wildcardClass35);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test442");
        double double1 = org.apache.commons.math.util.FastMath.expm1(8.961879029114238d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7799.000128205128d + "'", double1 == 7799.000128205128d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test443");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-968000660L), (float) 1105975879);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-9.6800064E8f) + "'", float2 == (-9.6800064E8f));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test444");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, 1586495488, 21);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test445");
        double double1 = org.apache.commons.math.util.FastMath.tan(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test446");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 3900, 69L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3969L + "'", long2 == 3969L);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test447");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) (-37), 74285528);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.5119022016285825E143d) + "'", double2 == (-4.5119022016285825E143d));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test448");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(2979.3805346802806d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test449");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1075970048);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test450");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 10);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (int) (byte) 100);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (int) (short) 10);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (int) (byte) 100);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 53);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) 0);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (int) (short) 10);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (int) (byte) 100);
        java.math.BigInteger bigInteger23 = null;
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, (long) 0);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, (int) (short) 10);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (int) (byte) 100);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, bigInteger27);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger27);
        java.math.BigInteger bigInteger32 = null;
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, (long) 0);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, (int) (short) 10);
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, (int) (byte) 100);
        java.math.BigInteger bigInteger39 = null;
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger39, (long) 0);
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger41, (int) (short) 10);
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger43, (int) (byte) 100);
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, bigInteger43);
        java.math.BigInteger bigInteger47 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger46);
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger47);
        org.junit.Assert.assertNotNull(bigInteger48);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test451");
        float float2 = org.apache.commons.math.util.MathUtils.round((-62.0f), 1586495488);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test452");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (short) 100, 963641344);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test453");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray15);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (1 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 141.43549766589717d + "'", double18 == 141.43549766589717d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test454");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.07051436688301507d, (-6.053272382792838d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test455");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 36L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test456");
        double double1 = org.apache.commons.math.util.FastMath.acosh(34.99999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.248291097914389d + "'", double1 == 4.248291097914389d);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test457");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1, 1162674021347622912L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test458");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        double[] doubleArray16 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) (-1.0f));
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double[] doubleArray26 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) (-1.0f));
        double[] doubleArray35 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) (-1.0f));
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray35);
        double[] doubleArray45 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (double) (-1.0f));
        double double48 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray35, doubleArray45);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) (short) 1);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray50);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray16);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (1 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.7071774883294859d + "'", double9 == 0.7071774883294859d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 141.43549766589717d + "'", double19 == 141.43549766589717d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test459");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-21.999999999999996d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.7924564230657895E9d) + "'", double1 == (-1.7924564230657895E9d));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test460");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, number1, 0, orderDirection3, false);
        java.lang.String str6 = nonMonotonousSequenceException5.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (null < 1)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (null < 1)"));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test461");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1L, (java.lang.Number) 100, 0);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        boolean boolean12 = nonMonotonousSequenceException10.getStrict();
        java.lang.Number number13 = nonMonotonousSequenceException10.getPrevious();
        java.lang.Number number14 = nonMonotonousSequenceException10.getArgument();
        java.lang.Throwable[] throwableArray15 = nonMonotonousSequenceException10.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 100 + "'", number13.equals(100));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 1L + "'", number14.equals(1L));
        org.junit.Assert.assertNotNull(throwableArray15);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test462");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-755673343));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test463");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 100L, (-10));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test464");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(53, (long) (-97));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test465");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection3, false);
        java.lang.String str6 = nonMonotonousSequenceException5.toString();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number9 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (100 < 0)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (100 < 0)"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 100.0f + "'", number7.equals(100.0f));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 100.0f + "'", number9.equals(100.0f));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test466");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 36);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test467");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 0.012652378577065889d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test468");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 59L, 6.691673596021348E41d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test469");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (-97.0f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test470");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.0447108096889517d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9990006382468385d + "'", double1 == 0.9990006382468385d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test471");
        double double1 = org.apache.commons.math.util.FastMath.sin((-0.38937226128359037d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.37960773902752165d) + "'", double1 == (-0.37960773902752165d));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test472");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        java.lang.Class<?> wildcardClass7 = orderDirection6.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97, (java.lang.Number) 572.9577951308232d, (int) (byte) 0, orderDirection6, false);
        int int10 = nonMonotonousSequenceException9.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException9.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.2012104037905144E25d, number1, 0, orderDirection11, false);
        int int14 = nonMonotonousSequenceException13.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test473");
        double double1 = org.apache.commons.math.util.FastMath.atan(8.948422304476766d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4595065284196334d + "'", double1 == 1.4595065284196334d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test474");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-6.053272382792838d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 212.75275683459444d + "'", double1 == 212.75275683459444d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test475");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.20198435049990984d, 7400);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.20198435049990984d + "'", double2 == 0.20198435049990984d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test476");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1L, (java.lang.Number) 100, 0);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        boolean boolean12 = nonMonotonousSequenceException10.getStrict();
        java.lang.Number number13 = nonMonotonousSequenceException10.getArgument();
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException10.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException10.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 1L + "'", number13.equals(1L));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test477");
        int[] intArray0 = new int[] {};
        int[] intArray5 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int6 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray5);
        int[] intArray12 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray12);
        int[] intArray14 = new int[] {};
        int[] intArray19 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int20 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray19);
        int[] intArray27 = new int[] { (byte) 0, (byte) 10, '#', (short) -1, (short) 1, 97 };
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray27);
        int[] intArray29 = new int[] {};
        int[] intArray34 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int35 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray34);
        int[] intArray41 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double42 = org.apache.commons.math.util.MathUtils.distance(intArray29, intArray41);
        double double43 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray41);
        int int44 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray41);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 56 + "'", int28 == 56);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 121.51131634543344d + "'", double43 == 121.51131634543344d);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test478");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(13260.0d, (double) 132L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test479");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (byte) -1, (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-32L) + "'", long2 == (-32L));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test480");
        java.lang.Number number4 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, number4, 0, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.665201168491711d, (java.lang.Number) 0.6931471784987917d, (-1), orderDirection6, true);
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException10.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray11);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test481");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 100, (-62));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test482");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) 0);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (int) (short) 10);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (int) (byte) 100);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 9603);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) 0);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (int) (short) 10);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger12);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) 0);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (int) (short) 10);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (int) (byte) 0);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (int) '#');
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger22);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.718281828459045d, (java.lang.Number) bigInteger12, (int) '4');
        java.lang.String str28 = nonMonotonousSequenceException27.toString();
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 51 and 52 are not strictly increasing (1 >= 2.718)" + "'", str28.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 51 and 52 are not strictly increasing (1 >= 2.718)"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test483");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.19611987703015263d + "'", double1 == 0.19611987703015263d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test484");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1167939852);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test485");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 74285528, (float) (-2048582795));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-2.04858278E9f) + "'", float2 == (-2.04858278E9f));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test486");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.39912428462176963d, 1624620833);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.96086850281557E-68d + "'", double2 == 2.96086850281557E-68d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test487");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 56190271540L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3830.1905192376134d + "'", double1 == 3830.1905192376134d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test488");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(156, (-841025708));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test489");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection3, false);
        java.lang.String str6 = nonMonotonousSequenceException5.toString();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection11, false);
        boolean boolean14 = nonMonotonousSequenceException13.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1L, (java.lang.Number) 100, 0);
        nonMonotonousSequenceException13.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        boolean boolean20 = nonMonotonousSequenceException18.getStrict();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = nonMonotonousSequenceException18.getDirection();
        java.lang.Number number23 = nonMonotonousSequenceException18.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (100 < 0)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (100 < 0)"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 100.0f + "'", number7.equals(100.0f));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 100 + "'", number23.equals(100));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test490");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(5.206879716514544E22d, (double) 132L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test491");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(52, 779127710);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test492");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.4278171389293276d, (double) 3900, (double) 522516360069353100L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test493");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 14621587497L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2092745699) + "'", int1 == (-2092745699));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test494");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 156.3608363030788d + "'", double1 == 156.3608363030788d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test495");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1L, (java.lang.Number) 100, 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-3.162351711701654E226d), (java.lang.Number) (-968000650), 1080582144, orderDirection7, true);
        java.lang.Number number10 = nonMonotonousSequenceException9.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (-968000650) + "'", number10.equals((-968000650)));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test496");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-1352038911L), (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1352038911L + "'", long2 == 1352038911L);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test497");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 354302819);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 354302819 + "'", int2 == 354302819);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test498");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.7853981613362947d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999958776928d + "'", double1 == 0.9999999958776928d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test499");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) (-2072794013720961303L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test500");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 1162674021347622912L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1620041051) + "'", int1 == (-1620041051));
    }
}

