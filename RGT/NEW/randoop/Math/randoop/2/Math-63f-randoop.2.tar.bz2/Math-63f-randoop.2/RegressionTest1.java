import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (byte) 1, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 59L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (byte) 10, 4.189654742026425d, (-0.2858640202755717d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(1.565720228261598d, 10, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        java.lang.Class<?> wildcardClass4 = orderDirection3.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97, (java.lang.Number) 572.9577951308232d, (int) (byte) 0, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection10, false);
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException6.getSuppressed();
        int int15 = nonMonotonousSequenceException6.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.9999999999999999d, Double.NaN, 141.43549766589715d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        int int2 = org.apache.commons.math.util.FastMath.max(3500, 3500);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3500 + "'", int2 == 3500);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        int int2 = org.apache.commons.math.util.FastMath.min(32, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(36);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 888019042);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963267948966d) + "'", double1 == (-1.5707963267948966d));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 1079574628);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8842131779592965E7d + "'", double1 == 1.8842131779592965E7d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        int int2 = org.apache.commons.math.util.FastMath.min((-1), (-53));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-53) + "'", int2 == (-53));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.857293145724863d), 0.5403023093369417d, 0.8414709848078965d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 779127810, 1079574528);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 36, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 52L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2979.3805346802806d + "'", double1 == 2979.3805346802806d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(0, (-888018845));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-888018845) + "'", int2 == (-888018845));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1079574628, 3500);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.8813735841046317d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6360918687915654d + "'", double1 == 0.6360918687915654d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (short) -1, 35, 888019042);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 195, 1.0831800840797905d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.015152900342617516d + "'", double2 == 0.015152900342617516d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 888019042, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(0, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (-22L), (-0.17260374626909167d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-21.999999999999996d) + "'", double2 == (-21.999999999999996d));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        double double1 = org.apache.commons.math.util.FastMath.abs((-1.3520389109999998E9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3520389109999998E9d + "'", double1 == 1.3520389109999998E9d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        int int2 = org.apache.commons.math.util.FastMath.max(63, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 63 + "'", int2 == 63);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.7071774883294858d, 1079574628, (-888018845));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        int int1 = org.apache.commons.math.util.FastMath.abs(56);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 56 + "'", int1 == 56);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.5553480614894135d + "'", double1 == 3.5553480614894135d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((-0.41148230684214054d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0858601266130457d + "'", double1 == 1.0858601266130457d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        double double1 = org.apache.commons.math.util.FastMath.tan(13.96424004376894d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.725032845889426d + "'", double1 == 5.725032845889426d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 195);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1080582144 + "'", int1 == 1080582144);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(779127810, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 779127810 + "'", int2 == 779127810);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(52L, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 53L + "'", long2 == 53L);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-888018845), (int) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 59L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1078820864 + "'", int1 == 1078820864);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.4650188248182272d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.02556940209677608d + "'", double1 == 0.02556940209677608d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (short) 10, 64512240L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 64512240L + "'", long2 == 64512240L);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        long long1 = org.apache.commons.math.util.MathUtils.sign((-42L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        int int1 = org.apache.commons.math.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.9442157056960554d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-454785511) + "'", int1 == (-454785511));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        int int2 = org.apache.commons.math.util.FastMath.max(779127810, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 779127810 + "'", int2 == 779127810);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) (-1.0f));
        double[] doubleArray16 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) (-1.0f));
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray16);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, 2.718281828459045d);
        double[] doubleArray28 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, (double) (-1.0f));
        double[] doubleArray37 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, (double) (-1.0f));
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray37);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, 2.718281828459045d);
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray21, doubleArray28);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, (-0.9999999999999999d));
        try {
            double double46 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 139.51318994987582d + "'", double43 == 139.51318994987582d);
        org.junit.Assert.assertNotNull(doubleArray45);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        double double1 = org.apache.commons.math.util.FastMath.sin(13.96424004376894d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9850853666260323d + "'", double1 == 0.9850853666260323d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, 8.853665407629286d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 36);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 36L + "'", long1 == 36L);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        double double1 = org.apache.commons.math.util.FastMath.rint(4.66335008258431d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.0d + "'", double1 == 5.0d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        double double1 = org.apache.commons.math.util.FastMath.log10(15.104412573075516d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.179103839756096d + "'", double1 == 1.179103839756096d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        double double1 = org.apache.commons.math.util.FastMath.ulp(20.37562652865567d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.552713678800501E-15d + "'", double1 == 3.552713678800501E-15d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        double double1 = org.apache.commons.math.util.FastMath.asin(8.853665407629286d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        long long1 = org.apache.commons.math.util.FastMath.round(4.189654742026425d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 4L + "'", long1 == 4L);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1L, (java.lang.Number) 100, 0);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        java.lang.Class<?> wildcardClass12 = nonMonotonousSequenceException10.getClass();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(59.42317395936698d, (-53));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.5972975925995244E-15d + "'", double2 == 6.5972975925995244E-15d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 10, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        int[] intArray0 = null;
        int[] intArray1 = new int[] {};
        int[] intArray6 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray6);
        int[] intArray14 = new int[] { (byte) 0, (byte) 10, '#', (short) -1, (short) 1, 97 };
        int int15 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray14);
        int[] intArray16 = new int[] {};
        int[] intArray21 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int22 = org.apache.commons.math.util.MathUtils.distanceInf(intArray16, intArray21);
        int[] intArray28 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray16, intArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray28);
        int[] intArray31 = new int[] {};
        int[] intArray36 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int37 = org.apache.commons.math.util.MathUtils.distanceInf(intArray31, intArray36);
        int[] intArray42 = new int[] { (byte) 1, '4', '#', 'a' };
        int int43 = org.apache.commons.math.util.MathUtils.distance1(intArray36, intArray42);
        int[] intArray44 = new int[] {};
        int[] intArray49 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int50 = org.apache.commons.math.util.MathUtils.distanceInf(intArray44, intArray49);
        int[] intArray56 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double57 = org.apache.commons.math.util.MathUtils.distance(intArray44, intArray56);
        int int58 = org.apache.commons.math.util.MathUtils.distanceInf(intArray42, intArray56);
        double double59 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray42);
        try {
            int int60 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 56 + "'", int15 == 56);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 121.51131634543344d + "'", double30 == 121.51131634543344d);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 195 + "'", int43 == 195);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 65 + "'", int58 == 65);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 117.12813496338103d + "'", double59 == 117.12813496338103d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(36, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 68 + "'", int2 == 68);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        double double2 = org.apache.commons.math.util.FastMath.atan2(53.0d, 3.552713678800501E-15d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7453292519943295d + "'", double1 == 1.7453292519943295d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double[] doubleArray24 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) (-1.0f));
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray24);
        double[] doubleArray34 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, (double) (-1.0f));
        double double37 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray24, doubleArray34);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) (short) 1);
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) 1L);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray24);
        double[] doubleArray50 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, (double) (-1.0f));
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray50);
        double[] doubleArray60 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) (-1.0f));
        double double63 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray60);
        double double64 = org.apache.commons.math.util.MathUtils.distance1(doubleArray50, doubleArray60);
        double double65 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray24, doubleArray50);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray50);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (1 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 141.43549766589717d + "'", double40 == 141.43549766589717d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 141.43549766589717d + "'", double53 == 141.43549766589717d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 141.43549766589717d + "'", double63 == 141.43549766589717d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 2.718281828459045d);
        double[] doubleArray27 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) (-1.0f));
        double[] doubleArray36 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) (-1.0f));
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray36);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 2.718281828459045d);
        double double42 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray27);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (-0.9999999999999999d));
        double[] doubleArray51 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, (double) (-1.0f));
        double[] doubleArray60 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) (-1.0f));
        double[] doubleArray69 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray71 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray69, (double) (-1.0f));
        double double72 = org.apache.commons.math.util.MathUtils.distance1(doubleArray60, doubleArray69);
        double[] doubleArray79 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray81 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray79, (double) (-1.0f));
        double double82 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray69, doubleArray79);
        double[] doubleArray84 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray69, (double) (short) 1);
        double double85 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray69);
        double[] doubleArray87 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray69, (double) 1L);
        boolean boolean88 = org.apache.commons.math.util.MathUtils.equals(doubleArray53, doubleArray69);
        boolean boolean89 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray69);
        double[] doubleArray91 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, 0.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 139.51318994987582d + "'", double42 == 139.51318994987582d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 141.43549766589717d + "'", double85 == 141.43549766589717d);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNotNull(doubleArray91);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-43L), (long) 53);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2072794013720961147L) + "'", long2 == (-2072794013720961147L));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 779127810, (int) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-9218868437227405312L) + "'", long2 == (-9218868437227405312L));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        float float2 = org.apache.commons.math.util.FastMath.min((float) '4', (float) 99);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 888019042);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) ' ', 99);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 35, 65.99621212121211d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.00000000000001d + "'", double2 == 35.00000000000001d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (byte) -1, 99);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        double double1 = org.apache.commons.math.util.FastMath.sinh(121.51131634543344d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.955726068636564E52d + "'", double1 == 2.955726068636564E52d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.9999999958776927d, 1.379695231654459E48d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (byte) 100, 5730.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray25 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) (-1.0f));
        double[] doubleArray34 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, (double) (-1.0f));
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray34);
        double[] doubleArray44 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, (double) (-1.0f));
        double double47 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray44);
        double[] doubleArray54 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray54, (double) (-1.0f));
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray54);
        double[] doubleArray64 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray64, (double) (-1.0f));
        double double67 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray64);
        double double68 = org.apache.commons.math.util.MathUtils.distance1(doubleArray54, doubleArray64);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray54);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray54);
        double[] doubleArray72 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 15.104412573075516d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 141.43549766589717d + "'", double57 == 141.43549766589717d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 141.43549766589717d + "'", double67 == 141.43549766589717d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNotNull(doubleArray72);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 195, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 99.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.0d, 3500);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        int[] intArray0 = new int[] {};
        int[] intArray5 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int6 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray5);
        int[] intArray13 = new int[] { (byte) 0, (byte) 10, '#', (short) -1, (short) 1, 97 };
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray13);
        int[] intArray15 = new int[] {};
        int[] intArray20 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray20);
        int[] intArray27 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double28 = org.apache.commons.math.util.MathUtils.distance(intArray15, intArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray27);
        int[] intArray30 = new int[] {};
        int[] intArray35 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int36 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray35);
        int[] intArray41 = new int[] { (byte) 1, '4', '#', 'a' };
        int int42 = org.apache.commons.math.util.MathUtils.distance1(intArray35, intArray41);
        int[] intArray43 = new int[] {};
        int[] intArray48 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int49 = org.apache.commons.math.util.MathUtils.distanceInf(intArray43, intArray48);
        int[] intArray55 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double56 = org.apache.commons.math.util.MathUtils.distance(intArray43, intArray55);
        int int57 = org.apache.commons.math.util.MathUtils.distanceInf(intArray41, intArray55);
        double double58 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray41);
        int[] intArray59 = new int[] {};
        int[] intArray64 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int65 = org.apache.commons.math.util.MathUtils.distanceInf(intArray59, intArray64);
        int[] intArray70 = new int[] { (byte) 1, '4', '#', 'a' };
        int int71 = org.apache.commons.math.util.MathUtils.distance1(intArray64, intArray70);
        int[] intArray72 = new int[] {};
        int[] intArray77 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int78 = org.apache.commons.math.util.MathUtils.distanceInf(intArray72, intArray77);
        int[] intArray84 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double85 = org.apache.commons.math.util.MathUtils.distance(intArray72, intArray84);
        int int86 = org.apache.commons.math.util.MathUtils.distanceInf(intArray70, intArray84);
        int int87 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray84);
        java.lang.Class<?> wildcardClass88 = intArray84.getClass();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 56 + "'", int14 == 56);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 121.51131634543344d + "'", double29 == 121.51131634543344d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 195 + "'", int42 == 195);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 65 + "'", int57 == 65);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 117.12813496338103d + "'", double58 == 117.12813496338103d);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 195 + "'", int71 == 195);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
        org.junit.Assert.assertNotNull(intArray84);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 65 + "'", int86 == 65);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 197 + "'", int87 == 197);
        org.junit.Assert.assertNotNull(wildcardClass88);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1080582144, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1080582145 + "'", int2 == 1080582145);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 888019042);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(0, 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-97) + "'", int2 == (-97));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.993222846126381d + "'", double1 == 2.993222846126381d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(132L, (long) 1078820864);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 142404354048L + "'", long2 == 142404354048L);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 2.718281828459045d);
        double[] doubleArray27 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) (-1.0f));
        double[] doubleArray36 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) (-1.0f));
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray36);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 2.718281828459045d);
        double double42 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray27);
        double[] doubleArray49 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, (double) (-1.0f));
        double double52 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray49);
        double[] doubleArray59 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray59, (double) (-1.0f));
        double double62 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray59);
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray49, doubleArray59);
        double double64 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray49);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (1 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 139.51318994987582d + "'", double42 == 139.51318994987582d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 141.43549766589717d + "'", double52 == 141.43549766589717d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 141.43549766589717d + "'", double62 == 141.43549766589717d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (short) -1, (-53));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 8.88019042E8d, 1078820864, orderDirection3, true);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1078820864, 36);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.127059477140893E283d + "'", double2 == 4.127059477140893E283d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (-454785511));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(11.489125293076057d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.20052306453833568d + "'", double1 == 0.20052306453833568d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 64512240L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 6.451224E7f + "'", float1 == 6.451224E7f);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 1079574528);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray25 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) (-1.0f));
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray25);
        double[] doubleArray35 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) (-1.0f));
        double double38 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray45 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (double) (-1.0f));
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray45);
        double double49 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray45);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray35);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection54 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException56 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection54, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15, orderDirection54, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not decreasing (-1 < 100)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 141.43549766589717d + "'", double38 == 141.43549766589717d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 141.43549766589717d + "'", double48 == 141.43549766589717d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + orderDirection54 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection54.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-1), (float) 63);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 63.0f + "'", float2 == 63.0f);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 1080582145, 53L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 57270853685L + "'", long2 == 57270853685L);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        int int2 = org.apache.commons.math.util.FastMath.min(1, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        double double1 = org.apache.commons.math.util.FastMath.ulp(140.7283201775677d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.8421709430404007E-14d + "'", double1 == 2.8421709430404007E-14d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (short) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (double) 5L, 10.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 888019095L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 961.1859962243583d + "'", double1 == 961.1859962243583d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, 0.20052306453833568d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 13L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 221206.6960055904d + "'", double1 == 221206.6960055904d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        int int1 = org.apache.commons.math.util.FastMath.round((float) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1079574528);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.07957453E9f + "'", float1 == 1.07957453E9f);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.806217383937352E-6d + "'", double1 == 4.806217383937352E-6d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1080582144, (float) 1399733633);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.39973363E9f + "'", float2 == 1.39973363E9f);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        double double1 = org.apache.commons.math.util.FastMath.asinh(2.524630659933467d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6563400983387864d + "'", double1 == 1.6563400983387864d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (byte) 0, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 35, 5L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.7363221375979174d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7363221375979174d + "'", double1 == 1.7363221375979174d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.10491011977356592d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.857293145724863d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.857293145724863d + "'", double1 == 0.857293145724863d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 1399733633);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1399733633L + "'", long1 == 1399733633L);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 53L, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 53.0d + "'", double2 == 53.0d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.8414709848078965d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0749608545604955d) + "'", double1 == (-0.0749608545604955d));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(3.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4422495703074083d + "'", double1 == 1.4422495703074083d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(100L, 20L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 80L + "'", long2 == 80L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 1.39973363E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2889738015572888d + "'", double1 == 0.2889738015572888d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 100, 13L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1300L + "'", long2 == 1300L);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        double double1 = org.apache.commons.math.util.FastMath.acos(100.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        double double2 = org.apache.commons.math.util.FastMath.min(2.199023255552E12d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        long long1 = org.apache.commons.math.util.MathUtils.sign(13L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        double double1 = org.apache.commons.math.util.FastMath.sinh(572.9577951308232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.399216241149525E248d + "'", double1 == 3.399216241149525E248d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(59L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 156, (long) 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 156L + "'", long2 == 156L);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 2.718281828459045d);
        double[] doubleArray27 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) (-1.0f));
        double[] doubleArray36 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) (-1.0f));
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray36);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 2.718281828459045d);
        double double42 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray27);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (-0.9999999999999999d));
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) 99.0f);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (0.014 >= -0.014)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 139.51318994987582d + "'", double42 == 139.51318994987582d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.9999999999999999d), 0.9999999958776927d, 1.565720228261598d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (-22L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.792456423065796E9d) + "'", double1 == (-1.792456423065796E9d));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        double double2 = org.apache.commons.math.util.FastMath.max(141.43549766589717d, (double) 57270853685L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.7270853685E10d + "'", double2 == 5.7270853685E10d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 0);
        try {
            java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232874703393d + "'", double1 == 11013.232874703393d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(2.7182818284590446d, (double) 56, 65);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        double double2 = org.apache.commons.math.util.MathUtils.round(6.283185307179586d, 35);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.283185307179586d + "'", double2 == 6.283185307179586d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        double[] doubleArray0 = null;
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 4.248699261236361d, (-1352038911));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(53L, (-55L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 108L + "'", long2 == 108L);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.4515827052894548d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1080582144, 195, 195);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.0d, (int) (byte) 1, 65);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 52L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 52.0f + "'", float1 == 52.0f);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        int int1 = org.apache.commons.math.util.FastMath.abs(53);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 53 + "'", int1 == 53);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-888018845), (int) '4');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1078820864);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1078820864 + "'", int1 == 1078820864);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) 0);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (int) (short) 10);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (int) (byte) 0);
        try {
            java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, 0, 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        double double2 = org.apache.commons.math.util.MathUtils.round(1.0d, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 68, (long) 195);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 13260L + "'", long2 == 13260L);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 10, (long) 1079574628);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-0.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 132L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 132.0d + "'", double1 == 132.0d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        int int1 = org.apache.commons.math.util.MathUtils.hash(1904.9409439665053d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-968004150) + "'", int1 == (-968004150));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 35, (-2.4492935982947064E-16d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, number1, 10);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 1399733633, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.399733633E9d + "'", double2 == 1.399733633E9d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        double double1 = org.apache.commons.math.util.FastMath.atan(99.50000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5607464139018623d + "'", double1 == 1.5607464139018623d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(5.298342365610589d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        double double1 = org.apache.commons.math.util.FastMath.ceil(8.880190419999999E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.88019042E8d + "'", double1 == 8.88019042E8d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 1989426017);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) -1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (short) 10, (long) 1399733633);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.9999999958776927d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1752011872827488d + "'", double1 == 1.1752011872827488d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 13260L, 888019042);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 1989426017);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1 == 10.0f);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        double double1 = org.apache.commons.math.util.FastMath.signum(141.43549766589715d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        double double2 = org.apache.commons.math.util.MathUtils.log(132.0d, 2.7182818284590446d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.20480044364984396d + "'", double2 == 0.20480044364984396d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.9850853666260323d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6780404899442742d + "'", double1 == 2.6780404899442742d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        float float1 = org.apache.commons.math.util.MathUtils.sign(Float.NaN);
        org.junit.Assert.assertEquals((float) float1, Float.NaN, 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        double double2 = org.apache.commons.math.util.FastMath.min(6.283185307179586d, 0.5403023093369417d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5403023093369417d + "'", double2 == 0.5403023093369417d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-888018845));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.8842131779592965E7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 17.44475315305432d + "'", double1 == 17.44475315305432d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 97, (long) 63);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.389883474391312E16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) (byte) 1, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        long long2 = org.apache.commons.math.util.MathUtils.pow(80L, (long) 1079574628);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 1989426017, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (byte) -1, 1.565720228261598d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        float float1 = org.apache.commons.math.util.MathUtils.sign(52.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(888019042, (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        double double1 = org.apache.commons.math.util.FastMath.abs(117.12813496338103d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 117.12813496338103d + "'", double1 == 117.12813496338103d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298292365610485d + "'", double1 == 5.298292365610485d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 59L, 20.37562652865567d, 15.104412573075516d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        int int1 = org.apache.commons.math.util.FastMath.abs(1079574528);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1079574528 + "'", int1 == 1079574528);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(3.5553480614894135d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.555348061489414d + "'", double1 == 3.555348061489414d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number3, (java.lang.Number) 4.248699261236361d, (-1352038911));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1904.9409439665053d, (java.lang.Number) 37.17058140016013d, 0, orderDirection7, false);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        long long1 = org.apache.commons.math.util.MathUtils.factorial(0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 13260L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        int int2 = org.apache.commons.math.util.FastMath.min(1078820864, 65);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 65 + "'", int2 == 65);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) 'a', 1080582144);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 197, 1399733633L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 197L + "'", long2 == 197L);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 0.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.8414709848078965d, 0.6360918687915654d, 1.665201168491711d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.20480044364984396d, 1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1752011936438014d + "'", double1 == 1.1752011936438014d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        long long1 = org.apache.commons.math.util.MathUtils.sign(1300L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.7853981613362947d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1932800462173283d + "'", double1 == 1.1932800462173283d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        double double1 = org.apache.commons.math.util.FastMath.rint(5.656854249492381d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.0d + "'", double1 == 6.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) '#');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 53);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 53 + "'", int1 == 53);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(197, 888019042);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 888019239 + "'", int2 == 888019239);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double[] doubleArray24 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) (-1.0f));
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray24);
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray24);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (0.005 >= -0.5)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 141.43549766589717d + "'", double28 == 141.43549766589717d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        long long2 = org.apache.commons.math.util.FastMath.max(36L, 32L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 36L + "'", long2 == 36L);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(3500, (-968004150));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-968000650) + "'", int2 == (-968000650));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1352038911), (int) (byte) 1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        int int2 = org.apache.commons.math.util.FastMath.min(35, 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(5730.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 75.69676347110224d + "'", double1 == 75.69676347110224d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 53);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, 32L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        int int2 = org.apache.commons.math.util.FastMath.min(100, 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        double double1 = org.apache.commons.math.util.FastMath.log(4.806217383937352E-6d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-12.245600189892366d) + "'", double1 == (-12.245600189892366d));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 13L, (-1352038911));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-1), 1989426017);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(1300L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1300L + "'", long2 == 1300L);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        int int1 = org.apache.commons.math.util.MathUtils.hash((-0.9645439376973555d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2138030215) + "'", int1 == (-2138030215));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 'a');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double[] doubleArray24 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) (-1.0f));
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray24);
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray24);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (1 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 141.43549766589717d + "'", double28 == 141.43549766589717d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0333147966386297E40d + "'", double1 == 1.0333147966386297E40d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 80L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.54062238439351E34d + "'", double1 == 5.54062238439351E34d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        double double1 = org.apache.commons.math.util.FastMath.log1p(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 5L, (double) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(3.5553480614894135d, 961.1859962243583d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 10, (long) 3500);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-1), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 2.718281828459045d);
        double[] doubleArray27 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) (-1.0f));
        double[] doubleArray36 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) (-1.0f));
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray36);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 2.718281828459045d);
        double double42 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray27);
        double[] doubleArray49 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, (double) (-1.0f));
        double double52 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray49);
        double[] doubleArray59 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray59, (double) (-1.0f));
        double double62 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray59);
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray49, doubleArray59);
        double double64 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray49);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray49);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (1 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 139.51318994987582d + "'", double42 == 139.51318994987582d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 141.43549766589717d + "'", double52 == 141.43549766589717d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 141.43549766589717d + "'", double62 == 141.43549766589717d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(53L, (-55L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1L, (java.lang.Number) 100, 0);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        java.lang.Number number12 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (short) 0 + "'", number12.equals((short) 0));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray25 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) (-1.0f));
        double[] doubleArray34 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, (double) (-1.0f));
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray34);
        double[] doubleArray44 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, (double) (-1.0f));
        double double47 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray44);
        double[] doubleArray54 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray54, (double) (-1.0f));
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray54);
        double[] doubleArray64 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray64, (double) (-1.0f));
        double double67 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray64);
        double double68 = org.apache.commons.math.util.MathUtils.distance1(doubleArray54, doubleArray64);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray54);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray54);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection71 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6, orderDirection71, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 141.43549766589717d + "'", double57 == 141.43549766589717d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 141.43549766589717d + "'", double67 == 141.43549766589717d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-2138030215));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.7315666758872256E7d) + "'", double1 == (-3.7315666758872256E7d));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 59L, (float) 64512240L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 6.451224E7f + "'", float2 == 6.451224E7f);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        double double2 = org.apache.commons.math.util.MathUtils.log(Double.NEGATIVE_INFINITY, 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(65, 1078820864);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(63);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9826083154044198E87d + "'", double1 == 1.9826083154044198E87d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(888019239, 195);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-968004150), (int) ' ');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(2.7501303671488815d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 4L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7568024953079282d) + "'", double1 == (-0.7568024953079282d));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 20L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 57270853685L, (float) (short) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(4.882801922586371d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08522097027184145d + "'", double1 == 0.08522097027184145d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-1.0f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        float float1 = org.apache.commons.math.util.MathUtils.sign(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 9L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 9 + "'", int1 == 9);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 68, 5.298292365610485d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 67.99999999999999d + "'", double2 == 67.99999999999999d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (byte) 1, 1080582145);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1080582145 + "'", int2 == 1080582145);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 63);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.143134726391533d + "'", double1 == 4.143134726391533d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 197L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.294466226161593d + "'", double1 == 2.294466226161593d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        float float2 = org.apache.commons.math.util.FastMath.max(52.0f, (float) 3500);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3500.0f + "'", float2 == 3500.0f);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(75.69676347110224d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 75.69676347110223d + "'", double2 == 75.69676347110223d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2.993222846126381d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (byte) -1);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 36, (-888019142L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-888018845));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        int int2 = org.apache.commons.math.util.FastMath.min(97, 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 4L, (float) (-968000650));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-9.6800064E8f) + "'", float2 == (-9.6800064E8f));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.0d, 1080582144, 888019042);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 108L, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-1));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 2.718281828459045d);
        double[] doubleArray27 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) (-1.0f));
        double[] doubleArray36 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) (-1.0f));
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray36);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 2.718281828459045d);
        double double42 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray27);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, 10.0d);
        double[] doubleArray51 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, (double) (-1.0f));
        double[] doubleArray60 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) (-1.0f));
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray51, doubleArray60);
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, 2.718281828459045d);
        double[] doubleArray72 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray74 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray72, (double) (-1.0f));
        double[] doubleArray81 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray83 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray81, (double) (-1.0f));
        double double84 = org.apache.commons.math.util.MathUtils.distance1(doubleArray72, doubleArray81);
        double[] doubleArray86 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray72, 2.718281828459045d);
        double double87 = org.apache.commons.math.util.MathUtils.distance(doubleArray65, doubleArray72);
        double[] doubleArray89 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray65, (-0.9999999999999999d));
        double[] doubleArray91 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray65, (double) 99.0f);
        double double92 = org.apache.commons.math.util.MathUtils.distance1(doubleArray44, doubleArray91);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 139.51318994987582d + "'", double42 == 139.51318994987582d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 139.51318994987582d + "'", double87 == 139.51318994987582d);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 90.78d + "'", double92 == 90.78d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 3500);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3500 + "'", int1 == 3500);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        float float1 = org.apache.commons.math.util.MathUtils.sign(1.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        float float1 = org.apache.commons.math.util.FastMath.abs(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.5872139151569291d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.46198022462000077d + "'", double1 == 0.46198022462000077d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(52L, 52L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 104L + "'", long2 == 104L);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((-2.4492935982947064E-16d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.4515827052894548d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4670882772136576d + "'", double1 == 0.4670882772136576d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        double double1 = org.apache.commons.math.util.FastMath.sin(3.399216241149525E248d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.22013364551749795d + "'", double1 == 0.22013364551749795d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(132L, (long) 1079574528);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1079574396L) + "'", long2 == (-1079574396L));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 59L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.2012104037905144E25d + "'", double1 == 4.2012104037905144E25d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(57270853685L, 13260L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 151882303972620L + "'", long2 == 151882303972620L);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) (-1.0f));
        double[] doubleArray16 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) (-1.0f));
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray16);
        double[] doubleArray26 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) (-1.0f));
        double[] doubleArray35 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) (-1.0f));
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray35);
        double[] doubleArray45 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (double) (-1.0f));
        double double48 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray35, doubleArray45);
        double[] doubleArray55 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray57 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray55, (double) (-1.0f));
        double double58 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray55);
        double[] doubleArray65 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray67 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray65, (double) (-1.0f));
        double double68 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray65);
        double double69 = org.apache.commons.math.util.MathUtils.distance1(doubleArray55, doubleArray65);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray35, doubleArray55);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray55);
        try {
            double double72 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 141.43549766589717d + "'", double58 == 141.43549766589717d);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 141.43549766589717d + "'", double68 == 141.43549766589717d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 9, 1399733633L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9L + "'", long2 == 9L);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-15.954589770191003d) + "'", double1 == (-15.954589770191003d));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) (-1.0f));
        double[] doubleArray16 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) (-1.0f));
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray16);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, 2.718281828459045d);
        double[] doubleArray28 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, (double) (-1.0f));
        double[] doubleArray37 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, (double) (-1.0f));
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray37);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, 2.718281828459045d);
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray21, doubleArray28);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, (-0.9999999999999999d));
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, (double) 99.0f);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, (double) 1989426017);
        try {
            double double50 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 139.51318994987582d + "'", double43 == 139.51318994987582d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 2L, (int) ' ', (-888018845));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (long) 779127710);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((-0.2858640202755717d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0411381226745244d + "'", double1 == 1.0411381226745244d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(53L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 53L + "'", long2 == 53L);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 1.0f, (-0.6569141418449421d), 0.857293145724863d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        java.lang.Number number4 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, number4, 0, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.9999999958776927d, (java.lang.Number) 0.20480044364984396d, 32, orderDirection6, false);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 'a', (double) 104L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) '4', 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, 0.2889738015572888d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(53, 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21 + "'", int2 == 21);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7853981633974484d + "'", double1 == 0.7853981633974484d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, number1, 0, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        double double2 = org.apache.commons.math.util.MathUtils.log(1.7363221375979174d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        double double1 = org.apache.commons.math.util.FastMath.sin(2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9991050130774393d) + "'", double1 == (-0.9991050130774393d));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(100L, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(1.9826083154044198E87d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.9826083154044198E87d + "'", double2 == 1.9826083154044198E87d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(52L, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 62L + "'", long2 == 62L);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1), (int) (byte) 100);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(35.0d, 2.8421709430404007E-14d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 34.99999999999999d + "'", double2 == 34.99999999999999d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-43L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 43.0f + "'", float1 == 43.0f);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        int int2 = org.apache.commons.math.util.FastMath.min((int) 'a', 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 32, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(36, 3500);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31500 + "'", int2 == 31500);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        double double1 = org.apache.commons.math.util.FastMath.ceil(4051.5420254925943d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4052.0d + "'", double1 == 4052.0d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1352038911), 63);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        double double1 = org.apache.commons.math.util.FastMath.acos(5.7270853685E10d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(36);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1080582145, 63);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-6625612055612252159L) + "'", long2 == (-6625612055612252159L));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 1300L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 156L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8938.141604040842d + "'", double1 == 8938.141604040842d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1079574628);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, 59L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 59L + "'", long2 == 59L);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 349.9541180407703d + "'", double1 == 349.9541180407703d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 1079574528);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        int int1 = org.apache.commons.math.util.MathUtils.hash(8938.141604040842d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1624620833 + "'", int1 == 1624620833);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8813735841046317d, (java.lang.Number) (-1079574396L), (int) (byte) 10);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) '#', 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-62) + "'", int2 == (-62));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 108L, 1399733633);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.4657359027997265d + "'", double1 == 3.4657359027997265d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 9L, 0, 779127810);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 99.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.944515159673473E42d + "'", double1 == 4.944515159673473E42d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 151882303972620L, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.07051436688301507d + "'", double2 == 0.07051436688301507d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(197, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        long long1 = org.apache.commons.math.util.FastMath.round(4.944515159673473E42d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 9223372036854775807L + "'", long1 == 9223372036854775807L);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.9972233523474408d, (double) (-888018845));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        double double1 = org.apache.commons.math.util.FastMath.log1p(2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection3, false);
        java.lang.String str6 = nonMonotonousSequenceException5.toString();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection11, false);
        boolean boolean14 = nonMonotonousSequenceException13.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1L, (java.lang.Number) 100, 0);
        nonMonotonousSequenceException13.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        boolean boolean20 = nonMonotonousSequenceException18.getStrict();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        java.lang.String str22 = nonMonotonousSequenceException5.toString();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (100 < 0)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (100 < 0)"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 100.0f + "'", number7.equals(100.0f));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (100 < 0)" + "'", str22.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (100 < 0)"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 36);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        int int2 = org.apache.commons.math.util.MathUtils.pow(195, 31500);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-984724751) + "'", int2 == (-984724751));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        double double1 = org.apache.commons.math.util.FastMath.sinh(5.656854249492381d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 143.1216351825583d + "'", double1 == 143.1216351825583d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(99, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9603 + "'", int2 == 9603);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (double) 57270853685L, 2.993222846126381d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        double double1 = org.apache.commons.math.util.FastMath.ulp(8.88019042E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1920928955078125E-7d + "'", double1 == 1.1920928955078125E-7d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.399733633E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 37413.01421965357d + "'", double1 == 37413.01421965357d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        double double2 = org.apache.commons.math.util.MathUtils.round(2.718281828459045d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 13260L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 13260.0d + "'", double1 == 13260.0d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 43.66827237527655d + "'", double1 == 43.66827237527655d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.4515827052894548d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0078816050523642d + "'", double1 == 0.0078816050523642d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.1752011936438014d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(4.294967296E11d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((-6625612055612252159L), (long) 888019239);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-6625612056500271398L) + "'", long2 == (-6625612056500271398L));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        double double1 = org.apache.commons.math.util.FastMath.log10((-1.5707963267948966d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-968000650), 9);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) -1, (java.lang.Number) Float.NaN, (int) (byte) 10, orderDirection6, false);
        java.lang.String str11 = nonMonotonousSequenceException10.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException10.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not decreasing (� < -1)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not decreasing (� < -1)"));
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, 197L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 197L + "'", long2 == 197L);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(9);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12.801827480081469d + "'", double1 == 12.801827480081469d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, 197, 100);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 0L, (float) (-97));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-97.0f) + "'", float2 == (-97.0f));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 888019095L, (-97), 63);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        int int2 = org.apache.commons.math.util.MathUtils.pow(65, (long) 1399733633);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1987797057 + "'", int2 == 1987797057);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.9850853666260323d, (double) 1L, 97.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (short) -1, 68);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-69) + "'", int2 == (-69));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        int int2 = org.apache.commons.math.util.FastMath.max(21, 1079574528);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1079574528 + "'", int2 == 1079574528);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (-22L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-22L) + "'", long2 == (-22L));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 10);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 1080582145);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 10, 56);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        int int1 = org.apache.commons.math.util.MathUtils.hash(2.154434690031884d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 20532231 + "'", int1 == 20532231);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(32, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.179103839756096d, (double) 20L, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        double double1 = org.apache.commons.math.util.FastMath.cosh(2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        long long1 = org.apache.commons.math.util.FastMath.round((-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-2L) + "'", long1 == (-2L));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        double double1 = org.apache.commons.math.util.FastMath.log10(2.6780404899442742d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4278171389293276d + "'", double1 == 0.4278171389293276d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, 0.07051436688301507d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) 10);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 63, 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-37L) + "'", long2 == (-37L));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        double double1 = org.apache.commons.math.util.FastMath.log10(5.54062238439351E34d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 34.74355855226015d + "'", double1 == 34.74355855226015d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1079574528, 888019042);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        int[] intArray0 = new int[] {};
        int[] intArray5 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int6 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray5);
        int[] intArray12 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray12);
        int[] intArray14 = new int[] {};
        int[] intArray19 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int20 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray19);
        int[] intArray27 = new int[] { (byte) 0, (byte) 10, '#', (short) -1, (short) 1, 97 };
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray27);
        int[] intArray29 = new int[] {};
        int[] intArray34 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int35 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray34);
        int[] intArray41 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double42 = org.apache.commons.math.util.MathUtils.distance(intArray29, intArray41);
        double double43 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray41);
        int[] intArray44 = new int[] {};
        int[] intArray49 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int50 = org.apache.commons.math.util.MathUtils.distanceInf(intArray44, intArray49);
        int[] intArray55 = new int[] { (byte) 1, '4', '#', 'a' };
        int int56 = org.apache.commons.math.util.MathUtils.distance1(intArray49, intArray55);
        int[] intArray57 = new int[] {};
        int[] intArray62 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int63 = org.apache.commons.math.util.MathUtils.distanceInf(intArray57, intArray62);
        int[] intArray69 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double70 = org.apache.commons.math.util.MathUtils.distance(intArray57, intArray69);
        int int71 = org.apache.commons.math.util.MathUtils.distanceInf(intArray55, intArray69);
        double double72 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray55);
        int[] intArray73 = new int[] {};
        int[] intArray78 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int79 = org.apache.commons.math.util.MathUtils.distanceInf(intArray73, intArray78);
        int[] intArray86 = new int[] { (byte) 0, (byte) 10, '#', (short) -1, (short) 1, 97 };
        int int87 = org.apache.commons.math.util.MathUtils.distance1(intArray78, intArray86);
        double double88 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray86);
        int int89 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray19);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 56 + "'", int28 == 56);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 121.51131634543344d + "'", double43 == 121.51131634543344d);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 195 + "'", int56 == 195);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 65 + "'", int71 == 65);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 117.12813496338103d + "'", double72 == 117.12813496338103d);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertNotNull(intArray86);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 56 + "'", int87 == 56);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 38.02630668366309d + "'", double88 == 38.02630668366309d);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 0 + "'", int89 == 0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.389883474391312E16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.389883474391312E16d + "'", double1 == 1.389883474391312E16d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        double double1 = org.apache.commons.math.util.FastMath.log10(37413.01421965357d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.573022699008911d + "'", double1 == 4.573022699008911d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 132L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 132.0d + "'", double1 == 132.0d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        double double1 = org.apache.commons.math.util.FastMath.acosh(4.66335008258431d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.221181889247967d + "'", double1 == 2.221181889247967d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.7853981613362947d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6674572193582448d + "'", double1 == 0.6674572193582448d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.6360918687915654d, 0.07051436688301507d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4603914750271216d + "'", double2 == 1.4603914750271216d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 53, (int) (short) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(3.555348061489414d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 203.70643862336212d + "'", double1 == 203.70643862336212d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(4.143134726391533d, 0.7071774883294859d, 143.1216351825583d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) -1);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) -1 + "'", byte1 == (byte) -1);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) (-888019142L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) 'a', 21);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-279932959) + "'", int2 == (-279932959));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        double double1 = org.apache.commons.math.util.FastMath.tan(2.7501303671488815d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4127653077953633d) + "'", double1 == (-0.4127653077953633d));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 43.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 43.00000000000001d + "'", double1 == 43.00000000000001d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-454785511));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 32L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(56.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.5486677646162761d) + "'", double2 == (-0.5486677646162761d));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray25 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) (-1.0f));
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray25);
        double[] doubleArray35 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) (-1.0f));
        double double38 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray45 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (double) (-1.0f));
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray45);
        double double49 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray45);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray35);
        double[] doubleArray57 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray57, (double) (-1.0f));
        double[] doubleArray66 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray68 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray66, (double) (-1.0f));
        double double69 = org.apache.commons.math.util.MathUtils.distance1(doubleArray57, doubleArray66);
        double[] doubleArray76 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray78 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray76, (double) (-1.0f));
        double double79 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray66, doubleArray76);
        double double80 = org.apache.commons.math.util.MathUtils.distance(doubleArray35, doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 141.43549766589717d + "'", double38 == 141.43549766589717d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 141.43549766589717d + "'", double48 == 141.43549766589717d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-9218868437227405312L), 3500);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 2.718281828459045d);
        double[] doubleArray27 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) (-1.0f));
        double[] doubleArray36 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) (-1.0f));
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray36);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 2.718281828459045d);
        double double42 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray27);
        double[] doubleArray43 = null;
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray43);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection45 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection45, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 139.51318994987582d + "'", double42 == 139.51318994987582d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((-1), 1078820864);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078820864 + "'", int2 == 1078820864);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (-0.41148230684214054d), 195);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (byte) 100, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-888018845), (long) 1079574628);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1967593473L) + "'", long2 == (-1967593473L));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        double double1 = org.apache.commons.math.util.FastMath.atan(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5607966601082315d + "'", double1 == 1.5607966601082315d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        double[] doubleArray0 = null;
        double[] doubleArray1 = null;
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        double double1 = org.apache.commons.math.util.FastMath.tan(5.7270853685E10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.39912428462176963d + "'", double1 == 0.39912428462176963d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, 888019239);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1), 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-10) + "'", int2 == (-10));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (-42L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        int int1 = org.apache.commons.math.util.MathUtils.hash(9.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1075970048 + "'", int1 == 1075970048);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, 1080582144);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1080582144 + "'", int2 == 1080582144);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        int int1 = org.apache.commons.math.util.MathUtils.sign(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.7853981613362947d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.6729530497092316d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7249085520219886d + "'", double1 == 0.7249085520219886d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        long long1 = org.apache.commons.math.util.FastMath.round(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 779127810, 4051.5420254925943d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4054.2998571395874d + "'", double2 == 4054.2998571395874d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        java.lang.Class<?> wildcardClass4 = orderDirection3.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97, (java.lang.Number) 572.9577951308232d, (int) (byte) 0, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection10, false);
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException12.getSuppressed();
        java.lang.Number number15 = nonMonotonousSequenceException12.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (short) 0 + "'", number15.equals((short) 0));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(63);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 201.00931639928152d + "'", double1 == 201.00931639928152d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 1075970048);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 9, (int) (byte) 10, 56);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 2);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        double double1 = org.apache.commons.math.util.FastMath.log(572.9577951308232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.3508120580348555d + "'", double1 == 6.3508120580348555d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (-55L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.022126756261955736d + "'", double1 == 0.022126756261955736d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(4.66335008258431d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08139081311424569d + "'", double1 == 0.08139081311424569d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        int[] intArray0 = new int[] {};
        int[] intArray5 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int6 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray5);
        int[] intArray7 = new int[] {};
        int[] intArray12 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int13 = org.apache.commons.math.util.MathUtils.distanceInf(intArray7, intArray12);
        int[] intArray14 = new int[] {};
        int[] intArray19 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int20 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray19);
        int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray7, intArray14);
        try {
            int int22 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.20052306453833568d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.20052306453833568d + "'", double1 == 0.20052306453833568d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (long) (-888018845));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-888018845L) + "'", long2 == (-888018845L));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        long long1 = org.apache.commons.math.util.FastMath.abs(100L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (short) 100, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) '4', 1080582144);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        double double2 = org.apache.commons.math.util.MathUtils.log(4.66335008258431d, (double) 1300L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.6567258477490165d + "'", double2 == 4.6567258477490165d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        java.lang.Class<?> wildcardClass4 = orderDirection3.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97, (java.lang.Number) 572.9577951308232d, (int) (byte) 0, orderDirection3, false);
        int int7 = nonMonotonousSequenceException6.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException6.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        java.lang.Class<?> wildcardClass7 = orderDirection6.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97, (java.lang.Number) 572.9577951308232d, (int) (byte) 0, orderDirection6, false);
        int int10 = nonMonotonousSequenceException9.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException9.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 6.3508120580348555d, 1987797057, orderDirection11, false);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        int[] intArray0 = new int[] {};
        int[] intArray5 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int6 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray5);
        int[] intArray13 = new int[] { (byte) 0, (byte) 10, '#', (short) -1, (short) 1, 97 };
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray13);
        int[] intArray15 = new int[] {};
        int[] intArray20 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray20);
        int[] intArray27 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double28 = org.apache.commons.math.util.MathUtils.distance(intArray15, intArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray27);
        int[] intArray30 = new int[] {};
        int[] intArray35 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int36 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray35);
        int[] intArray41 = new int[] { (byte) 1, '4', '#', 'a' };
        int int42 = org.apache.commons.math.util.MathUtils.distance1(intArray35, intArray41);
        int[] intArray43 = new int[] {};
        int[] intArray48 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int49 = org.apache.commons.math.util.MathUtils.distanceInf(intArray43, intArray48);
        int[] intArray55 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double56 = org.apache.commons.math.util.MathUtils.distance(intArray43, intArray55);
        int int57 = org.apache.commons.math.util.MathUtils.distanceInf(intArray41, intArray55);
        int int58 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray41);
        java.lang.Class<?> wildcardClass59 = intArray5.getClass();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 56 + "'", int14 == 56);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 121.51131634543344d + "'", double29 == 121.51131634543344d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 195 + "'", int42 == 195);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 65 + "'", int57 == 65);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 195 + "'", int58 == 195);
        org.junit.Assert.assertNotNull(wildcardClass59);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        long long2 = org.apache.commons.math.util.FastMath.max(151882303972620L, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 151882303972620L + "'", long2 == 151882303972620L);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.0d, (int) (byte) 10, 31500);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(3500, 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.556615209031034E195d + "'", double2 == 6.556615209031034E195d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) (-1.0f));
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray7);
        double[] doubleArray17 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) (-1.0f));
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray17);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 141.43549766589717d + "'", double10 == 141.43549766589717d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 141.43549766589717d + "'", double20 == 141.43549766589717d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 100, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (0.005 >= -0.5)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.7071774883294859d + "'", double9 == 0.7071774883294859d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-1352038911), (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(9603, 3500);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33610500 + "'", int2 == 33610500);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(2.7501303671488815d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6583517018862077d + "'", double1 == 1.6583517018862077d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        float float2 = org.apache.commons.math.util.MathUtils.round(10.0f, 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        int[] intArray0 = null;
        int[] intArray1 = new int[] {};
        int[] intArray6 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray6);
        int[] intArray14 = new int[] { (byte) 0, (byte) 10, '#', (short) -1, (short) 1, 97 };
        int int15 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray14);
        int[] intArray16 = new int[] {};
        int[] intArray21 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int22 = org.apache.commons.math.util.MathUtils.distanceInf(intArray16, intArray21);
        int[] intArray28 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray16, intArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray28);
        int[] intArray31 = new int[] {};
        int[] intArray36 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int37 = org.apache.commons.math.util.MathUtils.distanceInf(intArray31, intArray36);
        int[] intArray42 = new int[] { (byte) 1, '4', '#', 'a' };
        int int43 = org.apache.commons.math.util.MathUtils.distance1(intArray36, intArray42);
        int[] intArray44 = new int[] {};
        int[] intArray49 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int50 = org.apache.commons.math.util.MathUtils.distanceInf(intArray44, intArray49);
        int[] intArray56 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double57 = org.apache.commons.math.util.MathUtils.distance(intArray44, intArray56);
        int int58 = org.apache.commons.math.util.MathUtils.distanceInf(intArray42, intArray56);
        int int59 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray42);
        try {
            int int60 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 56 + "'", int15 == 56);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 121.51131634543344d + "'", double30 == 121.51131634543344d);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 195 + "'", int43 == 195);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 65 + "'", int58 == 65);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 195 + "'", int59 == 195);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) (-6625612056500271398L), 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-6.6256120565002711E18d) + "'", double2 == (-6.6256120565002711E18d));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 779127810, 37413.01421965357d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        int int1 = org.apache.commons.math.util.MathUtils.hash((-2.4492935982947064E-16d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1884947935) + "'", int1 == (-1884947935));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 1624620833);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-55L), (float) 13L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 13.0f + "'", float2 == 13.0f);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection3, false);
        int int6 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) 'a', 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(4.189654742026425d, 2.993222846126381d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.556798099474812d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999020264157933d + "'", double1 == 0.9999020264157933d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.4515827052894548d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3726544820459676d + "'", double1 == 0.3726544820459676d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (double) (-968000650), 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 4L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.5018338600483341d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5486860494636248d + "'", double1 == 0.5486860494636248d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(33610500);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (byte) 0, (int) (byte) 1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        double double1 = org.apache.commons.math.util.FastMath.log(11.489125293076057d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4414009612931853d + "'", double1 == 2.4414009612931853d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 1080582145);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1080582145L + "'", long1 == 1080582145L);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 10, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(21, (-10));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 210 + "'", int2 == 210);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        int int1 = org.apache.commons.math.util.FastMath.abs((-2138030215));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2138030215 + "'", int1 == 2138030215);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 53L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.663528081877013d + "'", double1 == 4.663528081877013d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.5018338600483341d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.794669699186025d + "'", double1 == 0.794669699186025d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, (-10));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 156);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 57270853685L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.36787944117144233d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6065306597126334d + "'", double1 == 0.6065306597126334d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, 2, 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.01f + "'", float3 == 0.01f);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 2.718281828459045d);
        double[] doubleArray27 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) (-1.0f));
        double[] doubleArray36 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) (-1.0f));
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray36);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 2.718281828459045d);
        double double42 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray27);
        double[] doubleArray43 = null;
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray43);
        int int45 = org.apache.commons.math.util.MathUtils.hash(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 139.51318994987582d + "'", double42 == 139.51318994987582d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 9223372036854775807L, 1.556798099474812d, 0.9999999958776927d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 59L, 12.801827480081469d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0f, (java.lang.Number) 64512240L, 63);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 64512240L + "'", number4.equals(64512240L));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection6, false);
        boolean boolean9 = nonMonotonousSequenceException8.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1L, (java.lang.Number) 100, 0);
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        boolean boolean15 = nonMonotonousSequenceException13.getStrict();
        java.lang.String str16 = nonMonotonousSequenceException13.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = nonMonotonousSequenceException13.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 13L, (java.lang.Number) 197L, 156, orderDirection17, true);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (100 >= 1)" + "'", str16.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (100 >= 1)"));
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        long long1 = org.apache.commons.math.util.FastMath.abs((-6625612056500271398L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 6625612056500271398L + "'", long1 == 6625612056500271398L);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(10L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        double double1 = org.apache.commons.math.util.FastMath.asin((-0.4127653077953633d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4254879871148926d) + "'", double1 == (-0.4254879871148926d));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 36);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-10), 1075970048);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        int[] intArray0 = new int[] {};
        int[] intArray5 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int6 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray5);
        int[] intArray7 = new int[] {};
        int[] intArray12 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int13 = org.apache.commons.math.util.MathUtils.distanceInf(intArray7, intArray12);
        int int14 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray7);
        int[] intArray15 = new int[] {};
        int[] intArray20 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray20);
        int[] intArray27 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double28 = org.apache.commons.math.util.MathUtils.distance(intArray15, intArray27);
        int[] intArray29 = new int[] {};
        int[] intArray34 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int35 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray34);
        int[] intArray40 = new int[] { (byte) 1, '4', '#', 'a' };
        int int41 = org.apache.commons.math.util.MathUtils.distance1(intArray34, intArray40);
        int[] intArray42 = new int[] {};
        int[] intArray47 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int48 = org.apache.commons.math.util.MathUtils.distanceInf(intArray42, intArray47);
        int[] intArray54 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double55 = org.apache.commons.math.util.MathUtils.distance(intArray42, intArray54);
        int int56 = org.apache.commons.math.util.MathUtils.distanceInf(intArray40, intArray54);
        int int57 = org.apache.commons.math.util.MathUtils.distanceInf(intArray27, intArray54);
        int int58 = org.apache.commons.math.util.MathUtils.distanceInf(intArray7, intArray27);
        int[] intArray59 = new int[] {};
        int[] intArray64 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int65 = org.apache.commons.math.util.MathUtils.distanceInf(intArray59, intArray64);
        int[] intArray70 = new int[] { (byte) 1, '4', '#', 'a' };
        int int71 = org.apache.commons.math.util.MathUtils.distance1(intArray64, intArray70);
        try {
            int int72 = org.apache.commons.math.util.MathUtils.distanceInf(intArray27, intArray70);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 195 + "'", int41 == 195);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 65 + "'", int56 == 65);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 195 + "'", int71 == 195);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        double double1 = org.apache.commons.math.util.FastMath.rint(5.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.0d + "'", double1 == 5.0d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray25 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) (-1.0f));
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray25);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (short) 1);
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1989426017 + "'", int31 == 1989426017);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        int int2 = org.apache.commons.math.util.FastMath.max(1078820864, 195);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078820864 + "'", int2 == 1078820864);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray25 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) (-1.0f));
        double[] doubleArray34 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, (double) (-1.0f));
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray34);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, 2.718281828459045d);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray25);
        java.lang.Class<?> wildcardClass41 = doubleArray15.getClass();
        java.lang.Class<?> wildcardClass42 = doubleArray15.getClass();
        double[] doubleArray49 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, (double) (-1.0f));
        double[] doubleArray58 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, (double) (-1.0f));
        double double61 = org.apache.commons.math.util.MathUtils.distance1(doubleArray49, doubleArray58);
        double[] doubleArray68 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray70 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray68, (double) (-1.0f));
        double double71 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray58, doubleArray68);
        double[] doubleArray73 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, (double) (short) 1);
        double double74 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray58);
        double[] doubleArray76 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, (double) 1L);
        double double77 = org.apache.commons.math.util.MathUtils.distance(doubleArray15, doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 141.43549766589717d + "'", double74 == 141.43549766589717d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 140.7283201775677d + "'", double77 == 140.7283201775677d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        int[] intArray0 = null;
        int[] intArray1 = new int[] {};
        int[] intArray6 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray6);
        int[] intArray14 = new int[] { (byte) 0, (byte) 10, '#', (short) -1, (short) 1, 97 };
        int int15 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray14);
        int[] intArray16 = new int[] {};
        int[] intArray21 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int22 = org.apache.commons.math.util.MathUtils.distanceInf(intArray16, intArray21);
        int[] intArray28 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray16, intArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray28);
        int[] intArray31 = new int[] {};
        int[] intArray36 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int37 = org.apache.commons.math.util.MathUtils.distanceInf(intArray31, intArray36);
        int[] intArray42 = new int[] { (byte) 1, '4', '#', 'a' };
        int int43 = org.apache.commons.math.util.MathUtils.distance1(intArray36, intArray42);
        int[] intArray44 = new int[] {};
        int[] intArray49 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int50 = org.apache.commons.math.util.MathUtils.distanceInf(intArray44, intArray49);
        int[] intArray56 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double57 = org.apache.commons.math.util.MathUtils.distance(intArray44, intArray56);
        int int58 = org.apache.commons.math.util.MathUtils.distanceInf(intArray42, intArray56);
        double double59 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray42);
        int[] intArray60 = new int[] {};
        int[] intArray65 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int66 = org.apache.commons.math.util.MathUtils.distanceInf(intArray60, intArray65);
        int[] intArray71 = new int[] { (byte) 1, '4', '#', 'a' };
        int int72 = org.apache.commons.math.util.MathUtils.distance1(intArray65, intArray71);
        int[] intArray73 = new int[] {};
        int[] intArray78 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int79 = org.apache.commons.math.util.MathUtils.distanceInf(intArray73, intArray78);
        int[] intArray85 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double86 = org.apache.commons.math.util.MathUtils.distance(intArray73, intArray85);
        int int87 = org.apache.commons.math.util.MathUtils.distanceInf(intArray71, intArray85);
        int int88 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray85);
        try {
            int int89 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray85);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 56 + "'", int15 == 56);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 121.51131634543344d + "'", double30 == 121.51131634543344d);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 195 + "'", int43 == 195);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 65 + "'", int58 == 65);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 117.12813496338103d + "'", double59 == 117.12813496338103d);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 195 + "'", int72 == 195);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 65 + "'", int87 == 65);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 197 + "'", int88 == 197);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(104L, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        double double1 = org.apache.commons.math.util.FastMath.rint(4.882801922586371d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.0d + "'", double1 == 5.0d);
    }
}

