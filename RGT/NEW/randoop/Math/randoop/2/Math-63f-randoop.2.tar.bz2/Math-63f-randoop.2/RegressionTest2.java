import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-279932959));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (byte) 10, 20.604503744420224d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 20.604503744420224d + "'", double2 == 20.604503744420224d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 3500.0f, 13260.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        int[] intArray0 = new int[] {};
        int[] intArray5 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int6 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray5);
        int[] intArray7 = new int[] {};
        int[] intArray12 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int13 = org.apache.commons.math.util.MathUtils.distanceInf(intArray7, intArray12);
        int[] intArray18 = new int[] { (byte) 1, '4', '#', 'a' };
        int int19 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray18);
        int[] intArray21 = null;
        try {
            double double22 = org.apache.commons.math.util.MathUtils.distance(intArray18, intArray21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 195 + "'", int19 == 195);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 117.12813496338103d + "'", double20 == 117.12813496338103d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 210);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        int[] intArray0 = new int[] {};
        int[] intArray5 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int6 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray5);
        int[] intArray13 = new int[] { (byte) 0, (byte) 10, '#', (short) -1, (short) 1, 97 };
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray13);
        int[] intArray15 = new int[] {};
        int[] intArray20 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray20);
        int[] intArray27 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double28 = org.apache.commons.math.util.MathUtils.distance(intArray15, intArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray27);
        int[] intArray30 = new int[] {};
        int[] intArray35 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int36 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray35);
        int[] intArray42 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double43 = org.apache.commons.math.util.MathUtils.distance(intArray30, intArray42);
        int[] intArray44 = new int[] {};
        int[] intArray49 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int50 = org.apache.commons.math.util.MathUtils.distanceInf(intArray44, intArray49);
        int[] intArray55 = new int[] { (byte) 1, '4', '#', 'a' };
        int int56 = org.apache.commons.math.util.MathUtils.distance1(intArray49, intArray55);
        int[] intArray57 = new int[] {};
        int[] intArray62 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int63 = org.apache.commons.math.util.MathUtils.distanceInf(intArray57, intArray62);
        int[] intArray69 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double70 = org.apache.commons.math.util.MathUtils.distance(intArray57, intArray69);
        int int71 = org.apache.commons.math.util.MathUtils.distanceInf(intArray55, intArray69);
        int int72 = org.apache.commons.math.util.MathUtils.distanceInf(intArray42, intArray69);
        double double73 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray69);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 56 + "'", int14 == 56);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 121.51131634543344d + "'", double29 == 121.51131634543344d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 195 + "'", int56 == 195);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 65 + "'", int71 == 65);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 121.51131634543344d + "'", double73 == 121.51131634543344d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 2.718281828459045d);
        double[] doubleArray27 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) (-1.0f));
        double[] doubleArray36 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) (-1.0f));
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray36);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 2.718281828459045d);
        double double42 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray27);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (-0.9999999999999999d));
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) 99.0f);
        double[] doubleArray53 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray55 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, (double) (-1.0f));
        double[] doubleArray62 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray64 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray62, (double) (-1.0f));
        double double65 = org.apache.commons.math.util.MathUtils.distance1(doubleArray53, doubleArray62);
        double[] doubleArray67 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, 2.718281828459045d);
        double[] doubleArray74 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray76 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray74, (double) (-1.0f));
        double[] doubleArray83 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray85 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray83, (double) (-1.0f));
        double double86 = org.apache.commons.math.util.MathUtils.distance1(doubleArray74, doubleArray83);
        boolean boolean87 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray67, doubleArray74);
        boolean boolean88 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 139.51318994987582d + "'", double42 == 139.51318994987582d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-888018845));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.88018845E8d + "'", double1 == 8.88018845E8d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        java.lang.Class<?> wildcardClass4 = orderDirection3.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97, (java.lang.Number) 572.9577951308232d, (int) (byte) 0, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection10, false);
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException6.getSuppressed();
        java.lang.String str15 = nonMonotonousSequenceException6.toString();
        java.lang.Throwable[] throwableArray16 = nonMonotonousSequenceException6.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.2250738585072014E-308d, (java.lang.Number) Float.NaN, 32);
        int int21 = nonMonotonousSequenceException20.getIndex();
        java.lang.Number number22 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number22, (java.lang.Number) 4.248699261236361d, (-1352038911));
        nonMonotonousSequenceException20.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException25);
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException20);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = nonMonotonousSequenceException6.getDirection();
        java.lang.String str29 = nonMonotonousSequenceException6.toString();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (572.958 > 97)" + "'", str15.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (572.958 > 97)"));
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 32 + "'", int21 == 32);
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (572.958 > 97)" + "'", str29.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (572.958 > 97)"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1352038911));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1352038911 + "'", int1 == 1352038911);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-984724751));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-69), 13L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1252588625290418901L) + "'", long2 == (-1252588625290418901L));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 97.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.41032129904824216d) + "'", double1 == (-0.41032129904824216d));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.20052306453833568d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5853129205049546d + "'", double1 == 0.5853129205049546d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.6360918687915654d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1078820864);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-968004150), (long) 1079574628);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 522516360069353100L + "'", long2 == 522516360069353100L);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.6674572193582448d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5112998429212577d + "'", double1 == 0.5112998429212577d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.665201168491711d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(1.179103839756096d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        int int8 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (100 < 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (100 < 0)"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(0, (-2138030215));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2138030215 + "'", int2 == 2138030215);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 99, 1.5607966601082315d, (-0.7568024953079282d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 97);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 1624620833);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1624620833L + "'", long1 == 1624620833L);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) (-1.0f));
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        double[] doubleArray17 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) (-1.0f));
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double[] doubleArray27 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) (-1.0f));
        double[] doubleArray36 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) (-1.0f));
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray36);
        double[] doubleArray46 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) (-1.0f));
        double double49 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray36, doubleArray46);
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) (short) 1);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equals(doubleArray17, doubleArray51);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray17);
        try {
            double double54 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.7071774883294859d + "'", double10 == 0.7071774883294859d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 141.43549766589717d + "'", double20 == 141.43549766589717d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 99);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.288241522117258d + "'", double1 == 5.288241522117258d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (byte) 10, 1352038911);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-2138030215));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        long long1 = org.apache.commons.math.util.MathUtils.sign((-2072794013720961147L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(2.2250738585072014E-308d, 0.9998219848673034d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.225073858507202E-308d + "'", double2 == 2.225073858507202E-308d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1080582144, (float) 197L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 197.0f + "'", float2 == 197.0f);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 92.13617560368711d + "'", double1 == 92.13617560368711d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        double double1 = org.apache.commons.math.util.FastMath.rint(67.99999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 68.0d + "'", double1 == 68.0d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        double double2 = org.apache.commons.math.util.FastMath.max(2.220446049250313E-16d, 100.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        double double1 = org.apache.commons.math.util.FastMath.cosh(4051.5420254925943d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        double double2 = org.apache.commons.math.util.FastMath.min(4.573022699008911d, (double) (-69));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-69.0d) + "'", double2 == (-69.0d));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.6583517018862077d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2877700500812277d + "'", double1 == 1.2877700500812277d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(36L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-0.2858640202755717d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.27832363159831786d) + "'", double1 == (-0.27832363159831786d));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        double double2 = org.apache.commons.math.util.FastMath.max(1.0831800840797905d, 5730.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5730.0d + "'", double2 == 5730.0d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(53, (int) 'a');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) (-1.0f));
        double[] doubleArray16 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) (-1.0f));
        double[] doubleArray25 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) (-1.0f));
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray25);
        double[] doubleArray35 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) (-1.0f));
        double double38 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray25, doubleArray35);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) (short) 1);
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) 1L);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray9, doubleArray25);
        double[] doubleArray51 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, (double) (-1.0f));
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray51);
        double[] doubleArray61 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray61, (double) (-1.0f));
        double double64 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray61);
        double double65 = org.apache.commons.math.util.MathUtils.distance1(doubleArray51, doubleArray61);
        double double66 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray25, doubleArray51);
        try {
            double double67 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 141.43549766589717d + "'", double41 == 141.43549766589717d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 141.43549766589717d + "'", double54 == 141.43549766589717d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 141.43549766589717d + "'", double64 == 141.43549766589717d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-2072794013720961147L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2.07279396E18f + "'", float1 == 2.07279396E18f);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 1.389883474391312E16d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(201.00931639928152d, (-4.503599627370496E15d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 201.0093163992815d + "'", double2 == 201.0093163992815d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-968004150));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(4.2012104037905144E25d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4071162498364887E27d + "'", double1 == 2.4071162498364887E27d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 1079574528, (-0.4254879871148926d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.079574528E9d + "'", double2 == 1.079574528E9d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        double double2 = org.apache.commons.math.util.MathUtils.round((-0.5486677646162761d), 195);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.5486677646162761d) + "'", double2 == (-0.5486677646162761d));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        double double1 = org.apache.commons.math.util.FastMath.asin(4.127059477140893E283d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        double double1 = org.apache.commons.math.util.FastMath.cosh(90.78d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3311379696385056E39d + "'", double1 == 1.3311379696385056E39d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection3, false);
        java.lang.String str6 = nonMonotonousSequenceException5.toString();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (100 < 0)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (100 < 0)"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) 0 + "'", number7.equals((short) 0));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray25 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) (-1.0f));
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray25);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (short) 1);
        double double31 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray38 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, (double) (-1.0f));
        double[] doubleArray47 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, (double) (-1.0f));
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray47);
        double[] doubleArray57 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray57, (double) (-1.0f));
        double double60 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray47, doubleArray57);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, (double) (short) 1);
        double double63 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray47);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray47);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (1 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 141.43549766589717d + "'", double31 == 141.43549766589717d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(201.0093163992815d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.913041577021816E86d + "'", double1 == 9.913041577021816E86d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 100, (long) 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 200L + "'", long2 == 200L);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(4.2012104037905144E25d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.476360533117656E8d + "'", double1 == 3.476360533117656E8d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-12.245600189892366d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.158638853279167d + "'", double1 == 4.158638853279167d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        int int1 = org.apache.commons.math.util.FastMath.round(97.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-37L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-37) + "'", int1 == (-37));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (-2072794013720961147L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9499601814350958d) + "'", double1 == (-0.9499601814350958d));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(100.50000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7540558982543015d + "'", double1 == 1.7540558982543015d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6313083693369503E35d + "'", double1 == 2.6313083693369503E35d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        double double2 = org.apache.commons.math.util.FastMath.pow((-0.0749608545604955d), 0.5486860494636248d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(195, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3900 + "'", int2 == 3900);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(4.294967296E11d, 3628800.0d, 572.9577951308232d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((-9218868437227405312L), (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-9218868437227405312L) + "'", long2 == (-9218868437227405312L));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 0, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 9.848857801796104d, (java.lang.Number) 4.248699261236361d, 100, orderDirection6, true);
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException10.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray11);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        int int1 = org.apache.commons.math.util.MathUtils.hash(2.955726068636564E52d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-893328343) + "'", int1 == (-893328343));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 100.0f, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 99.99999999999999d + "'", double2 == 99.99999999999999d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-1352038911), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 1399733633L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3997336330000002E9d + "'", double1 == 1.3997336330000002E9d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection6, false);
        java.lang.Class<?> wildcardClass9 = orderDirection6.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.5018338600483341d, (java.lang.Number) 32, 32, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.2250738585072014E-308d, (java.lang.Number) Float.NaN, 32);
        int int16 = nonMonotonousSequenceException15.getIndex();
        java.lang.Number number17 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number17, (java.lang.Number) 4.248699261236361d, (-1352038911));
        nonMonotonousSequenceException15.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException20);
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 32 + "'", int16 == 32);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        double double2 = org.apache.commons.math.util.FastMath.atan2(2.6881171418161356E43d, (-0.9499601814350958d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.9440892412430648d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0907187537628569d + "'", double1 == 1.0907187537628569d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.7249085520219886d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.012652041008648298d + "'", double1 == 0.012652041008648298d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 68, (double) 13.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 67.99999999999999d + "'", double2 == 67.99999999999999d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-893328343));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5.118394377331518E10d) + "'", double1 == (-5.118394377331518E10d));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((-454785511), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        double double1 = org.apache.commons.math.util.FastMath.sin(2.221181889247967d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7958504022274034d + "'", double1 == 0.7958504022274034d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        double double1 = org.apache.commons.math.util.FastMath.expm1(4.882801922586371d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 130.99999999999997d + "'", double1 == 130.99999999999997d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        int int2 = org.apache.commons.math.util.FastMath.min(36, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36 + "'", int2 == 36);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(65.99621212121211d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3781.30441839558d + "'", double1 == 3781.30441839558d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        double[] doubleArray0 = null;
        java.lang.Number number8 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, number8, 0, orderDirection10, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.665201168491711d, (java.lang.Number) 0.6931471784987917d, (-1), orderDirection10, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.6569141418449421d), (java.lang.Number) 1.1102230246251565E-16d, (int) (short) 10, orderDirection10, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0, orderDirection10, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-62));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.4422495703074083d, 2.4830062883006265d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 888019095L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.948422304476766d + "'", double1 == 8.948422304476766d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-62));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1989426017, (-53));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (-1352038911));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1352038911L) + "'", long1 == (-1352038911L));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-893328343), 10);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 13L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.605551275463989d + "'", double1 == 3.605551275463989d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.022126756261955736d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1167939852 + "'", int1 == 1167939852);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-893328343), (-0.0749608545604955d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963268788085d) + "'", double2 == (-1.5707963268788085d));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 97L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.691673596021348E41d + "'", double1 == 6.691673596021348E41d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        double double1 = org.apache.commons.math.util.FastMath.acosh(4.573022699008911d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2011467903722264d + "'", double1 == 2.2011467903722264d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (short) 1, 33610500);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33610500 + "'", int2 == 33610500);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 9603);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1354487784640475d) + "'", double1 == (-1.1354487784640475d));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 2.718281828459045d);
        double[] doubleArray27 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) (-1.0f));
        double[] doubleArray36 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) (-1.0f));
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray36);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 2.718281828459045d);
        double double42 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray27);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (-0.9999999999999999d));
        double[] doubleArray51 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, (double) (-1.0f));
        double double54 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray51);
        double double55 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 139.51318994987582d + "'", double42 == 139.51318994987582d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 139.51318994987582d + "'", double54 == 139.51318994987582d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 141.43549766589717d + "'", double55 == 141.43549766589717d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 80L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 80L + "'", long1 == 80L);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(57270853685L, 104L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5956168783240L + "'", long2 == 5956168783240L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.00000000000001d + "'", double1 == 32.00000000000001d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        int int1 = org.apache.commons.math.util.FastMath.abs(65);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 65 + "'", int1 == 65);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray25 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) (-1.0f));
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray25);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (short) 1);
        double double31 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) 1L);
        java.lang.Class<?> wildcardClass34 = doubleArray15.getClass();
        java.lang.Number number39 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection41 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException43 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, number39, 0, orderDirection41, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException45 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.665201168491711d, (java.lang.Number) 0.6931471784987917d, (-1), orderDirection41, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15, orderDirection41, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly decreasing (-1 <= 100)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 141.43549766589717d + "'", double31 == 141.43549766589717d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + orderDirection41 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection41.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (byte) 10, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 0.01f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.734723475976807E-18d + "'", double1 == 1.734723475976807E-18d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 0.01f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.010050166858404251d + "'", double1 == 0.010050166858404251d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 10, 779127810);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 779127810 + "'", int2 == 779127810);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1075970048, 65);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection3, false);
        java.lang.String str6 = nonMonotonousSequenceException5.toString();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Number number8 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Number number9 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (100 < 0)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (100 < 0)"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 100.0f + "'", number7.equals(100.0f));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 100.0f + "'", number8.equals(100.0f));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (short) 0 + "'", number9.equals((short) 0));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, 108L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 108L + "'", long2 == 108L);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.7071774883294859d, 1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7071774883294859d + "'", double2 == 0.7071774883294859d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        double double1 = org.apache.commons.math.util.FastMath.cos(67.99999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.44014302249602794d + "'", double1 == 0.44014302249602794d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.6674572193582448d, (-984724751));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.162351711701654E226d) + "'", double2 == (-3.162351711701654E226d));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-10), 156);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.283185307179587d + "'", double1 == 6.283185307179587d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 10);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (int) (byte) 100);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (int) (short) 10);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (int) (byte) 100);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger11);
        java.math.BigInteger bigInteger15 = null;
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) 0);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (int) (short) 10);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, (int) (byte) 100);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, 9603);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) (-1352038911L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1105975906) + "'", int1 == (-1105975906));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        double double1 = org.apache.commons.math.util.FastMath.tanh(130.99999999999997d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 1080582145, 100.0d, 2.225073858507202E-308d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray25 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) (-1.0f));
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray25);
        double[] doubleArray35 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) (-1.0f));
        double[] doubleArray44 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, (double) (-1.0f));
        double double47 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray44);
        double[] doubleArray54 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray54, (double) (-1.0f));
        double double57 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray44, doubleArray54);
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, (double) (short) 1);
        double double60 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray44);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, (double) 1L);
        double double63 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray62);
        int int64 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray71 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray73 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray71, (double) (-1.0f));
        double[] doubleArray80 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray82 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray80, (double) (-1.0f));
        double double83 = org.apache.commons.math.util.MathUtils.distance1(doubleArray71, doubleArray80);
        double[] doubleArray90 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray92 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray90, (double) (-1.0f));
        double double93 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray80, doubleArray90);
        double[] doubleArray95 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray80, (double) (short) 1);
        double double96 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray80);
        double[] doubleArray98 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray80, (double) 1L);
        boolean boolean99 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 141.43549766589717d + "'", double60 == 141.43549766589717d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 99.50000000000001d + "'", double63 == 99.50000000000001d);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1989426017 + "'", int64 == 1989426017);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 0.0d + "'", double93 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray95);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 141.43549766589717d + "'", double96 == 141.43549766589717d);
        org.junit.Assert.assertNotNull(doubleArray98);
        org.junit.Assert.assertTrue("'" + boolean99 + "' != '" + true + "'", boolean99 == true);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        double double2 = org.apache.commons.math.util.FastMath.pow((-21.999999999999996d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection11, false);
        boolean boolean14 = nonMonotonousSequenceException13.getStrict();
        java.lang.String str15 = nonMonotonousSequenceException13.toString();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (100 < 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (100 < 0)"));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (100 < 0)" + "'", str15.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (100 < 0)"));
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 10);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (int) (short) 10);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger9);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (int) (short) 10);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) 0);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (int) (short) 10);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger20);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger15);
        try {
            java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (int) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger22);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-1105975906), 156);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.9223077160213498d, 1.7453292519943295d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-97), 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 33610500);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 18.023496256675422d + "'", double1 == 18.023496256675422d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        double double1 = org.apache.commons.math.util.FastMath.acos(267.7467614837482d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 3500, (int) (short) -1, (int) (byte) 10);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(56, (int) 'a');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, number1, 0, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (-97.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.594700892207039d) + "'", double1 == (-4.594700892207039d));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.9850853666260323d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5527919788071113d + "'", double1 == 0.5527919788071113d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        double double2 = org.apache.commons.math.util.MathUtils.round(267.7467614837482d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 268.0d + "'", double2 == 268.0d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        long long1 = org.apache.commons.math.util.FastMath.abs(151882303972620L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 151882303972620L + "'", long1 == 151882303972620L);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.1920928955078125E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1920928955078125E-7d + "'", double1 == 1.1920928955078125E-7d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.6674572193582448d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6674572193582448d + "'", double1 == 0.6674572193582448d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-2138030215), 195);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        int[] intArray0 = new int[] {};
        int[] intArray5 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int6 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray5);
        int[] intArray11 = new int[] { (byte) 1, '4', '#', 'a' };
        int int12 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray11);
        int[] intArray13 = new int[] {};
        int[] intArray18 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int19 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray18);
        int[] intArray25 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double26 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray25);
        int[] intArray27 = new int[] {};
        int[] intArray32 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int33 = org.apache.commons.math.util.MathUtils.distanceInf(intArray27, intArray32);
        int[] intArray40 = new int[] { (byte) 0, (byte) 10, '#', (short) -1, (short) 1, 97 };
        int int41 = org.apache.commons.math.util.MathUtils.distance1(intArray32, intArray40);
        int[] intArray42 = new int[] {};
        int[] intArray47 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int48 = org.apache.commons.math.util.MathUtils.distanceInf(intArray42, intArray47);
        int[] intArray54 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double55 = org.apache.commons.math.util.MathUtils.distance(intArray42, intArray54);
        double double56 = org.apache.commons.math.util.MathUtils.distance(intArray32, intArray54);
        int[] intArray57 = new int[] {};
        int[] intArray62 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int63 = org.apache.commons.math.util.MathUtils.distanceInf(intArray57, intArray62);
        int[] intArray68 = new int[] { (byte) 1, '4', '#', 'a' };
        int int69 = org.apache.commons.math.util.MathUtils.distance1(intArray62, intArray68);
        int[] intArray70 = new int[] {};
        int[] intArray75 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int76 = org.apache.commons.math.util.MathUtils.distanceInf(intArray70, intArray75);
        int[] intArray82 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double83 = org.apache.commons.math.util.MathUtils.distance(intArray70, intArray82);
        int int84 = org.apache.commons.math.util.MathUtils.distanceInf(intArray68, intArray82);
        double double85 = org.apache.commons.math.util.MathUtils.distance(intArray32, intArray68);
        int int86 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray32);
        int int87 = org.apache.commons.math.util.MathUtils.distance1(intArray11, intArray32);
        java.lang.Class<?> wildcardClass88 = intArray11.getClass();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 195 + "'", int12 == 195);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 56 + "'", int41 == 56);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 121.51131634543344d + "'", double56 == 121.51131634543344d);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 195 + "'", int69 == 195);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 65 + "'", int84 == 65);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 117.12813496338103d + "'", double85 == 117.12813496338103d);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 0 + "'", int86 == 0);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 195 + "'", int87 == 195);
        org.junit.Assert.assertNotNull(wildcardClass88);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1078820864, 197);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-279932959));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 279932959L + "'", long1 == 279932959L);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        double double1 = org.apache.commons.math.util.FastMath.asin(75.69676347110223d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(100, (-968000650));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        double double1 = org.apache.commons.math.util.FastMath.log1p(5730.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.653645314551737d + "'", double1 == 8.653645314551737d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 4.248699261236361d, (-1352038911));
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(2.225073858507202E-308d, 0.0d, 195);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        double double1 = org.apache.commons.math.util.FastMath.sinh(2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 2.718281828459045d);
        double[] doubleArray27 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) (-1.0f));
        double[] doubleArray36 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) (-1.0f));
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray36);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 2.718281828459045d);
        double double42 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray27);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, 10.0d);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, 57.29577951308232d);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, 8938.141604040842d);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray46);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (0.286 >= -0.286)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 139.51318994987582d + "'", double42 == 139.51318994987582d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(32, (-968004150));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1167939852, 1352038911);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        double double1 = org.apache.commons.math.util.FastMath.atan((-0.41032129904824216d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.38937226128359037d) + "'", double1 == (-0.38937226128359037d));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1075970048, (-1352038911));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.641588833612779d + "'", double1 == 4.641588833612779d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 779127710);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.57079632551141d + "'", double1 == 1.57079632551141d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-2.220446049250313E-16d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.930380657631324E-32d + "'", double1 == 4.930380657631324E-32d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        double double2 = org.apache.commons.math.util.FastMath.min(0.7249085520219886d, Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 52.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7160033436347992d + "'", double1 == 1.7160033436347992d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1352038911, (double) 52L, (double) 197.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        double double1 = org.apache.commons.math.util.FastMath.log(117.12813496338103d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.763268506163082d + "'", double1 == 4.763268506163082d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 1624620833, (long) (-53));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1624620886L + "'", long2 == 1624620886L);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1078820864, 65);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        int int1 = org.apache.commons.math.util.MathUtils.sign(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 21);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 57270853685L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.7270853685E10d + "'", double1 == 5.7270853685E10d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        double double1 = org.apache.commons.math.util.FastMath.expm1(4.641588833612779d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 102.70899308565303d + "'", double1 == 102.70899308565303d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 197L, 0.4278171389293276d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.585438304388047d + "'", double2 == 9.585438304388047d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.2533141373155001d, 5.288241522117258d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-8.881381194183809E-7d), (java.lang.Number) 99.0f, (int) (short) -1);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (99 >= -0)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (99 >= -0)"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(5.288241522117258d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.09229722620162269d + "'", double1 == 0.09229722620162269d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 6625612056500271398L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.6256120565002711E18d + "'", double1 == 6.6256120565002711E18d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        java.lang.Class<?> wildcardClass4 = orderDirection3.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97, (java.lang.Number) 572.9577951308232d, (int) (byte) 0, orderDirection3, false);
        boolean boolean7 = nonMonotonousSequenceException6.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(0L, (-22L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        java.lang.Class<?> wildcardClass7 = orderDirection6.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97, (java.lang.Number) 572.9577951308232d, (int) (byte) 0, orderDirection6, false);
        int int10 = nonMonotonousSequenceException9.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException9.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.02556940209677608d, (java.lang.Number) 1987797057, 97, orderDirection11, true);
        java.lang.Number number14 = nonMonotonousSequenceException13.getPrevious();
        java.lang.String str15 = nonMonotonousSequenceException13.toString();
        int int16 = nonMonotonousSequenceException13.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 1987797057 + "'", number14.equals(1987797057));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly increasing (1,987,797,057 >= 0.026)" + "'", str15.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly increasing (1,987,797,057 >= 0.026)"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 97 + "'", int16 == 97);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1080582145L, (float) (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        int int1 = org.apache.commons.math.util.FastMath.abs(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0f, (java.lang.Number) 64512240L, 63);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number6 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 64512240L + "'", number6.equals(64512240L));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1105975906));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1105975906 + "'", int1 == 1105975906);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-984724751), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-984724751) + "'", int2 == (-984724751));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.4278171389293276d, (double) (-454785511));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.42781713892932755d + "'", double2 == 0.42781713892932755d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        double double1 = org.apache.commons.math.util.FastMath.tan(4.2012104037905144E25d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.046776136927120265d + "'", double1 == 0.046776136927120265d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.9991050130774393d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(35, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 10);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (int) (short) 10);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger9);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (int) (short) 10);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger13);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) 1167939852);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1352038911), (-893328343));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((-55L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-55L) + "'", long2 == (-55L));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(53.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.206879716514544E22d + "'", double1 == 5.206879716514544E22d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(53.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.206879716514544E22d + "'", double1 == 5.206879716514544E22d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 62L, (double) (-97.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 61.99999999999999d + "'", double2 == 61.99999999999999d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(888019042, (-97));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-62), 4L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14776336 + "'", int2 == 14776336);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 141.43549766589717d + "'", double9 == 141.43549766589717d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 141.43549766589717d + "'", double10 == 141.43549766589717d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(20532231);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.0E194d, (double) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.999999999999998E193d + "'", double2 == 9.999999999999998E193d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.7568024953079282d), 75.69676347110224d, 1.556798099474812d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) (-1352038911L), 4.930380657631324E-32d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 888019239, (-9.889466189365882d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.880192389999999E8d + "'", double2 == 8.880192389999999E8d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, (-984724751));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(1.079574528E9d, (-1105975906), (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.4127653077953633d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9160150401636142d + "'", double1 == 0.9160150401636142d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        double double2 = org.apache.commons.math.util.MathUtils.log(56.0d, 4.127059477140893E283d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 162.2340596929131d + "'", double2 == 162.2340596929131d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-10));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection3, false);
        java.lang.String str6 = nonMonotonousSequenceException5.toString();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        java.lang.Class<?> wildcardClass9 = orderDirection8.getClass();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (100 < 0)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (100 < 0)"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 100.0f + "'", number7.equals(100.0f));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.794669699186025d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0187171445731638d + "'", double1 == 1.0187171445731638d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (byte) 10, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-968000650), (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-968000660L) + "'", long2 == (-968000660L));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.44014302249602794d, (double) 3500);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3500.174359121526d + "'", double2 == 3500.174359121526d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        long long2 = org.apache.commons.math.util.FastMath.min(151882303972620L, 13L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 13L + "'", long2 == 13L);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 9);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        java.lang.Class<?> wildcardClass4 = orderDirection3.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97, (java.lang.Number) 572.9577951308232d, (int) (byte) 0, orderDirection3, false);
        int int7 = nonMonotonousSequenceException6.getIndex();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException6.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-2L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.0d) + "'", double1 == (-3.0d));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        long long1 = org.apache.commons.math.util.MathUtils.factorial((int) (short) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) (-1.0f));
        double[] doubleArray16 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) (-1.0f));
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray16);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1);
        try {
            double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 14776336);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 53);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        double double1 = org.apache.commons.math.util.FastMath.atan(59.42317395936698d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5539694636287837d + "'", double1 == 1.5539694636287837d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        double double1 = org.apache.commons.math.util.FastMath.tanh(90.78d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1080582145L, (float) (-62));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-62.0f) + "'", float2 == (-62.0f));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.046776136927120265d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0478873995271376d + "'", double1 == 1.0478873995271376d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        double double1 = org.apache.commons.math.util.FastMath.asinh(4.294967296E11d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 27.479027144466286d + "'", double1 == 27.479027144466286d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        int int2 = org.apache.commons.math.util.FastMath.min(1079574628, (-968004150));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-968004150) + "'", int2 == (-968004150));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-1.792456423065796E9d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.2533141373155003d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0496616655455318d + "'", double1 == 1.0496616655455318d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        double double1 = org.apache.commons.math.util.FastMath.tanh(65.99621212121211d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        int int1 = org.apache.commons.math.util.MathUtils.hash(3.605551275463989d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 74285528 + "'", int1 == 74285528);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(5.286736667635593d, 197, 63);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray25 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) (-1.0f));
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray25);
        double[] doubleArray35 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) (-1.0f));
        double double38 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray45 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (double) (-1.0f));
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray45);
        double double49 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray45);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray35);
        double[] doubleArray51 = null;
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 141.43549766589717d + "'", double38 == 141.43549766589717d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 141.43549766589717d + "'", double48 == 141.43549766589717d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(1080582145, (-37L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 2.07279396E18f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.9499601814350958d), 0.20480044364984396d, 0.08139081311424569d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray25 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) (-1.0f));
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray25);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (short) 1);
        double double31 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray38 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, (double) (-1.0f));
        double[] doubleArray47 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, (double) (-1.0f));
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray47);
        double[] doubleArray57 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray57, (double) (-1.0f));
        double double60 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray47, doubleArray57);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, (double) (short) 1);
        double double63 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray47);
        int int64 = org.apache.commons.math.util.MathUtils.hash(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 141.43549766589717d + "'", double31 == 141.43549766589717d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1989426017 + "'", int64 == 1989426017);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        double double2 = org.apache.commons.math.util.MathUtils.log(Double.NEGATIVE_INFINITY, 4.944515159673473E42d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) ' ', 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-97), (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        double double1 = org.apache.commons.math.util.FastMath.log(4.763268506163082d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5609340935581888d + "'", double1 == 1.5609340935581888d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-37), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-37L) + "'", long2 == (-37L));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        double double1 = org.apache.commons.math.util.FastMath.tan(43.66827237527655d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.32477101382376d) + "'", double1 == (-0.32477101382376d));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.9165215479156338d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 1352038911);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 4.248699261236361d, (-1352038911));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        java.lang.Class<?> wildcardClass8 = orderDirection7.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97, (java.lang.Number) 572.9577951308232d, (int) (byte) 0, orderDirection7, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection14, false);
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        java.lang.Throwable[] throwableArray18 = nonMonotonousSequenceException10.getSuppressed();
        java.lang.Number number19 = nonMonotonousSequenceException10.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        int int21 = nonMonotonousSequenceException10.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 97 + "'", number19.equals(97));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.4422495703074083d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (-62.0f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        double double2 = org.apache.commons.math.util.FastMath.pow(8.853665407629286d, (double) 197);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.830467268363199E186d + "'", double2 == 3.830467268363199E186d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray25 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) (-1.0f));
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray25);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (short) 1);
        double double31 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) 1L);
        java.lang.Class<?> wildcardClass34 = doubleArray15.getClass();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (1 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 141.43549766589717d + "'", double31 == 141.43549766589717d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(wildcardClass34);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(62L, 5956168783240L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 369282464560880L + "'", long2 == 369282464560880L);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1987797057, (int) (short) 10, (-984724751));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1102230246251565E-16d + "'", double2 == 1.1102230246251565E-16d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        double double1 = org.apache.commons.math.util.FastMath.abs(9.848857801796104d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.848857801796104d + "'", double1 == 9.848857801796104d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 10, (-37));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-37) + "'", int2 == (-37));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-0.1726037463d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 1079574628, 5.656854249492381d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963215550047d + "'", double2 == 1.5707963215550047d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(100, 1080582145);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1080582045) + "'", int2 == (-1080582045));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 52L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1105975906), (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        long long1 = org.apache.commons.math.util.FastMath.abs(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 1080582144);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.384185791015625E-7d + "'", double1 == 2.384185791015625E-7d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.7763568394002505E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 2.718281828459045d);
        double[] doubleArray27 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) (-1.0f));
        double[] doubleArray36 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) (-1.0f));
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray36);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 2.718281828459045d);
        double double42 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray27);
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) 62L);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 139.51318994987582d + "'", double42 == 139.51318994987582d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.9223077160213498d + "'", double43 == 1.9223077160213498d);
        org.junit.Assert.assertNotNull(doubleArray45);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 80L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        java.lang.Class<?> wildcardClass7 = orderDirection6.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.2858640202755717d), (java.lang.Number) 117.12813496338103d, 1399733633, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.5403023093369417d, (java.lang.Number) 98.64085908577049d, 1987797057, orderDirection6, false);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(0, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 32);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 32.0f + "'", float1 == 32.0f);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.154434690031884d, (java.lang.Number) 2L, 888019042);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(1300L, (long) 2138030215);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2138028915L) + "'", long2 == (-2138028915L));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1105975906), (-37));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1105975869) + "'", int2 == (-1105975869));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-279932959), 68);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 888019095L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.7071774883294858d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7601986612033375d + "'", double1 == 0.7601986612033375d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(9.999999999999998E193d, 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 2.718281828459045d);
        double[] doubleArray27 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) (-1.0f));
        double[] doubleArray36 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) (-1.0f));
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray36);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 2.718281828459045d);
        double double42 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray27);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, 117.12813496338103d);
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray44);
        double[] doubleArray52 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray52, (double) (-1.0f));
        double[] doubleArray61 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray61, (double) (-1.0f));
        double[] doubleArray70 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray72 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray70, (double) (-1.0f));
        double double73 = org.apache.commons.math.util.MathUtils.distance1(doubleArray61, doubleArray70);
        double double74 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray70);
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray54, doubleArray70);
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray44, doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 139.51318994987582d + "'", double42 == 139.51318994987582d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 82.83038029612084d + "'", double45 == 82.83038029612084d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 141.43549766589717d + "'", double74 == 141.43549766589717d);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        float float2 = org.apache.commons.math.util.MathUtils.round(13.0f, (-53));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        double double2 = org.apache.commons.math.util.FastMath.min(1.399733633E9d, 5.286736667635593d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.286736667635593d + "'", double2 == 5.286736667635593d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((-2138028915L), (long) 1987797057);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-4125825972L) + "'", long2 == (-4125825972L));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 2.718281828459045d);
        double[] doubleArray27 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) (-1.0f));
        double[] doubleArray36 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) (-1.0f));
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray36);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 2.718281828459045d);
        double double42 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray27);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, 143.1216351825583d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 139.51318994987582d + "'", double42 == 139.51318994987582d);
        org.junit.Assert.assertNotNull(doubleArray44);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.7958504022274034d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(97.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6929693744344998d + "'", double1 == 1.6929693744344998d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        double double1 = org.apache.commons.math.util.FastMath.tan((-6.6256120565002711E18d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.3428067497052016d) + "'", double1 == (-1.3428067497052016d));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 151882303972620L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(56.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.045829748006498E24d + "'", double1 == 1.045829748006498E24d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        double double1 = org.apache.commons.math.util.FastMath.rint(75.69676347110223d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 76.0d + "'", double1 == 76.0d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 10);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 3500);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 142404354048L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.42404354048E11d + "'", double1 == 1.42404354048E11d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-888018845));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        double double1 = org.apache.commons.math.util.FastMath.cosh(4052.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.0d + "'", double1 == 35.0d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (-1080582045));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-43L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        int int2 = org.apache.commons.math.util.FastMath.min((-69), 1167939852);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-69) + "'", int2 == (-69));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        double double1 = org.apache.commons.math.util.FastMath.exp(59.42317395936698d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.414407515177852E25d + "'", double1 == 6.414407515177852E25d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-1080582045));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6932056354284859d + "'", double1 == 0.6932056354284859d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(1.4603914750271216d, (double) 1080582144);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0805821414740984E9d + "'", double2 == 1.0805821414740984E9d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 197, (float) (-968000650));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-9.6800064E8f) + "'", float2 == (-9.6800064E8f));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(74285528, 97);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (byte) 100, (double) 3900);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.02563540852167748d + "'", double2 == 0.02563540852167748d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 2138030215, 0.6729530497092316d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963264801428d + "'", double2 == 1.5707963264801428d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, 65);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((-2072794013720961147L), 156L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2072794013720961303L) + "'", long2 == (-2072794013720961303L));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        java.lang.Class<?> wildcardClass4 = orderDirection3.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97, (java.lang.Number) 572.9577951308232d, (int) (byte) 0, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection10, false);
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException6.getSuppressed();
        java.lang.String str15 = nonMonotonousSequenceException6.toString();
        java.lang.Throwable[] throwableArray16 = nonMonotonousSequenceException6.getSuppressed();
        int int17 = nonMonotonousSequenceException6.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (572.958 > 97)" + "'", str15.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (572.958 > 97)"));
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-1105975869), (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1105975879L) + "'", long2 == (-1105975879L));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-0.9991050130774393d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 1080582144, (long) 1075970048);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1162674021347622912L + "'", long2 == 1162674021347622912L);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, (double) 210, 35);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        double double1 = org.apache.commons.math.util.FastMath.cosh(3.552713678800501E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        double double2 = org.apache.commons.math.util.MathUtils.log(1.6583517018862077d, (double) 1079574628);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 41.12067917735976d + "'", double2 == 41.12067917735976d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (short) 10, (long) 156);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 156L + "'", long2 == 156L);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        double double2 = org.apache.commons.math.util.FastMath.atan2(6.283185307179587d, (double) 3500);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0017951938735791333d + "'", double2 == 0.0017951938735791333d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-888018845), (-968000650), 63);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-1105975906));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        int int2 = org.apache.commons.math.util.FastMath.min(1987797057, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 2.718281828459045d);
        double[] doubleArray27 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) (-1.0f));
        double[] doubleArray36 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) (-1.0f));
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray36);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 2.718281828459045d);
        double double42 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray27);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, 10.0d);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, 57.29577951308232d);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 139.51318994987582d + "'", double42 == 139.51318994987582d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 354302819 + "'", int47 == 354302819);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        java.lang.Number number10 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, number10, 0, orderDirection12, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.665201168491711d, (java.lang.Number) 0.6931471784987917d, (-1), orderDirection12, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.6569141418449421d), (java.lang.Number) 1.1102230246251565E-16d, (int) (short) 10, orderDirection12, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 13L, (java.lang.Number) 11.489125293076057d, 0, orderDirection12, true);
        java.lang.Class<?> wildcardClass21 = orderDirection12.getClass();
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(31500, 888019239);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        double double1 = org.apache.commons.math.util.FastMath.tan(52.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.053272382792838d) + "'", double1 == (-6.053272382792838d));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-43L), 0.4670882772136576d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        int int1 = org.apache.commons.math.util.FastMath.abs(1624620833);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1624620833 + "'", int1 == 1624620833);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1L), (java.lang.Number) 0.5018338600483341d, 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0.502 >= -1)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0.502 >= -1)"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(0L, (long) (-1884947935));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        long long2 = org.apache.commons.math.util.FastMath.min(156L, (long) (-69));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-69L) + "'", long2 == (-69L));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.0187171445731638d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8945468709435429d + "'", double1 == 0.8945468709435429d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (byte) 100, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.8813735841046317d, 1125950.9958367867d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-1.1354487784640475d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-454785511), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-454785511L) + "'", long2 == (-454785511L));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        double double2 = org.apache.commons.math.util.FastMath.min(4.663528081877013d, (-0.9499601814350958d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9499601814350958d) + "'", double2 == (-0.9499601814350958d));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        double double1 = org.apache.commons.math.util.FastMath.atan(100.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5607966601082315d + "'", double1 == 1.5607966601082315d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 64512240L, 11013.232874703393d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5175544230390033d + "'", double2 == 0.5175544230390033d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(5.286736667635593d, (double) 1352038911);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.352038910391644E9d + "'", double2 == 1.352038910391644E9d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 99.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 99.0d + "'", double1 == 99.0d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        double double1 = org.apache.commons.math.util.FastMath.sin((-2.4492935982947064E-16d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.4492935982947064E-16d) + "'", double1 == (-2.4492935982947064E-16d));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(2.99822295029797d, 8.88018845E8d, (double) (-53));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-69L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-69.0d) + "'", double1 == (-69.0d));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray25 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) (-1.0f));
        double[] doubleArray34 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, (double) (-1.0f));
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray34);
        double[] doubleArray44 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, (double) (-1.0f));
        double double47 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray44);
        double[] doubleArray54 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray54, (double) (-1.0f));
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray54);
        double[] doubleArray64 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray64, (double) (-1.0f));
        double double67 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray64);
        double double68 = org.apache.commons.math.util.MathUtils.distance1(doubleArray54, doubleArray64);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray54);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray54);
        double double71 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 141.43549766589717d + "'", double57 == 141.43549766589717d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 141.43549766589717d + "'", double67 == 141.43549766589717d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 141.43549766589717d + "'", double71 == 141.43549766589717d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(63, 68);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(3.830467268363199E186d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.6854265722811046E184d + "'", double1 == 6.6854265722811046E184d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.916079783099616d + "'", double1 == 5.916079783099616d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-6.053272382792838d), 3.552713678800501E-15d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-6.053272382792837d) + "'", double2 == (-6.053272382792837d));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1080582144, (-1105975906));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(3.03494495037239d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.423955077173417d + "'", double1 == 10.423955077173417d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        double double1 = org.apache.commons.math.util.FastMath.log1p(32.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.4965075614664802d + "'", double1 == 3.4965075614664802d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        java.lang.Class<?> wildcardClass4 = orderDirection3.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97, (java.lang.Number) 572.9577951308232d, (int) (byte) 0, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection10, false);
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        boolean boolean14 = nonMonotonousSequenceException12.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(3500, 3900);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7400 + "'", int2 == 7400);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) -1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 197, 36, (-69));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-1884947935), (float) (short) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(5.7270853685E10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.995649622311774E8d + "'", double1 == 9.995649622311774E8d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 2.718281828459045d);
        double[] doubleArray27 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) (-1.0f));
        double[] doubleArray36 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) (-1.0f));
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray36);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray27);
        double[] doubleArray41 = null;
        try {
            double double42 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray27, doubleArray41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(2.6780404899442742d, (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.6780404899442747d + "'", double2 == 2.6780404899442747d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-12.245600189892366d), (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-12.245600189892365d) + "'", double2 == (-12.245600189892365d));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 68);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, 1080582145L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1080582145L + "'", long2 == 1080582145L);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 64512240L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 64512240L + "'", long1 == 64512240L);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.9972233523474408d, (java.lang.Number) 1.0831800840797905d, (int) (short) 0, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertNull(orderDirection6);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double[] doubleArray24 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) (-1.0f));
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray24);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, 2.718281828459045d);
        double[] doubleArray36 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) (-1.0f));
        double[] doubleArray45 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (double) (-1.0f));
        double double48 = org.apache.commons.math.util.MathUtils.distance1(doubleArray36, doubleArray45);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, 2.718281828459045d);
        double double51 = org.apache.commons.math.util.MathUtils.distance(doubleArray29, doubleArray36);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (-0.9999999999999999d));
        double double54 = org.apache.commons.math.util.MathUtils.distance(doubleArray8, doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 139.51318994987582d + "'", double51 == 139.51318994987582d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.2413882881933434E-16d + "'", double54 == 1.2413882881933434E-16d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        java.lang.Number number7 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, number7, 0, orderDirection9, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.665201168491711d, (java.lang.Number) 0.6931471784987917d, (-1), orderDirection9, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.6569141418449421d), (java.lang.Number) 1.1102230246251565E-16d, (int) (short) 10, orderDirection9, true);
        int int16 = nonMonotonousSequenceException15.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        double double3 = org.apache.commons.math.util.MathUtils.round(0.9999999999999999d, (int) (byte) 1, 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 74285528);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-37), 0.9998219848673034d, (double) 197L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.012652041008648298d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.012652378577065889d + "'", double1 == 0.012652378577065889d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, 2.225073858507202E-308d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(156L, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560L + "'", long2 == 1560L);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(2.4830062883006265d, 99);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5737922058673786E30d + "'", double2 == 1.5737922058673786E30d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        long long1 = org.apache.commons.math.util.FastMath.round(1.2533141373155001d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        double double2 = org.apache.commons.math.util.MathUtils.log(20.799832844906106d, 1.1932800462173283d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.058223743635933814d + "'", double2 == 0.058223743635933814d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.4670882772136576d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8928831862356974d + "'", double1 == 0.8928831862356974d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (short) 1, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (byte) 0, (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(56);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 172.35279713916282d + "'", double1 == 172.35279713916282d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.0333147966386297E40d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        int[] intArray5 = new int[] { (short) 0, 63, (short) 10, 10, 779127810 };
        int[] intArray6 = new int[] {};
        int[] intArray11 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int12 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray11);
        int[] intArray18 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double19 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray18);
        int[] intArray20 = new int[] {};
        int[] intArray25 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int26 = org.apache.commons.math.util.MathUtils.distanceInf(intArray20, intArray25);
        int[] intArray31 = new int[] { (byte) 1, '4', '#', 'a' };
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray25, intArray31);
        int[] intArray33 = new int[] {};
        int[] intArray38 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int39 = org.apache.commons.math.util.MathUtils.distanceInf(intArray33, intArray38);
        int[] intArray45 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double46 = org.apache.commons.math.util.MathUtils.distance(intArray33, intArray45);
        int int47 = org.apache.commons.math.util.MathUtils.distanceInf(intArray31, intArray45);
        int int48 = org.apache.commons.math.util.MathUtils.distanceInf(intArray18, intArray45);
        int int49 = org.apache.commons.math.util.MathUtils.distanceInf(intArray5, intArray45);
        int[] intArray50 = new int[] {};
        int[] intArray55 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int56 = org.apache.commons.math.util.MathUtils.distanceInf(intArray50, intArray55);
        int[] intArray63 = new int[] { (byte) 0, (byte) 10, '#', (short) -1, (short) 1, 97 };
        int int64 = org.apache.commons.math.util.MathUtils.distance1(intArray55, intArray63);
        try {
            int int65 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray55);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 195 + "'", int32 == 195);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 65 + "'", int47 == 65);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 779127710 + "'", int49 == 779127710);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 56 + "'", int64 == 56);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1624620833, 1105975906);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 0.01f, (double) (-42L), 9.999999999999998E193d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.39912428462176963d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.160234765545241d + "'", double1 == 1.160234765545241d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        int[] intArray0 = new int[] {};
        int[] intArray5 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int6 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray5);
        int[] intArray13 = new int[] { (byte) 0, (byte) 10, '#', (short) -1, (short) 1, 97 };
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray13);
        int[] intArray15 = new int[] {};
        int[] intArray20 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray20);
        int[] intArray27 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double28 = org.apache.commons.math.util.MathUtils.distance(intArray15, intArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray27);
        int[] intArray30 = new int[] {};
        int[] intArray35 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int36 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray35);
        int[] intArray41 = new int[] { (byte) 1, '4', '#', 'a' };
        int int42 = org.apache.commons.math.util.MathUtils.distance1(intArray35, intArray41);
        int[] intArray43 = new int[] {};
        int[] intArray48 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int49 = org.apache.commons.math.util.MathUtils.distanceInf(intArray43, intArray48);
        int[] intArray55 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double56 = org.apache.commons.math.util.MathUtils.distance(intArray43, intArray55);
        int int57 = org.apache.commons.math.util.MathUtils.distanceInf(intArray41, intArray55);
        double double58 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray41);
        int[] intArray59 = new int[] {};
        int[] intArray64 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int65 = org.apache.commons.math.util.MathUtils.distanceInf(intArray59, intArray64);
        int[] intArray72 = new int[] { (byte) 0, (byte) 10, '#', (short) -1, (short) 1, 97 };
        int int73 = org.apache.commons.math.util.MathUtils.distance1(intArray64, intArray72);
        double double74 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray72);
        int[] intArray75 = new int[] {};
        int[] intArray80 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int81 = org.apache.commons.math.util.MathUtils.distanceInf(intArray75, intArray80);
        try {
            double double82 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray75);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 56 + "'", int14 == 56);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 121.51131634543344d + "'", double29 == 121.51131634543344d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 195 + "'", int42 == 195);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 65 + "'", int57 == 65);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 117.12813496338103d + "'", double58 == 117.12813496338103d);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 56 + "'", int73 == 56);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 38.02630668366309d + "'", double74 == 38.02630668366309d);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        double double2 = org.apache.commons.math.util.FastMath.atan2(8.948422304476766d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        int int2 = org.apache.commons.math.util.FastMath.min(36, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(1814400.000000139d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, (-1.5707963268788085d));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((-6.053272382792838d), (-1.5707963268788085d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(779127710);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        double double2 = org.apache.commons.math.util.FastMath.max(0.857293145724863d, 4.143134726391533d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.143134726391533d + "'", double2 == 4.143134726391533d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 2.718281828459045d);
        double[] doubleArray27 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) (-1.0f));
        double[] doubleArray36 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) (-1.0f));
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray36);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 2.718281828459045d);
        double double42 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray27);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (-0.9999999999999999d));
        double[] doubleArray51 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, (double) (-1.0f));
        double[] doubleArray60 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) (-1.0f));
        double[] doubleArray69 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray71 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray69, (double) (-1.0f));
        double double72 = org.apache.commons.math.util.MathUtils.distance1(doubleArray60, doubleArray69);
        double[] doubleArray79 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray81 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray79, (double) (-1.0f));
        double double82 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray69, doubleArray79);
        double[] doubleArray84 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray69, (double) (short) 1);
        double double85 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray69);
        double[] doubleArray87 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray69, (double) 1L);
        boolean boolean88 = org.apache.commons.math.util.MathUtils.equals(doubleArray53, doubleArray69);
        boolean boolean89 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray69);
        double[] doubleArray91 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, 5.54062238439351E34d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 139.51318994987582d + "'", double42 == 139.51318994987582d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 141.43549766589717d + "'", double85 == 141.43549766589717d);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNotNull(doubleArray91);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-6625612055612252159L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.857293145724863d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.01496258804767841d + "'", double1 == 0.01496258804767841d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        int int2 = org.apache.commons.math.util.FastMath.min(197, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        int int2 = org.apache.commons.math.util.MathUtils.pow(53, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(1.0805821414740984E9d, (-454785511), (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1624620886L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 195);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.278114659230517d + "'", double1 == 5.278114659230517d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray25 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) (-1.0f));
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray25);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (short) 1);
        double double31 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) 1L);
        java.lang.Class<?> wildcardClass34 = doubleArray15.getClass();
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 141.43549766589717d + "'", double31 == 141.43549766589717d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1989426017 + "'", int35 == 1989426017);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 197);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 197L + "'", long1 == 197L);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(65, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 65 + "'", int2 == 65);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 1300L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2737367544323206E-13d + "'", double1 == 2.2737367544323206E-13d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 43.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (byte) 1, 156);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.9850853666260323d, (-1352038911), 31500);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1080582045), 63);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1080582108) + "'", int2 == (-1080582108));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (byte) 0, (-69L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 69L + "'", long2 == 69L);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 97L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        double double1 = org.apache.commons.math.util.FastMath.asinh(6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.537297501373361d + "'", double1 == 2.537297501373361d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        int int2 = org.apache.commons.math.util.FastMath.max(0, (-1105975906));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.6729530497092316d, 2.6780404899442747d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.24618828658383457d + "'", double2 == 0.24618828658383457d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.4670882772136576d, (double) (-1105975869));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-5.118394377331518E10d), 0.20052306453833568d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-5.118394377331517E10d) + "'", double2 == (-5.118394377331517E10d));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.7160033436347992d, 99.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.7160033436347994d + "'", double2 == 1.7160033436347994d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(201.00931639928152d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.85785650421589d + "'", double1 == 5.85785650421589d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.8414709848078965d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8414709848078965d + "'", double1 == 0.8414709848078965d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-888018845), (float) 63);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-8.8801882E8f) + "'", float2 == (-8.8801882E8f));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-10), 99.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-10.0f) + "'", float2 == (-10.0f));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) (-968000660L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1105975906, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 197);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.818647867496961d + "'", double1 == 5.818647867496961d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.57079632551141d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray25 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) (-1.0f));
        double[] doubleArray34 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, (double) (-1.0f));
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray34);
        double[] doubleArray44 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, (double) (-1.0f));
        double double47 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray44);
        double[] doubleArray54 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray54, (double) (-1.0f));
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray54);
        double[] doubleArray64 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray64, (double) (-1.0f));
        double double67 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray64);
        double double68 = org.apache.commons.math.util.MathUtils.distance1(doubleArray54, doubleArray64);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray54);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray54);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray54);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (1 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 141.43549766589717d + "'", double57 == 141.43549766589717d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 141.43549766589717d + "'", double67 == 141.43549766589717d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-1352038911));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.6674572193582448d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8400075290619021d + "'", double1 == 0.8400075290619021d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        double double1 = org.apache.commons.math.util.FastMath.expm1(3.399216241149525E248d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 10);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (byte) 0);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (int) '#');
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 0);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (int) (short) 10);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (int) (byte) 0);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (int) '#');
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 200L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1079574628, 9);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-5547412656154738688L) + "'", long2 == (-5547412656154738688L));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1105975906, 1987797057);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        double double1 = org.apache.commons.math.util.FastMath.rint(27.479027144466286d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 27.0d + "'", double1 == 27.0d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 99.50000000000001d, (java.lang.Number) 2.993222846126381d, (int) (byte) 0, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        int int2 = org.apache.commons.math.util.FastMath.min(7400, 779127810);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7400 + "'", int2 == 7400);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 34.99999999999999d, (java.lang.Number) 6.691673596021348E41d, (-69));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        long long2 = org.apache.commons.math.util.FastMath.min(5L, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        long long1 = org.apache.commons.math.util.MathUtils.sign(32L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        long long2 = org.apache.commons.math.util.MathUtils.pow(52L, 36L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(779127810, 1080582144);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-301454334) + "'", int2 == (-301454334));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 2.718281828459045d);
        double[] doubleArray27 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) (-1.0f));
        double[] doubleArray36 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) (-1.0f));
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray36);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 2.718281828459045d);
        double double42 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray27);
        double[] doubleArray43 = null;
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray43);
        double[] doubleArray51 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, (double) (-1.0f));
        double[] doubleArray60 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) (-1.0f));
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray51, doubleArray60);
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, 2.718281828459045d);
        double double66 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray65);
        int int67 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 139.51318994987582d + "'", double42 == 139.51318994987582d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1281864422) + "'", int67 == (-1281864422));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        double double1 = org.apache.commons.math.util.FastMath.log10(201.00931639928152d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3032161866097134d + "'", double1 == 2.3032161866097134d);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.20480044364984396d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.20198435049990984d + "'", double1 == 0.20198435049990984d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) (short) 1, (-279932959));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(4.930380657631324E-32d, 0.010050166858404251d, (double) 1987797057);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(1.179103839756096d, (int) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0513699442723656E10d + "'", double2 == 4.0513699442723656E10d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        int[] intArray0 = new int[] {};
        int[] intArray5 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int6 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray5);
        int[] intArray13 = new int[] { (byte) 0, (byte) 10, '#', (short) -1, (short) 1, 97 };
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray13);
        int[] intArray15 = new int[] {};
        int[] intArray20 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray20);
        int[] intArray27 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double28 = org.apache.commons.math.util.MathUtils.distance(intArray15, intArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray27);
        int[] intArray30 = new int[] {};
        int[] intArray35 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int36 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray35);
        int[] intArray43 = new int[] { (byte) 0, (byte) 10, '#', (short) -1, (short) 1, 97 };
        int int44 = org.apache.commons.math.util.MathUtils.distance1(intArray35, intArray43);
        int[] intArray45 = new int[] {};
        int[] intArray50 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int51 = org.apache.commons.math.util.MathUtils.distanceInf(intArray45, intArray50);
        int[] intArray57 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double58 = org.apache.commons.math.util.MathUtils.distance(intArray45, intArray57);
        double double59 = org.apache.commons.math.util.MathUtils.distance(intArray35, intArray57);
        int int60 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray57);
        int[] intArray61 = new int[] {};
        int[] intArray66 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int67 = org.apache.commons.math.util.MathUtils.distanceInf(intArray61, intArray66);
        int[] intArray72 = new int[] { (byte) 1, '4', '#', 'a' };
        int int73 = org.apache.commons.math.util.MathUtils.distance1(intArray66, intArray72);
        try {
            double double74 = org.apache.commons.math.util.MathUtils.distance(intArray57, intArray66);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 56 + "'", int14 == 56);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 121.51131634543344d + "'", double29 == 121.51131634543344d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 56 + "'", int44 == 56);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 121.51131634543344d + "'", double59 == 121.51131634543344d);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 197 + "'", int60 == 197);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 195 + "'", int73 == 195);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 1399733633L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.399733633E9d + "'", double1 == 1.399733633E9d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        int int1 = org.apache.commons.math.util.MathUtils.hash(4.930380657631324E-32d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 963641344 + "'", int1 == 963641344);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(68, 2138030215);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2138030283 + "'", int2 == 2138030283);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (byte) 0, 1624620833L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (-69L), (-4.503599627370496E15d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.5035996273704935E15d) + "'", double2 == (-4.5035996273704935E15d));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 369282464560880L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0625d + "'", double1 == 0.0625d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray25 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) (-1.0f));
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray25);
        double[] doubleArray35 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) (-1.0f));
        double[] doubleArray44 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, (double) (-1.0f));
        double double47 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray44);
        double[] doubleArray54 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray54, (double) (-1.0f));
        double double57 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray44, doubleArray54);
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, (double) (short) 1);
        double double60 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray44);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, (double) 1L);
        double double63 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray62);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray62);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (0.005 >= -0.005)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 141.43549766589717d + "'", double60 == 141.43549766589717d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 99.50000000000001d + "'", double63 == 99.50000000000001d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(5.286736667635593d, 100.50000000000001d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.6360918687915654d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6798632316080779d + "'", double1 == 0.6798632316080779d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(888019042, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, (double) 63);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(0, (-97));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-97) + "'", int2 == (-97));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 3900);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.961879029114238d + "'", double1 == 8.961879029114238d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        java.lang.Class<?> wildcardClass7 = orderDirection6.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97, (java.lang.Number) 572.9577951308232d, (int) (byte) 0, orderDirection6, false);
        int int10 = nonMonotonousSequenceException9.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException9.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.2012104037905144E25d, number1, 0, orderDirection11, false);
        java.lang.Number number14 = nonMonotonousSequenceException13.getArgument();
        java.lang.Number number15 = nonMonotonousSequenceException13.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 4.2012104037905144E25d + "'", number14.equals(4.2012104037905144E25d));
        org.junit.Assert.assertNull(number15);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 1.07957453E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32856.879462298304d + "'", double1 == 32856.879462298304d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(6.6854265722811046E184d, 53.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.685426572281104E184d + "'", double2 == 6.685426572281104E184d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(0L, (-1967593473L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1967593473L + "'", long2 == 1967593473L);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        double double2 = org.apache.commons.math.util.FastMath.atan2(572.9577951308232d, (double) 52.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4802871658095333d + "'", double2 == 1.4802871658095333d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(99.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 99.00000000000001d + "'", double1 == 99.00000000000001d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray16 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) (-1.0f));
        double[] doubleArray25 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) (-1.0f));
        double[] doubleArray34 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, (double) (-1.0f));
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray34);
        double double38 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray34);
        double double40 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray18);
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 141.43549766589717d + "'", double9 == 141.43549766589717d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 141.43549766589717d + "'", double38 == 141.43549766589717d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 142.14267515422665d + "'", double40 == 142.14267515422665d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.7071774883294859d + "'", double41 == 0.7071774883294859d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 100L, (-0.41148230684214054d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.5309649148733797d) + "'", double2 == (-0.5309649148733797d));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        double double1 = org.apache.commons.math.util.FastMath.signum((-0.4127653077953633d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.5527919788071113d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5813788799911153d + "'", double1 == 0.5813788799911153d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        int[] intArray0 = new int[] {};
        int[] intArray5 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int6 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray5);
        int[] intArray7 = new int[] {};
        int[] intArray12 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int13 = org.apache.commons.math.util.MathUtils.distanceInf(intArray7, intArray12);
        int[] intArray14 = new int[] {};
        int[] intArray19 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int20 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray19);
        int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray7, intArray14);
        int[] intArray22 = new int[] {};
        int[] intArray27 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int28 = org.apache.commons.math.util.MathUtils.distanceInf(intArray22, intArray27);
        int[] intArray29 = new int[] {};
        int[] intArray34 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int35 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray34);
        int int36 = org.apache.commons.math.util.MathUtils.distanceInf(intArray22, intArray29);
        int int37 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray22);
        int int38 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray22);
        int[] intArray39 = new int[] {};
        int[] intArray44 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int45 = org.apache.commons.math.util.MathUtils.distanceInf(intArray39, intArray44);
        int[] intArray50 = new int[] { (byte) 1, '4', '#', 'a' };
        int int51 = org.apache.commons.math.util.MathUtils.distance1(intArray44, intArray50);
        int[] intArray52 = new int[] {};
        int[] intArray57 = new int[] { (byte) 10, (-1), 0, (byte) -1 };
        int int58 = org.apache.commons.math.util.MathUtils.distanceInf(intArray52, intArray57);
        int[] intArray64 = new int[] { 53, (byte) -1, 100, 53, (short) 100 };
        double double65 = org.apache.commons.math.util.MathUtils.distance(intArray52, intArray64);
        int int66 = org.apache.commons.math.util.MathUtils.distanceInf(intArray50, intArray64);
        double double67 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray64);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 195 + "'", int51 == 195);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 65 + "'", int66 == 65);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.7853981613362947d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8686709587557868d + "'", double1 == 0.8686709587557868d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 36);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        double double1 = org.apache.commons.math.util.FastMath.sinh(8.948422304476766d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3847.870306293416d + "'", double1 == 3847.870306293416d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (short) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-984724751));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        double[] doubleArray6 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-1.0f));
        double[] doubleArray15 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1.0f));
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray15);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 2.718281828459045d);
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray28 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, (double) (-1.0f));
        double[] doubleArray37 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, (double) (-1.0f));
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray37);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, 2.718281828459045d);
        double[] doubleArray49 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, (double) (-1.0f));
        double[] doubleArray58 = new double[] { 1L, (-1L), 100L, (-1.0f), 100.00000000000001d, 1.0000000000000002d };
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, (double) (-1.0f));
        double double61 = org.apache.commons.math.util.MathUtils.distance1(doubleArray49, doubleArray58);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, 2.718281828459045d);
        double double64 = org.apache.commons.math.util.MathUtils.distance(doubleArray42, doubleArray49);
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray42, (-0.9999999999999999d));
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 141.43549766589717d + "'", double21 == 141.43549766589717d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 139.51318994987582d + "'", double64 == 139.51318994987582d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-1080582045));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-3.7315666758872256E7d), (java.lang.Number) (-1080582108), (int) (short) 1);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, 0, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) -1, (java.lang.Number) Float.NaN, (int) (byte) 10, orderDirection6, false);
        java.lang.String str11 = nonMonotonousSequenceException10.toString();
        boolean boolean12 = nonMonotonousSequenceException10.getStrict();
        int int13 = nonMonotonousSequenceException10.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not decreasing (� < -1)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not decreasing (� < -1)"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, (-279932959));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        int int1 = org.apache.commons.math.util.FastMath.abs(779127810);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 779127810 + "'", int1 == 779127810);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 2138030215);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.4831507818161d + "'", double1 == 21.4831507818161d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 4L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(34.99999999999999d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 34.999999999999986d + "'", double2 == 34.999999999999986d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 32.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.158638853279167d + "'", double1 == 4.158638853279167d);
    }
}

