import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9155040003582885E22d + "'", double1 == 1.9155040003582885E22d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 1, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.lang.Object[] objArray3 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException("", objArray3);
        java.lang.String str5 = mathException4.getPattern();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE_AS_TYPE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE_AS_TYPE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE_AS_TYPE));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.LENGTH;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LENGTH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.LENGTH));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_COST_RELATIVE_TOLERANCE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_COST_RELATIVE_TOLERANCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_COST_RELATIVE_TOLERANCE));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        double double1 = org.apache.commons.math.util.FastMath.floor(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) '4', (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.019230769230769232d + "'", double2 == 0.019230769230769232d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_3D_VECTOR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_3D_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_3D_VECTOR));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0f);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION_FAILED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION_FAILED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION_FAILED));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SUBARRAY_ENDS_AFTER_ARRAY_END;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SUBARRAY_ENDS_AFTER_ARRAY_END + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SUBARRAY_ENDS_AFTER_ARRAY_END));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        float float2 = org.apache.commons.math.util.FastMath.copySign(0.0f, (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_NUMBER_OF_POINTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_NUMBER_OF_POINTS));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) (short) 10, 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9.999999f + "'", float2 == 9.999999f);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (-1L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.lang.Object[] objArray3 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException("", objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = mathException4.getGeneralPattern();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("", objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray11);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException4, "hi!", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable15 = convergenceException14.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(localizable5);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(localizable15);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INPUT_DATA_FROM_UNSUPPORTED_DATASOURCE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INPUT_DATA_FROM_UNSUPPORTED_DATASOURCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INPUT_DATA_FROM_UNSUPPORTED_DATASOURCE));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MEAN;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MEAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MEAN));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7615941559557649d + "'", double1 == 0.7615941559557649d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.COVARIANCE_MATRIX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COVARIANCE_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.COVARIANCE_MATRIX));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (short) 10);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.USER_EXCEPTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.USER_EXCEPTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.USER_EXCEPTION));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.00001f + "'", float1 == 100.00001f);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.0d, (double) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.009999666686665238d + "'", double2 == 0.009999666686665238d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298342365610589d + "'", double1 == 5.298342365610589d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.apache.commons.math.exception.ZeroException zeroException0 = new org.apache.commons.math.exception.ZeroException();
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.optimization.OptimizationException optimizationException1 = new org.apache.commons.math.optimization.OptimizationException(throwable0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_ONE_PREVIOUS_POINT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_ONE_PREVIOUS_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_ONE_PREVIOUS_POINT));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_MICROSPHERE_ELEMENTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_MICROSPHERE_ELEMENTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_MICROSPHERE_ELEMENTS));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-127) + "'", int1 == (-127));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_FOR_NUMBER_OF_PREDICTORS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_FOR_NUMBER_OF_PREDICTORS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_FOR_NUMBER_OF_PREDICTORS));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DATA;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DATA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DATA));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) (-127), (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-126.99999f) + "'", float2 == (-126.99999f));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 57.29577951308232d + "'", double1 == 57.29577951308232d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        try {
            incrementor0.incrementCount(10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: ");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_CONVERGENT_CONTINUED_FRACTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_CONVERGENT_CONTINUED_FRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_CONVERGENT_CONTINUED_FRACTION));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_COMPLEX_NUMBER;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_COMPLEX_NUMBER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_COMPLEX_NUMBER));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FRACTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FRACTION));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SAMPLE_SIZE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SAMPLE_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SAMPLE_SIZE));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        long long2 = org.apache.commons.math.util.FastMath.min((-1L), (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 100L, 0.7615941559557649d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 33.35710192050218d + "'", double2 == 33.35710192050218d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_EXCEEDS_N;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_EXCEEDS_N + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_EXCEEDS_N));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 100.00001f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.009999666686665238d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.010000000006666444d + "'", double1 == 0.010000000006666444d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_ONE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_ONE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_ONE));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        double double2 = org.apache.commons.math.util.FastMath.hypot((double) 1, (double) (-1L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4142135623730951d + "'", double2 == 1.4142135623730951d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 10.0f, (double) 9.999999f, (double) (byte) 1, (double) 10, 0.0d);
        double double6 = levenbergMarquardtOptimizer5.getRMS();
        try {
            double[] doubleArray7 = levenbergMarquardtOptimizer5.guessParametersErrors();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooSmallException; message: 0 is smaller than, or equal to, the minimum (0): no degrees of freedom (0 measurements, 0 parameters)");
        } catch (org.apache.commons.math.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (byte) 10, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUBTRACTION_COMPATIBLE_MATRICES;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUBTRACTION_COMPATIBLE_MATRICES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUBTRACTION_COMPATIBLE_MATRICES));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1622776601683795d + "'", double1 == 3.1622776601683795d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.WRONG_NUMBER_OF_POINTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WRONG_NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.WRONG_NUMBER_OF_POINTS));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.apache.commons.math.exception.NullArgumentException nullArgumentException0 = new org.apache.commons.math.exception.NullArgumentException();
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        double double1 = org.apache.commons.math.util.FastMath.floor(57.29577951308232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 57.0d + "'", double1 == 57.0d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        int int2 = org.apache.commons.math.util.FastMath.min((int) 'a', (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.009999666686665238d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.009999833344165989d + "'", double1 == 0.009999833344165989d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SHAPE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SHAPE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SHAPE));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (short) 0, (double) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL;
        org.apache.commons.math.exception.ZeroException zeroException1 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats0);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.lang.Object[] objArray4 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException("", objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = mathException5.getGeneralPattern();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND;
        java.lang.Object[] objArray12 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException("", objArray12);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray12);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException5, "hi!", objArray12);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND;
        java.lang.Object[] objArray22 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException("", objArray22);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats18, objArray22);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException25 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) convergenceException15, (org.apache.commons.math.exception.util.Localizable) localizedFormats16, (org.apache.commons.math.exception.util.Localizable) localizedFormats17, objArray22);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException("", objArray22);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND));
        org.junit.Assert.assertNotNull(objArray22);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-126.99999f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-127.0d) + "'", double1 == (-127.0d));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (byte) -1, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SHAPE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SHAPE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SHAPE));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-1.0f), (double) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        double double1 = org.apache.commons.math.util.FastMath.atanh(5.298342365610589d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 10.0f, (double) 9.999999f, (double) (byte) 1, (double) 10, 0.0d);
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker6 = levenbergMarquardtOptimizer5.getConvergenceChecker();
        int int7 = levenbergMarquardtOptimizer5.getJacobianEvaluations();
        try {
            double[] doubleArray8 = levenbergMarquardtOptimizer5.guessParametersErrors();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooSmallException; message: 0 is smaller than, or equal to, the minimum (0): no degrees of freedom (0 measurements, 0 parameters)");
        } catch (org.apache.commons.math.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        double double1 = org.apache.commons.math.util.FastMath.log1p(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210804127942926d + "'", double1 == 1.4210804127942926d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-1L), 33.35710192050218d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 33.35710192050218d + "'", double2 == 33.35710192050218d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        float float2 = org.apache.commons.math.util.FastMath.copySign((float) '4', (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer differentiableMultivariateVectorialOptimizer0 = null;
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter1 = new org.apache.commons.math.optimization.fitting.CurveFitter(differentiableMultivariateVectorialOptimizer0);
        curveFitter1.addObservedPoint((double) (-1.0f), 0.009999666686665238d, (double) (byte) -1);
        curveFitter1.addObservedPoint((double) (-1L), (double) 1L);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric10 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray11 = null;
        try {
            double[] doubleArray12 = curveFitter1.fit(1, (org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric10, doubleArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        double double1 = org.apache.commons.math.util.FastMath.log(3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.151292546497023d + "'", double1 == 1.151292546497023d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FACTORIAL_NEGATIVE_PARAMETER;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FACTORIAL_NEGATIVE_PARAMETER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FACTORIAL_NEGATIVE_PARAMETER));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer differentiableMultivariateVectorialOptimizer0 = null;
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter1 = new org.apache.commons.math.optimization.fitting.CurveFitter(differentiableMultivariateVectorialOptimizer0);
        curveFitter1.addObservedPoint((double) (-1.0f), 0.009999666686665238d, (double) (byte) -1);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric6 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray9 = new double[] { 100.00001f, 'a' };
        double[] doubleArray15 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair16 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray9, doubleArray15);
        double[] doubleArray19 = new double[] { 100.00001f, 'a' };
        double[] doubleArray25 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair26 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray25);
        double[] doubleArray27 = vectorialPointValuePair26.getPoint();
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair28 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray9, doubleArray27);
        double[] doubleArray31 = new double[] { 100.00001f, 'a' };
        double[] doubleArray37 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair38 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray31, doubleArray37);
        double[] doubleArray41 = new double[] { 100.00001f, 'a' };
        double[] doubleArray47 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair48 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray41, doubleArray47);
        double[] doubleArray49 = vectorialPointValuePair48.getPoint();
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair50 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray31, doubleArray49);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair52 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray27, doubleArray49, true);
        try {
            double[] doubleArray53 = curveFitter1.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric6, doubleArray49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        float float1 = org.apache.commons.math.util.FastMath.signum((-126.99999f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1L), (float) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIGEST_NOT_INITIALIZED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIGEST_NOT_INITIALIZED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIGEST_NOT_INITIALIZED));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        double double2 = org.apache.commons.math.util.FastMath.min(Double.NaN, 1.151292546497023d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        org.apache.commons.math.analysis.DifferentiableMultivariateVectorialFunction differentiableMultivariateVectorialFunction2 = null;
        double[] doubleArray5 = new double[] { 100.00001f, 'a' };
        double[] doubleArray11 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair12 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray5, doubleArray11);
        double[] doubleArray15 = new double[] { 100.00001f, 'a' };
        double[] doubleArray21 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair22 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray15, doubleArray21);
        double[] doubleArray23 = vectorialPointValuePair22.getPoint();
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair24 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray5, doubleArray23);
        double[] doubleArray27 = new double[] { 100.00001f, 'a' };
        double[] doubleArray33 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair34 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray27, doubleArray33);
        double[] doubleArray37 = new double[] { 100.00001f, 'a' };
        double[] doubleArray43 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair44 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray37, doubleArray43);
        double[] doubleArray45 = vectorialPointValuePair44.getPoint();
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray27, doubleArray45);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair48 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray23, doubleArray45, true);
        double[] doubleArray51 = new double[] { 100.00001f, 'a' };
        double[] doubleArray57 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair58 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray51, doubleArray57);
        double[] doubleArray59 = null;
        try {
            org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair60 = levenbergMarquardtOptimizer0.optimize((int) (short) 10, differentiableMultivariateVectorialFunction2, doubleArray23, doubleArray57, doubleArray59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray57);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_REAL_VECTOR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_REAL_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_REAL_VECTOR));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 5.298342365610589d);
        java.util.Locale locale3 = null;
        try {
            java.lang.String str4 = localizedFormats0.getLocalizedString(locale3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        long long2 = org.apache.commons.math.util.FastMath.min((long) '#', (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.apache.commons.math.exception.ConvergenceException convergenceException0 = new org.apache.commons.math.exception.ConvergenceException();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException("", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException6.getGeneralPattern();
        java.lang.Throwable[] throwableArray8 = mathException6.getSuppressed();
        java.lang.Object[] objArray9 = mathException6.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray9);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException10);
        convergenceException0.addSuppressed((java.lang.Throwable) mathIllegalArgumentException10);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (byte) 1, (java.lang.Number) 1.9155040003582885E22d, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("", objArray9);
        org.apache.commons.math.exception.util.Localizable localizable11 = mathException10.getGeneralPattern();
        java.lang.Throwable[] throwableArray12 = mathException10.getSuppressed();
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException3, (org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Object[]) throwableArray12);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException15 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 0L);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxCountExceededException15);
        mathException13.addSuppressed((java.lang.Throwable) convergenceException16);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        java.lang.Object[] objArray20 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException21 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathException13, (org.apache.commons.math.exception.util.Localizable) localizedFormats18, (org.apache.commons.math.exception.util.Localizable) localizedFormats19, objArray20);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.9155040003582885E22d + "'", number4.equals(1.9155040003582885E22d));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_OVERFLOW_AFTER_MULTIPLY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_OVERFLOW_AFTER_MULTIPLY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_OVERFLOW_AFTER_MULTIPLY));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-126.99999f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MISMATCHED_LOESS_ABSCISSA_ORDINATE_ARRAYS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MISMATCHED_LOESS_ABSCISSA_ORDINATE_ARRAYS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MISMATCHED_LOESS_ABSCISSA_ORDINATE_ARRAYS));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CONVERT_OBJECT_TO_FRACTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CONVERT_OBJECT_TO_FRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CONVERT_OBJECT_TO_FRACTION));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) '#', (int) (short) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 10L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.LIST_OF_CHROMOSOMES_BIGGER_THAN_POPULATION_SIZE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LIST_OF_CHROMOSOMES_BIGGER_THAN_POPULATION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.LIST_OF_CHROMOSOMES_BIGGER_THAN_POPULATION_SIZE));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 1);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        java.lang.Object[] objArray3 = notStrictlyPositiveException1.getArguments();
        java.lang.Class<?> wildcardClass4 = notStrictlyPositiveException1.getClass();
        boolean boolean5 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_BOTTH_ZERO_FOR_ENTRY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_BOTTH_ZERO_FOR_ENTRY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_BOTTH_ZERO_FOR_ENTRY));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) 0, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException("", objArray4);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray4);
        org.apache.commons.math.exception.ZeroException zeroException7 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats0);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND));
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.BETA;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BETA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.BETA));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS;
        org.apache.commons.math.exception.ZeroException zeroException2 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats1);
        mathException0.addSuppressed((java.lang.Throwable) zeroException2);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.START_POSITION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.START_POSITION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.START_POSITION));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SUCCESS_LARGER_THAN_POPULATION_SIZE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SUCCESS_LARGER_THAN_POPULATION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SUCCESS_LARGER_THAN_POPULATION_SIZE));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (byte) 1, (java.lang.Number) 1.9155040003582885E22d, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("", objArray9);
        org.apache.commons.math.exception.util.Localizable localizable11 = mathException10.getGeneralPattern();
        java.lang.Throwable[] throwableArray12 = mathException10.getSuppressed();
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException3, (org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Object[]) throwableArray12);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException15 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 0L);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxCountExceededException15);
        mathException13.addSuppressed((java.lang.Throwable) convergenceException16);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (byte) 1, (java.lang.Number) 1.9155040003582885E22d, false);
        java.lang.Number number23 = numberIsTooSmallException22.getArgument();
        java.lang.Throwable[] throwableArray24 = numberIsTooSmallException22.getSuppressed();
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException16, "", (java.lang.Object[]) throwableArray24);
        org.apache.commons.math.optimization.OptimizationException optimizationException26 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) mathException25);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.9155040003582885E22d + "'", number4.equals(1.9155040003582885E22d));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (byte) 1 + "'", number23.equals((byte) 1));
        org.junit.Assert.assertNotNull(throwableArray24);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 1, (double) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        try {
            incrementor0.incrementCount();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: ");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException("", objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = mathException5.getGeneralPattern();
        java.lang.Throwable[] throwableArray7 = mathException5.getSuppressed();
        java.lang.Object[] objArray8 = mathException5.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray8);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException9);
        org.apache.commons.math.exception.util.Localizable localizable11 = mathIllegalArgumentException9.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNull(localizable11);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        double double2 = org.apache.commons.math.util.FastMath.min(0.010000000006666444d, 3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.010000000006666444d + "'", double2 == 0.010000000006666444d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1622776601683795d + "'", double1 == 3.1622776601683795d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        double double2 = org.apache.commons.math.util.FastMath.copySign(1.1102230246251565E-14d, 100.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1102230246251565E-14d + "'", double2 == 1.1102230246251565E-14d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 10.0f, (double) 9.999999f, (double) (byte) 1, (double) 10, 0.0d);
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker6 = levenbergMarquardtOptimizer5.getConvergenceChecker();
        int int7 = levenbergMarquardtOptimizer5.getJacobianEvaluations();
        org.apache.commons.math.analysis.DifferentiableMultivariateVectorialFunction differentiableMultivariateVectorialFunction9 = null;
        double[] doubleArray15 = new double[] { (byte) 100, (short) 0, 33.35710192050218d, 0.009999666686665238d, 100.00001f };
        double[] doubleArray18 = new double[] { 100.00001f, 'a' };
        double[] doubleArray24 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair25 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray18, doubleArray24);
        double[] doubleArray28 = new double[] { 100.00001f, 'a' };
        double[] doubleArray34 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair35 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray28, doubleArray34);
        try {
            org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair36 = levenbergMarquardtOptimizer5.optimize((int) '4', differentiableMultivariateVectorialFunction9, doubleArray15, doubleArray18, doubleArray28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY;
        java.lang.Throwable throwable3 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException9.getGeneralPattern();
        java.lang.Throwable[] throwableArray11 = mathException9.getSuppressed();
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException(throwable3, "hi!", (java.lang.Object[]) throwableArray11);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException13 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Object[]) throwableArray11);
        org.apache.commons.math.optimization.OptimizationException optimizationException14 = new org.apache.commons.math.optimization.OptimizationException("", (java.lang.Object[]) throwableArray11);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(throwableArray11);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint weightedObservedPoint3 = new org.apache.commons.math.optimization.fitting.WeightedObservedPoint(0.0d, 0.019230769230769232d, 1.4142135623730951d);
        double double4 = weightedObservedPoint3.getWeight();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.896296018267969E13d + "'", double1 == 7.896296018267969E13d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 10.0f, (double) 9.999999f, (double) (byte) 1, (double) 10, 0.0d);
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker6 = levenbergMarquardtOptimizer5.getConvergenceChecker();
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker7 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        levenbergMarquardtOptimizer5.setConvergenceChecker((org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair>) simpleVectorialValueChecker7);
        double double9 = simpleVectorialValueChecker7.getRelativeThreshold();
        double double10 = simpleVectorialValueChecker7.getRelativeThreshold();
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.1102230246251565E-14d + "'", double9 == 1.1102230246251565E-14d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.1102230246251565E-14d + "'", double10 == 1.1102230246251565E-14d);
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test212");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.5640681427824117d + "'", double0 == 0.5640681427824117d);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-57.29577951308232d) + "'", double1 == (-57.29577951308232d));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(Double.NEGATIVE_INFINITY, (double) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.7976931348623157E308d) + "'", double2 == (-1.7976931348623157E308d));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ROBUSTNESS_ITERATIONS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROBUSTNESS_ITERATIONS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROBUSTNESS_ITERATIONS));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        int int2 = org.apache.commons.math.util.FastMath.max((int) '4', 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.7615941559557649d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        try {
            incrementor0.incrementCount(100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: ");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_POLYNOMIALS_COEFFICIENTS_ARRAY;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException1 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_POLYNOMIALS_COEFFICIENTS_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_POLYNOMIALS_COEFFICIENTS_ARRAY));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUND_SIGNIFICANCE_LEVEL;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUND_SIGNIFICANCE_LEVEL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUND_SIGNIFICANCE_LEVEL));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_MATRIX;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_MATRIX));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((double) (-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_INTEGRATION_INTERVAL;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_INTEGRATION_INTERVAL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_INTEGRATION_INTERVAL));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (byte) 1, (java.lang.Number) 1.9155040003582885E22d, false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException("", objArray10);
        org.apache.commons.math.exception.util.Localizable localizable12 = mathException11.getGeneralPattern();
        java.lang.Throwable[] throwableArray13 = mathException11.getSuppressed();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException4, (org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Object[]) throwableArray13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("hi!", (java.lang.Object[]) throwableArray13);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.9155040003582885E22d + "'", number5.equals(1.9155040003582885E22d));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertNotNull(throwableArray13);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        double double2 = org.apache.commons.math.util.FastMath.copySign((double) 0.0f, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.IMAGINARY_FORMAT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.IMAGINARY_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.IMAGINARY_FORMAT));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 100L, 1.151292546497023d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) -1, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        float float2 = org.apache.commons.math.util.FastMath.copySign(0.0f, (float) (short) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.99822295029797d + "'", double1 == 2.99822295029797d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        double double2 = org.apache.commons.math.util.FastMath.scalb(0.0d, 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_INFINITE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_INFINITE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_INFINITE));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.WHOLE_FORMAT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WHOLE_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.WHOLE_FORMAT));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_SYMMETRIC_MATRIX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_SYMMETRIC_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_SYMMETRIC_MATRIX));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_OPERATION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_OPERATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_OPERATION));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 57.29577951308232d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer differentiableMultivariateVectorialOptimizer0 = null;
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter1 = new org.apache.commons.math.optimization.fitting.CurveFitter(differentiableMultivariateVectorialOptimizer0);
        curveFitter1.addObservedPoint((double) (-1.0f), 0.009999666686665238d, (double) (byte) -1);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric6 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray9 = new double[] { 100.00001f, 'a' };
        double[] doubleArray15 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair16 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray9, doubleArray15);
        try {
            double[] doubleArray17 = curveFitter1.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric6, doubleArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getCount();
        incrementor0.setMaximalCount((int) (short) -1);
        try {
            incrementor0.incrementCount();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: ");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.ITERATOR_EXHAUSTED;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException("", objArray3);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException5 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) convergenceException4);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_COUNT_EXCEEDED;
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException9 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 0L);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxCountExceededException9);
        java.lang.Throwable[] throwableArray11 = maxCountExceededException9.getSuppressed();
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, (java.lang.Object[]) throwableArray11);
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException4, (org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Object[]) throwableArray11);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException14 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) throwableArray11);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException15 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Object[]) throwableArray11);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ITERATOR_EXHAUSTED + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.ITERATOR_EXHAUSTED));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_COUNT_EXCEEDED + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_COUNT_EXCEEDED));
        org.junit.Assert.assertNotNull(throwableArray11);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.7615941559557649d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.5640681427824117d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5109895864477217d + "'", double1 == 0.5109895864477217d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0000001f + "'", float1 == 1.0000001f);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SCALE;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SCALE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SCALE));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 9.999999f, 1.9155040003582885E22d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 10.0d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        double double1 = org.apache.commons.math.util.FastMath.ulp(57.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS;
        java.lang.Throwable throwable1 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException("", objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = mathException7.getGeneralPattern();
        java.lang.Throwable[] throwableArray9 = mathException7.getSuppressed();
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException(throwable1, "hi!", (java.lang.Object[]) throwableArray9);
        java.lang.Object[] objArray11 = mathException10.getArguments();
        org.apache.commons.math.optimization.OptimizationException optimizationException12 = new org.apache.commons.math.optimization.OptimizationException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray11);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(localizable8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(objArray11);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (byte) 100);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_ELEMENT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_ELEMENT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_ELEMENT));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.009999666686665238d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000499970835348d + "'", double1 == 1.0000499970835348d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        double double1 = org.apache.commons.math.util.FastMath.cos(33.35710192050218d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.3619688119383991d) + "'", double1 == (-0.3619688119383991d));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        int int1 = org.apache.commons.math.util.FastMath.round(9.999999f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_NTH_ROOT_FOR_NEGATIVE_N;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_NTH_ROOT_FOR_NEGATIVE_N + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_NTH_ROOT_FOR_NEGATIVE_N));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer differentiableMultivariateVectorialOptimizer0 = null;
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter1 = new org.apache.commons.math.optimization.fitting.CurveFitter(differentiableMultivariateVectorialOptimizer0);
        curveFitter1.addObservedPoint((double) (-127), (-1.7976931348623157E308d));
        curveFitter1.addObservedPoint(1.4210804127942926d, 0.5640681427824117d, (double) '#');
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric10 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray13 = new double[] { 100.00001f, 'a' };
        double[] doubleArray19 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair20 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray13, doubleArray19);
        double[] doubleArray23 = new double[] { 100.00001f, 'a' };
        double[] doubleArray29 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair30 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray23, doubleArray29);
        double[] doubleArray31 = vectorialPointValuePair30.getPoint();
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair32 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray13, doubleArray31);
        double[] doubleArray35 = new double[] { 100.00001f, 'a' };
        double[] doubleArray41 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair42 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray35, doubleArray41);
        double[] doubleArray45 = new double[] { 100.00001f, 'a' };
        double[] doubleArray51 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair52 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray45, doubleArray51);
        double[] doubleArray53 = vectorialPointValuePair52.getPoint();
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair54 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray35, doubleArray53);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair56 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray31, doubleArray53, true);
        try {
            double[] doubleArray57 = curveFitter1.fit((-1), (org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric10, doubleArray53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_RESULT_AVAILABLE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_RESULT_AVAILABLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_RESULT_AVAILABLE));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (short) 100);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        java.lang.Object[] objArray3 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException("", objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = mathException4.getGeneralPattern();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("", objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray11);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException4, "hi!", objArray11);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND;
        java.lang.Object[] objArray21 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("", objArray21);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats17, objArray21);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException24 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) convergenceException14, (org.apache.commons.math.exception.util.Localizable) localizedFormats15, (org.apache.commons.math.exception.util.Localizable) localizedFormats16, objArray21);
        java.lang.Object[] objArray29 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException("", objArray29);
        org.apache.commons.math.exception.util.Localizable localizable31 = mathException30.getGeneralPattern();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND;
        java.lang.Object[] objArray37 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException("", objArray37);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats33, objArray37);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException30, "hi!", objArray37);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats41 = org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats42 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats43 = org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND;
        java.lang.Object[] objArray47 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException("", objArray47);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats43, objArray47);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException50 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) convergenceException40, (org.apache.commons.math.exception.util.Localizable) localizedFormats41, (org.apache.commons.math.exception.util.Localizable) localizedFormats42, objArray47);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException14, "hi!", objArray47);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats52 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS;
        java.lang.Object[] objArray56 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException("", objArray56);
        org.apache.commons.math.exception.util.Localizable localizable58 = mathException57.getGeneralPattern();
        java.lang.Throwable[] throwableArray59 = mathException57.getSuppressed();
        java.lang.Object[] objArray60 = mathException57.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException61 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats52, objArray60);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException62 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException61);
        convergenceException14.addSuppressed((java.lang.Throwable) mathRuntimeException62);
        java.lang.Class<?> wildcardClass64 = mathRuntimeException62.getClass();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(localizable5);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(localizable31);
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND + "'", localizedFormats33.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND));
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertTrue("'" + localizedFormats41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET + "'", localizedFormats41.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT + "'", localizedFormats42.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT));
        org.junit.Assert.assertTrue("'" + localizedFormats43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND + "'", localizedFormats43.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND));
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertTrue("'" + localizedFormats52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS + "'", localizedFormats52.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS));
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(localizable58);
        org.junit.Assert.assertNotNull(throwableArray59);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(wildcardClass64);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker2 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker(1.0d, 1.151292546497023d);
        double[] doubleArray6 = new double[] { 100.00001f, 'a' };
        double[] doubleArray12 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair13 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray6, doubleArray12);
        double[] doubleArray14 = vectorialPointValuePair13.getValueRef();
        double[] doubleArray17 = new double[] { 100.00001f, 'a' };
        double[] doubleArray23 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair24 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray17, doubleArray23);
        boolean boolean25 = simpleVectorialValueChecker2.converged((int) 'a', vectorialPointValuePair13, vectorialPointValuePair24);
        double[] doubleArray29 = new double[] { 100.00001f, 'a' };
        double[] doubleArray35 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair36 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray29, doubleArray35);
        double[] doubleArray37 = vectorialPointValuePair36.getPoint();
        double[] doubleArray40 = new double[] { 100.00001f, 'a' };
        double[] doubleArray46 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair47 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray40, doubleArray46);
        double[] doubleArray50 = new double[] { 100.00001f, 'a' };
        double[] doubleArray56 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair57 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray50, doubleArray56);
        double[] doubleArray58 = vectorialPointValuePair57.getPoint();
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair59 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray40, doubleArray58);
        double[] doubleArray62 = new double[] { 100.00001f, 'a' };
        double[] doubleArray68 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair69 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray62, doubleArray68);
        double[] doubleArray72 = new double[] { 100.00001f, 'a' };
        double[] doubleArray78 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair79 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray72, doubleArray78);
        double[] doubleArray80 = vectorialPointValuePair79.getPoint();
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair81 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray62, doubleArray80);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair83 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray58, doubleArray80, true);
        try {
            boolean boolean84 = simpleVectorialValueChecker2.converged((int) (byte) 10, vectorialPointValuePair36, vectorialPointValuePair83);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray80);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-127) + "'", int1 == (-127));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.010000000006666444d, (java.lang.Number) 0.009999666686665238d, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.apache.commons.math.analysis.function.Gaussian gaussian3 = new org.apache.commons.math.analysis.function.Gaussian(0.0d, (double) 100.0f, 10.0d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = gaussian3.derivative();
        double double6 = gaussian3.value((double) (short) 100);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction7 = gaussian3.derivative();
        org.junit.Assert.assertNotNull(univariateRealFunction4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(univariateRealFunction7);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_ROW;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_ROW + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_ROW));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        int int1 = org.apache.commons.math.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.0000499970835348d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.5640681427824117d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5640681427824117d + "'", double1 == 0.5640681427824117d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        double double1 = org.apache.commons.math.util.FastMath.tan(3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.020687957244708476d + "'", double1 == 0.020687957244708476d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException("", objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = mathException5.getGeneralPattern();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND;
        java.lang.Object[] objArray12 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException("", objArray12);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray12);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException5, "hi!", objArray12);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND;
        java.lang.Object[] objArray22 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException("", objArray22);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats18, objArray22);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException25 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) convergenceException15, (org.apache.commons.math.exception.util.Localizable) localizedFormats16, (org.apache.commons.math.exception.util.Localizable) localizedFormats17, objArray22);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException30 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (byte) 1, (java.lang.Number) 1.9155040003582885E22d, false);
        java.lang.Number number31 = numberIsTooSmallException30.getMin();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS;
        java.lang.Object[] objArray36 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException("", objArray36);
        org.apache.commons.math.exception.util.Localizable localizable38 = mathException37.getGeneralPattern();
        java.lang.Throwable[] throwableArray39 = mathException37.getSuppressed();
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException30, (org.apache.commons.math.exception.util.Localizable) localizedFormats32, (java.lang.Object[]) throwableArray39);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException41 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathException40);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats42 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED;
        java.lang.Object[] objArray46 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException("", objArray46);
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException((java.lang.Throwable) mathRuntimeException41, (org.apache.commons.math.exception.util.Localizable) localizedFormats42, objArray46);
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException15, "", objArray46);
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray46);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 1.9155040003582885E22d + "'", number31.equals(1.9155040003582885E22d));
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS + "'", localizedFormats32.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS));
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(localizable38);
        org.junit.Assert.assertNotNull(throwableArray39);
        org.junit.Assert.assertTrue("'" + localizedFormats42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizedFormats42.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray46);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        double double1 = levenbergMarquardtOptimizer0.getChiSquare();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 10.0d, (java.lang.Number) 10.0f, (java.lang.Number) 1L);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1L + "'", number4.equals(1L));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_COUNT_EXCEEDED;
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException2 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 0L);
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxCountExceededException2);
        java.lang.Throwable[] throwableArray4 = maxCountExceededException2.getSuppressed();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray4);
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException();
        java.lang.Throwable[] throwableArray7 = mathException6.getSuppressed();
        mathException5.addSuppressed((java.lang.Throwable) mathException6);
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException6.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException6.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_COUNT_EXCEEDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_COUNT_EXCEEDED));
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNull(localizable9);
        org.junit.Assert.assertNull(localizable10);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7853981633974483d) + "'", double1 == (-0.7853981633974483d));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 9.999999f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1544346215442474d + "'", double1 == 2.1544346215442474d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker2 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker(1.0d, 1.151292546497023d);
        double[] doubleArray6 = new double[] { 100.00001f, 'a' };
        double[] doubleArray12 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair13 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray6, doubleArray12);
        double[] doubleArray14 = vectorialPointValuePair13.getValueRef();
        double[] doubleArray17 = new double[] { 100.00001f, 'a' };
        double[] doubleArray23 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair24 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray17, doubleArray23);
        boolean boolean25 = simpleVectorialValueChecker2.converged((int) 'a', vectorialPointValuePair13, vectorialPointValuePair24);
        double[] doubleArray26 = vectorialPointValuePair13.getPointRef();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(doubleArray26);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        double double1 = org.apache.commons.math.util.FastMath.acos(7.896296018267969E13d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) Double.POSITIVE_INFINITY, (java.lang.Number) (short) 10, false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) 10, 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer differentiableMultivariateVectorialOptimizer0 = null;
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter1 = new org.apache.commons.math.optimization.fitting.CurveFitter(differentiableMultivariateVectorialOptimizer0);
        curveFitter1.addObservedPoint((double) (-127), (-1.7976931348623157E308d));
        curveFitter1.addObservedPoint(1.4210804127942926d, 0.5640681427824117d, (double) '#');
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric10 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray13 = new double[] { 100.00001f, 'a' };
        double[] doubleArray19 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair20 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray13, doubleArray19);
        double[] doubleArray21 = vectorialPointValuePair20.getPoint();
        double[] doubleArray22 = vectorialPointValuePair20.getValue();
        try {
            double[] doubleArray23 = curveFitter1.fit(0, (org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric10, doubleArray22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker2 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker((double) 0, (double) '#');
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (byte) 1, (java.lang.Number) 1.9155040003582885E22d, false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException("", objArray10);
        org.apache.commons.math.exception.util.Localizable localizable12 = mathException11.getGeneralPattern();
        java.lang.Throwable[] throwableArray13 = mathException11.getSuppressed();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException4, (org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Object[]) throwableArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray13);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.9155040003582885E22d + "'", number5.equals(1.9155040003582885E22d));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertNotNull(throwableArray13);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.791759469228055d + "'", double1 == 1.791759469228055d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) (short) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer differentiableMultivariateVectorialOptimizer0 = null;
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter1 = new org.apache.commons.math.optimization.fitting.CurveFitter(differentiableMultivariateVectorialOptimizer0);
        curveFitter1.addObservedPoint((double) (-127), (-1.7976931348623157E308d));
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray5 = curveFitter1.getObservations();
        try {
            org.apache.commons.math.optimization.fitting.GaussianFitter.ParameterGuesser parameterGuesser6 = new org.apache.commons.math.optimization.fitting.GaussianFitter.ParameterGuesser(weightedObservedPointArray5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooSmallException; message: 1 is smaller than the minimum (3)");
        } catch (org.apache.commons.math.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(weightedObservedPointArray5);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        double double2 = org.apache.commons.math.util.FastMath.scalb((double) (-1L), 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "distribution not loaded" + "'", str1.equals("distribution not loaded"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.5109895864477217d, (double) 1.0000001f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.47240052873288296d + "'", double2 == 0.47240052873288296d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (int) '#', 0);
        int int4 = dimensionMismatchException3.getDimension();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-1), (double) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        try {
            org.apache.commons.math.analysis.function.Gaussian gaussian2 = new org.apache.commons.math.analysis.function.Gaussian((double) (byte) 0, (-0.7853981633974483d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.785 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        float float2 = org.apache.commons.math.util.FastMath.min((-126.99999f), (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-126.99999f) + "'", float2 == (-126.99999f));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2533141373155001d + "'", double1 == 1.2533141373155001d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1752011936438014d + "'", double1 == 1.1752011936438014d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        double double2 = org.apache.commons.math.util.FastMath.scalb((double) (short) 10, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) '#');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) 1L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0000001f + "'", float1 == 1.0000001f);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-127));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (short) 100, (float) (short) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        int int2 = org.apache.commons.math.util.FastMath.max((-1), (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8623188722876839d + "'", double1 == 0.8623188722876839d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        double double1 = org.apache.commons.math.util.FastMath.cos((-127.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.23235910202965793d + "'", double1 == 0.23235910202965793d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer differentiableMultivariateVectorialOptimizer0 = null;
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter1 = new org.apache.commons.math.optimization.fitting.CurveFitter(differentiableMultivariateVectorialOptimizer0);
        curveFitter1.addObservedPoint((double) (-127), (-1.7976931348623157E308d));
        curveFitter1.addObservedPoint(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, (double) (-1));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(2.99822295029797d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.731537741517051d + "'", double1 == 1.731537741517051d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-1.0f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.8623188722876839d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3954144401702078d + "'", double1 == 1.3954144401702078d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.731537741517051d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (byte) 1, (java.lang.Number) 1.9155040003582885E22d, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("", objArray9);
        org.apache.commons.math.exception.util.Localizable localizable11 = mathException10.getGeneralPattern();
        java.lang.Throwable[] throwableArray12 = mathException10.getSuppressed();
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException3, (org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Object[]) throwableArray12);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException15 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 0L);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxCountExceededException15);
        mathException13.addSuppressed((java.lang.Throwable) convergenceException16);
        org.apache.commons.math.exception.util.Localizable localizable18 = mathException13.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.9155040003582885E22d + "'", number4.equals(1.9155040003582885E22d));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer differentiableMultivariateVectorialOptimizer0 = null;
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter1 = new org.apache.commons.math.optimization.fitting.CurveFitter(differentiableMultivariateVectorialOptimizer0);
        curveFitter1.addObservedPoint((double) (-127), (-1.7976931348623157E308d));
        curveFitter1.clearObservations();
        curveFitter1.addObservedPoint((double) 1.0000001f, 1.151292546497023d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker2 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker(1.0d, 1.151292546497023d);
        double[] doubleArray6 = new double[] { 100.00001f, 'a' };
        double[] doubleArray12 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair13 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray6, doubleArray12);
        double[] doubleArray14 = vectorialPointValuePair13.getValueRef();
        double[] doubleArray17 = new double[] { 100.00001f, 'a' };
        double[] doubleArray23 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair24 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray17, doubleArray23);
        boolean boolean25 = simpleVectorialValueChecker2.converged((int) 'a', vectorialPointValuePair13, vectorialPointValuePair24);
        double double26 = simpleVectorialValueChecker2.getRelativeThreshold();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 10, (int) (byte) 0);
        int int4 = dimensionMismatchException3.getDimension();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) dimensionMismatchException3);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 0L);
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException((java.lang.Throwable) maxCountExceededException1);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        double double1 = org.apache.commons.math.util.FastMath.asinh(7.896296018267969E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.69314718055993d + "'", double1 == 32.69314718055993d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 1);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        java.lang.Object[] objArray3 = notStrictlyPositiveException1.getArguments();
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException1);
        java.lang.Object[] objArray5 = mathException4.getArguments();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray5);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker1 = levenbergMarquardtOptimizer0.getConvergenceChecker();
        try {
            double[] doubleArray2 = levenbergMarquardtOptimizer0.guessParametersErrors();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooSmallException; message: 0 is smaller than, or equal to, the minimum (0): no degrees of freedom (0 measurements, 0 parameters)");
        } catch (org.apache.commons.math.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker1);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        float float2 = org.apache.commons.math.util.FastMath.max((-126.99999f), (float) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 'a', (double) 35.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ILLEGAL_STATE;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 1, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ILLEGAL_STATE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ILLEGAL_STATE));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 1L, (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker1 = levenbergMarquardtOptimizer0.getConvergenceChecker();
        org.apache.commons.math.analysis.DifferentiableMultivariateVectorialFunction differentiableMultivariateVectorialFunction3 = null;
        double[] doubleArray4 = null;
        double[] doubleArray7 = new double[] { 100.00001f, 'a' };
        double[] doubleArray13 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair14 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray7, doubleArray13);
        double[] doubleArray17 = new double[] { 100.00001f, 'a' };
        double[] doubleArray23 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair24 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray17, doubleArray23);
        double[] doubleArray25 = vectorialPointValuePair24.getPoint();
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair26 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray7, doubleArray25);
        double[] doubleArray29 = new double[] { 100.00001f, 'a' };
        double[] doubleArray35 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair36 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray29, doubleArray35);
        double[] doubleArray37 = vectorialPointValuePair36.getValueRef();
        double[] doubleArray38 = vectorialPointValuePair36.getPoint();
        try {
            org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair39 = levenbergMarquardtOptimizer0.optimize(0, differentiableMultivariateVectorialFunction3, doubleArray4, doubleArray25, doubleArray38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-1), (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 35.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.930067261567154E14d + "'", double1 == 7.930067261567154E14d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        java.lang.Throwable throwable1 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException("", objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = mathException7.getGeneralPattern();
        java.lang.Throwable[] throwableArray9 = mathException7.getSuppressed();
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException(throwable1, "hi!", (java.lang.Object[]) throwableArray9);
        java.lang.Object[] objArray11 = mathException10.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException("hi!", objArray11);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(localizable8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(objArray11);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((-57.29577951308232d), (double) '4', 0.009999666686665238d);
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker4 = levenbergMarquardtOptimizer3.getConvergenceChecker();
        try {
            double[] doubleArray5 = levenbergMarquardtOptimizer3.guessParametersErrors();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooSmallException; message: 0 is smaller than, or equal to, the minimum (0): no degrees of freedom (0 measurements, 0 parameters)");
        } catch (org.apache.commons.math.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker4);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-0.3619688119383991d), (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.36196881193839914d) + "'", double2 == (-0.36196881193839914d));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        long long1 = org.apache.commons.math.util.FastMath.round(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.apache.commons.math.analysis.function.Gaussian gaussian3 = new org.apache.commons.math.analysis.function.Gaussian(0.0d, (double) 100.0f, 10.0d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = gaussian3.derivative();
        double double6 = gaussian3.value(0.019230769230769232d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction7 = gaussian3.derivative();
        double double9 = gaussian3.value(0.7615941559557649d);
        double double11 = gaussian3.value((double) 1L);
        org.junit.Assert.assertNotNull(univariateRealFunction4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(univariateRealFunction7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 35.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5860134523134298E15d + "'", double1 == 1.5860134523134298E15d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        long long1 = org.apache.commons.math.util.FastMath.round(3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3L + "'", long1 == 3L);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0d, (java.lang.Number) 3L, (java.lang.Number) 0L);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer differentiableMultivariateVectorialOptimizer0 = null;
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter1 = new org.apache.commons.math.optimization.fitting.CurveFitter(differentiableMultivariateVectorialOptimizer0);
        curveFitter1.addObservedPoint((double) (-127), (-1.7976931348623157E308d));
        curveFitter1.addObservedPoint(1.4210804127942926d, 0.5640681427824117d, (double) '#');
        curveFitter1.addObservedPoint((double) 6, 3.1622776601683795d, 0.0d);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric14 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray17 = new double[] { 100.00001f, 'a' };
        double[] doubleArray23 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair24 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray17, doubleArray23);
        try {
            double[] doubleArray25 = curveFitter1.fit(0, (org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric14, doubleArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("distribution not loaded", objArray1);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer differentiableMultivariateVectorialOptimizer1 = null;
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter2 = new org.apache.commons.math.optimization.fitting.CurveFitter(differentiableMultivariateVectorialOptimizer1);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray3 = curveFitter2.getObservations();
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException("distribution not loaded", (java.lang.Object[]) weightedObservedPointArray3);
        org.junit.Assert.assertNotNull(weightedObservedPointArray3);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException("", objArray4);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN;
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) mathException5, (org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException5.getSpecificPattern();
        java.lang.Object[] objArray10 = mathException5.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray10);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN));
        org.junit.Assert.assertNull(localizable9);
        org.junit.Assert.assertNotNull(objArray10);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        double double1 = org.apache.commons.math.util.FastMath.sin(2.1544346215442474d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8344632455014589d + "'", double1 == 0.8344632455014589d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder(0.0d, (double) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.000000000000002d + "'", double1 == 10.000000000000002d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        double double1 = org.apache.commons.math.util.FastMath.tanh(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 9.999999f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3978951861007016d + "'", double1 == 2.3978951861007016d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 1);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        java.lang.Object[] objArray3 = notStrictlyPositiveException1.getArguments();
        java.lang.Throwable[] throwableArray4 = notStrictlyPositiveException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        double double2 = org.apache.commons.math.util.FastMath.scalb((double) (-127), 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-127.0d) + "'", double2 == (-127.0d));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.5860134523134298E15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.58601345231343E15d + "'", double1 == 1.58601345231343E15d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_ROWS_AND_COLUMNS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_ROWS_AND_COLUMNS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_ROWS_AND_COLUMNS));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.apache.commons.math.analysis.function.Gaussian gaussian3 = new org.apache.commons.math.analysis.function.Gaussian((double) '4', (double) 52, (double) 35.0f);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NULL_NOT_ALLOWED;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException("", objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = mathException5.getGeneralPattern();
        java.lang.Throwable[] throwableArray7 = mathException5.getSuppressed();
        java.lang.Object[] objArray8 = mathException5.getArguments();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS;
        java.lang.Object[] objArray15 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("", objArray15);
        org.apache.commons.math.exception.util.Localizable localizable17 = mathException16.getGeneralPattern();
        java.lang.Throwable[] throwableArray18 = mathException16.getSuppressed();
        java.lang.Object[] objArray19 = mathException16.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, objArray19);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException21 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathException5, (org.apache.commons.math.exception.util.Localizable) localizedFormats9, (org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray19);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException22 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray19);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NULL_NOT_ALLOWED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NULL_NOT_ALLOWED));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(objArray19);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        int int2 = org.apache.commons.math.util.FastMath.min(100, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) (-1));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-0.99999994f) + "'", float1 == (-0.99999994f));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        float float2 = org.apache.commons.math.util.FastMath.copySign((float) 'a', (float) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        java.lang.Object[] objArray3 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException("", objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = mathException4.getGeneralPattern();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("", objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray11);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException4, "hi!", objArray11);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND;
        java.lang.Object[] objArray21 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("", objArray21);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats17, objArray21);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException24 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) convergenceException14, (org.apache.commons.math.exception.util.Localizable) localizedFormats15, (org.apache.commons.math.exception.util.Localizable) localizedFormats16, objArray21);
        java.lang.Object[] objArray29 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException("", objArray29);
        org.apache.commons.math.exception.util.Localizable localizable31 = mathException30.getGeneralPattern();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND;
        java.lang.Object[] objArray37 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException("", objArray37);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats33, objArray37);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException30, "hi!", objArray37);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats41 = org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats42 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats43 = org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND;
        java.lang.Object[] objArray47 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException("", objArray47);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats43, objArray47);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException50 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) convergenceException40, (org.apache.commons.math.exception.util.Localizable) localizedFormats41, (org.apache.commons.math.exception.util.Localizable) localizedFormats42, objArray47);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException14, "hi!", objArray47);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats52 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS;
        java.lang.Object[] objArray56 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException("", objArray56);
        org.apache.commons.math.exception.util.Localizable localizable58 = mathException57.getGeneralPattern();
        java.lang.Throwable[] throwableArray59 = mathException57.getSuppressed();
        java.lang.Object[] objArray60 = mathException57.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException61 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats52, objArray60);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException62 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException61);
        convergenceException14.addSuppressed((java.lang.Throwable) mathRuntimeException62);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException64 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) convergenceException14);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(localizable5);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(localizable31);
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND + "'", localizedFormats33.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND));
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertTrue("'" + localizedFormats41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET + "'", localizedFormats41.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT + "'", localizedFormats42.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT));
        org.junit.Assert.assertTrue("'" + localizedFormats43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND + "'", localizedFormats43.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND));
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertTrue("'" + localizedFormats52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS + "'", localizedFormats52.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS));
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(localizable58);
        org.junit.Assert.assertNotNull(throwableArray59);
        org.junit.Assert.assertNotNull(objArray60);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.930067261567154E14d + "'", double1 == 7.930067261567154E14d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        float float1 = org.apache.commons.math.util.FastMath.nextUp(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.4E-45f + "'", float1 == 1.4E-45f);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 1);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        java.lang.Object[] objArray3 = notStrictlyPositiveException1.getArguments();
        java.lang.Class<?> wildcardClass4 = notStrictlyPositiveException1.getClass();
        java.lang.Object[] objArray5 = notStrictlyPositiveException1.getArguments();
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException6 = new org.apache.commons.math.exception.MathIllegalStateException(objArray5);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(objArray5);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) 100L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.00001f + "'", float1 == 100.00001f);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 0, (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_COLUMN;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_COLUMN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_COLUMN));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.apache.commons.math.analysis.function.Gaussian gaussian2 = new org.apache.commons.math.analysis.function.Gaussian((-1.0d), 3.1622776601683795d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        java.lang.Throwable throwable1 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException("", objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = mathException7.getGeneralPattern();
        java.lang.Throwable[] throwableArray9 = mathException7.getSuppressed();
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException(throwable1, "hi!", (java.lang.Object[]) throwableArray9);
        java.lang.Object[] objArray11 = mathException10.getArguments();
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("distribution not loaded", objArray11);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(localizable8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(objArray11);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 10L, (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (int) (byte) 10, 0);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.8104773809653514d + "'", double1 == 3.8104773809653514d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.731537741517051d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 10.0f, (double) 9.999999f, (double) (byte) 1, (double) 10, 0.0d);
        double double6 = levenbergMarquardtOptimizer5.getChiSquare();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.791759469228055d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.083333333333333d + "'", double1 == 3.083333333333333d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (byte) 1, (java.lang.Number) 1.9155040003582885E22d, false);
        java.lang.Number number6 = numberIsTooSmallException5.getMin();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = mathException12.getGeneralPattern();
        java.lang.Throwable[] throwableArray14 = mathException12.getSuppressed();
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException5, (org.apache.commons.math.exception.util.Localizable) localizedFormats7, (java.lang.Object[]) throwableArray14);
        org.apache.commons.math.exception.ZeroException zeroException16 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats7);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException20 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats17, 10, (int) (byte) 0);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException22 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 1);
        boolean boolean23 = notStrictlyPositiveException22.getBoundIsAllowed();
        java.lang.Object[] objArray24 = notStrictlyPositiveException22.getArguments();
        java.lang.Class<?> wildcardClass25 = notStrictlyPositiveException22.getClass();
        java.lang.Object[] objArray26 = notStrictlyPositiveException22.getArguments();
        java.lang.Object[] objArray27 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray26);
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException((java.lang.Throwable) zeroException16, (org.apache.commons.math.exception.util.Localizable) localizedFormats17, objArray26);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException29 = new org.apache.commons.math.exception.MathIllegalStateException(throwable0, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray26);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.9155040003582885E22d + "'", number6.equals(1.9155040003582885E22d));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray27);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.2533141373155001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.078168517213161d + "'", double1 == 1.078168517213161d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker0 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        double double1 = simpleVectorialValueChecker0.getAbsoluteThreshold();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2250738585072014E-306d + "'", double1 == 2.2250738585072014E-306d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.apache.commons.math.analysis.function.Gaussian gaussian0 = new org.apache.commons.math.analysis.function.Gaussian();
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) (short) -1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-0.99999994f) + "'", float1 == (-0.99999994f));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) ' ');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 32L + "'", long1 == 32L);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(7.105427357601002E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601003E-15d + "'", double1 == 7.105427357601003E-15d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric0 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray4 = new double[] { 100.00001f, 'a' };
        double[] doubleArray10 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair11 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray4, doubleArray10);
        double[] doubleArray14 = new double[] { 100.00001f, 'a' };
        double[] doubleArray20 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair21 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray14, doubleArray20);
        double[] doubleArray22 = vectorialPointValuePair21.getPoint();
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair23 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray4, doubleArray22);
        double[] doubleArray26 = new double[] { 100.00001f, 'a' };
        double[] doubleArray32 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair33 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray26, doubleArray32);
        double[] doubleArray34 = vectorialPointValuePair33.getValueRef();
        double[] doubleArray35 = vectorialPointValuePair33.getPoint();
        double[] doubleArray36 = vectorialPointValuePair33.getPointRef();
        double[] doubleArray39 = new double[] { 100.00001f, 'a' };
        double[] doubleArray45 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray39, doubleArray45);
        double[] doubleArray49 = new double[] { 100.00001f, 'a' };
        double[] doubleArray55 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair56 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray49, doubleArray55);
        double[] doubleArray57 = vectorialPointValuePair56.getPoint();
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair58 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray39, doubleArray57);
        double[] doubleArray61 = new double[] { 100.00001f, 'a' };
        double[] doubleArray67 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair68 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray61, doubleArray67);
        double[] doubleArray71 = new double[] { 100.00001f, 'a' };
        double[] doubleArray77 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair78 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray71, doubleArray77);
        double[] doubleArray79 = vectorialPointValuePair78.getPoint();
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair80 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray61, doubleArray79);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair82 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray57, doubleArray79, true);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair83 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray36, doubleArray79);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair85 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray22, doubleArray79, false);
        try {
            double[] doubleArray86 = parametric0.gradient(1.3954144401702078d, doubleArray22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: dimensions mismatch: 2 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray79);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.302585092994046d + "'", double1 == 2.302585092994046d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ROWS_NOT_INITIALIZED_YET;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ROWS_NOT_INITIALIZED_YET + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ROWS_NOT_INITIALIZED_YET));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.302585092994046d + "'", double1 == 2.302585092994046d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 0.020687957244708476d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 3.141592653589793d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.010000000006666444d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.010000000006666445d + "'", double1 == 0.010000000006666445d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        double double1 = org.apache.commons.math.util.FastMath.log10((-0.3619688119383991d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.23235910202965793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.23450247038662617d + "'", double1 == 0.23450247038662617d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.0000499970835348d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1752783446440636d + "'", double1 == 1.1752783446440636d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.STANDARD_DEVIATION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.STANDARD_DEVIATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.STANDARD_DEVIATION));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer differentiableMultivariateVectorialOptimizer0 = null;
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter1 = new org.apache.commons.math.optimization.fitting.CurveFitter(differentiableMultivariateVectorialOptimizer0);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = curveFitter1.getObservations();
        try {
            org.apache.commons.math.optimization.fitting.GaussianFitter.ParameterGuesser parameterGuesser3 = new org.apache.commons.math.optimization.fitting.GaussianFitter.ParameterGuesser(weightedObservedPointArray2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooSmallException; message: 0 is smaller than the minimum (3)");
        } catch (org.apache.commons.math.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) '4');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 52L + "'", long1 == 52L);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 10.0f, (double) 9.999999f, (double) (byte) 1, (double) 10, 0.0d);
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker6 = levenbergMarquardtOptimizer5.getConvergenceChecker();
        int int7 = levenbergMarquardtOptimizer5.getMaxEvaluations();
        int int8 = levenbergMarquardtOptimizer5.getMaxEvaluations();
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker11 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker((double) (byte) 100, (double) '#');
        levenbergMarquardtOptimizer5.setConvergenceChecker((org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair>) simpleVectorialValueChecker11);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) 6, 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 12.0f + "'", float2 == 12.0f);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        float float1 = org.apache.commons.math.util.FastMath.signum(1.0000001f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 32L);
        java.lang.Number number2 = tooManyEvaluationsException1.getMax();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 32L + "'", number2.equals(32L));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.1102230246251565E-14d, (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.007199254740992E13d + "'", double2 == 9.007199254740992E13d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric0 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray4 = new double[] { 100.00001f, 'a' };
        double[] doubleArray10 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair11 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray4, doubleArray10);
        double[] doubleArray14 = new double[] { 100.00001f, 'a' };
        double[] doubleArray20 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair21 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray14, doubleArray20);
        double[] doubleArray22 = vectorialPointValuePair21.getPoint();
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair23 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray4, doubleArray22);
        double[] doubleArray26 = new double[] { 100.00001f, 'a' };
        double[] doubleArray32 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair33 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray26, doubleArray32);
        double[] doubleArray36 = new double[] { 100.00001f, 'a' };
        double[] doubleArray42 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair43 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray36, doubleArray42);
        double[] doubleArray44 = vectorialPointValuePair43.getPoint();
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair45 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray26, doubleArray44);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair47 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray22, doubleArray44, true);
        try {
            double[] doubleArray48 = parametric0.gradient(0.0d, doubleArray44);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: dimensions mismatch: 2 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS;
        org.apache.commons.math.exception.ZeroException zeroException1 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats0);
        java.lang.Object[] objArray2 = zeroException1.getArguments();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS));
        org.junit.Assert.assertNotNull(objArray2);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 10.0f, (double) 9.999999f, (double) (byte) 1, (double) 10, 0.0d);
        double double6 = levenbergMarquardtOptimizer5.getRMS();
        org.apache.commons.math.analysis.DifferentiableMultivariateVectorialFunction differentiableMultivariateVectorialFunction8 = null;
        double[] doubleArray11 = new double[] { 100.00001f, 'a' };
        double[] doubleArray17 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair18 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray11, doubleArray17);
        double[] doubleArray19 = vectorialPointValuePair18.getPoint();
        double[] doubleArray20 = vectorialPointValuePair18.getValue();
        double[] doubleArray23 = new double[] { 100.00001f, 'a' };
        double[] doubleArray29 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair30 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray23, doubleArray29);
        double[] doubleArray31 = vectorialPointValuePair30.getValueRef();
        double[] doubleArray32 = vectorialPointValuePair30.getPoint();
        double[] doubleArray33 = vectorialPointValuePair30.getPointRef();
        double[] doubleArray34 = vectorialPointValuePair30.getPointRef();
        double[] doubleArray37 = new double[] { 100.00001f, 'a' };
        double[] doubleArray43 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair44 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray37, doubleArray43);
        double[] doubleArray45 = vectorialPointValuePair44.getValueRef();
        double[] doubleArray46 = vectorialPointValuePair44.getPoint();
        try {
            org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair47 = levenbergMarquardtOptimizer5.optimize((int) (short) 100, differentiableMultivariateVectorialFunction8, doubleArray20, doubleArray34, doubleArray46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        float float2 = org.apache.commons.math.util.FastMath.copySign((float) (short) 10, (float) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ROW_DIMENSION;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException("", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException6.getGeneralPattern();
        java.lang.Throwable[] throwableArray8 = mathException6.getSuppressed();
        java.lang.Object[] objArray9 = mathException6.getArguments();
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException10 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100, objArray9);
        java.lang.String str11 = localizedFormats0.getSourceString();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.ITERATOR_EXHAUSTED;
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException("", objArray15);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException17 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) convergenceException16);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_COUNT_EXCEEDED;
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException21 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 0L);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxCountExceededException21);
        java.lang.Throwable[] throwableArray23 = maxCountExceededException21.getSuppressed();
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((org.apache.commons.math.exception.util.Localizable) localizedFormats19, (java.lang.Object[]) throwableArray23);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException16, (org.apache.commons.math.exception.util.Localizable) localizedFormats18, (java.lang.Object[]) throwableArray23);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException26 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, (org.apache.commons.math.exception.util.Localizable) localizedFormats13, (java.lang.Object[]) throwableArray23);
        org.apache.commons.math.exception.ConvergenceException convergenceException27 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray23);
        org.apache.commons.math.optimization.OptimizationException optimizationException28 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException27);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ROW_DIMENSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ROW_DIMENSION));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "invalid row dimension: {0} (must be positive)" + "'", str11.equals("invalid row dimension: {0} (must be positive)"));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ITERATOR_EXHAUSTED + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.ITERATOR_EXHAUSTED));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_COUNT_EXCEEDED + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_COUNT_EXCEEDED));
        org.junit.Assert.assertNotNull(throwableArray23);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX;
        org.apache.commons.math.exception.ZeroException zeroException1 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats0);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException("", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException6.getGeneralPattern();
        java.lang.Throwable[] throwableArray8 = mathException6.getSuppressed();
        java.lang.Object[] objArray9 = mathException6.getArguments();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS;
        java.lang.Object[] objArray16 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("", objArray16);
        org.apache.commons.math.exception.util.Localizable localizable18 = mathException17.getGeneralPattern();
        java.lang.Throwable[] throwableArray19 = mathException17.getSuppressed();
        java.lang.Object[] objArray20 = mathException17.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, objArray20);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathException6, (org.apache.commons.math.exception.util.Localizable) localizedFormats10, (org.apache.commons.math.exception.util.Localizable) localizedFormats11, objArray20);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray20);
        org.apache.commons.math.optimization.OptimizationException optimizationException24 = new org.apache.commons.math.optimization.OptimizationException("distribution not loaded", objArray20);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(localizable18);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(objArray20);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 32L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (byte) 1, (java.lang.Number) 1.9155040003582885E22d, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        java.lang.Object[] objArray5 = numberIsTooSmallException3.getArguments();
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException6 = new org.apache.commons.math.exception.MathIllegalStateException(objArray5);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.9155040003582885E22d + "'", number4.equals(1.9155040003582885E22d));
        org.junit.Assert.assertNotNull(objArray5);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) ' ');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 100.0d);
        java.lang.Number number2 = tooManyEvaluationsException1.getMax();
        org.apache.commons.math.exception.util.Localizable localizable3 = tooManyEvaluationsException1.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 100.0d + "'", number2.equals(100.0d));
        org.junit.Assert.assertNull(localizable3);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        int int2 = org.apache.commons.math.util.FastMath.max(0, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        double double2 = org.apache.commons.math.util.FastMath.scalb((double) 0.0f, 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(0.009999666686665238d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-7) + "'", int1 == (-7));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        org.apache.commons.math.analysis.DifferentiableMultivariateVectorialFunction differentiableMultivariateVectorialFunction2 = null;
        double[] doubleArray5 = new double[] { 100.00001f, 'a' };
        double[] doubleArray11 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair12 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray5, doubleArray11);
        double[] doubleArray13 = vectorialPointValuePair12.getPoint();
        double[] doubleArray14 = vectorialPointValuePair12.getValue();
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker17 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker(1.0d, 1.151292546497023d);
        double[] doubleArray21 = new double[] { 100.00001f, 'a' };
        double[] doubleArray27 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair28 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray21, doubleArray27);
        double[] doubleArray29 = vectorialPointValuePair28.getValueRef();
        double[] doubleArray32 = new double[] { 100.00001f, 'a' };
        double[] doubleArray38 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair39 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray32, doubleArray38);
        boolean boolean40 = simpleVectorialValueChecker17.converged((int) 'a', vectorialPointValuePair28, vectorialPointValuePair39);
        double[] doubleArray41 = vectorialPointValuePair28.getPoint();
        double[] doubleArray42 = new double[] {};
        try {
            org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair43 = levenbergMarquardtOptimizer0.optimize(0, differentiableMultivariateVectorialFunction2, doubleArray14, doubleArray41, doubleArray42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) 1L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        java.lang.Object[] objArray3 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException("", objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = mathException4.getGeneralPattern();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("", objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray11);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException4, "hi!", objArray11);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND;
        java.lang.Object[] objArray21 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("", objArray21);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats17, objArray21);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException24 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) convergenceException14, (org.apache.commons.math.exception.util.Localizable) localizedFormats15, (org.apache.commons.math.exception.util.Localizable) localizedFormats16, objArray21);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (byte) 1, (java.lang.Number) 1.9155040003582885E22d, false);
        java.lang.Number number29 = numberIsTooSmallException28.getMin();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS;
        java.lang.Object[] objArray34 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException("", objArray34);
        org.apache.commons.math.exception.util.Localizable localizable36 = mathException35.getGeneralPattern();
        java.lang.Throwable[] throwableArray37 = mathException35.getSuppressed();
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException28, (org.apache.commons.math.exception.util.Localizable) localizedFormats30, (java.lang.Object[]) throwableArray37);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException39 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathException38);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats40 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE;
        java.lang.Throwable throwable41 = null;
        java.lang.Object[] objArray46 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException("", objArray46);
        org.apache.commons.math.exception.util.Localizable localizable48 = mathException47.getGeneralPattern();
        java.lang.Throwable[] throwableArray49 = mathException47.getSuppressed();
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException(throwable41, "hi!", (java.lang.Object[]) throwableArray49);
        java.lang.Object[] objArray51 = mathException50.getArguments();
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException((java.lang.Throwable) mathRuntimeException39, (org.apache.commons.math.exception.util.Localizable) localizedFormats40, objArray51);
        org.apache.commons.math.exception.ConvergenceException convergenceException53 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, objArray51);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats54 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS;
        java.lang.Object[] objArray58 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException("", objArray58);
        org.apache.commons.math.exception.util.Localizable localizable60 = mathException59.getGeneralPattern();
        java.lang.Throwable[] throwableArray61 = mathException59.getSuppressed();
        java.lang.Object[] objArray62 = mathException59.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats54, objArray62);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats64 = org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY;
        java.lang.Throwable throwable65 = null;
        java.lang.Object[] objArray70 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException("", objArray70);
        org.apache.commons.math.exception.util.Localizable localizable72 = mathException71.getGeneralPattern();
        java.lang.Throwable[] throwableArray73 = mathException71.getSuppressed();
        org.apache.commons.math.MathException mathException74 = new org.apache.commons.math.MathException(throwable65, "hi!", (java.lang.Object[]) throwableArray73);
        java.lang.Object[] objArray75 = mathException74.getArguments();
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException63, (org.apache.commons.math.exception.util.Localizable) localizedFormats64, objArray75);
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, objArray75);
        org.apache.commons.math.exception.util.Localizable localizable78 = convergenceException77.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(localizable5);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 1.9155040003582885E22d + "'", number29.equals(1.9155040003582885E22d));
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS + "'", localizedFormats30.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS));
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(localizable36);
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertTrue("'" + localizedFormats40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE + "'", localizedFormats40.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE));
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(localizable48);
        org.junit.Assert.assertNotNull(throwableArray49);
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertTrue("'" + localizedFormats54 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS + "'", localizedFormats54.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS));
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(localizable60);
        org.junit.Assert.assertNotNull(throwableArray61);
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertTrue("'" + localizedFormats64 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY + "'", localizedFormats64.equals(org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY));
        org.junit.Assert.assertNotNull(objArray70);
        org.junit.Assert.assertNotNull(localizable72);
        org.junit.Assert.assertNotNull(throwableArray73);
        org.junit.Assert.assertNotNull(objArray75);
        org.junit.Assert.assertTrue("'" + localizable78 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT + "'", localizable78.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        long long1 = org.apache.commons.math.util.FastMath.abs(52L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 52L + "'", long1 == 52L);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) 10L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.000001f + "'", float1 == 10.000001f);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException("", objArray4);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException6 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray4);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException7 = new org.apache.commons.math.exception.MathIllegalStateException(objArray4);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 1);
        boolean boolean11 = notStrictlyPositiveException10.getBoundIsAllowed();
        java.lang.Object[] objArray12 = notStrictlyPositiveException10.getArguments();
        java.lang.Class<?> wildcardClass13 = notStrictlyPositiveException10.getClass();
        java.lang.Object[] objArray14 = notStrictlyPositiveException10.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException7, "hi!", objArray14);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE;
        java.lang.Throwable throwable17 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException("", objArray22);
        org.apache.commons.math.exception.util.Localizable localizable24 = mathException23.getGeneralPattern();
        java.lang.Throwable[] throwableArray25 = mathException23.getSuppressed();
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException(throwable17, "hi!", (java.lang.Object[]) throwableArray25);
        java.lang.Object[] objArray27 = mathException26.getArguments();
        org.apache.commons.math.optimization.OptimizationException optimizationException28 = new org.apache.commons.math.optimization.OptimizationException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, objArray27);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES;
        java.lang.Object[] objArray31 = null;
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException("", objArray31);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException33 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) convergenceException32);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_COUNT_EXCEEDED;
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException37 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 0L);
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxCountExceededException37);
        java.lang.Throwable[] throwableArray39 = maxCountExceededException37.getSuppressed();
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException((org.apache.commons.math.exception.util.Localizable) localizedFormats35, (java.lang.Object[]) throwableArray39);
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException32, (org.apache.commons.math.exception.util.Localizable) localizedFormats34, (java.lang.Object[]) throwableArray39);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats43 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats44 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS;
        java.lang.Object[] objArray48 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException("", objArray48);
        org.apache.commons.math.exception.util.Localizable localizable50 = mathException49.getGeneralPattern();
        java.lang.Throwable[] throwableArray51 = mathException49.getSuppressed();
        java.lang.Object[] objArray52 = mathException49.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException53 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats44, objArray52);
        org.apache.commons.math.exception.ConvergenceException convergenceException54 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats43, objArray52);
        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException32, "", objArray52);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException56 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalStateException7, (org.apache.commons.math.exception.util.Localizable) localizedFormats16, (org.apache.commons.math.exception.util.Localizable) localizedFormats29, objArray52);
        org.apache.commons.math.exception.util.Localizable localizable57 = mathIllegalStateException7.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(localizable24);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES + "'", localizedFormats29.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES));
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING + "'", localizedFormats34.equals(org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING));
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_COUNT_EXCEEDED + "'", localizedFormats35.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_COUNT_EXCEEDED));
        org.junit.Assert.assertNotNull(throwableArray39);
        org.junit.Assert.assertTrue("'" + localizedFormats43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX + "'", localizedFormats43.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS + "'", localizedFormats44.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS));
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(localizable50);
        org.junit.Assert.assertNotNull(throwableArray51);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertTrue("'" + localizable57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ILLEGAL_STATE + "'", localizable57.equals(org.apache.commons.math.exception.util.LocalizedFormats.ILLEGAL_STATE));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer differentiableMultivariateVectorialOptimizer0 = null;
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter1 = new org.apache.commons.math.optimization.fitting.GaussianFitter(differentiableMultivariateVectorialOptimizer0);
        try {
            double[] doubleArray2 = gaussianFitter1.fit();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooSmallException; message: 0 is smaller than the minimum (3)");
        } catch (org.apache.commons.math.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7453292519943295d + "'", double1 == 1.7453292519943295d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.020687957244708476d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException("", objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = mathException5.getGeneralPattern();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND;
        java.lang.Object[] objArray12 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException("", objArray12);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray12);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException5, "hi!", objArray12);
        java.lang.Throwable[] throwableArray16 = convergenceException15.getSuppressed();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE;
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException();
        java.lang.Throwable[] throwableArray20 = mathException19.getSuppressed();
        org.apache.commons.math.optimization.OptimizationException optimizationException21 = new org.apache.commons.math.optimization.OptimizationException("hi!", (java.lang.Object[]) throwableArray20);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException15, (org.apache.commons.math.exception.util.Localizable) localizedFormats17, (java.lang.Object[]) throwableArray20);
        org.apache.commons.math.exception.ConvergenceException convergenceException23 = new org.apache.commons.math.exception.ConvergenceException(localizable0, (java.lang.Object[]) throwableArray20);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(throwableArray20);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer differentiableMultivariateVectorialOptimizer0 = null;
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter1 = new org.apache.commons.math.optimization.fitting.GaussianFitter(differentiableMultivariateVectorialOptimizer0);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = gaussianFitter1.getObservations();
        double[] doubleArray5 = new double[] { 100.00001f, 'a' };
        double[] doubleArray11 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair12 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray5, doubleArray11);
        double[] doubleArray15 = new double[] { 100.00001f, 'a' };
        double[] doubleArray21 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair22 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray15, doubleArray21);
        double[] doubleArray23 = vectorialPointValuePair22.getPoint();
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair24 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray5, doubleArray23);
        double[] doubleArray27 = new double[] { 100.00001f, 'a' };
        double[] doubleArray33 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair34 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray27, doubleArray33);
        double[] doubleArray37 = new double[] { 100.00001f, 'a' };
        double[] doubleArray43 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair44 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray37, doubleArray43);
        double[] doubleArray45 = vectorialPointValuePair44.getPoint();
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray27, doubleArray45);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair48 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray23, doubleArray45, true);
        try {
            double[] doubleArray49 = gaussianFitter1.fit(doubleArray45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        double double2 = org.apache.commons.math.util.FastMath.max((-57.29577951308232d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getCount();
        incrementor0.setMaximalCount((int) (short) -1);
        incrementor0.setMaximalCount(0);
        int int6 = incrementor0.getCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.010000000006666445d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.009999833340832777d + "'", double1 == 0.009999833340832777d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.apache.commons.math.analysis.function.Gaussian gaussian3 = new org.apache.commons.math.analysis.function.Gaussian((double) 1, 1.2533141373155001d, 1.7453292519943295d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        int int1 = org.apache.commons.math.util.FastMath.abs(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        double double2 = org.apache.commons.math.util.FastMath.hypot((double) 6, Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 52L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.00000000000001d + "'", double1 == 52.00000000000001d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) -1, (java.lang.Number) 0, (java.lang.Number) (-127));
        java.lang.Number number5 = outOfRangeException4.getHi();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-127) + "'", number5.equals((-127)));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE;
        java.lang.Throwable throwable2 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException8.getGeneralPattern();
        java.lang.Throwable[] throwableArray10 = mathException8.getSuppressed();
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(throwable2, "hi!", (java.lang.Object[]) throwableArray10);
        java.lang.Object[] objArray12 = mathException11.getArguments();
        org.apache.commons.math.optimization.OptimizationException optimizationException13 = new org.apache.commons.math.optimization.OptimizationException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray12);
        org.apache.commons.math.optimization.OptimizationException optimizationException14 = new org.apache.commons.math.optimization.OptimizationException("", objArray12);
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (byte) 1, (java.lang.Number) 1.9155040003582885E22d, false);
        java.lang.Number number21 = numberIsTooSmallException20.getArgument();
        java.lang.Throwable[] throwableArray22 = numberIsTooSmallException20.getSuppressed();
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException23 = new org.apache.commons.math.exception.MathIllegalStateException(localizable15, (org.apache.commons.math.exception.util.Localizable) localizedFormats16, (java.lang.Object[]) throwableArray22);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_COLUMN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY;
        java.lang.Throwable throwable27 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException("", objArray32);
        org.apache.commons.math.exception.util.Localizable localizable34 = mathException33.getGeneralPattern();
        java.lang.Throwable[] throwableArray35 = mathException33.getSuppressed();
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException(throwable27, "hi!", (java.lang.Object[]) throwableArray35);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException37 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats25, (org.apache.commons.math.exception.util.Localizable) localizedFormats26, (java.lang.Object[]) throwableArray35);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException38 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) optimizationException14, (org.apache.commons.math.exception.util.Localizable) localizedFormats16, (org.apache.commons.math.exception.util.Localizable) localizedFormats24, (java.lang.Object[]) throwableArray35);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats39 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats40 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY;
        java.lang.Throwable throwable41 = null;
        java.lang.Object[] objArray46 = new java.lang.Object[] { 0.0d, 1L };
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException("", objArray46);
        org.apache.commons.math.exception.util.Localizable localizable48 = mathException47.getGeneralPattern();
        java.lang.Throwable[] throwableArray49 = mathException47.getSuppressed();
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException(throwable41, "hi!", (java.lang.Object[]) throwableArray49);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException51 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats39, (org.apache.commons.math.exception.util.Localizable) localizedFormats40, (java.lang.Object[]) throwableArray49);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats52 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException56 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (byte) 1, (java.lang.Number) 1.9155040003582885E22d, false);
        java.lang.Number number57 = numberIsTooSmallException56.getArgument();
        java.lang.Throwable[] throwableArray58 = numberIsTooSmallException56.getSuppressed();
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException59 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalStateException38, (org.apache.commons.math.exception.util.Localizable) localizedFormats39, (org.apache.commons.math.exception.util.Localizable) localizedFormats52, (java.lang.Object[]) throwableArray58);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (byte) 1 + "'", number21.equals((byte) 1));
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_COLUMN + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_COLUMN));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(localizable34);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertTrue("'" + localizedFormats39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats39.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertTrue("'" + localizedFormats40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY + "'", localizedFormats40.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY));
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(localizable48);
        org.junit.Assert.assertNotNull(throwableArray49);
        org.junit.Assert.assertTrue("'" + localizedFormats52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats52.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertTrue("'" + number57 + "' != '" + (byte) 1 + "'", number57.equals((byte) 1));
        org.junit.Assert.assertNotNull(throwableArray58);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        double double2 = org.apache.commons.math.util.FastMath.pow(9.007199254740992E13d, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.007199254740992E13d + "'", double2 == 9.007199254740992E13d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 6, (double) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.0d + "'", double2 == 6.0d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer differentiableMultivariateVectorialOptimizer0 = null;
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter1 = new org.apache.commons.math.optimization.fitting.CurveFitter(differentiableMultivariateVectorialOptimizer0);
        org.apache.commons.math.analysis.ParametricUnivariateRealFunction parametricUnivariateRealFunction2 = null;
        double[] doubleArray5 = new double[] { 100.00001f, 'a' };
        double[] doubleArray11 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair12 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray5, doubleArray11);
        double[] doubleArray13 = vectorialPointValuePair12.getValueRef();
        double[] doubleArray14 = vectorialPointValuePair12.getPoint();
        double[] doubleArray15 = vectorialPointValuePair12.getPointRef();
        double[] doubleArray16 = vectorialPointValuePair12.getPointRef();
        double[] doubleArray17 = vectorialPointValuePair12.getPointRef();
        try {
            double[] doubleArray18 = curveFitter1.fit(parametricUnivariateRealFunction2, doubleArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        double double2 = org.apache.commons.math.util.FastMath.scalb(2.2250738585072014E-306d, 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.8206162122887962E-276d + "'", double2 == 2.8206162122887962E-276d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_ROW_AFTER_FINAL_ROW;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_ROW_AFTER_FINAL_ROW + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_ROW_AFTER_FINAL_ROW));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.8623188722876839d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        double[] doubleArray2 = new double[] { 100.00001f, 'a' };
        double[] doubleArray8 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair9 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray2, doubleArray8);
        double[] doubleArray12 = new double[] { 100.00001f, 'a' };
        double[] doubleArray18 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair19 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray12, doubleArray18);
        double[] doubleArray20 = vectorialPointValuePair19.getPoint();
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair21 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray2, doubleArray20);
        double[] doubleArray24 = new double[] { 100.00001f, 'a' };
        double[] doubleArray30 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair31 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray24, doubleArray30);
        double[] doubleArray34 = new double[] { 100.00001f, 'a' };
        double[] doubleArray40 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair41 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray34, doubleArray40);
        double[] doubleArray42 = vectorialPointValuePair41.getPoint();
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair43 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray24, doubleArray42);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair45 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray20, doubleArray42, true);
        double[] doubleArray48 = new double[] { 100.00001f, 'a' };
        double[] doubleArray54 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair55 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray48, doubleArray54);
        double[] doubleArray56 = vectorialPointValuePair55.getPoint();
        double[] doubleArray57 = vectorialPointValuePair55.getValue();
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair59 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray42, doubleArray57, false);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        double double1 = org.apache.commons.math.util.FastMath.atan(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((-57.29577951308232d), (double) '4', 0.009999666686665238d);
        int int4 = levenbergMarquardtOptimizer3.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 0, (float) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-0.3619688119383991d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.3469470372869078d) + "'", double1 == (-0.3469470372869078d));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6321205588285577d) + "'", double1 == (-0.6321205588285577d));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        double double1 = org.apache.commons.math.util.FastMath.atan(2.302585092994046d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1610795826858162d + "'", double1 == 1.1610795826858162d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        int int2 = org.apache.commons.math.util.FastMath.min((int) ' ', (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.5109895864477217d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5363356317751373d + "'", double1 == 0.5363356317751373d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        double[] doubleArray2 = new double[] { 100.00001f, 'a' };
        double[] doubleArray8 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair9 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray2, doubleArray8);
        double[] doubleArray12 = new double[] { 100.00001f, 'a' };
        double[] doubleArray18 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair19 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray12, doubleArray18);
        double[] doubleArray20 = vectorialPointValuePair19.getPoint();
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair21 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray2, doubleArray20);
        double[] doubleArray24 = new double[] { 100.00001f, 'a' };
        double[] doubleArray30 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair31 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray24, doubleArray30);
        double[] doubleArray32 = vectorialPointValuePair31.getValueRef();
        double[] doubleArray33 = vectorialPointValuePair31.getPoint();
        double[] doubleArray34 = vectorialPointValuePair31.getPointRef();
        double[] doubleArray37 = new double[] { 100.00001f, 'a' };
        double[] doubleArray43 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair44 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray37, doubleArray43);
        double[] doubleArray47 = new double[] { 100.00001f, 'a' };
        double[] doubleArray53 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair54 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray47, doubleArray53);
        double[] doubleArray55 = vectorialPointValuePair54.getPoint();
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair56 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray37, doubleArray55);
        double[] doubleArray59 = new double[] { 100.00001f, 'a' };
        double[] doubleArray65 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair66 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray59, doubleArray65);
        double[] doubleArray69 = new double[] { 100.00001f, 'a' };
        double[] doubleArray75 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair76 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray69, doubleArray75);
        double[] doubleArray77 = vectorialPointValuePair76.getPoint();
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair78 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray59, doubleArray77);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair80 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray55, doubleArray77, true);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair81 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray34, doubleArray77);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair83 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray20, doubleArray77, false);
        double[] doubleArray84 = vectorialPointValuePair83.getPoint();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray84);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 10.0f, (double) 9.999999f, (double) (byte) 1, (double) 10, 0.0d);
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker6 = levenbergMarquardtOptimizer5.getConvergenceChecker();
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker7 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        levenbergMarquardtOptimizer5.setConvergenceChecker((org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair>) simpleVectorialValueChecker7);
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter9 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer5);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric11 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray14 = new double[] { 100.00001f, 'a' };
        double[] doubleArray20 = new double[] { 'a', 9.999999f, (short) 0, '#', Double.NaN };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair21 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray14, doubleArray20);
        double[] doubleArray22 = vectorialPointValuePair21.getPoint();
        double[] doubleArray23 = vectorialPointValuePair21.getValue();
        try {
            double[] doubleArray24 = curveFitter9.fit((int) (byte) 1, (org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric11, doubleArray23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.TooManyEvaluationsException; message: evaluations");
        } catch (org.apache.commons.math.exception.TooManyEvaluationsException e) {
        }
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer differentiableMultivariateVectorialOptimizer0 = null;
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter1 = new org.apache.commons.math.optimization.fitting.CurveFitter(differentiableMultivariateVectorialOptimizer0);
        curveFitter1.addObservedPoint((double) (-127), (-1.7976931348623157E308d));
        curveFitter1.addObservedPoint(1.4210804127942926d, 0.5640681427824117d, (double) '#');
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric9 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray10 = null;
        try {
            double[] doubleArray11 = curveFitter1.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric9, doubleArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        double double1 = org.apache.commons.math.util.FastMath.ulp(2.3978951861007016d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100L);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException1.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(localizable3);
    }
}

