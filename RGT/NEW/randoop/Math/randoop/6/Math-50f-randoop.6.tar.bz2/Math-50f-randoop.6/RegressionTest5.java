import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest5 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test001");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger4 = null;
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger6);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 257862796);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 257862796, (java.lang.Number) (-385L), false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX));
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test002");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) (-4558301418543122432L), (float) 362819936404418211L, 2026769579);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test003");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.21094709796687366d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test004");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 1.19873438E11f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1036261117) + "'", int1 == (-1036261117));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test005");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        double[] doubleArray4 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray11 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double12 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray4, doubleArray11);
        double[][] doubleArray13 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray11, doubleArray13);
        java.lang.Object[] objArray15 = org.apache.commons.math.exception.util.ArgUtils.flatten((java.lang.Object[]) doubleArray13);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException16 = new org.apache.commons.math.exception.NullArgumentException(localizable0, objArray15);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext17 = nullArgumentException16.getContext();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 90.0d + "'", double12 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(exceptionContext17);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test006");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) (-3.831008000716671E22d), 0, orderDirection3, true);
        int int6 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.SCALE;
        java.lang.Object[] objArray9 = null;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException10 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray9);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException19 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, (java.lang.Number) 1731268350, (java.lang.Number) (-1L), false);
        java.lang.Number number20 = numberIsTooLargeException19.getArgument();
        boolean boolean21 = numberIsTooLargeException19.getBoundIsAllowed();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 10, 10L };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException28 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats23, (java.lang.Number) 1731268350, objArray27);
        java.lang.Object[] objArray29 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray27);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException30 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooLargeException19, (org.apache.commons.math.exception.util.Localizable) localizedFormats22, objArray29);
        org.apache.commons.math.exception.NoBracketingException noBracketingException31 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (-0.6321205588285577d), 0.0d, (double) 209568959, (double) 1.0000001f, objArray29);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        java.lang.Number number34 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats33, number34, (java.lang.Number) 10L, true);
        java.lang.Object[] objArray42 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException43 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats33, (double) ' ', 1.0d, 0.6321206780378472d, 21.965267307681675d, objArray42);
        java.lang.Object[] objArray44 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray42);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats8, (org.apache.commons.math.exception.util.Localizable) localizedFormats32, objArray42);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException46 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) nonMonotonousSequenceException5, (org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray42);
        boolean boolean47 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SCALE + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 1731268350 + "'", number20.equals(1731268350));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT + "'", localizedFormats32.equals(org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT));
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats33.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test007");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(Double.NEGATIVE_INFINITY, (double) (short) 100);
        double double3 = regulaFalsiSolver2.getMin();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        try {
            double double7 = regulaFalsiSolver2.solve(1077936128, univariateRealFunction5, 0.44519637046557664d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test008");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException(1, (int) (short) 100);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test009");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test010");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 11);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999994421064d + "'", double1 == 0.9999999994421064d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test011");
        org.apache.commons.math.util.MathUtils.checkFinite((double) 70L);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test012");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NULL_NOT_ALLOWED;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NULL_NOT_ALLOWED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NULL_NOT_ALLOWED));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test013");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(2.2250738585072014E-308d, (double) 'a');
        double double3 = regulaFalsiSolver2.getFunctionValueAccuracy();
        double double4 = regulaFalsiSolver2.getMax();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test014");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence((double) 19206.0f, (double) 39916800L, (double) 1024);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test015");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (double) 7766279631452241919L, 3.462536700000001E9d, 5.916080105500369d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test016");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-554520870));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0509866131424377d + "'", double1 == 0.0509866131424377d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test017");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test018");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(100.0d);
        double double2 = regulaFalsiSolver1.getAbsoluteAccuracy();
        double double3 = regulaFalsiSolver1.getRelativeAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction9 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver11 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(100.0d);
        double double12 = regulaFalsiSolver11.getStartValue();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution16 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double17 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) '4', univariateRealFunction9, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver11, (double) 100, 1097.0d, (double) 10L, allowedSolution16);
        try {
            double double18 = regulaFalsiSolver1.solve((-1998348287), univariateRealFunction5, 53.46937508619497d, 10.27975705894653d, allowedSolution16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-14d + "'", double3 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + allowedSolution16 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution16.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 100.0d + "'", double17 == 100.0d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test019");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 90.0d, (double) 362819936404418211L, (double) 7766279629720978769L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test020");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((-1.7716215698884212E40d));
        int int2 = regulaFalsiSolver1.getEvaluations();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        try {
            double double8 = regulaFalsiSolver1.solve(129, univariateRealFunction4, 138.8527908288184d, (double) 52L, (-1.0d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test021");
        float float2 = org.apache.commons.math.util.FastMath.copySign((float) 1, 2048.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test022");
        long long2 = org.apache.commons.math.util.FastMath.max(1077936128L, (long) 1077936128);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1077936128L + "'", long2 == 1077936128L);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test023");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 35, 19043951850L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test024");
        float float1 = org.apache.commons.math.util.FastMath.ulp(435897.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.03125f + "'", float1 == 0.03125f);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test025");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 567829369856L, (float) ' ');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test026");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 100, 61);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test027");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 1731268351, 52.0f, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test028");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 1024, (-7766279629720978759L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1024L + "'", long2 == 1024L);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test029");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 1.1920928244535446E-7d, 110.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test030");
        long long1 = org.apache.commons.math.util.FastMath.abs((-1L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test031");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount((int) '4');
        incrementor0.incrementCount(37);
        int int5 = incrementor0.getMaximalCount();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test032");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(20.798314057214018d, (double) (-1024L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 20.798314057214014d + "'", double2 == 20.798314057214014d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test033");
        float float3 = org.apache.commons.math.util.MathUtils.round(2.1464352E9f, 993337088, 6);
        org.junit.Assert.assertEquals((float) float3, Float.NaN, 0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test034");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(1.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test035");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 4024981426555L, 1.6929693744344998d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.018139895679306513d + "'", double2 == 0.018139895679306513d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test036");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((int) '#', 1731263104);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test037");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence(1.1697541313627178d, 41608.51295107769d, (double) (-2026769706));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [41,608.513, -2,026,769,706]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test038");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((-1998347587), (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1998347587 + "'", int2 == 1998347587);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test039");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.8423320834271332d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.014701468250987035d + "'", double1 == 0.014701468250987035d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test040");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence(0.8751688612297938d, (-1.7182818284590458d), (double) 2026769706);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test041");
        float float2 = org.apache.commons.math.util.FastMath.copySign(16384.0f, (float) (short) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 16384.0f + "'", float2 == 16384.0f);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test042");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 7766279631452241920L, (java.lang.Number) 1.1102230246251565E-16d, (int) '4', orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-15.942385152878742d), (java.lang.Number) 0.9999999994421064d, (int) (short) -1, orderDirection6, false);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test043");
        double[] doubleArray3 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray10 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        double[][] doubleArray12 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray10, doubleArray12);
        double[] doubleArray17 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray24 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray24);
        double[][] doubleArray26 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray24, doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray24);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray10);
        double[] doubleArray33 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray40 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double41 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray33, doubleArray40);
        double[][] doubleArray42 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray40, doubleArray42);
        double[] doubleArray47 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray54 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray47, doubleArray54);
        double[][] doubleArray56 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray54, doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray54);
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray40);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray59);
        double double61 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray10, doubleArray59);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, 100.0d);
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray63, (int) (short) 10);
        double[] doubleArray67 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray65, 36917.9834805808d);
        double[] doubleArray68 = new double[] {};
        double[] doubleArray69 = new double[] {};
        double[] doubleArray70 = new double[] {};
        double[] doubleArray71 = new double[] {};
        double[][] doubleArray72 = new double[][] { doubleArray68, doubleArray69, doubleArray70, doubleArray71 };
        try {
            org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray67, doubleArray72);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 10");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 90.0d + "'", double25 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 90.0d + "'", double41 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 90.0d + "'", double55 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 1126.0d + "'", double61 == 1126.0d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test044");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-1014), (-5531328L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5608766592L + "'", long2 == 5608766592L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test045");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 70, (double) (-1.0f));
        double double3 = regulaFalsiSolver2.getAbsoluteAccuracy();
        double double4 = regulaFalsiSolver2.getStartValue();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test046");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.5403023058681395d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test047");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 10, 10L };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException7 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) 1731268350, objArray6);
        org.apache.commons.math.exception.MathInternalError mathInternalError8 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) maxCountExceededException7);
        java.lang.Throwable[] throwableArray9 = maxCountExceededException7.getSuppressed();
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException10 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) throwableArray9);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray9);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(throwableArray9);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test048");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 'a', (byte) 10 };
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (-1.0f), (org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray9);
        org.apache.commons.math.exception.NoBracketingException noBracketingException11 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 2.302585092994046d, 0.0d, 0.8862395404791882d, (double) 10, objArray9);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS;
        double[] doubleArray16 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray23 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double24 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray16, doubleArray23);
        double[][] doubleArray25 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray23, doubleArray25);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException27 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) noBracketingException11, (org.apache.commons.math.exception.util.Localizable) localizedFormats12, (java.lang.Object[]) doubleArray25);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE;
        java.lang.Object[] objArray32 = new java.lang.Object[] { 10, 10L };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException33 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats28, (java.lang.Number) 1731268350, objArray32);
        org.apache.commons.math.exception.MathInternalError mathInternalError34 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) maxCountExceededException33);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext35 = mathInternalError34.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext36 = mathInternalError34.getContext();
        noBracketingException11.addSuppressed((java.lang.Throwable) mathInternalError34);
        double double38 = noBracketingException11.getFLo();
        double double39 = noBracketingException11.getLo();
        double double40 = noBracketingException11.getLo();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext41 = noBracketingException11.getContext();
        java.util.Set<java.lang.String> strSet42 = exceptionContext41.getKeys();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 90.0d + "'", double24 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE + "'", localizedFormats28.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(exceptionContext35);
        org.junit.Assert.assertNotNull(exceptionContext36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.8862395404791882d + "'", double38 == 0.8862395404791882d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 2.302585092994046d + "'", double39 == 2.302585092994046d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 2.302585092994046d + "'", double40 == 2.302585092994046d);
        org.junit.Assert.assertNotNull(exceptionContext41);
        org.junit.Assert.assertNotNull(strSet42);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test049");
        float float2 = org.apache.commons.math.util.FastMath.copySign(1.5258789E-5f, (float) 5210L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.5258789E-5f + "'", float2 == 1.5258789E-5f);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test050");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 7766279631452241919L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 7766279631452241920L + "'", long1 == 7766279631452241920L);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test051");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.LENGTH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH;
        java.lang.Object[] objArray7 = new java.lang.Object[] { localizedFormats1, localizedFormats2, 100.0d, 100, localizedFormats5, localizedFormats6 };
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException8 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray7);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext9 = mathArithmeticException8.getContext();
        java.util.Set<java.lang.String> strSet10 = exceptionContext9.getKeys();
        java.lang.Object obj12 = exceptionContext9.getValue("hi!");
        java.lang.Object obj14 = exceptionContext9.getValue("");
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LENGTH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.LENGTH));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(exceptionContext9);
        org.junit.Assert.assertNotNull(strSet10);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertNull(obj14);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test052");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-35L), (java.lang.Number) 97.00001f, false);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test053");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-288.0f), (double) 128L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test054");
        float float1 = org.apache.commons.math.util.FastMath.abs(97.00001f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 97.00001f + "'", float1 == 97.00001f);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test055");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1731263151L, number1, false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test056");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.3502552191163302d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.21875765670988073d + "'", double1 == 0.21875765670988073d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test057");
        double double2 = org.apache.commons.math.util.FastMath.copySign((double) (-7.7662789E18f), (double) 567829369856L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.7662788867609068E18d + "'", double2 == 7.7662788867609068E18d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test058");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1731268350, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1731268350) + "'", int2 == (-1731268350));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test059");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 1998347587, (float) 257862796);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test060");
        long long2 = org.apache.commons.math.util.MathUtils.pow(198L, 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-8570350090886053888L) + "'", long2 == (-8570350090886053888L));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test061");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination(1.0E-14d, (double) (-10), (-3.831008000716671E22d), (double) 7.7662794E18f, 0.004425697988050785d, (double) 7.6293945E-6f, (-57.29577951308232d), (-0.7187963764108645d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-2.9752678657096915E41d) + "'", double8 == (-2.9752678657096915E41d));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test062");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 1.5707963257268107d, 36917.983480580806d, 1.0d, 1731268341);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test063");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, 0.5908569980761279d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test064");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 1.100747554766916d);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext2 = tooManyEvaluationsException1.getContext();
        org.junit.Assert.assertNotNull(exceptionContext2);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test065");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination(104.94810050620777d, (-0.7187963764108645d), (-6.923689900271567d), 100.4987562112089d, (double) 7.6293945E-6f, (double) 7766279631452241920L, (double) 1.07793613E9f, 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 5.935980496038874E13d + "'", double8 == 5.935980496038874E13d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test066");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) 2.302585092994046d, false);
        org.apache.commons.math.exception.MathInternalError mathInternalError4 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) numberIsTooSmallException3);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 'a', (byte) 10 };
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (-1.0f), (org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray10);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException12 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException3, (org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray10);
        java.lang.Number number13 = numberIsTooSmallException3.getMin();
        boolean boolean14 = numberIsTooSmallException3.getBoundIsAllowed();
        boolean boolean15 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 2.302585092994046d + "'", number13.equals(2.302585092994046d));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test067");
        float[] floatArray4 = new float[] { 7766279631452241920L, 'a', 0, 1.0000001f };
        float[] floatArray8 = new float[] { 10.0f, (-1.0f), 100 };
        float[] floatArray9 = null;
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(floatArray8, floatArray9);
        float[] floatArray12 = new float[] { 100.0f };
        float[] floatArray13 = null;
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(floatArray12, floatArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray8, floatArray12);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(floatArray4, floatArray8);
        float[] floatArray20 = new float[] { 10.0f, (-1.0f), 100 };
        float[] floatArray21 = null;
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(floatArray20, floatArray21);
        float[] floatArray24 = new float[] { 100.0f };
        float[] floatArray25 = null;
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(floatArray24, floatArray25);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray20, floatArray24);
        float[] floatArray32 = new float[] { 7766279631452241920L, 'a', 0, 1.0000001f };
        float[] floatArray36 = new float[] { 10.0f, (-1.0f), 100 };
        float[] floatArray37 = null;
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(floatArray36, floatArray37);
        float[] floatArray40 = new float[] { 100.0f };
        float[] floatArray41 = null;
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(floatArray40, floatArray41);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray36, floatArray40);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(floatArray32, floatArray36);
        float[] floatArray49 = new float[] { 7766279631452241920L, 'a', 0, 1.0000001f };
        float[] floatArray53 = new float[] { 10.0f, (-1.0f), 100 };
        float[] floatArray54 = null;
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equals(floatArray53, floatArray54);
        float[] floatArray57 = new float[] { 100.0f };
        float[] floatArray58 = null;
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(floatArray57, floatArray58);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray53, floatArray57);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(floatArray49, floatArray53);
        float[] floatArray66 = new float[] { 7766279631452241920L, 'a', 0, 1.0000001f };
        float[] floatArray70 = new float[] { 10.0f, (-1.0f), 100 };
        float[] floatArray71 = null;
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equals(floatArray70, floatArray71);
        float[] floatArray74 = new float[] { 100.0f };
        float[] floatArray75 = null;
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equals(floatArray74, floatArray75);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray70, floatArray74);
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equals(floatArray66, floatArray70);
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equals(floatArray49, floatArray70);
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray32, floatArray49);
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equals(floatArray20, floatArray49);
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equals(floatArray4, floatArray49);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(floatArray49);
        org.junit.Assert.assertNotNull(floatArray53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(floatArray57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(floatArray66);
        org.junit.Assert.assertNotNull(floatArray70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(floatArray74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test068");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.602567035097998d, number2, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test069");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination(0.0d, (-2.1987108057699997E11d), 599.149787360389d, 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test070");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-1023), 29.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test071");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((-13.018470045191767d), (double) 1.9073486E-6f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.45209943083259496d) + "'", double2 == (-0.45209943083259496d));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test072");
        float float2 = org.apache.commons.math.util.FastMath.copySign((float) (-1), 97.00001f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test073");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.557437075253452d, (java.lang.Number) 1.0861557509700144d, false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test074");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 18, (-1731268350));
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test075");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 1024, 117875096261L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-117875095237L) + "'", long2 == (-117875095237L));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test076");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-11L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test077");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, (double) 2305258549L, 0.018139895679306513d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test078");
        int[] intArray1 = new int[] { (byte) 100 };
        int[] intArray5 = new int[] { (byte) 0, (byte) -1, 100 };
        int[] intArray6 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        double double7 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray5);
        int[] intArray11 = new int[] { (byte) 0, (byte) -1, 100 };
        int[] intArray12 = org.apache.commons.math.util.MathUtils.copyOf(intArray11);
        double double13 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray11);
        int[] intArray15 = org.apache.commons.math.util.MathUtils.copyOf(intArray5, 10);
        int[] intArray16 = org.apache.commons.math.util.MathUtils.copyOf(intArray15);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test079");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-127));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.991989996645917E-56d + "'", double1 == 6.991989996645917E-56d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test080");
        double[] doubleArray6 = new double[] { (byte) 10, 100.0d, 105.94810050208545d, (short) -1, 0.0d, 1L };
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray12 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray19 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double20 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray19);
        double[][] doubleArray21 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray19, doubleArray21);
        double[] doubleArray26 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray33 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double34 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray26, doubleArray33);
        double[][] doubleArray35 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray33, doubleArray35);
        double[] doubleArray40 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray47 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double48 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray40, doubleArray47);
        double[][] doubleArray49 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray47, doubleArray49);
        double double51 = org.apache.commons.math.util.MathUtils.distance1(doubleArray33, doubleArray47);
        double double52 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray47);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection53 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[] doubleArray57 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray64 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double65 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray57, doubleArray64);
        double[][] doubleArray66 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray64, doubleArray66);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray47, orderDirection53, doubleArray66);
        double double69 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray47);
        double[] doubleArray70 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray47);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1731268350 + "'", int7 == 1731268350);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1731268350 + "'", int8 == 1731268350);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 90.0d + "'", double20 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 90.0d + "'", double34 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 90.0d + "'", double48 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection53 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection53.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 90.0d + "'", double65 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 104.94810050208545d + "'", double69 == 104.94810050208545d);
        org.junit.Assert.assertNotNull(doubleArray70);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test081");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1071382528, 343666689);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test082");
        double double1 = org.apache.commons.math.util.FastMath.expm1(35.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5860134523134298E15d + "'", double1 == 1.5860134523134298E15d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test083");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 10.0f, (-1.57079608419819d));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test084");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test085");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-7766279629720978759L));
        int int2 = regulaFalsiSolver1.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test086");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Number) 1731268350, (java.lang.Number) (-1L), false);
        java.lang.Throwable[] throwableArray10 = numberIsTooLargeException9.getSuppressed();
        org.apache.commons.math.exception.NoBracketingException noBracketingException11 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) 52L, 0.5188787072485352d, (double) (-10), (double) 10, (java.lang.Object[]) throwableArray10);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException12 = new org.apache.commons.math.exception.MathArithmeticException();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext13 = mathArithmeticException12.getContext();
        noBracketingException11.addSuppressed((java.lang.Throwable) mathArithmeticException12);
        double double15 = noBracketingException11.getFLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(exceptionContext13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-10.0d) + "'", double15 == (-10.0d));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test087");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double1 = regulaFalsiSolver0.getFunctionValueAccuracy();
        double double2 = regulaFalsiSolver0.getMin();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-15d + "'", double1 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test088");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.8862395404791882d, (java.lang.Number) 0.0d, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-21.706844140603472d), (java.lang.Number) 100.0d, false);
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException11 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (int) (short) -1, 1998348287);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test089");
        double double1 = org.apache.commons.math.util.FastMath.acos((-6.923689900271567d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test090");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(11013.232920103324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 192.21717574483262d + "'", double1 == 192.21717574483262d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test091");
        int[] intArray1 = new int[] { (byte) 100 };
        int[] intArray5 = new int[] { (byte) 0, (byte) -1, 100 };
        int[] intArray6 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        double double7 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray5);
        int[] intArray11 = new int[] { (byte) 0, (byte) -1, 100 };
        int[] intArray12 = org.apache.commons.math.util.MathUtils.copyOf(intArray11);
        double double13 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray11);
        int[] intArray14 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        int[] intArray15 = org.apache.commons.math.util.MathUtils.copyOf(intArray14);
        int[] intArray17 = new int[] { (byte) 100 };
        int[] intArray21 = new int[] { (byte) 0, (byte) -1, 100 };
        int[] intArray22 = org.apache.commons.math.util.MathUtils.copyOf(intArray21);
        double double23 = org.apache.commons.math.util.MathUtils.distance(intArray17, intArray21);
        int[] intArray27 = new int[] { (byte) 0, (byte) -1, 100 };
        int[] intArray28 = org.apache.commons.math.util.MathUtils.copyOf(intArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray21, intArray27);
        int[] intArray30 = org.apache.commons.math.util.MathUtils.copyOf(intArray27);
        double double31 = org.apache.commons.math.util.MathUtils.distance(intArray14, intArray30);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 100.0d + "'", double23 == 100.0d);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test092");
        int[] intArray3 = new int[] { (byte) 0, (byte) -1, 100 };
        int[] intArray4 = org.apache.commons.math.util.MathUtils.copyOf(intArray3);
        int[] intArray8 = new int[] { (byte) 0, (byte) -1, 100 };
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray8);
        int[] intArray10 = org.apache.commons.math.util.MathUtils.copyOf(intArray9);
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray10);
        int[] intArray13 = new int[] { (byte) 100 };
        int[] intArray17 = new int[] { (byte) 0, (byte) -1, 100 };
        int[] intArray18 = org.apache.commons.math.util.MathUtils.copyOf(intArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray17);
        int[] intArray23 = new int[] { (byte) 0, (byte) -1, 100 };
        int[] intArray24 = org.apache.commons.math.util.MathUtils.copyOf(intArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distance(intArray17, intArray23);
        int[] intArray26 = org.apache.commons.math.util.MathUtils.copyOf(intArray17);
        int[] intArray27 = org.apache.commons.math.util.MathUtils.copyOf(intArray26);
        int[] intArray29 = new int[] { (byte) 100 };
        int[] intArray33 = new int[] { (byte) 0, (byte) -1, 100 };
        int[] intArray34 = org.apache.commons.math.util.MathUtils.copyOf(intArray33);
        double double35 = org.apache.commons.math.util.MathUtils.distance(intArray29, intArray33);
        int[] intArray39 = new int[] { (byte) 0, (byte) -1, 100 };
        int[] intArray40 = org.apache.commons.math.util.MathUtils.copyOf(intArray39);
        double double41 = org.apache.commons.math.util.MathUtils.distance(intArray33, intArray39);
        int[] intArray42 = org.apache.commons.math.util.MathUtils.copyOf(intArray33);
        int[] intArray43 = org.apache.commons.math.util.MathUtils.copyOf(intArray42);
        int[] intArray45 = org.apache.commons.math.util.MathUtils.copyOf(intArray43, 99);
        double double46 = org.apache.commons.math.util.MathUtils.distance(intArray27, intArray43);
        double double47 = org.apache.commons.math.util.MathUtils.distance(intArray10, intArray43);
        int[] intArray51 = new int[] { (byte) 0, (byte) -1, 100 };
        int[] intArray52 = org.apache.commons.math.util.MathUtils.copyOf(intArray51);
        int[] intArray56 = new int[] { (byte) 0, (byte) -1, 100 };
        int[] intArray57 = org.apache.commons.math.util.MathUtils.copyOf(intArray56);
        int[] intArray58 = org.apache.commons.math.util.MathUtils.copyOf(intArray57);
        double double59 = org.apache.commons.math.util.MathUtils.distance(intArray51, intArray58);
        int[] intArray61 = org.apache.commons.math.util.MathUtils.copyOf(intArray58, 1);
        try {
            int int62 = org.apache.commons.math.util.MathUtils.distance1(intArray43, intArray61);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 100.0d + "'", double19 == 100.0d);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 100.0d + "'", double35 == 100.0d);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(intArray61);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test093");
        double[] doubleArray3 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray10 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 10000000000L);
        double[] doubleArray20 = new double[] { (byte) 10, 100.0d, 105.94810050208545d, (short) -1, 0.0d, 1L };
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray20);
        double double24 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray20);
        double[] doubleArray31 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray38 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double39 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray31, doubleArray38);
        double[][] doubleArray40 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray38, doubleArray40);
        double[] doubleArray45 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray52 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double53 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray45, doubleArray52);
        double[][] doubleArray54 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray52, doubleArray54);
        double[] doubleArray59 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray66 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double67 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray59, doubleArray66);
        double[][] doubleArray68 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray66, doubleArray68);
        double double70 = org.apache.commons.math.util.MathUtils.distance1(doubleArray52, doubleArray66);
        double double71 = org.apache.commons.math.util.MathUtils.distance(doubleArray38, doubleArray66);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection72 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[] doubleArray76 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray83 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double84 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray76, doubleArray83);
        double[][] doubleArray85 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray83, doubleArray85);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray66, orderDirection72, doubleArray85);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection88 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        boolean boolean91 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray66, orderDirection88, false, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException93 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5370263527767281E31d, (java.lang.Number) 213431353344L, 1071382528, orderDirection88, true);
        try {
            boolean boolean96 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection88, false, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not decreasing (10 < 100)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1731268350 + "'", int21 == 1731268350);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1731268350 + "'", int22 == 1731268350);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 104.94810050620777d + "'", double24 == 104.94810050620777d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 90.0d + "'", double39 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 90.0d + "'", double53 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 90.0d + "'", double67 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection72 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection72.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 90.0d + "'", double84 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + orderDirection88 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection88.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test094");
        long long2 = org.apache.commons.math.util.MathUtils.pow(98L, 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3894783031000432640L + "'", long2 == 3894783031000432640L);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test095");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.027415567780803774d + "'", double1 == 0.027415567780803774d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test096");
        double[] doubleArray3 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray10 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        double[][] doubleArray12 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray10, doubleArray12);
        double[] doubleArray17 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray24 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray24);
        double[][] doubleArray26 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray24, doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray24);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray10);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 90.0d + "'", double25 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-209568959) + "'", int30 == (-209568959));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test097");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED;
        java.lang.Object[] objArray16 = new java.lang.Object[] { 'a', (byte) 10 };
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (-1.0f), (org.apache.commons.math.exception.util.Localizable) localizedFormats13, objArray16);
        org.apache.commons.math.exception.NoBracketingException noBracketingException18 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, 2.302585092994046d, 0.0d, 0.8862395404791882d, (double) 10, objArray16);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS;
        double[] doubleArray23 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray30 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double31 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray23, doubleArray30);
        double[][] doubleArray32 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray30, doubleArray32);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException34 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) noBracketingException18, (org.apache.commons.math.exception.util.Localizable) localizedFormats19, (java.lang.Object[]) doubleArray32);
        java.lang.Throwable[] throwableArray35 = noBracketingException18.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Object[]) throwableArray35);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats37 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math.exception.util.LocalizedFormats.LENGTH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats39 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats40 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats43 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats44 = org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH;
        java.lang.Object[] objArray45 = new java.lang.Object[] { localizedFormats39, localizedFormats40, 100.0d, 100, localizedFormats43, localizedFormats44 };
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException46 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats38, objArray45);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException47 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats37, objArray45);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException48 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray45);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException49 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) (-2.0d), objArray45);
        org.apache.commons.math.exception.NoBracketingException noBracketingException50 = new org.apache.commons.math.exception.NoBracketingException(localizable0, 53.46937508619497d, (double) 0.0f, 0.0d, 0.0d, objArray45);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS));
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 90.0d + "'", double31 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertTrue("'" + localizedFormats37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM + "'", localizedFormats37.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM));
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LENGTH + "'", localizedFormats38.equals(org.apache.commons.math.exception.util.LocalizedFormats.LENGTH));
        org.junit.Assert.assertTrue("'" + localizedFormats39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE + "'", localizedFormats39.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE));
        org.junit.Assert.assertTrue("'" + localizedFormats40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats40.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE + "'", localizedFormats43.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH + "'", localizedFormats44.equals(org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH));
        org.junit.Assert.assertNotNull(objArray45);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test098");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination((-13.018470045191767d), (double) (-32), (double) 1.07793613E9f, (-28.0d), 0.0d, (double) 19206, (double) Float.NEGATIVE_INFINITY, 11013.232920103324d);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test099");
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException0 = new org.apache.commons.math.exception.MathArithmeticException();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext1 = mathArithmeticException0.getContext();
        java.util.Set<java.lang.String> strSet2 = exceptionContext1.getKeys();
        org.junit.Assert.assertNotNull(exceptionContext1);
        org.junit.Assert.assertNotNull(strSet2);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test100");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver4 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(Double.NEGATIVE_INFINITY, (double) (short) 100);
        double double5 = regulaFalsiSolver4.getMin();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction10 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver12 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(100.0d);
        double double13 = regulaFalsiSolver12.getStartValue();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution17 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double18 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) '4', univariateRealFunction10, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver12, (double) 100, 1097.0d, (double) 10L, allowedSolution17);
        double double19 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(1455423489, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver4, 19206.0d, 268.0d, 3.4366668799999994E8d, allowedSolution17);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + allowedSolution17 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution17.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 100.0d + "'", double18 == 100.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 19206.0d + "'", double19 == 19206.0d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test101");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-1.73126835E9f), 64.0f, (-1998347587));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test102");
        double double2 = org.apache.commons.math.util.MathUtils.log(52.0d, (double) 129);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2299449870701566d + "'", double2 == 1.2299449870701566d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test103");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-2.0d), (java.lang.Number) 257862796L, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test104");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination(3.948148009134034E13d, 7.7662794365167206E18d, (double) (-993337088L), 1.427957018610231E93d, 0.8683757821044538d, (double) (short) 10);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.4184426666554486E102d) + "'", double6 == (-1.4184426666554486E102d));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test105");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.9073486328125E-6d, 1.5707963238851002d, 161700.00000000003d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test106");
        double[] doubleArray3 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray10 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        double[][] doubleArray12 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray10, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray10, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray10);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray10, 9);
        double[] doubleArray22 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray29 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray22, doubleArray29);
        double[][] doubleArray31 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray29, doubleArray31);
        double[] doubleArray36 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray43 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double44 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray36, doubleArray43);
        double[][] doubleArray45 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray43, doubleArray45);
        double double47 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray43);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray29);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray48);
        double[] doubleArray53 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray60 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double61 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray53, doubleArray60);
        double[][] doubleArray62 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray60, doubleArray62);
        double[] doubleArray67 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray74 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double75 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray67, doubleArray74);
        double[][] doubleArray76 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray74, doubleArray76);
        double double78 = org.apache.commons.math.util.MathUtils.distance1(doubleArray60, doubleArray74);
        double[] doubleArray79 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray60);
        double[] doubleArray80 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray79);
        double[] doubleArray82 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray80, (double) 98L);
        double double83 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray48, doubleArray80);
        try {
            double double84 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray18, doubleArray48);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 9 != 6");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 90.0d + "'", double30 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 90.0d + "'", double44 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 90.0d + "'", double61 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 90.0d + "'", double75 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 1126.0d + "'", double83 == 1126.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test107");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SCALE;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException2 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, (java.lang.Number) 1731268350, (java.lang.Number) (-1L), false);
        java.lang.Number number12 = numberIsTooLargeException11.getArgument();
        boolean boolean13 = numberIsTooLargeException11.getBoundIsAllowed();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE;
        java.lang.Object[] objArray19 = new java.lang.Object[] { 10, 10L };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException20 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, (java.lang.Number) 1731268350, objArray19);
        java.lang.Object[] objArray21 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray19);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException22 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooLargeException11, (org.apache.commons.math.exception.util.Localizable) localizedFormats14, objArray21);
        org.apache.commons.math.exception.NoBracketingException noBracketingException23 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (-0.6321205588285577d), 0.0d, (double) 209568959, (double) 1.0000001f, objArray21);
        double double24 = noBracketingException23.getFLo();
        double double25 = noBracketingException23.getFLo();
        double double26 = noBracketingException23.getLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SCALE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 1731268350 + "'", number12.equals(1731268350));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 2.09568959E8d + "'", double24 == 2.09568959E8d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 2.09568959E8d + "'", double25 == 2.09568959E8d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + (-0.6321205588285577d) + "'", double26 == (-0.6321205588285577d));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test108");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test109");
        double double3 = org.apache.commons.math.util.MathUtils.reduce((double) (short) 1, (double) (-117875095237L), (double) 30);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.17875095208E11d + "'", double3 == 1.17875095208E11d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test110");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 1.8184464592320668d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test111");
        int int1 = org.apache.commons.math.util.FastMath.round((-7.920808E19f));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2147483648) + "'", int1 == (-2147483648));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test112");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, (java.lang.Number) 1731268350, (java.lang.Number) (-1L), false);
        java.lang.Throwable[] throwableArray15 = numberIsTooLargeException14.getSuppressed();
        org.apache.commons.math.exception.NoBracketingException noBracketingException16 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (double) 52L, 0.5188787072485352d, (double) (-10), (double) 10, (java.lang.Object[]) throwableArray15);
        org.apache.commons.math.exception.NoBracketingException noBracketingException17 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) 1.0000001f, 100.0d, 1.5430806348152437d, (double) 70.0f, (java.lang.Object[]) throwableArray15);
        java.lang.String str18 = noBracketingException17.toString();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.FRACTION;
        org.apache.commons.math.exception.NotPositiveException notPositiveException21 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats19, (java.lang.Number) 1.1102230246251565E-16d);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException28 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats24, (java.lang.Number) 1731268350, (java.lang.Number) (-1L), false);
        java.lang.Throwable[] throwableArray29 = numberIsTooLargeException28.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats23, (java.lang.Object[]) throwableArray29);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException31 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 1.1752011936438014d, (java.lang.Object[]) throwableArray29);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_CONSIDER_PADDING;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats41 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED;
        java.lang.Object[] objArray44 = new java.lang.Object[] { 'a', (byte) 10 };
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (-1.0f), (org.apache.commons.math.exception.util.Localizable) localizedFormats41, objArray44);
        org.apache.commons.math.exception.NoBracketingException noBracketingException46 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats35, 2.302585092994046d, 0.0d, 0.8862395404791882d, (double) 10, objArray44);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats47 = org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS;
        double[] doubleArray51 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray58 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double59 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray51, doubleArray58);
        double[][] doubleArray60 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray58, doubleArray60);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException62 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) noBracketingException46, (org.apache.commons.math.exception.util.Localizable) localizedFormats47, (java.lang.Object[]) doubleArray60);
        java.lang.Throwable[] throwableArray63 = noBracketingException46.getSuppressed();
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException64 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats33, (java.lang.Number) 1.0f, (java.lang.Object[]) throwableArray63);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException65 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) notFiniteNumberException31, (org.apache.commons.math.exception.util.Localizable) localizedFormats32, (java.lang.Object[]) throwableArray63);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats66 = org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE;
        java.lang.Object[] objArray70 = new java.lang.Object[] { 10, 10L };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException71 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats66, (java.lang.Number) 1731268350, objArray70);
        java.lang.Object[] objArray72 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray70);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException73 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats32, objArray72);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException74 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) noBracketingException17, (org.apache.commons.math.exception.util.Localizable) localizedFormats19, objArray72);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.apache.commons.math.exception.NoBracketingException: 1 wide hole between models time ranges" + "'", str18.equals("org.apache.commons.math.exception.NoBracketingException: 1 wide hole between models time ranges"));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FRACTION + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS + "'", localizedFormats32.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS));
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_CONSIDER_PADDING + "'", localizedFormats33.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_CONSIDER_PADDING));
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats35.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED + "'", localizedFormats41.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertTrue("'" + localizedFormats47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS + "'", localizedFormats47.equals(org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS));
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 90.0d + "'", double59 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(throwableArray63);
        org.junit.Assert.assertTrue("'" + localizedFormats66 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE + "'", localizedFormats66.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE));
        org.junit.Assert.assertNotNull(objArray70);
        org.junit.Assert.assertNotNull(objArray72);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test113");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 1731263114L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.423848867416382d + "'", double2 == 2.423848867416382d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test114");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(2.9802322387695312E-8d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction3 = null;
        try {
            double double5 = regulaFalsiSolver1.solve(0, univariateRealFunction3, 0.01895699404389834d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test115");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.0001796891927d, 1.1495489051661059d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test116");
        double double1 = org.apache.commons.math.util.FastMath.atanh(343329.4281896033d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test117");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.1920929E-7f), (java.lang.Number) 0.5188787072485352d, 52);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.5188787072485352d + "'", number4.equals(0.5188787072485352d));
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test118");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3L, number1, (int) (byte) 10);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test119");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Number) 1731268350, (java.lang.Number) (-1L), false);
        java.lang.Throwable[] throwableArray10 = numberIsTooLargeException9.getSuppressed();
        org.apache.commons.math.exception.NoBracketingException noBracketingException11 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) 52L, 0.5188787072485352d, (double) (-10), (double) 10, (java.lang.Object[]) throwableArray10);
        double double12 = noBracketingException11.getHi();
        double double13 = noBracketingException11.getFLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.5188787072485352d + "'", double12 == 0.5188787072485352d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-10.0d) + "'", double13 == (-10.0d));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test120");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(0L, 343666897L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 343666897L + "'", long2 == 343666897L);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test121");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 1731268350, (java.lang.Number) (-1L), false);
        java.lang.Number number6 = numberIsTooLargeException5.getMax();
        org.apache.commons.math.exception.MathInternalError mathInternalError7 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) numberIsTooLargeException5);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.LENGTH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH;
        java.lang.Object[] objArray17 = new java.lang.Object[] { localizedFormats11, localizedFormats12, 100.0d, 100, localizedFormats15, localizedFormats16 };
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException18 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray17);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException19 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, objArray17);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException20 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray17);
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException23 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (int) '#', 35);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.TRUST_REGION_STEP_FAILED;
        java.lang.String str25 = localizedFormats24.getSourceString();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED;
        java.lang.Object[] objArray35 = new java.lang.Object[] { 'a', (byte) 10 };
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (-1.0f), (org.apache.commons.math.exception.util.Localizable) localizedFormats32, objArray35);
        org.apache.commons.math.exception.NoBracketingException noBracketingException37 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats26, 2.302585092994046d, 0.0d, 0.8862395404791882d, (double) 10, objArray35);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS;
        double[] doubleArray42 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray49 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double50 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray42, doubleArray49);
        double[][] doubleArray51 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray49, doubleArray51);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException53 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) noBracketingException37, (org.apache.commons.math.exception.util.Localizable) localizedFormats38, (java.lang.Object[]) doubleArray51);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException54 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats24, (java.lang.Object[]) doubleArray51);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException55 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooLargeException5, (org.apache.commons.math.exception.util.Localizable) localizedFormats8, (java.lang.Object[]) doubleArray51);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) doubleArray51);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1L) + "'", number6.equals((-1L)));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LENGTH + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.LENGTH));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TRUST_REGION_STEP_FAILED + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.TRUST_REGION_STEP_FAILED));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "trust region step has failed to reduce Q" + "'", str25.equals("trust region step has failed to reduce Q"));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED + "'", localizedFormats32.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED));
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS + "'", localizedFormats38.equals(org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS));
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 90.0d + "'", double50 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray51);
    }
}

