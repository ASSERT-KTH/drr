import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (byte) 100);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        double double0 = org.apache.commons.math.util.MathUtils.SAFE_MIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.2250738585072014E-308d + "'", double0 == 2.2250738585072014E-308d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 198L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0798317705429828d + "'", double1 == 0.0798317705429828d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval(53.47872541589045d, Double.POSITIVE_INFINITY);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(267.70557299807183d, (-209568959), (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(0L, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) '#', 8.56806886553248E-6d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        int[] intArray3 = new int[] { (byte) 0, (byte) -1, 100 };
        int[] intArray4 = org.apache.commons.math.util.MathUtils.copyOf(intArray3);
        int[] intArray8 = new int[] { (byte) 0, (byte) -1, 100 };
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray8);
        int[] intArray10 = org.apache.commons.math.util.MathUtils.copyOf(intArray9);
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray10);
        int[] intArray12 = new int[] {};
        int[] intArray13 = null;
        int int14 = org.apache.commons.math.util.MathUtils.distanceInf(intArray12, intArray13);
        try {
            int int15 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.36787944117144233d + "'", double1 == 0.36787944117144233d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint((double) 10L, 267.70557299807183d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 138.85278649903591d + "'", double2 == 138.85278649903591d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CLEAR_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CLEAR_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CLEAR_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) 0, 70);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(3.4965075614664802d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction3 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution6 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        try {
            double double7 = regulaFalsiSolver1.solve(1077936128, univariateRealFunction3, 6.938893903907228E-18d, 8.56806886553248E-6d, allowedSolution6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + allowedSolution6 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution6.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.resetCount();
        int int2 = incrementor0.getCount();
        try {
            incrementor0.incrementCount((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) (byte) -1, (float) 10000000000L, (float) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-15.942385152878742d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SHAPE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SHAPE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SHAPE));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval((double) 97, (double) (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [97, -1]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) (byte) 100, 1.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(2.99822295029797d, (-57.29577951308232d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 11, (float) (-1), (float) 70);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        float[] floatArray3 = new float[] { 10.0f, (-1.0f), 100 };
        float[] floatArray4 = null;
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(floatArray3, floatArray4);
        float[] floatArray7 = new float[] { 100.0f };
        float[] floatArray8 = null;
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equals(floatArray7, floatArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray3, floatArray7);
        float[] floatArray11 = null;
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equals(floatArray7, floatArray11);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(2.99822295029797d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.049875621120892d + "'", double1 == 10.049875621120892d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double[] doubleArray3 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray10 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        double[][] doubleArray12 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray10, doubleArray12);
        double[] doubleArray17 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray24 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray24);
        double[][] doubleArray26 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray24, doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray24);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray10);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray29);
        double[] doubleArray31 = null;
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 90.0d + "'", double25 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        double double1 = org.apache.commons.math.util.FastMath.tan(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_REGRESSORS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_REGRESSORS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_REGRESSORS));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        double double1 = org.apache.commons.math.util.FastMath.cos((-1.2876178137472069E-19d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_MICROSPHERE_ELEMENTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_MICROSPHERE_ELEMENTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_MICROSPHERE_ELEMENTS));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (-1));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 1.077936E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.79831393939627d + "'", double1 == 20.79831393939627d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1), 70.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 10L, (double) (byte) 0, 97);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(198L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 198L + "'", long2 == 198L);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-10), (double) 98L, 70);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2.302585092994046d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        double double3 = org.apache.commons.math.util.MathUtils.reduce(1.503300998004841d, 1.201855897199358E19d, 0.004425697988050785d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.4988753000167903d + "'", double3 == 1.4988753000167903d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        double double3 = org.apache.commons.math.util.MathUtils.reduce((double) 10000000000L, 0.0d, 0.4451963704655766d);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        float float1 = org.apache.commons.math.util.MathUtils.indicator(3.8146973E-6f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 70.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence(1.8491431899952486d, 10.049875621120892d, (double) 100L);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1), (java.lang.Number) 2.302585092994046d, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 2.302585092994046d + "'", number4.equals(2.302585092994046d));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22026.465794806718d + "'", double1 == 22026.465794806718d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination((double) 97L, 0.6321206780378472d, 2.2250738585072014E-308d, 0.0d, (double) (-10), (double) 5200L);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-51938.68429423033d) + "'", double6 == (-51938.68429423033d));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        double double1 = org.apache.commons.math.util.FastMath.signum(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(97.0d, (-0.2817181715409549d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 3.141592653589793d, number1, true);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 70);
        int int4 = regulaFalsiSolver3.getEvaluations();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution8 = org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE;
        try {
            double double9 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) ' ', univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver3, (double) (short) 1, (double) 1.07793613E9f, 1097.0d, allowedSolution8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution8 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE + "'", allowedSolution8.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 0.0f, 0.0d, 70);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(100.0d);
        double double4 = regulaFalsiSolver3.getAbsoluteAccuracy();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution8 = org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE;
        try {
            double double9 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) (short) -1, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver3, (double) 1L, 1.1920928955078125E-7d, 1.2577193354595834E30d, allowedSolution8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
        org.junit.Assert.assertTrue("'" + allowedSolution8 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE + "'", allowedSolution8.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, Double.NaN, 0.9999999958776927d, 100.00499987500625d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.4451963704655766d, 146.03766637412417d, (-127));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver4 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 70, (double) (-1.0f));
        double double5 = regulaFalsiSolver4.getMin();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution9 = null;
        try {
            double double10 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(0, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver4, (double) (byte) 0, (double) (short) 10, 1097.0d, allowedSolution9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint(2.2250738585072014E-308d, 90.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 45.0d + "'", double2 == 45.0d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.4451963704655766d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.007770142482552752d + "'", double1 == 0.007770142482552752d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 0.0798317705429828d, 2.993222846126381d, 0.0d, 97);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        double double2 = org.apache.commons.math.util.FastMath.atan2(20.79831393939627d, 1097.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.01895699404389834d + "'", double2 == 0.01895699404389834d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 11);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 70, (double) (-1.0f));
        double double3 = regulaFalsiSolver2.getFunctionValueAccuracy();
        double double4 = regulaFalsiSolver2.getRelativeAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        try {
            double double9 = regulaFalsiSolver2.solve(1731268351, univariateRealFunction6, (double) 3.8146973E-6f, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 70.0d + "'", double4 == 70.0d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) 100, 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 1731268350);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.965267307681675d + "'", double1 == 21.965267307681675d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(343666689, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        double double2 = org.apache.commons.math.util.FastMath.copySign(138.85278649903591d, 64.5d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 138.85278649903591d + "'", double2 == 138.85278649903591d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1731268350, (long) 1731268351);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1731268350L + "'", long2 == 1731268350L);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval((double) (short) -1, 1.5607966601082315d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((int) 'a', (int) 'a');
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (short) 10, (-11L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1731268351, 1731268351);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1337003777) + "'", int2 == (-1337003777));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        float float1 = org.apache.commons.math.util.FastMath.abs(1.4E-45f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.4E-45f + "'", float1 == 1.4E-45f);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (short) 10, 1731263151L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1731263161L + "'", long2 == 1731263161L);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.5188787072485352d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint(11013.232874703393d, Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double[] doubleArray3 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray10 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        double[][] doubleArray12 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray10, doubleArray12);
        double[] doubleArray17 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray24 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray24);
        double[][] doubleArray26 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray24, doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray24);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray10);
        double[] doubleArray33 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray40 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double41 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray33, doubleArray40);
        double[][] doubleArray42 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray40, doubleArray42);
        double[] doubleArray47 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray54 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray47, doubleArray54);
        double[][] doubleArray56 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray54, doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray54);
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray40);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray59);
        double double61 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray10, doubleArray59);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, 100.0d);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 90.0d + "'", double25 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 90.0d + "'", double41 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 90.0d + "'", double55 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 1126.0d + "'", double61 == 1126.0d);
        org.junit.Assert.assertNotNull(doubleArray63);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.9867717342662448d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1044889974911132d + "'", double1 == 1.1044889974911132d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 100, 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-3.831008000716671E22d));
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (byte) -1, 1731268351);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 10.049875621120892d, (double) (byte) 10, 8.56806886553248E-6d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) 97L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 7.6293945E-6f + "'", float1 == 7.6293945E-6f);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) (-2305258549L), (float) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 10.0f, (double) 3);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1000.0d + "'", double2 == 1000.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((int) (byte) 1, (int) (short) -1);
        int int3 = dimensionMismatchException2.getDimension();
        int int4 = dimensionMismatchException2.getDimension();
        java.lang.Number number5 = dimensionMismatchException2.getArgument();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1 + "'", number5.equals(1));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        float float1 = org.apache.commons.math.util.MathUtils.indicator(100.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(0.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1023) + "'", int1 == (-1023));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(100.0d);
        double double2 = regulaFalsiSolver1.getStartValue();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution7 = org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE;
        try {
            double double8 = regulaFalsiSolver1.solve((-127), univariateRealFunction4, 0.36787944117144233d, Double.NEGATIVE_INFINITY, allowedSolution7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + allowedSolution7 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE + "'", allowedSolution7.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 0L, 1731268351, (-1023));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathIllegalArgumentException; message: invalid rounding method -1,023, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        try {
            java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 97L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        float float2 = org.apache.commons.math.util.FastMath.copySign((float) 7766279631452241919L, (float) 'a');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 7.7662794E18f + "'", float2 == 7.7662794E18f);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) '#', 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        try {
            java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        double[] doubleArray3 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray10 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        double[][] doubleArray12 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray10, doubleArray12);
        double[] doubleArray17 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray24 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray24);
        double[][] doubleArray26 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray24, doubleArray26);
        double[] doubleArray31 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray38 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double39 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray31, doubleArray38);
        double[][] doubleArray40 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray38, doubleArray40);
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray38);
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray10, doubleArray38);
        double[] doubleArray44 = null;
        try {
            double double45 = org.apache.commons.math.util.MathUtils.distance(doubleArray38, doubleArray44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 90.0d + "'", double25 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 90.0d + "'", double39 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (byte) -1, 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        double double2 = org.apache.commons.math.util.FastMath.scalb(100.0d, 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 102400.0d + "'", double2 == 102400.0d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        float float2 = org.apache.commons.math.util.FastMath.copySign(1.1920929E-7f, (float) (-10));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.1920929E-7f) + "'", float2 == (-1.1920929E-7f));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(0, (-209568959));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 209568959 + "'", int2 == 209568959);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        double double1 = org.apache.commons.math.util.FastMath.acos(2.993222846126381d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        double double3 = org.apache.commons.math.util.MathUtils.round(0.0d, 1731268350, 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence(267.70557299807183d, 1.3440585709080678E43d, (double) (-11L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [13,440,585,709,080,678,000,000,000,000,000,000,000,000,000, -11]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        double double1 = org.apache.commons.math.util.FastMath.exp(21.965267307681675d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.462536700000001E9d + "'", double1 == 3.462536700000001E9d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-127), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        double double2 = org.apache.commons.math.util.FastMath.max(0.9999999958776927d, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999999958776927d + "'", double2 == 0.9999999958776927d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.6321206780378472d, (double) 1.5370264E31f, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) (-10));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1071382528) + "'", int1 == (-1071382528));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_EXCEEDS_N;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_EXCEEDS_N + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_EXCEEDS_N));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) (-2305258549L), 0.4451963704655766d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-2.30525824E9f) + "'", float2 == (-2.30525824E9f));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint(20.79831393939627d, 100.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 60.39915696969813d + "'", double2 == 60.39915696969813d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        double double2 = org.apache.commons.math.util.FastMath.hypot(6.283185307179586d, (double) (-1.1920929E-7f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.283185307179587d + "'", double2 == 6.283185307179587d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.948148009134034E13d + "'", double1 == 3.948148009134034E13d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-1337003777));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 1731268350, 1.4988753000167903d, 102400.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(2.220446049250313E-16d, 0.0d, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-10), (java.lang.Number) (-0.6321205588285577d), (int) (short) 10, orderDirection3, true);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.01895699404389834d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0001796891927d + "'", double1 == 1.0001796891927d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.007770142482552752d, 6.938893903907228E-18d, (-1023));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1077936128, (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        double double1 = org.apache.commons.math.util.FastMath.log10(7.7662796314522419E18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 18.89021302363088d + "'", double1 == 18.89021302363088d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EXPANSION_FACTOR_SMALLER_THAN_ONE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EXPANSION_FACTOR_SMALLER_THAN_ONE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EXPANSION_FACTOR_SMALLER_THAN_ONE));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.9867717342662448d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.986771734266245d + "'", double1 == 1.986771734266245d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) 98L, (float) 100L, (float) 97L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.4451963704655766d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.100747554766916d + "'", double1 == 1.100747554766916d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        double double1 = org.apache.commons.math.util.FastMath.exp(8.56806886553248E-6d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000085681055715d + "'", double1 == 1.0000085681055715d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-209568959));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.9802322387695312E-8d + "'", double1 == 2.9802322387695312E-8d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence((double) 3.8146973E-6f, (double) 0L, (-15.942385152878742d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.791759469228055d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 10, (long) 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 70L + "'", long2 == 70L);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException3 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1, objArray2);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 97L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, 2.302585092994046d, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-209568959), (java.lang.Number) 7.6293945E-6f, true);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        double double1 = org.apache.commons.math.util.FastMath.sin(102400.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.21094709796687366d + "'", double1 == 0.21094709796687366d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (byte) 100, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(70, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 70 + "'", int2 == 70);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-1337003777), 343666689);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-993337088) + "'", int2 == (-993337088));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        double[] doubleArray3 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray10 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        double[][] doubleArray12 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray10, doubleArray12);
        double[] doubleArray17 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray24 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray24);
        double[][] doubleArray26 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray24, doubleArray26);
        double[] doubleArray31 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray38 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double39 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray31, doubleArray38);
        double[][] doubleArray40 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray38, doubleArray40);
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray38);
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray10, doubleArray38);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection44 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[] doubleArray48 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray55 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double56 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray48, doubleArray55);
        double[][] doubleArray57 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray55, doubleArray57);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray38, orderDirection44, doubleArray57);
        double[] doubleArray60 = null;
        try {
            double double61 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 90.0d + "'", double25 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 90.0d + "'", double39 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection44 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection44.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 90.0d + "'", double56 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray57);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        double double2 = org.apache.commons.math.util.FastMath.copySign((double) 10L, 1.986771734266245d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        double double1 = org.apache.commons.math.util.FastMath.expm1(2.99822295029797d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 19.049875621120893d + "'", double1 == 19.049875621120893d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        double[] doubleArray6 = new double[] { (byte) 10, 100.0d, 105.94810050208545d, (short) -1, 0.0d, 1L };
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray6);
        int int10 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1731268350 + "'", int7 == 1731268350);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1731268350 + "'", int8 == 1731268350);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1731268350 + "'", int10 == 1731268350);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 10L);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, (-1337003777), 343666689);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathIllegalArgumentException; message: invalid rounding method 343,666,689, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        double double2 = org.apache.commons.math.util.FastMath.copySign(0.9999999958776927d, 102400.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999999958776927d + "'", double2 == 0.9999999958776927d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (short) 1, (java.lang.Number) 7766279631452241919L, true);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.7453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2039980656902276d + "'", double1 == 1.2039980656902276d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.4451963704655766d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.44519637046557664d + "'", double1 == 0.44519637046557664d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-10), 343666689);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 343,666,689, n = -10");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (byte) 10, 1731268351);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(9.536743E-7f, (float) 1077936128, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) ' ', (float) 70L, 7.7662794E18f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 0, 1.5370264E31f, (float) ' ');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        try {
            incrementor0.incrementCount();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 5200L, 0.0f, (-1.4E-45f));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-10), (-10));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: must have n >= 0 for binomial coefficient (n, k), got n = -10");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 10);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-2.19871080577E11d), 0.4451963704655766d, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 105.94810050208545d);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0E-15d);
        notPositiveException1.addSuppressed((java.lang.Throwable) notStrictlyPositiveException3);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (byte) -1, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-32) + "'", int2 == (-32));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        float float2 = org.apache.commons.math.util.FastMath.copySign((float) 1L, (float) (-209568959));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException2 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 35);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8184464592320668d + "'", double1 == 1.8184464592320668d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        double double1 = org.apache.commons.math.util.FastMath.signum(11013.232920103324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-1731268351), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, 1731263151L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1731263151L + "'", long2 == 1731263151L);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1097.0d, 1.7453292519943295d, 1.1978571669969933E100d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution9 = org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE;
        try {
            double double10 = regulaFalsiSolver3.solve(100, univariateRealFunction5, 1.986771734266245d, (-0.5440211108893698d), 1126.0d, allowedSolution9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + allowedSolution9 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE + "'", allowedSolution9.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.007770142482552752d, (double) (-1731268351));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        double double1 = org.apache.commons.math.util.FastMath.signum(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.STANDARD_DEVIATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (java.lang.Number) 1731268350, (java.lang.Number) (-1L), false);
        java.lang.Throwable[] throwableArray13 = numberIsTooLargeException12.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, (java.lang.Object[]) throwableArray13);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException15 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Number) 0.0d, (java.lang.Object[]) throwableArray13);
        org.apache.commons.math.exception.NoBracketingException noBracketingException16 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) 10.0f, (-1.2876178137472069E-19d), 0.0798317705429828d, (double) 10L, (java.lang.Object[]) throwableArray13);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.STANDARD_DEVIATION + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.STANDARD_DEVIATION));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertNotNull(throwableArray13);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 1731268351);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Number) 1731268350, (java.lang.Number) (-1L), false);
        java.lang.Throwable[] throwableArray10 = numberIsTooLargeException9.getSuppressed();
        org.apache.commons.math.exception.NoBracketingException noBracketingException11 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) 52L, 0.5188787072485352d, (double) (-10), (double) 10, (java.lang.Object[]) throwableArray10);
        double double12 = noBracketingException11.getLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 52.0d + "'", double12 == 52.0d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 7766279631452241920L);
        int int2 = regulaFalsiSolver1.getEvaluations();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        try {
            double double8 = regulaFalsiSolver1.solve((int) (byte) 1, univariateRealFunction4, 99.99999999999999d, 146.03766637412417d, 97.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        double double2 = org.apache.commons.math.util.FastMath.scalb((-0.5440211108893698d), 209568959);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        long long1 = org.apache.commons.math.util.MathUtils.factorial(11);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 39916800L + "'", long1 == 39916800L);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 1731268350, 1.8184464592320668d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.7312683499999998E9d + "'", double2 == 1.7312683499999998E9d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        float[] floatArray3 = new float[] { 10.0f, (-1.0f), 100 };
        float[] floatArray4 = null;
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(floatArray3, floatArray4);
        float[] floatArray7 = new float[] { 100.0f };
        float[] floatArray8 = null;
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equals(floatArray7, floatArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray3, floatArray7);
        float[] floatArray12 = new float[] { 100.0f };
        float[] floatArray13 = null;
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(floatArray12, floatArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(floatArray7, floatArray13);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        double double2 = org.apache.commons.math.util.FastMath.min(1.5607966601082315d, (double) (-11L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-11.0d) + "'", double2 == (-11.0d));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        double double2 = org.apache.commons.math.util.FastMath.copySign((double) 0L, 60.39915696969813d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        try {
            java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 198L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint(18.89021302363088d, 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.44510651181544d + "'", double2 == 9.44510651181544d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        double[] doubleArray3 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray10 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        double[][] doubleArray12 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray10, doubleArray12);
        double[] doubleArray17 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray24 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray24);
        double[][] doubleArray26 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray24, doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray24);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray10);
        double[] doubleArray33 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray40 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double41 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray33, doubleArray40);
        double[][] doubleArray42 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray40, doubleArray42);
        double[] doubleArray47 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray54 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray47, doubleArray54);
        double[][] doubleArray56 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray54, doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray54);
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray40);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray59);
        double double61 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray10, doubleArray59);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, 100.0d);
        double[] doubleArray67 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray74 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double75 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray67, doubleArray74);
        double[][] doubleArray76 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray74, doubleArray76);
        double[] doubleArray81 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray88 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double89 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray81, doubleArray88);
        double[][] doubleArray90 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray88, doubleArray90);
        double double92 = org.apache.commons.math.util.MathUtils.distance1(doubleArray74, doubleArray88);
        double[] doubleArray93 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray74);
        boolean boolean94 = org.apache.commons.math.util.MathUtils.equals(doubleArray63, doubleArray93);
        double[] doubleArray95 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray63);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray95);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (0 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 90.0d + "'", double25 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 90.0d + "'", double41 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 90.0d + "'", double55 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 1126.0d + "'", double61 == 1126.0d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 90.0d + "'", double75 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 90.0d + "'", double89 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertNotNull(doubleArray95);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        double double2 = org.apache.commons.math.util.FastMath.scalb((double) (-32), (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-32768.0d) + "'", double2 == (-32768.0d));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(198L, (long) 1077936128);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 213431353344L + "'", long2 == 213431353344L);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 209568959);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        double double2 = org.apache.commons.math.util.MathUtils.log(3.462536700000001E9d, (double) 3.8146973E-6f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.5680171825505484d) + "'", double2 == (-0.5680171825505484d));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        double double1 = org.apache.commons.math.util.FastMath.floor((-1.7182818284590458d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.0d) + "'", double1 == (-2.0d));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-2.19871080577E11d), 22026.465794806718d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.1987108057699997E11d) + "'", double2 == (-2.1987108057699997E11d));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.1752011936438014d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-32));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        long long1 = org.apache.commons.math.util.FastMath.abs(7766279631452241919L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 7766279631452241919L + "'", long1 == 7766279631452241919L);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 35);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (double) 1.07793613E9f, 99.99999999999999d, 2.718281828459045d, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.apache.commons.math.util.MathUtils.checkFinite(0.0d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isBracketing(univariateRealFunction0, 1126.0d, 60.39915696969813d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7453292519943295d + "'", double1 == 1.7453292519943295d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1622776601683795d + "'", double1 == 3.1622776601683795d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 0, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(70.0d, (double) 52, 1.986771734266245d, (double) 70.0f);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) 1, 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(3.831008000716577E22d, (double) '4', 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint((double) 1.5370264E31f, 6.938893903907228E-18d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.685131763883641E30d + "'", double2 == 7.685131763883641E30d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        double double2 = org.apache.commons.math.util.FastMath.hypot(100.0d, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.4987562112089d + "'", double2 == 100.4987562112089d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(1.0E-15d, (double) 1077936128, 3.948148009134034E13d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        double double1 = org.apache.commons.math.util.FastMath.ulp(2.154434690031884d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.0d, 1731268351, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval(6.938893903907228E-18d, 3.1622776601683795d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((-1), (int) ' ');
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 1.201855897199358E19d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        int int2 = org.apache.commons.math.util.MathUtils.pow(11, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1731268351, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        double[] doubleArray0 = null;
        double[] doubleArray4 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray11 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double12 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray4, doubleArray11);
        double[][] doubleArray13 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray11, doubleArray13);
        double[] doubleArray18 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray25 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double26 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray18, doubleArray25);
        double[][] doubleArray27 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray25, doubleArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray25);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray11);
        try {
            double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 90.0d + "'", double12 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 90.0d + "'", double26 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 1731263151L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.384185791015625E-7d + "'", double1 == 2.384185791015625E-7d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence(19.049875621120893d, (-0.5680171825505484d), 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1731268351), 209568959);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 209,568,959, n = -1,731,268,351");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d, (double) (-10), (double) (short) 10);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.4988753000167903d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.350016302011459d + "'", double1 == 2.350016302011459d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) 19206L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 0.007770142482552752d, 1.503300998004841d, (double) 209568959);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-32768.0d));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) 1L, (-127));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 5.877472E-39f + "'", float2 == 5.877472E-39f);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0798317705429828d, 0.0d, (-32));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        double[] doubleArray3 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray10 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        double[][] doubleArray12 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray10, doubleArray12);
        java.lang.Object[] objArray14 = org.apache.commons.math.exception.util.ArgUtils.flatten((java.lang.Object[]) doubleArray12);
        java.lang.Object[] objArray15 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray14);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray15);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(1.1978571669969933E100d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint((-1.7182818284590458d), (double) (-2305258549L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.1526292753591409E9d) + "'", double2 == (-1.1526292753591409E9d));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (double) 11, (double) (-32), 105.94810050208545d, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 343666689);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8751688612297938d + "'", double1 == 0.8751688612297938d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getMaximalCount();
        try {
            incrementor0.incrementCount();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence(52.0d, (double) 1.4E-45f, 60.39915696969813d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        try {
            java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-1)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((int) '4', 11);
        int int3 = dimensionMismatchException2.getDimension();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1731268350, (java.lang.Number) (-1L), false);
        java.lang.Number number5 = numberIsTooLargeException4.getArgument();
        boolean boolean6 = numberIsTooLargeException4.getBoundIsAllowed();
        java.lang.Number number7 = numberIsTooLargeException4.getMax();
        java.lang.Number number8 = numberIsTooLargeException4.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1731268350 + "'", number5.equals(1731268350));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1L) + "'", number7.equals((-1L)));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (-1L) + "'", number8.equals((-1L)));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (short) 10);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction3 = null;
        try {
            double double5 = regulaFalsiSolver1.solve(3, univariateRealFunction3, (double) 10.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OBJECT_TRANSFORMATION;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OBJECT_TRANSFORMATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OBJECT_TRANSFORMATION));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        double[] doubleArray3 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray10 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        double[][] doubleArray12 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray10, doubleArray12);
        double[] doubleArray17 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray24 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray24);
        double[][] doubleArray26 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray24, doubleArray26);
        double[] doubleArray31 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray38 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double39 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray31, doubleArray38);
        double[][] doubleArray40 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray38, doubleArray40);
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray38);
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray10, doubleArray38);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray10);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray10, (int) (short) 100);
        double[] doubleArray50 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray57 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double58 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray50, doubleArray57);
        double[][] doubleArray59 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray57, doubleArray59);
        try {
            double double61 = org.apache.commons.math.util.MathUtils.distance1(doubleArray46, doubleArray57);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 90.0d + "'", double25 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 90.0d + "'", double39 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 90.0d + "'", double58 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.9126365759632116d, 0.0d, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        double double1 = org.apache.commons.math.util.FastMath.sinh(4.672343674754381d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 53.46937508619497d + "'", double1 == 53.46937508619497d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ALPHA;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ALPHA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ALPHA));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        double double1 = org.apache.commons.math.util.FastMath.log10((-2.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-209568959), (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) (byte) 100, (float) '4', (-1.0f));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.9867717342662448d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.03467570824850382d + "'", double1 == 0.03467570824850382d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 100.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 1.5607966601082315d);
        java.lang.Throwable[] throwableArray2 = notPositiveException1.getSuppressed();
        boolean boolean3 = notPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) 1077936128, (float) 10, (-1337003777));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (short) 0, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        double[] doubleArray3 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray10 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        double[][] doubleArray12 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray10, doubleArray12);
        double[] doubleArray17 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray24 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray24);
        double[][] doubleArray26 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray24, doubleArray26);
        double[] doubleArray31 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray38 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double39 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray31, doubleArray38);
        double[][] doubleArray40 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray38, doubleArray40);
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray38);
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray10, doubleArray38);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection44 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        boolean boolean47 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10, orderDirection44, true, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (0 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 90.0d + "'", double25 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 90.0d + "'", double39 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection44 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection44.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.5403023058681395d, 105.94810050208545d, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(100.0d);
        double double2 = regulaFalsiSolver1.getAbsoluteAccuracy();
        double double3 = regulaFalsiSolver1.getMin();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution9 = org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE;
        try {
            double double10 = regulaFalsiSolver1.solve((int) (short) 0, univariateRealFunction5, 1.986771734266245d, 7.7662796314522419E18d, 0.0d, allowedSolution9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + allowedSolution9 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE + "'", allowedSolution9.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        double[] doubleArray3 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray10 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        double[][] doubleArray12 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray10, doubleArray12);
        double[] doubleArray17 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray24 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray24);
        double[][] doubleArray26 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray24, doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray24);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray10);
        double[] doubleArray33 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray40 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double41 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray33, doubleArray40);
        double[][] doubleArray42 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray40, doubleArray42);
        double[] doubleArray47 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray54 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray47, doubleArray54);
        double[][] doubleArray56 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray54, doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray54);
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray40);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray59);
        double double61 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray10, doubleArray59);
        int int62 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        double[] doubleArray64 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, 1126.0d);
        double[][] doubleArray65 = null;
        try {
            org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray64, doubleArray65);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 90.0d + "'", double25 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 90.0d + "'", double41 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 90.0d + "'", double55 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 1126.0d + "'", double61 == 1126.0d);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-209568959) + "'", int62 == (-209568959));
        org.junit.Assert.assertNotNull(doubleArray64);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 10, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9L + "'", long2 == 9L);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, (-0.0d), 19.049875621120893d, (double) 1.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 105.94810050208545d, 60.39915696969813d, (double) 1731268351, (-1071382528));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1731268350, 9L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9L + "'", long2 == 9L);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution6 = null;
        try {
            double double7 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((-993337088), univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver2, (double) (-1.1920929E-7f), 1126.0d, (double) 198L, allowedSolution6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence(7.7662796314522419E18d, (double) (-1337003777), (double) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        double double1 = org.apache.commons.math.util.FastMath.exp(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        double[] doubleArray0 = null;
        double[] doubleArray4 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray11 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double12 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray4, doubleArray11);
        double[][] doubleArray13 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray11, doubleArray13);
        double[] doubleArray18 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray25 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double26 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray18, doubleArray25);
        double[][] doubleArray27 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray25, doubleArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray25);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[] doubleArray34 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray41 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double42 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray41);
        double[][] doubleArray43 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray41, doubleArray43);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray11, orderDirection30, doubleArray43);
        try {
            double double46 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 90.0d + "'", double12 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 90.0d + "'", double26 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection30 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection30.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 90.0d + "'", double42 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray43);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (double) (-10), 0.0d, (double) 1731263151L, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (double) 7.7662794E18f, 0.0d, (double) 35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination(0.8862395404791882d, (double) 7766279631452241920L, (double) 10000000000L, (double) (-11L), (double) 1.1920929E-7f, 1.1978571669969933E100d, 1.0001796891927d, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.427957018610231E93d + "'", double8 == 1.427957018610231E93d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        long long1 = org.apache.commons.math.util.FastMath.abs(10L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        int int2 = org.apache.commons.math.util.FastMath.max(209568959, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 209568959 + "'", int2 == 209568959);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (double) 9.536743E-7f, 0.5188787072485352d, (double) 198L, (-209568959));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (byte) 10);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        try {
            java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger3);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        double double1 = org.apache.commons.math.util.FastMath.sin(33.555923471125034d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8423320834271332d + "'", double1 == 0.8423320834271332d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) 10);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DATA;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DATA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DATA));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        double double1 = org.apache.commons.math.util.MathUtils.sign(2.99822295029797d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-32));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: must have n >= 0 for n!, got n = -32");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 'a', (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(267.70557299807183d, 4.672343674754381d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((-57.29577951308232d), 0.5403023058681395d, (double) 10, 2.154434690031884d);
        double double5 = noBracketingException4.getLo();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-57.29577951308232d) + "'", double5 == (-57.29577951308232d));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(0L, (-2305258549L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, (int) '#', 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathIllegalArgumentException; message: invalid rounding method 100, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 'a', (byte) 10 };
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (-1.0f), (org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray10);
        org.apache.commons.math.exception.NoBracketingException noBracketingException12 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, 2.302585092994046d, 0.0d, 0.8862395404791882d, (double) 10, objArray10);
        java.lang.Object[] objArray13 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray10);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray13);
        java.lang.String str15 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "input array" + "'", str15.equals("input array"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        double double2 = org.apache.commons.math.util.FastMath.hypot(1.1978571669969933E100d, 3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1978571669969933E100d + "'", double2 == 1.1978571669969933E100d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) (-993337088));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 64.0f + "'", float1 == 64.0f);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (double) 19206L, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        double double2 = org.apache.commons.math.util.FastMath.scalb(1.0000000000000002d, 343666689);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        double double1 = org.apache.commons.math.util.FastMath.ceil(7.685131763883641E30d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.685131763883641E30d + "'", double1 == 7.685131763883641E30d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.resetCount();
        int int2 = incrementor0.getCount();
        try {
            incrementor0.incrementCount((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        int int1 = org.apache.commons.math.util.FastMath.abs((-32));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 209568959, 19.049875621120893d, (int) '4');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: must have n >= 0 for n!, got n = -1");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder(0.0d, (double) 10000000000L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        int int1 = org.apache.commons.math.util.FastMath.abs(35);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (byte) 100, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 99 + "'", int2 == 99);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(7766279631452241920L, 1731263151L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7766279629720978769L + "'", long2 == 7766279629720978769L);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 343666689, 3.8146973E-6f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.43666688E8f + "'", float2 == 3.43666688E8f);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.MathInternalError mathInternalError1 = new org.apache.commons.math.exception.MathInternalError(throwable0);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 10, 10L };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException8 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Number) 1731268350, objArray7);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException9 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) mathInternalError1, (org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray7);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) mathIllegalStateException9);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE));
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-32), (double) (-2305258549L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017453292519943295d + "'", double1 == 0.017453292519943295d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        long long2 = org.apache.commons.math.util.MathUtils.pow(70L, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 5.877472E-39f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        int[] intArray0 = null;
        try {
            int[] intArray2 = org.apache.commons.math.util.MathUtils.copyOf(intArray0, 343666689);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        double double2 = org.apache.commons.math.util.FastMath.min((double) Float.NaN, (double) 64.0f);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 53.46937508619497d, 2.2250738585072014E-308d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        double double1 = org.apache.commons.math.util.FastMath.ulp(2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.930380657631324E-32d + "'", double1 == 4.930380657631324E-32d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        float float1 = org.apache.commons.math.util.FastMath.ulp(1.0000001f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.1920929E-7f + "'", float1 == 1.1920929E-7f);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 10, 10L };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException5 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1731268350, objArray4);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.LENGTH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH;
        java.lang.Object[] objArray14 = new java.lang.Object[] { localizedFormats8, localizedFormats9, 100.0d, 100, localizedFormats12, localizedFormats13 };
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException15 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray14);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException16 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray14);
        org.apache.commons.math.exception.MathInternalError mathInternalError17 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) mathIllegalStateException16);
        maxCountExceededException5.addSuppressed((java.lang.Throwable) mathIllegalStateException16);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LENGTH + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.LENGTH));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH));
        org.junit.Assert.assertNotNull(objArray14);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isBracketing(univariateRealFunction0, 1.8491431899952486d, 97.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.36787944117144233d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0684342442825563d + "'", double1 == 1.0684342442825563d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (byte) -1, (long) (-1023));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1024L) + "'", long2 == (-1024L));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        double[] doubleArray0 = null;
        double[] doubleArray1 = null;
        try {
            double double2 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray0, doubleArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.6321206780378472d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        double[] doubleArray3 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray10 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        double[][] doubleArray12 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray10, doubleArray12);
        double[] doubleArray17 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray24 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray24);
        double[][] doubleArray26 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray24, doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray24);
        double[] doubleArray32 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray39 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double40 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray32, doubleArray39);
        double[][] doubleArray41 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray39, doubleArray41);
        double[] doubleArray46 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray53 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double54 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray46, doubleArray53);
        double[][] doubleArray55 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray53, doubleArray55);
        double double57 = org.apache.commons.math.util.MathUtils.distance1(doubleArray39, doubleArray53);
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray10, doubleArray39);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection59 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray39, orderDirection59, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 90.0d + "'", double25 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 90.0d + "'", double40 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 90.0d + "'", double54 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver4 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(Double.NEGATIVE_INFINITY, (double) (short) 100);
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution8 = org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE;
        try {
            double double9 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(52, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver4, 0.0d, (-3.831008000716671E22d), 0.0d, allowedSolution8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + allowedSolution8 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE + "'", allowedSolution8.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, (java.lang.Number) 1731268350, (java.lang.Number) (-1L), false);
        java.lang.Throwable[] throwableArray15 = numberIsTooLargeException14.getSuppressed();
        org.apache.commons.math.exception.NoBracketingException noBracketingException16 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (double) 52L, 0.5188787072485352d, (double) (-10), (double) 10, (java.lang.Object[]) throwableArray15);
        org.apache.commons.math.exception.NoBracketingException noBracketingException17 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) 1.0000001f, 100.0d, 1.5430806348152437d, (double) 70.0f, (java.lang.Object[]) throwableArray15);
        double double18 = noBracketingException17.getFHi();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 70.0d + "'", double18 == 70.0d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-2305258549L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.305258549E9d) + "'", double1 == (-2.305258549E9d));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, 2.384185791015625E-7d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval(1.2039980656902276d, 2.246067844446904d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.5403023058681395d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1495489051661059d + "'", double1 == 1.1495489051661059d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        double[] doubleArray0 = null;
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-1.0f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-1.1920929E-7f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.570796446004186d + "'", double1 == 1.570796446004186d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0f, 0.0f, (float) (-1023));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 1731263151L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 41608.450475834834d + "'", double1 == 41608.450475834834d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        double[] doubleArray3 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray10 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        double[][] doubleArray12 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray10, doubleArray12);
        double[] doubleArray17 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray24 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray24);
        double[][] doubleArray26 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray24, doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray24);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray10);
        double[] doubleArray33 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray40 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double41 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray33, doubleArray40);
        double[][] doubleArray42 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray40, doubleArray42);
        double[] doubleArray47 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray54 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray47, doubleArray54);
        double[][] doubleArray56 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray54, doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray54);
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray40);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray59);
        double double61 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray10, doubleArray59);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, 100.0d);
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray63, (int) (short) 10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection66 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats67 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats73 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED;
        java.lang.Object[] objArray76 = new java.lang.Object[] { 'a', (byte) 10 };
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (-1.0f), (org.apache.commons.math.exception.util.Localizable) localizedFormats73, objArray76);
        org.apache.commons.math.exception.NoBracketingException noBracketingException78 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats67, 2.302585092994046d, 0.0d, 0.8862395404791882d, (double) 10, objArray76);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats79 = org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS;
        double[] doubleArray83 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray90 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double91 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray83, doubleArray90);
        double[][] doubleArray92 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray90, doubleArray92);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException94 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) noBracketingException78, (org.apache.commons.math.exception.util.Localizable) localizedFormats79, (java.lang.Object[]) doubleArray92);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray63, orderDirection66, doubleArray92);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 90.0d + "'", double25 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 90.0d + "'", double41 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 90.0d + "'", double55 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 1126.0d + "'", double61 == 1126.0d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + orderDirection66 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection66.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + localizedFormats67 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats67.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats73 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED + "'", localizedFormats73.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED));
        org.junit.Assert.assertNotNull(objArray76);
        org.junit.Assert.assertTrue("'" + localizedFormats79 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS + "'", localizedFormats79.equals(org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS));
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 90.0d + "'", double91 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray92);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(100.0d);
        double double2 = regulaFalsiSolver1.getStartValue();
        double double3 = regulaFalsiSolver1.getRelativeAccuracy();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-14d + "'", double3 == 1.0E-14d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        double double1 = org.apache.commons.math.util.FastMath.signum(100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-1337003777));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-21.706844140603472d) + "'", double1 == (-21.706844140603472d));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 209568959, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 209568959L + "'", long2 == 209568959L);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.6321206780378472d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5908569980761279d + "'", double1 == 0.5908569980761279d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, 7766279629720978769L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7766279629720978769L + "'", long2 == 7766279629720978769L);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.4E-45f, 0.0f, (float) 1077936128);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        float float1 = org.apache.commons.math.util.FastMath.abs(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(98L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.4988753000167903d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        float float1 = org.apache.commons.math.util.FastMath.nextUp(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.4E-45f + "'", float1 == 1.4E-45f);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 198L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.889646032848159E85d + "'", double1 == 4.889646032848159E85d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.570787758726031d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.570787758726031d + "'", double1 == 1.570787758726031d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) '4', 1.1495489051661059d, 99);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval(70.0d, 90.0d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        try {
            java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 35, 70L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-35L) + "'", long2 == (-35L));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(10L, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 260L + "'", long2 == 260L);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.0d, 0.0798317705429828d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(7.6293945E-6f, (float) 32);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.4988753000167903d, 100.0d, 1.1495489051661059d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        float float2 = org.apache.commons.math.util.FastMath.max(52.0f, (float) 97L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.01895699404389834d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.018956994043898345d + "'", double1 == 0.018956994043898345d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        double[] doubleArray3 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray10 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        double[][] doubleArray12 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray10, doubleArray12);
        double[] doubleArray17 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray24 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray24);
        double[][] doubleArray26 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray24, doubleArray26);
        double[] doubleArray31 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray38 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double39 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray31, doubleArray38);
        double[][] doubleArray40 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray38, doubleArray40);
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray38);
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray10, doubleArray38);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray10);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray10, (int) (short) 100);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, 4.440892098500626E-16d);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 90.0d + "'", double25 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 90.0d + "'", double39 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isBracketing(univariateRealFunction0, (double) 343666689, (double) (-1731268351));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.7453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 52L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9866275920404853d + "'", double1 == 0.9866275920404853d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 70);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, (-57.29577951308232d), (-2.19871080577E11d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0f, (float) 3, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 213431353344L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.MathInternalError mathInternalError1 = new org.apache.commons.math.exception.MathInternalError(throwable0);
        java.lang.String str2 = mathInternalError1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math.exception.MathInternalError: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH" + "'", str2.equals("org.apache.commons.math.exception.MathInternalError: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(4.9E-324d, 1.1495489051661059d);
        double double3 = regulaFalsiSolver2.getRelativeAccuracy();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.9E-324d + "'", double3 == 4.9E-324d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-11L), (long) 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-385L) + "'", long2 == (-385L));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) 'a', (-1731268351));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        double double1 = org.apache.commons.math.util.MathUtils.sign(99.99999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.427957018610231E93d);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        double double2 = org.apache.commons.math.util.FastMath.copySign(1.1102230246251565E-16d, 0.007770142482552752d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1102230246251565E-16d + "'", double2 == 1.1102230246251565E-16d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{0} is smaller than the minimum ({1})" + "'", str1.equals("{0} is smaller than the minimum ({1})"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (-10));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext0 = new org.apache.commons.math.exception.util.ExceptionContext();
        double[] doubleArray5 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray12 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        java.lang.Class<?> wildcardClass14 = doubleArray5.getClass();
        double[] doubleArray18 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray25 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double26 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray18, doubleArray25);
        double[][] doubleArray27 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray25, doubleArray27);
        double[] doubleArray32 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray39 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double40 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray32, doubleArray39);
        double[][] doubleArray41 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray39, doubleArray41);
        double double43 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray39);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray25);
        double[] doubleArray48 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray55 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double56 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray48, doubleArray55);
        double[][] doubleArray57 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray55, doubleArray57);
        double[] doubleArray62 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray69 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double70 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray62, doubleArray69);
        double[][] doubleArray71 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray69, doubleArray71);
        double double73 = org.apache.commons.math.util.MathUtils.distance1(doubleArray55, doubleArray69);
        double[] doubleArray74 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray55);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray74);
        double double76 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray25, doubleArray74);
        double[] doubleArray78 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, 100.0d);
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray78);
        exceptionContext0.setValue("", (java.lang.Object) doubleArray78);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray78);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (0 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 90.0d + "'", double13 == 90.0d);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 90.0d + "'", double26 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 90.0d + "'", double40 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 90.0d + "'", double56 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 90.0d + "'", double70 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 1126.0d + "'", double76 == 1126.0d);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) 'a');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 97.00001f + "'", float1 == 97.00001f);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number1, (java.lang.Number) 10L, true);
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException10 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) ' ', 1.0d, 0.6321206780378472d, 21.965267307681675d, objArray9);
        java.lang.Object[] objArray11 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray9);
        java.lang.Object[] objArray12 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray9);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray12);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        double double3 = org.apache.commons.math.util.MathUtils.reduce(3.831008000716577E22d, (double) 260L, 0.004425697988050785d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.004425697988050785d) + "'", double3 == (-0.004425697988050785d));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (-1.1920929E-7f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(19206L, (-2305258549L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4024981426554L + "'", long2 == 4024981426554L);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.007770142482552752d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000301877089812d + "'", double1 == 1.0000301877089812d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((int) 'a', (-993337088));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-993,337,088)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination((double) (-385L), (double) 1731268350, 0.44519637046557664d, 0.0d, 6.938893903907228E-18d, 60.39915696969813d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-6.6653831475E11d) + "'", double6 == (-6.6653831475E11d));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence((double) 1.5370264E31f, 2.154434690031884d, 1.1495489051661059d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [15,370,263,527,767,281,000,000,000,000,000, 2.154]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 1731268350);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1731268350L + "'", long1 == 1731268350L);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        int int2 = org.apache.commons.math.util.MathUtils.pow(52, 343666689);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (double) (-32), 4.930380657631324E-32d, 1.1752011936438014d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1097.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.001245622069476d + "'", double1 == 7.001245622069476d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.LENGTH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH;
        java.lang.Object[] objArray8 = new java.lang.Object[] { localizedFormats2, localizedFormats3, 100.0d, 100, localizedFormats6, localizedFormats7 };
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException9 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray8);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException10 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray8);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext11 = mathIllegalStateException10.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext12 = mathIllegalStateException10.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LENGTH + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.LENGTH));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(exceptionContext11);
        org.junit.Assert.assertNotNull(exceptionContext12);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0, 99);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((-1), 99);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isBracketing(univariateRealFunction0, (-2.1987108057699997E11d), 2.350016302011459d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 1.0000001f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1920928244535446E-7d + "'", double1 == 1.1920928244535446E-7d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(41608.450475834834d, 0.0d, 209568959);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 1.0001796891927d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 198L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.4557519189487724d + "'", double1 == 3.4557519189487724d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        double double1 = org.apache.commons.math.util.FastMath.log((-1.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(11013.232874703393d, (-0.017453292519943295d), 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) 3.462536700000001E9d, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray2);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) ' ');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1731268350, (java.lang.Number) (-1L), false);
        java.lang.Throwable[] throwableArray5 = numberIsTooLargeException4.getSuppressed();
        boolean boolean6 = numberIsTooLargeException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        double double1 = org.apache.commons.math.util.FastMath.atan(97.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5604874136486533d + "'", double1 == 1.5604874136486533d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.0d + "'", double1 == 35.0d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_ELEMENT;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.0000085681055715d, (java.lang.Number) 1.8184464592320668d, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_ELEMENT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_ELEMENT));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        float[] floatArray4 = new float[] { 7766279631452241920L, 'a', 0, 1.0000001f };
        float[] floatArray8 = new float[] { 10.0f, (-1.0f), 100 };
        float[] floatArray9 = null;
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(floatArray8, floatArray9);
        float[] floatArray12 = new float[] { 100.0f };
        float[] floatArray13 = null;
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(floatArray12, floatArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray8, floatArray12);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(floatArray4, floatArray8);
        float[] floatArray20 = new float[] { 10.0f, (-1.0f), 100 };
        float[] floatArray21 = null;
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(floatArray20, floatArray21);
        float[] floatArray24 = new float[] { 100.0f };
        float[] floatArray25 = null;
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(floatArray24, floatArray25);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray20, floatArray24);
        float[] floatArray29 = new float[] { 100.0f };
        float[] floatArray30 = null;
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(floatArray29, floatArray30);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(floatArray20, floatArray29);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray4, floatArray20);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        double[] doubleArray0 = null;
        double[] doubleArray4 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray11 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double12 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray4, doubleArray11);
        double[][] doubleArray13 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray11, doubleArray13);
        double[] doubleArray18 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray25 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double26 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray18, doubleArray25);
        double[][] doubleArray27 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray25, doubleArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray25);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray11);
        double[] doubleArray34 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray41 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double42 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray41);
        double[][] doubleArray43 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray41, doubleArray43);
        double[] doubleArray48 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray55 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double56 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray48, doubleArray55);
        double[][] doubleArray57 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray55, doubleArray57);
        double double59 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray55);
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray41);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray60);
        double double62 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray11, doubleArray60);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats63 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats69 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED;
        java.lang.Object[] objArray72 = new java.lang.Object[] { 'a', (byte) 10 };
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (-1.0f), (org.apache.commons.math.exception.util.Localizable) localizedFormats69, objArray72);
        org.apache.commons.math.exception.NoBracketingException noBracketingException74 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats63, 2.302585092994046d, 0.0d, 0.8862395404791882d, (double) 10, objArray72);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats75 = org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS;
        double[] doubleArray79 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray86 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double87 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray79, doubleArray86);
        double[][] doubleArray88 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray86, doubleArray88);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException90 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) noBracketingException74, (org.apache.commons.math.exception.util.Localizable) localizedFormats75, (java.lang.Object[]) doubleArray88);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray11, doubleArray88);
        try {
            org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray0, doubleArray88);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 90.0d + "'", double12 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 90.0d + "'", double26 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 90.0d + "'", double42 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 90.0d + "'", double56 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 1126.0d + "'", double62 == 1126.0d);
        org.junit.Assert.assertTrue("'" + localizedFormats63 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats63.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats69 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED + "'", localizedFormats69.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED));
        org.junit.Assert.assertNotNull(objArray72);
        org.junit.Assert.assertTrue("'" + localizedFormats75 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS + "'", localizedFormats75.equals(org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS));
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 90.0d + "'", double87 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray88);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) 1);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        double double2 = org.apache.commons.math.util.FastMath.min(2.220446049250313E-16d, (-0.5680171825505484d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.5680171825505484d) + "'", double2 == (-0.5680171825505484d));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 0.017453292519943295d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-1024L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-11.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-29937.07084924806d) + "'", double1 == (-29937.07084924806d));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 70, (double) (-1.0f));
        double double3 = regulaFalsiSolver2.getFunctionValueAccuracy();
        double double4 = regulaFalsiSolver2.getRelativeAccuracy();
        double double5 = regulaFalsiSolver2.getAbsoluteAccuracy();
        double double6 = regulaFalsiSolver2.getMin();
        int int7 = regulaFalsiSolver2.getEvaluations();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 70.0d + "'", double4 == 70.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((-0.5440211108893698d), (-1.0d), 1.1920928955078125E-7d, (double) 'a');
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (short) 1, (long) (-127));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 128L + "'", long2 == 128L);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        try {
            java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        double double2 = org.apache.commons.math.util.FastMath.max(10.049875621120892d, 2.246067844446904d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.049875621120892d + "'", double2 == 10.049875621120892d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-209568959));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.09568959E8d) + "'", double1 == (-2.09568959E8d));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        double[] doubleArray3 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray10 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        double[][] doubleArray12 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray10, doubleArray12);
        double[] doubleArray14 = null;
        try {
            double double15 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray10, doubleArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getMaximalCount();
        int int2 = incrementor0.getMaximalCount();
        int int3 = incrementor0.getMaximalCount();
        try {
            incrementor0.incrementCount((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination(1.427957018610231E93d, (double) 39916800L, 0.0d, 2.246067844446904d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 5.699947472046087E100d + "'", double4 == 5.699947472046087E100d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder(2.993222846126381d, (-2.305258549E9d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.993222846126381d + "'", double2 == 2.993222846126381d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (short) -1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-127));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) (-2.30525824E9f));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.LENGTH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH;
        java.lang.Object[] objArray7 = new java.lang.Object[] { localizedFormats1, localizedFormats2, 100.0d, 100, localizedFormats5, localizedFormats6 };
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException8 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray7);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext9 = mathArithmeticException8.getContext();
        java.util.Set<java.lang.String> strSet10 = exceptionContext9.getKeys();
        java.lang.Object obj12 = exceptionContext9.getValue("hi!");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext14 = new org.apache.commons.math.exception.util.ExceptionContext();
        exceptionContext14.setValue("", (java.lang.Object) (-10));
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException25 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats21, (java.lang.Number) 1731268350, (java.lang.Number) (-1L), false);
        java.lang.Throwable[] throwableArray26 = numberIsTooLargeException25.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats20, (java.lang.Object[]) throwableArray26);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException28 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 1.1752011936438014d, (java.lang.Object[]) throwableArray26);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_CONSIDER_PADDING;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED;
        java.lang.Object[] objArray41 = new java.lang.Object[] { 'a', (byte) 10 };
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (-1.0f), (org.apache.commons.math.exception.util.Localizable) localizedFormats38, objArray41);
        org.apache.commons.math.exception.NoBracketingException noBracketingException43 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats32, 2.302585092994046d, 0.0d, 0.8862395404791882d, (double) 10, objArray41);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats44 = org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS;
        double[] doubleArray48 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray55 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double56 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray48, doubleArray55);
        double[][] doubleArray57 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray55, doubleArray57);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException59 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) noBracketingException43, (org.apache.commons.math.exception.util.Localizable) localizedFormats44, (java.lang.Object[]) doubleArray57);
        java.lang.Throwable[] throwableArray60 = noBracketingException43.getSuppressed();
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException61 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats30, (java.lang.Number) 1.0f, (java.lang.Object[]) throwableArray60);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException62 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) notFiniteNumberException28, (org.apache.commons.math.exception.util.Localizable) localizedFormats29, (java.lang.Object[]) throwableArray60);
        exceptionContext14.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats18, (java.lang.Object[]) throwableArray60);
        exceptionContext9.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats13, (java.lang.Object[]) throwableArray60);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LENGTH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.LENGTH));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(exceptionContext9);
        org.junit.Assert.assertNotNull(strSet10);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS + "'", localizedFormats29.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS));
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_CONSIDER_PADDING + "'", localizedFormats30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_CONSIDER_PADDING));
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats32.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED + "'", localizedFormats38.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED));
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertTrue("'" + localizedFormats44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS + "'", localizedFormats44.equals(org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS));
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 90.0d + "'", double56 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(throwableArray60);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 3.43666688E8f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(1.8184464592320668d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence(0.0d, (-3.831008000716671E22d), 100.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [0, -38,310,080,007,166,710,000,000]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 343666689, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 343666637L + "'", long2 == 343666637L);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) 1731268350, (java.lang.Number) (-1L), false);
        java.lang.Throwable[] throwableArray7 = numberIsTooLargeException6.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) throwableArray7);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException9 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 1.1752011936438014d, (java.lang.Object[]) throwableArray7);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_CONSIDER_PADDING;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED;
        java.lang.Object[] objArray22 = new java.lang.Object[] { 'a', (byte) 10 };
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (-1.0f), (org.apache.commons.math.exception.util.Localizable) localizedFormats19, objArray22);
        org.apache.commons.math.exception.NoBracketingException noBracketingException24 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats13, 2.302585092994046d, 0.0d, 0.8862395404791882d, (double) 10, objArray22);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS;
        double[] doubleArray29 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray36 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double37 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray29, doubleArray36);
        double[][] doubleArray38 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray36, doubleArray38);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException40 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) noBracketingException24, (org.apache.commons.math.exception.util.Localizable) localizedFormats25, (java.lang.Object[]) doubleArray38);
        java.lang.Throwable[] throwableArray41 = noBracketingException24.getSuppressed();
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException42 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, (java.lang.Number) 1.0f, (java.lang.Object[]) throwableArray41);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException43 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) notFiniteNumberException9, (org.apache.commons.math.exception.util.Localizable) localizedFormats10, (java.lang.Object[]) throwableArray41);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException45 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 2.99822295029797d);
        notFiniteNumberException9.addSuppressed((java.lang.Throwable) maxCountExceededException45);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_CONSIDER_PADDING + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_CONSIDER_PADDING));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS));
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 90.0d + "'", double37 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(throwableArray41);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0f, (float) 9L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-385L), (long) 1731268350);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(70.0d, (double) 19206L, 4.9E-324d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 19206L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 19206 + "'", int1 == 19206);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) (byte) 100, (-10));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1097.0d, 1.7453292519943295d, 1.1978571669969933E100d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        try {
            double double7 = regulaFalsiSolver3.solve(0, univariateRealFunction5, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 32);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) 100);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        double double3 = org.apache.commons.math.util.MathUtils.round((double) 5200L, (int) (short) 0, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5200.0d + "'", double3 == 5200.0d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(2.99822295029797d, 0, 70);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232920103324d + "'", double1 == 11013.232920103324d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        double[] doubleArray3 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray10 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        double[][] doubleArray12 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray10, doubleArray12);
        double[] doubleArray17 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray24 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray24);
        double[][] doubleArray26 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray24, doubleArray26);
        double[] doubleArray31 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray38 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double39 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray31, doubleArray38);
        double[][] doubleArray40 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray38, doubleArray40);
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray38);
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray10, doubleArray38);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray10);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray10, (int) (short) 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection47 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        try {
            boolean boolean50 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10, orderDirection47, false, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not decreasing (-1 < 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 90.0d + "'", double25 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 90.0d + "'", double39 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + orderDirection47 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection47.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, 0.0d, 1.7453292519943295d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 70L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 70, (double) (-1.0f));
        double double3 = regulaFalsiSolver2.getFunctionValueAccuracy();
        double double4 = regulaFalsiSolver2.getRelativeAccuracy();
        double double5 = regulaFalsiSolver2.getAbsoluteAccuracy();
        double double6 = regulaFalsiSolver2.getMin();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction8 = null;
        try {
            double double11 = regulaFalsiSolver2.solve((int) (short) 100, univariateRealFunction8, Double.NEGATIVE_INFINITY, 0.01895699404389834d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 70.0d + "'", double4 == 70.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 7766279631452241920L);
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution7 = org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE;
        try {
            double double8 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(70, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver3, (-2.19871080577E11d), (double) 3, (-11.0d), allowedSolution7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + allowedSolution7 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE + "'", allowedSolution7.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-209568959), (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        double double1 = org.apache.commons.math.util.MathUtils.sign(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(100.0d);
        double double2 = regulaFalsiSolver1.getAbsoluteAccuracy();
        double double3 = regulaFalsiSolver1.getFunctionValueAccuracy();
        double double4 = regulaFalsiSolver1.getFunctionValueAccuracy();
        double double5 = regulaFalsiSolver1.getAbsoluteAccuracy();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-15d + "'", double4 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, (java.lang.Number) 1731268350, (java.lang.Number) (-1L), false);
        java.lang.Throwable[] throwableArray12 = numberIsTooLargeException11.getSuppressed();
        org.apache.commons.math.exception.NoBracketingException noBracketingException13 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (double) 52L, 0.5188787072485352d, (double) (-10), (double) 10, (java.lang.Object[]) throwableArray12);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats0, localizable1, (java.lang.Object[]) throwableArray12);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertNotNull(throwableArray12);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 70.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2577193354595834E30d + "'", double1 == 1.2577193354595834E30d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 209568959L, (float) (-127), (float) 1L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        long long2 = org.apache.commons.math.util.FastMath.max(35L, (long) 70);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 70L + "'", long2 == 70L);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.0f, (float) (-385L), 3.43666688E8f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1731268350, (java.lang.Number) (-1L), false);
        java.lang.Number number5 = numberIsTooLargeException4.getArgument();
        boolean boolean6 = numberIsTooLargeException4.getBoundIsAllowed();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE;
        java.lang.Object[] objArray12 = new java.lang.Object[] { 10, 10L };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException13 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (java.lang.Number) 1731268350, objArray12);
        java.lang.Object[] objArray14 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray12);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException15 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooLargeException4, (org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray14);
        java.lang.Number number16 = numberIsTooLargeException4.getArgument();
        boolean boolean17 = numberIsTooLargeException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1731268350 + "'", number5.equals(1731268350));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 1731268350 + "'", number16.equals(1731268350));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 39916800L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException(0, (int) (byte) 10);
        int int3 = dimensionMismatchException2.getDimension();
        int int4 = dimensionMismatchException2.getDimension();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.5188787072485352d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8683757821044538d + "'", double1 == 0.8683757821044538d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        double[] doubleArray3 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray10 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        java.lang.Class<?> wildcardClass12 = doubleArray3.getClass();
        double[] doubleArray16 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray23 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double24 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray16, doubleArray23);
        double[][] doubleArray25 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray23, doubleArray25);
        double[] doubleArray30 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray37 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double38 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray30, doubleArray37);
        double[][] doubleArray39 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray37, doubleArray39);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray37);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray23);
        double[] doubleArray46 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray53 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double54 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray46, doubleArray53);
        double[][] doubleArray55 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray53, doubleArray55);
        double[] doubleArray60 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray67 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double68 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray60, doubleArray67);
        double[][] doubleArray69 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray67, doubleArray69);
        double double71 = org.apache.commons.math.util.MathUtils.distance1(doubleArray53, doubleArray67);
        double[] doubleArray72 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray53);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray72);
        double double74 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray23, doubleArray72);
        double[] doubleArray76 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, 100.0d);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray76);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (100 >= 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 90.0d + "'", double24 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 90.0d + "'", double38 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 90.0d + "'", double54 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 90.0d + "'", double68 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 1126.0d + "'", double74 == 1126.0d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(100.0d);
        double double2 = regulaFalsiSolver1.getAbsoluteAccuracy();
        double double3 = regulaFalsiSolver1.getStartValue();
        double double4 = regulaFalsiSolver1.getMax();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        double double2 = org.apache.commons.math.util.FastMath.min(18.89021302363088d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 3, 1.6929693744344998d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) '#');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 35.000004f + "'", float1 == 35.000004f);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_RESULT_AVAILABLE;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number1);
        boolean boolean3 = notPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_RESULT_AVAILABLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_RESULT_AVAILABLE));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        int int1 = org.apache.commons.math.util.MathUtils.hash(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2146435072 + "'", int1 == 2146435072);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((-2.19871080577E11d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(70);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 230.43904356577696d + "'", double1 == 230.43904356577696d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_BOTTH_ZERO_FOR_ENTRY;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 70, (java.lang.Number) 0.4451963704655766d, true);
        boolean boolean5 = numberIsTooSmallException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_BOTTH_ZERO_FOR_ENTRY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_BOTTH_ZERO_FOR_ENTRY));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(10.0f, 1.07793613E9f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 100L, (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-1023));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) 198L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.5258789E-5f + "'", float1 == 1.5258789E-5f);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 70);
        int int2 = regulaFalsiSolver1.getEvaluations();
        double double3 = regulaFalsiSolver1.getStartValue();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        try {
            double double7 = regulaFalsiSolver1.solve((int) (byte) -1, univariateRealFunction5, (double) 4024981426554L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        double[] doubleArray3 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray10 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 70L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2217304763960306d + "'", double1 == 1.2217304763960306d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1077936128, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 52L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }
}

