import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        double double1 = org.apache.commons.math.util.FastMath.atanh(100.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval(21.965267307681675d, (double) 0L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [21.965, 0]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        double[] doubleArray3 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray10 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        double[][] doubleArray12 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray10, doubleArray12);
        double[] doubleArray17 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray24 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray24);
        double[][] doubleArray26 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray24, doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray24);
        double[] doubleArray29 = null;
        try {
            double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 90.0d + "'", double25 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        double[] doubleArray6 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray13 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double14 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray13);
        double[][] doubleArray15 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray13, doubleArray15);
        double[] doubleArray20 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray27 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray27);
        double[][] doubleArray29 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray27, doubleArray29);
        double[] doubleArray34 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray41 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double42 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray41);
        double[][] doubleArray43 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray41, doubleArray43);
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray41);
        double double46 = org.apache.commons.math.util.MathUtils.distance(doubleArray13, doubleArray41);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection47 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[] doubleArray51 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray58 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double59 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray51, doubleArray58);
        double[][] doubleArray60 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray58, doubleArray60);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray41, orderDirection47, doubleArray60);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection63 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        boolean boolean66 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray41, orderDirection63, false, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException68 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97L, (java.lang.Number) 3.4965075614664802d, 1, orderDirection63, false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 90.0d + "'", double14 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 90.0d + "'", double28 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 90.0d + "'", double42 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection47 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection47.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 90.0d + "'", double59 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + orderDirection63 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection63.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        int[] intArray3 = new int[] { (byte) 0, (byte) -1, 100 };
        int[] intArray4 = org.apache.commons.math.util.MathUtils.copyOf(intArray3);
        int[] intArray5 = org.apache.commons.math.util.MathUtils.copyOf(intArray4);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) intArray4);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(3.4965075614664802d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction3 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution7 = org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE;
        try {
            double double8 = regulaFalsiSolver1.solve((int) '4', univariateRealFunction3, (double) '#', 1.427957018610231E93d, 100.0d, allowedSolution7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + allowedSolution7 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE + "'", allowedSolution7.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint(4.672343674754381d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.3361718373771905d + "'", double2 == 2.3361718373771905d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isBracketing(univariateRealFunction0, 1.1044889974911132d, 19.049875621120893d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) (byte) 1, 99);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 6.338253E29f + "'", float2 == 6.338253E29f);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.007770142482552752d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4451963704655766d + "'", double1 == 0.4451963704655766d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException(0, (int) (byte) 10);
        int int3 = dimensionMismatchException2.getDimension();
        java.lang.Number number4 = dimensionMismatchException2.getArgument();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        double double2 = org.apache.commons.math.util.FastMath.copySign(1.201855897199358E19d, 1.201855897199358E19d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.201855897199358E19d + "'", double2 == 1.201855897199358E19d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-51938.68429423033d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-906.5010500881865d) + "'", double1 == (-906.5010500881865d));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.4451963704655766d, 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.004451711715313271d + "'", double2 == 0.004451711715313271d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination(1.1044889974911132d, (double) 97, 33.555923471125034d, 1097.0d, 2.9802322387695312E-8d, 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 36917.9834805808d + "'", double6 == 36917.9834805808d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 52);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-993337088));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(2.9802322387695312E-8d);
        int int2 = regulaFalsiSolver1.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination((double) (short) 1, 0.018956994043898345d, 1.1044889974911132d, 2.302585092994046d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.562136895042874d + "'", double4 == 2.562136895042874d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence((double) 100.0f, (double) 19206, 4.440892098500626E-16d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [19,206, 0]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 64.5d);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 'a', (byte) 10 };
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (-1.0f), (org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray11);
        org.apache.commons.math.exception.NoBracketingException noBracketingException13 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, 2.302585092994046d, 0.0d, 0.8862395404791882d, (double) 10, objArray11);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS;
        double[] doubleArray18 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray25 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double26 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray18, doubleArray25);
        double[][] doubleArray27 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray25, doubleArray27);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException29 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) noBracketingException13, (org.apache.commons.math.exception.util.Localizable) localizedFormats14, (java.lang.Object[]) doubleArray27);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE;
        java.lang.Object[] objArray34 = new java.lang.Object[] { 10, 10L };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException35 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats30, (java.lang.Number) 1731268350, objArray34);
        org.apache.commons.math.exception.MathInternalError mathInternalError36 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) maxCountExceededException35);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext37 = mathInternalError36.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext38 = mathInternalError36.getContext();
        noBracketingException13.addSuppressed((java.lang.Throwable) mathInternalError36);
        double double40 = noBracketingException13.getFLo();
        double double41 = noBracketingException13.getLo();
        maxCountExceededException1.addSuppressed((java.lang.Throwable) noBracketingException13);
        java.lang.Number number43 = maxCountExceededException1.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 90.0d + "'", double26 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE + "'", localizedFormats30.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE));
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(exceptionContext37);
        org.junit.Assert.assertNotNull(exceptionContext38);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.8862395404791882d + "'", double40 == 0.8862395404791882d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 2.302585092994046d + "'", double41 == 2.302585092994046d);
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + 64.5d + "'", number43.equals(64.5d));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        double double2 = org.apache.commons.math.util.FastMath.copySign((-0.017453292519943295d), (-11.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.017453292519943295d) + "'", double2 == (-0.017453292519943295d));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-1), (double) 97);
        int int3 = regulaFalsiSolver2.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        try {
            java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger3);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 209568959);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, (double) (byte) 0, (double) 213431353344L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        double double1 = org.apache.commons.math.util.FastMath.abs(6.283185307179587d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.283185307179587d + "'", double1 == 6.283185307179587d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(41608.450475834834d, (double) 213431353344L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 0.0d, 4.440892098500626E-16d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_INTERVAL_INITIAL_VALUE_PARAMETERS;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_INTERVAL_INITIAL_VALUE_PARAMETERS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_INTERVAL_INITIAL_VALUE_PARAMETERS));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        int int1 = org.apache.commons.math.util.MathUtils.sign(99);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 3.8146973E-6f, 1.2039980656902276d, (-32768.0d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        double double1 = org.apache.commons.math.util.MathUtils.sign(2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 'a', (byte) 10 };
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (-1.0f), (org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray9);
        org.apache.commons.math.exception.NoBracketingException noBracketingException11 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 2.302585092994046d, 0.0d, 0.8862395404791882d, (double) 10, objArray9);
        double double12 = noBracketingException11.getHi();
        double double13 = noBracketingException11.getLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.302585092994046d + "'", double13 == 2.302585092994046d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        double[] doubleArray3 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray10 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        double[][] doubleArray12 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray10, doubleArray12);
        double[] doubleArray17 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray24 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray24);
        double[][] doubleArray26 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray24, doubleArray26);
        double[] doubleArray31 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray38 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double39 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray31, doubleArray38);
        double[][] doubleArray40 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray38, doubleArray40);
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray38);
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray10, doubleArray38);
        double[] doubleArray47 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray54 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray47, doubleArray54);
        double[][] doubleArray56 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray54, doubleArray56);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray10, doubleArray54);
        double[] doubleArray62 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray69 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double70 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray62, doubleArray69);
        double[][] doubleArray71 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray69, doubleArray71);
        double[] doubleArray76 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray83 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double84 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray76, doubleArray83);
        double[][] doubleArray85 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray83, doubleArray85);
        double double87 = org.apache.commons.math.util.MathUtils.distance1(doubleArray69, doubleArray83);
        double[] doubleArray88 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray69);
        double double89 = org.apache.commons.math.util.MathUtils.distance1(doubleArray54, doubleArray69);
        double[] doubleArray91 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray54, 19206);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 90.0d + "'", double25 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 90.0d + "'", double39 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 90.0d + "'", double55 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 90.0d + "'", double70 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 90.0d + "'", double84 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray91);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence(100.0d, 0.0d, 1.8491431899952486d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [100, 0]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        double[] doubleArray3 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray10 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        double[][] doubleArray12 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray10, doubleArray12);
        double[] doubleArray17 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray24 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray24);
        double[][] doubleArray26 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray24, doubleArray26);
        double[] doubleArray31 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray38 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double39 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray31, doubleArray38);
        double[][] doubleArray40 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray38, doubleArray40);
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray38);
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray10, doubleArray38);
        double[] doubleArray47 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray54 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray47, doubleArray54);
        double[][] doubleArray56 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray54, doubleArray56);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray10, doubleArray54);
        double[] doubleArray62 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray69 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double70 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray62, doubleArray69);
        double[][] doubleArray71 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray69, doubleArray71);
        double[] doubleArray76 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray83 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double84 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray76, doubleArray83);
        double[][] doubleArray85 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray83, doubleArray85);
        double double87 = org.apache.commons.math.util.MathUtils.distance1(doubleArray69, doubleArray83);
        double[] doubleArray88 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray69);
        double double89 = org.apache.commons.math.util.MathUtils.distance1(doubleArray54, doubleArray69);
        double[] doubleArray90 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray54);
        double[] doubleArray91 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray90);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 90.0d + "'", double25 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 90.0d + "'", double39 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 90.0d + "'", double55 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 90.0d + "'", double70 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 90.0d + "'", double84 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertNotNull(doubleArray91);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        double double1 = org.apache.commons.math.util.FastMath.ulp(100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger7 = null;
        try {
            java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isBracketing(univariateRealFunction0, 0.0d, (double) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 198L, (-1731268351));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "cannot compute 0-th root of unity, indefinite result" + "'", str1.equals("cannot compute 0-th root of unity, indefinite result"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(100.0d);
        double double2 = regulaFalsiSolver1.getStartValue();
        double double3 = regulaFalsiSolver1.getMax();
        double double4 = regulaFalsiSolver1.getFunctionValueAccuracy();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-15d + "'", double4 == 1.0E-15d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double1 = regulaFalsiSolver0.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction3 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution7 = org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE;
        try {
            double double8 = regulaFalsiSolver0.solve((int) '#', univariateRealFunction3, 1.570796446004186d, (-51938.68429423033d), (double) '4', allowedSolution7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-15d + "'", double1 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + allowedSolution7 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE + "'", allowedSolution7.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_SELF_ADJOINT_LINEAR_OPERATOR;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException2 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_SELF_ADJOINT_LINEAR_OPERATOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_SELF_ADJOINT_LINEAR_OPERATOR));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, (java.lang.Number) 1731268350, (java.lang.Number) (-1L), false);
        java.lang.Throwable[] throwableArray15 = numberIsTooLargeException14.getSuppressed();
        org.apache.commons.math.exception.NoBracketingException noBracketingException16 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (double) 52L, 0.5188787072485352d, (double) (-10), (double) 10, (java.lang.Object[]) throwableArray15);
        org.apache.commons.math.exception.NoBracketingException noBracketingException17 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) 1.0000001f, 100.0d, 1.5430806348152437d, (double) 70.0f, (java.lang.Object[]) throwableArray15);
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException19 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 1.100747554766916d);
        noBracketingException17.addSuppressed((java.lang.Throwable) tooManyEvaluationsException19);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertNotNull(throwableArray15);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 7766279631452241919L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence((-51938.68429423033d), (double) (short) 10, 1.8184464592320668d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [10, 1.818]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FRACTION;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FRACTION));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (-1));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        long long1 = org.apache.commons.math.util.FastMath.abs((-2305258549L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2305258549L + "'", long1 == 2305258549L);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.9126365759632116d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.015928513124685382d + "'", double1 == 0.015928513124685382d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount((int) '4');
        int int3 = incrementor0.getMaximalCount();
        incrementor0.incrementCount((-1337003777));
        int int6 = incrementor0.getCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        long long1 = org.apache.commons.math.util.MathUtils.sign(213431353344L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (double) (short) 100, (double) 98L, (double) 100L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        double double1 = org.apache.commons.math.util.FastMath.abs(2.350016302011459d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.350016302011459d + "'", double1 == 2.350016302011459d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(99, (-127));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28) + "'", int2 == (-28));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        double double1 = org.apache.commons.math.util.FastMath.atanh(3.948148009134034E13d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (short) 10, 0.018956994043898345d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.018956994043898345d + "'", double2 == 0.018956994043898345d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Number) 1731268350, (java.lang.Number) (-1L), false);
        java.lang.Throwable[] throwableArray10 = numberIsTooLargeException9.getSuppressed();
        org.apache.commons.math.exception.NoBracketingException noBracketingException11 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) 52L, 0.5188787072485352d, (double) (-10), (double) 10, (java.lang.Object[]) throwableArray10);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.LENGTH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH;
        java.lang.Object[] objArray20 = new java.lang.Object[] { localizedFormats14, localizedFormats15, 100.0d, 100, localizedFormats18, localizedFormats19 };
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException21 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats13, objArray20);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException22 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, objArray20);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException27 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (short) 1, (java.lang.Number) 7766279631452241919L, true);
        java.lang.Throwable[] throwableArray28 = numberIsTooSmallException27.getSuppressed();
        java.lang.Object[] objArray29 = org.apache.commons.math.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray28);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException30 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, (java.lang.Number) 1731263161L, (java.lang.Object[]) throwableArray28);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException31 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray28);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LENGTH + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.LENGTH));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertNotNull(objArray29);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) '#', (int) (byte) 100, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 1L, (float) 2305258549L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        long long2 = org.apache.commons.math.util.MathUtils.pow(198L, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        double double2 = org.apache.commons.math.util.FastMath.hypot(7.001245622069476d, (double) 1.5370264E31f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5370263527767281E31d + "'", double2 == 1.5370263527767281E31d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.065817517094494E67d + "'", double1 == 8.065817517094494E67d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) 213431353344L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 16384.0f + "'", float1 == 16384.0f);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(209568959, (int) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 578.4835406645935d + "'", double2 == 578.4835406645935d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(4.672343674754381d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.672343674754382d + "'", double1 == 4.672343674754382d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-1071382528));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.138569709845675E10d) + "'", double1 == (-6.138569709845675E10d));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 1.0f, 0.0d, 2.246067844446904d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        double double1 = org.apache.commons.math.util.FastMath.sinh(104.94810050208545d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8938733752369803E45d + "'", double1 == 1.8938733752369803E45d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, 35);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, (-1.2876178137472069E-19d), 2.99822295029797d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(100.0d);
        double double2 = regulaFalsiSolver1.getStartValue();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        try {
            double double7 = regulaFalsiSolver1.solve((int) (byte) 0, univariateRealFunction4, Double.NaN, (double) 70.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(2.2250738585072014E-308d, (double) 'a');
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        try {
            double double8 = regulaFalsiSolver2.solve(1731268350, univariateRealFunction4, (-0.0d), 2.562136895042874d, (double) 10L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97.0d, (java.lang.Number) (-1.4E-45f), (int) ' ');
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, 1731268350);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        double double2 = org.apache.commons.math.util.FastMath.copySign((double) (short) -1, 0.018956994043898345d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.2217304763960306d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.105319173992757d + "'", double1 == 1.105319173992757d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 70, (double) (-1.0f));
        double double3 = regulaFalsiSolver2.getFunctionValueAccuracy();
        double double4 = regulaFalsiSolver2.getMin();
        double double5 = regulaFalsiSolver2.getRelativeAccuracy();
        double double6 = regulaFalsiSolver2.getFunctionValueAccuracy();
        double double7 = regulaFalsiSolver2.getStartValue();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 70.0d + "'", double5 == 70.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-15d + "'", double6 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence(1.1920928955078125E-7d, 19206.0d, (double) 52.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [19,206, 52]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval(104.94810050208545d, (double) 35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [104.948, 35]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) (-1), (int) ' ');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-4.2949673E9f) + "'", float2 == (-4.2949673E9f));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6313083693369503E35d + "'", double1 == 2.6313083693369503E35d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-3.831008000716671E22d), (java.lang.Number) 99.99999999999999d, (int) (byte) 10, orderDirection3, false);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext7 = new org.apache.commons.math.exception.util.ExceptionContext();
        exceptionContext7.setValue("", (java.lang.Object) (-10));
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats22, (java.lang.Number) 1731268350, (java.lang.Number) (-1L), false);
        java.lang.Throwable[] throwableArray27 = numberIsTooLargeException26.getSuppressed();
        org.apache.commons.math.exception.NoBracketingException noBracketingException28 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats17, (double) 52L, 0.5188787072485352d, (double) (-10), (double) 10, (java.lang.Object[]) throwableArray27);
        org.apache.commons.math.exception.NoBracketingException noBracketingException29 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, (double) 1.0000001f, 100.0d, 1.5430806348152437d, (double) 70.0f, (java.lang.Object[]) throwableArray27);
        exceptionContext7.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats11, (java.lang.Object[]) throwableArray27);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException31 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) nonMonotonousSequenceException5, (org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Object[]) throwableArray27);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS));
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertNull(orderDirection32);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        double double1 = org.apache.commons.math.util.FastMath.log1p(4.930380657631324E-32d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.930380657631324E-32d + "'", double1 == 4.930380657631324E-32d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((double) Float.NaN);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1024 + "'", int1 == 1024);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.0d, (int) (byte) 10, (-1071382528));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 213431353344L, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.570796326799582d + "'", double2 == 1.570796326799582d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-993337088), 1024);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 1,024, n = -993,337,088");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((int) (byte) 1, (int) (short) -1);
        int int3 = dimensionMismatchException2.getDimension();
        int int4 = dimensionMismatchException2.getDimension();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ABSCISSA;
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException7 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) dimensionMismatchException2, (org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray6);
        double[] doubleArray11 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray18 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double19 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray18);
        double[][] doubleArray20 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray18, doubleArray20);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException22 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Object[]) doubleArray20);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ABSCISSA + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ABSCISSA));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 90.0d + "'", double19 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        double double3 = org.apache.commons.math.util.MathUtils.reduce(4.672343674754382d, (double) 0.0f, (double) 3);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 99, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 99.0d + "'", double2 == 99.0d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        long long1 = org.apache.commons.math.util.MathUtils.sign((-1L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-10), 1731268351);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1731268341 + "'", int2 == 1731268341);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (short) 10, 1.5258789E-5f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.5258789E-5f + "'", float2 == 1.5258789E-5f);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        double double2 = org.apache.commons.math.util.FastMath.hypot(138.85278649903591d, 0.03467570824850382d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 138.8527908288184d + "'", double2 == 138.8527908288184d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.4E-45f, (float) 32, (float) 39916800L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        double double1 = org.apache.commons.math.util.FastMath.cos(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8390715290764524d) + "'", double1 == (-0.8390715290764524d));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence(138.85278649903591d, (double) 2305258549L, 1.3440585709080678E43d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        double[] doubleArray3 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray10 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        double[][] doubleArray12 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray10, doubleArray12);
        double[] doubleArray17 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray24 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray24);
        double[][] doubleArray26 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray24, doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray24);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray10);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray29);
        double[] doubleArray34 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray41 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double42 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray41);
        double[][] doubleArray43 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray41, doubleArray43);
        double[] doubleArray48 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray55 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double56 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray48, doubleArray55);
        double[][] doubleArray57 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray55, doubleArray57);
        double double59 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray55);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection60 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[] doubleArray64 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray71 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double72 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray64, doubleArray71);
        double[][] doubleArray73 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray71, doubleArray73);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray41, orderDirection60, doubleArray73);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray29, doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 90.0d + "'", double25 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 90.0d + "'", double42 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 90.0d + "'", double56 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection60 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection60.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 90.0d + "'", double72 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray73);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        long long2 = org.apache.commons.math.util.FastMath.max((-1024L), 70L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 70L + "'", long2 == 70L);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((-0.6321205588285577d), 1.100747554766916d, 0.0d, 7.001245622069476d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 1.4E-45f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.401298464324817E-45d + "'", double1 == 1.401298464324817E-45d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        float float2 = org.apache.commons.math.util.FastMath.scalb(16384.0f, (int) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 7.3786976E19f + "'", float2 == 7.3786976E19f);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        double double2 = org.apache.commons.math.util.FastMath.copySign((double) (-993337088), (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.93337088E8d + "'", double2 == 9.93337088E8d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-2.305258549E9d), 11, 1731268350);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) 0.5403023058681395d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 9L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 9 + "'", int1 == 9);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException2 = new org.apache.commons.math.exception.NullArgumentException(localizable0, objArray1);
        try {
            org.apache.commons.math.exception.MathInternalError mathInternalError3 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) nullArgumentException2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(97L, (-385L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-288L) + "'", long2 == (-288L));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) 1731268350, (java.lang.Number) (-1L), false);
        java.lang.Throwable[] throwableArray7 = numberIsTooLargeException6.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) throwableArray7);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException9 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray7);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext10 = mathArithmeticException9.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext11 = mathArithmeticException9.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(exceptionContext10);
        org.junit.Assert.assertNotNull(exceptionContext11);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        double[] doubleArray3 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray10 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        double[][] doubleArray12 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray10, doubleArray12);
        double[] doubleArray17 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray24 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray24);
        double[][] doubleArray26 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray24, doubleArray26);
        double[] doubleArray31 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray38 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double39 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray31, doubleArray38);
        double[][] doubleArray40 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray38, doubleArray40);
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray38);
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray10, doubleArray38);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray10);
        double[] doubleArray45 = new double[] {};
        try {
            double double46 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray10, doubleArray45);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 6 != 0");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 90.0d + "'", double25 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 90.0d + "'", double39 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(10, 1024);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1014) + "'", int2 == (-1014));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(16384.0f, (-10), (-993337088));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathIllegalArgumentException; message: invalid rounding method -993,337,088, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        double double2 = org.apache.commons.math.util.FastMath.hypot((double) 343666689, 52.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.4366668900000393E8d + "'", double2 == 3.4366668900000393E8d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-288L), 19206L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-5531328L) + "'", long2 == (-5531328L));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 70);
        double double2 = regulaFalsiSolver1.getFunctionValueAccuracy();
        double double3 = regulaFalsiSolver1.getMax();
        double double4 = regulaFalsiSolver1.getFunctionValueAccuracy();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-15d + "'", double2 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-15d + "'", double4 == 1.0E-15d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-28));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        double[] doubleArray3 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray10 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        double[][] doubleArray12 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray10, doubleArray12);
        double[] doubleArray17 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray24 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray24);
        double[][] doubleArray26 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray24, doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray24);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray10);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 90.0d + "'", double25 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        int int2 = org.apache.commons.math.util.FastMath.max(343666689, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 343666689 + "'", int2 == 343666689);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1731268341, (-209568959));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.LENGTH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH;
        java.lang.Object[] objArray8 = new java.lang.Object[] { localizedFormats2, localizedFormats3, 100.0d, 100, localizedFormats6, localizedFormats7 };
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException9 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray8);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException10 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray8);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, (java.lang.Number) 19206.0d, (java.lang.Number) 90.0d, false);
        mathArithmeticException10.addSuppressed((java.lang.Throwable) numberIsTooLargeException15);
        java.lang.Number number17 = numberIsTooLargeException15.getMax();
        java.lang.Number number18 = numberIsTooLargeException15.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LENGTH + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.LENGTH));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 90.0d + "'", number17.equals(90.0d));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 90.0d + "'", number18.equals(90.0d));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(10, (-993337088));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        double[] doubleArray3 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray10 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        java.lang.Class<?> wildcardClass12 = doubleArray3.getClass();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (100 >= 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        double[] doubleArray3 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray10 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        double[][] doubleArray12 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray10, doubleArray12);
        double[] doubleArray17 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray24 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray24);
        double[][] doubleArray26 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray24, doubleArray26);
        double[] doubleArray31 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray38 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double39 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray31, doubleArray38);
        double[][] doubleArray40 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray38, doubleArray40);
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray38);
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray10, doubleArray38);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection44 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        boolean boolean47 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10, orderDirection44, true, false);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray10);
        double[] doubleArray52 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray59 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double60 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray52, doubleArray59);
        double[][] doubleArray61 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray59, doubleArray61);
        double[] doubleArray66 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray73 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double74 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray66, doubleArray73);
        double[][] doubleArray75 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray73, doubleArray75);
        double[] doubleArray80 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray87 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double88 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray80, doubleArray87);
        double[][] doubleArray89 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray87, doubleArray89);
        double double91 = org.apache.commons.math.util.MathUtils.distance1(doubleArray73, doubleArray87);
        double double92 = org.apache.commons.math.util.MathUtils.distance(doubleArray59, doubleArray87);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray59);
        double[] doubleArray95 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray59, (int) (short) 100);
        try {
            double double96 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray10, doubleArray95);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 6 != 100");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 90.0d + "'", double25 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 90.0d + "'", double39 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection44 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection44.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 33.555923471125034d + "'", double48 == 33.555923471125034d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 90.0d + "'", double60 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 90.0d + "'", double74 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 90.0d + "'", double88 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray95);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (-1071382528));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1023.2494500120577d) + "'", double1 == (-1023.2494500120577d));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double1 = regulaFalsiSolver0.getStartValue();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 10, 10L };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException10 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Number) 1731268350, objArray9);
        java.lang.Object[] objArray11 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray9);
        org.apache.commons.math.exception.NoBracketingException noBracketingException12 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 0.9999999958776927d, (double) (byte) -1, (double) 100.0f, (double) 1.0f, objArray9);
        double double13 = noBracketingException12.getFHi();
        double double14 = noBracketingException12.getHi();
        double double15 = noBracketingException12.getHi();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.0d) + "'", double14 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.0d) + "'", double15 == (-1.0d));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.100747554766916d, (java.lang.Number) 0.5403023058681395d, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(209568959);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 10, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(2.302585092994046d, (double) (-1023), 100.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (short) 0, 1731268350);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1731268350 + "'", int2 == 1731268350);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination((double) 35.000004f, 1.7453292519943295d, (double) '#', 6.283185307179587d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 280.9980162289898d + "'", double4 == 280.9980162289898d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        double[] doubleArray3 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray10 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        double[] doubleArray15 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray22 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double23 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray22);
        double[][] doubleArray24 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray22, doubleArray24);
        double[] doubleArray29 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray36 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double37 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray29, doubleArray36);
        double[][] doubleArray38 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray36, doubleArray38);
        double[] doubleArray43 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray50 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double51 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray43, doubleArray50);
        double[][] doubleArray52 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray50, doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray36, doubleArray50);
        double double55 = org.apache.commons.math.util.MathUtils.distance(doubleArray22, doubleArray50);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection56 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        boolean boolean59 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22, orderDirection56, true, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10, orderDirection56, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly decreasing (0 <= 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 90.0d + "'", double23 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 90.0d + "'", double37 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 90.0d + "'", double51 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection56 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection56.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        org.apache.commons.math.util.MathUtils.checkFinite((double) 1.5370264E31f);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(100.0d);
        double double4 = regulaFalsiSolver3.getAbsoluteAccuracy();
        double double5 = regulaFalsiSolver3.getMin();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution9 = org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE;
        try {
            double double10 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((-1014), univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver3, 4.9E-324d, 7.001245622069476d, (double) 11, allowedSolution9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + allowedSolution9 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE + "'", allowedSolution9.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: must have n >= 0 for n!, got n = -1");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (-385L), (double) 1077936128, 1.0E-14d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) (-3.831008000716671E22d), 0, orderDirection3, true);
        int int6 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, (java.lang.Number) 19206.0d, (java.lang.Number) 90.0d, false);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext14 = numberIsTooLargeException13.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (short) 1, (java.lang.Number) 7766279631452241919L, true);
        java.lang.Throwable[] throwableArray20 = numberIsTooSmallException19.getSuppressed();
        exceptionContext14.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats15, (java.lang.Object[]) throwableArray20);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException22 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) nonMonotonousSequenceException5, (org.apache.commons.math.exception.util.Localizable) localizedFormats8, (java.lang.Object[]) throwableArray20);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-3.831008000716671E22d) + "'", number7.equals((-3.831008000716671E22d)));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT));
        org.junit.Assert.assertNotNull(exceptionContext14);
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(throwableArray20);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        double[] doubleArray3 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray10 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        double[][] doubleArray12 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray10, doubleArray12);
        double[] doubleArray17 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray24 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray24);
        double[][] doubleArray26 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray24, doubleArray26);
        double[] doubleArray31 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray38 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double39 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray31, doubleArray38);
        double[][] doubleArray40 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray38, doubleArray40);
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray38);
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray10, doubleArray38);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection44 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        boolean boolean47 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10, orderDirection44, true, false);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray10);
        double[] doubleArray52 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray59 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double60 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray52, doubleArray59);
        double[][] doubleArray61 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray59, doubleArray61);
        double[] doubleArray66 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray73 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double74 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray66, doubleArray73);
        double[][] doubleArray75 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray73, doubleArray75);
        double[] doubleArray80 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray87 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double88 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray80, doubleArray87);
        double[][] doubleArray89 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray87, doubleArray89);
        double double91 = org.apache.commons.math.util.MathUtils.distance1(doubleArray73, doubleArray87);
        double double92 = org.apache.commons.math.util.MathUtils.distance(doubleArray59, doubleArray87);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection93 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        boolean boolean96 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray59, orderDirection93, true, false);
        double double97 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray59);
        double double98 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray59);
        double[] doubleArray99 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 90.0d + "'", double25 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 90.0d + "'", double39 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection44 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection44.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 33.555923471125034d + "'", double48 == 33.555923471125034d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 90.0d + "'", double60 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 90.0d + "'", double74 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 90.0d + "'", double88 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection93 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection93.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 33.555923471125034d + "'", double97 == 33.555923471125034d);
        org.junit.Assert.assertTrue("'" + double98 + "' != '" + 0.0d + "'", double98 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray99);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (byte) -1, (double) (-4.2949673E9f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.1415926533569625d) + "'", double2 == (-3.1415926533569625d));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((-1014), 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1014 + "'", int2 == 1014);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        double double1 = org.apache.commons.math.util.FastMath.log10(7.001245622069476d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8451753141093394d + "'", double1 == 0.8451753141093394d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        double double1 = org.apache.commons.math.util.FastMath.exp(5.699947472046087E100d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        double double1 = org.apache.commons.math.util.MathUtils.sign(2.993222846126381d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        double double1 = org.apache.commons.math.util.FastMath.log1p(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3132616875182228d + "'", double1 == 1.3132616875182228d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) 'a', 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        double double1 = org.apache.commons.math.util.FastMath.abs(11013.232920103324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232920103324d + "'", double1 == 11013.232920103324d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination(22026.465794806718d, 3.4366668900000393E8d, (-2.305258549E9d), 7.685131763883641E30d, 0.01895699404389834d, 1.570796446004186d, 3.141592653589793d, 0.0798317705429828d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.7716215698884212E40d) + "'", double8 == (-1.7716215698884212E40d));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 35);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) '#');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 2.09568959E8d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(1.0000085681055715d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 0.6321206780378472d, 2.246067844446904d, (double) 100, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(3, 1731268351);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 9.536743E-7f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.536743164063946E-7d + "'", double1 == 9.536743164063946E-7d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        double double1 = org.apache.commons.math.util.FastMath.asinh(9.93337088E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.40972780921419d + "'", double1 == 21.40972780921419d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 100L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DATA;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) 100);
        org.apache.commons.math.exception.MathInternalError mathInternalError3 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) notStrictlyPositiveException2);
        java.lang.Number number4 = notStrictlyPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DATA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DATA));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-1014), 3.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1731268350, (long) 11);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-4558301418543122432L) + "'", long2 == (-4558301418543122432L));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) 7766279631452241920L, (float) (short) -1, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "parameters relative tolerance is too small ({0}), no further improvement in the approximate solution is possible" + "'", str1.equals("parameters relative tolerance is too small ({0}), no further improvement in the approximate solution is possible"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-10), (java.lang.Number) (-51938.68429423033d), true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-51938.68429423033d) + "'", number4.equals((-51938.68429423033d)));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((float) 52, (float) 3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) (-2305258549L), 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-2.3052585E9f) + "'", float2 == (-2.3052585E9f));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 99, (float) 3);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 99.0f + "'", float2 == 99.0f);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-209568959));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: must have n >= 0 for n!, got n = -209,568,959");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 35.000004f);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-1023));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: must have n >= 0 for n!, got n = -1,023");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 70, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.0001796891927d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getMaxEvaluations();
        double double2 = regulaFalsiSolver0.getMax();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 19206L, 3.43666688E8f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 19206.0f + "'", float2 == 19206.0f);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(64.5d, 0.5403023058681395d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 64.49999999999999d + "'", double2 == 64.49999999999999d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination(0.0d, (double) (-2.3052585E9f), 20.79831393939627d, 0.0d, 0.6389139850038871d, (double) (-2.30525824E9f));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.4728617285814471E9d) + "'", double6 == (-1.4728617285814471E9d));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        double double2 = org.apache.commons.math.util.MathUtils.round(35.0d, 11);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (-28));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-27.999999999999996d) + "'", double1 == (-27.999999999999996d));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) 52L, (-2.30525824E9f), (float) 1024);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(209568959, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 209568959 + "'", int2 == 209568959);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(Double.NEGATIVE_INFINITY, (double) (short) 100);
        double double3 = regulaFalsiSolver2.getMax();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        double double2 = org.apache.commons.math.util.FastMath.max(0.36787944117144233d, (double) (-993337088));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.36787944117144233d + "'", double2 == 0.36787944117144233d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 1.5258789E-5f);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        int int2 = org.apache.commons.math.util.FastMath.max(2146435072, 1731268351);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2146435072 + "'", int2 == 2146435072);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 41608.450475834834d, 0.0d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) (byte) -1, (double) 1024);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-0.99999994f) + "'", float2 == (-0.99999994f));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) (-2305258549L), 35);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-7.920808E19f) + "'", float2 == (-7.920808E19f));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-1071382528), (long) (-1071382528));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1147860521303670784L + "'", long2 == 1147860521303670784L);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.incrementCount((int) (short) 0);
        int int3 = incrementor0.getCount();
        try {
            incrementor0.incrementCount();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) 9L, (float) (-1731268351), 3);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        float float1 = org.apache.commons.math.util.MathUtils.indicator(1.5370264E31f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 0.0d, 1.2217304763960306d, Double.NEGATIVE_INFINITY, 99);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) (-1731268351), (-1), 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.73126835E9f) + "'", float3 == (-1.73126835E9f));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 99);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext0 = new org.apache.commons.math.exception.util.ExceptionContext();
        java.util.Set<java.lang.String> strSet1 = exceptionContext0.getKeys();
        java.util.Set<java.lang.String> strSet2 = exceptionContext0.getKeys();
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) strSet2);
        org.junit.Assert.assertNotNull(strSet1);
        org.junit.Assert.assertNotNull(strSet2);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 52, 2305258549L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 119873444548L + "'", long2 == 119873444548L);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        double double2 = org.apache.commons.math.util.FastMath.min(0.004425697988050785d, (-6.138569709845675E10d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-6.138569709845675E10d) + "'", double2 == (-6.138569709845675E10d));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_RESULT_AVAILABLE;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number1);
        java.lang.Number number3 = notPositiveException2.getArgument();
        boolean boolean4 = notPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_RESULT_AVAILABLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_RESULT_AVAILABLE));
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) (byte) 100, 3);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 161700.0d + "'", double2 == 161700.0d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 1731268350);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 41608.51295107769d + "'", double1 == 41608.51295107769d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        int int2 = org.apache.commons.math.util.FastMath.min(11, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-993337088), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-993337088L) + "'", long2 == (-993337088L));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        double[] doubleArray3 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray10 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 10000000000L);
        double[] doubleArray17 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray24 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray24);
        double[][] doubleArray26 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray24, doubleArray26);
        double[] doubleArray31 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray38 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double39 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray31, doubleArray38);
        double[][] doubleArray40 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray38, doubleArray40);
        double[] doubleArray45 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray52 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double53 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray45, doubleArray52);
        double[][] doubleArray54 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray52, doubleArray54);
        double double56 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray52);
        double double57 = org.apache.commons.math.util.MathUtils.distance(doubleArray24, doubleArray52);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection58 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        boolean boolean61 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24, orderDirection58, true, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3, orderDirection58, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not decreasing (0 < 100)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 90.0d + "'", double25 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 90.0d + "'", double39 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 90.0d + "'", double53 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection58 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection58.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 7.7662794E18f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.7662794365167206E18d + "'", double1 == 7.7662794365167206E18d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5707963267948967d + "'", double1 == 0.5707963267948967d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        double[] doubleArray3 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray10 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        double[][] doubleArray12 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray10, doubleArray12);
        double[] doubleArray17 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray24 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray24);
        double[][] doubleArray26 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray24, doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray24);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray10);
        double[] doubleArray33 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray40 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double41 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray33, doubleArray40);
        double[][] doubleArray42 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray40, doubleArray42);
        double[] doubleArray47 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray54 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray47, doubleArray54);
        double[][] doubleArray56 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray54, doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray54);
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray40);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray59);
        double double61 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray10, doubleArray59);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, 100.0d);
        double[] doubleArray67 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray74 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double75 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray67, doubleArray74);
        double[][] doubleArray76 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray74, doubleArray76);
        double[] doubleArray81 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray88 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double89 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray81, doubleArray88);
        double[][] doubleArray90 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray88, doubleArray90);
        double double92 = org.apache.commons.math.util.MathUtils.distance1(doubleArray74, doubleArray88);
        double[] doubleArray93 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray74);
        boolean boolean94 = org.apache.commons.math.util.MathUtils.equals(doubleArray63, doubleArray93);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray93);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (0 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 90.0d + "'", double25 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 90.0d + "'", double41 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 90.0d + "'", double55 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 1126.0d + "'", double61 == 1126.0d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 90.0d + "'", double75 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 90.0d + "'", double89 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        double[] doubleArray3 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray10 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        double[][] doubleArray12 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray10, doubleArray12);
        double[] doubleArray17 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray24 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray24);
        double[][] doubleArray26 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray24, doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray24);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray10);
        double[] doubleArray33 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray40 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double41 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray33, doubleArray40);
        double[][] doubleArray42 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray40, doubleArray42);
        double[] doubleArray47 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray54 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray47, doubleArray54);
        double[][] doubleArray56 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray54, doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray54);
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray40);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray59);
        double double61 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray10, doubleArray59);
        int int62 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        double[] doubleArray64 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, 1126.0d);
        double double65 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 90.0d + "'", double25 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 90.0d + "'", double41 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 90.0d + "'", double55 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 1126.0d + "'", double61 == 1126.0d);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-209568959) + "'", int62 == (-209568959));
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 33.555923471125034d + "'", double65 == 33.555923471125034d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        double double1 = org.apache.commons.math.util.FastMath.asin((-2.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 1.105319173992757d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-3.831008000716671E22d), (java.lang.Number) 99.99999999999999d, (int) (byte) 10, orderDirection3, false);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext7 = new org.apache.commons.math.exception.util.ExceptionContext();
        exceptionContext7.setValue("", (java.lang.Object) (-10));
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats22, (java.lang.Number) 1731268350, (java.lang.Number) (-1L), false);
        java.lang.Throwable[] throwableArray27 = numberIsTooLargeException26.getSuppressed();
        org.apache.commons.math.exception.NoBracketingException noBracketingException28 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats17, (double) 52L, 0.5188787072485352d, (double) (-10), (double) 10, (java.lang.Object[]) throwableArray27);
        org.apache.commons.math.exception.NoBracketingException noBracketingException29 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, (double) 1.0000001f, 100.0d, 1.5430806348152437d, (double) 70.0f, (java.lang.Object[]) throwableArray27);
        exceptionContext7.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats11, (java.lang.Object[]) throwableArray27);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException31 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) nonMonotonousSequenceException5, (org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Object[]) throwableArray27);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext32 = mathIllegalStateException31.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS));
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertNotNull(exceptionContext32);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 100, 1731268350);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.incrementCount((int) (short) 0);
        try {
            incrementor0.incrementCount(11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination((double) (-1023), 0.0d, (double) 1.4E-45f, 8.56806886553248E-6d, 1.9867717342662448d, 10.04987562112089d, 1.0d, 1.8184464592320668d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 21.78525527616647d + "'", double8 == 21.78525527616647d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        float float2 = org.apache.commons.math.util.FastMath.copySign((float) 35, 6.338253E29f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        double[] doubleArray3 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray10 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        double[][] doubleArray12 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray10, doubleArray12);
        double[] doubleArray17 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray24 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray24);
        double[][] doubleArray26 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray24, doubleArray26);
        double[] doubleArray31 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray38 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double39 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray31, doubleArray38);
        double[][] doubleArray40 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray38, doubleArray40);
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray38);
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray10, doubleArray38);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection44 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[] doubleArray48 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray55 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double56 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray48, doubleArray55);
        double[][] doubleArray57 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray55, doubleArray57);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray38, orderDirection44, doubleArray57);
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray38, 0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 90.0d + "'", double25 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 90.0d + "'", double39 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection44 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection44.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 90.0d + "'", double56 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray61);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        double double2 = org.apache.commons.math.util.FastMath.max(4.930380657631324E-32d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.930380657631324E-32d + "'", double2 == 4.930380657631324E-32d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 19206.0f, (double) 70.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 19206.0d + "'", double2 == 19206.0d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.7182818284590458d), (java.lang.Number) 1.077936E9f, (-1731268351));
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 1014);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0f, (float) 7766279631452241919L, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        float float2 = org.apache.commons.math.util.FastMath.max((-1.4E-45f), 7.7662794E18f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 7.7662794E18f + "'", float2 == 7.7662794E18f);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 99.99999999999999d, 2.0d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint(4.9E-324d, (double) (-1L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.5d) + "'", double2 == (-0.5d));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        double double2 = org.apache.commons.math.util.MathUtils.log(1.0d, 9.93337088E8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1126.0d, (double) 10000000000L, (int) ' ');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        int int2 = org.apache.commons.math.util.MathUtils.pow(11, 1731268341);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-554520869) + "'", int2 == (-554520869));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray0, 1014);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(35);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1731268350, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.NotPositiveException notPositiveException6 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 0.8862395404791882d);
        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) notPositiveException6);
        java.lang.Number number8 = numberIsTooLargeException4.getArgument();
        java.lang.Number number9 = numberIsTooLargeException4.getArgument();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1731268350 + "'", number8.equals(1731268350));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 1731268350 + "'", number9.equals(1731268350));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) 1731268350, (java.lang.Number) (-1L), false);
        java.lang.Throwable[] throwableArray7 = numberIsTooLargeException6.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) throwableArray7);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException9 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray7);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(2.2250738585072014E-308d, (double) 'a');
        double double3 = regulaFalsiSolver2.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        try {
            double double9 = regulaFalsiSolver2.solve(97, univariateRealFunction5, 41608.450475834834d, 64.5d, (double) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-209568959), 1.570796446004186d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        try {
            double double6 = regulaFalsiSolver2.solve((-1337003777), univariateRealFunction4, 21.78525527616647d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 1731268341, (double) 1.1920929E-7f, (-0.6321205588285577d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1077936128, (-2.30525824E9f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.07793613E9f + "'", float2 == 1.07793613E9f);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        double[] doubleArray3 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray10 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        double[][] doubleArray12 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray10, doubleArray12);
        double[] doubleArray17 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray24 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray24);
        double[][] doubleArray26 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray24, doubleArray26);
        double[] doubleArray31 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray38 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double39 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray31, doubleArray38);
        double[][] doubleArray40 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray38, doubleArray40);
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray38);
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray10, doubleArray38);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection44 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        boolean boolean47 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10, orderDirection44, true, false);
        double[] doubleArray54 = new double[] { (byte) 10, 100.0d, 105.94810050208545d, (short) -1, 0.0d, 1L };
        int int55 = org.apache.commons.math.util.MathUtils.hash(doubleArray54);
        int int56 = org.apache.commons.math.util.MathUtils.hash(doubleArray54);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray54);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray10, doubleArray54);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (0 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 90.0d + "'", double25 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 90.0d + "'", double39 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection44 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection44.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1731268350 + "'", int55 == 1731268350);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1731268350 + "'", int56 == 1731268350);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(70.0f, (float) (-127), (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-1), 198L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 198L + "'", long2 == 198L);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 10, 10L };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException10 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Number) 1731268350, objArray9);
        java.lang.Object[] objArray11 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray9);
        org.apache.commons.math.exception.NoBracketingException noBracketingException12 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 52.0d, 3.4965075614664802d, 0.0d, (-2.305258549E9d), objArray9);
        java.lang.Class<?> wildcardClass13 = noBracketingException12.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.5430806348152437d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        double double1 = org.apache.commons.math.util.FastMath.rint((-0.017453292519943295d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        int int2 = org.apache.commons.math.util.MathUtils.pow(10, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((float) 97L, (float) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 19206.0d, (java.lang.Number) 90.0d, false);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        java.lang.String str6 = numberIsTooLargeException4.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 90.0d + "'", number5.equals(90.0d));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: Array contains an infinite element, 19,206 at index 90" + "'", str6.equals("org.apache.commons.math.exception.NumberIsTooLargeException: Array contains an infinite element, 19,206 at index 90"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298342365610589d + "'", double1 == 5.298342365610589d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        float float1 = org.apache.commons.math.util.FastMath.ulp(3.43666688E8f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 32.0f + "'", float1 == 32.0f);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence((double) 1L, 0.0d, (double) (-288L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [1, 0]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        double[] doubleArray3 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray10 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        double[][] doubleArray12 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray10, doubleArray12);
        try {
            double[] doubleArray15 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray10, (-1023));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        double double2 = org.apache.commons.math.util.MathUtils.log(2.99822295029797d, 41608.51295107769d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.686583447271545d + "'", double2 == 9.686583447271545d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        int[] intArray3 = new int[] { (byte) 0, (byte) -1, 100 };
        int[] intArray4 = org.apache.commons.math.util.MathUtils.copyOf(intArray3);
        int[] intArray8 = new int[] { (byte) 0, (byte) -1, 100 };
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray8);
        int[] intArray10 = org.apache.commons.math.util.MathUtils.copyOf(intArray9);
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray10);
        int[] intArray13 = org.apache.commons.math.util.MathUtils.copyOf(intArray10, 1);
        int[] intArray15 = new int[] { (byte) 100 };
        int[] intArray19 = new int[] { (byte) 0, (byte) -1, 100 };
        int[] intArray20 = org.apache.commons.math.util.MathUtils.copyOf(intArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distance(intArray15, intArray19);
        int[] intArray25 = new int[] { (byte) 0, (byte) -1, 100 };
        int[] intArray26 = org.apache.commons.math.util.MathUtils.copyOf(intArray25);
        double double27 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray25);
        double double28 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray25);
        int[] intArray29 = null;
        try {
            int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray25, intArray29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.0000085681055715d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000085681055715d + "'", double1 == 1.0000085681055715d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        try {
            java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-1)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((-4558301418543122432L), (long) (-32));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-4558301418543122400L) + "'", long2 == (-4558301418543122400L));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(9.536743E-7f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-20) + "'", int1 == (-20));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 1.1044889974911132d, (double) 1731263151L, (double) 35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination(Double.POSITIVE_INFINITY, 4.889646032848159E85d, 7.001245622069476d, 0.0d, (double) 19206, 0.0d);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext0 = new org.apache.commons.math.exception.util.ExceptionContext();
        java.util.Set<java.lang.String> strSet1 = exceptionContext0.getKeys();
        java.util.Set<java.lang.String> strSet2 = exceptionContext0.getKeys();
        java.lang.Object obj4 = exceptionContext0.getValue("empty selected column index array");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 'a', (byte) 10 };
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (-1.0f), (org.apache.commons.math.exception.util.Localizable) localizedFormats14, objArray17);
        org.apache.commons.math.exception.NoBracketingException noBracketingException19 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, 2.302585092994046d, 0.0d, 0.8862395404791882d, (double) 10, objArray17);
        java.lang.Object[] objArray20 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray20);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException22 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) (-15.942385152878742d), objArray20);
        exceptionContext0.setValue("statistics constructed from external moments cannot be incremented", (java.lang.Object) objArray20);
        org.junit.Assert.assertNotNull(strSet1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray20);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (byte) 100, (java.lang.Number) 2.384185791015625E-7d, false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        double[] doubleArray3 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray10 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        java.lang.Class<?> wildcardClass12 = doubleArray3.getClass();
        double[] doubleArray16 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray23 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double24 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray16, doubleArray23);
        double[][] doubleArray25 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray23, doubleArray25);
        double[] doubleArray30 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray37 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double38 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray30, doubleArray37);
        double[][] doubleArray39 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray37, doubleArray39);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray37);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray23);
        double[] doubleArray46 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray53 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double54 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray46, doubleArray53);
        double[][] doubleArray55 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray53, doubleArray55);
        double[] doubleArray60 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray67 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double68 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray60, doubleArray67);
        double[][] doubleArray69 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray67, doubleArray69);
        double double71 = org.apache.commons.math.util.MathUtils.distance1(doubleArray53, doubleArray67);
        double[] doubleArray72 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray53);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray72);
        double double74 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray23, doubleArray72);
        double[] doubleArray76 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, 100.0d);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray76);
        double[] doubleArray81 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray88 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double89 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray81, doubleArray88);
        double[][] doubleArray90 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray88, doubleArray90);
        java.lang.Object[] objArray92 = org.apache.commons.math.exception.util.ArgUtils.flatten((java.lang.Object[]) doubleArray90);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray76, doubleArray90);
        int int94 = org.apache.commons.math.util.MathUtils.hash(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 90.0d + "'", double24 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 90.0d + "'", double38 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 90.0d + "'", double54 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 90.0d + "'", double68 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 1126.0d + "'", double74 == 1126.0d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 90.0d + "'", double89 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertNotNull(objArray92);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 257862796 + "'", int94 == 257862796);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 156.3608363030788d + "'", double1 == 156.3608363030788d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 'a', (byte) 10 };
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (-1.0f), (org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray9);
        org.apache.commons.math.exception.NoBracketingException noBracketingException11 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 2.302585092994046d, 0.0d, 0.8862395404791882d, (double) 10, objArray9);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS;
        double[] doubleArray16 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray23 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double24 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray16, doubleArray23);
        double[][] doubleArray25 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray23, doubleArray25);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException27 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) noBracketingException11, (org.apache.commons.math.exception.util.Localizable) localizedFormats12, (java.lang.Object[]) doubleArray25);
        double double28 = noBracketingException11.getFHi();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 90.0d + "'", double24 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 10.0d + "'", double28 == 10.0d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 0.8683757821044538d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        float[] floatArray0 = null;
        float[] floatArray7 = new float[] { (-4558301418543122400L), 100L, 35.000004f, 32.0f, 0, 4024981426554L };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equals(floatArray0, floatArray7);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(6.283185307179586d, (double) 97.0f, 209568959);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((float) 1731263161L, 1.1920929E-7f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR_FORMAT;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (short) 1, (java.lang.Number) 7766279631452241919L, true);
        java.lang.Throwable[] throwableArray9 = numberIsTooSmallException8.getSuppressed();
        java.lang.Object[] objArray10 = org.apache.commons.math.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray9);
        org.apache.commons.math.exception.NoBracketingException noBracketingException11 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) '#', (double) 9, (double) (-0.99999994f), 3.4557519189487724d, (java.lang.Object[]) throwableArray9);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR_FORMAT));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(objArray10);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 99, (-28));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        long long2 = org.apache.commons.math.util.FastMath.min((long) '#', (-11L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-11L) + "'", long2 == (-11L));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((int) ' ', 1);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 99.0f, (double) 1731263151L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.7183681142185815E-8d + "'", double2 == 5.7183681142185815E-8d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        float float2 = org.apache.commons.math.util.MathUtils.round((-0.99999994f), (int) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-0.9999999f) + "'", float2 == (-0.9999999f));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 7766279631452241920L, (double) (byte) -1, (-1337003777));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 70);
        int int2 = regulaFalsiSolver1.getEvaluations();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution8 = org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE;
        try {
            double double9 = regulaFalsiSolver1.solve((int) '4', univariateRealFunction4, 0.0d, 4.440892098500626E-16d, 161700.0d, allowedSolution8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution8 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE + "'", allowedSolution8.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        double[] doubleArray3 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray10 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        double[][] doubleArray12 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray10, doubleArray12);
        double[] doubleArray17 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray24 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray24);
        double[][] doubleArray26 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray24, doubleArray26);
        double[] doubleArray31 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray38 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double39 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray31, doubleArray38);
        double[][] doubleArray40 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray38, doubleArray40);
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray38);
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray10, doubleArray38);
        double[] doubleArray47 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray54 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray47, doubleArray54);
        double[][] doubleArray56 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray54, doubleArray56);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray10, doubleArray54);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray54);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (0 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 90.0d + "'", double25 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 90.0d + "'", double39 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 90.0d + "'", double55 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.WHOLE_FORMAT;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-32), (java.lang.Number) 1.8491431899952486d, true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WHOLE_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.WHOLE_FORMAT));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-554520869), 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 0, n = -554,520,869");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 70, (double) (-1.0f));
        double double3 = regulaFalsiSolver2.getFunctionValueAccuracy();
        double double4 = regulaFalsiSolver2.getMin();
        double double5 = regulaFalsiSolver2.getMin();
        double double6 = regulaFalsiSolver2.getFunctionValueAccuracy();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-15d + "'", double6 == 1.0E-15d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 9.686583447271545d, 3.4965075614664802d, (-1.7716215698884212E40d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        double[] doubleArray3 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray10 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        double[][] doubleArray12 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray10, doubleArray12);
        double[] doubleArray17 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray24 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray24);
        double[][] doubleArray26 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray24, doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray24);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray10);
        double[] doubleArray33 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray40 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double41 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray33, doubleArray40);
        double[][] doubleArray42 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray40, doubleArray42);
        double[] doubleArray47 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray54 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray47, doubleArray54);
        double[][] doubleArray56 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray54, doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray54);
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray40);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray59);
        double double61 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray10, doubleArray59);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, 100.0d);
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray63, (int) (short) 10);
        double[] doubleArray67 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray65, 36917.9834805808d);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 90.0d + "'", double25 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 90.0d + "'", double41 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 90.0d + "'", double55 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 1126.0d + "'", double61 == 1126.0d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((float) (-1024L), (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(343666637L, 260L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 343666897L + "'", long2 == 343666897L);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 0.0d, (double) (-1.4E-45f), (double) (-209568959), (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1731263151L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1731263104 + "'", int1 == 1731263104);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((float) 97L, 9.536743E-7f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-1731268351), (long) (-32));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-32)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        double[] doubleArray3 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray10 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        double[][] doubleArray12 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray10, doubleArray12);
        double[] doubleArray17 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray24 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray24);
        double[][] doubleArray26 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray24, doubleArray26);
        double[] doubleArray31 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray38 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double39 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray31, doubleArray38);
        double[][] doubleArray40 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray38, doubleArray40);
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray38);
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray10, doubleArray38);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection44 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[] doubleArray48 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray55 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double56 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray48, doubleArray55);
        double[][] doubleArray57 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray55, doubleArray57);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray38, orderDirection44, doubleArray57);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 90.0d + "'", double25 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 90.0d + "'", double39 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection44 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection44.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 90.0d + "'", double56 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray57);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-2305258549L), false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-2305258549L) + "'", number4.equals((-2305258549L)));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        java.lang.Object obj0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (short) 1, (java.lang.Number) 7766279631452241919L, true);
        java.lang.Throwable[] throwableArray6 = numberIsTooSmallException5.getSuppressed();
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException7 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) throwableArray6);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, (java.lang.Number) 1731268350, (java.lang.Number) (-1L), false);
        java.lang.Throwable[] throwableArray14 = numberIsTooLargeException13.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (java.lang.Object[]) throwableArray14);
        java.lang.Object[] objArray16 = org.apache.commons.math.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray14);
        try {
            org.apache.commons.math.util.MathUtils.checkNotNull(obj0, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) throwableArray14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: not positive definite matrix: diagonal element at ({0},{0}) is larger than {2}");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(objArray16);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 10L, 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-15d + "'", double2 == 1.0E-15d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) 35L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 35.000004f + "'", float1 == 35.000004f);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) (-7.920808E19f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination(7.001245622069476d, 3.4557519189487724d, (double) 198L, 20.79831393939627d, 2.302585092994046d, (double) 260L, (double) 97L, Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        double double1 = org.apache.commons.math.util.FastMath.exp(2.350016302011459d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.485740661998689d + "'", double1 == 10.485740661998689d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.03467570824850382d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.03467570824850383d + "'", double1 == 0.03467570824850383d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((-2.1987108057699997E11d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 37 + "'", int1 == 37);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1, 9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 9, n = 1");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 209568959);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 260L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0, 2146435072);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        int int2 = org.apache.commons.math.util.MathUtils.pow(343666689, 70);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1998348287) + "'", int2 == (-1998348287));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext0 = new org.apache.commons.math.exception.util.ExceptionContext();
        java.util.Set<java.lang.String> strSet1 = exceptionContext0.getKeys();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 'a', (byte) 10 };
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (-1.0f), (org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray13);
        org.apache.commons.math.exception.NoBracketingException noBracketingException15 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, 2.302585092994046d, 0.0d, 0.8862395404791882d, (double) 10, objArray13);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS;
        double[] doubleArray20 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray27 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray27);
        double[][] doubleArray29 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray27, doubleArray29);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException31 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) noBracketingException15, (org.apache.commons.math.exception.util.Localizable) localizedFormats16, (java.lang.Object[]) doubleArray29);
        java.lang.Throwable[] throwableArray32 = noBracketingException15.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Object[]) throwableArray32);
        exceptionContext0.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Object[]) throwableArray32);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats37 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException42 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats38, (java.lang.Number) 1731268350, (java.lang.Number) (-1L), false);
        java.lang.Throwable[] throwableArray43 = numberIsTooLargeException42.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException44 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats37, (java.lang.Object[]) throwableArray43);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException45 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 1.1752011936438014d, (java.lang.Object[]) throwableArray43);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats46 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats47 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_CONSIDER_PADDING;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats49 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats55 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED;
        java.lang.Object[] objArray58 = new java.lang.Object[] { 'a', (byte) 10 };
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (-1.0f), (org.apache.commons.math.exception.util.Localizable) localizedFormats55, objArray58);
        org.apache.commons.math.exception.NoBracketingException noBracketingException60 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats49, 2.302585092994046d, 0.0d, 0.8862395404791882d, (double) 10, objArray58);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats61 = org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS;
        double[] doubleArray65 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray72 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double73 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray65, doubleArray72);
        double[][] doubleArray74 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray72, doubleArray74);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException76 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) noBracketingException60, (org.apache.commons.math.exception.util.Localizable) localizedFormats61, (java.lang.Object[]) doubleArray74);
        java.lang.Throwable[] throwableArray77 = noBracketingException60.getSuppressed();
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException78 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats47, (java.lang.Number) 1.0f, (java.lang.Object[]) throwableArray77);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException79 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) notFiniteNumberException45, (org.apache.commons.math.exception.util.Localizable) localizedFormats46, (java.lang.Object[]) throwableArray77);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException80 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats35, (java.lang.Object[]) throwableArray77);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException81 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Object[]) throwableArray77);
        org.junit.Assert.assertNotNull(strSet1);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS));
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 90.0d + "'", double28 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION + "'", localizedFormats35.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE + "'", localizedFormats37.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertNotNull(throwableArray43);
        org.junit.Assert.assertTrue("'" + localizedFormats46 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS + "'", localizedFormats46.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS));
        org.junit.Assert.assertTrue("'" + localizedFormats47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_CONSIDER_PADDING + "'", localizedFormats47.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_CONSIDER_PADDING));
        org.junit.Assert.assertTrue("'" + localizedFormats49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats49.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED + "'", localizedFormats55.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED));
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertTrue("'" + localizedFormats61 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS + "'", localizedFormats61.equals(org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS));
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 90.0d + "'", double73 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(throwableArray77);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getMaximalCount();
        incrementor0.setMaximalCount((int) (byte) 0);
        incrementor0.setMaximalCount((int) (short) 100);
        int int6 = incrementor0.getCount();
        incrementor0.resetCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        double double1 = org.apache.commons.math.util.FastMath.floor((-1.2876178137472069E-19d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1126.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) 1731268350L, 11013.232920103324d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.73126822E9f + "'", float2 == 1.73126822E9f);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder(2.562136895042874d, (double) 5200L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.562136895042874d + "'", double2 == 2.562136895042874d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.00001f + "'", float1 == 100.00001f);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1076101120 + "'", int1 == 1076101120);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0f, (float) 32, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 363.7393755555636d + "'", double1 == 363.7393755555636d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        int[] intArray3 = new int[] { (byte) 0, (byte) -1, 100 };
        int[] intArray4 = org.apache.commons.math.util.MathUtils.copyOf(intArray3);
        int[] intArray5 = org.apache.commons.math.util.MathUtils.copyOf(intArray4);
        int[] intArray9 = new int[] { (byte) 0, (byte) -1, 100 };
        int[] intArray10 = org.apache.commons.math.util.MathUtils.copyOf(intArray9);
        int[] intArray14 = new int[] { (byte) 0, (byte) -1, 100 };
        int[] intArray15 = org.apache.commons.math.util.MathUtils.copyOf(intArray14);
        int[] intArray16 = org.apache.commons.math.util.MathUtils.copyOf(intArray15);
        double double17 = org.apache.commons.math.util.MathUtils.distance(intArray9, intArray16);
        int[] intArray19 = org.apache.commons.math.util.MathUtils.copyOf(intArray16, 1);
        try {
            int int20 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray19);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(intArray19);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        double[] doubleArray3 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray10 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        double[][] doubleArray12 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray10, doubleArray12);
        double[] doubleArray17 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray24 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray24);
        double[][] doubleArray26 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray24, doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray24);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray10);
        double[] doubleArray33 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray40 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double41 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray33, doubleArray40);
        double[][] doubleArray42 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray40, doubleArray42);
        double[] doubleArray47 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray54 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray47, doubleArray54);
        double[][] doubleArray56 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray54, doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray54);
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray40);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray59);
        double double61 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray10, doubleArray59);
        int int62 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        double[] doubleArray64 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, 1126.0d);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 90.0d + "'", double25 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 90.0d + "'", double41 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 90.0d + "'", double55 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 1126.0d + "'", double61 == 1126.0d);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-209568959) + "'", int62 == (-209568959));
        org.junit.Assert.assertNotNull(doubleArray64);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) (-1731268351), 1.73126822E9f, (-554520869));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.36787944117144233d, (double) '#', (int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getMaximalCount();
        incrementor0.setMaximalCount((int) (byte) 0);
        incrementor0.setMaximalCount((int) (short) 100);
        int int6 = incrementor0.getCount();
        int int7 = incrementor0.getCount();
        incrementor0.incrementCount();
        incrementor0.resetCount();
        int int10 = incrementor0.getMaximalCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-2.0d), (double) 99, (-209568959));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 70, (double) (-1.0f));
        double double3 = regulaFalsiSolver2.getFunctionValueAccuracy();
        double double4 = regulaFalsiSolver2.getMin();
        double double5 = regulaFalsiSolver2.getRelativeAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction7 = null;
        try {
            double double9 = regulaFalsiSolver2.solve(35, univariateRealFunction7, (double) 343666637L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 70.0d + "'", double5 == 70.0d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException3 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10, objArray2);
        java.lang.Number number4 = maxCountExceededException3.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10 + "'", number4.equals(10));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(343666897L, (-993337088L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-341377074707975936L) + "'", long2 == (-341377074707975936L));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 1077936128);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.798314057214018d + "'", double1 == 20.798314057214018d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) (-1071382528));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 64.0f + "'", float1 == 64.0f);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-0.99999994f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.141247386605077d + "'", double1 == 3.141247386605077d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        org.apache.commons.math.util.MathUtils.checkFinite((double) 128L);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        org.apache.commons.math.util.MathUtils.checkFinite(41608.51295107769d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, 4024981426554L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 1014);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1014L + "'", long1 == 1014L);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 21.965267307681675d, (java.lang.Number) 9.536743E-7f, false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(0.8862395404791882d, (double) 70, 1.0d, Double.NaN);
        double double5 = noBracketingException4.getFHi();
        double double6 = noBracketingException4.getLo();
        double double7 = noBracketingException4.getFHi();
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.8862395404791882d + "'", double6 == 0.8862395404791882d);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        float float1 = org.apache.commons.math.util.FastMath.nextUp(32.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 32.000004f + "'", float1 == 32.000004f);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        float[] floatArray4 = new float[] { 7766279631452241920L, 'a', 0, 1.0000001f };
        float[] floatArray8 = new float[] { 10.0f, (-1.0f), 100 };
        float[] floatArray9 = null;
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(floatArray8, floatArray9);
        float[] floatArray12 = new float[] { 100.0f };
        float[] floatArray13 = null;
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(floatArray12, floatArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray8, floatArray12);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(floatArray4, floatArray8);
        float[] floatArray21 = new float[] { 7766279631452241920L, 'a', 0, 1.0000001f };
        float[] floatArray25 = new float[] { 10.0f, (-1.0f), 100 };
        float[] floatArray26 = null;
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(floatArray25, floatArray26);
        float[] floatArray29 = new float[] { 100.0f };
        float[] floatArray30 = null;
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(floatArray29, floatArray30);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray25, floatArray29);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(floatArray21, floatArray25);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(floatArray4, floatArray25);
        float[] floatArray39 = new float[] { 7766279631452241920L, 'a', 0, 1.0000001f };
        float[] floatArray43 = new float[] { 10.0f, (-1.0f), 100 };
        float[] floatArray44 = null;
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(floatArray43, floatArray44);
        float[] floatArray47 = new float[] { 100.0f };
        float[] floatArray48 = null;
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(floatArray47, floatArray48);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray43, floatArray47);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equals(floatArray39, floatArray43);
        float[] floatArray56 = new float[] { 7766279631452241920L, 'a', 0, 1.0000001f };
        float[] floatArray60 = new float[] { 10.0f, (-1.0f), 100 };
        float[] floatArray61 = null;
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equals(floatArray60, floatArray61);
        float[] floatArray64 = new float[] { 100.0f };
        float[] floatArray65 = null;
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(floatArray64, floatArray65);
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray60, floatArray64);
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equals(floatArray56, floatArray60);
        float[] floatArray73 = new float[] { 7766279631452241920L, 'a', 0, 1.0000001f };
        float[] floatArray77 = new float[] { 10.0f, (-1.0f), 100 };
        float[] floatArray78 = null;
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equals(floatArray77, floatArray78);
        float[] floatArray81 = new float[] { 100.0f };
        float[] floatArray82 = null;
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equals(floatArray81, floatArray82);
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray77, floatArray81);
        boolean boolean85 = org.apache.commons.math.util.MathUtils.equals(floatArray73, floatArray77);
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equals(floatArray56, floatArray77);
        boolean boolean87 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray39, floatArray56);
        boolean boolean88 = org.apache.commons.math.util.MathUtils.equals(floatArray4, floatArray39);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(floatArray47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(floatArray56);
        org.junit.Assert.assertNotNull(floatArray60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(floatArray64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(floatArray73);
        org.junit.Assert.assertNotNull(floatArray77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(floatArray81);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        double double2 = org.apache.commons.math.util.FastMath.pow(9.44510651181544d, (double) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.44510651181544d + "'", double2 == 9.44510651181544d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(9);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.resetCount();
        int int2 = incrementor0.getMaximalCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        long long1 = org.apache.commons.math.util.FastMath.abs(4024981426554L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 4024981426554L + "'", long1 == 4024981426554L);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) (-127));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(100.0d);
        double double2 = regulaFalsiSolver1.getAbsoluteAccuracy();
        double double3 = regulaFalsiSolver1.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        try {
            double double8 = regulaFalsiSolver1.solve((-554520869), univariateRealFunction5, (double) (-4.2949673E9f), 3.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        double double1 = org.apache.commons.math.util.FastMath.exp(2.6313083693369503E35d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(7.3786976E19f, 1.0f, 52);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1731268341, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1731268341 + "'", int2 == 1731268341);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        double double2 = org.apache.commons.math.util.FastMath.copySign(60.39915696969813d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 60.39915696969813d + "'", double2 == 60.39915696969813d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 2.99822295029797d);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext2 = maxCountExceededException1.getContext();
        org.junit.Assert.assertNotNull(exceptionContext2);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        float float2 = org.apache.commons.math.util.FastMath.copySign((-2.30525824E9f), (-0.9999999f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-2.30525824E9f) + "'", float2 == (-2.30525824E9f));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        double double2 = org.apache.commons.math.util.MathUtils.log(578.4835406645935d, (double) (-1));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        int[] intArray1 = new int[] { (byte) 100 };
        int[] intArray5 = new int[] { (byte) 0, (byte) -1, 100 };
        int[] intArray6 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        double double7 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray5);
        int[] intArray11 = new int[] { (byte) 0, (byte) -1, 100 };
        int[] intArray12 = org.apache.commons.math.util.MathUtils.copyOf(intArray11);
        double double13 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray11);
        int[] intArray15 = org.apache.commons.math.util.MathUtils.copyOf(intArray5, 10);
        int[] intArray17 = new int[] { (byte) 100 };
        int[] intArray21 = new int[] { (byte) 0, (byte) -1, 100 };
        int[] intArray22 = org.apache.commons.math.util.MathUtils.copyOf(intArray21);
        double double23 = org.apache.commons.math.util.MathUtils.distance(intArray17, intArray21);
        try {
            int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray15, intArray21);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 100.0d + "'", double23 == 100.0d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 1.5370264E31f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        float float2 = org.apache.commons.math.util.FastMath.min((float) ' ', 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        float float1 = org.apache.commons.math.util.FastMath.signum(100.00001f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence(0.4451963704655766d, (double) 11, 1.401298464324817E-45d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [11, 0]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-10));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: must have n >= 0 for n!, got n = -10");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.21094709796687366d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.358252567484289d + "'", double1 == 1.358252567484289d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(64.0f, (-7.920808E19f), (-10));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0000001f + "'", float1 == 1.0000001f);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 100L, 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        long long1 = org.apache.commons.math.util.MathUtils.sign(70L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = null;
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, bigInteger8);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 1731263161L);
        try {
            java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, (long) 3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        int int2 = org.apache.commons.math.util.FastMath.max(1024, 2146435072);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2146435072 + "'", int2 == 2146435072);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(0.8862395404791882d, (double) 70, 1.0d, Double.NaN);
        double double5 = noBracketingException4.getFHi();
        double double6 = noBracketingException4.getLo();
        java.lang.Throwable[] throwableArray7 = noBracketingException4.getSuppressed();
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.8862395404791882d + "'", double6 == 0.8862395404791882d);
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (short) 1, (java.lang.Number) 7766279631452241919L, true);
        java.lang.Throwable[] throwableArray4 = numberIsTooSmallException3.getSuppressed();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.LENGTH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH;
        java.lang.Object[] objArray13 = new java.lang.Object[] { localizedFormats7, localizedFormats8, 100.0d, 100, localizedFormats11, localizedFormats12 };
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException14 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray13);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException15 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException3, (org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray13);
        java.lang.Number number16 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LENGTH + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.LENGTH));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 7766279631452241919L + "'", number16.equals(7766279631452241919L));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        double double1 = org.apache.commons.math.util.FastMath.log10(100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0000217136384313d + "'", double1 == 2.0000217136384313d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 1.4E-45f, 20.798314057214018d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 18.84955592153876d + "'", double2 == 18.84955592153876d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(0.0d, 1.5707963267948966d, (double) 1731268341, 1.2217304763960306d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0f, (float) 7766279631452241920L, (float) 1076101120);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        double[] doubleArray3 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray10 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        double[][] doubleArray12 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray10, doubleArray12);
        double[] doubleArray17 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray24 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray24);
        double[][] doubleArray26 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray24, doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray24);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray10);
        double[] doubleArray33 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray40 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double41 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray33, doubleArray40);
        double[][] doubleArray42 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray40, doubleArray42);
        double[] doubleArray47 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray54 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray47, doubleArray54);
        double[][] doubleArray56 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray54, doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray54);
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray40);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray59);
        double double61 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray10, doubleArray59);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, 100.0d);
        double[] doubleArray67 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray74 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double75 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray67, doubleArray74);
        double[][] doubleArray76 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray74, doubleArray76);
        double[] doubleArray81 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray88 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double89 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray81, doubleArray88);
        double[][] doubleArray90 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray88, doubleArray90);
        double double92 = org.apache.commons.math.util.MathUtils.distance1(doubleArray74, doubleArray88);
        double[] doubleArray93 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray74);
        boolean boolean94 = org.apache.commons.math.util.MathUtils.equals(doubleArray63, doubleArray93);
        double double95 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray93);
        double[] doubleArray97 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray93, 1.3440585709080678E43d);
        double[] doubleArray98 = null;
        boolean boolean99 = org.apache.commons.math.util.MathUtils.equals(doubleArray93, doubleArray98);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 90.0d + "'", double25 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 90.0d + "'", double41 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 90.0d + "'", double55 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 1126.0d + "'", double61 == 1126.0d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 90.0d + "'", double75 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 90.0d + "'", double89 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 33.555923471125034d + "'", double95 == 33.555923471125034d);
        org.junit.Assert.assertNotNull(doubleArray97);
        org.junit.Assert.assertTrue("'" + boolean99 + "' != '" + false + "'", boolean99 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(4.672343674754382d, (double) (byte) 10);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        double double1 = org.apache.commons.math.util.FastMath.asinh(10.049875621120892d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0031735464552987d + "'", double1 == 3.0031735464552987d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 'a', (byte) 10 };
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (-1.0f), (org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray9);
        org.apache.commons.math.exception.NoBracketingException noBracketingException11 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 2.302585092994046d, 0.0d, 0.8862395404791882d, (double) 10, objArray9);
        java.lang.Object[] objArray12 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray9);
        java.lang.Object[] objArray13 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray9);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        double double1 = org.apache.commons.math.util.FastMath.sin(138.85278649903591d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.583238424549414d + "'", double1 == 0.583238424549414d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-1998348287), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(6.283185307179587d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (double) (short) 1, 3);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        double double1 = org.apache.commons.math.util.FastMath.atanh(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 99.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.605170185988092d + "'", double1 == 4.605170185988092d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(1731263161L, 7766279631452241920L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-7766279629720978759L) + "'", long2 == (-7766279629720978759L));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.1495489051661059d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681394d + "'", double1 == 0.5403023058681394d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(1731268350L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1731268350L + "'", long2 == 1731268350L);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        double[] doubleArray3 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray10 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        double[][] doubleArray12 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray10, doubleArray12);
        double[] doubleArray17 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray24 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray24);
        double[][] doubleArray26 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray24, doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray24);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray10);
        double[] doubleArray33 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray40 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double41 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray33, doubleArray40);
        double[][] doubleArray42 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray40, doubleArray42);
        double[] doubleArray47 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray54 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray47, doubleArray54);
        double[][] doubleArray56 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray54, doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray54);
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray40);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray59);
        double double61 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray10, doubleArray59);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, 100.0d);
        double double64 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 90.0d + "'", double25 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 90.0d + "'", double41 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 90.0d + "'", double55 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 1126.0d + "'", double61 == 1126.0d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 33.555923471125034d + "'", double64 == 33.555923471125034d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 0, (double) 7766279631452241919L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-10), (long) 11);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 110L + "'", long2 == 110L);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        int int1 = org.apache.commons.math.util.MathUtils.sign(3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        double double1 = org.apache.commons.math.util.FastMath.atanh(41608.450475834834d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        float float1 = org.apache.commons.math.util.MathUtils.sign(19206.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 9L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.incrementCount((int) (short) 0);
        incrementor0.resetCount();
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1077936128, 99);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        double double2 = org.apache.commons.math.util.FastMath.scalb((double) 260L, 1076101120);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 1076101120);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.8491431899952486d, (double) (-1L));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        org.apache.commons.math.util.MathUtils.checkFinite(36917.9834805808d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 52L, (float) (-288L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-288.0f) + "'", float2 == (-288.0f));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.7312683499999998E9d, (double) 10.0f);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.004425697988050785d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getMaximalCount();
        int int2 = incrementor0.getMaximalCount();
        incrementor0.setMaximalCount((int) (byte) -1);
        try {
            incrementor0.incrementCount();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (-1) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        int int2 = org.apache.commons.math.util.FastMath.min((-554520869), (-1337003777));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1337003777) + "'", int2 == (-1337003777));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 209568959L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 209568960 + "'", int1 == 209568960);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException0 = new org.apache.commons.math.exception.MathArithmeticException();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext1 = mathArithmeticException0.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext2 = mathArithmeticException0.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext3 = mathArithmeticException0.getContext();
        java.lang.Object obj5 = exceptionContext3.getValue("scale ({0})");
        org.junit.Assert.assertNotNull(exceptionContext1);
        org.junit.Assert.assertNotNull(exceptionContext2);
        org.junit.Assert.assertNotNull(exceptionContext3);
        org.junit.Assert.assertNull(obj5);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(37, 32);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 435897L + "'", long2 == 435897L);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 52, (-2.30525824E9f), 0.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        double double1 = org.apache.commons.math.util.FastMath.ceil(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 209568960, (float) (-4558301418543122432L), (float) ' ');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-3.1415926533569625d), (-27.999999999999996d), (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 70);
        int int2 = regulaFalsiSolver1.getMaxEvaluations();
        double double3 = regulaFalsiSolver1.getAbsoluteAccuracy();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 70.0d + "'", double3 == 70.0d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 260L, (float) 343666897L, (-32));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        double double2 = org.apache.commons.math.util.FastMath.scalb(0.0798317705429828d, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 81.74773303601438d + "'", double2 == 81.74773303601438d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ROWS_NOT_INITIALIZED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 1731268350, (java.lang.Number) (-1L), false);
        java.lang.Number number6 = numberIsTooLargeException5.getArgument();
        boolean boolean7 = numberIsTooLargeException5.getBoundIsAllowed();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10, 10L };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException14 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, (java.lang.Number) 1731268350, objArray13);
        java.lang.Object[] objArray15 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray13);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException16 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooLargeException5, (org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray15);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException17 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray15);
        java.lang.Object[] objArray18 = null;
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException19 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray18);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext20 = mathIllegalStateException19.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.LENGTH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH;
        java.lang.Object[] objArray29 = new java.lang.Object[] { localizedFormats23, localizedFormats24, 100.0d, 100, localizedFormats27, localizedFormats28 };
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException30 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats22, objArray29);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException31 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats21, objArray29);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException36 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (short) 1, (java.lang.Number) 7766279631452241919L, true);
        java.lang.Throwable[] throwableArray37 = numberIsTooSmallException36.getSuppressed();
        java.lang.Object[] objArray38 = org.apache.commons.math.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray37);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException39 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats21, (java.lang.Number) 1731263161L, (java.lang.Object[]) throwableArray37);
        double[] doubleArray43 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray50 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double51 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray43, doubleArray50);
        double[][] doubleArray52 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray50, doubleArray52);
        java.lang.Object[] objArray54 = org.apache.commons.math.exception.util.ArgUtils.flatten((java.lang.Object[]) doubleArray52);
        exceptionContext20.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats21, objArray54);
        java.lang.Object obj57 = exceptionContext20.getValue("trust region step has failed to reduce Q");
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ROWS_NOT_INITIALIZED_YET + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ROWS_NOT_INITIALIZED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1731268350 + "'", number6.equals(1731268350));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(exceptionContext20);
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN));
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LENGTH + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.LENGTH));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE));
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH + "'", localizedFormats28.equals(org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH));
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 90.0d + "'", double51 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNull(obj57);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval(1.8184464592320668d, 2.220446049250313E-16d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [1.818, 0]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0f, (float) ' ');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 1731263161L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        int int2 = org.apache.commons.math.util.FastMath.max(37, 1076101120);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1076101120 + "'", int2 == 1076101120);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(7766279631452241919L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-4558301418543122400L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (double) 7766279631452241920L, 0.5403023058681394d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) (-993337088L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 29 + "'", int1 == 29);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(209568960, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 209568960, 260L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 39916800L, (-11.0d), 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        double double1 = org.apache.commons.math.util.FastMath.ceil(3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 274638334, (double) 35.000004f);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder(0.0d, (double) 1731263151L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        float[] floatArray0 = null;
        float[] floatArray4 = new float[] { 10.0f, (-1.0f), 100 };
        float[] floatArray5 = null;
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(floatArray4, floatArray5);
        float[] floatArray8 = new float[] { 100.0f };
        float[] floatArray9 = null;
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(floatArray8, floatArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray4, floatArray8);
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equals(floatArray0, floatArray4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1998348287));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1998348287 + "'", int1 == 1998348287);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) 97L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        double double3 = org.apache.commons.math.util.MathUtils.reduce((double) 29, (double) 32, 4.440892098500626E-16d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 29.0d + "'", double3 == 29.0d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        float float2 = org.apache.commons.math.util.FastMath.scalb((-0.9999999f), 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-0.9999999f) + "'", float2 == (-0.9999999f));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        int[] intArray3 = new int[] { (byte) 0, (byte) -1, 100 };
        int[] intArray4 = org.apache.commons.math.util.MathUtils.copyOf(intArray3);
        int[] intArray5 = null;
        try {
            int int6 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (-28));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        double double1 = org.apache.commons.math.util.FastMath.floor(41608.51295107769d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 41608.0d + "'", double1 == 41608.0d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 70, (double) (-1.0f));
        double double3 = regulaFalsiSolver2.getFunctionValueAccuracy();
        double double4 = regulaFalsiSolver2.getRelativeAccuracy();
        double double5 = regulaFalsiSolver2.getRelativeAccuracy();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 70.0d + "'", double4 == 70.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 70.0d + "'", double5 == 70.0d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 0.0d, 1.1752011936438014d, (double) 2305258549L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, (-3.1415926533569625d), 4.605170185988092d, 1.1920928955078125E-7d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-385L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.STANDARD_DEVIATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (java.lang.Number) 1731268350, (java.lang.Number) (-1L), false);
        java.lang.Throwable[] throwableArray13 = numberIsTooLargeException12.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, (java.lang.Object[]) throwableArray13);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException15 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Number) 0.0d, (java.lang.Object[]) throwableArray13);
        org.apache.commons.math.exception.NoBracketingException noBracketingException16 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 1.1044889974911132d, (double) (short) -1, (double) (byte) 10, (-11.0d), (java.lang.Object[]) throwableArray13);
        double double17 = noBracketingException16.getLo();
        double double18 = noBracketingException16.getHi();
        double double19 = noBracketingException16.getLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.STANDARD_DEVIATION + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.STANDARD_DEVIATION));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.1044889974911132d + "'", double17 == 1.1044889974911132d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-1.0d) + "'", double18 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.1044889974911132d + "'", double19 == 1.1044889974911132d);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) 39916800L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1), (java.lang.Number) 70.0f, true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence(6.938893903907228E-18d, (-3.1415926533569625d), 0.6321206780378472d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [0, -3.142]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) (short) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.4E-45f + "'", float1 == 1.4E-45f);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(7.7662794E18f, (float) 260L, (-28));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        double double2 = org.apache.commons.math.util.FastMath.hypot((-51938.68429423033d), 0.9126365759632116d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 51938.68430224848d + "'", double2 == 51938.68430224848d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 'a', (byte) 10 };
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (-1.0f), (org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray13);
        org.apache.commons.math.exception.NoBracketingException noBracketingException15 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, 2.302585092994046d, 0.0d, 0.8862395404791882d, (double) 10, objArray13);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS;
        double[] doubleArray20 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray27 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray27);
        double[][] doubleArray29 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray27, doubleArray29);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException31 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) noBracketingException15, (org.apache.commons.math.exception.util.Localizable) localizedFormats16, (java.lang.Object[]) doubleArray29);
        java.lang.Throwable[] throwableArray32 = noBracketingException15.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Object[]) throwableArray32);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math.exception.util.LocalizedFormats.LENGTH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats36 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats37 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats40 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats41 = org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH;
        java.lang.Object[] objArray42 = new java.lang.Object[] { localizedFormats36, localizedFormats37, 100.0d, 100, localizedFormats40, localizedFormats41 };
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException43 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats35, objArray42);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException44 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats34, objArray42);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException45 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray42);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException46 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-11L), objArray42);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT));
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS));
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 90.0d + "'", double28 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM + "'", localizedFormats34.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM));
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LENGTH + "'", localizedFormats35.equals(org.apache.commons.math.exception.util.LocalizedFormats.LENGTH));
        org.junit.Assert.assertTrue("'" + localizedFormats36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE + "'", localizedFormats36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE));
        org.junit.Assert.assertTrue("'" + localizedFormats37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats37.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE + "'", localizedFormats40.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH + "'", localizedFormats41.equals(org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH));
        org.junit.Assert.assertNotNull(objArray42);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(32.000004f, (-993337088), 37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathIllegalArgumentException; message: invalid rounding method 37, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 5200L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5200.0d + "'", double1 == 5200.0d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.STANDARD_DEVIATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (java.lang.Number) 1731268350, (java.lang.Number) (-1L), false);
        java.lang.Throwable[] throwableArray13 = numberIsTooLargeException12.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, (java.lang.Object[]) throwableArray13);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException15 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Number) 0.0d, (java.lang.Object[]) throwableArray13);
        org.apache.commons.math.exception.NoBracketingException noBracketingException16 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 1.1044889974911132d, (double) (short) -1, (double) (byte) 10, (-11.0d), (java.lang.Object[]) throwableArray13);
        double double17 = noBracketingException16.getLo();
        double double18 = noBracketingException16.getLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.STANDARD_DEVIATION + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.STANDARD_DEVIATION));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.1044889974911132d + "'", double17 == 1.1044889974911132d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.1044889974911132d + "'", double18 == 1.1044889974911132d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) 1014, (float) (-1L), (-1.4E-45f));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-28), 29);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 0L);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 'a', (byte) 10 };
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (-1.0f), (org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray9);
        org.apache.commons.math.exception.NoBracketingException noBracketingException11 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 2.302585092994046d, 0.0d, 0.8862395404791882d, (double) 10, objArray9);
        java.lang.Object[] objArray12 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray9);
        java.lang.Class<?> wildcardClass13 = objArray12.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(52, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, 257862796, 0);
        org.junit.Assert.assertEquals((float) float3, Float.NaN, 0);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        double double1 = org.apache.commons.math.util.MathUtils.sign((-51938.68429423033d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, (double) 39916800L, 0.004451711715313271d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) '4');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 52.000004f + "'", float1 == 52.000004f);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (-993337088));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.570796325788189d) + "'", double1 == (-1.570796325788189d));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder(51938.68430224848d, 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(280.9980162289898d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        double double1 = org.apache.commons.math.util.FastMath.acos(10.04987562112089d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 1.0E-15d, (double) 1998348287);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 0L);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 100, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        double[] doubleArray3 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray10 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) (short) 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        boolean boolean17 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10, orderDirection14, false, false);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((-20), 11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 220 + "'", int2 == 220);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 257862796);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 257862796L + "'", long1 == 257862796L);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 0.8751688612297938d, 1.105319173992757d, (double) (-1071382528));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) (byte) 1, (float) '4', (int) ' ');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((-554520869), 6);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1097.0d, 1.7453292519943295d, 1.1978571669969933E100d);
        int int4 = regulaFalsiSolver3.getEvaluations();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.018956994043898345d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0861557509700144d + "'", double1 == 1.0861557509700144d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 20.79831393939627d, (java.lang.Number) 35.000004f, true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 3.8146973E-6f);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, number4, (java.lang.Number) 10L, true);
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException13 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (double) ' ', 1.0d, 0.6321206780378472d, 21.965267307681675d, objArray12);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.NO_RESULT_AVAILABLE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED;
        java.lang.Object[] objArray24 = new java.lang.Object[] { 'a', (byte) 10 };
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (-1.0f), (org.apache.commons.math.exception.util.Localizable) localizedFormats21, objArray24);
        org.apache.commons.math.exception.NoBracketingException noBracketingException26 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, 2.302585092994046d, 0.0d, 0.8862395404791882d, (double) 10, objArray24);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS;
        double[] doubleArray31 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray38 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double39 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray31, doubleArray38);
        double[][] doubleArray40 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray38, doubleArray40);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException42 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) noBracketingException26, (org.apache.commons.math.exception.util.Localizable) localizedFormats27, (java.lang.Object[]) doubleArray40);
        java.lang.Throwable[] throwableArray43 = noBracketingException26.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException44 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats14, (java.lang.Object[]) throwableArray43);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException45 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) notPositiveException2, (org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Object[]) throwableArray43);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_RESULT_AVAILABLE + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_RESULT_AVAILABLE));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS));
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 90.0d + "'", double39 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(throwableArray43);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(156.3608363030788d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.7187963764108645d) + "'", double2 == (-0.7187963764108645d));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-28), (double) 213431353344L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-28.0d) + "'", double2 == (-28.0d));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        double[] doubleArray6 = new double[] { 0.0f, (short) 100, 0.9999999958776927d };
        double[] doubleArray13 = new double[] { 0.0d, (byte) 10, 1.0f, (-1.0d), ' ', 0 };
        double double14 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray13);
        double[][] doubleArray15 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray13, doubleArray15);
        java.lang.Object[] objArray17 = org.apache.commons.math.exception.util.ArgUtils.flatten((java.lang.Object[]) doubleArray15);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException18 = new org.apache.commons.math.exception.NullArgumentException(localizable2, objArray17);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException19 = new org.apache.commons.math.exception.MaxCountExceededException(localizable0, (java.lang.Number) 100.00001f, objArray17);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 90.0d + "'", double14 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(objArray17);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 4.440892098500626E-16d, 45.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 9);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, (double) (short) 10, 6.283185307179586d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }
}

