import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number7 = numberIsTooLargeException6.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray13);
        java.lang.Object[] objArray16 = new java.lang.Object[] { objArray13, "" };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException6, localizable8, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("", objArray13);
        org.apache.commons.math.exception.util.Localizable localizable20 = mathException19.getGeneralPattern();
        java.lang.Number number21 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException(localizable20, number21, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray29 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray29);
        java.lang.String str31 = maxIterationsExceededException30.getPattern();
        java.lang.Object[] objArray32 = maxIterationsExceededException30.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable20, objArray32);
        java.lang.Object[] objArray34 = null;
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException(localizable20, objArray34);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException40 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number41 = numberIsTooLargeException40.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        java.lang.Object[] objArray47 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray47);
        java.lang.Object[] objArray50 = new java.lang.Object[] { objArray47, "" };
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException40, localizable42, objArray47);
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException35, "", objArray47);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1.0d) + "'", number7.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + number41 + "' != '" + (-1.0d) + "'", number41.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(objArray50);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.density(100.0d);
        double[] doubleArray4 = normalDistributionImpl0.sample(47);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 51L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 51.0f + "'", float1 == 51.0f);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        double double1 = org.apache.commons.math.special.Gamma.digamma(1.1102769287390484d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.409122520006212d) + "'", double1 == (-0.409122520006212d));
    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test005");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT(4.599102285891914d);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure();
//        int int9 = randomDataImpl1.nextHypergeometric(100, 71, (int) (byte) 1);
//        randomDataImpl1.reSeedSecure();
//        double double12 = randomDataImpl1.nextT(5.298292365610485d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.9787610668923429d) + "'", double3 == (-0.9787610668923429d));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-0.16921380817150397d) + "'", double12 == (-0.16921380817150397d));
//    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test006");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.4711276743037347d, (double) 1L);
//        double double3 = normalDistributionImpl2.sample();
//        double double5 = normalDistributionImpl2.inverseCumulativeProbability(0.0d);
//        double double7 = normalDistributionImpl2.cumulativeProbability((-2.528992236021673d));
//        double double8 = normalDistributionImpl2.getMean();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3755464446637895d + "'", double3 == 0.3755464446637895d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.NEGATIVE_INFINITY + "'", double5 == Double.NEGATIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.165519805514716E-5d + "'", double7 == 3.165519805514716E-5d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.4711276743037347d + "'", double8 == 1.4711276743037347d);
//    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.16444888649579864d, 23.999999999999996d, (double) (byte) 10, 99);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.9999999999995454d + "'", double4 == 0.9999999999995454d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        double double1 = org.apache.commons.math.special.Erf.erf(0.17453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.19495775447231087d + "'", double1 == 0.19495775447231087d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        double double1 = org.apache.commons.math.util.FastMath.asin(16.83557943756344d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 6.0d, (java.lang.Number) 8.054359047689252E13d, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException5.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number14 = numberIsTooLargeException13.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException21 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray20);
        java.lang.Object[] objArray23 = new java.lang.Object[] { objArray20, "" };
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException13, localizable15, objArray20);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException("", objArray20);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException("", objArray20);
        org.apache.commons.math.exception.util.Localizable localizable27 = mathException26.getGeneralPattern();
        java.lang.Number number28 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException31 = new org.apache.commons.math.exception.OutOfRangeException(localizable27, number28, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray36 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray36);
        java.lang.String str38 = maxIterationsExceededException37.getPattern();
        java.lang.Object[] objArray39 = maxIterationsExceededException37.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException40 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable27, objArray39);
        org.apache.commons.math.exception.util.Localizable localizable41 = maxIterationsExceededException40.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException43 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.util.Localizable localizable44 = notStrictlyPositiveException43.getSpecificPattern();
        java.lang.Throwable[] throwableArray45 = notStrictlyPositiveException43.getSuppressed();
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException(localizable41, (java.lang.Object[]) throwableArray45);
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException53 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number54 = numberIsTooLargeException53.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException61 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray60);
        java.lang.Object[] objArray63 = new java.lang.Object[] { objArray60, "" };
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException53, localizable55, objArray60);
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException("", objArray60);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException66 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable48, objArray60);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException67 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable41, objArray60);
        org.apache.commons.math.exception.util.Localizable localizable68 = null;
        java.lang.Object[] objArray73 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException74 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray73);
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException(localizable68, objArray73);
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException(throwable1, localizable6, objArray73);
        java.lang.Number number77 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException78 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, number77);
        org.apache.commons.math.exception.util.Localizable localizable79 = null;
        java.lang.Object[] objArray84 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException85 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray84);
        org.apache.commons.math.ConvergenceException convergenceException86 = new org.apache.commons.math.ConvergenceException(localizable79, objArray84);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException87 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable6, objArray84);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + (-1.0d) + "'", number14.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(localizable27);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "hi!" + "'", str38.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(localizable41);
        org.junit.Assert.assertNull(localizable44);
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertTrue("'" + number54 + "' != '" + (-1.0d) + "'", number54.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertNotNull(objArray73);
        org.junit.Assert.assertNotNull(objArray84);
    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test011");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double1 = normalDistributionImpl0.sample();
//        double double3 = normalDistributionImpl0.cumulativeProbability(2.767576814789016d);
//        double double4 = normalDistributionImpl0.getMean();
//        normalDistributionImpl0.reseedRandomGenerator((-1L));
//        double double8 = normalDistributionImpl0.inverseCumulativeProbability(0.29720163021279145d);
//        double[] doubleArray10 = normalDistributionImpl0.sample(7);
//        double double11 = normalDistributionImpl0.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.6135264561718823d) + "'", double1 == (-1.6135264561718823d));
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.9971762632543613d + "'", double3 == 0.9971762632543613d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-0.532466034258566d) + "'", double8 == (-0.532466034258566d));
//        org.junit.Assert.assertNotNull(doubleArray10);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(99);
    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test013");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) 'a');
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeed();
//        double double16 = randomDataImpl1.nextBeta(12.808427727927521d, 7.99299442949858d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl19 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.4711276743037347d, (double) 1L);
//        double double20 = normalDistributionImpl19.sample();
//        double double22 = normalDistributionImpl19.inverseCumulativeProbability(0.0d);
//        double double23 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl19);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-12.084313082161652d) + "'", double4 == (-12.084313082161652d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.3801711065235145d + "'", double6 == 0.3801711065235145d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.48277534835440394d + "'", double16 == 0.48277534835440394d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.4930397699903618d + "'", double20 == 0.4930397699903618d);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + Double.NEGATIVE_INFINITY + "'", double22 == Double.NEGATIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 3.1545686361523138d + "'", double23 == 3.1545686361523138d);
//    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(1.4029534486805868E-257d, 1.2436118014689093d, (double) 99, 32);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.0146226312358714E-258d + "'", double4 == 2.0146226312358714E-258d);
    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test015");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        double double15 = randomDataImpl1.nextWeibull(40.223410238970004d, 0.11876664467085814d);
//        randomDataImpl1.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-12.335455308714748d) + "'", double4 == (-12.335455308714748d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 8.25453582285433E-4d + "'", double6 == 8.25453582285433E-4d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 5 + "'", int9 == 5);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.120749699809122d + "'", double15 == 0.120749699809122d);
//    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.0447136585535002E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 32);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (byte) 10, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) 0.0f);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, (java.lang.Number) (short) 100, (java.lang.Number) 0.8813735870195429d, (java.lang.Number) 100);
        java.lang.Number number10 = outOfRangeException9.getLo();
        java.lang.Throwable[] throwableArray11 = outOfRangeException9.getSuppressed();
        java.lang.Number number12 = outOfRangeException9.getHi();
        org.apache.commons.math.exception.util.Localizable localizable13 = outOfRangeException9.getGeneralPattern();
        outOfRangeException4.addSuppressed((java.lang.Throwable) outOfRangeException9);
        java.lang.Number number15 = outOfRangeException9.getArgument();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0.8813735870195429d + "'", number10.equals(0.8813735870195429d));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 100 + "'", number12.equals(100));
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (short) 100 + "'", number15.equals((short) 100));
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test019");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl0.density(100.0d);
//        double double3 = normalDistributionImpl0.getStandardDeviation();
//        double double4 = normalDistributionImpl0.sample();
//        try {
//            double double7 = normalDistributionImpl0.cumulativeProbability(0.6213153229208016d, (-225.95084645419513d));
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.2789187487804147d) + "'", double4 == (-0.2789187487804147d));
//    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.15385541444224388d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.14310886945841106d + "'", double1 == 0.14310886945841106d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.361562941897067d);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test022");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        long long3 = randomDataImpl1.nextPoisson((double) 10L);
//        double double6 = randomDataImpl1.nextGamma(5.896662418833589d, 4.265278032032717E-17d);
//        double double9 = randomDataImpl1.nextBeta((double) (byte) 1, 4.672738657069999d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution10 = null;
//        try {
//            int int11 = randomDataImpl1.nextInversionDeviate(integerDistribution10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 8L + "'", long3 == 8L);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.2575452338681906E-16d + "'", double6 == 1.2575452338681906E-16d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.19141017410296618d + "'", double9 == 0.19141017410296618d);
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        int int2 = org.apache.commons.math.util.FastMath.min(35, 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) (short) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(20.085536923187668d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.718281828459045d + "'", double1 == 2.718281828459045d);
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test026");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        randomDataImpl1.reSeed();
//        double double13 = randomDataImpl1.nextGaussian((-0.5418080117554591d), 0.4999921339008419d);
//        long long15 = randomDataImpl1.nextPoisson(0.015413343812216955d);
//        double double18 = randomDataImpl1.nextCauchy(0.0d, 5.058929815755315d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-63.18369385355061d) + "'", double4 == (-63.18369385355061d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05816255768582265d + "'", double6 == 0.05816255768582265d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.12430743470345351d + "'", double13 == 0.12430743470345351d);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-3.6997246740589316d) + "'", double18 == (-3.6997246740589316d));
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        double double1 = org.apache.commons.math.util.FastMath.atan((-8.725262846060508d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.4566844952629092d) + "'", double1 == (-1.4566844952629092d));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.005248366233766214d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray4);
        java.lang.String str6 = maxIterationsExceededException5.getPattern();
        java.lang.String str7 = maxIterationsExceededException5.toString();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException5);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Number number10 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, number10, (java.lang.Number) (-0.17738444574517354d), true);
        java.lang.Throwable[] throwableArray14 = numberIsTooSmallException13.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable15 = numberIsTooSmallException13.getSpecificPattern();
        java.lang.Class<?> wildcardClass16 = numberIsTooSmallException13.getClass();
        mathException8.addSuppressed((java.lang.Throwable) numberIsTooSmallException13);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: hi!" + "'", str7.equals("org.apache.commons.math.MaxIterationsExceededException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNull(localizable15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        double double2 = org.apache.commons.math.util.FastMath.atan2(100.0d, 5.775284847419849d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5131075595812769d + "'", double2 == 1.5131075595812769d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        double double1 = org.apache.commons.math.util.FastMath.log10((-0.5265471056297653d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.density(100.0d);
        double double4 = normalDistributionImpl0.inverseCumulativeProbability((double) 1);
        try {
            double double7 = normalDistributionImpl0.cumulativeProbability((double) 0.0f, (-1.4033878397655306d));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(12.801827480081467d, 2.002080933825346d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0646830613747976E-7d + "'", double2 == 3.0646830613747976E-7d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.0049655341270195205d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999876717607477d + "'", double1 == 0.9999876717607477d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.06933046210927461d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9975976060446933d + "'", double1 == 0.9975976060446933d);
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test036");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        randomDataImpl1.reSeed();
//        double double13 = randomDataImpl1.nextF(0.8018974326990581d, (double) (byte) 1);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double16 = normalDistributionImpl14.density(100.0d);
//        double double17 = normalDistributionImpl14.getStandardDeviation();
//        double double18 = normalDistributionImpl14.getStandardDeviation();
//        double double19 = normalDistributionImpl14.getStandardDeviation();
//        double double20 = normalDistributionImpl14.sample();
//        double double21 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-40.626472726320294d) + "'", double4 == (-40.626472726320294d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.350121360076656d + "'", double6 == 4.350121360076656d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 7.696472144856217E-4d + "'", double13 == 7.696472144856217E-4d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-0.380551639502605d) + "'", double20 == (-0.380551639502605d));
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.7865353550468592d + "'", double21 == 1.7865353550468592d);
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((-0.5418080117554591d), 0.29562583896000183d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(1.1185087377885383d, (-0.9538593386156619d), (double) 2147483647, 2147483647);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 6.0d, (java.lang.Number) 8.054359047689252E13d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number12 = numberIsTooLargeException11.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray18);
        java.lang.Object[] objArray21 = new java.lang.Object[] { objArray18, "" };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException11, localizable13, objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("", objArray18);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("", objArray18);
        org.apache.commons.math.exception.util.Localizable localizable25 = mathException24.getGeneralPattern();
        java.lang.Number number26 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException(localizable25, number26, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray34 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray34);
        java.lang.String str36 = maxIterationsExceededException35.getPattern();
        java.lang.Object[] objArray37 = maxIterationsExceededException35.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable25, objArray37);
        org.apache.commons.math.exception.util.Localizable localizable39 = maxIterationsExceededException38.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException41 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.util.Localizable localizable42 = notStrictlyPositiveException41.getSpecificPattern();
        java.lang.Throwable[] throwableArray43 = notStrictlyPositiveException41.getSuppressed();
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException(localizable39, (java.lang.Object[]) throwableArray43);
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException51 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number52 = numberIsTooLargeException51.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        java.lang.Object[] objArray58 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException59 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray58);
        java.lang.Object[] objArray61 = new java.lang.Object[] { objArray58, "" };
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException51, localizable53, objArray58);
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException("", objArray58);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException64 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable46, objArray58);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable39, objArray58);
        java.lang.Number number66 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException69 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, number66, (java.lang.Number) 12.801827480081469d, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException73 = new org.apache.commons.math.exception.OutOfRangeException(localizable4, (java.lang.Number) 100, (java.lang.Number) 2.169050661553112d, (java.lang.Number) 1.164058273003315d);
        java.lang.Number number74 = outOfRangeException73.getArgument();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.0d) + "'", number12.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(localizable25);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(localizable39);
        org.junit.Assert.assertNull(localizable42);
        org.junit.Assert.assertNotNull(throwableArray43);
        org.junit.Assert.assertTrue("'" + number52 + "' != '" + (-1.0d) + "'", number52.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertTrue("'" + number74 + "' != '" + 100 + "'", number74.equals(100));
    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test040");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl0.density(100.0d);
//        double double3 = normalDistributionImpl0.getStandardDeviation();
//        double double4 = normalDistributionImpl0.sample();
//        double double5 = normalDistributionImpl0.getMean();
//        try {
//            double double8 = normalDistributionImpl0.cumulativeProbability(0.31761547347786634d, 0.13519368159152448d);
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.4120500753082769d) + "'", double4 == (-0.4120500753082769d));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
//    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test041");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeed();
//        double double13 = randomDataImpl1.nextCauchy((-1.8384102186399753d), 0.34220201852392107d);
//        randomDataImpl1.reSeed((long) 35);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.8555391096189788d) + "'", double4 == (-0.8555391096189788d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.4881761900044095d + "'", double6 == 1.4881761900044095d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.9768520568016226d) + "'", double13 == (-1.9768520568016226d));
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.7742031534326508d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number8 = numberIsTooLargeException7.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] { objArray14, "" };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException7, localizable9, objArray14);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException("", objArray14);
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException("", objArray14);
        org.apache.commons.math.exception.util.Localizable localizable21 = mathException20.getGeneralPattern();
        java.lang.Number number22 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException25 = new org.apache.commons.math.exception.OutOfRangeException(localizable21, number22, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray30 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray30);
        java.lang.String str32 = maxIterationsExceededException31.getPattern();
        java.lang.Object[] objArray33 = maxIterationsExceededException31.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException34 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable21, objArray33);
        org.apache.commons.math.exception.util.Localizable localizable35 = maxIterationsExceededException34.getGeneralPattern();
        java.lang.Throwable throwable36 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException41 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number42 = numberIsTooLargeException41.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        java.lang.Object[] objArray48 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException49 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray48);
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException41, localizable43, objArray48);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException(throwable36, "b0b856f991", objArray48);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException52 = new org.apache.commons.math.MaxIterationsExceededException(1, localizable35, objArray48);
        org.apache.commons.math.exception.util.Localizable localizable53 = maxIterationsExceededException52.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (-1.0d) + "'", number8.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(localizable21);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "hi!" + "'", str32.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(localizable35);
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + (-1.0d) + "'", number42.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNull(localizable53);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray4);
        java.lang.String str6 = maxIterationsExceededException5.getPattern();
        java.lang.String str7 = maxIterationsExceededException5.toString();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException5);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException5);
        java.lang.Number number11 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException(number11, (java.lang.Number) 100, false);
        org.apache.commons.math.exception.util.Localizable localizable15 = numberIsTooSmallException14.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException(localizable18, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than, or equal to, the maximum (10)", objArray19);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException14, "org.apache.commons.math.MaxIterationsExceededException: hi!", objArray19);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException5, "org.apache.commons.math.MaxIterationsExceededException: ", objArray19);
        int int24 = maxIterationsExceededException5.getMaxIterations();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: hi!" + "'", str7.equals("org.apache.commons.math.MaxIterationsExceededException: hi!"));
        org.junit.Assert.assertNull(localizable15);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed();
        try {
            java.lang.String str3 = randomDataImpl0.nextHexString(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0);
        java.lang.String str2 = maxIterationsExceededException1.getPattern();
        java.lang.String str3 = maxIterationsExceededException1.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException8 = new org.apache.commons.math.exception.OutOfRangeException(localizable4, (java.lang.Number) (short) 100, (java.lang.Number) 0.8813735870195429d, (java.lang.Number) 100);
        java.lang.Number number9 = outOfRangeException8.getHi();
        java.lang.String str10 = outOfRangeException8.toString();
        java.lang.String str11 = outOfRangeException8.toString();
        maxIterationsExceededException1.addSuppressed((java.lang.Throwable) outOfRangeException8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "maximal number of iterations ({0}) exceeded" + "'", str2.equals("maximal number of iterations ({0}) exceeded"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "maximal number of iterations ({0}) exceeded" + "'", str3.equals("maximal number of iterations ({0}) exceeded"));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 100 + "'", number9.equals(100));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 100 out of [0.881, 100] range" + "'", str10.equals("org.apache.commons.math.exception.OutOfRangeException: 100 out of [0.881, 100] range"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 100 out of [0.881, 100] range" + "'", str11.equals("org.apache.commons.math.exception.OutOfRangeException: 100 out of [0.881, 100] range"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.07687062953330419d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-4.613095607795176d), number1, false);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-4.613095607795176d) + "'", number4.equals((-4.613095607795176d)));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        double double1 = org.apache.commons.math.util.FastMath.tan((-2.4089034388442125d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8997721702674504d + "'", double1 == 0.8997721702674504d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 4.672738657069999d);
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray13);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray13);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException16 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable6, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException(localizable3, objArray13);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable3, (java.lang.Number) 1.0435012536236978d, (java.lang.Number) 10L, false);
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooLargeException22.getSpecificPattern();
        java.lang.Number number24 = numberIsTooLargeException22.getMax();
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 10L + "'", number24.equals(10L));
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test051");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) (byte) 1);
//        double double5 = randomDataImpl1.nextT((double) 8);
//        randomDataImpl1.reSeed();
//        double double8 = randomDataImpl1.nextChiSquare((double) 100L);
//        try {
//            double double10 = randomDataImpl1.nextT((-0.41196668789851953d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.412 is smaller than, or equal to, the minimum (0): degrees of freedom (-0.412)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.6313317099900062d) + "'", double3 == (-0.6313317099900062d));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.5894469024895423d) + "'", double5 == (-0.5894469024895423d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 89.650878937594d + "'", double8 == 89.650878937594d);
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number7 = numberIsTooLargeException6.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray13);
        java.lang.Object[] objArray16 = new java.lang.Object[] { objArray13, "" };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException6, localizable8, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("", objArray13);
        org.apache.commons.math.exception.util.Localizable localizable20 = mathException19.getGeneralPattern();
        java.lang.Number number21 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException(localizable20, number21, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray29 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray29);
        java.lang.String str31 = maxIterationsExceededException30.getPattern();
        java.lang.Object[] objArray32 = maxIterationsExceededException30.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable20, objArray32);
        java.lang.Class<?> wildcardClass34 = objArray32.getClass();
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1.0d) + "'", number7.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(wildcardClass34);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        double double1 = org.apache.commons.math.util.FastMath.cos(6.97154186626894d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7722910842444254d + "'", double1 == 0.7722910842444254d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray4);
        java.lang.String str6 = maxIterationsExceededException5.getPattern();
        java.lang.String str7 = maxIterationsExceededException5.toString();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException5);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException5);
        org.apache.commons.math.exception.util.Localizable localizable10 = maxIterationsExceededException5.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable13, objArray14);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException16 = new org.apache.commons.math.MaxIterationsExceededException(4, localizable12, objArray14);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable10, objArray14);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable10, (java.lang.Number) 1.0419432903052384d, (java.lang.Number) 8.759744438546308d, false);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: hi!" + "'", str7.equals("org.apache.commons.math.MaxIterationsExceededException: hi!"));
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(objArray14);
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test055");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl0.density(100.0d);
//        double double3 = normalDistributionImpl0.getStandardDeviation();
//        double double4 = normalDistributionImpl0.getStandardDeviation();
//        double double5 = normalDistributionImpl0.sample();
//        double[] doubleArray7 = normalDistributionImpl0.sample((int) '4');
//        double double9 = normalDistributionImpl0.density(0.0d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.4281595067836253d) + "'", double5 == (-0.4281595067836253d));
//        org.junit.Assert.assertNotNull(doubleArray7);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.3989422804014327d + "'", double9 == 0.3989422804014327d);
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        float float2 = org.apache.commons.math.util.FastMath.max(97.0f, (float) 14L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 14.0f + "'", float2 == 14.0f);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number6 = numberIsTooLargeException5.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray12);
        java.lang.Object[] objArray15 = new java.lang.Object[] { objArray12, "" };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException5, localizable7, objArray12);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("", objArray12);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("", objArray12);
        org.apache.commons.math.exception.util.Localizable localizable19 = mathException18.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable19, (java.lang.Number) (-0.6838477032527703d), (java.lang.Number) 37.92811310393632d, false);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1.0d) + "'", number6.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(localizable19);
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test058");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        int int12 = randomDataImpl1.nextZipf(100, 2.718281828459045d);
//        double double14 = randomDataImpl1.nextT(0.9986169222235228d);
//        double double17 = randomDataImpl1.nextCauchy(23.999999999999996d, 5.865998271154641d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl18 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double20 = normalDistributionImpl18.density(100.0d);
//        double double21 = normalDistributionImpl18.getStandardDeviation();
//        double double22 = normalDistributionImpl18.getStandardDeviation();
//        double double23 = normalDistributionImpl18.sample();
//        normalDistributionImpl18.reseedRandomGenerator(4L);
//        double double26 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl18);
//        normalDistributionImpl18.reseedRandomGenerator(34L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.512937361605466d + "'", double4 == 7.512937361605466d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05378410539915176d + "'", double6 == 0.05378410539915176d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 8L + "'", long9 == 8L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.5494947597713595d) + "'", double14 == (-1.5494947597713595d));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 27.43276260662778d + "'", double17 == 27.43276260662778d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.3308512708069835d + "'", double23 == 1.3308512708069835d);
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.7527476589571448d + "'", double26 == 0.7527476589571448d);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (byte) -1, number2, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getSpecificPattern();
        org.junit.Assert.assertNull(localizable5);
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test060");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        long long7 = randomDataImpl1.nextLong((long) (byte) 10, (long) '4');
//        double double10 = randomDataImpl1.nextF(0.7400576788232446d, 0.8018974326990581d);
//        java.lang.Class<?> wildcardClass11 = randomDataImpl1.getClass();
//        double double13 = randomDataImpl1.nextChiSquare(0.8144703685360268d);
//        try {
//            randomDataImpl1.setSecureAlgorithm("166c99109", "org.apache.commons.math.MaxIterationsExceededException: hi!");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: org.apache.commons.math.MaxIterationsExceededException: hi!");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.358819241119406d + "'", double4 == 8.358819241119406d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 21L + "'", long7 == 21L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 5.074722054266424d + "'", double10 == 5.074722054266424d);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.5242870504189211d + "'", double13 == 0.5242870504189211d);
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.941843147108244d, 0.2911771639660623d, (double) '4');
        double[] doubleArray5 = normalDistributionImpl3.sample((int) '#');
        org.junit.Assert.assertNotNull(doubleArray5);
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test062");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        long long3 = randomDataImpl1.nextPoisson((double) 10L);
//        randomDataImpl1.reSeedSecure();
//        int[] intArray7 = randomDataImpl1.nextPermutation((int) 'a', 9);
//        randomDataImpl1.reSeedSecure((long) 100);
//        long long11 = randomDataImpl1.nextPoisson(1.911860368069791E-5d);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9L + "'", long3 == 9L);
//        org.junit.Assert.assertNotNull(intArray7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test063");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        long long7 = randomDataImpl1.nextLong((long) (byte) 10, (long) '4');
//        double double10 = randomDataImpl1.nextBeta(1.471127674303735d, 1.1185087377885383d);
//        try {
//            randomDataImpl1.setSecureAlgorithm("maximal number of iterations ({0}) exceeded", "228820e6ec828c55452a9b78dd24b7559e5cadf9a030cb7dd48bc2034f562f2568a37fa55f843a9ab037457ec6ba45516adb");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 228820e6ec828c55452a9b78dd24b7559e5cadf9a030cb7dd48bc2034f562f2568a37fa55f843a9ab037457ec6ba45516adb");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.200124315223187d + "'", double4 == 8.200124315223187d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 18L + "'", long7 == 18L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.7271870692555471d + "'", double10 == 0.7271870692555471d);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        double double1 = org.apache.commons.math.util.FastMath.floor((-71.51554023463386d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-72.0d) + "'", double1 == (-72.0d));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.3165039057035406d, (java.lang.Number) 2.48941808405721d, false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 2.48941808405721d + "'", number4.equals(2.48941808405721d));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray4);
        java.lang.String str6 = maxIterationsExceededException5.getPattern();
        int int7 = maxIterationsExceededException5.getMaxIterations();
        org.apache.commons.math.exception.util.Localizable localizable8 = maxIterationsExceededException5.getSpecificPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.util.Localizable localizable14 = notStrictlyPositiveException13.getSpecificPattern();
        java.lang.Throwable[] throwableArray15 = notStrictlyPositiveException13.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException16 = new org.apache.commons.math.MaxIterationsExceededException(10, "", (java.lang.Object[]) throwableArray15);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException5, "org.apache.commons.math.MaxIterationsExceededException: ", (java.lang.Object[]) throwableArray15);
        java.lang.Throwable[] throwableArray18 = maxIterationsExceededException5.getSuppressed();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(localizable8);
        org.junit.Assert.assertNull(localizable14);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(throwableArray18);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.1102769287390484d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8041602593975307d + "'", double1 == 0.8041602593975307d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.18013739181591165d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.18112612618392304d + "'", double1 == 0.18112612618392304d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.17862484014276203d, (double) 20, 0.17412425486732214d);
        normalDistributionImpl3.reseedRandomGenerator((long) (byte) 0);
        double[] doubleArray7 = normalDistributionImpl3.sample(32);
        double double8 = normalDistributionImpl3.getMean();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.17862484014276203d + "'", double8 == 0.17862484014276203d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.3578861807931399d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.37445945714835205d + "'", double1 == 0.37445945714835205d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.36509223087486414d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9340908354459301d + "'", double1 == 0.9340908354459301d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        double double1 = org.apache.commons.math.util.FastMath.atan(133.3162601334199d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5632955069786971d + "'", double1 == 1.5632955069786971d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.1261071045310234d);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test074");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl0.density(100.0d);
//        double double3 = normalDistributionImpl0.getStandardDeviation();
//        double double4 = normalDistributionImpl0.getStandardDeviation();
//        double double5 = normalDistributionImpl0.sample();
//        double double6 = normalDistributionImpl0.sample();
//        double double8 = normalDistributionImpl0.density(7.896296018268069E13d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.09218735407260586d) + "'", double5 == (-0.09218735407260586d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0696337135329532d + "'", double6 == 2.0696337135329532d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
//    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        java.lang.Object[] objArray5 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray5);
        java.lang.String str7 = maxIterationsExceededException6.getPattern();
        java.lang.String str8 = maxIterationsExceededException6.toString();
        java.lang.Object[] objArray9 = maxIterationsExceededException6.getArguments();
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("8cc2d200cc", objArray9);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number18 = numberIsTooLargeException17.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray24);
        java.lang.Object[] objArray27 = new java.lang.Object[] { objArray24, "" };
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException17, localizable19, objArray24);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException("", objArray24);
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException("", objArray24);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException10, "40ae077", objArray24);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: hi!" + "'", str8.equals("org.apache.commons.math.MaxIterationsExceededException: hi!"));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (-1.0d) + "'", number18.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray27);
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test076");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        long long7 = randomDataImpl1.nextLong((long) (byte) 10, (long) '4');
//        double double10 = randomDataImpl1.nextBeta(1.471127674303735d, 1.1185087377885383d);
//        randomDataImpl1.reSeed((long) '4');
//        int int15 = randomDataImpl1.nextZipf(4, 1.1713114974625016d);
//        double double18 = randomDataImpl1.nextCauchy((-0.3355134330424695d), 1.1713114974625016d);
//        try {
//            double double21 = randomDataImpl1.nextF(5.38766279556656d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.126654189967669d + "'", double4 == 9.126654189967669d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.4232348087758859d + "'", double10 == 0.4232348087758859d);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.17759321550844975d + "'", double18 == 0.17759321550844975d);
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) ' ', (double) (short) 10);
        double double5 = normalDistributionImpl2.cumulativeProbability(0.05260031770763203d, 4.789142871249076d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0025536099942406465d + "'", double5 == 0.0025536099942406465d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) (short) 100, (java.lang.Number) 0.8813735870195429d, (java.lang.Number) 100);
        java.lang.Number number6 = outOfRangeException5.getLo();
        java.lang.Throwable[] throwableArray7 = outOfRangeException5.getSuppressed();
        java.lang.Number number8 = outOfRangeException5.getHi();
        org.apache.commons.math.exception.util.Localizable localizable9 = outOfRangeException5.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = outOfRangeException5.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.2500542675426494d, (java.lang.Number) 0.5d, true);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number22 = numberIsTooLargeException21.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray28);
        java.lang.Object[] objArray31 = new java.lang.Object[] { objArray28, "" };
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException21, localizable23, objArray28);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray28);
        java.lang.Throwable[] throwableArray34 = mathIllegalArgumentException33.getSuppressed();
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException14, "1c76cf7fae145a93636deac63b24b958656c72134bd2fc583c22a7839ddaab9ae5c68f3f58998a6169f62d36e2cc70e45574", (java.lang.Object[]) throwableArray34);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable10, (java.lang.Object[]) throwableArray34);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.8813735870195429d + "'", number6.equals(0.8813735870195429d));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 100 + "'", number8.equals(100));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (-1.0d) + "'", number22.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(throwableArray34);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 155.74607629780772d, (java.lang.Number) 1.333707301036022d);
        org.apache.commons.math.exception.util.Localizable localizable4 = outOfRangeException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 4.0d, (java.lang.Number) (-0.530197124927653d), false);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-2.374845165237864d), (java.lang.Number) (-9.012841493147322d), true);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        double double1 = org.apache.commons.math.util.FastMath.cos(26.632782614397353d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.07069591959980931d + "'", double1 == 0.07069591959980931d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.6497517500661671d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.7387963814485965d, 1.1308564921585762d, 1.9002507367077104d);
        double double6 = normalDistributionImpl3.cumulativeProbability((-0.6376630821062104d), 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.044274226122234195d + "'", double6 == 0.044274226122234195d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number7 = numberIsTooLargeException6.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray13);
        java.lang.Object[] objArray16 = new java.lang.Object[] { objArray13, "" };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException6, localizable8, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("", objArray13);
        org.apache.commons.math.exception.util.Localizable localizable20 = mathException19.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException(localizable20, (java.lang.Number) 0.36496488262332794d, (java.lang.Number) 0.6439528600818949d, (java.lang.Number) 1.3052608122477107d);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException26 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable20, (java.lang.Number) 1.91682296922358d);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Object[] objArray36 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray36);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray36);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException39 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable29, objArray36);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException("", objArray36);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(localizable20, objArray36);
        java.lang.Object[] objArray46 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException47 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray46);
        java.lang.String str48 = maxIterationsExceededException47.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        java.lang.Object[] objArray59 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException60 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray59);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException61 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray59);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException62 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable52, objArray59);
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException("", objArray59);
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException47, localizable49, objArray59);
        java.lang.Throwable[] throwableArray65 = maxIterationsExceededException47.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException(throwable0, localizable20, (java.lang.Object[]) throwableArray65);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1.0d) + "'", number7.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "hi!" + "'", str48.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNotNull(throwableArray65);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.7837218672022305d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6548377739863794d + "'", double1 == 0.6548377739863794d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.density(100.0d);
        double double3 = normalDistributionImpl0.getStandardDeviation();
        double double4 = normalDistributionImpl0.getStandardDeviation();
        normalDistributionImpl0.reseedRandomGenerator((long) 6);
        double double8 = normalDistributionImpl0.density((-0.6601159579592064d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.3208392461239527d + "'", double8 == 0.3208392461239527d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        double double1 = org.apache.commons.math.util.FastMath.sinh(15.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1634508.6862359024d + "'", double1 == 1634508.6862359024d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.29743732778569243d, (-0.04261520489571098d), 0.040706524570184074d, (int) 'a');
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 5L, true);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 6.0d, (java.lang.Number) 8.054359047689252E13d, true);
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooLargeException7.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number16 = numberIsTooLargeException15.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray22);
        java.lang.Object[] objArray25 = new java.lang.Object[] { objArray22, "" };
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException15, localizable17, objArray22);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException("", objArray22);
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException("", objArray22);
        org.apache.commons.math.exception.util.Localizable localizable29 = mathException28.getGeneralPattern();
        java.lang.Number number30 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException(localizable29, number30, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray38 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException39 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray38);
        java.lang.String str40 = maxIterationsExceededException39.getPattern();
        java.lang.Object[] objArray41 = maxIterationsExceededException39.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException42 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable29, objArray41);
        org.apache.commons.math.exception.util.Localizable localizable43 = maxIterationsExceededException42.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException45 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.util.Localizable localizable46 = notStrictlyPositiveException45.getSpecificPattern();
        java.lang.Throwable[] throwableArray47 = notStrictlyPositiveException45.getSuppressed();
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException(localizable43, (java.lang.Object[]) throwableArray47);
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException55 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number56 = numberIsTooLargeException55.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        java.lang.Object[] objArray62 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException63 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray62);
        java.lang.Object[] objArray65 = new java.lang.Object[] { objArray62, "" };
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException55, localizable57, objArray62);
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException("", objArray62);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException68 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable50, objArray62);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException69 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable43, objArray62);
        java.lang.Number number70 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException73 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable8, number70, (java.lang.Number) 12.801827480081469d, false);
        boolean boolean74 = numberIsTooLargeException73.getBoundIsAllowed();
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooLargeException73);
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (-1.0d) + "'", number16.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(localizable29);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "hi!" + "'", str40.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(localizable43);
        org.junit.Assert.assertNull(localizable46);
        org.junit.Assert.assertNotNull(throwableArray47);
        org.junit.Assert.assertTrue("'" + number56 + "' != '" + (-1.0d) + "'", number56.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.3831016828731771d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4668271736870688d + "'", double1 == 1.4668271736870688d);
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test091");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        randomDataImpl1.reSeed();
//        double double13 = randomDataImpl1.nextCauchy(5.853949697499888d, 0.006937366662896952d);
//        double double15 = randomDataImpl1.nextChiSquare(0.761666183444699d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 119.58145313387d + "'", double4 == 119.58145313387d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.5504246114235538d + "'", double6 == 1.5504246114235538d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 6.031297221864072d + "'", double13 == 6.031297221864072d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.4368422012820137d + "'", double15 == 3.4368422012820137d);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        double double1 = org.apache.commons.math.util.FastMath.log(0.36390172746558747d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0108714272865642d) + "'", double1 == (-1.0108714272865642d));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray9);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray9);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable2, objArray9);
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException("5fa2692c956e6b17b0ae0645ae88e67a635", objArray9);
        java.lang.Object[] objArray19 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray19);
        java.lang.String str21 = maxIterationsExceededException20.getPattern();
        java.lang.Object[] objArray22 = maxIterationsExceededException20.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.MathException: hi!", objArray22);
        mathException13.addSuppressed((java.lang.Throwable) convergenceException23);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray22);
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test094");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        int[] intArray15 = randomDataImpl1.nextPermutation((int) ' ', (int) (short) 1);
//        randomDataImpl1.reSeed();
//        randomDataImpl1.reSeedSecure(18L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-397.3673959977177d) + "'", double4 == (-397.3673959977177d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.3370797607592374d + "'", double6 == 0.3370797607592374d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(intArray15);
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 52, (long) 18);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (short) 100, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.7387963814485965d, 1.1308564921585762d, 1.9002507367077104d);
        double double4 = normalDistributionImpl3.getMean();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.7387963814485965d + "'", double4 == 1.7387963814485965d);
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test098");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) (byte) 1);
//        randomDataImpl1.reSeed((long) (byte) -1);
//        long long7 = randomDataImpl1.nextPoisson(4.563166836687243d);
//        double double10 = randomDataImpl1.nextWeibull(0.003255247095197669d, 0.07069591959980931d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-104.27657900206226d) + "'", double3 == (-104.27657900206226d));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 5.349140468046405E9d + "'", double10 == 5.349140468046405E9d);
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 6.0d, (java.lang.Number) 8.054359047689252E13d, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number13 = numberIsTooLargeException12.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray19);
        java.lang.Object[] objArray22 = new java.lang.Object[] { objArray19, "" };
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException12, localizable14, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("", objArray19);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException("", objArray19);
        org.apache.commons.math.exception.util.Localizable localizable26 = mathException25.getGeneralPattern();
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException30 = new org.apache.commons.math.exception.OutOfRangeException(localizable26, number27, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray35 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray35);
        java.lang.String str37 = maxIterationsExceededException36.getPattern();
        java.lang.Object[] objArray38 = maxIterationsExceededException36.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException39 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable26, objArray38);
        org.apache.commons.math.exception.util.Localizable localizable40 = maxIterationsExceededException39.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException42 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.util.Localizable localizable43 = notStrictlyPositiveException42.getSpecificPattern();
        java.lang.Throwable[] throwableArray44 = notStrictlyPositiveException42.getSuppressed();
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException(localizable40, (java.lang.Object[]) throwableArray44);
        org.apache.commons.math.exception.util.Localizable localizable47 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException52 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number53 = numberIsTooLargeException52.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        java.lang.Object[] objArray59 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException60 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray59);
        java.lang.Object[] objArray62 = new java.lang.Object[] { objArray59, "" };
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException52, localizable54, objArray59);
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException("", objArray59);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException65 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable47, objArray59);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException66 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable40, objArray59);
        org.apache.commons.math.exception.util.Localizable localizable67 = null;
        java.lang.Object[] objArray72 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException73 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray72);
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException(localizable67, objArray72);
        org.apache.commons.math.MathException mathException75 = new org.apache.commons.math.MathException(throwable0, localizable5, objArray72);
        java.lang.Number number76 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException77 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, number76);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException81 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) (-0.380551639502605d), (java.lang.Number) (-0.532466034258566d), false);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-1.0d) + "'", number13.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(localizable26);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(localizable40);
        org.junit.Assert.assertNull(localizable43);
        org.junit.Assert.assertNotNull(throwableArray44);
        org.junit.Assert.assertTrue("'" + number53 + "' != '" + (-1.0d) + "'", number53.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertNotNull(objArray72);
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test100");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        int[] intArray15 = randomDataImpl1.nextPermutation((int) ' ', (int) (short) 1);
//        try {
//            int int18 = randomDataImpl1.nextPascal(52, (-8.725262846060508d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -8.725 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 84.01029886364263d + "'", double4 == 84.01029886364263d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.5717477157956472d + "'", double6 == 1.5717477157956472d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
//        org.junit.Assert.assertNotNull(intArray15);
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0.9999546000702375d, (java.lang.Number) (-0.008252437515514003d), false);
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException4);
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test102");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        long long7 = randomDataImpl1.nextLong((long) (byte) 10, (long) '4');
//        double double10 = randomDataImpl1.nextBeta(1.471127674303735d, 1.1185087377885383d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double13 = normalDistributionImpl11.density(100.0d);
//        double double14 = normalDistributionImpl11.getStandardDeviation();
//        double double15 = normalDistributionImpl11.sample();
//        double double17 = normalDistributionImpl11.cumulativeProbability((double) (byte) 10);
//        double[] doubleArray19 = normalDistributionImpl11.sample((int) (byte) 100);
//        double double20 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        double double22 = randomDataImpl1.nextExponential(0.8187666961461416d);
//        randomDataImpl1.reSeed();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 61.50601208359666d + "'", double4 == 61.50601208359666d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 17L + "'", long7 == 17L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.5958403580142331d + "'", double10 == 0.5958403580142331d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.3773881749594688d + "'", double15 == 0.3773881749594688d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
//        org.junit.Assert.assertNotNull(doubleArray19);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-0.16924405206304444d) + "'", double20 == (-0.16924405206304444d));
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.5860988871965757d + "'", double22 == 0.5860988871965757d);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray9);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray9);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable2, objArray9);
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException("", objArray9);
        java.lang.String str14 = convergenceException13.getPattern();
        java.lang.String str15 = convergenceException13.getPattern();
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.1185087377885383d, (java.lang.Number) 10, (java.lang.Number) 0.0076354937841634045d);
        org.apache.commons.math.exception.util.Localizable localizable4 = outOfRangeException3.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException4.getSpecificPattern();
        java.lang.Throwable[] throwableArray6 = notStrictlyPositiveException4.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException(10, "", (java.lang.Object[]) throwableArray6);
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (100)", (java.lang.Object[]) throwableArray6);
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        int int1 = org.apache.commons.math.util.FastMath.abs(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test107");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeed((long) (short) 0);
//        try {
//            double double17 = randomDataImpl1.nextWeibull((-0.008252437515514003d), 1.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.008 is smaller than, or equal to, the minimum (0): shape (-0.008)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 15.030418513837317d + "'", double4 == 15.030418513837317d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.38740834879523295d + "'", double6 == 0.38740834879523295d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray4);
        java.lang.String str6 = maxIterationsExceededException5.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray17);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray17);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable10, objArray17);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException("", objArray17);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException5, localizable7, objArray17);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException5);
        java.lang.Object[] objArray24 = mathException23.getArguments();
        java.lang.String str25 = mathException23.toString();
        java.lang.Number number26 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException(number26, (java.lang.Number) 155.74607629780772d, (java.lang.Number) 1.333707301036022d);
        java.lang.Number number30 = outOfRangeException29.getLo();
        mathException23.addSuppressed((java.lang.Throwable) outOfRangeException29);
        java.lang.Number number32 = outOfRangeException29.getArgument();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.apache.commons.math.MathException: hi!" + "'", str25.equals("org.apache.commons.math.MathException: hi!"));
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 155.74607629780772d + "'", number30.equals(155.74607629780772d));
        org.junit.Assert.assertNull(number32);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.7718551054848756d, number1, true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test110");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        long long7 = randomDataImpl1.nextLong((long) (byte) 10, (long) '4');
//        double double10 = randomDataImpl1.nextF(0.7400576788232446d, 0.8018974326990581d);
//        double double13 = randomDataImpl1.nextGamma(0.8426819462428745d, 0.661899304433709d);
//        int int16 = randomDataImpl1.nextSecureInt((int) (short) 0, (int) (short) 1);
//        try {
//            long long18 = randomDataImpl1.nextPoisson((-0.4064624400499381d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.406 is smaller than, or equal to, the minimum (0): mean (-0.406)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 16.94735108445076d + "'", double4 == 16.94735108445076d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 42L + "'", long7 == 42L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.11049509199532956d + "'", double10 == 0.11049509199532956d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.692447251507263d + "'", double13 == 0.692447251507263d);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.5504246114235538d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (short) 100, (java.lang.Number) 0.8813735870195429d, (java.lang.Number) 100);
        java.lang.Number number5 = outOfRangeException4.getLo();
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.8813735870195429d + "'", number5.equals(0.8813735870195429d));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 52.11866024219715d, (java.lang.Number) 0.9999584626848042d, (java.lang.Number) (-0.015722159129280943d));
        org.apache.commons.math.exception.util.Localizable localizable4 = outOfRangeException3.getSpecificPattern();
        java.lang.Number number5 = outOfRangeException3.getHi();
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-0.015722159129280943d) + "'", number5.equals((-0.015722159129280943d)));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.7420057716064438d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6303554722736091d + "'", double1 == 0.6303554722736091d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray10);
        java.lang.Object[] objArray13 = new java.lang.Object[] { objArray10, "" };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3, localizable5, objArray10);
        java.lang.Object[] objArray15 = convergenceException14.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable16 = convergenceException14.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0d) + "'", number4.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNull(localizable16);
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test117");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        int[] intArray15 = randomDataImpl1.nextPermutation((int) ' ', (int) (short) 1);
//        randomDataImpl1.reSeed();
//        double double19 = randomDataImpl1.nextGamma(10.0d, 0.13653950079971308d);
//        try {
//            int[] intArray22 = randomDataImpl1.nextPermutation(15, 32);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 32 is larger than the maximum (15): permutation size (32) exceeds permuation domain (15)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 19.193309747776695d + "'", double4 == 19.193309747776695d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.3713135247535753d + "'", double6 == 1.3713135247535753d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.9992023013316185d + "'", double19 == 1.9992023013316185d);
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double1 = normalDistributionImpl0.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        double double1 = org.apache.commons.math.special.Gamma.digamma(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8049262717364689d + "'", double1 == 0.8049262717364689d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.21982219793726177d), (java.lang.Number) 0.05273259000615482d, true);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        java.lang.Object[] objArray5 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray5);
        java.lang.String str7 = maxIterationsExceededException6.getPattern();
        java.lang.String str8 = maxIterationsExceededException6.toString();
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException6);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException6);
        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException6.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException(localizable14, objArray15);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException(4, localizable13, objArray15);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException(localizable11, objArray15);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException("166c99109", objArray15);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: hi!" + "'", str8.equals("org.apache.commons.math.MaxIterationsExceededException: hi!"));
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray15);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.4711276743037347d, (double) 1L);
        double double3 = normalDistributionImpl2.getStandardDeviation();
        double double5 = normalDistributionImpl2.density(2.220446049250313E-16d);
        double double7 = normalDistributionImpl2.inverseCumulativeProbability(0.36509223087486414d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.13519368159152453d + "'", double5 == 0.13519368159152453d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.1262475078488092d + "'", double7 == 1.1262475078488092d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.1185087377885383d, (java.lang.Number) 10, (java.lang.Number) 0.0076354937841634045d);
        java.lang.Number number4 = outOfRangeException3.getHi();
        java.lang.Number number5 = outOfRangeException3.getHi();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.0076354937841634045d + "'", number4.equals(0.0076354937841634045d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0076354937841634045d + "'", number5.equals(0.0076354937841634045d));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) 32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 78.0922235533153d + "'", double1 == 78.0922235533153d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        int int1 = org.apache.commons.math.util.FastMath.abs(4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 100L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-2.9386644769927934d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.4711276743037347d, (double) 1L);
        double double3 = normalDistributionImpl2.getStandardDeviation();
        double double4 = normalDistributionImpl2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 6.0d, (java.lang.Number) 8.054359047689252E13d, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number13 = numberIsTooLargeException12.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray19);
        java.lang.Object[] objArray22 = new java.lang.Object[] { objArray19, "" };
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException12, localizable14, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("", objArray19);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException("", objArray19);
        org.apache.commons.math.exception.util.Localizable localizable26 = mathException25.getGeneralPattern();
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException30 = new org.apache.commons.math.exception.OutOfRangeException(localizable26, number27, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray35 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray35);
        java.lang.String str37 = maxIterationsExceededException36.getPattern();
        java.lang.Object[] objArray38 = maxIterationsExceededException36.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException39 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable26, objArray38);
        org.apache.commons.math.exception.util.Localizable localizable40 = maxIterationsExceededException39.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException42 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.util.Localizable localizable43 = notStrictlyPositiveException42.getSpecificPattern();
        java.lang.Throwable[] throwableArray44 = notStrictlyPositiveException42.getSuppressed();
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException(localizable40, (java.lang.Object[]) throwableArray44);
        org.apache.commons.math.exception.util.Localizable localizable47 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException52 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number53 = numberIsTooLargeException52.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        java.lang.Object[] objArray59 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException60 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray59);
        java.lang.Object[] objArray62 = new java.lang.Object[] { objArray59, "" };
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException52, localizable54, objArray59);
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException("", objArray59);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException65 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable47, objArray59);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException66 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable40, objArray59);
        org.apache.commons.math.exception.util.Localizable localizable67 = null;
        java.lang.Object[] objArray72 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException73 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray72);
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException(localizable67, objArray72);
        org.apache.commons.math.MathException mathException75 = new org.apache.commons.math.MathException(throwable0, localizable5, objArray72);
        org.apache.commons.math.exception.util.Localizable localizable80 = null;
        java.lang.Object[] objArray87 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException88 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray87);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException89 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray87);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException90 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable80, objArray87);
        org.apache.commons.math.MathException mathException91 = new org.apache.commons.math.MathException("5fa2692c956e6b17b0ae0645ae88e67a635", objArray87);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException92 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, "0d2ac2d91eeb5f37139b635c926bd996e56", objArray87);
        org.apache.commons.math.ConvergenceException convergenceException93 = new org.apache.commons.math.ConvergenceException(localizable5, objArray87);
        org.apache.commons.math.MathException mathException94 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException93);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-1.0d) + "'", number13.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(localizable26);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(localizable40);
        org.junit.Assert.assertNull(localizable43);
        org.junit.Assert.assertNotNull(throwableArray44);
        org.junit.Assert.assertTrue("'" + number53 + "' != '" + (-1.0d) + "'", number53.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertNotNull(objArray72);
        org.junit.Assert.assertNotNull(objArray87);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        double double2 = org.apache.commons.math.util.FastMath.max(0.22613396021060134d, 0.3489200020960855d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3489200020960855d + "'", double2 == 0.3489200020960855d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.263934917330771d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.022059825838344295d + "'", double1 == 0.022059825838344295d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(7.291140084956589d, 0.01090388071289713d, 102.41106683260354d, (int) '#');
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 5.336844217774338E-19d + "'", double4 == 5.336844217774338E-19d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        double double1 = org.apache.commons.math.util.FastMath.expm1(5.860060723059558d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 349.74544170962304d + "'", double1 == 349.74544170962304d);
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test134");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) 'a');
//        randomDataImpl1.reSeedSecure();
//        int int15 = randomDataImpl1.nextBinomial(2, 0.05746016866185325d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-9.894368827561399d) + "'", double4 == (-9.894368827561399d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.38907396424594154d + "'", double6 == 0.38907396424594154d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((-0.4705444516411526d), 0.37653510734157053d, 0.0d, 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.17862484014276203d, (double) 20, 0.17412425486732214d);
        normalDistributionImpl3.reseedRandomGenerator((long) (byte) 0);
        double[] doubleArray7 = normalDistributionImpl3.sample(6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.361562941897067d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number8 = numberIsTooLargeException7.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] { objArray14, "" };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException7, localizable9, objArray14);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException("", objArray14);
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException("", objArray14);
        org.apache.commons.math.exception.util.Localizable localizable21 = mathException20.getGeneralPattern();
        java.lang.Number number22 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException25 = new org.apache.commons.math.exception.OutOfRangeException(localizable21, number22, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException29 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (short) -1, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable30 = numberIsTooLargeException29.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        java.lang.Object[] objArray33 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException(localizable32, objArray33);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than, or equal to, the maximum (10)", objArray33);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable30, objArray33);
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException1, localizable21, objArray33);
        org.apache.commons.math.exception.util.Localizable localizable38 = convergenceException37.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (-1.0d) + "'", number8.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(localizable21);
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNull(localizable38);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 3.241723184387021d, (java.lang.Number) 0.31761547347786634d, true);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.8651127901816617d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test140");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        double double15 = randomDataImpl1.nextWeibull(40.223410238970004d, 0.11876664467085814d);
//        try {
//            double double18 = randomDataImpl1.nextF((double) 61L, (-0.19435966086869458d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.194 is smaller than, or equal to, the minimum (0): degrees of freedom (-0.194)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-7.740411945255962d) + "'", double4 == (-7.740411945255962d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.11439561037101939d + "'", double6 == 0.11439561037101939d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.11629230600575491d + "'", double15 == 0.11629230600575491d);
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number7 = numberIsTooLargeException6.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray13);
        java.lang.Object[] objArray16 = new java.lang.Object[] { objArray13, "" };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException6, localizable8, objArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, localizable2, objArray13);
        java.lang.Throwable[] throwableArray19 = mathIllegalArgumentException18.getSuppressed();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number24 = numberIsTooLargeException23.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray30 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray30);
        java.lang.Object[] objArray33 = new java.lang.Object[] { objArray30, "" };
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException23, localizable25, objArray30);
        java.lang.Object[] objArray35 = numberIsTooLargeException23.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable36 = numberIsTooLargeException23.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException43 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number44 = numberIsTooLargeException43.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        java.lang.Object[] objArray50 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException51 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray50);
        java.lang.Object[] objArray53 = new java.lang.Object[] { objArray50, "" };
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException43, localizable45, objArray50);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException55 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable39, objArray50);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException56 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', "", objArray50);
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalArgumentException18, localizable36, objArray50);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException59 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable36, (java.lang.Number) 0.006937366662896952d);
        java.lang.Object[] objArray60 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException61 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', localizable36, objArray60);
        java.lang.String str62 = maxIterationsExceededException61.toString();
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1.0d) + "'", number7.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (-1.0d) + "'", number24.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number44 + "' != '" + (-1.0d) + "'", number44.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: {0} is larger than, or equal to, the maximum ({1})" + "'", str62.equals("org.apache.commons.math.MaxIterationsExceededException: {0} is larger than, or equal to, the maximum ({1})"));
    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test142");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT(4.599102285891914d);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure(48L);
//        int int9 = randomDataImpl1.nextInt(0, 47);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.6779092135215459d) + "'", double3 == (-1.6779092135215459d));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 31 + "'", int9 == 31);
//    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number8 = numberIsTooLargeException7.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] { objArray14, "" };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException7, localizable9, objArray14);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException("", objArray14);
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException("", objArray14);
        org.apache.commons.math.exception.util.Localizable localizable21 = mathException20.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException25 = new org.apache.commons.math.exception.OutOfRangeException(localizable21, (java.lang.Number) 0.36496488262332794d, (java.lang.Number) 0.6439528600818949d, (java.lang.Number) 1.3052608122477107d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException29 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable21, (java.lang.Number) 1, (java.lang.Number) (byte) 10, true);
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException34 = new org.apache.commons.math.exception.OutOfRangeException(localizable30, (java.lang.Number) (byte) 10, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) 0.0f);
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException39 = new org.apache.commons.math.exception.OutOfRangeException(localizable35, (java.lang.Number) (short) 100, (java.lang.Number) 0.8813735870195429d, (java.lang.Number) 100);
        java.lang.Number number40 = outOfRangeException39.getLo();
        java.lang.Throwable[] throwableArray41 = outOfRangeException39.getSuppressed();
        java.lang.Number number42 = outOfRangeException39.getHi();
        org.apache.commons.math.exception.util.Localizable localizable43 = outOfRangeException39.getGeneralPattern();
        outOfRangeException34.addSuppressed((java.lang.Throwable) outOfRangeException39);
        java.lang.Object[] objArray45 = outOfRangeException34.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException(localizable21, objArray45);
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException(throwable0, "0d2ac2d91eeb5f37139b635c926bd996e56", objArray45);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (-1.0d) + "'", number8.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(localizable21);
        org.junit.Assert.assertTrue("'" + number40 + "' != '" + 0.8813735870195429d + "'", number40.equals(0.8813735870195429d));
        org.junit.Assert.assertNotNull(throwableArray41);
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 100 + "'", number42.equals(100));
        org.junit.Assert.assertTrue("'" + localizable43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable43.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray45);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeedSecure();
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.1465938842655768d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number8 = numberIsTooLargeException7.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] { objArray14, "" };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException7, localizable9, objArray14);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException("", objArray14);
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException("", objArray14);
        org.apache.commons.math.exception.util.Localizable localizable21 = mathException20.getGeneralPattern();
        java.lang.Number number22 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException25 = new org.apache.commons.math.exception.OutOfRangeException(localizable21, number22, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray30 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray30);
        java.lang.String str32 = maxIterationsExceededException31.getPattern();
        java.lang.Object[] objArray33 = maxIterationsExceededException31.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException34 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable21, objArray33);
        java.lang.Object[] objArray35 = null;
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException(localizable21, objArray35);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException40 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable21, (java.lang.Number) (-0.045307020123132084d), (java.lang.Number) 9L, true);
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        java.lang.Object[] objArray47 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray47);
        java.lang.String str49 = maxIterationsExceededException48.getPattern();
        java.lang.String str50 = maxIterationsExceededException48.toString();
        java.lang.Object[] objArray51 = maxIterationsExceededException48.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException52 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, localizable42, objArray51);
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException(localizable21, objArray51);
        java.lang.Object[] objArray58 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException59 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray58);
        java.lang.String str60 = maxIterationsExceededException59.getPattern();
        java.lang.String str61 = maxIterationsExceededException59.toString();
        org.apache.commons.math.MathException mathException62 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException59);
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException59);
        org.apache.commons.math.exception.util.Localizable localizable64 = maxIterationsExceededException59.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable65 = null;
        org.apache.commons.math.exception.util.Localizable localizable66 = null;
        java.lang.Number number67 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException70 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable66, number67, (java.lang.Number) (-0.17738444574517354d), true);
        java.lang.Throwable[] throwableArray71 = numberIsTooSmallException70.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException(localizable65, (java.lang.Object[]) throwableArray71);
        java.lang.Object[] objArray73 = convergenceException72.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException74 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable21, localizable64, objArray73);
        java.lang.Object[] objArray79 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException80 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray79);
        java.lang.String str81 = maxIterationsExceededException80.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable82 = null;
        org.apache.commons.math.exception.util.Localizable localizable85 = null;
        java.lang.Object[] objArray92 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException93 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray92);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException94 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray92);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException95 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable85, objArray92);
        org.apache.commons.math.ConvergenceException convergenceException96 = new org.apache.commons.math.ConvergenceException("", objArray92);
        org.apache.commons.math.ConvergenceException convergenceException97 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException80, localizable82, objArray92);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException98 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, localizable64, objArray92);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (-1.0d) + "'", number8.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(localizable21);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "hi!" + "'", str32.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "hi!" + "'", str49.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: hi!" + "'", str50.equals("org.apache.commons.math.MaxIterationsExceededException: hi!"));
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "hi!" + "'", str60.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: hi!" + "'", str61.equals("org.apache.commons.math.MaxIterationsExceededException: hi!"));
        org.junit.Assert.assertNotNull(localizable64);
        org.junit.Assert.assertNotNull(throwableArray71);
        org.junit.Assert.assertNotNull(objArray73);
        org.junit.Assert.assertNotNull(objArray79);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "hi!" + "'", str81.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray92);
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test147");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        double double14 = randomDataImpl1.nextT(0.7627350637656639d);
//        double double17 = randomDataImpl1.nextGaussian((double) (byte) 1, 0.29495535414077817d);
//        randomDataImpl1.reSeedSecure((long) 100);
//        int int22 = randomDataImpl1.nextSecureInt((int) (byte) 10, (int) (byte) 100);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl23 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double24 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl23);
//        java.lang.String str26 = randomDataImpl1.nextHexString(71);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.6379944091989227d) + "'", double4 == (-1.6379944091989227d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.4150234238128611d + "'", double6 == 0.4150234238128611d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 18.02066667402018d + "'", double14 == 18.02066667402018d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.026082772091406d + "'", double17 == 1.026082772091406d);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.770792026483381d + "'", double24 == 1.770792026483381d);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "81155106378caaccb5f3ba5c6d5591682b9d2b823c4eb51935759cccfa73a79f88413d3" + "'", str26.equals("81155106378caaccb5f3ba5c6d5591682b9d2b823c4eb51935759cccfa73a79f88413d3"));
//    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-0.1465938842655768d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test149");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        int int12 = randomDataImpl1.nextZipf(100, 2.718281828459045d);
//        double double14 = randomDataImpl1.nextT(0.9986169222235228d);
//        int int17 = randomDataImpl1.nextInt((int) (byte) 1, 85);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.6225247709363915d) + "'", double4 == (-1.6225247709363915d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.006307490359122d + "'", double6 == 4.006307490359122d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 4L + "'", long9 == 4L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.3436918951763255d) + "'", double14 == (-1.3436918951763255d));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 5 + "'", int17 == 5);
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        double double2 = org.apache.commons.math.util.FastMath.min(0.9999999997059648d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.10460946955844201d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.5269469083754401d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        float float2 = org.apache.commons.math.util.FastMath.min((-1.0f), (float) 47);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test154");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) (byte) 1);
//        int int6 = randomDataImpl1.nextInt((int) (short) 1, 10);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.5970067801423443d) + "'", double3 == (-0.5970067801423443d));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(3.1545686361523138d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8404063516935795d + "'", double1 == 0.8404063516935795d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        double double1 = org.apache.commons.math.util.FastMath.rint(63.001116540868786d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 63.0d + "'", double1 == 63.0d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 6.0d, (java.lang.Number) 8.054359047689252E13d, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number13 = numberIsTooLargeException12.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray19);
        java.lang.Object[] objArray22 = new java.lang.Object[] { objArray19, "" };
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException12, localizable14, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("", objArray19);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException("", objArray19);
        org.apache.commons.math.exception.util.Localizable localizable26 = mathException25.getGeneralPattern();
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException30 = new org.apache.commons.math.exception.OutOfRangeException(localizable26, number27, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray35 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray35);
        java.lang.String str37 = maxIterationsExceededException36.getPattern();
        java.lang.Object[] objArray38 = maxIterationsExceededException36.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException39 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable26, objArray38);
        org.apache.commons.math.exception.util.Localizable localizable40 = maxIterationsExceededException39.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException42 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.util.Localizable localizable43 = notStrictlyPositiveException42.getSpecificPattern();
        java.lang.Throwable[] throwableArray44 = notStrictlyPositiveException42.getSuppressed();
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException(localizable40, (java.lang.Object[]) throwableArray44);
        org.apache.commons.math.exception.util.Localizable localizable47 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException52 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number53 = numberIsTooLargeException52.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        java.lang.Object[] objArray59 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException60 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray59);
        java.lang.Object[] objArray62 = new java.lang.Object[] { objArray59, "" };
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException52, localizable54, objArray59);
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException("", objArray59);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException65 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable47, objArray59);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException66 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable40, objArray59);
        org.apache.commons.math.exception.util.Localizable localizable67 = null;
        java.lang.Object[] objArray72 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException73 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray72);
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException(localizable67, objArray72);
        org.apache.commons.math.MathException mathException75 = new org.apache.commons.math.MathException(throwable0, localizable5, objArray72);
        java.lang.Number number76 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException77 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, number76);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException81 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 2.4611002279344573E-15d, (java.lang.Number) 1.1102230246251565E-16d, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException85 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 2.0146226312358714E-258d, (java.lang.Number) (-0.27861083953310206d), true);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-1.0d) + "'", number13.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(localizable26);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(localizable40);
        org.junit.Assert.assertNull(localizable43);
        org.junit.Assert.assertNotNull(throwableArray44);
        org.junit.Assert.assertTrue("'" + number53 + "' != '" + (-1.0d) + "'", number53.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertNotNull(objArray72);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.5220349218107092d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5752670100646318d + "'", double1 == 0.5752670100646318d);
    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test159");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        int int12 = randomDataImpl1.nextZipf(100, 2.718281828459045d);
//        double double15 = randomDataImpl1.nextCauchy(2.092790987315211d, 0.8813735870195429d);
//        double double18 = randomDataImpl1.nextGaussian((double) 10.0f, (double) 8);
//        int int21 = randomDataImpl1.nextPascal(20, 0.9999999997059648d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-4.0846520214904904d) + "'", double4 == (-4.0846520214904904d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0015302749701215212d + "'", double6 == 0.0015302749701215212d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.8990848379300225d + "'", double15 == 1.8990848379300225d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 5.414342797096762d + "'", double18 == 5.414342797096762d);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.005248366233766214d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5655479364661526d + "'", double1 == 1.5655479364661526d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.5264888286059799d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.009188963534142457d + "'", double1 == 0.009188963534142457d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.8144703685360268d, (java.lang.Number) 18.95083653482282d, true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.3165039057035406d, (java.lang.Number) 2.48941808405721d, false);
        java.lang.String str4 = numberIsTooLargeException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: 0.317 is larger than, or equal to, the maximum (2.489)" + "'", str4.equals("org.apache.commons.math.exception.NumberIsTooLargeException: 0.317 is larger than, or equal to, the maximum (2.489)"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number7 = numberIsTooLargeException6.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray13);
        java.lang.Object[] objArray16 = new java.lang.Object[] { objArray13, "" };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException6, localizable8, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("", objArray13);
        org.apache.commons.math.exception.util.Localizable localizable20 = mathException19.getGeneralPattern();
        java.lang.Number number21 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException(localizable20, number21, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray29 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray29);
        java.lang.String str31 = maxIterationsExceededException30.getPattern();
        java.lang.Object[] objArray32 = maxIterationsExceededException30.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable20, objArray32);
        java.lang.Object[] objArray34 = null;
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException(localizable20, objArray34);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException39 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable20, (java.lang.Number) (-0.045307020123132084d), (java.lang.Number) 9L, true);
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        java.lang.Object[] objArray46 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException47 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray46);
        java.lang.String str48 = maxIterationsExceededException47.getPattern();
        java.lang.String str49 = maxIterationsExceededException47.toString();
        java.lang.Object[] objArray50 = maxIterationsExceededException47.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException51 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, localizable41, objArray50);
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException(localizable20, objArray50);
        java.lang.Object[] objArray57 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException58 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray57);
        java.lang.String str59 = maxIterationsExceededException58.getPattern();
        java.lang.String str60 = maxIterationsExceededException58.toString();
        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException58);
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException58);
        org.apache.commons.math.exception.util.Localizable localizable63 = maxIterationsExceededException58.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable64 = null;
        org.apache.commons.math.exception.util.Localizable localizable65 = null;
        java.lang.Number number66 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException69 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable65, number66, (java.lang.Number) (-0.17738444574517354d), true);
        java.lang.Throwable[] throwableArray70 = numberIsTooSmallException69.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException(localizable64, (java.lang.Object[]) throwableArray70);
        java.lang.Object[] objArray72 = convergenceException71.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException73 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, localizable63, objArray72);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException77 = new org.apache.commons.math.exception.OutOfRangeException(localizable63, (java.lang.Number) 1.3203257660284435d, (java.lang.Number) (-0.6376630821062105d), (java.lang.Number) 2.31421686642742E-6d);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1.0d) + "'", number7.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "hi!" + "'", str48.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: hi!" + "'", str49.equals("org.apache.commons.math.MaxIterationsExceededException: hi!"));
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "hi!" + "'", str59.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: hi!" + "'", str60.equals("org.apache.commons.math.MaxIterationsExceededException: hi!"));
        org.junit.Assert.assertNotNull(localizable63);
        org.junit.Assert.assertNotNull(throwableArray70);
        org.junit.Assert.assertNotNull(objArray72);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable1, objArray8);
        java.lang.String str12 = maxIterationsExceededException11.toString();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException(localizable13, (java.lang.Number) (byte) 10, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) 0.0f);
        java.lang.Number number18 = outOfRangeException17.getHi();
        maxIterationsExceededException11.addSuppressed((java.lang.Throwable) outOfRangeException17);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: " + "'", str12.equals("org.apache.commons.math.MaxIterationsExceededException: "));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 0.0f + "'", number18.equals(0.0f));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 10, (float) 71);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 71.0f + "'", float2 == 71.0f);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(number2, (java.lang.Number) 100, false);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException5.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException(localizable9, objArray10);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than, or equal to, the maximum (10)", objArray10);
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException5, "org.apache.commons.math.MaxIterationsExceededException: hi!", objArray10);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException(97, "38eb270", objArray10);
        org.junit.Assert.assertNull(localizable6);
        org.junit.Assert.assertNotNull(objArray10);
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test168");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        int int12 = randomDataImpl1.nextZipf(100, 2.718281828459045d);
//        java.lang.String str14 = randomDataImpl1.nextHexString((int) (byte) 100);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-11.56695223901792d) + "'", double4 == (-11.56695223901792d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.31027683469303075d + "'", double6 == 0.31027683469303075d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "68cf15ab9c2e59b76868115480c3e8806cf37e0a6cdaa42e5826b5317f63f3416eb16c9747b22809352601a3ecf9352287b4" + "'", str14.equals("68cf15ab9c2e59b76868115480c3e8806cf37e0a6cdaa42e5826b5317f63f3416eb16c9747b22809352601a3ecf9352287b4"));
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.18013739181591165d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4244259556340913d + "'", double1 == 0.4244259556340913d);
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test170");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeed((long) (short) 0);
//        randomDataImpl1.reSeedSecure();
//        try {
//            int int19 = randomDataImpl1.nextHypergeometric(5, 85, 4);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 85 is larger than the maximum (5): number of successes (85) must be less than or equal to population size (5)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-12.15993233994926d) + "'", double4 == (-12.15993233994926d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.09235705857114232d + "'", double6 == 0.09235705857114232d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
//    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test171");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) (byte) 1);
//        double double5 = randomDataImpl1.nextT((double) 8);
//        randomDataImpl1.reSeed();
//        double double8 = randomDataImpl1.nextChiSquare((double) 100L);
//        randomDataImpl1.reSeed(3L);
//        double double13 = randomDataImpl1.nextF(0.2944340832285237d, 119.58145313387d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-2.806867247610574d) + "'", double3 == (-2.806867247610574d));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0979268641671116d + "'", double5 == 1.0979268641671116d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 82.97286528264134d + "'", double8 == 82.97286528264134d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.5490936845781292d + "'", double13 == 0.5490936845781292d);
//    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.04723013714999615d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.243213994359238E-4d + "'", double1 == 8.243213994359238E-4d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, (double) 19);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test174");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) (byte) 1);
//        randomDataImpl1.reSeed((long) (byte) -1);
//        java.lang.String str7 = randomDataImpl1.nextHexString(32);
//        java.lang.String str9 = randomDataImpl1.nextSecureHexString(71);
//        double double11 = randomDataImpl1.nextExponential(13.075922177263212d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-3.046118122371619d) + "'", double3 == (-3.046118122371619d));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "33ec59c443a207f097a0a4831e7fcb0c" + "'", str7.equals("33ec59c443a207f097a0a4831e7fcb0c"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "3908c5d9a6a73c0d66452fe4ba5b06e6599368128e0b75917d0d0747158d7bc850d7909" + "'", str9.equals("3908c5d9a6a73c0d66452fe4ba5b06e6599368128e0b75917d0d0747158d7bc850d7909"));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 6.662191767685537d + "'", double11 == 6.662191767685537d);
//    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test175");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT(4.599102285891914d);
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString((int) (byte) 100);
//        randomDataImpl1.reSeed((long) 6);
//        long long9 = randomDataImpl1.nextPoisson((double) 15);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl10 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double12 = normalDistributionImpl10.density(100.0d);
//        double double13 = normalDistributionImpl10.getStandardDeviation();
//        double double14 = normalDistributionImpl10.getStandardDeviation();
//        double double15 = normalDistributionImpl10.getStandardDeviation();
//        double double16 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl10);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.4749875482915458d) + "'", double3 == (-1.4749875482915458d));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "86d2fb1914373de83670f2972b67ab5c3ae152ddd15c36afe6672f1de548dd502f8c120a152b8b2b9e6e4c65d039eab97227" + "'", str5.equals("86d2fb1914373de83670f2972b67ab5c3ae152ddd15c36afe6672f1de548dd502f8c120a152b8b2b9e6e4c65d039eab97227"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 18L + "'", long9 == 18L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.008054107899125805d + "'", double16 == 0.008054107899125805d);
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.8266908339278949d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9385290234168583d + "'", double1 == 0.9385290234168583d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.2039833869074952d, 4.792786046229508d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.24611472921334446d + "'", double2 == 0.24611472921334446d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.24490950872371273d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3233699690266671d + "'", double1 == 1.3233699690266671d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 0.432811503818636d, (java.lang.Number) (-2.5496180456051607d));
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-2.5496180456051607d) + "'", number4.equals((-2.5496180456051607d)));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        int int2 = org.apache.commons.math.util.FastMath.max(5, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test181");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        randomDataImpl1.reSeed((-1L));
//        int int14 = randomDataImpl1.nextZipf(1, 0.9379198162596534d);
//        try {
//            double double16 = randomDataImpl1.nextChiSquare((-0.6442547081584085d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.322 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-49.979510199402945d) + "'", double4 == (-49.979510199402945d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.3787708965450232d + "'", double6 == 1.3787708965450232d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2L + "'", long9 == 2L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.9717386562014238E-5d), (java.lang.Number) 0.3981985353725279d, true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number5 = numberIsTooLargeException4.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray11);
        java.lang.Object[] objArray14 = new java.lang.Object[] { objArray11, "" };
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException4, localizable6, objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray11);
        java.lang.Object[] objArray22 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray22);
        java.lang.String str24 = maxIterationsExceededException23.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray35);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray35);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable28, objArray35);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException("", objArray35);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException23, localizable25, objArray35);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalArgumentException16, "org.apache.commons.math.MathException: ", objArray35);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1.0d) + "'", number5.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray35);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        double double1 = org.apache.commons.math.util.FastMath.signum((-0.409122520006212d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(1.7387963814485965d, (-3.046118122371619d), 0.5038520072893607d, 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getSpecificPattern();
        java.lang.String str3 = notStrictlyPositiveException1.toString();
        java.lang.Number number4 = notStrictlyPositiveException1.getMin();
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) (short) 100, (java.lang.Number) 0.8813735870195429d, (java.lang.Number) 100);
        java.lang.Number number11 = outOfRangeException10.getLo();
        org.apache.commons.math.exception.util.Localizable localizable12 = outOfRangeException10.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException19 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number20 = numberIsTooLargeException19.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        java.lang.Object[] objArray26 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray26);
        java.lang.Object[] objArray29 = new java.lang.Object[] { objArray26, "" };
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException19, localizable21, objArray26);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException("", objArray26);
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException("", objArray26);
        org.apache.commons.math.exception.util.Localizable localizable33 = mathException32.getGeneralPattern();
        java.lang.Number number34 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException37 = new org.apache.commons.math.exception.OutOfRangeException(localizable33, number34, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray42 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException43 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray42);
        java.lang.String str44 = maxIterationsExceededException43.getPattern();
        java.lang.Object[] objArray45 = maxIterationsExceededException43.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException46 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable33, objArray45);
        org.apache.commons.math.exception.util.Localizable localizable47 = maxIterationsExceededException46.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        java.lang.Object[] objArray49 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable48, objArray49);
        java.lang.Class<?> wildcardClass51 = mathIllegalArgumentException50.getClass();
        java.lang.Object[] objArray52 = mathIllegalArgumentException50.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException53 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable47, objArray52);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException54 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray52);
        org.junit.Assert.assertNull(localizable2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: -1 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: -1 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0.8813735870195429d + "'", number11.equals(0.8813735870195429d));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + (-1.0d) + "'", number20.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(localizable33);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "hi!" + "'", str44.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(localizable47);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNotNull(objArray52);
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test187");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        double double14 = randomDataImpl1.nextT(0.7627350637656639d);
//        double double17 = randomDataImpl1.nextGaussian((double) (byte) 1, 0.29495535414077817d);
//        randomDataImpl1.reSeedSecure((long) 100);
//        int int22 = randomDataImpl1.nextSecureInt((int) (byte) 10, (int) (byte) 100);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl23 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double24 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl23);
//        try {
//            long long26 = randomDataImpl1.nextPoisson((-4.613095607795176d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -4.613 is smaller than, or equal to, the minimum (0): mean (-4.613)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-378.5169911870321d) + "'", double4 == (-378.5169911870321d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.1841494911142698d + "'", double6 == 1.1841494911142698d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-2.069356096039724d) + "'", double14 == (-2.069356096039724d));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.6489143374877449d + "'", double17 == 0.6489143374877449d);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 45 + "'", int22 == 45);
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.3968816580727014d + "'", double24 == 0.3968816580727014d);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, (double) 7.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.0d + "'", double2 == 7.0d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(1.5655479364661526d, 2.7209854707924777d, (-0.4705444516411526d), 51);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: Continued fraction convergents failed to converge (in less than 2.721 iterations) for value {1}");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.4690996480235547E-11d, (java.lang.Number) 3.0d, (java.lang.Number) 32.0f);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.density(100.0d);
        double double3 = normalDistributionImpl0.getStandardDeviation();
        double double4 = normalDistributionImpl0.getStandardDeviation();
        double double5 = normalDistributionImpl0.getStandardDeviation();
        try {
            double double7 = normalDistributionImpl0.inverseCumulativeProbability(2.2516096916609687d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 2.252 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.7627350637656639d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1441325473714743d + "'", double1 == 2.1441325473714743d);
    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test193");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        double double14 = randomDataImpl1.nextExponential(0.9379198162596534d);
//        double double17 = randomDataImpl1.nextBeta(4.672738657069999d, 0.4015920856975591d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 915.9052031155087d + "'", double4 == 915.9052031155087d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.00679472516480409d + "'", double6 == 0.00679472516480409d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.1089804656168281d + "'", double14 == 0.1089804656168281d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.9986573984803258d + "'", double17 == 0.9986573984803258d);
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.020409332481171463d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1693686138503894d + "'", double1 == 1.1693686138503894d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(2147483647);
    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test197");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) 'a');
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeed();
//        double double15 = randomDataImpl1.nextExponential((double) (short) 100);
//        try {
//            double double18 = randomDataImpl1.nextWeibull(0.0d, 0.7837218672022305d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): shape (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-110.92828822601211d) + "'", double4 == (-110.92828822601211d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.11049113937113127d + "'", double6 == 0.11049113937113127d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 5 + "'", int9 == 5);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 437.0790422959926d + "'", double15 == 437.0790422959926d);
//    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable1, objArray8);
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException11);
        org.apache.commons.math.exception.util.Localizable localizable13 = mathException12.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test199");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) 'a');
//        randomDataImpl1.reSeedSecure();
//        double double15 = randomDataImpl1.nextWeibull(240.7369240718433d, 0.6619704527324951d);
//        randomDataImpl1.reSeedSecure();
//        double double19 = randomDataImpl1.nextBeta((double) 52.0f, 520.0226107645648d);
//        try {
//            double double22 = randomDataImpl1.nextBeta((-0.409122520006212d), 0.6199701620746297d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.954");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-154.62812535927034d) + "'", double4 == (-154.62812535927034d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.07212648600703668d + "'", double6 == 0.07212648600703668d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.6622530959027774d + "'", double15 == 0.6622530959027774d);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.08495671564619901d + "'", double19 == 0.08495671564619901d);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number7 = numberIsTooLargeException6.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray13);
        java.lang.Object[] objArray16 = new java.lang.Object[] { objArray13, "" };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException6, localizable8, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("", objArray13);
        org.apache.commons.math.exception.util.Localizable localizable20 = mathException19.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray29);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray29);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable22, objArray29);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable20, objArray29);
        java.lang.Number number34 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException35 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable20, number34);
        java.lang.String str36 = notStrictlyPositiveException35.toString();
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1.0d) + "'", number7.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0): " + "'", str36.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0): "));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        double double1 = org.apache.commons.math.util.FastMath.ulp(3.9969672135048326d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        java.lang.String str5 = numberIsTooLargeException3.toString();
        java.lang.Number number6 = numberIsTooLargeException3.getArgument();
        boolean boolean7 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.String str8 = numberIsTooLargeException3.toString();
        java.lang.Number number9 = numberIsTooLargeException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0d) + "'", number4.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than, or equal to, the maximum (10)" + "'", str5.equals("org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than, or equal to, the maximum (10)"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1.0d) + "'", number6.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than, or equal to, the maximum (10)" + "'", str8.equals("org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than, or equal to, the maximum (10)"));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0d) + "'", number9.equals((-1.0d)));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        boolean boolean3 = notStrictlyPositiveException1.getBoundIsAllowed();
        boolean boolean4 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        double double1 = org.apache.commons.math.util.FastMath.log(0.38907396424594154d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9439858139881837d) + "'", double1 == (-0.9439858139881837d));
    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test205");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        double double14 = randomDataImpl1.nextWeibull((double) 52, 0.9340908354459301d);
//        randomDataImpl1.reSeed(0L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 28.43758254951034d + "'", double4 == 28.43758254951034d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.07416551798804488d + "'", double6 == 0.07416551798804488d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 8 + "'", int9 == 8);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.9002846518758353d + "'", double14 == 0.9002846518758353d);
//    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (short) 100, (java.lang.Number) 0.8813735870195429d, (java.lang.Number) 100);
        java.lang.Number number5 = outOfRangeException4.getLo();
        java.lang.Throwable[] throwableArray6 = outOfRangeException4.getSuppressed();
        java.lang.Number number7 = outOfRangeException4.getHi();
        org.apache.commons.math.exception.util.Localizable localizable8 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = outOfRangeException4.getGeneralPattern();
        java.lang.Number number10 = outOfRangeException4.getLo();
        org.apache.commons.math.exception.util.Localizable localizable11 = outOfRangeException4.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.8813735870195429d + "'", number5.equals(0.8813735870195429d));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 100 + "'", number7.equals(100));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0.8813735870195429d + "'", number10.equals(0.8813735870195429d));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test207");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT(4.599102285891914d);
//        double double6 = randomDataImpl1.nextGaussian(1.1142547833872074E-7d, 0.02398007912785791d);
//        double double8 = randomDataImpl1.nextT(2.7973807818415874d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double11 = normalDistributionImpl9.density(100.0d);
//        double double13 = normalDistributionImpl9.inverseCumulativeProbability((double) 1);
//        double double14 = normalDistributionImpl9.getStandardDeviation();
//        double double15 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.9584690456065783d + "'", double3 == 1.9584690456065783d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-6.569244977614733E-4d) + "'", double6 == (-6.569244977614733E-4d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.8869274943443326d) + "'", double8 == (-1.8869274943443326d));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.4827865166646436d + "'", double15 == 0.4827865166646436d);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(7);
        org.apache.commons.math.exception.util.Localizable localizable2 = maxIterationsExceededException1.getGeneralPattern();
        java.lang.String str3 = maxIterationsExceededException1.getPattern();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "maximal number of iterations ({0}) exceeded" + "'", str3.equals("maximal number of iterations ({0}) exceeded"));
    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test209");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) (byte) 1);
//        double double5 = randomDataImpl1.nextT((double) 8);
//        try {
//            int int8 = randomDataImpl1.nextInt(5, 4);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 5 is larger than, or equal to, the maximum (4): lower bound (5) must be strictly less than upper bound (4)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.692672383579338d + "'", double3 == 5.692672383579338d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.8590043829738898d + "'", double5 == 0.8590043829738898d);
//    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.2857504987187536d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2513425935544027d + "'", double1 == 0.2513425935544027d);
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test211");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        double double14 = randomDataImpl1.nextT(0.7627350637656639d);
//        double double17 = randomDataImpl1.nextCauchy(0.5061169493981285d, 5.853949697499888d);
//        randomDataImpl1.reSeed(5L);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeed();
//        randomDataImpl1.reSeed();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 26.41740367606943d + "'", double4 == 26.41740367606943d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.9384647922075884E-4d + "'", double6 == 2.9384647922075884E-4d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-3.344078043537757d) + "'", double14 == (-3.344078043537757d));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-107.27217140402153d) + "'", double17 == (-107.27217140402153d));
//    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.352958469094319d, 0.040706524570184074d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3529584690943188d + "'", double2 == 1.3529584690943188d);
    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test213");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT(4.599102285891914d);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeed(0L);
//        try {
//            double double10 = randomDataImpl1.nextUniform(18.656699191319486d, 0.4100451773653382d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 18.657 is larger than, or equal to, the maximum (0.41): lower bound (18.657) must be strictly less than upper bound (0.41)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.2052322709235375d + "'", double3 == 2.2052322709235375d);
//    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.4711276743037347d, (double) 1L);
        double double3 = normalDistributionImpl2.getStandardDeviation();
        double double5 = normalDistributionImpl2.density(2.220446049250313E-16d);
        double double7 = normalDistributionImpl2.density(0.0d);
        java.lang.Class<?> wildcardClass8 = normalDistributionImpl2.getClass();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.13519368159152453d + "'", double5 == 0.13519368159152453d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.13519368159152448d + "'", double7 == 0.13519368159152448d);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        double double1 = org.apache.commons.math.util.FastMath.abs((-6.82095517597379E10d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.82095517597379E10d + "'", double1 == 6.82095517597379E10d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number7 = numberIsTooLargeException6.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray13);
        java.lang.Object[] objArray16 = new java.lang.Object[] { objArray13, "" };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException6, localizable8, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("", objArray13);
        org.apache.commons.math.exception.util.Localizable localizable20 = mathException19.getGeneralPattern();
        java.lang.Number number21 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException(localizable20, number21, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray29 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray29);
        java.lang.String str31 = maxIterationsExceededException30.getPattern();
        java.lang.Object[] objArray32 = maxIterationsExceededException30.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable20, objArray32);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        java.lang.Object[] objArray41 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException42 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray41);
        java.lang.String str43 = maxIterationsExceededException42.getPattern();
        java.lang.String str44 = maxIterationsExceededException42.toString();
        java.lang.Object[] objArray45 = maxIterationsExceededException42.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException46 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, localizable36, objArray45);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable34, objArray45);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, objArray45);
        java.lang.Object[] objArray54 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException55 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray54);
        java.lang.String str56 = maxIterationsExceededException55.getPattern();
        java.lang.String str57 = maxIterationsExceededException55.toString();
        int int58 = maxIterationsExceededException55.getMaxIterations();
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        org.apache.commons.math.exception.util.Localizable localizable63 = null;
        java.lang.Object[] objArray70 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException71 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray70);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException72 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray70);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException73 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable63, objArray70);
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException("", objArray70);
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.MaxIterationsExceededException: ", objArray70);
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException55, localizable59, objArray70);
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.MaxIterationsExceededException: ", objArray70);
        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException(localizable20, objArray70);
        java.lang.Object[] objArray79 = null;
        org.apache.commons.math.MathException mathException80 = new org.apache.commons.math.MathException(localizable20, objArray79);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1.0d) + "'", number7.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "hi!" + "'", str43.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: hi!" + "'", str44.equals("org.apache.commons.math.MaxIterationsExceededException: hi!"));
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "hi!" + "'", str56.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: hi!" + "'", str57.equals("org.apache.commons.math.MaxIterationsExceededException: hi!"));
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertNotNull(objArray70);
    }
}

