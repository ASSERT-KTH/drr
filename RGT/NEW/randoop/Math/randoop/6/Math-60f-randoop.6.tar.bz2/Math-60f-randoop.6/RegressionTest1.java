import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 6.0d, (java.lang.Number) 8.054359047689252E13d, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number13 = numberIsTooLargeException12.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray19);
        java.lang.Object[] objArray22 = new java.lang.Object[] { objArray19, "" };
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException12, localizable14, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("", objArray19);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException("", objArray19);
        org.apache.commons.math.exception.util.Localizable localizable26 = mathException25.getGeneralPattern();
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException30 = new org.apache.commons.math.exception.OutOfRangeException(localizable26, number27, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray35 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray35);
        java.lang.String str37 = maxIterationsExceededException36.getPattern();
        java.lang.Object[] objArray38 = maxIterationsExceededException36.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException39 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable26, objArray38);
        org.apache.commons.math.exception.util.Localizable localizable40 = maxIterationsExceededException39.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException42 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.util.Localizable localizable43 = notStrictlyPositiveException42.getSpecificPattern();
        java.lang.Throwable[] throwableArray44 = notStrictlyPositiveException42.getSuppressed();
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException(localizable40, (java.lang.Object[]) throwableArray44);
        org.apache.commons.math.exception.util.Localizable localizable47 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException52 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number53 = numberIsTooLargeException52.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        java.lang.Object[] objArray59 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException60 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray59);
        java.lang.Object[] objArray62 = new java.lang.Object[] { objArray59, "" };
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException52, localizable54, objArray59);
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException("", objArray59);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException65 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable47, objArray59);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException66 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable40, objArray59);
        java.lang.Number number67 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException70 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, number67, (java.lang.Number) 12.801827480081469d, false);
        java.lang.Object[] objArray75 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException76 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray75);
        java.lang.String str77 = maxIterationsExceededException76.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable78 = null;
        org.apache.commons.math.exception.util.Localizable localizable81 = null;
        java.lang.Object[] objArray88 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException89 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray88);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException90 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray88);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException91 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable81, objArray88);
        org.apache.commons.math.ConvergenceException convergenceException92 = new org.apache.commons.math.ConvergenceException("", objArray88);
        org.apache.commons.math.ConvergenceException convergenceException93 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException76, localizable78, objArray88);
        java.lang.Throwable[] throwableArray94 = maxIterationsExceededException76.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException95 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable5, (java.lang.Object[]) throwableArray94);
        int int96 = maxIterationsExceededException95.getMaxIterations();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-1.0d) + "'", number13.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(localizable26);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(localizable40);
        org.junit.Assert.assertNull(localizable43);
        org.junit.Assert.assertNotNull(throwableArray44);
        org.junit.Assert.assertTrue("'" + number53 + "' != '" + (-1.0d) + "'", number53.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertNotNull(objArray75);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "hi!" + "'", str77.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray88);
        org.junit.Assert.assertNotNull(throwableArray94);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 97 + "'", int96 == 97);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        double double1 = org.apache.commons.math.util.FastMath.cos(2.8366339028103726d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9538593386156619d) + "'", double1 == (-0.9538593386156619d));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        double double1 = org.apache.commons.math.util.FastMath.asin(11.471265370754681d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(5729.5779513082325d, 4.605170185988092d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8179617754648578d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        float float2 = org.apache.commons.math.util.FastMath.min(3.0f, (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.0f + "'", float2 == 3.0f);
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT(4.599102285891914d);
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString((int) (byte) 100);
//        try {
//            double double8 = randomDataImpl1.nextF(0.0d, 0.9999546000702375d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.4412887216555523d + "'", double3 == 0.4412887216555523d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "c5633ea5ad36b3cf066f1e52cf1ecdd12d9c1ae0259439ed10850bdbd5aeb29ad107505efe85092d4ecf3a2b4df604ab9af1" + "'", str5.equals("c5633ea5ad36b3cf066f1e52cf1ecdd12d9c1ae0259439ed10850bdbd5aeb29ad107505efe85092d4ecf3a2b4df604ab9af1"));
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        long long1 = org.apache.commons.math.util.FastMath.abs(48L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 48L + "'", long1 == 48L);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-28.36466158317452d), (java.lang.Number) 2.2645326428298556d, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 2.2645326428298556d + "'", number4.equals(2.2645326428298556d));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number6 = numberIsTooLargeException5.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray12);
        java.lang.Object[] objArray15 = new java.lang.Object[] { objArray12, "" };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException5, localizable7, objArray12);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("", objArray12);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("", objArray12);
        org.apache.commons.math.exception.util.Localizable localizable19 = mathException18.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException(localizable19, (java.lang.Number) 0.36496488262332794d, (java.lang.Number) 0.6439528600818949d, (java.lang.Number) 1.3052608122477107d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException27 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable19, (java.lang.Number) 1, (java.lang.Number) (byte) 10, true);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException31 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable19, (java.lang.Number) 7.291140084956589d, (java.lang.Number) 10.0d, false);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1.0d) + "'", number6.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(localizable19);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        double double1 = org.apache.commons.math.util.FastMath.atanh(7.1080791808757295d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.006937366662896952d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 100, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test014");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) 'a');
//        randomDataImpl1.reSeedSecure();
//        try {
//            double double15 = randomDataImpl1.nextBeta((double) 4L, (-0.12138524385555713d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.505");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.6662787724274795d + "'", double4 == 3.6662787724274795d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.18265125050618497d + "'", double6 == 0.18265125050618497d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
//    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.8179617754648578d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test016");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        randomDataImpl1.reSeed((-1L));
//        int int14 = randomDataImpl1.nextZipf(1, 0.9379198162596534d);
//        try {
//            double double17 = randomDataImpl1.nextGamma((-28.36466158317452d), 0.15385541444224388d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -28.365 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.983776082125817d + "'", double4 == 3.983776082125817d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.03673423121199407d + "'", double6 == 0.03673423121199407d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 9);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.080083823051904d + "'", double1 == 2.080083823051904d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number6 = numberIsTooLargeException5.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray12);
        java.lang.Object[] objArray15 = new java.lang.Object[] { objArray12, "" };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException5, localizable7, objArray12);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("", objArray12);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("", objArray12);
        org.apache.commons.math.exception.util.Localizable localizable19 = mathException18.getGeneralPattern();
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException(localizable19, number20, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Number number24 = outOfRangeException23.getLo();
        java.lang.Number number25 = outOfRangeException23.getArgument();
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException23);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1.0d) + "'", number6.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (byte) 0 + "'", number24.equals((byte) 0));
        org.junit.Assert.assertNull(number25);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(3.241723184387021d, (double) 0L, 0.9788629796100344d, (int) '4');
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-0.9538593386156619d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("c3f9f7fd6da28e1c8ac7e2aef31f6fc893dc30139b98d72dae053c81cd2661249c3b16f9e11c23cb17e401a5cfda2bfe46f1", objArray1);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 0, 1.6910147193352092d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        double double1 = org.apache.commons.math.util.FastMath.cos(8.739797322809835d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7744312967872216d) + "'", double1 == (-0.7744312967872216d));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.6243640113549542d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0662357463415135d + "'", double1 == 1.0662357463415135d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.6243640113549542d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test026");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        double double14 = randomDataImpl1.nextT(0.7627350637656639d);
//        double double17 = randomDataImpl1.nextGaussian((double) (byte) 1, 0.29495535414077817d);
//        try {
//            java.lang.String str19 = randomDataImpl1.nextSecureHexString((int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): length (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.377889313877546d + "'", double4 == 0.377889313877546d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0012291153038600814d + "'", double6 == 0.0012291153038600814d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.6869959671728825d) + "'", double14 == (-1.6869959671728825d));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.8992097749923736d + "'", double17 == 0.8992097749923736d);
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.471127674303735d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number7 = numberIsTooLargeException6.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray13);
        java.lang.Object[] objArray16 = new java.lang.Object[] { objArray13, "" };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException6, localizable8, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("", objArray13);
        org.apache.commons.math.exception.util.Localizable localizable20 = mathException19.getGeneralPattern();
        java.lang.Number number21 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException(localizable20, number21, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray29 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray29);
        java.lang.String str31 = maxIterationsExceededException30.getPattern();
        java.lang.Object[] objArray32 = maxIterationsExceededException30.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable20, objArray32);
        org.apache.commons.math.exception.util.Localizable localizable34 = maxIterationsExceededException33.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException36 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.util.Localizable localizable37 = notStrictlyPositiveException36.getSpecificPattern();
        java.lang.Throwable[] throwableArray38 = notStrictlyPositiveException36.getSuppressed();
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException(localizable34, (java.lang.Object[]) throwableArray38);
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        java.lang.Number number41 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException44 = new org.apache.commons.math.exception.NumberIsTooSmallException(number41, (java.lang.Number) 100, false);
        org.apache.commons.math.exception.util.Localizable localizable45 = numberIsTooSmallException44.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException(localizable48, objArray49);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than, or equal to, the maximum (10)", objArray49);
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException44, "org.apache.commons.math.MaxIterationsExceededException: hi!", objArray49);
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException(localizable40, objArray49);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException(localizable34, objArray49);
        java.lang.Number number55 = null;
        java.lang.Number number56 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException58 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable34, number55, number56, true);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException62 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable34, (java.lang.Number) (-0.35143403324086336d), (java.lang.Number) 0.13519368159152448d, true);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1.0d) + "'", number7.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(localizable34);
        org.junit.Assert.assertNull(localizable37);
        org.junit.Assert.assertNotNull(throwableArray38);
        org.junit.Assert.assertNull(localizable45);
        org.junit.Assert.assertNotNull(objArray49);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        double double1 = org.apache.commons.math.util.FastMath.exp(2.4382907908532676d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.453447665719617d + "'", double1 == 11.453447665719617d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 47, (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 6.0d, (java.lang.Number) 8.054359047689252E13d, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number13 = numberIsTooLargeException12.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray19);
        java.lang.Object[] objArray22 = new java.lang.Object[] { objArray19, "" };
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException12, localizable14, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("", objArray19);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException("", objArray19);
        org.apache.commons.math.exception.util.Localizable localizable26 = mathException25.getGeneralPattern();
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException30 = new org.apache.commons.math.exception.OutOfRangeException(localizable26, number27, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray35 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray35);
        java.lang.String str37 = maxIterationsExceededException36.getPattern();
        java.lang.Object[] objArray38 = maxIterationsExceededException36.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException39 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable26, objArray38);
        org.apache.commons.math.exception.util.Localizable localizable40 = maxIterationsExceededException39.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException42 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.util.Localizable localizable43 = notStrictlyPositiveException42.getSpecificPattern();
        java.lang.Throwable[] throwableArray44 = notStrictlyPositiveException42.getSuppressed();
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException(localizable40, (java.lang.Object[]) throwableArray44);
        org.apache.commons.math.exception.util.Localizable localizable47 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException52 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number53 = numberIsTooLargeException52.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        java.lang.Object[] objArray59 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException60 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray59);
        java.lang.Object[] objArray62 = new java.lang.Object[] { objArray59, "" };
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException52, localizable54, objArray59);
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException("", objArray59);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException65 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable47, objArray59);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException66 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable40, objArray59);
        org.apache.commons.math.exception.util.Localizable localizable67 = null;
        java.lang.Object[] objArray72 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException73 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray72);
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException(localizable67, objArray72);
        org.apache.commons.math.MathException mathException75 = new org.apache.commons.math.MathException(throwable0, localizable5, objArray72);
        java.lang.Number number76 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException77 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, number76);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException81 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) (-1.8384102186399753d), (java.lang.Number) 0.01125018911575255d, true);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-1.0d) + "'", number13.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(localizable26);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(localizable40);
        org.junit.Assert.assertNull(localizable43);
        org.junit.Assert.assertNotNull(throwableArray44);
        org.junit.Assert.assertTrue("'" + number53 + "' != '" + (-1.0d) + "'", number53.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertNotNull(objArray72);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((-0.547786400940282d), (-0.577290349936525d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) 100, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException(localizable7, objArray8);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than, or equal to, the maximum (10)", objArray8);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException3, "org.apache.commons.math.MaxIterationsExceededException: hi!", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable12 = convergenceException11.getSpecificPattern();
        java.lang.Throwable[] throwableArray13 = convergenceException11.getSuppressed();
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNull(localizable12);
        org.junit.Assert.assertNotNull(throwableArray13);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 47);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        java.lang.Object[] objArray6 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray6);
        java.lang.String str8 = maxIterationsExceededException7.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray19);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException21 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray19);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException22 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable12, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("", objArray19);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException7, localizable9, objArray19);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException(7, "ebc5324e7636de08bc97416c7d4d1e15b12", objArray19);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray19);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 155.74607629780772d, (java.lang.Number) 1.333707301036022d);
        java.lang.Number number4 = outOfRangeException3.getLo();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 6.0d, (java.lang.Number) 8.054359047689252E13d, true);
        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooLargeException8.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException16 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number17 = numberIsTooLargeException16.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Object[] objArray23 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException24 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray23);
        java.lang.Object[] objArray26 = new java.lang.Object[] { objArray23, "" };
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException16, localizable18, objArray23);
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException("", objArray23);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException("", objArray23);
        org.apache.commons.math.exception.util.Localizable localizable30 = mathException29.getGeneralPattern();
        java.lang.Number number31 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException34 = new org.apache.commons.math.exception.OutOfRangeException(localizable30, number31, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray39 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException40 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray39);
        java.lang.String str41 = maxIterationsExceededException40.getPattern();
        java.lang.Object[] objArray42 = maxIterationsExceededException40.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException43 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable30, objArray42);
        org.apache.commons.math.exception.util.Localizable localizable44 = maxIterationsExceededException43.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException46 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.util.Localizable localizable47 = notStrictlyPositiveException46.getSpecificPattern();
        java.lang.Throwable[] throwableArray48 = notStrictlyPositiveException46.getSuppressed();
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException(localizable44, (java.lang.Object[]) throwableArray48);
        org.apache.commons.math.exception.util.Localizable localizable51 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException56 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number57 = numberIsTooLargeException56.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        java.lang.Object[] objArray63 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException64 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray63);
        java.lang.Object[] objArray66 = new java.lang.Object[] { objArray63, "" };
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException56, localizable58, objArray63);
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException("", objArray63);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException69 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable51, objArray63);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException70 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable44, objArray63);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException74 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable44, (java.lang.Number) 11.144178405319577d, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException78 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable44, (java.lang.Number) 26.983826832980125d, (java.lang.Number) 0.7718551054848756d, false);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException82 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number83 = numberIsTooLargeException82.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable84 = null;
        java.lang.Object[] objArray89 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException90 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray89);
        org.apache.commons.math.MathException mathException91 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException82, localizable84, objArray89);
        org.apache.commons.math.ConvergenceException convergenceException92 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable44, objArray89);
        java.lang.Number number93 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 155.74607629780772d + "'", number4.equals(155.74607629780772d));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + (-1.0d) + "'", number17.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(localizable30);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "hi!" + "'", str41.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(localizable44);
        org.junit.Assert.assertNull(localizable47);
        org.junit.Assert.assertNotNull(throwableArray48);
        org.junit.Assert.assertTrue("'" + number57 + "' != '" + (-1.0d) + "'", number57.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertTrue("'" + number83 + "' != '" + (-1.0d) + "'", number83.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray89);
        org.junit.Assert.assertTrue("'" + number93 + "' != '" + 1.333707301036022d + "'", number93.equals(1.333707301036022d));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        double double1 = org.apache.commons.math.util.FastMath.rint((-0.04527605728197682d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        int int12 = randomDataImpl1.nextZipf(100, 2.718281828459045d);
//        double double15 = randomDataImpl1.nextCauchy(2.092790987315211d, 0.8813735870195429d);
//        int int19 = randomDataImpl1.nextHypergeometric(71, 47, 20);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.612228815478475d + "'", double4 == 7.612228815478475d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.1628509257251668d + "'", double6 == 0.1628509257251668d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.2483225160550546d + "'", double15 == 2.2483225160550546d);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 15 + "'", int19 == 15);
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.5264888286059799d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5220349218107092d + "'", double1 == 0.5220349218107092d);
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test041");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        long long11 = randomDataImpl1.nextPoisson(3.608826080138695d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.672110364971767d + "'", double4 == 7.672110364971767d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.442649094209893d + "'", double6 == 1.442649094209893d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 5L + "'", long9 == 5L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.03760197886023983d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray11);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray11);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable4, objArray11);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("", objArray11);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException16 = new org.apache.commons.math.MaxIterationsExceededException(8, "org.apache.commons.math.MathException: ", objArray11);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException16);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 6.0d, (java.lang.Number) 8.054359047689252E13d, true);
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooLargeException21.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException29 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number30 = numberIsTooLargeException29.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        java.lang.Object[] objArray36 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray36);
        java.lang.Object[] objArray39 = new java.lang.Object[] { objArray36, "" };
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException29, localizable31, objArray36);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException("", objArray36);
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException("", objArray36);
        org.apache.commons.math.exception.util.Localizable localizable43 = mathException42.getGeneralPattern();
        java.lang.Number number44 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException47 = new org.apache.commons.math.exception.OutOfRangeException(localizable43, number44, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray52 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException53 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray52);
        java.lang.String str54 = maxIterationsExceededException53.getPattern();
        java.lang.Object[] objArray55 = maxIterationsExceededException53.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException56 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable43, objArray55);
        org.apache.commons.math.exception.util.Localizable localizable57 = maxIterationsExceededException56.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException59 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.util.Localizable localizable60 = notStrictlyPositiveException59.getSpecificPattern();
        java.lang.Throwable[] throwableArray61 = notStrictlyPositiveException59.getSuppressed();
        org.apache.commons.math.MathException mathException62 = new org.apache.commons.math.MathException(localizable57, (java.lang.Object[]) throwableArray61);
        org.apache.commons.math.exception.util.Localizable localizable64 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException69 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number70 = numberIsTooLargeException69.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable71 = null;
        java.lang.Object[] objArray76 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException77 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray76);
        java.lang.Object[] objArray79 = new java.lang.Object[] { objArray76, "" };
        org.apache.commons.math.ConvergenceException convergenceException80 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException69, localizable71, objArray76);
        org.apache.commons.math.ConvergenceException convergenceException81 = new org.apache.commons.math.ConvergenceException("", objArray76);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException82 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable64, objArray76);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException83 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, localizable57, objArray76);
        java.lang.Object[] objArray84 = null;
        org.apache.commons.math.MathException mathException85 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException17, localizable57, objArray84);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + (-1.0d) + "'", number30.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(localizable43);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "hi!" + "'", str54.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(localizable57);
        org.junit.Assert.assertNull(localizable60);
        org.junit.Assert.assertNotNull(throwableArray61);
        org.junit.Assert.assertTrue("'" + number70 + "' != '" + (-1.0d) + "'", number70.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray76);
        org.junit.Assert.assertNotNull(objArray79);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        java.lang.String str5 = numberIsTooLargeException3.toString();
        java.lang.Number number6 = numberIsTooLargeException3.getArgument();
        java.lang.Number number7 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0d) + "'", number4.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than, or equal to, the maximum (10)" + "'", str5.equals("org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than, or equal to, the maximum (10)"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1.0d) + "'", number6.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 10.0f + "'", number7.equals(10.0f));
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test045");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        java.lang.String str11 = randomDataImpl1.nextHexString((int) '#');
//        int int14 = randomDataImpl1.nextZipf(20, 0.5772156649015329d);
//        double double17 = randomDataImpl1.nextUniform(0.0d, 1.5891306489769716d);
//        double double19 = randomDataImpl1.nextT(0.9999584626848042d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-71.51554023463386d) + "'", double4 == (-71.51554023463386d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.7420057716064438d + "'", double6 == 0.7420057716064438d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 8L + "'", long9 == 8L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0d2ac2d91eeb5f37139b635c926bd996e56" + "'", str11.equals("0d2ac2d91eeb5f37139b635c926bd996e56"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.1637803215194881d + "'", double17 == 0.1637803215194881d);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05360403603598485d + "'", double19 == 0.05360403603598485d);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(1.1750995950119212d, 162.5271506547573d, (-0.6442547081584085d), (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: Continued fraction convergents failed to converge (in less than 162.527 iterations) for value {1}");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 32L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        double double14 = randomDataImpl1.nextT(0.7627350637656639d);
//        double double17 = randomDataImpl1.nextCauchy(0.5061169493981285d, 5.853949697499888d);
//        randomDataImpl1.reSeed(5L);
//        randomDataImpl1.reSeedSecure();
//        try {
//            double double23 = randomDataImpl1.nextF(0.0d, 23.999999999999996d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-101.61829804254914d) + "'", double4 == (-101.61829804254914d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.6490450068233506d + "'", double6 == 1.6490450068233506d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 5 + "'", int9 == 5);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 34.49943870455971d + "'", double14 == 34.49943870455971d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-3.839274223024674d) + "'", double17 == (-3.839274223024674d));
//    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test049");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        long long7 = randomDataImpl1.nextLong((long) (byte) 10, (long) '4');
//        double double10 = randomDataImpl1.nextF(0.7400576788232446d, 0.8018974326990581d);
//        double double13 = randomDataImpl1.nextGamma(0.8426819462428745d, 0.661899304433709d);
//        try {
//            int int17 = randomDataImpl1.nextHypergeometric(9, (int) (short) 0, (int) ' ');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 32 is larger than the maximum (9): sample size (32) must be less than or equal to population size (9)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-43.023553312301146d) + "'", double4 == (-43.023553312301146d));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 11L + "'", long7 == 11L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.01683883207488639d + "'", double10 == 0.01683883207488639d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.4643351649672576d + "'", double13 == 1.4643351649672576d);
//    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test050");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl0.density(100.0d);
//        double double3 = normalDistributionImpl0.sample();
//        double[] doubleArray5 = normalDistributionImpl0.sample(5);
//        double double6 = normalDistributionImpl0.sample();
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.636567541417731d + "'", double3 == 1.636567541417731d);
//        org.junit.Assert.assertNotNull(doubleArray5);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-0.5265471056297653d) + "'", double6 == (-0.5265471056297653d));
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray4);
        java.lang.String str6 = maxIterationsExceededException5.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray17);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray17);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable10, objArray17);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException("", objArray17);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException5, localizable7, objArray17);
        java.lang.Throwable[] throwableArray23 = maxIterationsExceededException5.getSuppressed();
        java.lang.String str24 = maxIterationsExceededException5.toString();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: hi!" + "'", str24.equals("org.apache.commons.math.MaxIterationsExceededException: hi!"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 100, (-0.4705444516411526d), 0.0d, 5);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        double double1 = org.apache.commons.math.util.FastMath.atanh(52.11866024219715d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number7 = numberIsTooLargeException6.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray13);
        java.lang.Object[] objArray16 = new java.lang.Object[] { objArray13, "" };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException6, localizable8, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("", objArray13);
        org.apache.commons.math.exception.util.Localizable localizable20 = mathException19.getGeneralPattern();
        java.lang.Number number21 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException(localizable20, number21, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray29 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray29);
        java.lang.String str31 = maxIterationsExceededException30.getPattern();
        java.lang.Object[] objArray32 = maxIterationsExceededException30.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable20, objArray32);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        java.lang.Object[] objArray41 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException42 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray41);
        java.lang.String str43 = maxIterationsExceededException42.getPattern();
        java.lang.String str44 = maxIterationsExceededException42.toString();
        java.lang.Object[] objArray45 = maxIterationsExceededException42.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException46 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, localizable36, objArray45);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable34, objArray45);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, objArray45);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException53 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number54 = numberIsTooLargeException53.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException61 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray60);
        java.lang.Object[] objArray63 = new java.lang.Object[] { objArray60, "" };
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException53, localizable55, objArray60);
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException("", objArray60);
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException(localizable20, objArray60);
        java.lang.Throwable[] throwableArray67 = mathException66.getSuppressed();
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1.0d) + "'", number7.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "hi!" + "'", str43.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: hi!" + "'", str44.equals("org.apache.commons.math.MaxIterationsExceededException: hi!"));
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertTrue("'" + number54 + "' != '" + (-1.0d) + "'", number54.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertNotNull(throwableArray67);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.5061169493981285d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6588373234332228d + "'", double1 == 1.6588373234332228d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        long long2 = org.apache.commons.math.util.FastMath.max(47L, (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 47L + "'", long2 == 47L);
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test057");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        long long7 = randomDataImpl1.nextLong((long) (byte) 10, (long) '4');
//        double double10 = randomDataImpl1.nextBeta(1.471127674303735d, 1.1185087377885383d);
//        randomDataImpl1.reSeed((long) '4');
//        long long14 = randomDataImpl1.nextPoisson(1.2598590199387094d);
//        try {
//            int[] intArray17 = randomDataImpl1.nextPermutation(10, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): permutation size (0");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 337.3576310202944d + "'", double4 == 337.3576310202944d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 12L + "'", long7 == 12L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.1709031938762011d + "'", double10 == 0.1709031938762011d);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2L + "'", long14 == 2L);
//    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT(4.599102285891914d);
//        try {
//            double double6 = randomDataImpl1.nextWeibull(359.1342053695754d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): scale (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.098796200412045d + "'", double3 == 5.098796200412045d);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.9829334991014375d, (-3.5652717091549992d), (-19.308419168267168d), 7);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test060");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        randomDataImpl1.reSeed((-1L));
//        double double13 = randomDataImpl1.nextT(0.2857504987187536d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution14 = null;
//        try {
//            int int15 = randomDataImpl1.nextInversionDeviate(integerDistribution14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 201.38505660820823d + "'", double4 == 201.38505660820823d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.9146280005690903d + "'", double6 == 0.9146280005690903d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9L + "'", long9 == 9L);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-2.5496180456051607d) + "'", double13 == (-2.5496180456051607d));
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        double double1 = org.apache.commons.math.util.FastMath.log(3.165519805514716E-5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-10.360608187309596d) + "'", double1 == (-10.360608187309596d));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 15);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 15.0d + "'", double1 == 15.0d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        int int1 = org.apache.commons.math.util.FastMath.abs(71);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 71 + "'", int1 == 71);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 5, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        double double1 = org.apache.commons.math.util.FastMath.floor(15.230453562737472d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 15.0d + "'", double1 == 15.0d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        double double1 = org.apache.commons.math.util.FastMath.sin(4.3648677091068375d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9402197768244945d) + "'", double1 == (-0.9402197768244945d));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-57.29577951308232d) + "'", double1 == (-57.29577951308232d));
    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test068");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        double double14 = randomDataImpl1.nextT(0.7627350637656639d);
//        double double17 = randomDataImpl1.nextCauchy(0.5061169493981285d, 5.853949697499888d);
//        java.lang.String str19 = randomDataImpl1.nextHexString((int) (byte) 10);
//        try {
//            int int22 = randomDataImpl1.nextBinomial((int) (byte) 1, (-0.7363591225007852d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -0.736 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-129.48525567383507d) + "'", double4 == (-129.48525567383507d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.6105534890974117d + "'", double6 == 0.6105534890974117d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2616210396776715d + "'", double14 == 0.2616210396776715d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 15.83809391368003d + "'", double17 == 15.83809391368003d);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "b8e49b6911" + "'", str19.equals("b8e49b6911"));
//    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        double double1 = org.apache.commons.math.util.FastMath.ceil(2.7144176165949068d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number7 = numberIsTooLargeException6.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray13);
        java.lang.Object[] objArray16 = new java.lang.Object[] { objArray13, "" };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException6, localizable8, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("", objArray13);
        org.apache.commons.math.exception.util.Localizable localizable20 = mathException19.getGeneralPattern();
        java.lang.Number number21 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException(localizable20, number21, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray29 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray29);
        java.lang.String str31 = maxIterationsExceededException30.getPattern();
        java.lang.Object[] objArray32 = maxIterationsExceededException30.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable20, objArray32);
        org.apache.commons.math.exception.util.Localizable localizable34 = maxIterationsExceededException33.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException36 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.util.Localizable localizable37 = notStrictlyPositiveException36.getSpecificPattern();
        java.lang.Throwable[] throwableArray38 = notStrictlyPositiveException36.getSuppressed();
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException(localizable34, (java.lang.Object[]) throwableArray38);
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        java.lang.Number number41 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException44 = new org.apache.commons.math.exception.NumberIsTooSmallException(number41, (java.lang.Number) 100, false);
        org.apache.commons.math.exception.util.Localizable localizable45 = numberIsTooSmallException44.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException(localizable48, objArray49);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than, or equal to, the maximum (10)", objArray49);
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException44, "org.apache.commons.math.MaxIterationsExceededException: hi!", objArray49);
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException(localizable40, objArray49);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException(localizable34, objArray49);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException58 = new org.apache.commons.math.exception.OutOfRangeException(localizable34, (java.lang.Number) 1.333707301036022d, (java.lang.Number) 0.37653510734157053d, (java.lang.Number) (-0.02422157392596903d));
        java.lang.Number number59 = outOfRangeException58.getLo();
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1.0d) + "'", number7.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(localizable34);
        org.junit.Assert.assertNull(localizable37);
        org.junit.Assert.assertNotNull(throwableArray38);
        org.junit.Assert.assertNull(localizable45);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertTrue("'" + number59 + "' != '" + 0.37653510734157053d + "'", number59.equals(0.37653510734157053d));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.27080570870314047d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        int int2 = org.apache.commons.math.util.FastMath.max(97, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.9002507367077102d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2386168102233184d + "'", double1 == 1.2386168102233184d);
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        double double14 = randomDataImpl1.nextT(0.7627350637656639d);
//        try {
//            randomDataImpl1.setSecureAlgorithm("", "0d2ac2d91eeb5f37139b635c926bd996e56");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 0d2ac2d91eeb5f37139b635c926bd996e56");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 40.57356107778043d + "'", double4 == 40.57356107778043d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.741319012419601d + "'", double6 == 0.741319012419601d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.6029270376570098d + "'", double14 == 0.6029270376570098d);
//    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray4);
        java.lang.String str6 = maxIterationsExceededException5.getPattern();
        java.lang.String str7 = maxIterationsExceededException5.toString();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException5);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException5);
        org.apache.commons.math.exception.util.Localizable localizable10 = maxIterationsExceededException5.getGeneralPattern();
        java.lang.String str11 = maxIterationsExceededException5.getPattern();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: hi!" + "'", str7.equals("org.apache.commons.math.MaxIterationsExceededException: hi!"));
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 23L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (short) 10);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.5112000488548166E-33d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.7388424178216338d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((-0.27080570870314047d), (-0.9589242746631385d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT(4.599102285891914d);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeed(0L);
//        try {
//            double double10 = randomDataImpl1.nextUniform(0.660029220515412d, (-0.547786400940282d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0.66 is larger than, or equal to, the maximum (-0.548): lower bound (0.66) must be strictly less than upper bound (-0.548)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.357225987125772d + "'", double3 == 1.357225987125772d);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (short) -1, (java.lang.Number) 10L, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        java.lang.Number number6 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10L + "'", number4.equals(10L));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10L + "'", number5.equals(10L));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10L + "'", number6.equals(10L));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        double double2 = org.apache.commons.math.util.FastMath.max(2.526299952429221d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.526299952429221d + "'", double2 == 2.526299952429221d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.17862484014276203d, (double) 20, 0.17412425486732214d);
        normalDistributionImpl3.reseedRandomGenerator((long) (byte) 0);
        java.lang.Class<?> wildcardClass6 = normalDistributionImpl3.getClass();
        double double7 = normalDistributionImpl3.sample();
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 16.229286114923376d + "'", double7 == 16.229286114923376d);
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test085");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        long long7 = randomDataImpl1.nextLong((long) (byte) 10, (long) '4');
//        double double10 = randomDataImpl1.nextF(0.7400576788232446d, 0.8018974326990581d);
//        double double13 = randomDataImpl1.nextGamma(0.8426819462428745d, 0.661899304433709d);
//        randomDataImpl1.reSeedSecure(25L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 5.34111726122409d + "'", double4 == 5.34111726122409d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 26L + "'", long7 == 26L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 488.1876941421458d + "'", double10 == 488.1876941421458d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.2903511944283408d + "'", double13 == 0.2903511944283408d);
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 156.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 156.0d + "'", double2 == 156.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        double double1 = org.apache.commons.math.util.FastMath.acosh(5.865998271154641d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4549740319069104d + "'", double1 == 2.4549740319069104d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 23L, 97.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        int int2 = org.apache.commons.math.util.FastMath.min(3, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.8484181564217285d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3359488222012446d + "'", double1 == 1.3359488222012446d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number6 = numberIsTooLargeException5.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray12);
        java.lang.Object[] objArray15 = new java.lang.Object[] { objArray12, "" };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException5, localizable7, objArray12);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("", objArray12);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("", objArray12);
        org.apache.commons.math.exception.util.Localizable localizable19 = mathException18.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException(localizable19, (java.lang.Number) 0.36496488262332794d, (java.lang.Number) 0.6439528600818949d, (java.lang.Number) 1.3052608122477107d);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException25 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable19, (java.lang.Number) 1.91682296922358d);
        java.lang.Number number26 = notStrictlyPositiveException25.getMin();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1.0d) + "'", number6.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 0 + "'", number26.equals(0));
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test092");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        long long7 = randomDataImpl1.nextLong((long) (byte) 10, (long) '4');
//        try {
//            double double10 = randomDataImpl1.nextGamma((double) 32, (-5.998713782709511d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -5.999 is smaller than, or equal to, the minimum (0): beta");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 6.334177391863326d + "'", double4 == 6.334177391863326d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 31L + "'", long7 == 31L);
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.density(100.0d);
        double double3 = normalDistributionImpl0.getStandardDeviation();
        try {
            double double5 = normalDistributionImpl0.inverseCumulativeProbability(11.203302383478558d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 11.203 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.3359488222012446d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.5772903499365252d, 2.767576814789016d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9763836505421208d + "'", double2 == 0.9763836505421208d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298292365610485d + "'", double1 == 5.298292365610485d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        int int2 = org.apache.commons.math.util.FastMath.max(15, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        int int2 = org.apache.commons.math.util.FastMath.min(7, 19);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.008726646259971648d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        long long2 = org.apache.commons.math.util.FastMath.min(3L, 4L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.6439528600818949d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.57211240238586d + "'", double1 == 0.57211240238586d);
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test102");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) 'a');
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeed();
//        java.lang.String str15 = randomDataImpl1.nextHexString((int) 'a');
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.509599407970054d + "'", double4 == 4.509599407970054d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.36390172746558747d + "'", double6 == 0.36390172746558747d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ef721a39d9b5a861c94cc462925397df30616aaee39cef55f3bd300d61d8f370c7d3b7debe6bfe08748eafe4a55fb64e7" + "'", str15.equals("ef721a39d9b5a861c94cc462925397df30616aaee39cef55f3bd300d61d8f370c7d3b7debe6bfe08748eafe4a55fb64e7"));
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number8 = numberIsTooLargeException7.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] { objArray14, "" };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException7, localizable9, objArray14);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException("", objArray14);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable2, objArray14);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException(localizable0, objArray14);
        org.apache.commons.math.exception.util.Localizable localizable22 = convergenceException21.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (-1.0d) + "'", number8.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNull(localizable22);
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test104");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        randomDataImpl1.reSeedSecure((long) ' ');
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.7945692163463445d + "'", double4 == 4.7945692163463445d);
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable1, objArray8);
        java.lang.Throwable[] throwableArray12 = maxIterationsExceededException11.getSuppressed();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(throwableArray12);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number7 = numberIsTooLargeException6.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray13);
        java.lang.Object[] objArray16 = new java.lang.Object[] { objArray13, "" };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException6, localizable8, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("", objArray13);
        org.apache.commons.math.exception.util.Localizable localizable20 = mathException19.getGeneralPattern();
        java.lang.Number number21 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException(localizable20, number21, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray29 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray29);
        java.lang.String str31 = maxIterationsExceededException30.getPattern();
        java.lang.Object[] objArray32 = maxIterationsExceededException30.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable20, objArray32);
        org.apache.commons.math.exception.util.Localizable localizable34 = maxIterationsExceededException33.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException36 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.util.Localizable localizable37 = notStrictlyPositiveException36.getSpecificPattern();
        java.lang.Throwable[] throwableArray38 = notStrictlyPositiveException36.getSuppressed();
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException(localizable34, (java.lang.Object[]) throwableArray38);
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        java.lang.Number number41 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException44 = new org.apache.commons.math.exception.NumberIsTooSmallException(number41, (java.lang.Number) 100, false);
        org.apache.commons.math.exception.util.Localizable localizable45 = numberIsTooSmallException44.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException(localizable48, objArray49);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than, or equal to, the maximum (10)", objArray49);
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException44, "org.apache.commons.math.MaxIterationsExceededException: hi!", objArray49);
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException(localizable40, objArray49);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException(localizable34, objArray49);
        org.apache.commons.math.exception.util.Localizable localizable55 = convergenceException54.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException59 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable55, (java.lang.Number) 0.29720163021279145d, (java.lang.Number) 0.9788629796100344d, false);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1.0d) + "'", number7.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(localizable34);
        org.junit.Assert.assertNull(localizable37);
        org.junit.Assert.assertNotNull(throwableArray38);
        org.junit.Assert.assertNull(localizable45);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(localizable55);
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test107");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double1 = normalDistributionImpl0.sample();
//        double double3 = normalDistributionImpl0.cumulativeProbability(2.767576814789016d);
//        double double4 = normalDistributionImpl0.getMean();
//        normalDistributionImpl0.reseedRandomGenerator((-1L));
//        double double8 = normalDistributionImpl0.inverseCumulativeProbability(0.29720163021279145d);
//        java.lang.Class<?> wildcardClass9 = normalDistributionImpl0.getClass();
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4536846156063157d + "'", double1 == 1.4536846156063157d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.9971762632543613d + "'", double3 == 0.9971762632543613d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-0.532466034258566d) + "'", double8 == (-0.532466034258566d));
//        org.junit.Assert.assertNotNull(wildcardClass9);
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.8233617200173557d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.278145466316934d + "'", double1 == 1.278145466316934d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 4, 1.0670715664430842E15d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) ' ');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 32L + "'", long1 == 32L);
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test111");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        try {
//            int int16 = randomDataImpl1.nextHypergeometric(3, (int) '#', (int) ' ');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 35 is larger than the maximum (3): number of successes (35) must be less than or equal to population size (3)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.7589399931424508d + "'", double4 == 3.7589399931424508d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.6882321699694331d + "'", double6 == 0.6882321699694331d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test112");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        randomDataImpl1.reSeed((-1L));
//        int int14 = randomDataImpl1.nextZipf(1, 0.9379198162596534d);
//        int int17 = randomDataImpl1.nextBinomial(19, 0.9999584626848042d);
//        int int20 = randomDataImpl1.nextSecureInt(10, 97);
//        double double22 = randomDataImpl1.nextExponential(1.2610288642034437d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.7836549217621176d + "'", double4 == 3.7836549217621176d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.07773701167172087d + "'", double6 == 0.07773701167172087d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 19 + "'", int17 == 19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 51 + "'", int20 == 51);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.5200005253361201d + "'", double22 == 0.5200005253361201d);
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        double double1 = org.apache.commons.math.util.FastMath.sinh(26.983826832980125d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6175627310319656E11d + "'", double1 == 2.6175627310319656E11d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.530197124927653d), (-2.374845165237864d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.530197124927653d) + "'", double2 == (-0.530197124927653d));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.12414970842613213d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.49886369749095866d + "'", double1 == 0.49886369749095866d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 100.0d, (java.lang.Number) 4.9E-324d, false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        java.lang.Number number5 = numberIsTooLargeException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 4.9E-324d + "'", number4.equals(4.9E-324d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 100.0d + "'", number5.equals(100.0d));
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test117");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        int int12 = randomDataImpl1.nextZipf(100, 2.718281828459045d);
//        double double15 = randomDataImpl1.nextCauchy(2.092790987315211d, 0.8813735870195429d);
//        try {
//            randomDataImpl1.setSecureAlgorithm("org.apache.commons.math.exception.NotStrictlyPositiveException: -1 is smaller than, or equal to, the minimum (0)", "ebea043f5dd776406cba9b84d2e612fd");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: ebea043f5dd776406cba9b84d2e612fd");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0854066827002415d + "'", double4 == 3.0854066827002415d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.7017477153151775d + "'", double6 == 0.7017477153151775d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 7.532034570128921d + "'", double15 == 7.532034570128921d);
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(number1, (java.lang.Number) 155.74607629780772d, (java.lang.Number) 1.333707301036022d);
        java.lang.Number number5 = outOfRangeException4.getLo();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 6.0d, (java.lang.Number) 8.054359047689252E13d, true);
        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooLargeException9.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number18 = numberIsTooLargeException17.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray24);
        java.lang.Object[] objArray27 = new java.lang.Object[] { objArray24, "" };
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException17, localizable19, objArray24);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException("", objArray24);
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException("", objArray24);
        org.apache.commons.math.exception.util.Localizable localizable31 = mathException30.getGeneralPattern();
        java.lang.Number number32 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException35 = new org.apache.commons.math.exception.OutOfRangeException(localizable31, number32, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray40 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException41 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray40);
        java.lang.String str42 = maxIterationsExceededException41.getPattern();
        java.lang.Object[] objArray43 = maxIterationsExceededException41.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException44 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable31, objArray43);
        org.apache.commons.math.exception.util.Localizable localizable45 = maxIterationsExceededException44.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException47 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.util.Localizable localizable48 = notStrictlyPositiveException47.getSpecificPattern();
        java.lang.Throwable[] throwableArray49 = notStrictlyPositiveException47.getSuppressed();
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException(localizable45, (java.lang.Object[]) throwableArray49);
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException57 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number58 = numberIsTooLargeException57.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        java.lang.Object[] objArray64 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException65 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray64);
        java.lang.Object[] objArray67 = new java.lang.Object[] { objArray64, "" };
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException57, localizable59, objArray64);
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException("", objArray64);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException70 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable52, objArray64);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException71 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable45, objArray64);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException75 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable45, (java.lang.Number) 11.144178405319577d, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException79 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable45, (java.lang.Number) 26.983826832980125d, (java.lang.Number) 0.7718551054848756d, false);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException83 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number84 = numberIsTooLargeException83.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable85 = null;
        java.lang.Object[] objArray90 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException91 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray90);
        org.apache.commons.math.MathException mathException92 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException83, localizable85, objArray90);
        org.apache.commons.math.ConvergenceException convergenceException93 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException4, localizable45, objArray90);
        org.apache.commons.math.MathException mathException94 = new org.apache.commons.math.MathException("org.apache.commons.math.MaxIterationsExceededException: ", objArray90);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 155.74607629780772d + "'", number5.equals(155.74607629780772d));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (-1.0d) + "'", number18.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(localizable31);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(localizable45);
        org.junit.Assert.assertNull(localizable48);
        org.junit.Assert.assertNotNull(throwableArray49);
        org.junit.Assert.assertTrue("'" + number58 + "' != '" + (-1.0d) + "'", number58.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertTrue("'" + number84 + "' != '" + (-1.0d) + "'", number84.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray90);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 2, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.6619704527324951d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 37.92811310393632d + "'", double1 == 37.92811310393632d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.5264888286059799d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.27861083953310206d) + "'", double1 == (-0.27861083953310206d));
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test122");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl0.density(100.0d);
//        double double3 = normalDistributionImpl0.getStandardDeviation();
//        double double4 = normalDistributionImpl0.sample();
//        double double6 = normalDistributionImpl0.cumulativeProbability((double) (byte) 10);
//        double double7 = normalDistributionImpl0.getMean();
//        double double8 = normalDistributionImpl0.getStandardDeviation();
//        double double9 = normalDistributionImpl0.getMean();
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.45031481399922385d + "'", double4 == 0.45031481399922385d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10);
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test124");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        int int12 = randomDataImpl1.nextZipf(100, 2.718281828459045d);
//        double double15 = randomDataImpl1.nextWeibull(1.6585234628482202d, 2.7973807818415874d);
//        randomDataImpl1.reSeed((long) 4);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 16.83557943756344d + "'", double4 == 16.83557943756344d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.6588643574297026d + "'", double6 == 3.6588643574297026d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.3319715835578714d + "'", double15 == 1.3319715835578714d);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (short) 0, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test126");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeed((long) (short) 0);
//        try {
//            int int17 = randomDataImpl1.nextInt(100, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (100): lower bound (100) must be strictly less than upper bound (100)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 16.54152878614046d + "'", double4 == 16.54152878614046d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 8.296337814503318d + "'", double6 == 8.296337814503318d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.7099784235361526d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-7.138378067497139d) + "'", double1 == (-7.138378067497139d));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.7389860542550094d);
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test129");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) 'a');
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeed();
//        java.lang.String str15 = randomDataImpl1.nextHexString(71);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.62494710504021d + "'", double4 == 8.62494710504021d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.458273129301954d + "'", double6 == 1.458273129301954d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "bbe74b5348598c25d29a20c382f3fd0550e3d367763effe3c77b0db035cae9a282e5e61" + "'", str15.equals("bbe74b5348598c25d29a20c382f3fd0550e3d367763effe3c77b0db035cae9a282e5e61"));
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 6.0d, (java.lang.Number) 8.054359047689252E13d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number12 = numberIsTooLargeException11.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray18);
        java.lang.Object[] objArray21 = new java.lang.Object[] { objArray18, "" };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException11, localizable13, objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("", objArray18);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("", objArray18);
        org.apache.commons.math.exception.util.Localizable localizable25 = mathException24.getGeneralPattern();
        java.lang.Number number26 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException(localizable25, number26, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray34 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray34);
        java.lang.String str36 = maxIterationsExceededException35.getPattern();
        java.lang.Object[] objArray37 = maxIterationsExceededException35.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable25, objArray37);
        org.apache.commons.math.exception.util.Localizable localizable39 = maxIterationsExceededException38.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException41 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.util.Localizable localizable42 = notStrictlyPositiveException41.getSpecificPattern();
        java.lang.Throwable[] throwableArray43 = notStrictlyPositiveException41.getSuppressed();
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException(localizable39, (java.lang.Object[]) throwableArray43);
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException51 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number52 = numberIsTooLargeException51.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        java.lang.Object[] objArray58 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException59 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray58);
        java.lang.Object[] objArray61 = new java.lang.Object[] { objArray58, "" };
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException51, localizable53, objArray58);
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException("", objArray58);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException64 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable46, objArray58);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable39, objArray58);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException69 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable39, (java.lang.Number) 11.144178405319577d, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException73 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable39, (java.lang.Number) 26.983826832980125d, (java.lang.Number) 0.7718551054848756d, false);
        boolean boolean74 = numberIsTooSmallException73.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.0d) + "'", number12.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(localizable25);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(localizable39);
        org.junit.Assert.assertNull(localizable42);
        org.junit.Assert.assertNotNull(throwableArray43);
        org.junit.Assert.assertTrue("'" + number52 + "' != '" + (-1.0d) + "'", number52.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number6 = numberIsTooLargeException5.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray12);
        java.lang.Object[] objArray15 = new java.lang.Object[] { objArray12, "" };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException5, localizable7, objArray12);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("", objArray12);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("", objArray12);
        org.apache.commons.math.exception.util.Localizable localizable19 = mathException18.getGeneralPattern();
        java.lang.Object[] objArray20 = null;
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException(localizable19, objArray20);
        org.apache.commons.math.exception.util.Localizable localizable22 = mathException21.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1.0d) + "'", number6.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertNull(localizable22);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        double double1 = org.apache.commons.math.util.FastMath.rint(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (short) 100, (java.lang.Number) 0.8813735870195429d, (java.lang.Number) 100);
        java.lang.Number number5 = outOfRangeException4.getLo();
        java.lang.Throwable[] throwableArray6 = outOfRangeException4.getSuppressed();
        java.lang.Number number7 = outOfRangeException4.getHi();
        org.apache.commons.math.exception.util.Localizable localizable8 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) 0.9967456178959979d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number18 = numberIsTooLargeException17.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray24);
        java.lang.Object[] objArray27 = new java.lang.Object[] { objArray24, "" };
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException17, localizable19, objArray24);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException("", objArray24);
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException("", objArray24);
        org.apache.commons.math.exception.util.Localizable localizable31 = mathException30.getGeneralPattern();
        java.lang.Number number32 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException35 = new org.apache.commons.math.exception.OutOfRangeException(localizable31, number32, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray40 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException41 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray40);
        java.lang.String str42 = maxIterationsExceededException41.getPattern();
        java.lang.Object[] objArray43 = maxIterationsExceededException41.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException44 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable31, objArray43);
        org.apache.commons.math.exception.util.Localizable localizable45 = maxIterationsExceededException44.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException47 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.util.Localizable localizable48 = notStrictlyPositiveException47.getSpecificPattern();
        java.lang.Throwable[] throwableArray49 = notStrictlyPositiveException47.getSuppressed();
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException(localizable45, (java.lang.Object[]) throwableArray49);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException57 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number58 = numberIsTooLargeException57.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        java.lang.Object[] objArray64 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException65 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray64);
        java.lang.Object[] objArray67 = new java.lang.Object[] { objArray64, "" };
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException57, localizable59, objArray64);
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException("", objArray64);
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException("", objArray64);
        org.apache.commons.math.exception.util.Localizable localizable71 = mathException70.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable73 = null;
        java.lang.Object[] objArray80 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException81 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray80);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException82 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray80);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException83 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable73, objArray80);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException84 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable71, objArray80);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException85 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable45, objArray80);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.8813735870195429d + "'", number5.equals(0.8813735870195429d));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 100 + "'", number7.equals(100));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (-1.0d) + "'", number18.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(localizable31);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(localizable45);
        org.junit.Assert.assertNull(localizable48);
        org.junit.Assert.assertNotNull(throwableArray49);
        org.junit.Assert.assertTrue("'" + number58 + "' != '" + (-1.0d) + "'", number58.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertNotNull(localizable71);
        org.junit.Assert.assertNotNull(objArray80);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.10460946955844201d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102769287390484d + "'", double1 == 1.1102769287390484d);
    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test135");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl0.density(100.0d);
//        double double3 = normalDistributionImpl0.getStandardDeviation();
//        double double4 = normalDistributionImpl0.sample();
//        double double6 = normalDistributionImpl0.cumulativeProbability((double) (byte) 10);
//        double double7 = normalDistributionImpl0.getMean();
//        double double8 = normalDistributionImpl0.getMean();
//        double double9 = normalDistributionImpl0.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.08558306645700497d) + "'", double4 == (-0.08558306645700497d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        double double2 = org.apache.commons.math.util.FastMath.pow((-1.0764993907272205d), 18.95083653482282d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test137");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        int int12 = randomDataImpl1.nextZipf(100, 2.718281828459045d);
//        double double14 = randomDataImpl1.nextT(0.9986169222235228d);
//        try {
//            java.lang.String str16 = randomDataImpl1.nextHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-166.9729654352231d) + "'", double4 == (-166.9729654352231d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.45028845160096d + "'", double6 == 3.45028845160096d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.487976686316714d + "'", double14 == 3.487976686316714d);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number6 = numberIsTooLargeException5.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray12);
        java.lang.Object[] objArray15 = new java.lang.Object[] { objArray12, "" };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException5, localizable7, objArray12);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("", objArray12);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("", objArray12);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException18);
        java.lang.Throwable[] throwableArray20 = convergenceException19.getSuppressed();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1.0d) + "'", number6.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(throwableArray20);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        double double1 = org.apache.commons.math.util.FastMath.ulp(11.144178405319577d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 7.250303402295148d, (java.lang.Number) 0.9436379339725438d, true);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException3.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0d) + "'", number4.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(localizable6);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (short) 0);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test143");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) 'a');
//        randomDataImpl1.reSeedSecure();
//        try {
//            double double14 = randomDataImpl1.nextExponential(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 330.84606153350893d + "'", double4 == 330.84606153350893d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.1756036746357283d + "'", double6 == 2.1756036746357283d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.1628509257251668d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.176861236875575d + "'", double1 == 1.176861236875575d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        int int2 = org.apache.commons.math.util.FastMath.max((int) 'a', 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.07773701167172087d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.07773701167172087d + "'", double1 == 0.07773701167172087d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 6.0d, (java.lang.Number) 8.054359047689252E13d, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number13 = numberIsTooLargeException12.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray19);
        java.lang.Object[] objArray22 = new java.lang.Object[] { objArray19, "" };
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException12, localizable14, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("", objArray19);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException("", objArray19);
        org.apache.commons.math.exception.util.Localizable localizable26 = mathException25.getGeneralPattern();
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException30 = new org.apache.commons.math.exception.OutOfRangeException(localizable26, number27, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray35 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray35);
        java.lang.String str37 = maxIterationsExceededException36.getPattern();
        java.lang.Object[] objArray38 = maxIterationsExceededException36.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException39 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable26, objArray38);
        org.apache.commons.math.exception.util.Localizable localizable40 = maxIterationsExceededException39.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException42 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.util.Localizable localizable43 = notStrictlyPositiveException42.getSpecificPattern();
        java.lang.Throwable[] throwableArray44 = notStrictlyPositiveException42.getSuppressed();
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException(localizable40, (java.lang.Object[]) throwableArray44);
        org.apache.commons.math.exception.util.Localizable localizable47 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException52 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number53 = numberIsTooLargeException52.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        java.lang.Object[] objArray59 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException60 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray59);
        java.lang.Object[] objArray62 = new java.lang.Object[] { objArray59, "" };
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException52, localizable54, objArray59);
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException("", objArray59);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException65 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable47, objArray59);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException66 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable40, objArray59);
        org.apache.commons.math.exception.util.Localizable localizable67 = null;
        java.lang.Object[] objArray72 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException73 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray72);
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException(localizable67, objArray72);
        org.apache.commons.math.MathException mathException75 = new org.apache.commons.math.MathException(throwable0, localizable5, objArray72);
        java.lang.Number number76 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException77 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, number76);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException81 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 1.6585234628482202d, (java.lang.Number) 0.04666813117966975d, true);
        java.lang.Number number82 = numberIsTooSmallException81.getMin();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-1.0d) + "'", number13.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(localizable26);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(localizable40);
        org.junit.Assert.assertNull(localizable43);
        org.junit.Assert.assertNotNull(throwableArray44);
        org.junit.Assert.assertTrue("'" + number53 + "' != '" + (-1.0d) + "'", number53.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertNotNull(objArray72);
        org.junit.Assert.assertTrue("'" + number82 + "' != '" + 0.04666813117966975d + "'", number82.equals(0.04666813117966975d));
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test149");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        long long3 = randomDataImpl1.nextPoisson((double) 10L);
//        try {
//            int int6 = randomDataImpl1.nextInt(71, (int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 71 is larger than, or equal to, the maximum (1): lower bound (71) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 18L + "'", long3 == 18L);
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 4, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        int int1 = org.apache.commons.math.util.FastMath.abs(8);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-0.17738444574517354d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        double double1 = org.apache.commons.math.util.FastMath.atan((-0.5512765187224368d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5038227353842584d) + "'", double1 == (-0.5038227353842584d));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.04123334672217222d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.692977526344448d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        double double14 = randomDataImpl1.nextT(0.7627350637656639d);
//        double double17 = randomDataImpl1.nextCauchy(0.5061169493981285d, 5.853949697499888d);
//        java.lang.String str19 = randomDataImpl1.nextHexString((int) (byte) 10);
//        int int22 = randomDataImpl1.nextInt((int) (byte) 0, 47);
//        try {
//            double double25 = randomDataImpl1.nextF((-1.2028641704164191d), 7.291140084956589d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.203 is smaller than, or equal to, the minimum (0): degrees of freedom (-1.203)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-3.368645816174996d) + "'", double4 == (-3.368645816174996d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.30065327436266603d + "'", double6 == 0.30065327436266603d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.7040144064028198d + "'", double14 == 2.7040144064028198d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-12.57043049736714d) + "'", double17 == (-12.57043049736714d));
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "e9e63473ff" + "'", str19.equals("e9e63473ff"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 42 + "'", int22 == 42);
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(71);
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test158");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT(4.599102285891914d);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure();
//        try {
//            int int8 = randomDataImpl1.nextBinomial(0, 26.983826832980125d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 26.984 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.7102184330970845d) + "'", double3 == (-0.7102184330970845d));
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 32);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 32.0f + "'", float1 == 32.0f);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.35364002184812293d, (java.lang.Number) 0.5101135482240943d, (java.lang.Number) (-3.254343357554558d));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 23L, 0.0d, (double) 19, 8);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test163");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        double double9 = randomDataImpl1.nextGaussian(23.999999999999996d, (double) 4L);
//        long long11 = randomDataImpl1.nextPoisson(1.5112000488548166E-33d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-2.9386644769927934d) + "'", double4 == (-2.9386644769927934d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2600326995922794d + "'", double6 == 0.2600326995922794d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 19.774385621279073d + "'", double9 == 19.774385621279073d);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number7 = numberIsTooLargeException6.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray13);
        java.lang.Object[] objArray16 = new java.lang.Object[] { objArray13, "" };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException6, localizable8, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("", objArray13);
        org.apache.commons.math.exception.util.Localizable localizable20 = mathException19.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException(localizable20, (java.lang.Number) 0.36496488262332794d, (java.lang.Number) 0.6439528600818949d, (java.lang.Number) 1.3052608122477107d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException28 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable20, (java.lang.Number) (-0.6321205588285577d), (java.lang.Number) (-0.6321205588285577d), true);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException36 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number37 = numberIsTooLargeException36.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        java.lang.Object[] objArray43 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException44 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray43);
        java.lang.Object[] objArray46 = new java.lang.Object[] { objArray43, "" };
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException36, localizable38, objArray43);
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException("", objArray43);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException49 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable31, objArray43);
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException(localizable29, objArray43);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException51 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable20, objArray43);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1.0d) + "'", number7.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + (-1.0d) + "'", number37.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(objArray46);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.432811503818636d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7163721481593779d + "'", double1 == 0.7163721481593779d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.17738444574517354d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 52L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        double double1 = org.apache.commons.math.util.FastMath.tanh(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.4711276743037347d, (double) 1L);
        normalDistributionImpl2.reseedRandomGenerator(10L);
        double double6 = normalDistributionImpl2.inverseCumulativeProbability(0.021567306115782663d);
        double double7 = normalDistributionImpl2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-0.5512765187224368d) + "'", double6 == (-0.5512765187224368d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.8179617754648578d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9122732467510485d + "'", double1 == 0.9122732467510485d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        double double2 = org.apache.commons.math.util.FastMath.min(0.37008403273666945d, 5.179454339469011d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.37008403273666945d + "'", double2 == 0.37008403273666945d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException(localizable3, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than, or equal to, the maximum (10)", objArray4);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException(20, "maximal number of iterations ({0}) exceeded", objArray4);
        org.apache.commons.math.exception.util.Localizable localizable8 = maxIterationsExceededException7.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNull(localizable8);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(2.154434690031884d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1544346900318843d + "'", double1 == 2.1544346900318843d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        double double1 = org.apache.commons.math.util.FastMath.expm1(4.900197169420227d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 133.3162601334199d + "'", double1 == 133.3162601334199d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 7.672110364971767d);
    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test176");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        try {
//            java.lang.String str11 = randomDataImpl1.nextHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-4.223853450272834d) + "'", double4 == (-4.223853450272834d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.04185336429722795d + "'", double6 == 0.04185336429722795d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 4L + "'", long9 == 4L);
//    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray4);
        java.lang.String str6 = maxIterationsExceededException5.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray17);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray17);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable10, objArray17);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException("", objArray17);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException5, localizable7, objArray17);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException5);
        java.lang.String str24 = mathException23.getPattern();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "{0}" + "'", str24.equals("{0}"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray4);
        java.lang.String str6 = maxIterationsExceededException5.getPattern();
        java.lang.String str7 = maxIterationsExceededException5.toString();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException5);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException5);
        java.lang.Number number11 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException(number11, (java.lang.Number) 100, false);
        org.apache.commons.math.exception.util.Localizable localizable15 = numberIsTooSmallException14.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException(localizable18, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than, or equal to, the maximum (10)", objArray19);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException14, "org.apache.commons.math.MaxIterationsExceededException: hi!", objArray19);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException5, "org.apache.commons.math.MaxIterationsExceededException: ", objArray19);
        java.lang.Throwable[] throwableArray24 = maxIterationsExceededException5.getSuppressed();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: hi!" + "'", str7.equals("org.apache.commons.math.MaxIterationsExceededException: hi!"));
        org.junit.Assert.assertNull(localizable15);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(throwableArray24);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.07249088736699104d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.07261826738199298d + "'", double1 == 0.07261826738199298d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        double double1 = org.apache.commons.math.util.FastMath.floor(2.000930336872749d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 6.0d, (java.lang.Number) 8.054359047689252E13d, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number13 = numberIsTooLargeException12.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray19);
        java.lang.Object[] objArray22 = new java.lang.Object[] { objArray19, "" };
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException12, localizable14, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("", objArray19);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException("", objArray19);
        org.apache.commons.math.exception.util.Localizable localizable26 = mathException25.getGeneralPattern();
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException30 = new org.apache.commons.math.exception.OutOfRangeException(localizable26, number27, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray35 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray35);
        java.lang.String str37 = maxIterationsExceededException36.getPattern();
        java.lang.Object[] objArray38 = maxIterationsExceededException36.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException39 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable26, objArray38);
        org.apache.commons.math.exception.util.Localizable localizable40 = maxIterationsExceededException39.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException42 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.util.Localizable localizable43 = notStrictlyPositiveException42.getSpecificPattern();
        java.lang.Throwable[] throwableArray44 = notStrictlyPositiveException42.getSuppressed();
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException(localizable40, (java.lang.Object[]) throwableArray44);
        org.apache.commons.math.exception.util.Localizable localizable47 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException52 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number53 = numberIsTooLargeException52.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        java.lang.Object[] objArray59 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException60 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray59);
        java.lang.Object[] objArray62 = new java.lang.Object[] { objArray59, "" };
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException52, localizable54, objArray59);
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException("", objArray59);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException65 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable47, objArray59);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException66 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable40, objArray59);
        java.lang.Number number67 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException70 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, number67, (java.lang.Number) 12.801827480081469d, false);
        java.lang.Object[] objArray75 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException76 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray75);
        java.lang.String str77 = maxIterationsExceededException76.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable78 = null;
        org.apache.commons.math.exception.util.Localizable localizable81 = null;
        java.lang.Object[] objArray88 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException89 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray88);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException90 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray88);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException91 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable81, objArray88);
        org.apache.commons.math.ConvergenceException convergenceException92 = new org.apache.commons.math.ConvergenceException("", objArray88);
        org.apache.commons.math.ConvergenceException convergenceException93 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException76, localizable78, objArray88);
        java.lang.Throwable[] throwableArray94 = maxIterationsExceededException76.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException95 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable5, (java.lang.Object[]) throwableArray94);
        java.lang.Object[] objArray96 = maxIterationsExceededException95.getArguments();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-1.0d) + "'", number13.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(localizable26);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(localizable40);
        org.junit.Assert.assertNull(localizable43);
        org.junit.Assert.assertNotNull(throwableArray44);
        org.junit.Assert.assertTrue("'" + number53 + "' != '" + (-1.0d) + "'", number53.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertNotNull(objArray75);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "hi!" + "'", str77.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray88);
        org.junit.Assert.assertNotNull(throwableArray94);
        org.junit.Assert.assertNotNull(objArray96);
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test182");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT(4.599102285891914d);
//        double double6 = randomDataImpl1.nextGaussian(1.1142547833872074E-7d, 0.02398007912785791d);
//        double double9 = randomDataImpl1.nextGaussian(0.7718551054848756d, 4.605170185988092d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.3374716066411887d + "'", double3 == 3.3374716066411887d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-0.024576854842947325d) + "'", double6 == (-0.024576854842947325d));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-2.4089034388442125d) + "'", double9 == (-2.4089034388442125d));
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            int int3 = randomDataImpl0.nextBinomial(71, (-1.202864170416419d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -1.203 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-0.10908581510341842d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.00190390664077641d) + "'", double1 == (-0.00190390664077641d));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        int int1 = org.apache.commons.math.util.FastMath.round(8.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(7.094610098537221d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.757119422016195d + "'", double1 == 6.757119422016195d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((-35.29684161812119d), 2.2039172235993442E15d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.4536846156063157d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025371582827918356d + "'", double1 == 0.025371582827918356d);
    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test190");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        randomDataImpl1.reSeed();
//        int int10 = randomDataImpl1.nextInt((int) ' ', (int) (byte) 100);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 97.42907387769316d + "'", double4 == 97.42907387769316d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.875984080943245d + "'", double6 == 1.875984080943245d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 99 + "'", int10 == 99);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): standard deviation (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test193");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        long long3 = randomDataImpl1.nextPoisson((double) 10L);
//        double double6 = randomDataImpl1.nextGamma(5.896662418833589d, 4.265278032032717E-17d);
//        try {
//            int int9 = randomDataImpl1.nextPascal((int) '4', 2.766045953121938d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 2.766 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.2575452338681906E-16d + "'", double6 == 1.2575452338681906E-16d);
//    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test194");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl0.density(100.0d);
//        double double3 = normalDistributionImpl0.getStandardDeviation();
//        double double4 = normalDistributionImpl0.getStandardDeviation();
//        double double5 = normalDistributionImpl0.sample();
//        double double6 = normalDistributionImpl0.sample();
//        double double7 = normalDistributionImpl0.getMean();
//        double double8 = normalDistributionImpl0.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.761666183444699d + "'", double5 == 0.761666183444699d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-0.21982219793726177d) + "'", double6 == (-0.21982219793726177d));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test195");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        double double14 = randomDataImpl1.nextT(0.7627350637656639d);
//        double double17 = randomDataImpl1.nextCauchy(0.5061169493981285d, 5.853949697499888d);
//        java.lang.String str19 = randomDataImpl1.nextHexString((int) (byte) 10);
//        double double22 = randomDataImpl1.nextCauchy(1.6910147193352092d, 11.053536600647437d);
//        try {
//            int int25 = randomDataImpl1.nextInt((int) ' ', (int) ' ');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 32 is larger than, or equal to, the maximum (32): lower bound (32) must be strictly less than upper bound (32)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 16.786521889191242d + "'", double4 == 16.786521889191242d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.009331864461893302d + "'", double6 == 0.009331864461893302d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.9391062092747737d + "'", double14 == 2.9391062092747737d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-73.50453083395588d) + "'", double17 == (-73.50453083395588d));
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "d9c3389dab" + "'", str19.equals("d9c3389dab"));
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + (-290.4619517510763d) + "'", double22 == (-290.4619517510763d));
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.3016737816034727d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        double double1 = org.apache.commons.math.util.FastMath.ceil(3.1630827577952556d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number6 = numberIsTooLargeException5.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray12);
        java.lang.Object[] objArray15 = new java.lang.Object[] { objArray12, "" };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException5, localizable7, objArray12);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("", objArray12);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("", objArray12);
        org.apache.commons.math.exception.util.Localizable localizable19 = mathException18.getGeneralPattern();
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException(localizable19, number20, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Number number24 = outOfRangeException23.getLo();
        java.lang.Number number25 = outOfRangeException23.getArgument();
        java.lang.String str26 = outOfRangeException23.toString();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1.0d) + "'", number6.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (byte) 0 + "'", number24.equals((byte) 0));
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: null out of [0, -0.045] range: " + "'", str26.equals("org.apache.commons.math.exception.OutOfRangeException: null out of [0, -0.045] range: "));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.density(100.0d);
        double double4 = normalDistributionImpl0.inverseCumulativeProbability((double) 1);
        double double6 = normalDistributionImpl0.density(2.6384742796497194d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.012280878798950555d + "'", double6 == 0.012280878798950555d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        double double1 = org.apache.commons.math.util.FastMath.abs((-3.468407051996741d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.468407051996741d + "'", double1 == 3.468407051996741d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        double double1 = org.apache.commons.math.util.FastMath.exp(2.169050661553112d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.749973410396805d + "'", double1 == 8.749973410396805d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2.6175627310319656E11d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        double double1 = org.apache.commons.math.util.FastMath.rint((-51.254699613757296d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-51.0d) + "'", double1 == (-51.0d));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number9 = numberIsTooLargeException8.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException16 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray15);
        java.lang.Object[] objArray18 = new java.lang.Object[] { objArray15, "" };
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException8, localizable10, objArray15);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable4, objArray15);
        java.lang.Throwable[] throwableArray21 = mathIllegalArgumentException20.getSuppressed();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException25 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number26 = numberIsTooLargeException25.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray32);
        java.lang.Object[] objArray35 = new java.lang.Object[] { objArray32, "" };
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException25, localizable27, objArray32);
        java.lang.Object[] objArray37 = numberIsTooLargeException25.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable38 = numberIsTooLargeException25.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException45 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number46 = numberIsTooLargeException45.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable47 = null;
        java.lang.Object[] objArray52 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException53 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray52);
        java.lang.Object[] objArray55 = new java.lang.Object[] { objArray52, "" };
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException45, localizable47, objArray52);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException57 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable41, objArray52);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException58 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', "", objArray52);
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalArgumentException20, localizable38, objArray52);
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException(localizable2, objArray52);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException61 = new org.apache.commons.math.MaxIterationsExceededException(2, "org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than, or equal to, the maximum (10)", objArray52);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0d) + "'", number9.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + (-1.0d) + "'", number26.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number46 + "' != '" + (-1.0d) + "'", number46.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(objArray55);
    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test205");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) 'a');
//        randomDataImpl1.reSeedSecure();
//        double double14 = randomDataImpl1.nextT(16.3084113060053d);
//        java.lang.String str16 = randomDataImpl1.nextSecureHexString(32);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 12.160601261561162d + "'", double4 == 12.160601261561162d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.002080933825346d + "'", double6 == 2.002080933825346d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.5270006732917931d + "'", double14 == 0.5270006732917931d);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "ff173b16aeb3569034eafe3ddce87789" + "'", str16.equals("ff173b16aeb3569034eafe3ddce87789"));
//    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (byte) 10, 0.05746016866185325d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.5264888286059799d, 146.16516156047945d);
        double double4 = normalDistributionImpl2.density(0.661899304433709d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0027293925922225915d + "'", double4 == 0.0027293925922225915d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.458273129301954d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray4);
        java.lang.String str6 = maxIterationsExceededException5.getPattern();
        java.lang.String str7 = maxIterationsExceededException5.toString();
        int int8 = maxIterationsExceededException5.getMaxIterations();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException21 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray20);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException22 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray20);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable13, objArray20);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("", objArray20);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.MaxIterationsExceededException: ", objArray20);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException5, localizable9, objArray20);
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException26);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: hi!" + "'", str7.equals("org.apache.commons.math.MaxIterationsExceededException: hi!"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(objArray20);
    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test210");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        java.lang.String str11 = randomDataImpl1.nextHexString((int) '#');
//        double double14 = randomDataImpl1.nextF((double) 1, 3.7836549217621176d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 13.49667076149997d + "'", double4 == 13.49667076149997d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.536621906697815d + "'", double6 == 1.536621906697815d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2L + "'", long9 == 2L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "40c829ce9b7f1fc0746e5098d5a4543d4a1" + "'", str11.equals("40c829ce9b7f1fc0746e5098d5a4543d4a1"));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0419432903052384d + "'", double14 == 1.0419432903052384d);
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.2388097496736767d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.620417469163359d + "'", double1 == 0.620417469163359d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        double double1 = org.apache.commons.math.util.FastMath.sin(3.1630827577952556d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.021488450133937003d) + "'", double1 == (-0.021488450133937003d));
    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test213");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) (byte) 1);
//        double double5 = randomDataImpl1.nextT((double) 8);
//        randomDataImpl1.reSeed();
//        try {
//            java.lang.String str8 = randomDataImpl1.nextHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.5764144829456956d + "'", double3 == 2.5764144829456956d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.22849190767107d) + "'", double5 == (-1.22849190767107d));
//    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test214");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        long long7 = randomDataImpl1.nextLong((long) (byte) 10, (long) '4');
//        double double10 = randomDataImpl1.nextBeta(1.471127674303735d, 1.1185087377885383d);
//        randomDataImpl1.reSeed((long) ' ');
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 13.075922177263212d + "'", double4 == 13.075922177263212d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 34L + "'", long7 == 34L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.23613388039568872d + "'", double10 == 0.23613388039568872d);
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.6437732281381782d, 0.359143479977167d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.643773228138178d + "'", double2 == 0.643773228138178d);
    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test216");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        double double14 = randomDataImpl1.nextT(0.7627350637656639d);
//        double double17 = randomDataImpl1.nextGaussian((double) (byte) 1, 0.29495535414077817d);
//        randomDataImpl1.reSeed();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 12.564699317889351d + "'", double4 == 12.564699317889351d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2500542675426494d + "'", double6 == 0.2500542675426494d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 8 + "'", int9 == 8);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-0.9447181323536665d) + "'", double14 == (-0.9447181323536665d));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.6497517500661671d + "'", double17 == 0.6497517500661671d);
//    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test217");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) (byte) 1);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double6 = normalDistributionImpl4.density(100.0d);
//        double double7 = normalDistributionImpl4.getStandardDeviation();
//        double double8 = normalDistributionImpl4.sample();
//        double double10 = normalDistributionImpl4.cumulativeProbability((double) (byte) 10);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        try {
//            double double14 = randomDataImpl1.nextGamma((-1.165109480336308d), (double) (-1.0f));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.165 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.987974150083285d + "'", double3 == 2.987974150083285d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.5654102247914097d + "'", double8 == 0.5654102247914097d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.3681740579671499d + "'", double11 == 0.3681740579671499d);
//    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number7 = numberIsTooLargeException6.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray13);
        java.lang.Object[] objArray16 = new java.lang.Object[] { objArray13, "" };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException6, localizable8, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("", objArray13);
        org.apache.commons.math.exception.util.Localizable localizable20 = mathException19.getGeneralPattern();
        java.lang.Number number21 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException(localizable20, number21, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray29 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray29);
        java.lang.String str31 = maxIterationsExceededException30.getPattern();
        java.lang.Object[] objArray32 = maxIterationsExceededException30.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable20, objArray32);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        java.lang.Object[] objArray41 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException42 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray41);
        java.lang.String str43 = maxIterationsExceededException42.getPattern();
        java.lang.String str44 = maxIterationsExceededException42.toString();
        java.lang.Object[] objArray45 = maxIterationsExceededException42.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException46 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, localizable36, objArray45);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable34, objArray45);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, objArray45);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException53 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number54 = numberIsTooLargeException53.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException61 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray60);
        java.lang.Object[] objArray63 = new java.lang.Object[] { objArray60, "" };
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException53, localizable55, objArray60);
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException("", objArray60);
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException(localizable20, objArray60);
        org.apache.commons.math.exception.util.Localizable localizable67 = mathException66.getSpecificPattern();
        java.lang.Object[] objArray68 = mathException66.getArguments();
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1.0d) + "'", number7.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "hi!" + "'", str43.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: hi!" + "'", str44.equals("org.apache.commons.math.MaxIterationsExceededException: hi!"));
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertTrue("'" + number54 + "' != '" + (-1.0d) + "'", number54.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertNull(localizable67);
        org.junit.Assert.assertNotNull(objArray68);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        java.lang.Object[] objArray6 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray6);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray6);
        org.apache.commons.math.exception.util.Localizable localizable9 = maxIterationsExceededException8.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(localizable9);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (short) -1, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException(localizable6, objArray7);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than, or equal to, the maximum (10)", objArray7);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, objArray7);
        java.lang.Number number11 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException12 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, number11);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-140.85486110572478d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(15.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.872983346207417d + "'", double1 == 3.872983346207417d);
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test223");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        int int12 = randomDataImpl1.nextInt((int) (short) -1, 7);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-4.793564164569803d) + "'", double4 == (-4.793564164569803d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.4015920856975591d + "'", double6 == 0.4015920856975591d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.025371582827918356d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-0.7675383751963127d), (double) 18L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.04261520489571098d) + "'", double2 == (-0.04261520489571098d));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        double double1 = org.apache.commons.math.util.FastMath.signum(3.872983346207417d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number6 = numberIsTooLargeException5.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray12);
        java.lang.Object[] objArray15 = new java.lang.Object[] { objArray12, "" };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException5, localizable7, objArray12);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("", objArray12);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("", objArray12);
        java.lang.String str19 = mathException18.getPattern();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1.0d) + "'", number6.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test228");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        int int12 = randomDataImpl1.nextZipf(100, 2.718281828459045d);
//        long long14 = randomDataImpl1.nextPoisson(1.333707301036022d);
//        try {
//            int int17 = randomDataImpl1.nextSecureInt(0, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (0): lower bound (0) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-9.052450246225508d) + "'", double4 == (-9.052450246225508d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.13033266187416373d + "'", double6 == 0.13033266187416373d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2L + "'", long9 == 2L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        double double1 = org.apache.commons.math.util.FastMath.acos(16.70428890273695d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(1.5707963267948966d, 0.0013693530418394818d, 0.0d, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (-1) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.547786400940282d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        boolean boolean6 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.Number number7 = numberIsTooLargeException3.getMax();
        java.lang.Number number8 = numberIsTooLargeException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0d) + "'", number4.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 10.0f + "'", number7.equals(10.0f));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (-1.0d) + "'", number8.equals((-1.0d)));
    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test233");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        int int12 = randomDataImpl1.nextZipf(100, 2.718281828459045d);
//        double double14 = randomDataImpl1.nextT(0.9986169222235228d);
//        double double17 = randomDataImpl1.nextCauchy(23.999999999999996d, 5.865998271154641d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl18 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double20 = normalDistributionImpl18.density(100.0d);
//        double double21 = normalDistributionImpl18.getStandardDeviation();
//        double double22 = normalDistributionImpl18.getStandardDeviation();
//        double double23 = normalDistributionImpl18.sample();
//        normalDistributionImpl18.reseedRandomGenerator(4L);
//        double double26 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl18);
//        try {
//            randomDataImpl1.setSecureAlgorithm("org.apache.commons.math.MaxIterationsExceededException: hi!", "ff173b16aeb3569034eafe3ddce87789");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: ff173b16aeb3569034eafe3ddce87789");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-7.883230961895764d) + "'", double4 == (-7.883230961895764d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.866200886753672d + "'", double6 == 3.866200886753672d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 6L + "'", long9 == 6L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-0.016477518913181312d) + "'", double14 == (-0.016477518913181312d));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 43.32241366728295d + "'", double17 == 43.32241366728295d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + (-1.0794212641777636d) + "'", double23 == (-1.0794212641777636d));
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + (-0.2748223745521253d) + "'", double26 == (-0.2748223745521253d));
//    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        int int2 = org.apache.commons.math.util.FastMath.min(6, 47);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(5.34111726122409d, 15.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9986895350333456d + "'", double2 == 0.9986895350333456d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.8266908339278949d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.735694058833187d + "'", double1 == 0.735694058833187d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1, (float) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test238");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        long long7 = randomDataImpl1.nextLong((long) (byte) 10, (long) '4');
//        double double10 = randomDataImpl1.nextBeta(1.471127674303735d, 1.1185087377885383d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double13 = normalDistributionImpl11.density(100.0d);
//        double double14 = normalDistributionImpl11.getStandardDeviation();
//        double double15 = normalDistributionImpl11.sample();
//        double double17 = normalDistributionImpl11.cumulativeProbability((double) (byte) 10);
//        double[] doubleArray19 = normalDistributionImpl11.sample((int) (byte) 100);
//        double double20 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        randomDataImpl1.reSeedSecure(0L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-8.308690899449171d) + "'", double4 == (-8.308690899449171d));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 23L + "'", long7 == 23L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.889810680194652d + "'", double10 == 0.889810680194652d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-0.41196668789851953d) + "'", double15 == (-0.41196668789851953d));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
//        org.junit.Assert.assertNotNull(doubleArray19);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.102138941091466d + "'", double20 == 1.102138941091466d);
//    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test239");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) (byte) 1);
//        double double5 = randomDataImpl1.nextT((double) 8);
//        randomDataImpl1.reSeed();
//        double double8 = randomDataImpl1.nextChiSquare((double) 100L);
//        double double11 = randomDataImpl1.nextWeibull((double) 100L, 1.4690996480235547E-11d);
//        try {
//            int int15 = randomDataImpl1.nextHypergeometric(0, 0, 5);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): population size (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.9958537612035343d) + "'", double3 == (-1.9958537612035343d));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.6781379499326572d) + "'", double5 == (-0.6781379499326572d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 85.2978857780889d + "'", double8 == 85.2978857780889d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.4373117118433105E-11d + "'", double11 == 1.4373117118433105E-11d);
//    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 6.0d, (java.lang.Number) 8.054359047689252E13d, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number13 = numberIsTooLargeException12.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray19);
        java.lang.Object[] objArray22 = new java.lang.Object[] { objArray19, "" };
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException12, localizable14, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("", objArray19);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException("", objArray19);
        org.apache.commons.math.exception.util.Localizable localizable26 = mathException25.getGeneralPattern();
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException30 = new org.apache.commons.math.exception.OutOfRangeException(localizable26, number27, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray35 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray35);
        java.lang.String str37 = maxIterationsExceededException36.getPattern();
        java.lang.Object[] objArray38 = maxIterationsExceededException36.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException39 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable26, objArray38);
        org.apache.commons.math.exception.util.Localizable localizable40 = maxIterationsExceededException39.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException42 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.util.Localizable localizable43 = notStrictlyPositiveException42.getSpecificPattern();
        java.lang.Throwable[] throwableArray44 = notStrictlyPositiveException42.getSuppressed();
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException(localizable40, (java.lang.Object[]) throwableArray44);
        org.apache.commons.math.exception.util.Localizable localizable47 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException52 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number53 = numberIsTooLargeException52.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        java.lang.Object[] objArray59 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException60 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray59);
        java.lang.Object[] objArray62 = new java.lang.Object[] { objArray59, "" };
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException52, localizable54, objArray59);
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException("", objArray59);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException65 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable47, objArray59);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException66 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable40, objArray59);
        org.apache.commons.math.exception.util.Localizable localizable67 = null;
        java.lang.Object[] objArray72 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException73 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray72);
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException(localizable67, objArray72);
        org.apache.commons.math.MathException mathException75 = new org.apache.commons.math.MathException(throwable0, localizable5, objArray72);
        java.lang.Number number76 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException77 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, number76);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException81 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 1.6585234628482202d, (java.lang.Number) 0.04666813117966975d, true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException83 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) 2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-1.0d) + "'", number13.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(localizable26);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(localizable40);
        org.junit.Assert.assertNull(localizable43);
        org.junit.Assert.assertNotNull(throwableArray44);
        org.junit.Assert.assertTrue("'" + number53 + "' != '" + (-1.0d) + "'", number53.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertNotNull(objArray72);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(17.89962401897603d, 37.92811310393632d, (-0.35143403324086336d), 6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: Continued fraction convergents failed to converge (in less than 37.928 iterations) for value {1}");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable1, objArray8);
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException11);
        int int13 = maxIterationsExceededException11.getMaxIterations();
        org.apache.commons.math.exception.util.Localizable localizable14 = maxIterationsExceededException11.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
        org.junit.Assert.assertNull(localizable14);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-0.41196668789851953d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5309716794544337d) + "'", double1 == (-0.5309716794544337d));
    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test244");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) (byte) 1);
//        double double5 = randomDataImpl1.nextT((double) 8);
//        randomDataImpl1.reSeed();
//        try {
//            int int9 = randomDataImpl1.nextPascal(5, (-48.541565062745384d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -48.542 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-6.231085168173987d) + "'", double3 == (-6.231085168173987d));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.8346101270974731d) + "'", double5 == (-0.8346101270974731d));
//    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test245");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        double double14 = randomDataImpl1.nextT(0.7627350637656639d);
//        double double17 = randomDataImpl1.nextCauchy(0.5061169493981285d, 5.853949697499888d);
//        java.lang.String str19 = randomDataImpl1.nextHexString((int) (byte) 10);
//        long long22 = randomDataImpl1.nextSecureLong((long) 4, (long) 99);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-28.061012262670893d) + "'", double4 == (-28.061012262670893d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.27633763296569236d + "'", double6 == 0.27633763296569236d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-18.46692192390092d) + "'", double14 == (-18.46692192390092d));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 19.551297189332793d + "'", double17 == 19.551297189332793d);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "df27862f6d" + "'", str19.equals("df27862f6d"));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 34L + "'", long22 == 34L);
//    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        int int1 = org.apache.commons.math.util.FastMath.abs(97);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 47);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.871201010907891d + "'", double1 == 3.871201010907891d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-0.2966178050570343d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.005176957318283935d) + "'", double1 == (-0.005176957318283935d));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        long long1 = org.apache.commons.math.util.FastMath.round(0.31773538375817445d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (short) -1, (java.lang.Number) 10L, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number12 = numberIsTooLargeException11.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray18);
        java.lang.Object[] objArray21 = new java.lang.Object[] { objArray18, "" };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException11, localizable13, objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("", objArray18);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("", objArray18);
        org.apache.commons.math.exception.util.Localizable localizable25 = mathException24.getGeneralPattern();
        java.lang.Number number26 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException(localizable25, number26, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray34 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray34);
        java.lang.String str36 = maxIterationsExceededException35.getPattern();
        java.lang.Object[] objArray37 = maxIterationsExceededException35.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable25, objArray37);
        org.apache.commons.math.exception.util.Localizable localizable39 = maxIterationsExceededException38.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException41 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.util.Localizable localizable42 = notStrictlyPositiveException41.getSpecificPattern();
        java.lang.Throwable[] throwableArray43 = notStrictlyPositiveException41.getSuppressed();
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException(localizable39, (java.lang.Object[]) throwableArray43);
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        java.lang.Number number46 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException49 = new org.apache.commons.math.exception.NumberIsTooSmallException(number46, (java.lang.Number) 100, false);
        org.apache.commons.math.exception.util.Localizable localizable50 = numberIsTooSmallException49.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        java.lang.Object[] objArray54 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException(localizable53, objArray54);
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than, or equal to, the maximum (10)", objArray54);
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException49, "org.apache.commons.math.MaxIterationsExceededException: hi!", objArray54);
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException(localizable45, objArray54);
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException(localizable39, objArray54);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException66 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number67 = numberIsTooLargeException66.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable68 = null;
        java.lang.Object[] objArray73 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException74 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray73);
        java.lang.Object[] objArray76 = new java.lang.Object[] { objArray73, "" };
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException66, localizable68, objArray73);
        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException("", objArray73);
        org.apache.commons.math.MathException mathException79 = new org.apache.commons.math.MathException("", objArray73);
        org.apache.commons.math.exception.util.Localizable localizable80 = mathException79.getGeneralPattern();
        java.lang.Number number81 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException84 = new org.apache.commons.math.exception.OutOfRangeException(localizable80, number81, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray89 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException90 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray89);
        java.lang.String str91 = maxIterationsExceededException90.getPattern();
        java.lang.Object[] objArray92 = maxIterationsExceededException90.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException93 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable80, objArray92);
        org.apache.commons.math.ConvergenceException convergenceException94 = new org.apache.commons.math.ConvergenceException(localizable39, objArray92);
        java.lang.Object[] objArray95 = null;
        org.apache.commons.math.ConvergenceException convergenceException96 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3, localizable39, objArray95);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10L + "'", number4.equals(10L));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.0d) + "'", number12.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(localizable25);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(localizable39);
        org.junit.Assert.assertNull(localizable42);
        org.junit.Assert.assertNotNull(throwableArray43);
        org.junit.Assert.assertNull(localizable50);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertTrue("'" + number67 + "' != '" + (-1.0d) + "'", number67.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray73);
        org.junit.Assert.assertNotNull(objArray76);
        org.junit.Assert.assertNotNull(localizable80);
        org.junit.Assert.assertNotNull(objArray89);
        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "hi!" + "'", str91.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray92);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (short) -1, (java.lang.Number) 10L, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        boolean boolean6 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10L + "'", number4.equals(10L));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10L + "'", number5.equals(10L));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.05746016866185325d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.057523532423583434d + "'", double1 == 0.057523532423583434d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        long long1 = org.apache.commons.math.util.FastMath.round(1.0380377007567323d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test255");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT(4.599102285891914d);
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString((int) (byte) 100);
//        randomDataImpl1.reSeed((long) 6);
//        long long9 = randomDataImpl1.nextPoisson((double) 15);
//        java.lang.Class<?> wildcardClass10 = randomDataImpl1.getClass();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.6601159579592064d) + "'", double3 == (-0.6601159579592064d));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "d3039454fc72da65dd39e81862dfdf8592e07150e33a8f4d960dcf164dab3ef25754d103d2ed9a516b211f15c7aec13a8f0e" + "'", str5.equals("d3039454fc72da65dd39e81862dfdf8592e07150e33a8f4d960dcf164dab3ef25754d103d2ed9a516b211f15c7aec13a8f0e"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 18L + "'", long9 == 18L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        double double1 = org.apache.commons.math.util.FastMath.exp(7.941843147108244d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2812.5396582046383d + "'", double1 == 2812.5396582046383d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-0.9402197768244945d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.979662446853083d) + "'", double1 == (-0.979662446853083d));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.4064624400499381d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 4.672738657069999d);
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray13);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray13);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException16 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable6, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException(localizable3, objArray13);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable3, (java.lang.Number) 1.0435012536236978d, (java.lang.Number) 10L, false);
        boolean boolean23 = numberIsTooLargeException22.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray4);
        java.lang.String str6 = maxIterationsExceededException5.getPattern();
        java.lang.String str7 = maxIterationsExceededException5.toString();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException5);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException5);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number18 = numberIsTooLargeException17.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray24);
        java.lang.Object[] objArray27 = new java.lang.Object[] { objArray24, "" };
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException17, localizable19, objArray24);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, objArray24);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', "", objArray24);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException5, "org.apache.commons.math.MaxIterationsExceededException: hi!", objArray24);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: hi!" + "'", str7.equals("org.apache.commons.math.MaxIterationsExceededException: hi!"));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (-1.0d) + "'", number18.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray27);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) (-1L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number7 = numberIsTooLargeException6.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray13);
        java.lang.Object[] objArray16 = new java.lang.Object[] { objArray13, "" };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException6, localizable8, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("", objArray13);
        org.apache.commons.math.exception.util.Localizable localizable20 = mathException19.getGeneralPattern();
        java.lang.Number number21 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException(localizable20, number21, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray29 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray29);
        java.lang.String str31 = maxIterationsExceededException30.getPattern();
        java.lang.Object[] objArray32 = maxIterationsExceededException30.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable20, objArray32);
        java.lang.Object[] objArray34 = null;
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException(localizable20, objArray34);
        java.lang.String str36 = mathException35.toString();
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1.0d) + "'", number7.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "org.apache.commons.math.MathException: " + "'", str36.equals("org.apache.commons.math.MathException: "));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number6 = numberIsTooLargeException5.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray12);
        java.lang.Object[] objArray15 = new java.lang.Object[] { objArray12, "" };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException5, localizable7, objArray12);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("", objArray12);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("", objArray12);
        org.apache.commons.math.exception.util.Localizable localizable19 = mathException18.getGeneralPattern();
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException(localizable19, number20, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Number number24 = outOfRangeException23.getLo();
        java.lang.Number number25 = outOfRangeException23.getArgument();
        java.lang.Number number26 = outOfRangeException23.getLo();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1.0d) + "'", number6.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (byte) 0 + "'", number24.equals((byte) 0));
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + (byte) 0 + "'", number26.equals((byte) 0));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        double double1 = org.apache.commons.math.special.Gamma.digamma((double) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9227843322079321d + "'", double1 == 0.9227843322079321d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-0.4705444516411526d), 15.230453562737472d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.030885148884500332d) + "'", double2 == (-0.030885148884500332d));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 155.74607629780772d, (java.lang.Number) 1.333707301036022d);
        java.lang.Number number4 = outOfRangeException3.getLo();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number11 = numberIsTooLargeException10.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray17);
        java.lang.Object[] objArray20 = new java.lang.Object[] { objArray17, "" };
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException10, localizable12, objArray17);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException("", objArray17);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException("", objArray17);
        org.apache.commons.math.exception.util.Localizable localizable24 = mathException23.getGeneralPattern();
        java.lang.Object[] objArray25 = null;
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException(localizable24, objArray25);
        outOfRangeException3.addSuppressed((java.lang.Throwable) mathException26);
        java.lang.String str28 = outOfRangeException3.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 155.74607629780772d + "'", number4.equals(155.74607629780772d));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (-1.0d) + "'", number11.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(localizable24);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: null out of [155.746, 1.334] range" + "'", str28.equals("org.apache.commons.math.exception.OutOfRangeException: null out of [155.746, 1.334] range"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-1), 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        double double2 = org.apache.commons.math.util.FastMath.max(0.04123334672217222d, 5.850819246440887d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.850819246440887d + "'", double2 == 5.850819246440887d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.density(100.0d);
        double double4 = normalDistributionImpl0.inverseCumulativeProbability((double) 1);
        double double5 = normalDistributionImpl0.getStandardDeviation();
        try {
            double[] doubleArray7 = normalDistributionImpl0.sample((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): number of samples (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.91682296922358d);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test271");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        double double14 = randomDataImpl1.nextT(0.7627350637656639d);
//        double double17 = randomDataImpl1.nextCauchy(0.5061169493981285d, 5.853949697499888d);
//        java.lang.String str19 = randomDataImpl1.nextHexString((int) (byte) 10);
//        int int22 = randomDataImpl1.nextInt((int) (byte) 0, 47);
//        try {
//            int int25 = randomDataImpl1.nextZipf(0, (double) 6);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): dimension (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.3666065301114114d) + "'", double4 == (-0.3666065301114114d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05564748197892395d + "'", double6 == 0.05564748197892395d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-7.009504305986247d) + "'", double14 == (-7.009504305986247d));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-0.15517575596031807d) + "'", double17 == (-0.15517575596031807d));
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "58a8658052" + "'", str19.equals("58a8658052"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 26 + "'", int22 == 26);
//    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        double double1 = org.apache.commons.math.util.FastMath.atanh(3.1630827577952556d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray5);
        java.lang.String str7 = maxIterationsExceededException6.getPattern();
        java.lang.String str8 = maxIterationsExceededException6.toString();
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException6);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException6);
        java.lang.Number number12 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(number12, (java.lang.Number) 100, false);
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooSmallException15.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException(localizable19, objArray20);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than, or equal to, the maximum (10)", objArray20);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException15, "org.apache.commons.math.MaxIterationsExceededException: hi!", objArray20);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException6, "org.apache.commons.math.MaxIterationsExceededException: ", objArray20);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException(localizable0, objArray20);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: hi!" + "'", str8.equals("org.apache.commons.math.MaxIterationsExceededException: hi!"));
        org.junit.Assert.assertNull(localizable16);
        org.junit.Assert.assertNotNull(objArray20);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        double double1 = org.apache.commons.math.special.Erf.erf(0.5772156649015329d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5856749831752239d + "'", double1 == 0.5856749831752239d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 6.0d, (java.lang.Number) 8.054359047689252E13d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number12 = numberIsTooLargeException11.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray18);
        java.lang.Object[] objArray21 = new java.lang.Object[] { objArray18, "" };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException11, localizable13, objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("", objArray18);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("", objArray18);
        org.apache.commons.math.exception.util.Localizable localizable25 = mathException24.getGeneralPattern();
        java.lang.Number number26 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException(localizable25, number26, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray34 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray34);
        java.lang.String str36 = maxIterationsExceededException35.getPattern();
        java.lang.Object[] objArray37 = maxIterationsExceededException35.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable25, objArray37);
        org.apache.commons.math.exception.util.Localizable localizable39 = maxIterationsExceededException38.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException41 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.util.Localizable localizable42 = notStrictlyPositiveException41.getSpecificPattern();
        java.lang.Throwable[] throwableArray43 = notStrictlyPositiveException41.getSuppressed();
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException(localizable39, (java.lang.Object[]) throwableArray43);
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException51 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number52 = numberIsTooLargeException51.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        java.lang.Object[] objArray58 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException59 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray58);
        java.lang.Object[] objArray61 = new java.lang.Object[] { objArray58, "" };
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException51, localizable53, objArray58);
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException("", objArray58);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException64 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable46, objArray58);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable39, objArray58);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException69 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable39, (java.lang.Number) 11.144178405319577d, (java.lang.Number) (short) 0, false);
        java.lang.Number number70 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException73 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable39, number70, (java.lang.Number) (-0.8592237687095796d), false);
        java.lang.Object[] objArray74 = null;
        org.apache.commons.math.MathException mathException75 = new org.apache.commons.math.MathException(localizable39, objArray74);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.0d) + "'", number12.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(localizable25);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(localizable39);
        org.junit.Assert.assertNull(localizable42);
        org.junit.Assert.assertNotNull(throwableArray43);
        org.junit.Assert.assertTrue("'" + number52 + "' != '" + (-1.0d) + "'", number52.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(objArray61);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        double double1 = org.apache.commons.math.util.FastMath.cosh(2.4746473287171966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.980855096195225d + "'", double1 == 5.980855096195225d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 'a', 0.9227843322079321d, 1.6910147193352092d, 100);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-0.43364064491300164d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5685264992640194d) + "'", double1 == (-0.5685264992640194d));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getSpecificPattern();
        java.lang.String str3 = notStrictlyPositiveException1.toString();
        java.lang.Number number4 = notStrictlyPositiveException1.getMin();
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException1.getGeneralPattern();
        boolean boolean6 = notStrictlyPositiveException1.getBoundIsAllowed();
        java.lang.Number number7 = notStrictlyPositiveException1.getMin();
        boolean boolean8 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertNull(localizable2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: -1 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: -1 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0 + "'", number7.equals(0));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test282");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        int int12 = randomDataImpl1.nextZipf(100, 2.718281828459045d);
//        try {
//            double double15 = randomDataImpl1.nextWeibull((double) 52.0f, (-1.9717386562014238E-5d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0 is smaller than, or equal to, the minimum (0): scale (-0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.8045750696820619d) + "'", double4 == (-0.8045750696820619d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2585692887740386d + "'", double6 == 0.2585692887740386d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 8L + "'", long9 == 8L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0);
        java.lang.String str2 = maxIterationsExceededException1.getPattern();
        java.lang.String str3 = maxIterationsExceededException1.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = maxIterationsExceededException1.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException8 = new org.apache.commons.math.exception.OutOfRangeException(localizable4, (java.lang.Number) 1.7763568394002505E-15d, (java.lang.Number) 2.2645326428298556d, (java.lang.Number) (-0.8305568064477297d));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "maximal number of iterations ({0}) exceeded" + "'", str2.equals("maximal number of iterations ({0}) exceeded"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "maximal number of iterations ({0}) exceeded" + "'", str3.equals("maximal number of iterations ({0}) exceeded"));
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) (-0.04261520489571098d), (java.lang.Number) 1.0435012536236978d);
    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test285");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        randomDataImpl1.reSeed();
//        double double13 = randomDataImpl1.nextGaussian((-0.5418080117554591d), 0.4999921339008419d);
//        long long15 = randomDataImpl1.nextPoisson(0.015413343812216955d);
//        double double18 = randomDataImpl1.nextWeibull(0.1496495520142893d, (double) 3L);
//        double double21 = randomDataImpl1.nextGaussian(0.0011391256666861732d, 2.498447650589192E15d);
//        double double23 = randomDataImpl1.nextChiSquare(0.9967456178959979d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.8360439036188965d) + "'", double4 == (-0.8360439036188965d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.8190667886685015d + "'", double6 == 3.8190667886685015d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 8L + "'", long9 == 8L);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-0.8296985723645218d) + "'", double13 == (-0.8296985723645218d));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 8.759744438546308d + "'", double18 == 8.759744438546308d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-3.217822984691031E15d) + "'", double21 == (-3.217822984691031E15d));
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.263934917330771d + "'", double23 == 1.263934917330771d);
//    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        double double1 = org.apache.commons.math.util.FastMath.log10((-0.8592237687095796d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        double double1 = org.apache.commons.math.util.FastMath.floor(6.97154186626894d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.0d + "'", double1 == 6.0d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.5611783657224383E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.724770269276073E-11d + "'", double1 == 2.724770269276073E-11d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        float float2 = org.apache.commons.math.util.FastMath.max(8.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 0, 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray4);
        java.lang.String str6 = maxIterationsExceededException5.getPattern();
        java.lang.String str7 = maxIterationsExceededException5.toString();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException5);
        org.apache.commons.math.exception.util.Localizable localizable9 = maxIterationsExceededException5.getSpecificPattern();
        int int10 = maxIterationsExceededException5.getMaxIterations();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: hi!" + "'", str7.equals("org.apache.commons.math.MaxIterationsExceededException: hi!"));
        org.junit.Assert.assertNull(localizable9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test292");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        long long7 = randomDataImpl1.nextLong((long) (byte) 10, (long) '4');
//        double double10 = randomDataImpl1.nextF(0.7400576788232446d, 0.8018974326990581d);
//        double double13 = randomDataImpl1.nextGamma(0.8426819462428745d, 0.661899304433709d);
//        try {
//            double double16 = randomDataImpl1.nextWeibull((double) 18, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): scale (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.6230753489879135d) + "'", double4 == (-0.6230753489879135d));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 33L + "'", long7 == 33L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.6901568153847806d + "'", double10 == 2.6901568153847806d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0406363101406363d + "'", double13 == 0.0406363101406363d);
//    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test293");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) (byte) 1);
//        double double5 = randomDataImpl1.nextT((double) 8);
//        randomDataImpl1.reSeed();
//        double double8 = randomDataImpl1.nextChiSquare((double) 100L);
//        double double11 = randomDataImpl1.nextWeibull((double) 100L, 1.4690996480235547E-11d);
//        try {
//            int int14 = randomDataImpl1.nextInt(9, 8);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 9 is larger than, or equal to, the maximum (8): lower bound (9) must be strictly less than upper bound (8)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.34770758639596483d) + "'", double3 == (-0.34770758639596483d));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.023843579422799d + "'", double5 == 3.023843579422799d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 95.57559215125333d + "'", double8 == 95.57559215125333d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.4923252250782675E-11d + "'", double11 == 1.4923252250782675E-11d);
//    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number8 = numberIsTooLargeException7.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] { objArray14, "" };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException7, localizable9, objArray14);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException("", objArray14);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable2, objArray14);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException(localizable0, objArray14);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException21);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray35);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray35);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable28, objArray35);
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException("5fa2692c956e6b17b0ae0645ae88e67a635", objArray35);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException40 = new org.apache.commons.math.MaxIterationsExceededException(32, "maximal number of iterations ({0}) exceeded", objArray35);
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException21, "org.apache.commons.math.MaxIterationsExceededException: hi!", objArray35);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (-1.0d) + "'", number8.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray35);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.65382533884505d, (double) 99, 0.0d, 51);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.4906919352937438E-44d + "'", double4 == 1.4906919352937438E-44d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        double double1 = org.apache.commons.math.util.FastMath.log10(4.3648677091068375d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6399710855958733d + "'", double1 == 0.6399710855958733d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-57.29577951308232d) + "'", double1 == (-57.29577951308232d));
    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test298");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT(4.599102285891914d);
//        randomDataImpl1.reSeedSecure();
//        double double7 = randomDataImpl1.nextCauchy(0.9986169222235228d, 10.0d);
//        try {
//            int int10 = randomDataImpl1.nextPascal(15, 11.453447665719617d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 11.453 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.4937093065434995d) + "'", double3 == (-0.4937093065434995d));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-24.5742910726234d) + "'", double7 == (-24.5742910726234d));
//    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test299");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        double double14 = randomDataImpl1.nextT(0.7627350637656639d);
//        double double17 = randomDataImpl1.nextGaussian((double) (byte) 1, 0.29495535414077817d);
//        randomDataImpl1.reSeed((long) 2);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.9584701832998324d) + "'", double4 == (-1.9584701832998324d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.28888087399969736d + "'", double6 == 0.28888087399969736d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-0.06933046210927461d) + "'", double14 == (-0.06933046210927461d));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.669541753945742d + "'", double17 == 0.669541753945742d);
//    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        double double2 = org.apache.commons.math.util.FastMath.min(1.5625640275552255d, 8.759744438546308d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5625640275552255d + "'", double2 == 1.5625640275552255d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        double double1 = org.apache.commons.math.util.FastMath.atanh(5.896662418833589d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test302");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        randomDataImpl1.reSeed();
//        double double9 = randomDataImpl1.nextT(1.658714676597928d);
//        try {
//            long long12 = randomDataImpl1.nextSecureLong((long) 0, 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (0): lower bound (0) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.5672045769075114d) + "'", double4 == (-1.5672045769075114d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.4421326172313533d + "'", double6 == 1.4421326172313533d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.4988346349914473d) + "'", double9 == (-0.4988346349914473d));
//    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test303");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        int int12 = randomDataImpl1.nextZipf(100, 2.718281828459045d);
//        long long14 = randomDataImpl1.nextPoisson(1.333707301036022d);
//        try {
//            int int17 = randomDataImpl1.nextInt((int) (short) 100, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (100): lower bound (100) must be strictly less than upper bound (100)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.6081299471702888d) + "'", double4 == (-1.6081299471702888d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.9673535463738256d + "'", double6 == 1.9673535463738256d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2L + "'", long14 == 2L);
//    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-0.27663364868004303d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test305");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        long long4 = randomDataImpl0.nextLong((long) 20, (long) (short) 100);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 47L + "'", long4 == 47L);
//    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray4);
        java.lang.String str6 = maxIterationsExceededException5.getPattern();
        java.lang.String str7 = maxIterationsExceededException5.toString();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException5);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException5);
        java.lang.Number number11 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException(number11, (java.lang.Number) 100, false);
        org.apache.commons.math.exception.util.Localizable localizable15 = numberIsTooSmallException14.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException(localizable18, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than, or equal to, the maximum (10)", objArray19);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException14, "org.apache.commons.math.MaxIterationsExceededException: hi!", objArray19);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException5, "org.apache.commons.math.MaxIterationsExceededException: ", objArray19);
        org.apache.commons.math.exception.util.Localizable localizable24 = maxIterationsExceededException5.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: hi!" + "'", str7.equals("org.apache.commons.math.MaxIterationsExceededException: hi!"));
        org.junit.Assert.assertNull(localizable15);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(localizable24);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        int int2 = org.apache.commons.math.util.FastMath.max(99, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 99 + "'", int2 == 99);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.6442707901101211d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.011244646561846934d + "'", double1 == 0.011244646561846934d);
    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test309");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        int int12 = randomDataImpl1.nextZipf(100, 2.718281828459045d);
//        double double15 = randomDataImpl1.nextWeibull(1.6585234628482202d, 2.7973807818415874d);
//        java.lang.String str17 = randomDataImpl1.nextHexString(7);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution18 = null;
//        try {
//            int int19 = randomDataImpl1.nextInversionDeviate(integerDistribution18);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.638869046715172d + "'", double4 == 3.638869046715172d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.9836893644323768d + "'", double6 == 2.9836893644323768d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 5L + "'", long9 == 5L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.1609716245911987d + "'", double15 == 2.1609716245911987d);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ba19269" + "'", str17.equals("ba19269"));
//    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray4);
        java.lang.String str6 = maxIterationsExceededException5.getPattern();
        java.lang.String str7 = maxIterationsExceededException5.toString();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException5);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException5);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException9.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = mathException9.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray24);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray24);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable17, objArray24);
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException("", objArray24);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException(8, "org.apache.commons.math.MathException: ", objArray24);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException9, "ef721a39d9b5a861c94cc462925397df30616aaee39cef55f3bd300d61d8f370c7d3b7debe6bfe08748eafe4a55fb64e7", objArray24);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: hi!" + "'", str7.equals("org.apache.commons.math.MaxIterationsExceededException: hi!"));
        org.junit.Assert.assertNull(localizable10);
        org.junit.Assert.assertNull(localizable11);
        org.junit.Assert.assertNotNull(objArray24);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.10460946955844201d, 1.2386168102233184d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.017509202108419396d + "'", double2 == 0.017509202108419396d);
    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test312");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        long long7 = randomDataImpl1.nextLong((long) (byte) 10, (long) '4');
//        double double10 = randomDataImpl1.nextBeta(1.471127674303735d, 1.1185087377885383d);
//        randomDataImpl1.reSeed((long) '4');
//        int int15 = randomDataImpl1.nextZipf(4, 1.1713114974625016d);
//        double double18 = randomDataImpl1.nextCauchy((-0.3355134330424695d), 1.1713114974625016d);
//        long long21 = randomDataImpl1.nextSecureLong(50L, (long) 51);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.2516096916609687d + "'", double4 == 2.2516096916609687d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 32L + "'", long7 == 32L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.3197496624503456d + "'", double10 == 0.3197496624503456d);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.17759321550844975d + "'", double18 == 0.17759321550844975d);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 51L + "'", long21 == 51L);
//    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(5.298292365610485d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 303.5697911758657d + "'", double1 == 303.5697911758657d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.05746016866185325d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9983496186683268d + "'", double1 == 0.9983496186683268d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((-1.3589871584774578d), 0.9999546000702375d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.0013693530418394818d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.9788629796100344d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(19.774385621279073d, (-0.04527605728197682d), 5.179454339469011d, 4);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        double double2 = org.apache.commons.math.util.FastMath.pow((-0.9447181323536665d), (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.058516784798662d) + "'", double2 == (-1.058516784798662d));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-0.3518548721102766d));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 155.74607629780772d, (java.lang.Number) 1.333707301036022d);
        java.lang.Number number4 = outOfRangeException3.getHi();
        java.lang.Number number5 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.333707301036022d + "'", number4.equals(1.333707301036022d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.333707301036022d + "'", number5.equals(1.333707301036022d));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        int int2 = org.apache.commons.math.util.FastMath.max(1, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-0.017453292519943295d), 0.227697895714823d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.07650150137124312d) + "'", double2 == (-0.07650150137124312d));
    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test325");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        double double14 = randomDataImpl1.nextT(0.7627350637656639d);
//        double double17 = randomDataImpl1.nextGaussian((double) (byte) 1, 0.29495535414077817d);
//        try {
//            int int20 = randomDataImpl1.nextBinomial((-1), 1.1571890363470199d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of trials (-1)");
//        } catch (org.apache.commons.math.exception.NotPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.427331994377983d + "'", double4 == 2.427331994377983d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.1816795016359056d + "'", double6 == 0.1816795016359056d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.2060429914755701d + "'", double14 == 1.2060429914755701d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.4094877594039583d + "'", double17 == 1.4094877594039583d);
//    }

//    @Test
//    public void test326() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test326");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        double double14 = randomDataImpl1.nextT(0.7627350637656639d);
//        double double17 = randomDataImpl1.nextGaussian((double) (byte) 1, 0.29495535414077817d);
//        try {
//            int[] intArray20 = randomDataImpl1.nextPermutation((int) (byte) -1, (int) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 1 is larger than the maximum (-1): permutation size (1) exceeds permuation domain (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.455792343026056d + "'", double4 == 2.455792343026056d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.5148332964423514d + "'", double6 == 3.5148332964423514d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 5 + "'", int9 == 5);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-3.7279806861695075d) + "'", double14 == (-3.7279806861695075d));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.8623090694694975d + "'", double17 == 0.8623090694694975d);
//    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test327");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double1 = normalDistributionImpl0.sample();
//        double double3 = normalDistributionImpl0.cumulativeProbability(2.767576814789016d);
//        double double4 = normalDistributionImpl0.getMean();
//        normalDistributionImpl0.reseedRandomGenerator((-1L));
//        double double8 = normalDistributionImpl0.inverseCumulativeProbability(0.29720163021279145d);
//        try {
//            double double10 = normalDistributionImpl0.inverseCumulativeProbability(1.4536846156063157d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 1.454 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5447724775539189d + "'", double1 == 1.5447724775539189d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.9971762632543613d + "'", double3 == 0.9971762632543613d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-0.532466034258566d) + "'", double8 == (-0.532466034258566d));
//    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(16.70428890273695d, 8.759744438546308d, 0.8179617754648578d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        long long1 = org.apache.commons.math.util.FastMath.round(4.599102285891914d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 5L + "'", long1 == 5L);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.0419432903052384d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.01784408232461434d + "'", double1 == 0.01784408232461434d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.417895747432709d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4178957474327092d + "'", double1 == 1.4178957474327092d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        double double2 = org.apache.commons.math.util.FastMath.atan2(3.7836549217621176d, 1.4536846156063157d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2039833869074952d + "'", double2 == 1.2039833869074952d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        double double2 = org.apache.commons.math.util.FastMath.max(1.102138941091466d, 1.3324239006691985d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3324239006691985d + "'", double2 == 1.3324239006691985d);
    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test334");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        int int12 = randomDataImpl1.nextZipf(100, 2.718281828459045d);
//        try {
//            long long15 = randomDataImpl1.nextLong((long) (short) 100, (long) (short) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (1): lower bound (100) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.604022713160101d + "'", double4 == 2.604022713160101d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.40621949446135364d + "'", double6 == 0.40621949446135364d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 8L + "'", long9 == 8L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.4711276743037347d, (double) 1L);
        double double3 = normalDistributionImpl2.getStandardDeviation();
        double double5 = normalDistributionImpl2.density(2.220446049250313E-16d);
        double double6 = normalDistributionImpl2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.13519368159152453d + "'", double5 == 0.13519368159152453d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(101.01390413576755d, 1.6588373234332228d);
    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test337");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double1 = normalDistributionImpl0.sample();
//        double double3 = normalDistributionImpl0.cumulativeProbability(2.767576814789016d);
//        double double4 = normalDistributionImpl0.getMean();
//        double double6 = normalDistributionImpl0.density(1.2610288642034437d);
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08510804190921128d + "'", double1 == 0.08510804190921128d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.9971762632543613d + "'", double3 == 0.9971762632543613d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.18013739181591165d + "'", double6 == 0.18013739181591165d);
//    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.033848630998717065d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.033842170764600776d + "'", double1 == 0.033842170764600776d);
    }

//    @Test
//    public void test339() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test339");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        randomDataImpl1.reSeed((-1L));
//        int int14 = randomDataImpl1.nextZipf(1, 0.9379198162596534d);
//        try {
//            double double17 = randomDataImpl1.nextBeta(4.9E-324d, (-0.024576854842947325d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.012");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.5074276444720405d + "'", double4 == 1.5074276444720405d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.12961343524892882d + "'", double6 == 0.12961343524892882d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 6L + "'", long9 == 6L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException5);
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        long long2 = org.apache.commons.math.util.FastMath.max(4L, 8L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
    }

//    @Test
//    public void test342() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test342");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) 'a');
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeed();
//        double double15 = randomDataImpl1.nextExponential((double) (short) 100);
//        try {
//            double double18 = randomDataImpl1.nextUniform((double) 100, (double) 5);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (5): lower bound (100) must be strictly less than upper bound (5)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.4066469882252997d + "'", double4 == 1.4066469882252997d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.18880308584890465d + "'", double6 == 0.18880308584890465d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 5 + "'", int9 == 5);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 63.876280742933d + "'", double15 == 63.876280742933d);
//    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        long long1 = org.apache.commons.math.util.FastMath.abs(51L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 51L + "'", long1 == 51L);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.17862484014276203d, (double) 20, 0.17412425486732214d);
        normalDistributionImpl3.reseedRandomGenerator((long) (byte) 0);
        java.lang.Class<?> wildcardClass6 = normalDistributionImpl3.getClass();
        double double7 = normalDistributionImpl3.getMean();
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.17862484014276203d + "'", double7 == 0.17862484014276203d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        double double1 = org.apache.commons.math.util.FastMath.tan(4.599102285891914d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.789367378137937d + "'", double1 == 8.789367378137937d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 100L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test347");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        int int12 = randomDataImpl1.nextZipf(100, 2.718281828459045d);
//        double double15 = randomDataImpl1.nextWeibull(1.6585234628482202d, 2.7973807818415874d);
//        java.lang.String str17 = randomDataImpl1.nextSecureHexString(9);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.6965899486378895d + "'", double4 == 7.6965899486378895d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.31421686642742E-6d + "'", double6 == 2.31421686642742E-6d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 6L + "'", long9 == 6L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.7364153635521007d + "'", double15 == 0.7364153635521007d);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "166c99109" + "'", str17.equals("166c99109"));
//    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 6.0d, (java.lang.Number) 8.054359047689252E13d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number12 = numberIsTooLargeException11.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray18);
        java.lang.Object[] objArray21 = new java.lang.Object[] { objArray18, "" };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException11, localizable13, objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("", objArray18);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("", objArray18);
        org.apache.commons.math.exception.util.Localizable localizable25 = mathException24.getGeneralPattern();
        java.lang.Number number26 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException(localizable25, number26, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray34 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray34);
        java.lang.String str36 = maxIterationsExceededException35.getPattern();
        java.lang.Object[] objArray37 = maxIterationsExceededException35.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable25, objArray37);
        org.apache.commons.math.exception.util.Localizable localizable39 = maxIterationsExceededException38.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException41 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.util.Localizable localizable42 = notStrictlyPositiveException41.getSpecificPattern();
        java.lang.Throwable[] throwableArray43 = notStrictlyPositiveException41.getSuppressed();
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException(localizable39, (java.lang.Object[]) throwableArray43);
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException51 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number52 = numberIsTooLargeException51.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        java.lang.Object[] objArray58 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException59 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray58);
        java.lang.Object[] objArray61 = new java.lang.Object[] { objArray58, "" };
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException51, localizable53, objArray58);
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException("", objArray58);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException64 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable46, objArray58);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable39, objArray58);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException69 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable39, (java.lang.Number) 11.144178405319577d, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException73 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable39, (java.lang.Number) 0.7013482902748387d, (java.lang.Number) 2.767576814789016d, true);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.0d) + "'", number12.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(localizable25);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(localizable39);
        org.junit.Assert.assertNull(localizable42);
        org.junit.Assert.assertNotNull(throwableArray43);
        org.junit.Assert.assertTrue("'" + number52 + "' != '" + (-1.0d) + "'", number52.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(objArray61);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.4906919352937438E-44d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4611002279344573E-15d + "'", double1 == 2.4611002279344573E-15d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 51, (long) 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test352");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        double double14 = randomDataImpl1.nextT(0.7627350637656639d);
//        double double17 = randomDataImpl1.nextCauchy(0.5061169493981285d, 5.853949697499888d);
//        java.lang.String str19 = randomDataImpl1.nextHexString((int) (byte) 10);
//        java.lang.String str21 = randomDataImpl1.nextHexString(6);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 5.831464026515749d + "'", double4 == 5.831464026515749d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.597891145431516d + "'", double6 == 1.597891145431516d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-0.3642222224092271d) + "'", double14 == (-0.3642222224092271d));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-4.571991760224941d) + "'", double17 == (-4.571991760224941d));
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "feb3fc860e" + "'", str19.equals("feb3fc860e"));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "398648" + "'", str21.equals("398648"));
//    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-2.9386644769927934d), (-0.7363591225007852d), 0.07773701167172087d, (int) ' ');
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-0.030885148884500332d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.030894974878699036d) + "'", double1 == (-0.030894974878699036d));
    }

//    @Test
//    public void test356() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test356");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeed();
//        try {
//            int int13 = randomDataImpl1.nextSecureInt((int) (byte) 10, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 10 is larger than, or equal to, the maximum (0): lower bound (10) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.9546385828552637d + "'", double4 == 3.9546385828552637d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.2528445246013342d + "'", double6 == 1.2528445246013342d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test357");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        long long7 = randomDataImpl1.nextLong((long) (byte) 10, (long) '4');
//        double double10 = randomDataImpl1.nextF(0.7400576788232446d, 0.8018974326990581d);
//        double double13 = randomDataImpl1.nextF((double) 100L, 0.13653950079971308d);
//        try {
//            double double15 = randomDataImpl1.nextChiSquare((-71.51554023463386d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -35.758 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.9895196167209237d + "'", double4 == 3.9895196167209237d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 32L + "'", long7 == 32L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.03621190298525537d + "'", double10 == 0.03621190298525537d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2934511.4875654215d + "'", double13 == 2934511.4875654215d);
//    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray4);
        java.lang.String str6 = maxIterationsExceededException5.getPattern();
        java.lang.String str7 = maxIterationsExceededException5.toString();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException5);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException5);
        org.apache.commons.math.exception.util.Localizable localizable10 = maxIterationsExceededException5.getGeneralPattern();
        int int11 = maxIterationsExceededException5.getMaxIterations();
        int int12 = maxIterationsExceededException5.getMaxIterations();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: hi!" + "'", str7.equals("org.apache.commons.math.MaxIterationsExceededException: hi!"));
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-1.9717386562014238E-5d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.971738656456945E-5d) + "'", double1 == (-1.971738656456945E-5d));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) (-0.17738444574517354d), true);
        java.lang.Throwable[] throwableArray5 = numberIsTooSmallException4.getSuppressed();
        java.lang.Number number6 = numberIsTooSmallException4.getArgument();
        java.lang.Number number7 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-0.17738444574517354d) + "'", number7.equals((-0.17738444574517354d)));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        double double1 = org.apache.commons.math.util.FastMath.log(0.8233617200173557d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.19435966086869458d) + "'", double1 == (-0.19435966086869458d));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.1185087377885383d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.43702424710619747d + "'", double1 == 0.43702424710619747d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        double double1 = org.apache.commons.math.util.FastMath.ceil(2.1143569690735338d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

//    @Test
//    public void test364() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test364");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT(4.599102285891914d);
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString((int) (byte) 100);
//        try {
//            int int8 = randomDataImpl1.nextPascal(3, 2.1143569690735338d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 2.114 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.09807133830094646d) + "'", double3 == (-0.09807133830094646d));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "546ca38d5cd2c5d82c34b4610b2c4a4f622625ea76cce968d2ed781da1ce86fb2f1c0aa23296ccf07d15a7514610f5dd4b85" + "'", str5.equals("546ca38d5cd2c5d82c34b4610b2c4a4f622625ea76cce968d2ed781da1ce86fb2f1c0aa23296ccf07d15a7514610f5dd4b85"));
//    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) 100, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException(localizable7, objArray8);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than, or equal to, the maximum (10)", objArray8);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException3, "org.apache.commons.math.MaxIterationsExceededException: hi!", objArray8);
        java.lang.Object[] objArray12 = numberIsTooSmallException3.getArguments();
        java.lang.String str13 = numberIsTooSmallException3.toString();
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (100)" + "'", str13.equals("org.apache.commons.math.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (100)"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 6.0d, (java.lang.Number) 8.054359047689252E13d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number12 = numberIsTooLargeException11.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray18);
        java.lang.Object[] objArray21 = new java.lang.Object[] { objArray18, "" };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException11, localizable13, objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("", objArray18);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("", objArray18);
        org.apache.commons.math.exception.util.Localizable localizable25 = mathException24.getGeneralPattern();
        java.lang.Number number26 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException(localizable25, number26, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray34 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray34);
        java.lang.String str36 = maxIterationsExceededException35.getPattern();
        java.lang.Object[] objArray37 = maxIterationsExceededException35.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable25, objArray37);
        org.apache.commons.math.exception.util.Localizable localizable39 = maxIterationsExceededException38.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException41 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.util.Localizable localizable42 = notStrictlyPositiveException41.getSpecificPattern();
        java.lang.Throwable[] throwableArray43 = notStrictlyPositiveException41.getSuppressed();
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException(localizable39, (java.lang.Object[]) throwableArray43);
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException51 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number52 = numberIsTooLargeException51.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        java.lang.Object[] objArray58 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException59 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray58);
        java.lang.Object[] objArray61 = new java.lang.Object[] { objArray58, "" };
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException51, localizable53, objArray58);
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException("", objArray58);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException64 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable46, objArray58);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable39, objArray58);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException69 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable39, (java.lang.Number) 11.144178405319577d, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException73 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable39, (java.lang.Number) (-28.36466158317452d), (java.lang.Number) 5.980855096195225d, false);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.0d) + "'", number12.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(localizable25);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(localizable39);
        org.junit.Assert.assertNull(localizable42);
        org.junit.Assert.assertNotNull(throwableArray43);
        org.junit.Assert.assertTrue("'" + number52 + "' != '" + (-1.0d) + "'", number52.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(objArray61);
    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test367");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        double double14 = randomDataImpl1.nextT(0.7627350637656639d);
//        double double17 = randomDataImpl1.nextCauchy(0.5061169493981285d, 5.853949697499888d);
//        java.lang.String str19 = randomDataImpl1.nextHexString((int) (byte) 10);
//        double double22 = randomDataImpl1.nextCauchy(1.6910147193352092d, 11.053536600647437d);
//        double double24 = randomDataImpl1.nextExponential(0.963500591395213d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.08339299561005564d) + "'", double4 == (-0.08339299561005564d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08060911610236147d + "'", double6 == 0.08060911610236147d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-6.18400460204425d) + "'", double14 == (-6.18400460204425d));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 2.457390865009636d + "'", double17 == 2.457390865009636d);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "65f9a1cd3a" + "'", str19.equals("65f9a1cd3a"));
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.525423840258284d + "'", double22 == 1.525423840258284d);
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.03781795956525914d + "'", double24 == 0.03781795956525914d);
//    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.9849186773131967d, (double) 12L, 0.0d, 20);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 5.858980780632441E-6d + "'", double4 == 5.858980780632441E-6d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-0.6376630821062105d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6376630821062104d) + "'", double1 == (-0.6376630821062104d));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 52);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        double double2 = org.apache.commons.math.util.FastMath.min(1.0E-9d, 0.17862484014276203d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-9d + "'", double2 == 1.0E-9d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number8 = numberIsTooLargeException7.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] { objArray14, "" };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException7, localizable9, objArray14);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray14);
        java.lang.Throwable[] throwableArray20 = mathIllegalArgumentException19.getSuppressed();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException24 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number25 = numberIsTooLargeException24.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray31);
        java.lang.Object[] objArray34 = new java.lang.Object[] { objArray31, "" };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException24, localizable26, objArray31);
        java.lang.Object[] objArray36 = numberIsTooLargeException24.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable37 = numberIsTooLargeException24.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException44 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number45 = numberIsTooLargeException44.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        java.lang.Object[] objArray51 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException52 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray51);
        java.lang.Object[] objArray54 = new java.lang.Object[] { objArray51, "" };
        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException44, localizable46, objArray51);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable40, objArray51);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException57 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', "", objArray51);
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalArgumentException19, localizable37, objArray51);
        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException(localizable1, objArray51);
        org.apache.commons.math.ConvergenceException convergenceException60 = new org.apache.commons.math.ConvergenceException("ebc5324e7636de08bc97416c7d4d1e15b12", objArray51);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (-1.0d) + "'", number8.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + (-1.0d) + "'", number25.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number45 + "' != '" + (-1.0d) + "'", number45.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(objArray54);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        double double1 = org.apache.commons.math.util.FastMath.asin((-2.0306813569944775d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        long long2 = org.apache.commons.math.util.FastMath.max(25L, (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.0d, 9.108754203495801d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable1, objArray8);
        org.apache.commons.math.exception.util.Localizable localizable12 = maxIterationsExceededException11.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNull(localizable12);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 28L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 28.0f + "'", float1 == 28.0f);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        double double1 = org.apache.commons.math.util.FastMath.ulp(12.808427727927521d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 5.858980780632441E-6d, (java.lang.Number) 0.01784408232461434d, (java.lang.Number) (-1.342872763603486d));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 18, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (short) -1, (java.lang.Number) 10L, true);
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        boolean boolean6 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.Number number7 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0d) + "'", number4.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 10.0f + "'", number7.equals(10.0f));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 0.033842170764600776d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        double double1 = org.apache.commons.math.util.FastMath.atan(5.298292365610485d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3842507050922375d + "'", double1 == 1.3842507050922375d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        java.lang.Object[] objArray6 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray6);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray6);
        java.lang.String str9 = maxIterationsExceededException8.getPattern();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.1472057710510555d, 1.9002507367077104d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.026233036129363015d + "'", double2 == 0.026233036129363015d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(7.672110364971767d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.13390358644514117d + "'", double1 == 0.13390358644514117d);
    }

//    @Test
//    public void test390() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test390");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.9379198162596534d, 0.8813735870195429d, 14.711890248661776d);
//        double double4 = normalDistributionImpl3.sample();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.7157676469196366d + "'", double4 == 2.7157676469196366d);
//    }

//    @Test
//    public void test391() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test391");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        randomDataImpl1.reSeed();
//        double double13 = randomDataImpl1.nextCauchy(5.853949697499888d, 0.006937366662896952d);
//        int int16 = randomDataImpl1.nextZipf(7, 0.6743305045039658d);
//        try {
//            double double18 = randomDataImpl1.nextT((-0.8296985723645218d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.83 is smaller than, or equal to, the minimum (0): degrees of freedom (-0.83)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.019154837551469d + "'", double4 == 4.019154837551469d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.31774144791489023d + "'", double6 == 0.31774144791489023d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2L + "'", long9 == 2L);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 5.8584950524555355d + "'", double13 == 5.8584950524555355d);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
//    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        double double1 = org.apache.commons.math.util.FastMath.exp((-5.933414952891249d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0026494188818717785d + "'", double1 == 0.0026494188818717785d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.8822534687891753d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9392834869139217d + "'", double1 == 0.9392834869139217d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        double double1 = org.apache.commons.math.util.FastMath.signum(12.801827480081467d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.05296404435055778d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9985977328511465d + "'", double1 == 0.9985977328511465d);
    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test396");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        randomDataImpl1.reSeed((-1L));
//        double double13 = randomDataImpl1.nextT(0.2857504987187536d);
//        long long16 = randomDataImpl1.nextSecureLong(3L, (long) 71);
//        randomDataImpl1.reSeed();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.9969672135048326d + "'", double4 == 3.9969672135048326d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.3784473551696945d + "'", double6 == 0.3784473551696945d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-2.5496180456051607d) + "'", double13 == (-2.5496180456051607d));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 37L + "'", long16 == 37L);
//    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 20, (double) 7.0f);
        double double4 = normalDistributionImpl2.density((double) 48L);
        double double7 = normalDistributionImpl2.cumulativeProbability(1.7387963814485965d, (double) 4);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.911860368069791E-5d + "'", double4 == 1.911860368069791E-5d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.006591721237249548d + "'", double7 == 0.006591721237249548d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        double double1 = org.apache.commons.math.util.FastMath.cosh(11.203302383478558d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 36686.17290996581d + "'", double1 == 36686.17290996581d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        int int2 = org.apache.commons.math.util.FastMath.max((int) '#', 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

//    @Test
//    public void test400() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test400");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) (byte) 1);
//        double double5 = randomDataImpl1.nextT((double) 8);
//        randomDataImpl1.reSeed();
//        double double9 = randomDataImpl1.nextUniform(0.15385541444224388d, 0.2265225441315423d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.6199701620746297d + "'", double3 == 0.6199701620746297d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5038520072893607d + "'", double5 == 0.5038520072893607d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2030193928571542d + "'", double9 == 0.2030193928571542d);
//    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        float float1 = org.apache.commons.math.util.FastMath.abs((-1.0f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        double double2 = org.apache.commons.math.util.FastMath.max(0.004343531641415982d, 0.011244646561846934d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.011244646561846934d + "'", double2 == 0.011244646561846934d);
    }

//    @Test
//    public void test403() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test403");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        double double14 = randomDataImpl1.nextT(0.7627350637656639d);
//        double double17 = randomDataImpl1.nextCauchy(0.5061169493981285d, 5.853949697499888d);
//        java.lang.String str19 = randomDataImpl1.nextHexString((int) (byte) 10);
//        double double22 = randomDataImpl1.nextCauchy(1.6910147193352092d, 11.053536600647437d);
//        try {
//            double double24 = randomDataImpl1.nextT((-32.546918474539034d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -32.547 is smaller than, or equal to, the minimum (0): degrees of freedom (-32.547)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.451573536841046d + "'", double4 == 2.451573536841046d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.008144064698884465d + "'", double6 == 0.008144064698884465d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 5 + "'", int9 == 5);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-10.592061688128982d) + "'", double14 == (-10.592061688128982d));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 98.28817662607761d + "'", double17 == 98.28817662607761d);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1a37164138" + "'", str19.equals("1a37164138"));
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 22.480814999024773d + "'", double22 == 22.480814999024773d);
//    }

//    @Test
//    public void test404() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test404");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) (byte) 1);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double6 = normalDistributionImpl4.density(100.0d);
//        double double7 = normalDistributionImpl4.getStandardDeviation();
//        double double8 = normalDistributionImpl4.sample();
//        double double10 = normalDistributionImpl4.cumulativeProbability((double) (byte) 10);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        randomDataImpl1.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3831016828731771d + "'", double3 == 0.3831016828731771d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.306616964198211d + "'", double8 == 1.306616964198211d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.30511797471507235d + "'", double11 == 0.30511797471507235d);
//    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        double double1 = org.apache.commons.math.util.FastMath.asin((-1.971738656456945E-5d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.9717386565847056E-5d) + "'", double1 == (-1.9717386565847056E-5d));
    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test406");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        int int14 = randomDataImpl1.nextZipf(15, 0.18779231121495946d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.7657348532650357d + "'", double4 == 2.7657348532650357d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.3578861807931399d + "'", double6 == 0.3578861807931399d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//    }

//    @Test
//    public void test407() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test407");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        java.lang.String str11 = randomDataImpl1.nextHexString((int) '#');
//        int int14 = randomDataImpl1.nextZipf(20, 0.5772156649015329d);
//        double double17 = randomDataImpl1.nextUniform(0.0d, 1.5891306489769716d);
//        try {
//            double double20 = randomDataImpl1.nextUniform(0.0d, (-0.015722159129280943d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (-0.016): lower bound (0) must be strictly less than upper bound (-0.016)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.6521956527954895d + "'", double4 == 2.6521956527954895d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.46614927053267785d + "'", double6 == 0.46614927053267785d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "d379f5d015c82bef75f40d052ce830476e0" + "'", str11.equals("d379f5d015c82bef75f40d052ce830476e0"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.09763671592952299d + "'", double17 == 0.09763671592952299d);
//    }

//    @Test
//    public void test408() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test408");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        long long3 = randomDataImpl1.nextPoisson((double) 10L);
//        randomDataImpl1.reSeedSecure();
//        int[] intArray7 = randomDataImpl1.nextPermutation((int) 'a', 9);
//        int int10 = randomDataImpl1.nextBinomial((int) '4', 0.0d);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 14L + "'", long3 == 14L);
//        org.junit.Assert.assertNotNull(intArray7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-1.0764993907272205d), (-2.374845165237864d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.7160040968772954d) + "'", double2 == (-2.7160040968772954d));
    }

//    @Test
//    public void test410() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test410");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        double double14 = randomDataImpl1.nextT(0.7627350637656639d);
//        double double17 = randomDataImpl1.nextWeibull(0.9060765469822909d, 1.417895747432709d);
//        try {
//            randomDataImpl1.setSecureAlgorithm("feb3fc860e", "b0b856f991");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: b0b856f991");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 15.474506466147291d + "'", double4 == 15.474506466147291d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.13029237036654867d + "'", double6 == 0.13029237036654867d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0239607678451303d + "'", double14 == 1.0239607678451303d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0219037111856273d + "'", double17 == 1.0219037111856273d);
//    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number7 = numberIsTooLargeException6.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray13);
        java.lang.Object[] objArray16 = new java.lang.Object[] { objArray13, "" };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException6, localizable8, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("", objArray13);
        org.apache.commons.math.exception.util.Localizable localizable20 = mathException19.getGeneralPattern();
        java.lang.Number number21 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException(localizable20, number21, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray29 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray29);
        java.lang.String str31 = maxIterationsExceededException30.getPattern();
        java.lang.Object[] objArray32 = maxIterationsExceededException30.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable20, objArray32);
        java.lang.Object[] objArray34 = null;
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException(localizable20, objArray34);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException39 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable20, (java.lang.Number) 5.687571051624795d, (java.lang.Number) 1.5269469083754401d, false);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1.0d) + "'", number7.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray32);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        long long2 = org.apache.commons.math.util.FastMath.max(4L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((-57.29577951308232d), 0.24490950872371273d, 0.02398007912785791d, 8);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        double double1 = org.apache.commons.math.util.FastMath.tanh(2.457390865009636d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9854322497656478d + "'", double1 == 0.9854322497656478d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.4010084694877367d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test416() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test416");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        randomDataImpl1.reSeed();
//        int int13 = randomDataImpl1.nextSecureInt(3, 6);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.647278870347662d + "'", double4 == 10.647278870347662d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 5.996405150608687E-4d + "'", double6 == 5.996405150608687E-4d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 6L + "'", long9 == 6L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
//    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        int int2 = org.apache.commons.math.util.FastMath.min((int) '#', 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.4029534486805868E-257d, (java.lang.Number) 7.612228815478475d, true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException3.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number6 = numberIsTooLargeException5.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray12);
        java.lang.Object[] objArray15 = new java.lang.Object[] { objArray12, "" };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException5, localizable7, objArray12);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("", objArray12);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("", objArray12);
        org.apache.commons.math.exception.util.Localizable localizable19 = mathException18.getGeneralPattern();
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException(localizable19, number20, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Number number24 = outOfRangeException23.getLo();
        java.lang.Number number25 = outOfRangeException23.getArgument();
        java.lang.Number number26 = outOfRangeException23.getHi();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1.0d) + "'", number6.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (byte) 0 + "'", number24.equals((byte) 0));
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + (-0.04527605728197682d) + "'", number26.equals((-0.04527605728197682d)));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray4);
        java.lang.String str6 = maxIterationsExceededException5.getPattern();
        java.lang.String str7 = maxIterationsExceededException5.toString();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException5);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException5);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException(localizable12, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("5fa2692c956e6b17b0ae0645ae88e67a635", objArray13);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException9, "hi!", objArray13);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: hi!" + "'", str7.equals("org.apache.commons.math.MaxIterationsExceededException: hi!"));
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-0.8592237687095796d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray7);
        java.lang.String str9 = maxIterationsExceededException8.getPattern();
        java.lang.String str10 = maxIterationsExceededException8.toString();
        java.lang.Object[] objArray11 = maxIterationsExceededException8.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, localizable2, objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray11);
        java.lang.Class<?> wildcardClass14 = mathIllegalArgumentException13.getClass();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: hi!" + "'", str10.equals("org.apache.commons.math.MaxIterationsExceededException: hi!"));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

//    @Test
//    public void test423() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test423");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        randomDataImpl1.reSeed();
//        double double9 = randomDataImpl1.nextT(1.658714676597928d);
//        randomDataImpl1.reSeed(10L);
//        int int14 = randomDataImpl1.nextPascal((int) (short) 100, 0.0d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.23325916900923d + "'", double4 == 8.23325916900923d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.1125277267452628d + "'", double6 == 0.1125277267452628d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.2436118014689093d + "'", double9 == 1.2436118014689093d);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2147483647 + "'", int14 == 2147483647);
//    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        double double1 = org.apache.commons.math.util.FastMath.sin((-2.594126995249829d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5205249642512952d) + "'", double1 == (-0.5205249642512952d));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 6.0d, (java.lang.Number) 8.054359047689252E13d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number12 = numberIsTooLargeException11.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray18);
        java.lang.Object[] objArray21 = new java.lang.Object[] { objArray18, "" };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException11, localizable13, objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("", objArray18);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("", objArray18);
        org.apache.commons.math.exception.util.Localizable localizable25 = mathException24.getGeneralPattern();
        java.lang.Number number26 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException(localizable25, number26, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray34 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray34);
        java.lang.String str36 = maxIterationsExceededException35.getPattern();
        java.lang.Object[] objArray37 = maxIterationsExceededException35.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable25, objArray37);
        org.apache.commons.math.exception.util.Localizable localizable39 = maxIterationsExceededException38.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException41 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.util.Localizable localizable42 = notStrictlyPositiveException41.getSpecificPattern();
        java.lang.Throwable[] throwableArray43 = notStrictlyPositiveException41.getSuppressed();
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException(localizable39, (java.lang.Object[]) throwableArray43);
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException51 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number52 = numberIsTooLargeException51.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        java.lang.Object[] objArray58 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException59 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray58);
        java.lang.Object[] objArray61 = new java.lang.Object[] { objArray58, "" };
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException51, localizable53, objArray58);
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException("", objArray58);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException64 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable46, objArray58);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable39, objArray58);
        java.lang.Number number66 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException69 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, number66, (java.lang.Number) 12.801827480081469d, false);
        org.apache.commons.math.exception.util.Localizable localizable70 = null;
        java.lang.Number number71 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException74 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable70, number71, (java.lang.Number) (-0.17738444574517354d), true);
        java.lang.Throwable[] throwableArray75 = numberIsTooSmallException74.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException76 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, (java.lang.Object[]) throwableArray75);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException78 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 4.440892098500626E-16d);
        java.lang.Number number79 = null;
        java.lang.Number number80 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException82 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, number79, number80, true);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.0d) + "'", number12.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(localizable25);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(localizable39);
        org.junit.Assert.assertNull(localizable42);
        org.junit.Assert.assertNotNull(throwableArray43);
        org.junit.Assert.assertTrue("'" + number52 + "' != '" + (-1.0d) + "'", number52.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(throwableArray75);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.7602901140155076d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.951003803753234d + "'", double1 == 0.951003803753234d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 26L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.95087369077445d + "'", double1 == 3.95087369077445d);
    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test428");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT(4.599102285891914d);
//        double double6 = randomDataImpl1.nextGaussian(1.1142547833872074E-7d, 0.02398007912785791d);
//        try {
//            int int9 = randomDataImpl1.nextBinomial((int) (byte) 10, (-2.0d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -2 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.8497877628552561d + "'", double3 == 0.8497877628552561d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05143639678295984d + "'", double6 == 0.05143639678295984d);
//    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) '#');
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        double double1 = org.apache.commons.math.special.Erf.erf(0.9985977328511465d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8421178847136367d + "'", double1 == 0.8421178847136367d);
    }

//    @Test
//    public void test431() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test431");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl0.density(100.0d);
//        double double3 = normalDistributionImpl0.getStandardDeviation();
//        double double4 = normalDistributionImpl0.getStandardDeviation();
//        double double5 = normalDistributionImpl0.sample();
//        double double6 = normalDistributionImpl0.sample();
//        double double8 = normalDistributionImpl0.density(0.42110981177513296d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.155359128483252d + "'", double5 == 1.155359128483252d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-0.5435098583439938d) + "'", double6 == (-0.5435098583439938d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.36509223087486414d + "'", double8 == 0.36509223087486414d);
//    }

//    @Test
//    public void test432() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test432");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        int int12 = randomDataImpl1.nextZipf(100, 2.718281828459045d);
//        double double15 = randomDataImpl1.nextWeibull(1.6585234628482202d, 2.7973807818415874d);
//        java.lang.String str17 = randomDataImpl1.nextHexString(7);
//        double double20 = randomDataImpl1.nextWeibull(2.3204576652020874d, 0.8932953783196218d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.205576982948105d + "'", double4 == 7.205576982948105d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.1781038552708916d + "'", double6 == 0.1781038552708916d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9L + "'", long9 == 9L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.9422604863357836d + "'", double15 == 0.9422604863357836d);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "38eb270" + "'", str17.equals("38eb270"));
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.7110981025154166d + "'", double20 == 0.7110981025154166d);
//    }

//    @Test
//    public void test433() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test433");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT(4.599102285891914d);
//        int int6 = randomDataImpl1.nextZipf(7, 0.22613396021060134d);
//        java.lang.String str8 = randomDataImpl1.nextSecureHexString(7);
//        try {
//            java.lang.String str10 = randomDataImpl1.nextSecureHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.9155306674675575d + "'", double3 == 0.9155306674675575d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "f894b8b" + "'", str8.equals("f894b8b"));
//    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.41196668789851953d), (java.lang.Number) 0.04723013714999615d, true);
    }

//    @Test
//    public void test435() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test435");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        long long4 = randomDataImpl0.nextSecureLong((long) (byte) -1, 100L);
//        try {
//            int int7 = randomDataImpl0.nextBinomial(18, 117.18421228326486d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 117.184 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 60L + "'", long4 == 60L);
//    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 0.006591721237249548d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.006591721237249548d + "'", double2 == 0.006591721237249548d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(1.3648835453131154d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.061249650831671d + "'", double1 == 1.061249650831671d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.5772903499365252d, (-0.8390715290764524d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5856497060149108d + "'", double2 == 1.5856497060149108d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 155.74607629780772d, (java.lang.Number) 1.333707301036022d);
        java.lang.Number number4 = outOfRangeException3.getLo();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 155.74607629780772d + "'", number4.equals(155.74607629780772d));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(2.31421686642742E-6d, 0.07773701167172087d, (-0.27080570870314047d), 5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (5) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        double double1 = org.apache.commons.math.util.FastMath.sinh(37.92811310393632d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4823140818190054E16d + "'", double1 == 1.4823140818190054E16d);
    }

//    @Test
//    public void test442() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test442");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        int int12 = randomDataImpl1.nextZipf(100, 2.718281828459045d);
//        double double15 = randomDataImpl1.nextCauchy(2.092790987315211d, 0.8813735870195429d);
//        double double18 = randomDataImpl1.nextGaussian((double) 10.0f, (double) 8);
//        double double21 = randomDataImpl1.nextGaussian(0.04723013714999615d, (double) 47L);
//        randomDataImpl1.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 520.0226107645648d + "'", double4 == 520.0226107645648d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0049655341270195205d + "'", double6 == 0.0049655341270195205d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 31.71985519732817d + "'", double15 == 31.71985519732817d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 4.00086995955156d + "'", double18 == 4.00086995955156d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 40.546712601070816d + "'", double21 == 40.546712601070816d);
//    }

//    @Test
//    public void test443() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test443");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double1 = normalDistributionImpl0.sample();
//        double double3 = normalDistributionImpl0.cumulativeProbability(2.767576814789016d);
//        double double4 = normalDistributionImpl0.sample();
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.040706524570184074d + "'", double1 == 0.040706524570184074d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.9971762632543613d + "'", double3 == 0.9971762632543613d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5615782357164754d + "'", double4 == 0.5615782357164754d);
//    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray10);
        java.lang.Object[] objArray13 = new java.lang.Object[] { objArray10, "" };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3, localizable5, objArray10);
        java.lang.Object[] objArray15 = numberIsTooLargeException3.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooLargeException3.getGeneralPattern();
        java.lang.Object[] objArray22 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray22);
        java.lang.String str24 = maxIterationsExceededException23.getPattern();
        java.lang.String str25 = maxIterationsExceededException23.toString();
        int int26 = maxIterationsExceededException23.getMaxIterations();
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException39 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray38);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException40 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray38);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException41 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable31, objArray38);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException("", objArray38);
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.MaxIterationsExceededException: ", objArray38);
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException23, localizable27, objArray38);
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.MaxIterationsExceededException: ", objArray38);
        java.lang.Object[] objArray46 = convergenceException45.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException(localizable16, objArray46);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0d) + "'", number4.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: hi!" + "'", str25.equals("org.apache.commons.math.MaxIterationsExceededException: hi!"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray46);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(3.608826080138695d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.31898453917772873d + "'", double1 == 0.31898453917772873d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.361562941897067d);
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException1);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number6 = numberIsTooLargeException5.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray12);
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException5, localizable7, objArray12);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(throwable0, "b0b856f991", objArray12);
        java.lang.Object[] objArray16 = convergenceException15.getArguments();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1.0d) + "'", number6.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray16);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number7 = numberIsTooLargeException6.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray13);
        java.lang.Object[] objArray16 = new java.lang.Object[] { objArray13, "" };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException6, localizable8, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("", objArray13);
        org.apache.commons.math.exception.util.Localizable localizable20 = mathException19.getGeneralPattern();
        java.lang.Number number21 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException(localizable20, number21, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray29 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray29);
        java.lang.String str31 = maxIterationsExceededException30.getPattern();
        java.lang.Object[] objArray32 = maxIterationsExceededException30.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable20, objArray32);
        org.apache.commons.math.exception.util.Localizable localizable34 = maxIterationsExceededException33.getGeneralPattern();
        int int35 = maxIterationsExceededException33.getMaxIterations();
        int int36 = maxIterationsExceededException33.getMaxIterations();
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1.0d) + "'", number7.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(localizable34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 97 + "'", int35 == 97);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 97 + "'", int36 == 97);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) (-5.998713782709511d), (java.lang.Number) 0.7602901140155076d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.7753313617011479d, 13.49667076149997d, (-0.10908581510341842d), (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: Continued fraction convergents failed to converge (in less than 13.497 iterations) for value {1}");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        double double1 = org.apache.commons.math.special.Gamma.digamma((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

//    @Test
//    public void test452() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test452");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        randomDataImpl1.reSeed();
//        double double13 = randomDataImpl1.nextGaussian((-0.5418080117554591d), 0.4999921339008419d);
//        long long15 = randomDataImpl1.nextPoisson(0.015413343812216955d);
//        double double18 = randomDataImpl1.nextWeibull(0.1496495520142893d, (double) 3L);
//        double double21 = randomDataImpl1.nextGaussian(0.0011391256666861732d, 2.498447650589192E15d);
//        double double24 = randomDataImpl1.nextBeta(1.5544043524868913d, 155.74607629780772d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 33.67462624659425d + "'", double4 == 33.67462624659425d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0064208567910001456d + "'", double6 == 0.0064208567910001456d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9L + "'", long9 == 9L);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.8444273009864975d) + "'", double13 == (-1.8444273009864975d));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.29562583896000183d + "'", double18 == 0.29562583896000183d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-3.1190387033979644E14d) + "'", double21 == (-3.1190387033979644E14d));
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0239126793936969d + "'", double24 == 0.0239126793936969d);
//    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException(97, "org.apache.commons.math.MaxIterationsExceededException: hi!", objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = maxIterationsExceededException3.getGeneralPattern();
        org.junit.Assert.assertNotNull(localizable4);
    }

//    @Test
//    public void test454() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test454");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        long long7 = randomDataImpl1.nextLong((long) (byte) 10, (long) '4');
//        double double10 = randomDataImpl1.nextBeta(1.471127674303735d, 1.1185087377885383d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double13 = normalDistributionImpl11.density(100.0d);
//        double double14 = normalDistributionImpl11.getStandardDeviation();
//        double double15 = normalDistributionImpl11.sample();
//        double double17 = normalDistributionImpl11.cumulativeProbability((double) (byte) 10);
//        double[] doubleArray19 = normalDistributionImpl11.sample((int) (byte) 100);
//        double double20 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        double double23 = randomDataImpl1.nextF(0.01125018911575255d, 0.15485502616272392d);
//        try {
//            double double26 = randomDataImpl1.nextGamma((-0.43364064491300164d), 0.8266908339278949d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.434 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.843386092727826d + "'", double4 == 8.843386092727826d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 17L + "'", long7 == 17L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.32157195667741d + "'", double10 == 0.32157195667741d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0432377873505272d + "'", double15 == 1.0432377873505272d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
//        org.junit.Assert.assertNotNull(doubleArray19);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.2393658516074164d + "'", double20 == 1.2393658516074164d);
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
//    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 38L, 1.3984169833165265d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 161.8811241036179d + "'", double2 == 161.8811241036179d);
    }

//    @Test
//    public void test456() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test456");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        long long3 = randomDataImpl1.nextPoisson((double) 10L);
//        randomDataImpl1.reSeedSecure();
//        int[] intArray7 = randomDataImpl1.nextPermutation((int) 'a', 9);
//        randomDataImpl1.reSeedSecure((long) ' ');
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 12L + "'", long3 == 12L);
//        org.junit.Assert.assertNotNull(intArray7);
//    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 6.0d, (java.lang.Number) 8.054359047689252E13d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number12 = numberIsTooLargeException11.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray18);
        java.lang.Object[] objArray21 = new java.lang.Object[] { objArray18, "" };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException11, localizable13, objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("", objArray18);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("", objArray18);
        org.apache.commons.math.exception.util.Localizable localizable25 = mathException24.getGeneralPattern();
        java.lang.Number number26 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException(localizable25, number26, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray34 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray34);
        java.lang.String str36 = maxIterationsExceededException35.getPattern();
        java.lang.Object[] objArray37 = maxIterationsExceededException35.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable25, objArray37);
        org.apache.commons.math.exception.util.Localizable localizable39 = maxIterationsExceededException38.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException41 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.util.Localizable localizable42 = notStrictlyPositiveException41.getSpecificPattern();
        java.lang.Throwable[] throwableArray43 = notStrictlyPositiveException41.getSuppressed();
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException(localizable39, (java.lang.Object[]) throwableArray43);
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException51 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number52 = numberIsTooLargeException51.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        java.lang.Object[] objArray58 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException59 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray58);
        java.lang.Object[] objArray61 = new java.lang.Object[] { objArray58, "" };
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException51, localizable53, objArray58);
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException("", objArray58);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException64 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable46, objArray58);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable39, objArray58);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException69 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable39, (java.lang.Number) 11.144178405319577d, (java.lang.Number) (short) 0, false);
        java.lang.Number number70 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException73 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable39, number70, (java.lang.Number) (-0.8592237687095796d), false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException75 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable39, (java.lang.Number) 1.448271094386676d);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.0d) + "'", number12.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(localizable25);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(localizable39);
        org.junit.Assert.assertNull(localizable42);
        org.junit.Assert.assertNotNull(throwableArray43);
        org.junit.Assert.assertTrue("'" + number52 + "' != '" + (-1.0d) + "'", number52.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(objArray61);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        double double1 = org.apache.commons.math.util.FastMath.ulp(2.526299952429221d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(2.6384742796497194d, 0.1637803215194881d);
    }

//    @Test
//    public void test461() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test461");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeed((long) (short) 0);
//        randomDataImpl1.reSeedSecure();
//        java.lang.String str17 = randomDataImpl1.nextHexString(51);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.876043452039948d + "'", double4 == 4.876043452039948d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.04301528842622451d + "'", double6 == 0.04301528842622451d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "e034a03bb8d15954fa4b13bd3ef0b91b7649ad23ba709dcf37f" + "'", str17.equals("e034a03bb8d15954fa4b13bd3ef0b91b7649ad23ba709dcf37f"));
//    }

//    @Test
//    public void test462() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test462");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        randomDataImpl1.reSeed();
//        double double9 = randomDataImpl1.nextT(1.658714676597928d);
//        randomDataImpl1.reSeed(10L);
//        double double14 = randomDataImpl1.nextF(1.0419432903052384d, 1.1308564921585762d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.7687887098432915d + "'", double4 == 4.7687887098432915d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.3981985353725279d + "'", double6 == 0.3981985353725279d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.7111606265020615d + "'", double9 == 0.7111606265020615d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.153020698914413d + "'", double14 == 4.153020698914413d);
//    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 0.9422604863357836d, (java.lang.Number) (byte) 100, false);
    }

//    @Test
//    public void test464() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test464");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        long long3 = randomDataImpl1.nextPoisson((double) 10L);
//        double double5 = randomDataImpl1.nextExponential(0.7753313617011479d);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 15L + "'", long3 == 15L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.9947574906146563d + "'", double5 == 0.9947574906146563d);
//    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 5);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 5L + "'", long1 == 5L);
    }

//    @Test
//    public void test466() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test466");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        long long7 = randomDataImpl1.nextLong((long) (byte) 10, (long) '4');
//        double double10 = randomDataImpl1.nextBeta(1.471127674303735d, 1.1185087377885383d);
//        randomDataImpl1.reSeed((long) '4');
//        long long14 = randomDataImpl1.nextPoisson(1.2598590199387094d);
//        double double17 = randomDataImpl1.nextWeibull(0.5101135482240943d, 102.41106683260354d);
//        try {
//            int int20 = randomDataImpl1.nextPascal((int) (byte) 10, 7.094610098537221d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 7.095 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.672400839218557d + "'", double4 == 4.672400839218557d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 14L + "'", long7 == 14L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.4186726072217086d + "'", double10 == 0.4186726072217086d);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2L + "'", long14 == 2L);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 5.179454339469011d + "'", double17 == 5.179454339469011d);
//    }

//    @Test
//    public void test467() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test467");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        randomDataImpl1.reSeed();
//        double double13 = randomDataImpl1.nextCauchy(5.853949697499888d, 0.006937366662896952d);
//        int int16 = randomDataImpl1.nextZipf(7, 0.6743305045039658d);
//        long long19 = randomDataImpl1.nextLong(0L, 51L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 5.058929815755315d + "'", double4 == 5.058929815755315d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.32470692108908944d + "'", double6 == 0.32470692108908944d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 5L + "'", long9 == 5L);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 5.860060723059558d + "'", double13 == 5.860060723059558d);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 4L + "'", long19 == 4L);
//    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.31773538375817445d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2474561819614542d + "'", double1 == 1.2474561819614542d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray4);
        java.lang.String str6 = maxIterationsExceededException5.getPattern();
        java.lang.String str7 = maxIterationsExceededException5.toString();
        java.lang.Object[] objArray8 = maxIterationsExceededException5.getArguments();
        int int9 = maxIterationsExceededException5.getMaxIterations();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: hi!" + "'", str7.equals("org.apache.commons.math.MaxIterationsExceededException: hi!"));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

//    @Test
//    public void test470() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test470");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.4711276743037347d, (double) 1L);
//        double double3 = normalDistributionImpl2.sample();
//        double double5 = normalDistributionImpl2.inverseCumulativeProbability(0.0d);
//        try {
//            double double7 = normalDistributionImpl2.inverseCumulativeProbability((-54.84552985815836d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -54.846 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.59666619161129d + "'", double3 == 2.59666619161129d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.NEGATIVE_INFINITY + "'", double5 == Double.NEGATIVE_INFINITY);
//    }

//    @Test
//    public void test471() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test471");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        double double14 = randomDataImpl1.nextT(0.7627350637656639d);
//        double double17 = randomDataImpl1.nextWeibull(0.9060765469822909d, 1.417895747432709d);
//        try {
//            int int21 = randomDataImpl1.nextHypergeometric(0, 10, (int) 'a');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): population size (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.898237621988658d + "'", double4 == 4.898237621988658d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.3922091457271538d + "'", double6 == 0.3922091457271538d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.4130412582963805d + "'", double14 == 2.4130412582963805d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.405314002930103d + "'", double17 == 0.405314002930103d);
//    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, number2, (java.lang.Number) (-0.17738444574517354d), true);
        java.lang.Throwable[] throwableArray6 = numberIsTooSmallException5.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException(localizable0, (java.lang.Object[]) throwableArray6);
        java.lang.Object[] objArray8 = convergenceException7.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0);
        java.lang.String str11 = maxIterationsExceededException10.getPattern();
        java.lang.String str12 = maxIterationsExceededException10.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = maxIterationsExceededException10.getGeneralPattern();
        java.lang.Number number15 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException(number15, (java.lang.Number) 100, false);
        org.apache.commons.math.exception.util.Localizable localizable19 = numberIsTooSmallException18.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        java.lang.Object[] objArray23 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException(localizable22, objArray23);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than, or equal to, the maximum (10)", objArray23);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException18, "org.apache.commons.math.MaxIterationsExceededException: hi!", objArray23);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.MathException: hi!", objArray23);
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException7, localizable13, objArray23);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "maximal number of iterations ({0}) exceeded" + "'", str11.equals("maximal number of iterations ({0}) exceeded"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "maximal number of iterations ({0}) exceeded" + "'", str12.equals("maximal number of iterations ({0}) exceeded"));
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED));
        org.junit.Assert.assertNull(localizable19);
        org.junit.Assert.assertNotNull(objArray23);
    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test473");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT(4.599102285891914d);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure();
//        int int9 = randomDataImpl1.nextHypergeometric(100, 71, (int) (byte) 1);
//        randomDataImpl1.reSeedSecure();
//        try {
//            int int13 = randomDataImpl1.nextInt((int) (byte) 100, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (0): lower bound (100) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.44347232106516704d + "'", double3 == 0.44347232106516704d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.4711276743037347d, (double) 1L);
        double double3 = normalDistributionImpl2.getStandardDeviation();
        double double5 = normalDistributionImpl2.density(2.220446049250313E-16d);
        double[] doubleArray7 = normalDistributionImpl2.sample(32);
        normalDistributionImpl2.reseedRandomGenerator((long) 32);
        normalDistributionImpl2.reseedRandomGenerator(5L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.13519368159152453d + "'", double5 == 0.13519368159152453d);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

//    @Test
//    public void test475() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test475");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        int int12 = randomDataImpl1.nextZipf(100, 2.718281828459045d);
//        try {
//            int int16 = randomDataImpl1.nextHypergeometric((int) (short) 1, (int) (short) -1, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of successes (-1)");
//        } catch (org.apache.commons.math.exception.NotPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.5164552679232135d + "'", double4 == 3.5164552679232135d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.23380115990853742d + "'", double6 == 0.23380115990853742d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(2.7973807818415874d, (double) (short) 100, (double) 9L);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.735694058833187d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9027463676025067d + "'", double1 == 0.9027463676025067d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 10, (-0.6489388448852297d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.22441979179397292d + "'", double2 == 0.22441979179397292d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException2 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray1);
        java.lang.Class<?> wildcardClass3 = mathIllegalArgumentException2.getClass();
        org.apache.commons.math.exception.util.Localizable localizable4 = mathIllegalArgumentException2.getSpecificPattern();
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException(97, "org.apache.commons.math.MaxIterationsExceededException: hi!", objArray8);
        java.lang.Object[] objArray10 = maxIterationsExceededException9.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalArgumentException2, "", objArray10);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertNotNull(objArray10);
    }

//    @Test
//    public void test480() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test480");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl0.density(100.0d);
//        double double3 = normalDistributionImpl0.getStandardDeviation();
//        double double4 = normalDistributionImpl0.sample();
//        double double6 = normalDistributionImpl0.cumulativeProbability((double) (byte) 10);
//        double double7 = normalDistributionImpl0.getMean();
//        double double8 = normalDistributionImpl0.sample();
//        double double10 = normalDistributionImpl0.density(1.4536846156063157d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.1037672924853952d + "'", double4 == 1.1037672924853952d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.1863633411256682d) + "'", double8 == (-1.1863633411256682d));
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.13868667678942026d + "'", double10 == 0.13868667678942026d);
//    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        double double1 = org.apache.commons.math.util.FastMath.rint((-0.8592237687095796d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.2944340832285237d, 0.7718551054848756d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.11634512269058972d + "'", double2 == 0.11634512269058972d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.2598590199387094d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7061512504504489d + "'", double1 == 0.7061512504504489d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100.0f, (java.lang.Number) 10.0f, false);
        java.lang.Object[] objArray9 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray9);
        java.lang.String str11 = maxIterationsExceededException10.getPattern();
        java.lang.String str12 = maxIterationsExceededException10.toString();
        java.lang.Object[] objArray13 = maxIterationsExceededException10.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException3, "b0b856f991", objArray13);
        org.apache.commons.math.exception.util.Localizable localizable15 = numberIsTooSmallException3.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: hi!" + "'", str12.equals("org.apache.commons.math.MaxIterationsExceededException: hi!"));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNull(localizable15);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        long long1 = org.apache.commons.math.util.FastMath.round(0.7627350637656639d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException3.getSpecificPattern();
        java.lang.Throwable[] throwableArray5 = notStrictlyPositiveException3.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException(10, "", (java.lang.Object[]) throwableArray5);
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException6, "398648", objArray8);
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 4.7945692163463445d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.442649094209893d, 0.4999921339008419d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray10);
        java.lang.Object[] objArray13 = new java.lang.Object[] { objArray10, "" };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3, localizable5, objArray10);
        java.lang.Object[] objArray15 = numberIsTooLargeException3.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException20 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable16, (java.lang.Number) 0.660029220515412d, (java.lang.Number) 18.656699191319486d, false);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0d) + "'", number4.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 6.0d, (java.lang.Number) 8.054359047689252E13d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number12 = numberIsTooLargeException11.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray18);
        java.lang.Object[] objArray21 = new java.lang.Object[] { objArray18, "" };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException11, localizable13, objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("", objArray18);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("", objArray18);
        org.apache.commons.math.exception.util.Localizable localizable25 = mathException24.getGeneralPattern();
        java.lang.Number number26 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException(localizable25, number26, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray34 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray34);
        java.lang.String str36 = maxIterationsExceededException35.getPattern();
        java.lang.Object[] objArray37 = maxIterationsExceededException35.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable25, objArray37);
        org.apache.commons.math.exception.util.Localizable localizable39 = maxIterationsExceededException38.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException41 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.util.Localizable localizable42 = notStrictlyPositiveException41.getSpecificPattern();
        java.lang.Throwable[] throwableArray43 = notStrictlyPositiveException41.getSuppressed();
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException(localizable39, (java.lang.Object[]) throwableArray43);
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException51 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number52 = numberIsTooLargeException51.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        java.lang.Object[] objArray58 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException59 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray58);
        java.lang.Object[] objArray61 = new java.lang.Object[] { objArray58, "" };
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException51, localizable53, objArray58);
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException("", objArray58);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException64 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable46, objArray58);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable39, objArray58);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException69 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable39, (java.lang.Number) 11.144178405319577d, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException73 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable39, (java.lang.Number) 26.983826832980125d, (java.lang.Number) 0.7718551054848756d, false);
        org.apache.commons.math.exception.util.Localizable localizable75 = null;
        java.lang.Object[] objArray82 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException83 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray82);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException84 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray82);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException85 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable75, objArray82);
        org.apache.commons.math.MathException mathException86 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException85);
        java.lang.Object[] objArray87 = mathException86.getArguments();
        org.apache.commons.math.MathException mathException88 = new org.apache.commons.math.MathException(localizable39, objArray87);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.0d) + "'", number12.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(localizable25);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(localizable39);
        org.junit.Assert.assertNull(localizable42);
        org.junit.Assert.assertNotNull(throwableArray43);
        org.junit.Assert.assertTrue("'" + number52 + "' != '" + (-1.0d) + "'", number52.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(objArray82);
        org.junit.Assert.assertNotNull(objArray87);
    }

//    @Test
//    public void test491() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test491");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        int int12 = randomDataImpl1.nextZipf(100, 2.718281828459045d);
//        double double15 = randomDataImpl1.nextCauchy(2.092790987315211d, 0.8813735870195429d);
//        double double18 = randomDataImpl1.nextGaussian((double) 10.0f, (double) 8);
//        double double21 = randomDataImpl1.nextGaussian(0.04723013714999615d, (double) 47L);
//        double double24 = randomDataImpl1.nextWeibull(1.9002507367077102d, 0.001369353897744088d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 54.60985159296201d + "'", double4 == 54.60985159296201d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.489356938933437d + "'", double6 == 4.489356938933437d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.8183016918190473d + "'", double15 == 2.8183016918190473d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 13.021659765057514d + "'", double18 == 13.021659765057514d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 93.3754444210699d + "'", double21 == 93.3754444210699d);
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 5.409299585441573E-4d + "'", double24 == 5.409299585441573E-4d);
//    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.9589242746631385d), (java.lang.Number) (-34.22139922072d), false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) (byte) 100, true);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        java.lang.Number number5 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) 100 + "'", number4.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 100 + "'", number5.equals((byte) 100));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        double double1 = org.apache.commons.math.util.FastMath.rint(2.5693769253694936d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(1.5269469083754401d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9129691980281998d + "'", double1 == 0.9129691980281998d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        double double2 = org.apache.commons.math.util.FastMath.max(0.5856749831752239d, 11.144178405319577d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11.144178405319577d + "'", double2 == 11.144178405319577d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.density(100.0d);
        double double3 = normalDistributionImpl0.getStandardDeviation();
        double double4 = normalDistributionImpl0.getStandardDeviation();
        double double6 = normalDistributionImpl0.cumulativeProbability(3.6588643574297026d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.9998733323128d + "'", double6 == 0.9998733323128d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number6 = numberIsTooLargeException5.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray12);
        java.lang.Object[] objArray15 = new java.lang.Object[] { objArray12, "" };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException5, localizable7, objArray12);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("", objArray12);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("", objArray12);
        org.apache.commons.math.exception.util.Localizable localizable19 = mathException18.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException(localizable19, (java.lang.Number) 0.36496488262332794d, (java.lang.Number) 0.6439528600818949d, (java.lang.Number) 1.3052608122477107d);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException31 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number32 = numberIsTooLargeException31.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException39 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray38);
        java.lang.Object[] objArray41 = new java.lang.Object[] { objArray38, "" };
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException31, localizable33, objArray38);
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException("", objArray38);
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException("", objArray38);
        org.apache.commons.math.exception.util.Localizable localizable45 = mathException44.getGeneralPattern();
        java.lang.Number number46 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException49 = new org.apache.commons.math.exception.OutOfRangeException(localizable45, number46, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray54 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException55 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray54);
        java.lang.String str56 = maxIterationsExceededException55.getPattern();
        java.lang.Object[] objArray57 = maxIterationsExceededException55.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException58 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable45, objArray57);
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        org.apache.commons.math.exception.util.Localizable localizable61 = null;
        java.lang.Object[] objArray66 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException67 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray66);
        java.lang.String str68 = maxIterationsExceededException67.getPattern();
        java.lang.String str69 = maxIterationsExceededException67.toString();
        java.lang.Object[] objArray70 = maxIterationsExceededException67.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException71 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, localizable61, objArray70);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException72 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable59, objArray70);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException73 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, objArray70);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException78 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number79 = numberIsTooLargeException78.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable80 = null;
        java.lang.Object[] objArray85 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException86 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray85);
        java.lang.Object[] objArray88 = new java.lang.Object[] { objArray85, "" };
        org.apache.commons.math.ConvergenceException convergenceException89 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException78, localizable80, objArray85);
        org.apache.commons.math.ConvergenceException convergenceException90 = new org.apache.commons.math.ConvergenceException("", objArray85);
        org.apache.commons.math.MathException mathException91 = new org.apache.commons.math.MathException(localizable45, objArray85);
        org.apache.commons.math.ConvergenceException convergenceException92 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException23, localizable24, objArray85);
        java.lang.Throwable[] throwableArray93 = outOfRangeException23.getSuppressed();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1.0d) + "'", number6.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + (-1.0d) + "'", number32.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(localizable45);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "hi!" + "'", str56.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "hi!" + "'", str68.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: hi!" + "'", str69.equals("org.apache.commons.math.MaxIterationsExceededException: hi!"));
        org.junit.Assert.assertNotNull(objArray70);
        org.junit.Assert.assertTrue("'" + number79 + "' != '" + (-1.0d) + "'", number79.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray85);
        org.junit.Assert.assertNotNull(objArray88);
        org.junit.Assert.assertNotNull(throwableArray93);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((-0.27861083953310206d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.7742031534326508d, (java.lang.Number) 3.608826080138695d, (java.lang.Number) 0.21144886271385083d);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.21144886271385083d + "'", number4.equals(0.21144886271385083d));
    }
}

