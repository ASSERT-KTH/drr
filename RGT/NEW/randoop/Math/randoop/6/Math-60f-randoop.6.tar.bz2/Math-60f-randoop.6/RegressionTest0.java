import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 100, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        float float2 = org.apache.commons.math.util.FastMath.min((float) ' ', 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-1L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 100.0f, (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4711276743037347d + "'", double2 == 1.4711276743037347d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) -1, 1.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.605170185988092d + "'", double1 == 4.605170185988092d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 1.0f, (double) (short) 10, (double) 'a', (int) ' ');
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.9999546000702375d + "'", double4 == 0.9999546000702375d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8813735870195429d + "'", double1 == 0.8813735870195429d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5729.5779513082325d + "'", double1 == 5729.5779513082325d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 1.0f, (double) 0L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (byte) -1);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        double double1 = org.apache.commons.math.special.Erf.erf((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (byte) 10);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 100L, (double) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.9999546000702375d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.9717386562014238E-5d) + "'", double1 == (-1.9717386562014238E-5d));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        long long1 = org.apache.commons.math.util.FastMath.abs(10L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 0);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (byte) -1);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            int int4 = randomDataImpl1.nextPascal(100, (double) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 10 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test028");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05273259000615482d + "'", double0 == 0.05273259000615482d);
//    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.4711276743037347d, (double) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.471127674303735d + "'", double2 == 1.471127674303735d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            double double4 = randomDataImpl1.nextBeta(Double.NaN, 4.605170185988092d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.488");
        } catch (org.apache.commons.math.exception.MathUserException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            long long4 = randomDataImpl1.nextLong((long) (short) 100, 100L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (100): lower bound (100) must be strictly less than upper bound (100)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 0L);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        double double1 = org.apache.commons.math.special.Erf.erf(0.9999546000702375d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8426819462428745d + "'", double1 == 0.8426819462428745d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-2.594126995249829d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.04527605728197682d) + "'", double1 == (-0.04527605728197682d));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        double double1 = org.apache.commons.math.util.FastMath.acos(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) (byte) 10, 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1142547833872074E-7d + "'", double2 == 1.1142547833872074E-7d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0076354937841634045d, (-1.9717386562014238E-5d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5733786539228416d + "'", double2 == 1.5733786539228416d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.154434690031884d + "'", double1 == 2.154434690031884d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(1.1142547833872074E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.054359047689252E13d + "'", double1 == 8.054359047689252E13d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.02398007912785791d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.15485502616272392d + "'", double1 == 0.15485502616272392d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test052");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        try {
//            randomDataImpl1.setSecureAlgorithm("org.apache.commons.math.MaxIterationsExceededException: ", "hi!");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: hi!");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 6.783885190434473d + "'", double4 == 6.783885190434473d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.320417637603233d + "'", double6 == 4.320417637603233d);
//    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test053");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        try {
//            int int7 = randomDataImpl1.nextSecureInt((int) ' ', 3);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 32 is larger than, or equal to, the maximum (3): lower bound (32) must be strictly less than upper bound (3)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.309600540436698d + "'", double4 == 7.309600540436698d);
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) 100, false);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException3);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.3391224761981917d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8018974326990581d + "'", double1 == 0.8018974326990581d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        double double1 = org.apache.commons.math.util.FastMath.ceil(5.853949697499888d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.0d + "'", double1 == 6.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (short) 100, 1.4210854715202004E-14d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (short) 1, 4.9E-324d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.34220201852392107d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3489200020960855d + "'", double1 == 0.3489200020960855d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (byte) 0);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2.6579694755975147d, (java.lang.Number) 0.15485502616272392d, false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            randomDataImpl1.setSecureAlgorithm("5fa2692c956e6b17b0ae0645ae88e67a635", "5fa2692c956e6b17b0ae0645ae88e67a635");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 5fa2692c956e6b17b0ae0645ae88e67a635");
        } catch (java.security.NoSuchProviderException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            int int4 = randomDataImpl1.nextPascal((-1), 4.599102285891914d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of successes (-1)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test065");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        try {
//            double double9 = randomDataImpl1.nextUniform((double) 0L, (double) 0.0f);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (0): lower bound (0) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 5.23054168242432d + "'", double4 == 5.23054168242432d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5727935936578824d + "'", double6 == 0.5727935936578824d);
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 11L, 2.6579694755975147d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.333707301036022d + "'", double2 == 1.333707301036022d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.3052608122477107d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7627350637656639d + "'", double1 == 0.7627350637656639d);
    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test068");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        long long7 = randomDataImpl1.nextLong((long) (byte) 10, (long) '4');
//        try {
//            double double10 = randomDataImpl1.nextBeta((double) 0.0f, (double) 100L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.564");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 5.666311523333848d + "'", double4 == 5.666311523333848d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 12L + "'", long7 == 12L);
//    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(2.6579694755975147d, (-0.04527605728197682d), 4.9E-324d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.045 is smaller than, or equal to, the minimum (0): standard deviation (-0.045)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        double double1 = org.apache.commons.math.util.FastMath.cos(2.6579694755975147d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8853159963232385d) + "'", double1 == (-0.8853159963232385d));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test072");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        java.lang.String str8 = randomDataImpl1.nextSecureHexString((int) '#');
//        try {
//            int int12 = randomDataImpl1.nextHypergeometric(3, 0, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than the maximum (3): sample size (100) must be less than or equal to population size (3)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.72957335304263d + "'", double4 == 3.72957335304263d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.014115229285447d + "'", double6 == 2.014115229285447d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "7d8eb04ffa250a608c5831bca9c382ad601" + "'", str8.equals("7d8eb04ffa250a608c5831bca9c382ad601"));
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        double double1 = org.apache.commons.math.util.FastMath.sinh(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.896296018268069E13d + "'", double1 == 7.896296018268069E13d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        double double2 = org.apache.commons.math.util.FastMath.min(7.896296018268069E13d, 0.02398007912785791d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.02398007912785791d + "'", double2 == 0.02398007912785791d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        double double2 = org.apache.commons.math.util.FastMath.max(0.7019159666064033d, 1.471127674303735d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.471127674303735d + "'", double2 == 1.471127674303735d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        double double1 = org.apache.commons.math.util.FastMath.atan((-2.594126995249829d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.2028641704164191d) + "'", double1 == (-1.2028641704164191d));
    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test079");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        long long7 = randomDataImpl1.nextLong((long) (byte) 10, (long) '4');
//        try {
//            randomDataImpl1.setSecureAlgorithm("org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than, or equal to, the maximum (10)", "org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than, or equal to, the maximum (10)");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than, or equal to, the maximum (10)");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.139560000138722d + "'", double4 == 4.139560000138722d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 39L + "'", long7 == 39L);
//    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test080");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        java.lang.String str8 = randomDataImpl1.nextSecureHexString((int) '#');
//        try {
//            int int11 = randomDataImpl1.nextPascal(10, 1.6585234628482202d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 1.659 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.410808301659349d + "'", double4 == 4.410808301659349d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.026783129028332544d + "'", double6 == 0.026783129028332544d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "8821a7e6f9ab3245826c93a26fce141fc40" + "'", str8.equals("8821a7e6f9ab3245826c93a26fce141fc40"));
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 359.1342053695754d + "'", double1 == 359.1342053695754d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.34220201852392107d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        double double1 = org.apache.commons.math.util.FastMath.tan((-0.04527605728197682d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.045307020123132084d) + "'", double1 == (-0.045307020123132084d));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (short) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1 == 10.0f);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number6 = numberIsTooLargeException5.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray12);
        java.lang.Object[] objArray15 = new java.lang.Object[] { objArray12, "" };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException5, localizable7, objArray12);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray12);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Object[] objArray19 = null;
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException17, localizable18, objArray19);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1.0d) + "'", number6.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray15);
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test087");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        try {
//            double double14 = randomDataImpl1.nextCauchy((-0.8853159963232385d), 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): scale (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.3721990570799223d + "'", double4 == 3.3721990570799223d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.7643376349222841d + "'", double6 == 0.7643376349222841d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        double double1 = org.apache.commons.math.util.FastMath.tanh(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test089");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) (byte) 1);
//        try {
//            randomDataImpl1.setSecureAlgorithm("org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than, or equal to, the maximum (10)", "5fa2692c956e6b17b0ae0645ae88e67a635");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 5fa2692c956e6b17b0ae0645ae88e67a635");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.48973843058104904d + "'", double3 == 0.48973843058104904d);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        java.lang.String str6 = numberIsTooLargeException3.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0d) + "'", number4.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0f + "'", number5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than, or equal to, the maximum (10)" + "'", str6.equals("org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than, or equal to, the maximum (10)"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            double double4 = randomDataImpl1.nextGaussian((double) (byte) 1, (-0.04527605728197682d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.045 is smaller than, or equal to, the minimum (0): standard deviation (-0.045)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int int1 = org.apache.commons.math.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test093");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        try {
//            int int12 = randomDataImpl1.nextZipf((int) (byte) 0, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): dimension (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.478148202097913d + "'", double4 == 3.478148202097913d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.4235752307138174d + "'", double6 == 1.4235752307138174d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        double double1 = org.apache.commons.math.util.FastMath.log(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) 100, false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test097");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT(4.599102285891914d);
//        try {
//            double double6 = randomDataImpl1.nextWeibull(0.0d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): shape (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.1152769938293656d + "'", double3 == 2.1152769938293656d);
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) '#', (-0.008252437515514003d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable1, objArray8);
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException11);
        try {
            java.lang.String str13 = maxIterationsExceededException11.getPattern();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objArray8);
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test100");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        try {
//            java.lang.String str8 = randomDataImpl1.nextSecureHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 49.94747831800844d + "'", double4 == 49.94747831800844d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.24455361688216173d + "'", double6 == 0.24455361688216173d);
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12.801827480081469d + "'", double1 == 12.801827480081469d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        double double1 = org.apache.commons.math.special.Gamma.digamma((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        double double0 = org.apache.commons.math.distribution.NormalDistributionImpl.DEFAULT_INVERSE_ABSOLUTE_ACCURACY;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-9d + "'", double0 == 1.0E-9d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.599102285891914d, (-0.4064624400499381d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.406 is smaller than, or equal to, the minimum (0): standard deviation (-0.406)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 10, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(2.154434690031884d, (double) 100, 0.29495535414077817d, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: Continued fraction convergents failed to converge (in less than 100 iterations) for value {1}");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        long long1 = org.apache.commons.math.util.FastMath.abs(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        double double1 = org.apache.commons.math.util.FastMath.signum(5.775284847419849d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        float float1 = org.apache.commons.math.util.FastMath.abs(100.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        double double1 = org.apache.commons.math.special.Gamma.digamma(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.5264888286059799d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.692977526344448d + "'", double1 == 1.692977526344448d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17453292519943295d + "'", double1 == 0.17453292519943295d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) ' ');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.8853159963232385d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 11L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-225.95084645419513d) + "'", double1 == (-225.95084645419513d));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.9379198162596534d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9788629796100344d + "'", double1 == 0.9788629796100344d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.7400576788232446d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6743305045039658d + "'", double1 == 0.6743305045039658d);
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test118");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        long long7 = randomDataImpl1.nextLong((long) (byte) 10, (long) '4');
//        try {
//            long long10 = randomDataImpl1.nextSecureLong((long) '#', (long) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 35 is larger than, or equal to, the maximum (1): lower bound (35) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 11.181612440281624d + "'", double4 == 11.181612440281624d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 42L + "'", long7 == 42L);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 100, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 0L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.5264888286059799d, (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05260031770763203d + "'", double2 == 0.05260031770763203d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        int int1 = org.apache.commons.math.util.FastMath.round((float) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test123");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        randomDataImpl1.reSeed((-1L));
//        try {
//            int int15 = randomDataImpl1.nextHypergeometric(0, 0, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): population size (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 12.407842996416163d + "'", double4 == 12.407842996416163d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.5061229392913575E-4d + "'", double6 == 1.5061229392913575E-4d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9L + "'", long9 == 9L);
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.6585234628482202d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.7209854707924777d + "'", double1 == 2.7209854707924777d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-1), (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 47L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.608826080138695d + "'", double1 == 3.608826080138695d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.4711276743037347d, (double) 1L);
        try {
            double double4 = normalDistributionImpl2.inverseCumulativeProbability(2.154434690031884d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 2.154 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test128");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        try {
//            double double9 = randomDataImpl1.nextBeta((double) (-1), 4.605170185988092d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.071");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 12.926868255406728d + "'", double4 == 12.926868255406728d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.1176937361107133d + "'", double6 == 2.1176937361107133d);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.085536923187668d + "'", double1 == 20.085536923187668d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        int int1 = org.apache.commons.math.util.FastMath.round(1.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 11L, 1.4210854715202004E-14d, 1.4711276743037347d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.015413343812216955d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.24886603123466666d + "'", double1 == 0.24886603123466666d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.5733786539228416d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        java.lang.String str1 = mathException0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "org.apache.commons.math.MathException: " + "'", str1.equals("org.apache.commons.math.MathException: "));
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test138");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT(4.599102285891914d);
//        try {
//            int int6 = randomDataImpl1.nextBinomial((int) (byte) 1, (-0.4064624400499381d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -0.406 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.1159588876324544d + "'", double3 == 1.1159588876324544d);
//    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test139");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        long long3 = randomDataImpl1.nextPoisson((double) 10L);
//        try {
//            int int7 = randomDataImpl1.nextHypergeometric(0, (int) 'a', (int) ' ');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): population size (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 18L + "'", long3 == 18L);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 10.0d);
        java.lang.Number number3 = notStrictlyPositiveException2.getArgument();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 10.0d + "'", number3.equals(10.0d));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        int int2 = org.apache.commons.math.util.FastMath.min(5, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test142");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) 'a');
//        try {
//            int int14 = randomDataImpl1.nextZipf((int) (byte) 1, (-0.3518548721102766d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.352 is smaller than, or equal to, the minimum (0): exponent (-0.352)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.6565941696322484d + "'", double4 == 3.6565941696322484d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.6762477618939456d + "'", double6 == 0.6762477618939456d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
//    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(8.054359047689252E13d, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.10516633568161556d + "'", double1 == 0.10516633568161556d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            int int4 = randomDataImpl1.nextBinomial((int) (byte) 10, 11.841132140022399d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 11.841 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test146");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        randomDataImpl1.reSeed();
//        double double13 = randomDataImpl1.nextCauchy(5.853949697499888d, 0.006937366662896952d);
//        try {
//            int int16 = randomDataImpl1.nextInt(7, 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 7 is larger than, or equal to, the maximum (1): lower bound (7) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.471533347594529d + "'", double4 == 3.471533347594529d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0075972443332262395d + "'", double6 == 0.0075972443332262395d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 6L + "'", long9 == 6L);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 5.857670375207365d + "'", double13 == 5.857670375207365d);
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6321205588285577d) + "'", double1 == (-0.6321205588285577d));
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test148");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        double double14 = randomDataImpl1.nextT(0.7627350637656639d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution15 = null;
//        try {
//            int int16 = randomDataImpl1.nextInversionDeviate(integerDistribution15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.8698717651787202d + "'", double4 == 3.8698717651787202d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.008684110716434747d + "'", double6 == 0.008684110716434747d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-0.12375829720337245d) + "'", double14 == (-0.12375829720337245d));
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray4);
        java.lang.String str6 = maxIterationsExceededException5.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray17);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray17);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable10, objArray17);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException("", objArray17);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException5, localizable7, objArray17);
        java.lang.Throwable[] throwableArray23 = maxIterationsExceededException5.getSuppressed();
        java.lang.String str24 = maxIterationsExceededException5.getPattern();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        int int1 = org.apache.commons.math.util.FastMath.round(10.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test151");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        double double14 = randomDataImpl1.nextT(0.7627350637656639d);
//        double double17 = randomDataImpl1.nextGaussian((double) (byte) 1, 0.29495535414077817d);
//        randomDataImpl1.reSeedSecure((long) 100);
//        int int22 = randomDataImpl1.nextSecureInt((int) (byte) 10, (int) (byte) 100);
//        try {
//            java.lang.String str24 = randomDataImpl1.nextSecureHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.077380157639725d + "'", double4 == 4.077380157639725d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.9805520984039737d + "'", double6 == 2.9805520984039737d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-7.679494038493622d) + "'", double14 == (-7.679494038493622d));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0741284450150324d + "'", double17 == 1.0741284450150324d);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 64 + "'", int22 == 64);
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 47L, (java.lang.Number) 1.471127674303735d, false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(359.1342053695754d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 18.95083653482282d + "'", double1 == 18.95083653482282d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        double double2 = org.apache.commons.math.util.FastMath.pow(3.141592653589793d, (-0.8945632653807307d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.359143479977167d + "'", double2 == 0.359143479977167d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) -1, (float) 3);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.0f + "'", float2 == 3.0f);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 0L, (-0.04527605728197682d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test159");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution13 = null;
//        try {
//            int int14 = randomDataImpl1.nextInversionDeviate(integerDistribution13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.247110474608945d + "'", double4 == 4.247110474608945d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.850529739973855d + "'", double6 == 1.850529739973855d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
//    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        double double1 = org.apache.commons.math.special.Gamma.digamma((-0.015722159129280943d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 63.001116540868786d + "'", double1 == 63.001116540868786d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 100, (-0.04527605728197682d), 0.0d, 8);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        int int1 = org.apache.commons.math.util.FastMath.abs(5);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test163");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl0.density(100.0d);
//        double double3 = normalDistributionImpl0.getStandardDeviation();
//        double double4 = normalDistributionImpl0.getStandardDeviation();
//        double double5 = normalDistributionImpl0.sample();
//        try {
//            double double7 = normalDistributionImpl0.inverseCumulativeProbability(2.526299952429221d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 2.526 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.2344495913783597d + "'", double5 == 2.2344495913783597d);
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.05273259000615482d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.05260031770763203d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9986169222235228d + "'", double1 == 0.9986169222235228d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.04527605728197682d), (java.lang.Number) (-0.045307020123132084d), true);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8390715290764524d) + "'", double1 == (-0.8390715290764524d));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) (-0.17738444574517354d), true);
        java.lang.Throwable[] throwableArray5 = numberIsTooSmallException4.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.017453292519943295d) + "'", double1 == (-0.017453292519943295d));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.17412425486732214d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-0.6321205588285577d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test173");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        java.lang.String str8 = randomDataImpl1.nextSecureHexString((int) '#');
//        try {
//            double double11 = randomDataImpl1.nextUniform(0.0d, (-0.4064624400499381d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (-0.406): lower bound (0) must be strictly less than upper bound (-0.406)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.3894613252468786d + "'", double4 == 2.3894613252468786d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.12510187837778913d + "'", double6 == 0.12510187837778913d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "166d8caee7195665075a345197588e371be" + "'", str8.equals("166d8caee7195665075a345197588e371be"));
//    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(7.799533480847564d, 3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.018784420240901677d + "'", double2 == 0.018784420240901677d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 10, 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.9002507367077102d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9002507367077104d + "'", double1 == 1.9002507367077104d);
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test177");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        try {
//            java.lang.String str14 = randomDataImpl1.nextHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.4213826788299992d + "'", double4 == 1.4213826788299992d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.972020969361208d + "'", double6 == 1.972020969361208d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
//    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test178");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        randomDataImpl1.reSeed((-1L));
//        int int14 = randomDataImpl1.nextZipf(1, 0.9379198162596534d);
//        try {
//            int int17 = randomDataImpl1.nextPascal((int) (short) 0, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MathException; message: Discrete cumulative probability function returned NaN for argument 1,073,741,822");
//        } catch (org.apache.commons.math.MathException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.3587262134873557d + "'", double4 == 1.3587262134873557d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 5.237698414843581d + "'", double6 == 5.237698414843581d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 9L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) (-1));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test181");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        double double14 = randomDataImpl1.nextT(0.7627350637656639d);
//        double double17 = randomDataImpl1.nextGaussian((double) (byte) 1, 0.29495535414077817d);
//        randomDataImpl1.reSeedSecure((long) 100);
//        int int22 = randomDataImpl1.nextSecureInt((int) (byte) 10, (int) (byte) 100);
//        try {
//            randomDataImpl1.setSecureAlgorithm("5fa2692c956e6b17b0ae0645ae88e67a635", "");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.477643416168842d + "'", double4 == 1.477643416168842d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.569035227909605d + "'", double6 == 0.569035227909605d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-0.9207825385969507d) + "'", double14 == (-0.9207825385969507d));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.3192505777600119d + "'", double17 == 1.3192505777600119d);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 82 + "'", int22 == 82);
//    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        double double1 = org.apache.commons.math.util.FastMath.log1p(2.526299952429221d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2602491491122794d + "'", double1 == 1.2602491491122794d);
    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test183");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        try {
//            int[] intArray7 = randomDataImpl1.nextPermutation((int) (short) 1, (-1));
//            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
//        } catch (java.lang.NegativeArraySizeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.4344548960239059d + "'", double4 == 1.4344548960239059d);
//    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, 7L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test185");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) (byte) 1);
//        double double5 = randomDataImpl1.nextT((double) 8);
//        randomDataImpl1.reSeed();
//        try {
//            int int9 = randomDataImpl1.nextInt((int) '#', 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 35 is larger than, or equal to, the maximum (10): lower bound (35) must be strictly less than upper bound (10)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.16244894569080626d + "'", double3 == 0.16244894569080626d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.8606330094919297d + "'", double5 == 0.8606330094919297d);
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-0.3518548721102766d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.43364064491300164d) + "'", double1 == (-0.43364064491300164d));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        double double1 = org.apache.commons.math.util.FastMath.signum(359.1342053695754d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        double double1 = org.apache.commons.math.util.FastMath.abs(3.608826080138695d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.608826080138695d + "'", double1 == 3.608826080138695d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        double double1 = org.apache.commons.math.special.Gamma.digamma((-1.2028641704164191d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.789142871249076d + "'", double1 == 4.789142871249076d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) (byte) 10, (double) 47L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4690996480235547E-11d + "'", double2 == 1.4690996480235547E-11d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-1.9717386562014238E-5d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 47L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 47 + "'", int1 == 47);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.24886603123466666d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.004343531641415982d + "'", double1 == 0.004343531641415982d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        long long1 = org.apache.commons.math.util.FastMath.round(2.154434690031884d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        double double2 = org.apache.commons.math.util.FastMath.max(7.250303402295148d, (double) (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.250303402295148d + "'", double2 == 7.250303402295148d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        double double1 = org.apache.commons.math.util.FastMath.sinh(2.4746473287171966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.896662418833589d + "'", double1 == 5.896662418833589d);
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test199");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl0.density(100.0d);
//        double double3 = normalDistributionImpl0.getStandardDeviation();
//        double double4 = normalDistributionImpl0.sample();
//        double double5 = normalDistributionImpl0.getMean();
//        try {
//            double double7 = normalDistributionImpl0.inverseCumulativeProbability(8.054359047689252E13d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 80,543,590,476,892.52 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.713472682056031d + "'", double4 == 0.713472682056031d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-1.2028641704164191d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.202864170416419d) + "'", double1 == (-1.202864170416419d));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 7L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test203");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        randomDataImpl1.reSeed((-1L));
//        int int14 = randomDataImpl1.nextZipf(1, 0.9379198162596534d);
//        try {
//            double double17 = randomDataImpl1.nextUniform(0.03121305011401776d, (-0.3518548721102766d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0.031 is larger than, or equal to, the maximum (-0.352): lower bound (0.031) must be strictly less than upper bound (-0.352)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.7974085941992166d + "'", double4 == 1.7974085941992166d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.4979859015124309d + "'", double6 == 0.4979859015124309d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2L + "'", long9 == 2L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        double double0 = org.apache.commons.math.special.Gamma.GAMMA;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.5772156649015329d + "'", double0 == 0.5772156649015329d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        double double1 = org.apache.commons.math.special.Erf.erf(11.841132140022399d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 155.74607629780772d + "'", double1 == 155.74607629780772d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray4);
        java.lang.String str6 = maxIterationsExceededException5.getPattern();
        java.lang.String str7 = maxIterationsExceededException5.toString();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException5);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException8);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: hi!" + "'", str7.equals("org.apache.commons.math.MaxIterationsExceededException: hi!"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        double double1 = org.apache.commons.math.util.FastMath.ceil(155.74607629780772d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 156.0d + "'", double1 == 156.0d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (byte) -1, (-0.04527605728197682d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        java.lang.Number number2 = notStrictlyPositiveException1.getArgument();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + (-1.0d) + "'", number2.equals((-1.0d)));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        int int2 = org.apache.commons.math.util.FastMath.max(1, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.5061169493981285d, (-1.202864170416419d), (double) 52L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.203 is smaller than, or equal to, the minimum (0): standard deviation (-1.203)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test214");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT(4.599102285891914d);
//        try {
//            int int6 = randomDataImpl1.nextBinomial(0, (double) 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 100 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.322852835621115d + "'", double3 == 1.322852835621115d);
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        int int2 = org.apache.commons.math.util.FastMath.max(3, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 3.0f, (-2.892836077235549d), (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -2.893 is smaller than, or equal to, the minimum (0): standard deviation (-2.893)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.3489200020960855d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.292246797294528d + "'", double1 == 9.292246797294528d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) 0, 10.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (short) 100, (java.lang.Number) 0.8813735870195429d, (java.lang.Number) 100);
        java.lang.Number number5 = outOfRangeException4.getLo();
        java.lang.Throwable[] throwableArray6 = outOfRangeException4.getSuppressed();
        java.lang.Number number7 = outOfRangeException4.getHi();
        java.lang.Number number8 = outOfRangeException4.getLo();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.8813735870195429d + "'", number5.equals(0.8813735870195429d));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 100 + "'", number7.equals(100));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0.8813735870195429d + "'", number8.equals(0.8813735870195429d));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(1.1571890363470199d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3337666330107587d + "'", double1 == 1.3337666330107587d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray4);
        java.lang.String str6 = maxIterationsExceededException5.getPattern();
        java.lang.String str7 = maxIterationsExceededException5.toString();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException5);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException5);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException5);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: hi!" + "'", str7.equals("org.apache.commons.math.MaxIterationsExceededException: hi!"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        java.lang.Object[] objArray6 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray6);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray6);
        java.lang.Class<?> wildcardClass9 = maxIterationsExceededException8.getClass();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 20);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.7144176165949068d + "'", double1 == 2.7144176165949068d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-2.594126995249829d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.0d) + "'", double1 == (-2.0d));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        double double1 = org.apache.commons.math.util.FastMath.rint((-0.3518548721102766d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.24886603123466666d, (-0.9472126504103459d), 0.0d, (int) (short) 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        double double1 = org.apache.commons.math.special.Gamma.digamma(0.9999546000702375d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.577290349936525d) + "'", double1 == (-0.577290349936525d));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(14.711890248661776d, (double) '4', 0.14122346516813142d, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.9999999997059648d + "'", double4 == 0.9999999997059648d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        long long1 = org.apache.commons.math.util.FastMath.round(2.526299952429221d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3L + "'", long1 == 3L);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 3L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(8.054359047689252E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.498447650589192E15d + "'", double1 == 2.498447650589192E15d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.9436379339725438d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (short) -1, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getSpecificPattern();
        org.junit.Assert.assertNull(localizable4);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        double double2 = org.apache.commons.math.util.FastMath.max(0.47035854412542794d, 7.291140084956589d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.291140084956589d + "'", double2 == 7.291140084956589d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) '4');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        double double1 = org.apache.commons.math.util.FastMath.tanh(5.391022392535616d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999584626848042d + "'", double1 == 0.9999584626848042d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.17453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.16087055809932455d + "'", double1 == 0.16087055809932455d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 'a');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test243");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        double double14 = randomDataImpl1.nextT(0.7627350637656639d);
//        double double17 = randomDataImpl1.nextGaussian((double) (byte) 1, 0.29495535414077817d);
//        randomDataImpl1.reSeedSecure((long) 100);
//        int int22 = randomDataImpl1.nextSecureInt((int) (byte) 10, (int) (byte) 100);
//        try {
//            double double24 = randomDataImpl1.nextExponential(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.534904328674147d + "'", double4 == 4.534904328674147d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.29329790057370386d + "'", double6 == 0.29329790057370386d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.5693375499520985d + "'", double14 == 1.5693375499520985d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0119572781009123d + "'", double17 == 1.0119572781009123d);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 84 + "'", int22 == 84);
//    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((-0.8945632653807307d), 1.164058273003315d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (short) -1, (float) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        double double1 = org.apache.commons.math.util.FastMath.acosh(12.808427727927521d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.241723184387021d + "'", double1 == 3.241723184387021d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.466070329168668E-11d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.466070329168668E-11d + "'", double1 == 1.466070329168668E-11d);
    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test248");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        randomDataImpl1.reSeed();
//        double double13 = randomDataImpl1.nextCauchy(5.853949697499888d, 0.006937366662896952d);
//        try {
//            int int17 = randomDataImpl1.nextHypergeometric((int) (byte) -1, (int) ' ', (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): population size (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.437050336554185d + "'", double4 == 4.437050336554185d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5706925704604564d + "'", double6 == 0.5706925704604564d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 4L + "'", long9 == 4L);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 5.859127373342587d + "'", double13 == 5.859127373342587d);
//    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-0.015722159129280943d), (double) (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.125871789702468d) + "'", double2 == (-3.125871789702468d));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 24L, 7.941843147108244d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 23.999999999999996d + "'", double2 == 23.999999999999996d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test252");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl0.density(100.0d);
//        double double3 = normalDistributionImpl0.sample();
//        double double4 = normalDistributionImpl0.sample();
//        try {
//            double double6 = normalDistributionImpl0.inverseCumulativeProbability(1.7099784235361526d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 1.71 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.4077749537548987d) + "'", double3 == (-0.4077749537548987d));
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.07440648938076554d + "'", double4 == 0.07440648938076554d);
//    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(2.154434690031884d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.03760197886023983d + "'", double1 == 0.03760197886023983d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test255");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        double double14 = randomDataImpl1.nextT(0.7627350637656639d);
//        double double17 = randomDataImpl1.nextCauchy(0.5061169493981285d, 5.853949697499888d);
//        try {
//            double double20 = randomDataImpl1.nextF(0.0d, 1.3337666330107587d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 36.82380305363578d + "'", double4 == 36.82380305363578d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.49440513365191296d + "'", double6 == 0.49440513365191296d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.4567988389122884d + "'", double14 == 0.4567988389122884d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.5610437256400664d + "'", double17 == 1.5610437256400664d);
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.333707301036022d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException(localizable2, objArray3);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException(4, localizable1, objArray3);
        java.lang.String str6 = maxIterationsExceededException5.toString();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: " + "'", str6.equals("org.apache.commons.math.MaxIterationsExceededException: "));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number7 = numberIsTooLargeException6.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray13);
        java.lang.Object[] objArray16 = new java.lang.Object[] { objArray13, "" };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException6, localizable8, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable1, objArray13);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number27 = numberIsTooLargeException26.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        java.lang.Object[] objArray33 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException34 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray33);
        java.lang.Object[] objArray36 = new java.lang.Object[] { objArray33, "" };
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException26, localizable28, objArray33);
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException("", objArray33);
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException("", objArray33);
        org.apache.commons.math.exception.util.Localizable localizable40 = mathException39.getGeneralPattern();
        java.lang.Number number41 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException44 = new org.apache.commons.math.exception.OutOfRangeException(localizable40, number41, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray49 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException50 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray49);
        java.lang.String str51 = maxIterationsExceededException50.getPattern();
        java.lang.Object[] objArray52 = maxIterationsExceededException50.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException53 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable40, objArray52);
        org.apache.commons.math.exception.util.Localizable localizable54 = maxIterationsExceededException53.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException56 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.util.Localizable localizable57 = notStrictlyPositiveException56.getSpecificPattern();
        java.lang.Throwable[] throwableArray58 = notStrictlyPositiveException56.getSuppressed();
        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException(localizable54, (java.lang.Object[]) throwableArray58);
        java.lang.Object[] objArray60 = null;
        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException19, localizable54, objArray60);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1.0d) + "'", number7.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + (-1.0d) + "'", number27.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(localizable40);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "hi!" + "'", str51.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(localizable54);
        org.junit.Assert.assertNull(localizable57);
        org.junit.Assert.assertNotNull(throwableArray58);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.17862484014276203d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.42264032006277164d + "'", double1 == 0.42264032006277164d);
    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test260");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        long long7 = randomDataImpl1.nextLong((long) (byte) 10, (long) '4');
//        double double10 = randomDataImpl1.nextBeta(1.471127674303735d, 1.1185087377885383d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double13 = normalDistributionImpl11.density(100.0d);
//        double double14 = normalDistributionImpl11.getStandardDeviation();
//        double double15 = normalDistributionImpl11.sample();
//        double double17 = normalDistributionImpl11.cumulativeProbability((double) (byte) 10);
//        double[] doubleArray19 = normalDistributionImpl11.sample((int) (byte) 100);
//        double double20 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        try {
//            double double22 = randomDataImpl1.nextExponential((-3.125871789702468d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -3.126 is smaller than, or equal to, the minimum (0): mean (-3.126)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 18.868201237867936d + "'", double4 == 18.868201237867936d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 29L + "'", long7 == 29L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.804453393808952d + "'", double10 == 0.804453393808952d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.8336017530794939d + "'", double15 == 0.8336017530794939d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
//        org.junit.Assert.assertNotNull(doubleArray19);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-0.26499409671775626d) + "'", double20 == (-0.26499409671775626d));
//    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test261");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) 'a');
//        randomDataImpl1.reSeedSecure();
//        try {
//            long long14 = randomDataImpl1.nextPoisson((double) (-1));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): mean (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-4.7426966081268205d) + "'", double4 == (-4.7426966081268205d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.14767767936173407d + "'", double6 == 0.14767767936173407d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test262");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        randomDataImpl1.reSeed();
//        try {
//            int int14 = randomDataImpl1.nextHypergeometric((int) (byte) 1, (int) (byte) -1, 4);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of successes (-1)");
//        } catch (org.apache.commons.math.exception.NotPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-4.863436158630336d) + "'", double4 == (-4.863436158630336d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2792909365896662d + "'", double6 == 0.2792909365896662d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 4L + "'", long9 == 4L);
//    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (short) 100);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test264");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) (byte) 1);
//        double double5 = randomDataImpl1.nextT((double) 8);
//        randomDataImpl1.reSeed();
//        randomDataImpl1.reSeedSecure();
//        try {
//            double double10 = randomDataImpl1.nextBeta(0.0d, 1.2610288642034437d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.235");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0956374743745387d) + "'", double3 == (-1.0956374743745387d));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.9400908487309158d + "'", double5 == 0.9400908487309158d);
//    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test265");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        try {
//            int int8 = randomDataImpl1.nextHypergeometric((int) (short) 10, 32, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 32 is larger than the maximum (10): number of successes (32) must be less than or equal to population size (10)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-4.005843053004884d) + "'", double4 == (-4.005843053004884d));
//    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        int int2 = org.apache.commons.math.util.FastMath.min(8, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test268");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        long long7 = randomDataImpl1.nextLong((long) (byte) 10, (long) '4');
//        try {
//            int int10 = randomDataImpl1.nextPascal((-1), 0.9999999997059648d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of successes (-1)");
//        } catch (org.apache.commons.math.exception.NotPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-4.246674533180834d) + "'", double4 == (-4.246674533180834d));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 31L + "'", long7 == 31L);
//    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test269");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        long long7 = randomDataImpl1.nextLong((long) (byte) 10, (long) '4');
//        try {
//            int int10 = randomDataImpl1.nextPascal((int) (byte) 10, (-225.95084645419513d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -225.951 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-4.202214296395079d) + "'", double4 == (-4.202214296395079d));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 51L + "'", long7 == 51L);
//    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test270");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        randomDataImpl1.reSeed((-1L));
//        try {
//            int[] intArray14 = randomDataImpl1.nextPermutation(4, 5);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 5 is larger than the maximum (4): permutation size (5) exceeds permuation domain (4)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-3.636505023819743d) + "'", double4 == (-3.636505023819743d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2472727594661011d + "'", double6 == 0.2472727594661011d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
//    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number6 = numberIsTooLargeException5.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray12);
        java.lang.Object[] objArray15 = new java.lang.Object[] { objArray12, "" };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException5, localizable7, objArray12);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("", objArray12);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("", objArray12);
        org.apache.commons.math.exception.util.Localizable localizable19 = mathException18.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(localizable20, objArray21);
        mathException18.addSuppressed((java.lang.Throwable) convergenceException22);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1.0d) + "'", number6.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertNotNull(objArray21);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 5);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test274");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT(4.599102285891914d);
//        try {
//            java.lang.String str5 = randomDataImpl1.nextHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.4894144036111951d) + "'", double3 == (-1.4894144036111951d));
//    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number6 = numberIsTooLargeException5.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray12);
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException5, localizable7, objArray12);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(throwable0, "b0b856f991", objArray12);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number22 = numberIsTooLargeException21.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray28);
        java.lang.Object[] objArray31 = new java.lang.Object[] { objArray28, "" };
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException21, localizable23, objArray28);
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException("", objArray28);
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException("", objArray28);
        org.apache.commons.math.exception.util.Localizable localizable35 = mathException34.getGeneralPattern();
        java.lang.Number number36 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException39 = new org.apache.commons.math.exception.OutOfRangeException(localizable35, number36, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        java.lang.Object[] objArray48 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException49 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray48);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException50 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray48);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException51 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable41, objArray48);
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException51);
        java.lang.Object[] objArray53 = mathException52.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException(throwable0, localizable35, objArray53);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1.0d) + "'", number6.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (-1.0d) + "'", number22.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(localizable35);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(objArray53);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-1));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test278");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.4711276743037347d, (double) 1L);
//        double double3 = normalDistributionImpl2.sample();
//        double double4 = normalDistributionImpl2.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.092790987315211d + "'", double3 == 2.092790987315211d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
//    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test279");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        int int12 = randomDataImpl1.nextZipf(100, 2.718281828459045d);
//        double double14 = randomDataImpl1.nextT(0.9986169222235228d);
//        try {
//            randomDataImpl1.setSecureAlgorithm("c3f9f7fd6da28e1c8ac7e2aef31f6fc893dc30139b98d72dae053c81cd2661249c3b16f9e11c23cb17e401a5cfda2bfe46f1", "org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than, or equal to, the maximum (10)");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than, or equal to, the maximum (10)");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 28.9009363754587d + "'", double4 == 28.9009363754587d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.9657801521585729d + "'", double6 == 0.9657801521585729d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.1018298853858353d) + "'", double14 == (-1.1018298853858353d));
//    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        long long1 = org.apache.commons.math.util.FastMath.round(0.015413343812216955d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 7L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 7.0f + "'", float1 == 7.0f);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.8426819462428745d, (-0.8305568064477297d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.0013693530418394818d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.001369353897744088d + "'", double1 == 0.001369353897744088d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        double double1 = org.apache.commons.math.special.Gamma.digamma(0.29495535414077817d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.5652717091549992d) + "'", double1 == (-3.5652717091549992d));
    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test285");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        double double11 = randomDataImpl1.nextExponential(2.220446049250313E-16d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.03450956421152d + "'", double4 == 7.03450956421152d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.91682296922358d + "'", double6 == 1.91682296922358d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.265278032032717E-17d + "'", double11 == 4.265278032032717E-17d);
//    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test286");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        double double14 = randomDataImpl1.nextT(0.7627350637656639d);
//        double double17 = randomDataImpl1.nextCauchy(0.5061169493981285d, 5.853949697499888d);
//        java.lang.String str19 = randomDataImpl1.nextHexString((int) (byte) 10);
//        int int22 = randomDataImpl1.nextInt((int) (byte) 0, 47);
//        try {
//            long long25 = randomDataImpl1.nextSecureLong((long) (byte) 100, 7L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (7): lower bound (100) must be strictly less than upper bound (7)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 6.98894978619632d + "'", double4 == 6.98894978619632d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.002254409733357949d + "'", double6 == 0.002254409733357949d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 216.97442422016317d + "'", double14 == 216.97442422016317d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-2.1845888625499477d) + "'", double17 == (-2.1845888625499477d));
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "de590d118e" + "'", str19.equals("de590d118e"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 47 + "'", int22 == 47);
//    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test287");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        randomDataImpl1.reSeed();
//        double double13 = randomDataImpl1.nextCauchy(5.853949697499888d, 0.006937366662896952d);
//        try {
//            double double16 = randomDataImpl1.nextBeta(14.711890248661776d, (-0.8305568064477297d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.844");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-10.725839008976696d) + "'", double4 == (-10.725839008976696d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.9684136291911476d + "'", double6 == 0.9684136291911476d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 5L + "'", long9 == 5L);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 5.836270923192527d + "'", double13 == 5.836270923192527d);
//    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test288");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        try {
//            randomDataImpl1.setSecureAlgorithm("e095a50de7a8cd45e446824941e4345ea9e", "a588e52921");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: a588e52921");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-10.83336984124326d) + "'", double4 == (-10.83336984124326d));
//    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        double double1 = org.apache.commons.math.util.FastMath.abs(9.292246797294528d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.292246797294528d + "'", double1 == 9.292246797294528d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        double double1 = org.apache.commons.math.util.FastMath.log10(11.053536600647437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0435012536236978d + "'", double1 == 1.0435012536236978d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable1, objArray8);
        int int12 = maxIterationsExceededException11.getMaxIterations();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test292");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        double double14 = randomDataImpl1.nextT(0.7627350637656639d);
//        double double17 = randomDataImpl1.nextCauchy(0.5061169493981285d, 5.853949697499888d);
//        java.lang.String str19 = randomDataImpl1.nextHexString((int) (byte) 10);
//        try {
//            int int22 = randomDataImpl1.nextPascal((int) ' ', 2.154434690031884d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 2.154 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-9.515372093132811d) + "'", double4 == (-9.515372093132811d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.3525761645427118d + "'", double6 == 0.3525761645427118d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-0.13448945401988874d) + "'", double14 == (-0.13448945401988874d));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-42.22902101709738d) + "'", double17 == (-42.22902101709738d));
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "bb5929befd" + "'", str19.equals("bb5929befd"));
//    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.3337666330107587d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.02327861919927663d + "'", double1 == 0.02327861919927663d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.5264888286059799d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5511511156137109d + "'", double1 == 0.5511511156137109d);
    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test295");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeed();
//        try {
//            int int13 = randomDataImpl1.nextZipf((int) (short) 0, (double) 5L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): dimension (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-9.812166785146538d) + "'", double4 == (-9.812166785146538d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5730229482245676d + "'", double6 == 0.5730229482245676d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException(localizable2, objArray3);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException(4, localizable1, objArray3);
        int int6 = maxIterationsExceededException5.getMaxIterations();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray11);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray11);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable4, objArray11);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("", objArray11);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException16 = new org.apache.commons.math.MaxIterationsExceededException(8, "org.apache.commons.math.MathException: ", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable17 = maxIterationsExceededException16.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNull(localizable17);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        double double1 = org.apache.commons.math.util.FastMath.floor((-1.2028641704164191d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.0d) + "'", double1 == (-2.0d));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.8426819462428745d, 0.006937366662896952d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5625640275552255d + "'", double2 == 1.5625640275552255d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        double double2 = org.apache.commons.math.util.FastMath.max(0.29495535414077817d, (double) 7);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.0d + "'", double2 == 7.0d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.3648677091068375d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (byte) 10, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) 0.0f);
        java.lang.Number number5 = outOfRangeException4.getLo();
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4, "maximal number of iterations ({0}) exceeded", objArray7);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.5707963267948966d + "'", number5.equals(1.5707963267948966d));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            int int3 = randomDataImpl0.nextInt((int) ' ', 9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 32 is larger than, or equal to, the maximum (9): lower bound (32) must be strictly less than upper bound (9)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) ' ');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 32.0f + "'", float1 == 32.0f);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        long long2 = org.apache.commons.math.util.FastMath.max(10L, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 100, 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test309");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double1 = normalDistributionImpl0.sample();
//        normalDistributionImpl0.reseedRandomGenerator(6L);
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.033848630998717065d + "'", double1 == 0.033848630998717065d);
//    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.4210854715202004E-14d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(1.2610288642034437d, (double) 5L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.011867787460032826d + "'", double2 == 0.011867787460032826d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.density(100.0d);
        double double3 = normalDistributionImpl0.getStandardDeviation();
        double double4 = normalDistributionImpl0.getStandardDeviation();
        double double6 = normalDistributionImpl0.cumulativeProbability((-1.9717386562014238E-5d));
        try {
            double double8 = normalDistributionImpl0.inverseCumulativeProbability(14.09826392661204d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 14.098 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.4999921339008419d + "'", double6 == 0.4999921339008419d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(11.053536600647437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 15.230453562737472d + "'", double1 == 15.230453562737472d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 47);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 47L + "'", long1 == 47L);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.1185087377885383d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0380377007567323d + "'", double1 == 1.0380377007567323d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        long long2 = org.apache.commons.math.util.FastMath.min(24L, (long) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24L + "'", long2 == 24L);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.03760197886023983d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        double double2 = org.apache.commons.math.util.FastMath.pow(2.48941808405721d, (-35.29684161812119d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0447136585535002E-14d + "'", double2 == 1.0447136585535002E-14d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.5772156649015329d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.781072417990198d + "'", double1 == 0.781072417990198d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 2.7209854707924777d, (java.lang.Number) 1, (java.lang.Number) (-0.017453292519943295d));
    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test321");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        long long7 = randomDataImpl1.nextLong((long) (byte) 10, (long) '4');
//        double double10 = randomDataImpl1.nextBeta(1.471127674303735d, 1.1185087377885383d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double13 = normalDistributionImpl11.density(100.0d);
//        double double14 = normalDistributionImpl11.getStandardDeviation();
//        double double15 = normalDistributionImpl11.sample();
//        double double17 = normalDistributionImpl11.cumulativeProbability((double) (byte) 10);
//        double[] doubleArray19 = normalDistributionImpl11.sample((int) (byte) 100);
//        double double20 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        double double21 = normalDistributionImpl11.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 240.7369240718433d + "'", double4 == 240.7369240718433d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 40L + "'", long7 == 40L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.8233617200173557d + "'", double10 == 0.8233617200173557d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-0.12138524385555713d) + "'", double15 == (-0.12138524385555713d));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
//        org.junit.Assert.assertNotNull(doubleArray19);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-0.6442547081584085d) + "'", double20 == (-0.6442547081584085d));
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
//    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        int int2 = org.apache.commons.math.util.FastMath.min(32, 20);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test323");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        randomDataImpl1.reSeed();
//        try {
//            int int13 = randomDataImpl1.nextPascal(47, 3.241723184387021d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 3.242 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-2.6464678544478426d) + "'", double4 == (-2.6464678544478426d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.13610333305888847d + "'", double6 == 0.13610333305888847d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
//    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.6439528600818949d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8635444397314518d + "'", double1 == 0.8635444397314518d);
    }

//    @Test
//    public void test326() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test326");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.4711276743037347d, (double) 1L);
//        double double3 = normalDistributionImpl2.sample();
//        double double5 = normalDistributionImpl2.density((double) (-1));
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.3984169833165265d + "'", double3 == 1.3984169833165265d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.018832436981002204d + "'", double5 == 0.018832436981002204d);
//    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 8, (float) 52L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 8.0f + "'", float2 == 8.0f);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(2.7144176165949068d, (double) 20);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.29299166564974943d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3016737816034727d + "'", double1 == 0.3016737816034727d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 6.0d, (java.lang.Number) 8.054359047689252E13d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number12 = numberIsTooLargeException11.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray18);
        java.lang.Object[] objArray21 = new java.lang.Object[] { objArray18, "" };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException11, localizable13, objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("", objArray18);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("", objArray18);
        org.apache.commons.math.exception.util.Localizable localizable25 = mathException24.getGeneralPattern();
        java.lang.Number number26 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException(localizable25, number26, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray34 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray34);
        java.lang.String str36 = maxIterationsExceededException35.getPattern();
        java.lang.Object[] objArray37 = maxIterationsExceededException35.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable25, objArray37);
        org.apache.commons.math.exception.util.Localizable localizable39 = maxIterationsExceededException38.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException41 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.util.Localizable localizable42 = notStrictlyPositiveException41.getSpecificPattern();
        java.lang.Throwable[] throwableArray43 = notStrictlyPositiveException41.getSuppressed();
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException(localizable39, (java.lang.Object[]) throwableArray43);
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException51 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number52 = numberIsTooLargeException51.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        java.lang.Object[] objArray58 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException59 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray58);
        java.lang.Object[] objArray61 = new java.lang.Object[] { objArray58, "" };
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException51, localizable53, objArray58);
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException("", objArray58);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException64 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable46, objArray58);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable39, objArray58);
        java.lang.Number number66 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException69 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, number66, (java.lang.Number) 12.801827480081469d, false);
        boolean boolean70 = numberIsTooLargeException69.getBoundIsAllowed();
        java.lang.Number number71 = numberIsTooLargeException69.getArgument();
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException69);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.0d) + "'", number12.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(localizable25);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(localizable39);
        org.junit.Assert.assertNull(localizable42);
        org.junit.Assert.assertNotNull(throwableArray43);
        org.junit.Assert.assertTrue("'" + number52 + "' != '" + (-1.0d) + "'", number52.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNull(number71);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray4);
        java.lang.String str6 = maxIterationsExceededException5.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray17);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray17);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable10, objArray17);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException("", objArray17);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException5, localizable7, objArray17);
        java.lang.Class<?> wildcardClass23 = convergenceException22.getClass();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        double double2 = org.apache.commons.math.util.FastMath.min(Double.NEGATIVE_INFINITY, 0.18779231121495946d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test333");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        randomDataImpl1.reSeed((-1L));
//        double double14 = randomDataImpl1.nextF(1.0d, 1.471127674303735d);
//        try {
//            long long17 = randomDataImpl1.nextSecureLong((long) 'a', (long) 3);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than, or equal to, the maximum (3): lower bound (97) must be strictly less than upper bound (3)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.35723523629132603d + "'", double4 == 0.35723523629132603d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2155369919302479d + "'", double6 == 0.2155369919302479d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 8L + "'", long9 == 8L);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.1715896056734334d + "'", double14 == 0.1715896056734334d);
//    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        double double2 = org.apache.commons.math.util.FastMath.atan2(7.799533480847564d, (double) 47);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.16444888649579864d + "'", double2 == 0.16444888649579864d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        double double1 = org.apache.commons.math.special.Gamma.digamma(0.5264888286059799d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.8384102186399753d) + "'", double1 == (-1.8384102186399753d));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        long long2 = org.apache.commons.math.util.FastMath.min(1L, 25L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        double double2 = org.apache.commons.math.util.FastMath.pow(2.0d, (double) (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5d + "'", double2 == 0.5d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, 2.7209854707924777d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

//    @Test
//    public void test339() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test339");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        long long7 = randomDataImpl1.nextLong((long) (byte) 10, (long) '4');
//        double double10 = randomDataImpl1.nextF(0.7400576788232446d, 0.8018974326990581d);
//        java.lang.Class<?> wildcardClass11 = randomDataImpl1.getClass();
//        try {
//            int int14 = randomDataImpl1.nextSecureInt(20, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 20 is larger than, or equal to, the maximum (0): lower bound (20) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.481228486015435d) + "'", double4 == (-0.481228486015435d));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 22L + "'", long7 == 22L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.302077596163127d + "'", double10 == 0.302077596163127d);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        double double1 = org.apache.commons.math.util.FastMath.abs(7.03450956421152d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.03450956421152d + "'", double1 == 7.03450956421152d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        long long2 = org.apache.commons.math.util.FastMath.min(6L, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 5L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9589242746631385d) + "'", double1 == (-0.9589242746631385d));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        double double2 = org.apache.commons.math.util.FastMath.min(1.4210854715202004E-14d, 0.05296404435055778d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4210854715202004E-14d + "'", double2 == 1.4210854715202004E-14d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-0.03791350525567447d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.03790442809979912d) + "'", double1 == (-0.03790442809979912d));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray4);
        java.lang.String str6 = maxIterationsExceededException5.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray17);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray17);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable10, objArray17);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException("", objArray17);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException5, localizable7, objArray17);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException5);
        java.lang.Object[] objArray24 = mathException23.getArguments();
        java.lang.Throwable[] throwableArray25 = mathException23.getSuppressed();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(throwableArray25);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        double double1 = org.apache.commons.math.util.FastMath.ulp(3.608826080138695d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) 5L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2213229557370451d + "'", double1 == 0.2213229557370451d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.011867787460032826d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000704230161497d + "'", double1 == 1.0000704230161497d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-35.29684161812119d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0670715664430842E15d + "'", double1 == 1.0670715664430842E15d);
    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test350");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double1 = normalDistributionImpl0.sample();
//        double double3 = normalDistributionImpl0.cumulativeProbability(2.767576814789016d);
//        double double4 = normalDistributionImpl0.getMean();
//        normalDistributionImpl0.reseedRandomGenerator((-1L));
//        try {
//            double double9 = normalDistributionImpl0.cumulativeProbability(0.16087055809932455d, 0.0d);
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.9619520955672083d) + "'", double1 == (-1.9619520955672083d));
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.9971762632543613d + "'", double3 == 0.9971762632543613d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
//    }

//    @Test
//    public void test351() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test351");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        double double9 = randomDataImpl1.nextGaussian(23.999999999999996d, (double) 4L);
//        try {
//            long long12 = randomDataImpl1.nextLong(47L, (long) 4);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 47 is larger than, or equal to, the maximum (4): lower bound (47) must be strictly less than upper bound (4)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.1369359843123181d) + "'", double4 == (-1.1369359843123181d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5673816262998315d + "'", double6 == 0.5673816262998315d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 21.961140229029457d + "'", double9 == 21.961140229029457d);
//    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 0.65382533884505d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0380377007567323d, (java.lang.Number) 2.0d, true);
    }

//    @Test
//    public void test354() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test354");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) (byte) 1);
//        double double5 = randomDataImpl1.nextT((double) 8);
//        randomDataImpl1.reSeed();
//        try {
//            int int9 = randomDataImpl1.nextPascal((int) (short) 10, (-0.015722159129280943d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -0.016 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.3999061311498836d) + "'", double3 == (-0.3999061311498836d));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.537236023708778d + "'", double5 == 3.537236023708778d);
//    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        double double2 = org.apache.commons.math.util.FastMath.max(1.448271094386676d, 0.9060765469822909d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.448271094386676d + "'", double2 == 1.448271094386676d);
    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test357");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        randomDataImpl1.reSeed();
//        try {
//            int int13 = randomDataImpl1.nextInt((int) (byte) 10, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 10 is larger than, or equal to, the maximum (0): lower bound (10) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.9172305715297784d) + "'", double4 == (-0.9172305715297784d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.4009374130718412d + "'", double6 == 0.4009374130718412d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.0d, (-1.0d), (-0.9589242746631385d), (int) ' ');
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-0.008252437515514003d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test361");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) 'a');
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution12 = null;
//        try {
//            int int13 = randomDataImpl1.nextInversionDeviate(integerDistribution12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 25.29326595052651d + "'", double4 == 25.29326595052651d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.004081955963258662d + "'", double6 == 0.004081955963258662d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 8 + "'", int9 == 8);
//    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.13679043518599884d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.13722066291900362d + "'", double1 == 0.13722066291900362d);
    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test363");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        try {
//            int int14 = randomDataImpl1.nextPascal((int) (byte) 10, (-1.8384102186399753d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -1.838 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 24.01644266657155d + "'", double4 == 24.01644266657155d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.03799190284410972d + "'", double6 == 0.03799190284410972d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
//    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.164058273003315d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.06597472173167046d + "'", double1 == 0.06597472173167046d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.38605328091083446d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.37653510734157053d + "'", double1 == 0.37653510734157053d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.4831981102579275d);
    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test367");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        double double14 = randomDataImpl1.nextT(0.7627350637656639d);
//        double double17 = randomDataImpl1.nextCauchy(0.5061169493981285d, 5.853949697499888d);
//        randomDataImpl1.reSeed(5L);
//        try {
//            int[] intArray22 = randomDataImpl1.nextPermutation((int) (short) 1, 8);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 8 is larger than the maximum (1): permutation size (8) exceeds permuation domain (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 21.513561092704997d + "'", double4 == 21.513561092704997d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08299836635326605d + "'", double6 == 0.08299836635326605d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.7395496752597057d + "'", double14 == 2.7395496752597057d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-15.077303836022084d) + "'", double17 == (-15.077303836022084d));
//    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        double double1 = org.apache.commons.math.util.FastMath.cos(26.983826832980125d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.27663364868004303d) + "'", double1 == (-0.27663364868004303d));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test370");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        int int12 = randomDataImpl1.nextZipf(100, 2.718281828459045d);
//        double double14 = randomDataImpl1.nextT(0.9986169222235228d);
//        double double17 = randomDataImpl1.nextCauchy(23.999999999999996d, 5.865998271154641d);
//        double double20 = randomDataImpl1.nextF(0.6437732281381782d, (double) 3L);
//        try {
//            long long23 = randomDataImpl1.nextLong(11L, (-1L));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 11 is larger than, or equal to, the maximum (-1): lower bound (11) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 26.46639110963391d + "'", double4 == 26.46639110963391d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.426280313232519d + "'", double6 == 4.426280313232519d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 6L + "'", long9 == 6L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 6.739525751827947d + "'", double14 == 6.739525751827947d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 22.4427381820997d + "'", double17 == 22.4427381820997d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.07900771235552591d + "'", double20 == 0.07900771235552591d);
//    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("org.apache.commons.math.MathException: hi!", objArray1);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 5L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 74.20994852478785d + "'", double1 == 74.20994852478785d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than, or equal to, the maximum (10)", objArray2);
    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test374");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        randomDataImpl1.reSeed();
//        double double13 = randomDataImpl1.nextCauchy(5.853949697499888d, 0.006937366662896952d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution14 = null;
//        try {
//            int int15 = randomDataImpl1.nextInversionDeviate(integerDistribution14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.592271927171504d + "'", double4 == 7.592271927171504d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5388279900746299d + "'", double6 == 0.5388279900746299d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 7L + "'", long9 == 7L);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 5.863880493899001d + "'", double13 == 5.863880493899001d);
//    }

//    @Test
//    public void test375() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test375");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl0.density(100.0d);
//        double double3 = normalDistributionImpl0.getStandardDeviation();
//        double double4 = normalDistributionImpl0.sample();
//        double double5 = normalDistributionImpl0.getStandardDeviation();
//        double double6 = normalDistributionImpl0.getStandardDeviation();
//        double double7 = normalDistributionImpl0.sample();
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.6572074083967125d + "'", double4 == 0.6572074083967125d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.530197124927653d) + "'", double7 == (-0.530197124927653d));
//    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, number1);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.05746016866185325d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.292225154434066d + "'", double1 == 3.292225154434066d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (byte) 10, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) 0.0f);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, (java.lang.Number) (short) 100, (java.lang.Number) 0.8813735870195429d, (java.lang.Number) 100);
        java.lang.Number number10 = outOfRangeException9.getLo();
        java.lang.Throwable[] throwableArray11 = outOfRangeException9.getSuppressed();
        java.lang.Number number12 = outOfRangeException9.getHi();
        org.apache.commons.math.exception.util.Localizable localizable13 = outOfRangeException9.getGeneralPattern();
        outOfRangeException4.addSuppressed((java.lang.Throwable) outOfRangeException9);
        java.lang.Number number15 = outOfRangeException9.getLo();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0.8813735870195429d + "'", number10.equals(0.8813735870195429d));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 100 + "'", number12.equals(100));
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 0.8813735870195429d + "'", number15.equals(0.8813735870195429d));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.2911771639660623d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.4999921339008419d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4999921339008419d + "'", double1 == 0.4999921339008419d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.99299442949858d, 0.8484181564217285d, (double) (-1));
        double[] doubleArray5 = normalDistributionImpl3.sample(5);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2722218725854067E-14d + "'", double1 == 1.2722218725854067E-14d);
    }

//    @Test
//    public void test383() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test383");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT(4.599102285891914d);
//        double double6 = randomDataImpl1.nextGaussian(1.1142547833872074E-7d, 0.02398007912785791d);
//        java.lang.Class<?> wildcardClass7 = randomDataImpl1.getClass();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0714335840328193d + "'", double3 == 1.0714335840328193d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-0.010675567818099021d) + "'", double6 == (-0.010675567818099021d));
//        org.junit.Assert.assertNotNull(wildcardClass7);
//    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        double double1 = org.apache.commons.math.util.FastMath.atanh(5.775284847419849d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 10L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(11.471265370754681d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.471265370754683d + "'", double1 == 11.471265370754683d);
    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test387");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) (byte) 1);
//        double double5 = randomDataImpl1.nextT((double) 8);
//        randomDataImpl1.reSeed();
//        randomDataImpl1.reSeedSecure();
//        try {
//            randomDataImpl1.setSecureAlgorithm("e095a50de7a8cd45e446824941e4345ea9e", "ebea043f5dd776406cba9b84d2e612fd");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: ebea043f5dd776406cba9b84d2e612fd");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-2.686212910569249d) + "'", double3 == (-2.686212910569249d));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.022839810888509664d) + "'", double5 == (-0.022839810888509664d));
//    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.29299166564974943d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.29720163021279145d + "'", double1 == 0.29720163021279145d);
    }

//    @Test
//    public void test389() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test389");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        randomDataImpl1.reSeed((-1L));
//        try {
//            int[] intArray14 = randomDataImpl1.nextPermutation((int) (byte) 10, (int) '4');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 52 is larger than the maximum (10): permutation size (52) exceeds permuation domain (10)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-16.826138338122036d) + "'", double4 == (-16.826138338122036d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.4638431555889673d + "'", double6 == 2.4638431555889673d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 8L + "'", long9 == 8L);
//    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.13722066291900362d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.154434690031884d + "'", double1 == 2.154434690031884d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-1), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

//    @Test
//    public void test393() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test393");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        int int12 = randomDataImpl1.nextZipf(100, 2.718281828459045d);
//        double double15 = randomDataImpl1.nextCauchy(2.092790987315211d, 0.8813735870195429d);
//        double double18 = randomDataImpl1.nextGaussian((double) 10.0f, (double) 8);
//        try {
//            long long20 = randomDataImpl1.nextPoisson((double) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-13.867666776918396d) + "'", double4 == (-13.867666776918396d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08586872400851056d + "'", double6 == 0.08586872400851056d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.049305841088669d + "'", double15 == 2.049305841088669d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 9.43522231782906d + "'", double18 == 9.43522231782906d);
//    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(5.896662418833589d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.428304432898311d + "'", double1 == 2.428304432898311d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        double double1 = org.apache.commons.math.special.Erf.erf(0.0010095241802400181d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0011391256666861732d + "'", double1 == 0.0011391256666861732d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        double double1 = org.apache.commons.math.special.Gamma.digamma(5.391022392535616d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5891306489769716d + "'", double1 == 1.5891306489769716d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.302585092994046d + "'", double1 == 2.302585092994046d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

//    @Test
//    public void test399() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test399");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl0.density(100.0d);
//        double double3 = normalDistributionImpl0.sample();
//        double[] doubleArray5 = normalDistributionImpl0.sample(5);
//        try {
//            double double8 = normalDistributionImpl0.cumulativeProbability(9.108754203495801d, 0.13653950079971308d);
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.1488901105203095d) + "'", double3 == (-0.1488901105203095d));
//        org.junit.Assert.assertNotNull(doubleArray5);
//    }

//    @Test
//    public void test400() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test400");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl0.density(100.0d);
//        double double3 = normalDistributionImpl0.sample();
//        double double6 = normalDistributionImpl0.cumulativeProbability((-5.998713782709511d), 2.7209854707924777d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.7363591225007852d) + "'", double3 == (-0.7363591225007852d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.9967456178959979d + "'", double6 == 0.9967456178959979d);
//    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 155.74607629780772d, (java.lang.Number) 1.333707301036022d);
        java.lang.Number number4 = outOfRangeException3.getHi();
        java.lang.Number number5 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.333707301036022d + "'", number4.equals(1.333707301036022d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 155.74607629780772d + "'", number5.equals(155.74607629780772d));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        int int2 = org.apache.commons.math.util.FastMath.min(3, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.9986169222235228d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6924554024483952d + "'", double1 == 0.6924554024483952d);
    }

//    @Test
//    public void test405() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test405");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl0.density(100.0d);
//        double double3 = normalDistributionImpl0.sample();
//        double double5 = normalDistributionImpl0.cumulativeProbability((double) 9L);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.19996276533381324d + "'", double3 == 0.19996276533381324d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
//    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        double double1 = org.apache.commons.math.special.Erf.erf(4.672738657069999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999999611111d + "'", double1 == 0.9999999999611111d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 2.718281828459045d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 10, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.2610288642034437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2610288642034437d + "'", double1 == 1.2610288642034437d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.1472057710510555d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1472057710510555d + "'", double1 == 0.1472057710510555d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.3324239006691985d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7631912032574635d + "'", double1 == 1.7631912032574635d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray4);
        java.lang.String str6 = maxIterationsExceededException5.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray17);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray17);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable10, objArray17);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException("", objArray17);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException5, localizable7, objArray17);
        java.lang.Throwable[] throwableArray23 = maxIterationsExceededException5.getSuppressed();
        int int24 = maxIterationsExceededException5.getMaxIterations();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, number2, (java.lang.Number) (-0.17738444574517354d), true);
        java.lang.Throwable[] throwableArray6 = numberIsTooSmallException5.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException(localizable0, (java.lang.Object[]) throwableArray6);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100.0f, (java.lang.Number) 10.0f, false);
        convergenceException7.addSuppressed((java.lang.Throwable) numberIsTooSmallException11);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-0.577290349936525d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1713114974625016d + "'", double1 == 1.1713114974625016d);
    }

//    @Test
//    public void test415() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test415");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        randomDataImpl1.reSeed((-1L));
//        int int14 = randomDataImpl1.nextZipf(1, 0.9379198162596534d);
//        randomDataImpl1.reSeed();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 146.16516156047945d + "'", double4 == 146.16516156047945d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.14118195393467486d + "'", double6 == 0.14118195393467486d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number7 = numberIsTooLargeException6.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray13);
        java.lang.Object[] objArray16 = new java.lang.Object[] { objArray13, "" };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException6, localizable8, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("", objArray13);
        org.apache.commons.math.exception.util.Localizable localizable20 = mathException19.getGeneralPattern();
        java.lang.Number number21 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException(localizable20, number21, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray29 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray29);
        java.lang.String str31 = maxIterationsExceededException30.getPattern();
        java.lang.Object[] objArray32 = maxIterationsExceededException30.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable20, objArray32);
        org.apache.commons.math.exception.util.Localizable localizable34 = maxIterationsExceededException33.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException36 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable34, (java.lang.Number) 1.7387963814485965d);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1.0d) + "'", number7.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(localizable34);
    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test417");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        java.lang.String str8 = randomDataImpl1.nextSecureHexString((int) '#');
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString((int) ' ');
//        try {
//            double double13 = randomDataImpl1.nextCauchy(0.13519368159152453d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): scale (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-78.61161165248686d) + "'", double4 == (-78.61161165248686d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.24275015469427d + "'", double6 == 0.24275015469427d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "eb008067ef33bc1cad48d5dd16c26826902" + "'", str8.equals("eb008067ef33bc1cad48d5dd16c26826902"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "7878063319803d2dd16ab4b2daba10ff" + "'", str10.equals("7878063319803d2dd16ab4b2daba10ff"));
//    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(8.739797322809835d, 0.001369353897744088d, 0.0010095241802400181d, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (0) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-0.8945632653807307d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-51.254699613757296d) + "'", double1 == (-51.254699613757296d));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(5.853949697499888d, 1.1142547833872074E-7d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        int int2 = org.apache.commons.math.util.FastMath.max(0, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number6 = numberIsTooLargeException5.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray12);
        java.lang.Object[] objArray15 = new java.lang.Object[] { objArray12, "" };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException5, localizable7, objArray12);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("", objArray12);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("", objArray12);
        org.apache.commons.math.exception.util.Localizable localizable19 = mathException18.getGeneralPattern();
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException(localizable19, number20, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Number number24 = outOfRangeException23.getLo();
        java.lang.Throwable[] throwableArray25 = outOfRangeException23.getSuppressed();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1.0d) + "'", number6.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (byte) 0 + "'", number24.equals((byte) 0));
        org.junit.Assert.assertNotNull(throwableArray25);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 47L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.4711276743037347d, (double) 1L);
        double double3 = normalDistributionImpl2.getStandardDeviation();
        double double5 = normalDistributionImpl2.density(2.220446049250313E-16d);
        double double6 = normalDistributionImpl2.getMean();
        double double9 = normalDistributionImpl2.cumulativeProbability((-0.530197124927653d), 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.13519368159152453d + "'", double5 == 0.13519368159152453d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.4711276743037347d + "'", double6 == 1.4711276743037347d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.04794959660230114d + "'", double9 == 0.04794959660230114d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.9379198162596534d, 0.8813735870195429d, 14.711890248661776d);
        double double6 = normalDistributionImpl3.cumulativeProbability(4.265278032032717E-17d, 2.169050661553112d);
        double double7 = normalDistributionImpl3.getMean();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.7751391482829826d + "'", double6 == 0.7751391482829826d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.9379198162596534d + "'", double7 == 0.9379198162596534d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.008726646259971648d + "'", double1 == 0.008726646259971648d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(1.164058273003315d, (double) 1L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.4379732815178231d + "'", double2 == 0.4379732815178231d);
    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test428");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        try {
//            long long7 = randomDataImpl1.nextSecureLong(0L, 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (0): lower bound (0) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-2.1681446235318775d) + "'", double4 == (-2.1681446235318775d));
//    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 0, (double) 18);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray11);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray11);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable4, objArray11);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("", objArray11);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException16 = new org.apache.commons.math.MaxIterationsExceededException(8, "org.apache.commons.math.MathException: ", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException24 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number25 = numberIsTooLargeException24.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray31);
        java.lang.Object[] objArray34 = new java.lang.Object[] { objArray31, "" };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException24, localizable26, objArray31);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, objArray31);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', "", objArray31);
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException16, localizable17, objArray31);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + (-1.0d) + "'", number25.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray34);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray4);
        java.lang.String str6 = maxIterationsExceededException5.getPattern();
        java.lang.String str7 = maxIterationsExceededException5.toString();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException5);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException5);
        java.lang.Object[] objArray10 = maxIterationsExceededException5.getArguments();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: hi!" + "'", str7.equals("org.apache.commons.math.MaxIterationsExceededException: hi!"));
        org.junit.Assert.assertNotNull(objArray10);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(19);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.9002507367077104d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.687571051624795d + "'", double1 == 5.687571051624795d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(4.47559368552185d, 1.1142547833872074E-7d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5112000488548166E-33d + "'", double2 == 1.5112000488548166E-33d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(117.18421228326486d, 0.2857504987187536d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4029534486805868E-257d + "'", double2 == 1.4029534486805868E-257d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 32);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 32L + "'", long1 == 32L);
    }

//    @Test
//    public void test437() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test437");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) (byte) 1);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double6 = normalDistributionImpl4.density(100.0d);
//        double double7 = normalDistributionImpl4.getStandardDeviation();
//        double double8 = normalDistributionImpl4.sample();
//        double double10 = normalDistributionImpl4.cumulativeProbability((double) (byte) 10);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        try {
//            int int14 = randomDataImpl1.nextBinomial(0, 1.5733786539228416d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 1.573 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.9935178607796693d) + "'", double3 == (-0.9935178607796693d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-0.8364955000927379d) + "'", double8 == (-0.8364955000927379d));
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.4685603690102675d) + "'", double11 == (-1.4685603690102675d));
//    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 4.672738657069999d);
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number9 = numberIsTooLargeException8.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException16 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray15);
        java.lang.Object[] objArray18 = new java.lang.Object[] { objArray15, "" };
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException8, localizable10, objArray15);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException2, "", objArray15);
        java.lang.String str21 = convergenceException20.getPattern();
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0d) + "'", number9.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.045307020123132084d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9989738125219486d + "'", double1 == 0.9989738125219486d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        double double1 = org.apache.commons.math.special.Erf.erf(0.9436379339725438d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8179617754648578d + "'", double1 == 0.8179617754648578d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 32.0f);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.3518548721102766d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.2966178050570343d) + "'", double1 == (-0.2966178050570343d));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.4711276743037347d, (double) (byte) 0, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.11876664467085814d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1261071045310234d + "'", double1 == 1.1261071045310234d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 0.04666813117966975d, (java.lang.Number) (-0.02422157392596903d), false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(2.8366339028103726d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 162.5271506547573d + "'", double1 == 162.5271506547573d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number7 = numberIsTooLargeException6.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray13);
        java.lang.Object[] objArray16 = new java.lang.Object[] { objArray13, "" };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException6, localizable8, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("", objArray13);
        org.apache.commons.math.exception.util.Localizable localizable20 = mathException19.getGeneralPattern();
        java.lang.Number number21 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException(localizable20, number21, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray29 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray29);
        java.lang.String str31 = maxIterationsExceededException30.getPattern();
        java.lang.Object[] objArray32 = maxIterationsExceededException30.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable20, objArray32);
        org.apache.commons.math.exception.util.Localizable localizable34 = maxIterationsExceededException33.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException36 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.util.Localizable localizable37 = notStrictlyPositiveException36.getSpecificPattern();
        java.lang.Throwable[] throwableArray38 = notStrictlyPositiveException36.getSuppressed();
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException(localizable34, (java.lang.Object[]) throwableArray38);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException41 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable34, (java.lang.Number) 1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1.0d) + "'", number7.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(localizable34);
        org.junit.Assert.assertNull(localizable37);
        org.junit.Assert.assertNotNull(throwableArray38);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        double double1 = org.apache.commons.math.special.Erf.erf((-0.4064624400499381d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4345901367330447d) + "'", double1 == (-0.4345901367330447d));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 52L, (float) 97);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number7 = numberIsTooLargeException6.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray13);
        java.lang.Object[] objArray16 = new java.lang.Object[] { objArray13, "" };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException6, localizable8, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("", objArray13);
        org.apache.commons.math.exception.util.Localizable localizable20 = mathException19.getGeneralPattern();
        java.lang.Number number21 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException(localizable20, number21, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray29 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray29);
        java.lang.String str31 = maxIterationsExceededException30.getPattern();
        java.lang.Object[] objArray32 = maxIterationsExceededException30.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable20, objArray32);
        int int34 = maxIterationsExceededException33.getMaxIterations();
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1.0d) + "'", number7.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 97 + "'", int34 == 97);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.38605328091083446d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test455() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test455");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        double double14 = randomDataImpl1.nextT(0.7627350637656639d);
//        double double17 = randomDataImpl1.nextCauchy(0.5061169493981285d, 5.853949697499888d);
//        try {
//            int int20 = randomDataImpl1.nextPascal(1, 4.599102285891914d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 4.599 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.26921213202939787d + "'", double4 == 0.26921213202939787d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.9988716693947943d + "'", double6 == 0.9988716693947943d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-2.2970249428580063d) + "'", double14 == (-2.2970249428580063d));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-3.7108038508425043d) + "'", double17 == (-3.7108038508425043d));
//    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number7 = numberIsTooLargeException6.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray13);
        java.lang.Object[] objArray16 = new java.lang.Object[] { objArray13, "" };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException6, localizable8, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("", objArray13);
        org.apache.commons.math.exception.util.Localizable localizable20 = mathException19.getGeneralPattern();
        java.lang.Number number21 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException(localizable20, number21, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray29 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray29);
        java.lang.String str31 = maxIterationsExceededException30.getPattern();
        java.lang.Object[] objArray32 = maxIterationsExceededException30.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable20, objArray32);
        org.apache.commons.math.exception.util.Localizable localizable34 = maxIterationsExceededException33.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException36 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.util.Localizable localizable37 = notStrictlyPositiveException36.getSpecificPattern();
        java.lang.Throwable[] throwableArray38 = notStrictlyPositiveException36.getSuppressed();
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException(localizable34, (java.lang.Object[]) throwableArray38);
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        java.lang.Number number41 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException44 = new org.apache.commons.math.exception.NumberIsTooSmallException(number41, (java.lang.Number) 100, false);
        org.apache.commons.math.exception.util.Localizable localizable45 = numberIsTooSmallException44.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException(localizable48, objArray49);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than, or equal to, the maximum (10)", objArray49);
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException44, "org.apache.commons.math.MaxIterationsExceededException: hi!", objArray49);
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException(localizable40, objArray49);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException(localizable34, objArray49);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException61 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number62 = numberIsTooLargeException61.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable63 = null;
        java.lang.Object[] objArray68 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException69 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray68);
        java.lang.Object[] objArray71 = new java.lang.Object[] { objArray68, "" };
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException61, localizable63, objArray68);
        org.apache.commons.math.ConvergenceException convergenceException73 = new org.apache.commons.math.ConvergenceException("", objArray68);
        org.apache.commons.math.MathException mathException74 = new org.apache.commons.math.MathException("", objArray68);
        org.apache.commons.math.exception.util.Localizable localizable75 = mathException74.getGeneralPattern();
        java.lang.Number number76 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException79 = new org.apache.commons.math.exception.OutOfRangeException(localizable75, number76, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray84 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException85 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray84);
        java.lang.String str86 = maxIterationsExceededException85.getPattern();
        java.lang.Object[] objArray87 = maxIterationsExceededException85.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException88 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable75, objArray87);
        org.apache.commons.math.ConvergenceException convergenceException89 = new org.apache.commons.math.ConvergenceException(localizable34, objArray87);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException93 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable34, (java.lang.Number) 0.05260031770763203d, (java.lang.Number) 2, true);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1.0d) + "'", number7.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(localizable34);
        org.junit.Assert.assertNull(localizable37);
        org.junit.Assert.assertNotNull(throwableArray38);
        org.junit.Assert.assertNull(localizable45);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertTrue("'" + number62 + "' != '" + (-1.0d) + "'", number62.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray68);
        org.junit.Assert.assertNotNull(objArray71);
        org.junit.Assert.assertNotNull(localizable75);
        org.junit.Assert.assertNotNull(objArray84);
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "hi!" + "'", str86.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray87);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.471127674303735d);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

//    @Test
//    public void test458() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test458");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT(4.599102285891914d);
//        randomDataImpl1.reSeedSecure();
//        try {
//            java.lang.String str6 = randomDataImpl1.nextHexString((-1));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): length (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.33626501585153706d) + "'", double3 == (-0.33626501585153706d));
//    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 7.0f, 1.5625640275552255d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5625640275552255d + "'", double2 == 1.5625640275552255d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray10);
        java.lang.Object[] objArray13 = new java.lang.Object[] { objArray10, "" };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3, localizable5, objArray10);
        java.lang.Object[] objArray15 = numberIsTooLargeException3.getArguments();
        java.lang.Number number16 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0d) + "'", number4.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 10.0f + "'", number16.equals(10.0f));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 5L);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 1, 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
    }

//    @Test
//    public void test463() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test463");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) (byte) 1);
//        double double5 = randomDataImpl1.nextT((double) 8);
//        randomDataImpl1.reSeed();
//        double double8 = randomDataImpl1.nextChiSquare((double) 100L);
//        try {
//            double double11 = randomDataImpl1.nextCauchy((double) 4L, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): scale (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.37705069777162964d) + "'", double3 == (-0.37705069777162964d));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.4432437547504195d) + "'", double5 == (-1.4432437547504195d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 95.28034803376688d + "'", double8 == 95.28034803376688d);
//    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        double double1 = org.apache.commons.math.special.Erf.erf(0.4956517277880427d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5166703962734769d + "'", double1 == 0.5166703962734769d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.8635444397314518d, 0.6483059661666595d, 2.4746473287171966d, 7);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.6213153229208016d + "'", double4 == 0.6213153229208016d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-0.8390715290764524d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) 1, 11L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        double double1 = org.apache.commons.math.special.Gamma.digamma(1.466070329168668E-11d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.82095517597379E10d) + "'", double1 == (-6.82095517597379E10d));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 100L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        double double1 = org.apache.commons.math.util.FastMath.rint((-1.982621331658684d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.0d) + "'", double1 == (-2.0d));
    }

//    @Test
//    public void test471() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test471");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        int int12 = randomDataImpl1.nextZipf(100, 2.718281828459045d);
//        double double14 = randomDataImpl1.nextT(0.9986169222235228d);
//        try {
//            randomDataImpl1.setSecureAlgorithm("e095a50de7a8cd45e446824941e4345ea9e", "8cc2d200cc");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 8cc2d200cc");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-5.665257435215109d) + "'", double4 == (-5.665257435215109d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.6422612725471755d + "'", double6 == 0.6422612725471755d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 6.058396573941296d + "'", double14 == 6.058396573941296d);
//    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.1713114974625016d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5772903499365252d + "'", double1 == 0.5772903499365252d);
    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test473");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        double double14 = randomDataImpl1.nextT(0.7627350637656639d);
//        double double17 = randomDataImpl1.nextGaussian((double) (byte) 1, 0.29495535414077817d);
//        randomDataImpl1.reSeedSecure((long) 100);
//        int int22 = randomDataImpl1.nextSecureInt((int) (byte) 10, (int) (byte) 100);
//        try {
//            randomDataImpl1.setSecureAlgorithm("ebea043f5dd776406cba9b84d2e612fd", "org.apache.commons.math.MathException: ");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: org.apache.commons.math.MathException: ");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-11.696878298091294d) + "'", double4 == (-11.696878298091294d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.065236051841571d + "'", double6 == 0.065236051841571d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-0.1219194286999656d) + "'", double14 == (-0.1219194286999656d));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.231059176454815d + "'", double17 == 1.231059176454815d);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 92 + "'", int22 == 92);
//    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.7387963814485965d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray6);
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException(localizable1, objArray6);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("org.apache.commons.math.MathException: hi!", objArray6);
        org.junit.Assert.assertNotNull(objArray6);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        float float1 = org.apache.commons.math.util.FastMath.abs(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.9849186773131968d, 0.004343531641415982d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9849186773131967d + "'", double2 == 0.9849186773131967d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.1713114974625016d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7753313617011479d + "'", double1 == 0.7753313617011479d);
    }

//    @Test
//    public void test479() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test479");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        int int9 = randomDataImpl1.nextInt((int) (short) 0, (int) (byte) 10);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        randomDataImpl1.reSeedSecure();
//        double double14 = randomDataImpl1.nextT(0.7627350637656639d);
//        double double17 = randomDataImpl1.nextCauchy(0.5061169493981285d, 5.853949697499888d);
//        try {
//            int int20 = randomDataImpl1.nextBinomial((int) (byte) 10, 162.5271506547573d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 162.527 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.816055170887882d) + "'", double4 == (-1.816055170887882d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.032363205937514516d + "'", double6 == 0.032363205937514516d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.534296551700092d + "'", double14 == 4.534296551700092d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 25.04489595269376d + "'", double17 == 25.04489595269376d);
//    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.17453292519943295d, 0.31761547347786634d, 0.8484181564217285d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 61L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5544043524868913d + "'", double1 == 1.5544043524868913d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.8484181564217285d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2504799005021285d + "'", double1 == 1.2504799005021285d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 6.0d, (java.lang.Number) 8.054359047689252E13d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number12 = numberIsTooLargeException11.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray18);
        java.lang.Object[] objArray21 = new java.lang.Object[] { objArray18, "" };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException11, localizable13, objArray18);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("", objArray18);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("", objArray18);
        org.apache.commons.math.exception.util.Localizable localizable25 = mathException24.getGeneralPattern();
        java.lang.Number number26 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException(localizable25, number26, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray34 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray34);
        java.lang.String str36 = maxIterationsExceededException35.getPattern();
        java.lang.Object[] objArray37 = maxIterationsExceededException35.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable25, objArray37);
        org.apache.commons.math.exception.util.Localizable localizable39 = maxIterationsExceededException38.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException41 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.util.Localizable localizable42 = notStrictlyPositiveException41.getSpecificPattern();
        java.lang.Throwable[] throwableArray43 = notStrictlyPositiveException41.getSuppressed();
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException(localizable39, (java.lang.Object[]) throwableArray43);
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException51 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number52 = numberIsTooLargeException51.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        java.lang.Object[] objArray58 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException59 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray58);
        java.lang.Object[] objArray61 = new java.lang.Object[] { objArray58, "" };
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException51, localizable53, objArray58);
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException("", objArray58);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException64 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable46, objArray58);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable39, objArray58);
        java.lang.Number number66 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException69 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, number66, (java.lang.Number) 12.801827480081469d, false);
        org.apache.commons.math.exception.util.Localizable localizable70 = null;
        java.lang.Number number71 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException74 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable70, number71, (java.lang.Number) (-0.17738444574517354d), true);
        java.lang.Throwable[] throwableArray75 = numberIsTooSmallException74.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException76 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, (java.lang.Object[]) throwableArray75);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException80 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 24L, (java.lang.Number) 40.223410238970004d, true);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.0d) + "'", number12.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(localizable25);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(localizable39);
        org.junit.Assert.assertNull(localizable42);
        org.junit.Assert.assertNotNull(throwableArray43);
        org.junit.Assert.assertTrue("'" + number52 + "' != '" + (-1.0d) + "'", number52.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(throwableArray75);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(359.1342053695754d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.1080791808757295d + "'", double1 == 7.1080791808757295d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        double double1 = org.apache.commons.math.util.FastMath.rint((-0.577290349936525d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.7387963814485965d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3203257660284435d + "'", double1 == 1.3203257660284435d);
    }

//    @Test
//    public void test487() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test487");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        long long9 = randomDataImpl1.nextLong((long) (byte) -1, (long) 10);
//        int int12 = randomDataImpl1.nextZipf(100, 2.718281828459045d);
//        long long14 = randomDataImpl1.nextPoisson(1.333707301036022d);
//        randomDataImpl1.reSeedSecure((long) 'a');
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.658714676597928d + "'", double4 == 1.658714676597928d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.8973430661925637d + "'", double6 == 2.8973430661925637d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2L + "'", long9 == 2L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(9);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(12.801827480081469d, (-1.982621331658684d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 12.801827480081467d + "'", double2 == 12.801827480081467d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (byte) 10, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) 0.0f);
        java.lang.Number number5 = outOfRangeException4.getHi();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray18);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray18);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException21 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable11, objArray18);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException("", objArray18);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException(8, "org.apache.commons.math.MathException: ", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException4, "", objArray18);
        java.lang.Number number25 = outOfRangeException4.getLo();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0f + "'", number5.equals(0.0f));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 1.5707963267948966d + "'", number25.equals(1.5707963267948966d));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 8L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.1185087377885383d, (java.lang.Number) 10, (java.lang.Number) 0.0076354937841634045d);
        java.lang.Number number4 = outOfRangeException3.getHi();
        java.lang.Number number5 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.0076354937841634045d + "'", number4.equals(0.0076354937841634045d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10 + "'", number5.equals(10));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (short) 100, (java.lang.Number) 0.8813735870195429d, (java.lang.Number) 100);
        java.lang.Number number5 = outOfRangeException4.getArgument();
        java.lang.Number number6 = outOfRangeException4.getLo();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 100 + "'", number5.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.8813735870195429d + "'", number6.equals(0.8813735870195429d));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) 9);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.60460290274525d + "'", double1 == 10.60460290274525d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number7 = numberIsTooLargeException6.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray13);
        java.lang.Object[] objArray16 = new java.lang.Object[] { objArray13, "" };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException6, localizable8, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("", objArray13);
        org.apache.commons.math.exception.util.Localizable localizable20 = mathException19.getGeneralPattern();
        java.lang.Number number21 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException(localizable20, number21, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray29 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray29);
        java.lang.String str31 = maxIterationsExceededException30.getPattern();
        java.lang.Object[] objArray32 = maxIterationsExceededException30.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable20, objArray32);
        java.lang.Object[] objArray34 = null;
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException(localizable20, objArray34);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException39 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable20, (java.lang.Number) (-0.045307020123132084d), (java.lang.Number) 9L, true);
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        java.lang.Object[] objArray46 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException47 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray46);
        java.lang.String str48 = maxIterationsExceededException47.getPattern();
        java.lang.String str49 = maxIterationsExceededException47.toString();
        java.lang.Object[] objArray50 = maxIterationsExceededException47.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException51 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, localizable41, objArray50);
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException(localizable20, objArray50);
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        java.lang.Number number54 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException57 = new org.apache.commons.math.exception.NumberIsTooSmallException(number54, (java.lang.Number) 100, false);
        org.apache.commons.math.exception.util.Localizable localizable58 = numberIsTooSmallException57.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable61 = null;
        java.lang.Object[] objArray62 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException(localizable61, objArray62);
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than, or equal to, the maximum (10)", objArray62);
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException57, "org.apache.commons.math.MaxIterationsExceededException: hi!", objArray62);
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException(localizable53, objArray62);
        org.apache.commons.math.MathException mathException67 = new org.apache.commons.math.MathException(localizable20, objArray62);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1.0d) + "'", number7.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "hi!" + "'", str48.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: hi!" + "'", str49.equals("org.apache.commons.math.MaxIterationsExceededException: hi!"));
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNull(localizable58);
        org.junit.Assert.assertNotNull(objArray62);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number7 = numberIsTooLargeException6.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray13);
        java.lang.Object[] objArray16 = new java.lang.Object[] { objArray13, "" };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException6, localizable8, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("", objArray13);
        org.apache.commons.math.exception.util.Localizable localizable20 = mathException19.getGeneralPattern();
        java.lang.Number number21 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException(localizable20, number21, (java.lang.Number) (byte) 0, (java.lang.Number) (-0.04527605728197682d));
        java.lang.Object[] objArray29 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray29);
        java.lang.String str31 = maxIterationsExceededException30.getPattern();
        java.lang.Object[] objArray32 = maxIterationsExceededException30.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable20, objArray32);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        java.lang.Object[] objArray41 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException42 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray41);
        java.lang.String str43 = maxIterationsExceededException42.getPattern();
        java.lang.String str44 = maxIterationsExceededException42.toString();
        java.lang.Object[] objArray45 = maxIterationsExceededException42.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException46 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, localizable36, objArray45);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable34, objArray45);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, objArray45);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException53 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, false);
        java.lang.Number number54 = numberIsTooLargeException53.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException61 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray60);
        java.lang.Object[] objArray63 = new java.lang.Object[] { objArray60, "" };
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException53, localizable55, objArray60);
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException("", objArray60);
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException(localizable20, objArray60);
        java.lang.Class<?> wildcardClass67 = objArray60.getClass();
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1.0d) + "'", number7.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "hi!" + "'", str43.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: hi!" + "'", str44.equals("org.apache.commons.math.MaxIterationsExceededException: hi!"));
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertTrue("'" + number54 + "' != '" + (-1.0d) + "'", number54.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertNotNull(wildcardClass67);
    }

//    @Test
//    public void test497() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test497");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy((double) (short) 1, 4.605170185988092d);
//        double double6 = randomDataImpl1.nextChiSquare((double) (short) 1);
//        java.lang.String str8 = randomDataImpl1.nextSecureHexString((int) '#');
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString((int) ' ');
//        try {
//            double double13 = randomDataImpl1.nextBeta(0.47035854412542794d, (-2.892836077235549d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.659");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 6.06854208357887d + "'", double4 == 6.06854208357887d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.47704703821448324d + "'", double6 == 0.47704703821448324d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "d4b8ebed47d8c0919ffaca753e8a9b73889" + "'", str8.equals("d4b8ebed47d8c0919ffaca753e8a9b73889"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2e274bad5f3caee3282ee64bc9a320aa" + "'", str10.equals("2e274bad5f3caee3282ee64bc9a320aa"));
//    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        double double1 = org.apache.commons.math.util.FastMath.asin(16.3084113060053d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (-1), 100.0d };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "hi!", objArray4);
        java.lang.String str6 = maxIterationsExceededException5.getPattern();
        java.lang.String str7 = maxIterationsExceededException5.toString();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException5);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException5);
        java.lang.Object[] objArray10 = mathException9.getArguments();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: hi!" + "'", str7.equals("org.apache.commons.math.MaxIterationsExceededException: hi!"));
        org.junit.Assert.assertNotNull(objArray10);
    }

//    @Test
//    public void test500() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test500");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl0.density(100.0d);
//        double double3 = normalDistributionImpl0.getStandardDeviation();
//        double double4 = normalDistributionImpl0.sample();
//        double double5 = normalDistributionImpl0.getStandardDeviation();
//        double double7 = normalDistributionImpl0.inverseCumulativeProbability(0.8018974326990581d);
//        double double8 = normalDistributionImpl0.getMean();
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.2120407547455465d + "'", double4 == 1.2120407547455465d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.8484181564217285d + "'", double7 == 0.8484181564217285d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
//    }
//}

