import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999958776927d + "'", double1 == 0.9999999958776927d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6931471805599453d + "'", double1 == 0.6931471805599453d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double double2 = org.apache.commons.math.util.FastMath.max((double) ' ', (double) 1L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) '4');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_DIV_ZERO;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = org.apache.commons.math.dfp.Dfp.MAX_EXP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32768 + "'", int0 == 32768);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5574077246549023d) + "'", double1 == (-1.5574077246549023d));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 32768);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 32768L + "'", long1 == 32768L);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 114.59155902616465d + "'", double1 == 114.59155902616465d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = org.apache.commons.math.dfp.Dfp.RADIX;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10000 + "'", int0 == 10000);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        float float1 = org.apache.commons.math.util.FastMath.abs((-1.0f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_INVALID;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.718281828459045d + "'", double1 == 2.718281828459045d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double double1 = org.apache.commons.math.util.FastMath.acos(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) '4', (-1.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.019230769230769232d + "'", double2 == 0.019230769230769232d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int2 = org.apache.commons.math.util.FastMath.min(2, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        double double1 = org.apache.commons.math.util.FastMath.acosh(7.105427357601002E-15d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (short) -1, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9999999999999999d) + "'", double2 == (-0.9999999999999999d));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 10.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        byte byte0 = org.apache.commons.math.dfp.Dfp.QNAN;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 3 + "'", byte0 == (byte) 3);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 32768);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 32768.0f + "'", float1 == 32768.0f);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_UNDERFLOW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1833.4649444186343d + "'", double1 == 1833.4649444186343d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5607966601082315d + "'", double1 == 1.5607966601082315d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        double double1 = org.apache.commons.math.util.FastMath.signum(32.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-1.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 8, (-1.5574077246549023d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.0d + "'", double2 == 8.0d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, number1);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        java.lang.Object[] objArray4 = notStrictlyPositiveException2.getArguments();
        java.lang.Class<?> wildcardClass5 = notStrictlyPositiveException2.getClass();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 8);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 2);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        double double1 = org.apache.commons.math.util.FastMath.rint(114.59155902616465d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 115.0d + "'", double1 == 115.0d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        byte byte0 = org.apache.commons.math.dfp.Dfp.INFINITE;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 1 + "'", byte0 == (byte) 1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        float float2 = org.apache.commons.math.util.FastMath.min((float) '4', (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8623188722876839d + "'", double1 == 0.8623188722876839d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.019230769230769232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.019416871522534d + "'", double1 == 1.019416871522534d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test055");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.5352983268235827d + "'", double0 == 0.5352983268235827d);
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.36787944117144233d + "'", double1 == 0.36787944117144233d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 'a');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int1 = org.apache.commons.math.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1833.4649444186343d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.0d + "'", double1 == 32.0d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 32768.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.0d + "'", double1 == 32.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-0.9999999999999999d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 10);
        double double2 = mersenneTwister1.nextDouble();
        int int3 = mersenneTwister1.nextInt();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.77132064549269d + "'", double2 == 0.77132064549269d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 89128932 + "'", int3 == 89128932);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        byte byte0 = org.apache.commons.math.dfp.Dfp.SNAN;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 2 + "'", byte0 == (byte) 2);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-4218389569722409859L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 10);
        try {
            int int3 = mersenneTwister1.nextInt((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double double1 = org.apache.commons.math.util.FastMath.atan(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4711276743037347d + "'", double1 == 1.4711276743037347d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.Dfp dfp1 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp2 = org.apache.commons.math.dfp.Dfp.copysign(dfp0, dfp1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.691673596021348E41d + "'", double1 == 6.691673596021348E41d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, number1);
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        java.lang.String str4 = notStrictlyPositiveException2.toString();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.0f);
        notStrictlyPositiveException2.addSuppressed((java.lang.Throwable) notStrictlyPositiveException6);
        java.lang.Number number8 = notStrictlyPositiveException6.getMin();
        java.lang.Throwable throwable9 = null;
        try {
            notStrictlyPositiveException6.addSuppressed(throwable9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)" + "'", str4.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0 + "'", number8.equals(0));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_INEXACT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.5607966601082315d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.27632259394013d + "'", double1 == 2.27632259394013d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        long long1 = org.apache.commons.math.util.FastMath.round(0.5352983268235827d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 1283169405);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 0.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test078");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        int int1 = mersenneTwister0.nextInt();
//        boolean boolean2 = mersenneTwister0.nextBoolean();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1131741064 + "'", int1 == 1131741064);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (short) 100, (float) (byte) 3);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.0d + "'", double1 == 32.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.4711276743037347d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025676021633806948d + "'", double1 == 0.025676021633806948d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.0d + "'", double1 == 8.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        int int2 = org.apache.commons.math.util.FastMath.max((int) 'a', 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.5607966601082315d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2493184782545368d + "'", double1 == 1.2493184782545368d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 4589153899890174528L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.5891538998901745E18d + "'", double1 == 4.5891538998901745E18d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.77132064549269d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.880913579642763d + "'", double1 == 0.880913579642763d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 10.0f, 0.9999999958776927d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.999999999999998d + "'", double2 == 9.999999999999998d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp1 = new org.apache.commons.math.dfp.Dfp(dfp0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.8623188722876839d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6218224167640864d + "'", double1 == 0.6218224167640864d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        int[] intArray2 = new int[] { 32768, (short) 1 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        double double1 = org.apache.commons.math.util.FastMath.expm1(6.691673596021348E41d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 4589153899890174528L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) (short) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        double double1 = org.apache.commons.math.util.FastMath.rint(9.999999999999998d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        int int1 = org.apache.commons.math.util.FastMath.round(32768.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32768 + "'", int1 == 32768);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.multiply(dfp7);
        try {
            org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (byte) 100, (double) 97);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E194d + "'", double2 == 1.0E194d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1L));
        byte[] byteArray5 = new byte[] { (byte) 10, (byte) 3, (byte) 10 };
        mersenneTwister1.nextBytes(byteArray5);
        long long7 = mersenneTwister1.nextLong();
        try {
            int int9 = mersenneTwister1.nextInt((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 4589153899890174528L + "'", long7 == 4589153899890174528L);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.36787944117144233d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1L));
        byte[] byteArray5 = new byte[] { (byte) 10, (byte) 3, (byte) 10 };
        mersenneTwister1.nextBytes(byteArray5);
        long long7 = mersenneTwister1.nextLong();
        try {
            int int9 = mersenneTwister1.nextInt(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 4589153899890174528L + "'", long7 == 4589153899890174528L);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, number2);
        boolean boolean4 = notStrictlyPositiveException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { 32768L, 10000, 'a', 10.0d, 1.0d };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException13 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException3, localizable5, localizable6, objArray12);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray12);
        java.lang.Throwable throwable15 = null;
        try {
            mathIllegalArgumentException14.addSuppressed(throwable15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(objArray12);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        double double1 = org.apache.commons.math.util.FastMath.tanh(9.999999999999998d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999958776927d + "'", double1 == 0.9999999958776927d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 10);
        int int3 = mersenneTwister1.nextInt(2);
        int int4 = mersenneTwister1.nextInt();
        int[] intArray7 = new int[] { 1, 32768 };
        mersenneTwister1.setSeed(intArray7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1283169405 + "'", int4 == 1283169405);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 100, (double) (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5807959934815619d + "'", double2 == 1.5807959934815619d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5515679276951895d + "'", double1 == 1.5515679276951895d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) '#');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 35.0f + "'", float1 == 35.0f);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-1), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 10L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1 == 10.0f);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) 1.5515679276951895d, false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (byte) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22025.465794806718d + "'", double1 == 22025.465794806718d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 32768L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 32768L + "'", long1 == 32768L);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        long long1 = org.apache.commons.math.util.FastMath.abs((-4218389569722409859L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 4218389569722409859L + "'", long1 == 4218389569722409859L);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        double double1 = org.apache.commons.math.util.FastMath.acos((-1.5574077246549023d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, number1);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        java.lang.String str4 = notStrictlyPositiveException2.toString();
        java.lang.Throwable[] throwableArray5 = notStrictlyPositiveException2.getSuppressed();
        java.lang.Class<?> wildcardClass6 = throwableArray5.getClass();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)" + "'", str4.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, number1);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        java.lang.String str4 = notStrictlyPositiveException2.toString();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException5 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)" + "'", str4.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.831008000716577E22d + "'", double1 == 3.831008000716577E22d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        java.lang.Object[] objArray5 = new java.lang.Object[] { '4', 2.718281828459045d, roundingMode4 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, number8);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (byte) 100 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException14 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException9, localizable10, localizable11, objArray13);
        mathIllegalArgumentException6.addSuppressed((java.lang.Throwable) notStrictlyPositiveException9);
        java.lang.Throwable throwable16 = null;
        try {
            notStrictlyPositiveException9.addSuppressed(throwable16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (byte) 2, (double) 1L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 89128932, (double) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.570795967764453d + "'", double2 == 1.570795967764453d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        long long2 = org.apache.commons.math.util.FastMath.min(100L, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 10L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        int int2 = org.apache.commons.math.util.FastMath.max(8, 1283169405);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1283169405 + "'", int2 == 1283169405);
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test136");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        int int1 = mersenneTwister0.nextInt();
//        double double2 = mersenneTwister0.nextGaussian();
//        float float3 = mersenneTwister0.nextFloat();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-543263219) + "'", int1 == (-543263219));
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.4593041074031422d + "'", double2 == 0.4593041074031422d);
//        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.7847284f + "'", float3 == 0.7847284f);
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        double double1 = org.apache.commons.math.util.FastMath.asinh(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.99822295029797d + "'", double1 == 2.99822295029797d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        double double1 = org.apache.commons.math.util.FastMath.expm1(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 2147483647);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22.180709777452588d + "'", double1 == 22.180709777452588d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        double double2 = org.apache.commons.math.util.FastMath.min(0.4593041074031422d, (double) 4589153899890174528L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.4593041074031422d + "'", double2 == 0.4593041074031422d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.5515679276951895d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9367080438189684d + "'", double1 == 0.9367080438189684d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        double double1 = org.apache.commons.math.util.FastMath.atan(7.105427357601002E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) 97);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 10);
        mersenneTwister1.setSeed(0);
        float float4 = mersenneTwister1.nextFloat();
        int[] intArray8 = new int[] { (byte) 0, '#', (byte) 100 };
        mersenneTwister1.setSeed(intArray8);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.54881346f + "'", float4 == 0.54881346f);
        org.junit.Assert.assertNotNull(intArray8);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        double double1 = org.apache.commons.math.util.FastMath.log1p(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.multiply(dfp7);
        java.lang.String str9 = dfp3.toString();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0.6931471805599453" + "'", str9.equals("0.6931471805599453"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1283169405, (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        java.lang.Object[] objArray5 = new java.lang.Object[] { '4', 2.718281828459045d, roundingMode4 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, number8);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (byte) 100 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException14 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException9, localizable10, localizable11, objArray13);
        mathIllegalArgumentException6.addSuppressed((java.lang.Throwable) notStrictlyPositiveException9);
        java.lang.String str16 = notStrictlyPositiveException9.toString();
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)" + "'", str16.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        double double1 = org.apache.commons.math.util.FastMath.log10(4.5891538998901745E18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 18.661732622251716d + "'", double1 == 18.661732622251716d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 4.5891538998901745E18d, (java.lang.Number) 0L, true);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (byte) -1, (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9999999999999999d) + "'", double2 == (-0.9999999999999999d));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, number1);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        java.lang.String str4 = notStrictlyPositiveException2.toString();
        java.lang.Throwable[] throwableArray5 = notStrictlyPositiveException2.getSuppressed();
        java.lang.Throwable throwable6 = null;
        try {
            notStrictlyPositiveException2.addSuppressed(throwable6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)" + "'", str4.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.9999999999999999d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        int int0 = org.apache.commons.math.dfp.Dfp.MIN_EXP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-32767) + "'", int0 == (-32767));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        java.lang.Object[] objArray5 = new java.lang.Object[] { '4', 2.718281828459045d, roundingMode4 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, number8);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (byte) 100 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException14 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException9, localizable10, localizable11, objArray13);
        mathIllegalArgumentException6.addSuppressed((java.lang.Throwable) notStrictlyPositiveException9);
        java.lang.Object[] objArray16 = mathIllegalArgumentException6.getArguments();
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray16);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5729.5779513082325d + "'", double1 == 5729.5779513082325d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.multiply(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getZero();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.multiply(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getZero();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.getLn2();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp21.multiply(dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp16, dfp21);
        double[] doubleArray28 = dfp21.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField29 = dfp21.getField();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getPi();
        org.apache.commons.math.dfp.Dfp dfp31 = new org.apache.commons.math.dfp.Dfp(dfp30);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(dfpField29);
        org.junit.Assert.assertNotNull(dfp30);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 0.606213f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5005239130785922d) + "'", double1 == (-0.5005239130785922d));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 10);
        long long2 = mersenneTwister1.nextLong();
        double double3 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-4218389569722409859L) + "'", long2 == (-4218389569722409859L));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.9471517478827094d + "'", double3 == 0.9471517478827094d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 32768.0f, 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707133714170212d + "'", double2 == 1.5707133714170212d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, number1);
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        java.lang.String str4 = notStrictlyPositiveException2.toString();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.0f);
        notStrictlyPositiveException2.addSuppressed((java.lang.Throwable) notStrictlyPositiveException6);
        org.apache.commons.math.exception.util.Localizable localizable8 = notStrictlyPositiveException6.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)" + "'", str4.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNull(localizable8);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, number1);
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        java.lang.String str4 = notStrictlyPositiveException2.toString();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.0f);
        notStrictlyPositiveException2.addSuppressed((java.lang.Throwable) notStrictlyPositiveException6);
        java.lang.Number number8 = notStrictlyPositiveException6.getMin();
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException6.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)" + "'", str4.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0 + "'", number8.equals(0));
        org.junit.Assert.assertNull(localizable9);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException3 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = mathIllegalArgumentException3.getGeneralPattern();
        java.lang.Object[] objArray5 = mathIllegalArgumentException3.getArguments();
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertNotNull(objArray5);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 1283169405);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.66574613261532d + "'", double1 == 21.66574613261532d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_OVERFLOW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 'a');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 97L + "'", long1 == 97L);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        double double2 = org.apache.commons.math.util.FastMath.atan2(3.0d, 8.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.35877067027057225d + "'", double2 == 0.35877067027057225d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.multiply(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getZero();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.multiply(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getZero();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.getLn2();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp21.multiply(dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp16, dfp21);
        double[] doubleArray28 = dfp21.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField29 = dfp21.getField();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getPi();
        org.apache.commons.math.dfp.Dfp dfp31 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp32 = dfp30.multiply(dfp31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(dfpField29);
        org.junit.Assert.assertNotNull(dfp30);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        double double1 = org.apache.commons.math.util.FastMath.log10(5729.5779513082325d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.7581226324091723d + "'", double1 == 3.7581226324091723d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        double double1 = org.apache.commons.math.util.FastMath.cos(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, number1);
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray4 = notStrictlyPositiveException2.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        double double1 = org.apache.commons.math.util.FastMath.sin(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.41078129050290885d + "'", double1 == 0.41078129050290885d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.36787944117144233d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3678794411714424d + "'", double1 == 0.3678794411714424d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.8623188722876839d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9732324798502845d + "'", double1 == 0.9732324798502845d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 1283169405);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963260155764d + "'", double1 == 1.5707963260155764d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017453292519943295d + "'", double1 == 0.017453292519943295d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance((int) (byte) 3);
        int int7 = dfp4.intValue();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.newDfp((long) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp12.newInstance((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getZero();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.getZero();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.getLn2();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp20.multiply(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getZero();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getZero();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.getLn2();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp29.multiply(dfp33);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField36.getZero();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField40.getZero();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField40.getLn2();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp38.multiply(dfp42);
        org.apache.commons.math.dfp.Dfp dfp44 = org.apache.commons.math.dfp.DfpField.computeLn(dfp24, dfp33, dfp38);
        java.lang.Class<?> wildcardClass45 = dfp33.getClass();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp33.getTwo();
        boolean boolean47 = dfp12.greaterThan(dfp33);
        double double48 = dfp33.toDouble();
        org.apache.commons.math.dfp.Dfp dfp49 = org.apache.commons.math.dfp.Dfp.copysign(dfp4, dfp33);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.69314718056d + "'", double48 == 0.69314718056d);
        org.junit.Assert.assertNotNull(dfp49);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, number1);
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        java.lang.String str4 = notStrictlyPositiveException2.toString();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.0f);
        notStrictlyPositiveException2.addSuppressed((java.lang.Throwable) notStrictlyPositiveException6);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException8 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException6);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Number number12 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, number12);
        boolean boolean14 = notStrictlyPositiveException13.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] { 32768L, 10000, 'a', 10.0d, 1.0d };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException23 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException13, localizable15, localizable16, objArray22);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException24 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException8, localizable9, localizable10, objArray22);
        java.lang.String str25 = mathRuntimeException8.toString();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)" + "'", str4.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str25.equals("org.apache.commons.math.exception.MathRuntimeException: "));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        double double2 = org.apache.commons.math.util.FastMath.min(2.99822295029797d, 2.27632259394013d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.27632259394013d + "'", double2 == 2.27632259394013d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 100L, 0.5755677771820237d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5650407125795116d + "'", double2 == 1.5650407125795116d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.multiply(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getZero();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.multiply(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getZero();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.getLn2();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp21.multiply(dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp16, dfp21);
        java.lang.Class<?> wildcardClass28 = dfp16.getClass();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp16.rint();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(dfp29);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (-4218389569722409859L));
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.5807959934815619d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.326505327141374d + "'", double1 == 2.326505327141374d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getZero();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getZero();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.getLn2();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp11.multiply(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getZero();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.getZero();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.getLn2();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp20.multiply(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getZero();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getZero();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.getLn2();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp29.multiply(dfp33);
        org.apache.commons.math.dfp.Dfp dfp35 = org.apache.commons.math.dfp.DfpField.computeLn(dfp15, dfp24, dfp29);
        java.lang.Class<?> wildcardClass36 = dfp24.getClass();
        org.apache.commons.math.dfp.Dfp dfp37 = org.apache.commons.math.dfp.DfpField.computeExp(dfp7, dfp24);
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField39.getZero();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField39.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField43.getZero();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField43.getLn2();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp41.multiply(dfp45);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp24.newInstance(dfp45);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-6089729882471614018L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.0897298824716145E18d) + "'", double1 == (-6.0897298824716145E18d));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)");
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 0.606213f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 4218389569722409859L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.41078129050290885d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.916809113253893d + "'", double1 == 0.916809113253893d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(21.66574613261532d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.787776054013205d + "'", double1 == 2.787776054013205d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        double double2 = org.apache.commons.math.util.FastMath.atan2(7.105427357601002E-15d, 2.27632259394013d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.1214500864317666E-15d + "'", double2 == 3.1214500864317666E-15d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.5352983268235827d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.27140411408419574d) + "'", double1 == (-0.27140411408419574d));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        double double1 = org.apache.commons.math.util.FastMath.abs((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((int) (byte) 0);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 10);
        mersenneTwister1.setSeed(32768);
        float float4 = mersenneTwister1.nextFloat();
        long long5 = mersenneTwister1.nextLong();
        long long6 = mersenneTwister1.nextLong();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.606213f + "'", float4 == 0.606213f);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-6089729882471614018L) + "'", long5 == (-6089729882471614018L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 7135322557707956303L + "'", long6 == 7135322557707956303L);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        double double1 = org.apache.commons.math.util.FastMath.ceil(114.59155902616465d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 115.0d + "'", double1 == 115.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, (double) (-1L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        dfpField1.setIEEEFlagsBits(89128932);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 10);
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 10);
        int int5 = mersenneTwister3.nextInt(2);
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister((-1L));
        byte[] byteArray11 = new byte[] { (byte) 10, (byte) 3, (byte) 10 };
        mersenneTwister7.nextBytes(byteArray11);
        mersenneTwister3.nextBytes(byteArray11);
        mersenneTwister1.nextBytes(byteArray11);
        long long15 = mersenneTwister1.nextLong();
        mersenneTwister1.setSeed((long) 32768);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 5511170629791907812L + "'", long15 == 5511170629791907812L);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (short) 0, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 3, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.multiply(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getZero();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.multiply(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getZero();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.getLn2();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp21.multiply(dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp16, dfp21);
        java.lang.Class<?> wildcardClass28 = dfp16.getClass();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp16.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getZero();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.getZero();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField35.getLn2();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp33.multiply(dfp37);
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField40.getZero();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField40.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField44.getZero();
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField44.getLn2();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp42.multiply(dfp46);
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField49.getZero();
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField49.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField53 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField53.getZero();
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField53.getLn2();
        org.apache.commons.math.dfp.Dfp dfp56 = dfp51.multiply(dfp55);
        org.apache.commons.math.dfp.Dfp dfp57 = org.apache.commons.math.dfp.DfpField.computeLn(dfp37, dfp46, dfp51);
        double[] doubleArray58 = dfp51.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField59 = dfp51.getField();
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField59.getPi();
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField59.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField63 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField63.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp66 = dfpField63.newDfp((long) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField63.newDfp((int) (byte) -1);
        boolean boolean69 = dfp61.unequal(dfp68);
        org.apache.commons.math.dfp.Dfp dfp70 = dfp16.divide(dfp61);
        org.apache.commons.math.dfp.Dfp dfp72 = dfp16.newInstance((int) (byte) 100);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(dfpField59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp72);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 0, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 8);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.multiply(dfp7);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode13 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        java.lang.Object[] objArray14 = new java.lang.Object[] { '4', 2.718281828459045d, roundingMode13 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable10, objArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Number number17 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable16, number17);
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] { (byte) 100 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException23 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException18, localizable19, localizable20, objArray22);
        mathIllegalArgumentException15.addSuppressed((java.lang.Throwable) notStrictlyPositiveException18);
        boolean boolean25 = dfp3.equals((java.lang.Object) mathIllegalArgumentException15);
        boolean boolean26 = dfp3.isNaN();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + roundingMode13 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode13.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException3 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = mathIllegalArgumentException3.getGeneralPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException5 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException3);
        org.junit.Assert.assertNull(localizable4);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 0.7847284f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.013696094451086499d + "'", double1 == 0.013696094451086499d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.5607966601082315d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.027241040673019475d + "'", double1 == 0.027241040673019475d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((int) (byte) -1);
        int int7 = dfp6.intValue();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1833.4649444186343d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 105049.8032003758d + "'", double1 == 105049.8032003758d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        double double1 = org.apache.commons.math.util.FastMath.expm1(7.105427357601002E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601027E-15d + "'", double1 == 7.105427357601027E-15d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        long long1 = org.apache.commons.math.util.FastMath.round(100.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (-4218389569722409859L));
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable3, (java.lang.Number) 1.5707133714170212d);
        java.lang.Number number6 = notStrictlyPositiveException5.getArgument();
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.5707133714170212d + "'", number6.equals(1.5707133714170212d));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0.5352983268235827d, (java.lang.Number) Double.POSITIVE_INFINITY, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) (-4218389569722409859L));
        org.apache.commons.math.exception.util.Localizable localizable8 = notStrictlyPositiveException7.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, (java.lang.Number) 8, (java.lang.Number) (-0.5005239130785922d), false);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException15 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable13, (java.lang.Number) (-4218389569722409859L));
        org.apache.commons.math.exception.util.Localizable localizable16 = notStrictlyPositiveException15.getGeneralPattern();
        java.lang.Object[] objArray17 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException4, localizable8, localizable16, objArray17);
        java.lang.String str19 = mathRuntimeException18.toString();
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: {0} is smaller than, or equal to, the minimum ({1}): {0} is smaller than, or equal to, the minimum ({1})" + "'", str19.equals("org.apache.commons.math.exception.MathRuntimeException: {0} is smaller than, or equal to, the minimum ({1}): {0} is smaller than, or equal to, the minimum ({1})"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        double double2 = org.apache.commons.math.util.FastMath.max(Double.NaN, (double) 7135322557707956303L);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-155033141));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.55033136E8f + "'", float1 == 1.55033136E8f);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        double double1 = org.apache.commons.math.util.FastMath.abs(2.99822295029797d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.99822295029797d + "'", double1 == 2.99822295029797d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (-4218389569722409859L));
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getGeneralPattern();
        java.lang.String str4 = notStrictlyPositiveException2.toString();
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: -4,218,389,569,722,409,859 is smaller than, or equal to, the minimum (0)" + "'", str4.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: -4,218,389,569,722,409,859 is smaller than, or equal to, the minimum (0)"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)");
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getZero();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.getLn2();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp7.multiply(dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField14.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField14.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField14.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp11.nextAfter(dfp18);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp3.divide(dfp11);
        int int21 = dfp11.log10();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getTwo();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 89128932);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.106711636108507E9d + "'", double1 == 5.106711636108507E9d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-543263219));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 5.4326323E8f + "'", float1 == 5.4326323E8f);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        long long1 = org.apache.commons.math.util.FastMath.round(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException3 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = mathIllegalArgumentException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = mathIllegalArgumentException3.getGeneralPattern();
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertNull(localizable5);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp4.newInstance((byte) 0);
        int int9 = dfp8.intValue();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.getTwo();
        int int11 = dfp8.log10K();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.multiply(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField9 = dfp3.getField();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getLn10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpField9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 0, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.newInstance();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.rint();
        org.apache.commons.math.dfp.Dfp dfp9 = null;
        try {
            boolean boolean10 = dfp7.greaterThan(dfp9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.multiply(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getZero();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.multiply(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getZero();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.getLn2();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp21.multiply(dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp16, dfp21);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getPi();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.getTwo();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp31.negate();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp7.newInstance(dfp32);
        boolean boolean34 = dfp33.isNaN();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.multiply(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getZero();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.multiply(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getZero();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.getLn2();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp21.multiply(dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp16, dfp21);
        double[] doubleArray28 = dfp21.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField29 = dfp21.getField();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp21.getOne();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(dfpField29);
        org.junit.Assert.assertNotNull(dfp30);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 32768);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32768.0d + "'", double1 == 32768.0d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (-4218389569722409859L));
        java.lang.String str3 = notStrictlyPositiveException2.toString();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 0.5352983268235827d, (java.lang.Number) Double.POSITIVE_INFINITY, true);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException11 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable9, (java.lang.Number) (-4218389569722409859L));
        org.apache.commons.math.exception.util.Localizable localizable12 = notStrictlyPositiveException11.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, (java.lang.Number) 8, (java.lang.Number) (-0.5005239130785922d), false);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException19 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable17, (java.lang.Number) (-4218389569722409859L));
        org.apache.commons.math.exception.util.Localizable localizable20 = notStrictlyPositiveException19.getGeneralPattern();
        java.lang.Object[] objArray21 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException8, localizable12, localizable20, objArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException25 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable23, (java.lang.Number) (-4218389569722409859L));
        org.apache.commons.math.exception.util.Localizable localizable26 = notStrictlyPositiveException25.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException28 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable26, (java.lang.Number) 1.5707133714170212d);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Number number30 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException31 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable29, number30);
        boolean boolean32 = notStrictlyPositiveException31.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        java.lang.Object[] objArray40 = new java.lang.Object[] { 32768L, 10000, 'a', 10.0d, 1.0d };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException41 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException31, localizable33, localizable34, objArray40);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException42 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2, localizable20, localizable26, objArray40);
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException47 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable43, (java.lang.Number) 0.5352983268235827d, (java.lang.Number) Double.POSITIVE_INFINITY, true);
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException50 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable48, (java.lang.Number) (-4218389569722409859L));
        org.apache.commons.math.exception.util.Localizable localizable51 = notStrictlyPositiveException50.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException55 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable51, (java.lang.Number) 8, (java.lang.Number) (-0.5005239130785922d), false);
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException58 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable56, (java.lang.Number) (-4218389569722409859L));
        org.apache.commons.math.exception.util.Localizable localizable59 = notStrictlyPositiveException58.getGeneralPattern();
        java.lang.Object[] objArray60 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException61 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException47, localizable51, localizable59, objArray60);
        notStrictlyPositiveException2.addSuppressed((java.lang.Throwable) numberIsTooSmallException47);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: -4,218,389,569,722,409,859 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: -4,218,389,569,722,409,859 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable26.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertTrue("'" + localizable51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable51.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable59 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable59.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        double double1 = org.apache.commons.math.util.FastMath.ceil(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.9367080438189684d, (double) 2147483647);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)");
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getZero();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.getLn2();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp7.multiply(dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField14.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField14.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField14.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp11.nextAfter(dfp18);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp3.divide(dfp11);
        org.apache.commons.math.dfp.Dfp dfp21 = null;
        try {
            boolean boolean22 = dfp3.lessThan(dfp21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        int int1 = org.apache.commons.math.util.FastMath.abs(10000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10000 + "'", int1 == 10000);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        double double1 = org.apache.commons.math.util.FastMath.acosh(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6574544541530771d + "'", double1 == 1.6574544541530771d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.multiply(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getZero();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.multiply(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getZero();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.getLn2();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp21.multiply(dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp16, dfp21);
        java.lang.Class<?> wildcardClass28 = dfp16.getClass();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray32 = dfpField30.getESplit();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField30.newDfp();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField30.getLn2();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField30.newDfp();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField30.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField38.getZero();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField38.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField42.getZero();
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.getLn2();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp40.multiply(dfp44);
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField47.getZero();
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField47.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField51.getZero();
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField51.getLn2();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp49.multiply(dfp53);
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField56.getZero();
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField56.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField60 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField60.getZero();
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField60.getLn2();
        org.apache.commons.math.dfp.Dfp dfp63 = dfp58.multiply(dfp62);
        org.apache.commons.math.dfp.Dfp dfp64 = org.apache.commons.math.dfp.DfpField.computeLn(dfp44, dfp53, dfp58);
        java.lang.Class<?> wildcardClass65 = dfp53.getClass();
        org.apache.commons.math.dfp.Dfp dfp66 = org.apache.commons.math.dfp.DfpField.computeExp(dfp36, dfp53);
        int int67 = dfp66.log10();
        org.apache.commons.math.dfp.DfpField dfpField69 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField69.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray71 = dfpField69.getESplit();
        org.apache.commons.math.dfp.Dfp dfp72 = dfpField69.newDfp();
        org.apache.commons.math.dfp.Dfp dfp74 = dfp72.newInstance((int) '4');
        boolean boolean75 = dfp66.greaterThan(dfp72);
        boolean boolean76 = dfp16.lessThan(dfp72);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfpArray32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfpArray71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.multiply(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getZero();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.multiply(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getZero();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.getLn2();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp21.multiply(dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp16, dfp21);
        double[] doubleArray28 = dfp21.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp21.floor();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(dfp29);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp((long) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp10.newInstance((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getZero();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getZero();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.getLn2();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp18.multiply(dfp22);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.getZero();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getZero();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.getLn2();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp27.multiply(dfp31);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.getZero();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField38.getZero();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField38.getLn2();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp36.multiply(dfp40);
        org.apache.commons.math.dfp.Dfp dfp42 = org.apache.commons.math.dfp.DfpField.computeLn(dfp22, dfp31, dfp36);
        java.lang.Class<?> wildcardClass43 = dfp31.getClass();
        org.apache.commons.math.dfp.Dfp dfp44 = dfp31.getTwo();
        boolean boolean45 = dfp10.greaterThan(dfp31);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp5.nextAfter(dfp10);
        org.apache.commons.math.dfp.Dfp dfp47 = null;
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField49.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField49.newDfp((long) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp52.newInstance((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp56 = dfp52.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp58 = dfp56.newInstance((int) 'a');
        try {
            org.apache.commons.math.dfp.Dfp dfp59 = org.apache.commons.math.dfp.DfpField.computeLn(dfp46, dfp47, dfp56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp58);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.multiply(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getZero();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.multiply(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getZero();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.getLn2();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp21.multiply(dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp16, dfp21);
        double[] doubleArray28 = dfp21.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField29 = dfp21.getField();
        int int30 = dfp21.classify();
        org.apache.commons.math.dfp.DfpField dfpField31 = dfp21.getField();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getLn2();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(dfpField29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(dfpField31);
        org.junit.Assert.assertNotNull(dfp32);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        int[] intArray6 = new int[] { (byte) -1, 8, (short) 10, (byte) 3, (byte) 3, 32768 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        float float8 = mersenneTwister7.nextFloat();
        int[] intArray13 = new int[] { (byte) 3, 10, 0, (byte) 1 };
        mersenneTwister7.setSeed(intArray13);
        mersenneTwister7.setSeed((int) ' ');
        long long17 = mersenneTwister7.nextLong();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.10849404f + "'", float8 == 0.10849404f);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-2603033481457588693L) + "'", long17 == (-2603033481457588693L));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 3);
        try {
            org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.multiply(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getZero();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.multiply(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getZero();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.getLn2();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp21.multiply(dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp16, dfp21);
        double[] doubleArray28 = dfp21.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField29 = dfp21.getField();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getTwo();
        org.apache.commons.math.dfp.Dfp[] dfpArray31 = dfpField29.getLn5Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(dfpField29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfpArray31);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        dfpField1.setIEEEFlags((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-0.27140411408419574d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0370567283972962d + "'", double1 == 1.0370567283972962d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException3 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = mathIllegalArgumentException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) (-4218389569722409859L));
        org.apache.commons.math.exception.util.Localizable localizable8 = notStrictlyPositiveException7.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, (java.lang.Number) 8, (java.lang.Number) (-0.5005239130785922d), false);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException15 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable13, (java.lang.Number) (-4218389569722409859L));
        org.apache.commons.math.exception.util.Localizable localizable16 = notStrictlyPositiveException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode21 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        java.lang.Object[] objArray22 = new java.lang.Object[] { '4', 2.718281828459045d, roundingMode21 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, localizable18, objArray22);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException24 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException3, localizable8, localizable16, objArray22);
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + roundingMode21 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode21.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(objArray22);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.multiply(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getZero();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.multiply(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getZero();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.getLn2();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp21.multiply(dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp16, dfp21);
        double[] doubleArray28 = dfp21.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField29 = dfp21.getField();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getTwo();
        org.apache.commons.math.dfp.Dfp dfp31 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp32 = dfp30.multiply(dfp31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(dfpField29);
        org.junit.Assert.assertNotNull(dfp30);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, number1);
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 32768L, 10000, 'a', 10.0d, 1.0d };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2, localizable4, localizable5, objArray11);
        java.lang.String str13 = notStrictlyPositiveException2.toString();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)" + "'", str13.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 10);
        mersenneTwister1.setSeed(0);
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 10);
        int int7 = mersenneTwister5.nextInt(2);
        org.apache.commons.math.random.MersenneTwister mersenneTwister9 = new org.apache.commons.math.random.MersenneTwister((-1L));
        byte[] byteArray13 = new byte[] { (byte) 10, (byte) 3, (byte) 10 };
        mersenneTwister9.nextBytes(byteArray13);
        mersenneTwister5.nextBytes(byteArray13);
        mersenneTwister1.nextBytes(byteArray13);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(byteArray13);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0.5352983268235827d, (java.lang.Number) Double.POSITIVE_INFINITY, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        java.lang.Object[] objArray10 = new java.lang.Object[] { '4', 2.718281828459045d, roundingMode9 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray10);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) mathIllegalArgumentException11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException15 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable13, (java.lang.Number) (-4218389569722409859L));
        java.lang.String str16 = notStrictlyPositiveException15.toString();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) 0.5352983268235827d, (java.lang.Number) Double.POSITIVE_INFINITY, true);
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException24 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable22, (java.lang.Number) (-4218389569722409859L));
        org.apache.commons.math.exception.util.Localizable localizable25 = notStrictlyPositiveException24.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable25, (java.lang.Number) 8, (java.lang.Number) (-0.5005239130785922d), false);
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException32 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable30, (java.lang.Number) (-4218389569722409859L));
        org.apache.commons.math.exception.util.Localizable localizable33 = notStrictlyPositiveException32.getGeneralPattern();
        java.lang.Object[] objArray34 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException35 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException21, localizable25, localizable33, objArray34);
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException38 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable36, (java.lang.Number) (-4218389569722409859L));
        org.apache.commons.math.exception.util.Localizable localizable39 = notStrictlyPositiveException38.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException41 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable39, (java.lang.Number) 1.5707133714170212d);
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        java.lang.Number number43 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException44 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable42, number43);
        boolean boolean45 = notStrictlyPositiveException44.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.exception.util.Localizable localizable47 = null;
        java.lang.Object[] objArray53 = new java.lang.Object[] { 32768L, 10000, 'a', 10.0d, 1.0d };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException54 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException44, localizable46, localizable47, objArray53);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException55 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException15, localizable33, localizable39, objArray53);
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        java.lang.Number number57 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException58 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable56, number57);
        boolean boolean59 = notStrictlyPositiveException58.getBoundIsAllowed();
        java.lang.String str60 = notStrictlyPositiveException58.toString();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException62 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.0f);
        notStrictlyPositiveException58.addSuppressed((java.lang.Throwable) notStrictlyPositiveException62);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException64 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException62);
        org.apache.commons.math.exception.util.Localizable localizable65 = null;
        org.apache.commons.math.exception.util.Localizable localizable66 = null;
        org.apache.commons.math.exception.util.Localizable localizable67 = null;
        java.lang.Number number68 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException69 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable67, number68);
        boolean boolean70 = notStrictlyPositiveException69.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable71 = null;
        org.apache.commons.math.exception.util.Localizable localizable72 = null;
        java.lang.Object[] objArray78 = new java.lang.Object[] { 32768L, 10000, 'a', 10.0d, 1.0d };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException79 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException69, localizable71, localizable72, objArray78);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException80 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException64, localizable65, localizable66, objArray78);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException81 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, objArray78);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) mathIllegalArgumentException81);
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode9.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: -4,218,389,569,722,409,859 is smaller than, or equal to, the minimum (0)" + "'", str16.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: -4,218,389,569,722,409,859 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable25.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable33.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable39.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)" + "'", str60.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(objArray78);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, number1);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        java.lang.Number number4 = notStrictlyPositiveException2.getArgument();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        long long1 = org.apache.commons.math.util.FastMath.round(9.999999999999998d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)");
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance("org.apache.commons.math.exception.MathRuntimeException: ");
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.35877067027057225d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.36695055094192036d + "'", double1 == 0.36695055094192036d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.multiply(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getZero();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.multiply(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getZero();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.getLn2();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp21.multiply(dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp16, dfp21);
        double[] doubleArray28 = dfp21.toSplitDouble();
        double double29 = dfp21.toDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.69314718056d + "'", double29 == 0.69314718056d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0f);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 4589153899890174528L, (-1.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.589153899890174E18d + "'", double2 == 4.589153899890174E18d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.multiply(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getZero();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.multiply(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getZero();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.getLn2();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp21.multiply(dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp16, dfp21);
        java.lang.Class<?> wildcardClass28 = dfp16.getClass();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp16.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getZero();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.getZero();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField35.getLn2();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp33.multiply(dfp37);
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField40.getZero();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField40.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField44.getZero();
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField44.getLn2();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp42.multiply(dfp46);
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField49.getZero();
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField49.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField53 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField53.getZero();
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField53.getLn2();
        org.apache.commons.math.dfp.Dfp dfp56 = dfp51.multiply(dfp55);
        org.apache.commons.math.dfp.Dfp dfp57 = org.apache.commons.math.dfp.DfpField.computeLn(dfp37, dfp46, dfp51);
        double[] doubleArray58 = dfp51.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField59 = dfp51.getField();
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField59.getPi();
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField59.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField63 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField63.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp66 = dfpField63.newDfp((long) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField63.newDfp((int) (byte) -1);
        boolean boolean69 = dfp61.unequal(dfp68);
        org.apache.commons.math.dfp.Dfp dfp70 = dfp16.divide(dfp61);
        org.apache.commons.math.dfp.Dfp dfp71 = dfp70.floor();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(dfpField59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp71);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.multiply(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getZero();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.multiply(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getZero();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.getLn2();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp21.multiply(dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp16, dfp21);
        java.lang.Class<?> wildcardClass28 = dfp27.getClass();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp27.newInstance((byte) -1);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(dfp30);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getSqr2Split();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232920103323d + "'", double1 == 11013.232920103323d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        double double1 = org.apache.commons.math.util.FastMath.atan(6.691673596021348E41d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        double double1 = org.apache.commons.math.util.FastMath.exp(3.1214500864317666E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.000000000000003d + "'", double1 == 1.000000000000003d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (-4218389569722409859L));
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException2.getSpecificPattern();
        java.lang.Object[] objArray5 = notStrictlyPositiveException2.getArguments();
        java.lang.Throwable[] throwableArray6 = notStrictlyPositiveException2.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 10);
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 10);
        int int5 = mersenneTwister3.nextInt(2);
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister((-1L));
        byte[] byteArray11 = new byte[] { (byte) 10, (byte) 3, (byte) 10 };
        mersenneTwister7.nextBytes(byteArray11);
        mersenneTwister3.nextBytes(byteArray11);
        mersenneTwister1.nextBytes(byteArray11);
        long long15 = mersenneTwister1.nextLong();
        int int17 = mersenneTwister1.nextInt(97);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 5511170629791907812L + "'", long15 == 5511170629791907812L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 15 + "'", int17 == 15);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 0);
        boolean boolean2 = mersenneTwister1.nextBoolean();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.multiply(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField10.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField10.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.newDfp();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp7.nextAfter(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getZero();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getZero();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.getLn2();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp19.multiply(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getZero();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getZero();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField30.getLn2();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp28.multiply(dfp32);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.getZero();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField35.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField39.getZero();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField39.getLn2();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp37.multiply(dfp41);
        org.apache.commons.math.dfp.Dfp dfp43 = org.apache.commons.math.dfp.DfpField.computeLn(dfp23, dfp32, dfp37);
        double[] doubleArray44 = dfp37.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField45 = dfp37.getField();
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.getPi();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField45.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField49.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField49.newDfp((long) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField49.newDfp((int) (byte) -1);
        boolean boolean55 = dfp47.unequal(dfp54);
        org.apache.commons.math.dfp.Dfp dfp56 = dfp7.subtract(dfp47);
        double[] doubleArray57 = dfp47.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(dfpField45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(doubleArray57);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        int int3 = dfp2.log10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.power10K((-155033141));
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        int[] intArray6 = new int[] { (byte) -1, 8, (short) 10, (byte) 3, (byte) 3, 32768 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        org.apache.commons.math.random.MersenneTwister mersenneTwister9 = new org.apache.commons.math.random.MersenneTwister(1283169405);
        boolean boolean10 = mersenneTwister9.nextBoolean();
        int[] intArray14 = new int[] { 2, 16, (-155033141) };
        mersenneTwister9.setSeed(intArray14);
        byte[] byteArray21 = new byte[] { (byte) 100, (byte) -1, (byte) 3, (byte) -1, (byte) 100 };
        mersenneTwister9.nextBytes(byteArray21);
        mersenneTwister7.nextBytes(byteArray21);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(byteArray21);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp4.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.getZero();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        double double1 = org.apache.commons.math.util.FastMath.expm1(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 14.154262241479262d + "'", double1 == 14.154262241479262d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        double double1 = org.apache.commons.math.util.FastMath.rint(21.66574613261532d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22.0d + "'", double1 == 22.0d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) 10, (float) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.multiply(1);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.newDfp(100);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp14 = org.apache.commons.math.dfp.Dfp.copysign(dfp7, dfp13);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 1.55033136E8f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 18.85914943913109d + "'", double1 == 18.85914943913109d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-32767));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField1.getSqr2Split();
        int int11 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dfpArray12);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(100);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField6.getESplit();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.getOne();
        int int11 = dfp9.log10K();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp4.multiply(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField13 = dfp9.getField();
        dfpField13.setIEEEFlags(8);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.getSqr3();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpField13);
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp((long) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp10.newInstance((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getZero();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getZero();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.getLn2();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp18.multiply(dfp22);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.getZero();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getZero();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.getLn2();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp27.multiply(dfp31);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.getZero();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField38.getZero();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField38.getLn2();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp36.multiply(dfp40);
        org.apache.commons.math.dfp.Dfp dfp42 = org.apache.commons.math.dfp.DfpField.computeLn(dfp22, dfp31, dfp36);
        java.lang.Class<?> wildcardClass43 = dfp31.getClass();
        org.apache.commons.math.dfp.Dfp dfp44 = dfp31.getTwo();
        boolean boolean45 = dfp10.greaterThan(dfp31);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp5.nextAfter(dfp10);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField48.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray50 = dfpField48.getESplit();
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField48.newDfp();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField48.getLn2();
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField48.newDfp();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp53.newInstance();
        org.apache.commons.math.dfp.Dfp dfp55 = dfp46.divide(dfp54);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfpArray50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((long) (short) -1);
        org.apache.commons.math.dfp.DfpField dfpField8 = dfp7.getField();
        org.apache.commons.math.dfp.DfpField dfpField9 = dfp7.getField();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpField8);
        org.junit.Assert.assertNotNull(dfpField9);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 10);
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 10);
        int int5 = mersenneTwister3.nextInt(2);
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister((-1L));
        byte[] byteArray11 = new byte[] { (byte) 10, (byte) 3, (byte) 10 };
        mersenneTwister7.nextBytes(byteArray11);
        mersenneTwister3.nextBytes(byteArray11);
        mersenneTwister1.nextBytes(byteArray11);
        float float15 = mersenneTwister1.nextFloat();
        double double16 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.29876113f + "'", float15 == 0.29876113f);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.9471517478827094d + "'", double16 == 0.9471517478827094d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.multiply(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getZero();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.multiply(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getZero();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.getLn2();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp21.multiply(dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp16, dfp21);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp27.newInstance(0.9999999958776927d);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode7);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, number1);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        java.lang.String str4 = notStrictlyPositiveException2.toString();
        boolean boolean5 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, number7);
        boolean boolean9 = notStrictlyPositiveException8.getBoundIsAllowed();
        java.lang.String str10 = notStrictlyPositiveException8.toString();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException12 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.0f);
        notStrictlyPositiveException8.addSuppressed((java.lang.Throwable) notStrictlyPositiveException12);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException14 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException12);
        notStrictlyPositiveException2.addSuppressed((java.lang.Throwable) mathRuntimeException14);
        java.lang.Class<?> wildcardClass16 = mathRuntimeException14.getClass();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Number number18 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException19 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable17, number18);
        java.lang.Number number20 = notStrictlyPositiveException19.getMin();
        java.lang.String str21 = notStrictlyPositiveException19.toString();
        java.lang.Throwable[] throwableArray22 = notStrictlyPositiveException19.getSuppressed();
        mathRuntimeException14.addSuppressed((java.lang.Throwable) notStrictlyPositiveException19);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)" + "'", str4.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)" + "'", str10.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0 + "'", number20.equals(0));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)" + "'", str21.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(throwableArray22);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.newInstance();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.rint();
        double double9 = dfp8.toDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + Double.NEGATIVE_INFINITY + "'", double9 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp6 = dfp4.nextAfter(dfp5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 10);
        mersenneTwister1.setSeed(32768);
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(0L);
        byte[] byteArray11 = new byte[] { (byte) 10, (byte) 10, (byte) 0, (byte) 3, (byte) 1 };
        mersenneTwister5.nextBytes(byteArray11);
        mersenneTwister1.nextBytes(byteArray11);
        org.junit.Assert.assertNotNull(byteArray11);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(100);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField6.getESplit();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.getOne();
        int int11 = dfp9.log10K();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp4.multiply(dfp9);
        int int13 = dfp4.log10K();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.multiply(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getZero();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.multiply(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getZero();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.getLn2();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp21.multiply(dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp16, dfp21);
        double[] doubleArray28 = dfp21.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField29 = dfp21.getField();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getPi();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField33.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.newDfp((long) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField33.newDfp((int) (byte) -1);
        boolean boolean39 = dfp31.unequal(dfp38);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField41.getZero();
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField41.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.getZero();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField45.getLn2();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp43.multiply(dfp47);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField50.getZero();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField50.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField54.getZero();
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField54.getLn2();
        org.apache.commons.math.dfp.Dfp dfp57 = dfp52.multiply(dfp56);
        org.apache.commons.math.dfp.DfpField dfpField59 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField59.getZero();
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField59.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField63 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField63.getZero();
        org.apache.commons.math.dfp.Dfp dfp65 = dfpField63.getLn2();
        org.apache.commons.math.dfp.Dfp dfp66 = dfp61.multiply(dfp65);
        org.apache.commons.math.dfp.Dfp dfp67 = org.apache.commons.math.dfp.DfpField.computeLn(dfp47, dfp56, dfp61);
        double[] doubleArray68 = dfp61.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField69 = dfp61.getField();
        int int70 = dfp61.classify();
        org.apache.commons.math.dfp.DfpField dfpField71 = dfp61.getField();
        org.apache.commons.math.dfp.Dfp dfp73 = dfp61.multiply((int) (byte) 2);
        boolean boolean74 = dfp31.unequal(dfp61);
        org.apache.commons.math.dfp.DfpField dfpField76 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp77 = dfpField76.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray78 = dfpField76.getESplit();
        org.apache.commons.math.dfp.Dfp dfp79 = dfpField76.newDfp();
        org.apache.commons.math.dfp.Dfp dfp80 = dfpField76.getLn2();
        org.apache.commons.math.dfp.Dfp dfp81 = dfpField76.newDfp();
        org.apache.commons.math.dfp.Dfp dfp82 = dfpField76.getZero();
        org.apache.commons.math.dfp.Dfp dfp83 = dfp31.divide(dfp82);
        boolean boolean84 = dfp83.isNaN();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(dfpField29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(dfpField69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertNotNull(dfpField71);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertNotNull(dfpArray78);
        org.junit.Assert.assertNotNull(dfp79);
        org.junit.Assert.assertNotNull(dfp80);
        org.junit.Assert.assertNotNull(dfp81);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        double double1 = org.apache.commons.math.util.FastMath.sinh(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, number1);
        java.lang.Throwable[] throwableArray3 = notStrictlyPositiveException2.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(0);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((double) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getLn2();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.9471517478827094d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.843506246783419d + "'", double1 == 0.843506246783419d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        int[] intArray5 = new int[] { (byte) -1, (short) 100, 97, (-1), (byte) 10 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math.random.MersenneTwister(intArray5);
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray5);
        org.junit.Assert.assertNotNull(intArray5);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.multiply(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getZero();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.multiply(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getZero();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.getLn2();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp21.multiply(dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp16, dfp21);
        double[] doubleArray28 = dfp21.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp21.newInstance((byte) -1, (byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField33.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray35 = dfpField33.getESplit();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.newDfp();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField33.getLn2();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField33.newDfp();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField33.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField41.getZero();
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField41.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.getZero();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField45.getLn2();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp43.multiply(dfp47);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField50.getZero();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField50.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField54.getZero();
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField54.getLn2();
        org.apache.commons.math.dfp.Dfp dfp57 = dfp52.multiply(dfp56);
        org.apache.commons.math.dfp.DfpField dfpField59 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField59.getZero();
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField59.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField63 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField63.getZero();
        org.apache.commons.math.dfp.Dfp dfp65 = dfpField63.getLn2();
        org.apache.commons.math.dfp.Dfp dfp66 = dfp61.multiply(dfp65);
        org.apache.commons.math.dfp.Dfp dfp67 = org.apache.commons.math.dfp.DfpField.computeLn(dfp47, dfp56, dfp61);
        java.lang.Class<?> wildcardClass68 = dfp56.getClass();
        org.apache.commons.math.dfp.Dfp dfp69 = org.apache.commons.math.dfp.DfpField.computeExp(dfp39, dfp56);
        int int70 = dfp69.log10();
        org.apache.commons.math.dfp.DfpField dfpField72 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField72.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray74 = dfpField72.getESplit();
        org.apache.commons.math.dfp.Dfp dfp75 = dfpField72.newDfp();
        org.apache.commons.math.dfp.Dfp dfp77 = dfp75.newInstance((int) '4');
        boolean boolean78 = dfp69.greaterThan(dfp75);
        boolean boolean79 = dfp31.lessThan(dfp75);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfpArray35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(wildcardClass68);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfpArray74);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.691673596021348E41d + "'", double1 == 6.691673596021348E41d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        double double1 = org.apache.commons.math.util.FastMath.atan(115.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.562100893783118d + "'", double1 == 1.562100893783118d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        float float1 = org.apache.commons.math.util.FastMath.abs(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        int[] intArray6 = new int[] { (byte) -1, 8, (short) 10, (byte) 3, (byte) 3, 32768 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        float float8 = mersenneTwister7.nextFloat();
        int[] intArray13 = new int[] { (byte) 3, 10, 0, (byte) 1 };
        mersenneTwister7.setSeed(intArray13);
        mersenneTwister7.setSeed((int) ' ');
        int int17 = mersenneTwister7.nextInt();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.10849404f + "'", float8 == 0.10849404f);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-606065961) + "'", int17 == (-606065961));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance((int) (byte) 3);
        int int7 = dfp4.intValue();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp4.rint();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 10);
        double double2 = mersenneTwister1.nextDouble();
        double double3 = mersenneTwister1.nextDouble();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.77132064549269d + "'", double2 == 0.77132064549269d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.020751945593803d + "'", double3 == 0.020751945593803d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(1283169405);
        boolean boolean2 = mersenneTwister1.nextBoolean();
        int[] intArray6 = new int[] { 2, 16, (-155033141) };
        mersenneTwister1.setSeed(intArray6);
        byte[] byteArray13 = new byte[] { (byte) 100, (byte) -1, (byte) 3, (byte) -1, (byte) 100 };
        mersenneTwister1.nextBytes(byteArray13);
        float float15 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.59270287f + "'", float15 == 0.59270287f);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        double double1 = org.apache.commons.math.util.FastMath.floor(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        double double1 = org.apache.commons.math.util.FastMath.cos(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 32768);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 181.01933598375618d + "'", double1 == 181.01933598375618d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 0.59270287f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((long) (short) -1);
        org.apache.commons.math.dfp.DfpField dfpField8 = dfp7.getField();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.newDfp((long) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.newInstance((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp13.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.newInstance((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField8.newDfp(dfp19);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField8.newDfp((byte) 1, (byte) 0);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpField8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 4589153899890174528L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 43.663374525997426d + "'", double1 == 43.663374525997426d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn5Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, number1);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        java.lang.Object[] objArray4 = notStrictlyPositiveException2.getArguments();
        java.lang.String str5 = notStrictlyPositiveException2.toString();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)" + "'", str5.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField1.getSqr2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((double) 1283169405);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr2();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.multiply(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField9 = dfp3.getField();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.newDfp();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpField9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.multiply(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getZero();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.multiply(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getZero();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.getLn2();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp21.multiply(dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp16, dfp21);
        double[] doubleArray28 = dfp21.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField29 = dfp21.getField();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getPi();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp32 = null;
        try {
            boolean boolean33 = dfp31.greaterThan(dfp32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(dfpField29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) 2);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.multiply(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getZero();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.multiply(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getZero();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.getLn2();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp21.multiply(dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp16, dfp21);
        double[] doubleArray28 = dfp21.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField29 = dfp21.getField();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getPi();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField33.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.newDfp((long) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField33.newDfp((int) (byte) -1);
        boolean boolean39 = dfp31.unequal(dfp38);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField41.getZero();
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField41.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.getZero();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField45.getLn2();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp43.multiply(dfp47);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField50.getZero();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField50.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField54.getZero();
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField54.getLn2();
        org.apache.commons.math.dfp.Dfp dfp57 = dfp52.multiply(dfp56);
        org.apache.commons.math.dfp.DfpField dfpField59 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField59.getZero();
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField59.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField63 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField63.getZero();
        org.apache.commons.math.dfp.Dfp dfp65 = dfpField63.getLn2();
        org.apache.commons.math.dfp.Dfp dfp66 = dfp61.multiply(dfp65);
        org.apache.commons.math.dfp.Dfp dfp67 = org.apache.commons.math.dfp.DfpField.computeLn(dfp47, dfp56, dfp61);
        double[] doubleArray68 = dfp61.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField69 = dfp61.getField();
        int int70 = dfp61.classify();
        org.apache.commons.math.dfp.DfpField dfpField71 = dfp61.getField();
        org.apache.commons.math.dfp.Dfp dfp73 = dfp61.multiply((int) (byte) 2);
        boolean boolean74 = dfp31.unequal(dfp61);
        org.apache.commons.math.dfp.Dfp dfp75 = dfp31.getOne();
        org.apache.commons.math.dfp.Dfp dfp76 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp77 = dfp31.newInstance(dfp76);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(dfpField29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(dfpField69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertNotNull(dfpField71);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNotNull(dfp75);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp((long) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp10.newInstance((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getZero();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getZero();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.getLn2();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp18.multiply(dfp22);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.getZero();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getZero();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.getLn2();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp27.multiply(dfp31);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.getZero();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField38.getZero();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField38.getLn2();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp36.multiply(dfp40);
        org.apache.commons.math.dfp.Dfp dfp42 = org.apache.commons.math.dfp.DfpField.computeLn(dfp22, dfp31, dfp36);
        java.lang.Class<?> wildcardClass43 = dfp31.getClass();
        org.apache.commons.math.dfp.Dfp dfp44 = dfp31.getTwo();
        boolean boolean45 = dfp10.greaterThan(dfp31);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp5.nextAfter(dfp10);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField48.getZero();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField48.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField52.getZero();
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField52.getLn2();
        org.apache.commons.math.dfp.Dfp dfp55 = dfp50.multiply(dfp54);
        org.apache.commons.math.dfp.Dfp dfp57 = dfp55.power10K((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp58 = dfp10.remainder(dfp55);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        int[] intArray6 = new int[] { (byte) -1, 8, (short) 10, (byte) 3, (byte) 3, 32768 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        double double8 = mersenneTwister7.nextDouble();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.10849408656236958d + "'", double8 == 0.10849408656236958d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, number1);
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 32768L, 10000, 'a', 10.0d, 1.0d };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2, localizable4, localizable5, objArray11);
        java.lang.Number number13 = notStrictlyPositiveException2.getMin();
        java.lang.Number number14 = notStrictlyPositiveException2.getArgument();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0 + "'", number13.equals(0));
        org.junit.Assert.assertNull(number14);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.00000000000001d + "'", double1 == 97.00000000000001d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (-4218389569722409859L));
        java.lang.String str3 = notStrictlyPositiveException2.toString();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 0.5352983268235827d, (java.lang.Number) Double.POSITIVE_INFINITY, true);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException11 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable9, (java.lang.Number) (-4218389569722409859L));
        org.apache.commons.math.exception.util.Localizable localizable12 = notStrictlyPositiveException11.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, (java.lang.Number) 8, (java.lang.Number) (-0.5005239130785922d), false);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException19 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable17, (java.lang.Number) (-4218389569722409859L));
        org.apache.commons.math.exception.util.Localizable localizable20 = notStrictlyPositiveException19.getGeneralPattern();
        java.lang.Object[] objArray21 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException8, localizable12, localizable20, objArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException25 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable23, (java.lang.Number) (-4218389569722409859L));
        org.apache.commons.math.exception.util.Localizable localizable26 = notStrictlyPositiveException25.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException28 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable26, (java.lang.Number) 1.5707133714170212d);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Number number30 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException31 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable29, number30);
        boolean boolean32 = notStrictlyPositiveException31.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        java.lang.Object[] objArray40 = new java.lang.Object[] { 32768L, 10000, 'a', 10.0d, 1.0d };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException41 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException31, localizable33, localizable34, objArray40);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException42 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2, localizable20, localizable26, objArray40);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException46 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable26, (java.lang.Number) (-4218389569722409859L), (java.lang.Number) 2.718281828459045d, false);
        org.apache.commons.math.exception.util.Localizable localizable47 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException51 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable47, (java.lang.Number) 0.5352983268235827d, (java.lang.Number) Double.POSITIVE_INFINITY, true);
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException54 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable52, (java.lang.Number) (-4218389569722409859L));
        org.apache.commons.math.exception.util.Localizable localizable55 = notStrictlyPositiveException54.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException59 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable55, (java.lang.Number) 8, (java.lang.Number) (-0.5005239130785922d), false);
        org.apache.commons.math.exception.util.Localizable localizable60 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException62 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable60, (java.lang.Number) (-4218389569722409859L));
        org.apache.commons.math.exception.util.Localizable localizable63 = notStrictlyPositiveException62.getGeneralPattern();
        java.lang.Object[] objArray64 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException65 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException51, localizable55, localizable63, objArray64);
        org.apache.commons.math.exception.util.Localizable localizable66 = null;
        java.lang.Number number67 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException68 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable66, number67);
        boolean boolean69 = notStrictlyPositiveException68.getBoundIsAllowed();
        java.lang.String str70 = notStrictlyPositiveException68.toString();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException72 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.0f);
        notStrictlyPositiveException68.addSuppressed((java.lang.Throwable) notStrictlyPositiveException72);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException74 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException72);
        java.lang.Throwable[] throwableArray75 = notStrictlyPositiveException72.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException76 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable63, (java.lang.Object[]) throwableArray75);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException77 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable26, (java.lang.Object[]) throwableArray75);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException79 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable26, (java.lang.Number) 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: -4,218,389,569,722,409,859 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: -4,218,389,569,722,409,859 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable26.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertTrue("'" + localizable55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable55.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable63 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable63.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)" + "'", str70.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(throwableArray75);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        double double1 = org.apache.commons.math.util.FastMath.signum(22025.465794806718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.getTwo();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, number1);
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        java.lang.String str4 = notStrictlyPositiveException2.toString();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.0f);
        notStrictlyPositiveException2.addSuppressed((java.lang.Throwable) notStrictlyPositiveException6);
        java.lang.Number number8 = notStrictlyPositiveException6.getMin();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Number number10 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException11 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable9, number10);
        java.lang.Number number12 = notStrictlyPositiveException11.getMin();
        java.lang.String str13 = notStrictlyPositiveException11.toString();
        boolean boolean14 = notStrictlyPositiveException11.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Number number16 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException17 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable15, number16);
        boolean boolean18 = notStrictlyPositiveException17.getBoundIsAllowed();
        java.lang.String str19 = notStrictlyPositiveException17.toString();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.0f);
        notStrictlyPositiveException17.addSuppressed((java.lang.Throwable) notStrictlyPositiveException21);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException23 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException21);
        notStrictlyPositiveException11.addSuppressed((java.lang.Throwable) mathRuntimeException23);
        notStrictlyPositiveException6.addSuppressed((java.lang.Throwable) notStrictlyPositiveException11);
        java.lang.Object[] objArray26 = notStrictlyPositiveException11.getArguments();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)" + "'", str4.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0 + "'", number8.equals(0));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0 + "'", number12.equals(0));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)" + "'", str13.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)" + "'", str19.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray26);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.9471517478827094d, 1.6574544541530771d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9471517478827095d + "'", double2 == 0.9471517478827095d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, number1);
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getSpecificPattern();
        java.lang.Number number4 = notStrictlyPositiveException2.getMin();
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.multiply(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getZero();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.multiply(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getZero();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.getLn2();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp21.multiply(dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp16, dfp21);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getPi();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.getTwo();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp31.negate();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp7.newInstance(dfp32);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.getZero();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField35.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField39.getZero();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField39.getLn2();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp37.multiply(dfp41);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField44.getZero();
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField44.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField48.getZero();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField48.getLn2();
        org.apache.commons.math.dfp.Dfp dfp51 = dfp46.multiply(dfp50);
        org.apache.commons.math.dfp.DfpField dfpField53 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField53.getZero();
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField53.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField57 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField57.getZero();
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField57.getLn2();
        org.apache.commons.math.dfp.Dfp dfp60 = dfp55.multiply(dfp59);
        org.apache.commons.math.dfp.Dfp dfp61 = org.apache.commons.math.dfp.DfpField.computeLn(dfp41, dfp50, dfp55);
        double[] doubleArray62 = dfp55.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField63 = dfp55.getField();
        int int64 = dfp55.classify();
        org.apache.commons.math.dfp.DfpField dfpField65 = dfp55.getField();
        boolean boolean66 = dfp32.greaterThan(dfp55);
        org.apache.commons.math.dfp.Dfp dfp67 = dfp32.getOne();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(dfpField63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertNotNull(dfpField65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(dfp67);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(100);
        org.apache.commons.math.dfp.Dfp dfp4 = dfp3.getTwo();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, number1);
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        java.lang.String str4 = notStrictlyPositiveException2.toString();
        java.lang.Number number5 = notStrictlyPositiveException2.getArgument();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)" + "'", str4.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100.0d, (java.lang.Number) 1.019416871522534d, true);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        java.lang.Number number5 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.019416871522534d + "'", number5.equals(1.019416871522534d));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1.55033136E8f, (java.lang.Number) (short) 0, false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.multiply(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getZero();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.multiply(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getZero();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.getLn2();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp21.multiply(dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp16, dfp21);
        int int28 = dfp16.log10K();
        java.lang.Class<?> wildcardClass29 = dfp16.getClass();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass29);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-0.7150317874715495d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.multiply(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getZero();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.multiply(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getZero();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.getLn2();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp21.multiply(dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp16, dfp21);
        double[] doubleArray28 = dfp21.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField29 = dfp21.getField();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getPi();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.getSqr3();
        dfpField29.setIEEEFlagsBits(4);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField29.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField29.getZero();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(dfpField29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        double double1 = org.apache.commons.math.util.FastMath.tan(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.2246467991473532E-16d) + "'", double1 == (-1.2246467991473532E-16d));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(100);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField6.getESplit();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.getOne();
        int int11 = dfp9.log10K();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp4.multiply(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField13 = dfp9.getField();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp9.ceil();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getZero();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getZero();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.getLn2();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp18.multiply(dfp22);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.getZero();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getZero();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.getLn2();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp27.multiply(dfp31);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.getZero();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField38.getZero();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField38.getLn2();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp36.multiply(dfp40);
        org.apache.commons.math.dfp.Dfp dfp42 = org.apache.commons.math.dfp.DfpField.computeLn(dfp22, dfp31, dfp36);
        double[] doubleArray43 = dfp36.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField44 = dfp36.getField();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField44.getPi();
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField44.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField48.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField48.newDfp((long) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField48.newDfp((int) (byte) -1);
        boolean boolean54 = dfp46.unequal(dfp53);
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField56.getZero();
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField56.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField60 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField60.getZero();
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField60.getLn2();
        org.apache.commons.math.dfp.Dfp dfp63 = dfp58.multiply(dfp62);
        org.apache.commons.math.dfp.DfpField dfpField65 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp66 = dfpField65.getZero();
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField65.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField69 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField69.getZero();
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField69.getLn2();
        org.apache.commons.math.dfp.Dfp dfp72 = dfp67.multiply(dfp71);
        org.apache.commons.math.dfp.DfpField dfpField74 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp75 = dfpField74.getZero();
        org.apache.commons.math.dfp.Dfp dfp76 = dfpField74.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField78 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp79 = dfpField78.getZero();
        org.apache.commons.math.dfp.Dfp dfp80 = dfpField78.getLn2();
        org.apache.commons.math.dfp.Dfp dfp81 = dfp76.multiply(dfp80);
        org.apache.commons.math.dfp.Dfp dfp82 = org.apache.commons.math.dfp.DfpField.computeLn(dfp62, dfp71, dfp76);
        double[] doubleArray83 = dfp76.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField84 = dfp76.getField();
        int int85 = dfp76.classify();
        org.apache.commons.math.dfp.DfpField dfpField86 = dfp76.getField();
        org.apache.commons.math.dfp.Dfp dfp88 = dfp76.multiply((int) (byte) 2);
        boolean boolean89 = dfp46.unequal(dfp76);
        org.apache.commons.math.dfp.DfpField dfpField91 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp92 = dfpField91.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray93 = dfpField91.getESplit();
        org.apache.commons.math.dfp.Dfp dfp94 = dfpField91.newDfp();
        org.apache.commons.math.dfp.Dfp dfp95 = dfpField91.getLn2();
        org.apache.commons.math.dfp.Dfp dfp96 = dfpField91.newDfp();
        org.apache.commons.math.dfp.Dfp dfp97 = dfpField91.getZero();
        org.apache.commons.math.dfp.Dfp dfp98 = dfp46.divide(dfp97);
        boolean boolean99 = dfp9.equals((java.lang.Object) dfp97);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpField13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(dfpField44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertNotNull(dfp79);
        org.junit.Assert.assertNotNull(dfp80);
        org.junit.Assert.assertNotNull(dfp81);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(dfpField84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
        org.junit.Assert.assertNotNull(dfpField86);
        org.junit.Assert.assertNotNull(dfp88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
        org.junit.Assert.assertNotNull(dfp92);
        org.junit.Assert.assertNotNull(dfpArray93);
        org.junit.Assert.assertNotNull(dfp94);
        org.junit.Assert.assertNotNull(dfp95);
        org.junit.Assert.assertNotNull(dfp96);
        org.junit.Assert.assertNotNull(dfp97);
        org.junit.Assert.assertNotNull(dfp98);
        org.junit.Assert.assertTrue("'" + boolean99 + "' != '" + true + "'", boolean99 == true);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        int int2 = org.apache.commons.math.util.FastMath.min(1, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.multiply(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getZero();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.multiply(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getZero();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.getLn2();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp21.multiply(dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp16, dfp21);
        double[] doubleArray28 = dfp21.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField29 = dfp21.getField();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getPi();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.getSqr3();
        dfpField29.setIEEEFlagsBits(4);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField29.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField29.newDfp((byte) 0);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(dfpField29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-32767));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (-4218389569722409859L));
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException2.getSpecificPattern();
        java.lang.Object[] objArray5 = notStrictlyPositiveException2.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable6 = notStrictlyPositiveException2.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 2L, (-6.0897298824716145E18d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 97L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.267831587699267d + "'", double1 == 5.267831587699267d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6483608274590866d + "'", double1 == 0.6483608274590866d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.10849408656236958d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4620882581185577d + "'", double1 == 1.4620882581185577d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.multiply(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField10.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField10.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.newDfp();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp7.nextAfter(dfp14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.multiply((int) (byte) 2);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(181.01933598375618d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.656854249492381d + "'", double1 == 5.656854249492381d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(0);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((double) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance((byte) 10);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0.5352983268235827d, (java.lang.Number) Double.POSITIVE_INFINITY, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) (-4218389569722409859L));
        org.apache.commons.math.exception.util.Localizable localizable8 = notStrictlyPositiveException7.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, (java.lang.Number) 8, (java.lang.Number) (-0.5005239130785922d), false);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException15 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable13, (java.lang.Number) (-4218389569722409859L));
        org.apache.commons.math.exception.util.Localizable localizable16 = notStrictlyPositiveException15.getGeneralPattern();
        java.lang.Object[] objArray17 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException4, localizable8, localizable16, objArray17);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) 7.105427357601027E-15d);
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2.0d, (java.lang.Number) 0.916809113253893d, true);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.4711276743037347d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2129005211903137d + "'", double1 == 1.2129005211903137d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 10);
        long long2 = mersenneTwister1.nextLong();
        boolean boolean3 = mersenneTwister1.nextBoolean();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-4218389569722409859L) + "'", long2 == (-4218389569722409859L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.9471517478827095d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.973217215159447d + "'", double1 == 0.973217215159447d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 10);
        mersenneTwister1.setSeed(32768);
        float float4 = mersenneTwister1.nextFloat();
        long long5 = mersenneTwister1.nextLong();
        float float6 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.606213f + "'", float4 == 0.606213f);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-6089729882471614018L) + "'", long5 == (-6089729882471614018L));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.3868066f + "'", float6 == 0.3868066f);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp((long) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp10.newInstance((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getZero();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getZero();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.getLn2();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp18.multiply(dfp22);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.getZero();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getZero();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.getLn2();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp27.multiply(dfp31);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.getZero();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField38.getZero();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField38.getLn2();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp36.multiply(dfp40);
        org.apache.commons.math.dfp.Dfp dfp42 = org.apache.commons.math.dfp.DfpField.computeLn(dfp22, dfp31, dfp36);
        java.lang.Class<?> wildcardClass43 = dfp31.getClass();
        org.apache.commons.math.dfp.Dfp dfp44 = dfp31.getTwo();
        boolean boolean45 = dfp10.greaterThan(dfp31);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp5.nextAfter(dfp10);
        java.lang.String str47 = dfp5.toString();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "0." + "'", str47.equals("0."));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.newInstance();
        java.lang.Class<?> wildcardClass8 = dfp7.getClass();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1L));
        byte[] byteArray5 = new byte[] { (byte) 10, (byte) 3, (byte) 10 };
        mersenneTwister1.nextBytes(byteArray5);
        mersenneTwister1.setSeed(0L);
        org.junit.Assert.assertNotNull(byteArray5);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.multiply(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getZero();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.multiply(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getZero();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.getLn2();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp21.multiply(dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp16, dfp21);
        double[] doubleArray28 = dfp21.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField29 = dfp21.getField();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getTwo();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.getZero();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(dfpField29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, number1);
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        java.lang.String str4 = notStrictlyPositiveException2.toString();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.0f);
        notStrictlyPositiveException2.addSuppressed((java.lang.Throwable) notStrictlyPositiveException6);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException8 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException6);
        java.lang.Throwable[] throwableArray9 = notStrictlyPositiveException6.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException6);
        org.apache.commons.math.exception.util.Localizable localizable11 = notStrictlyPositiveException6.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)" + "'", str4.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.multiply(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getZero();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.multiply(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getZero();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.getLn2();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp21.multiply(dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp16, dfp21);
        double[] doubleArray28 = dfp21.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField29 = dfp21.getField();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getTwo();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode31 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP;
        dfpField29.setRoundingMode(roundingMode31);
        org.apache.commons.math.dfp.Dfp[] dfpArray33 = dfpField29.getLn2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(dfpField29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + roundingMode31 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP + "'", roundingMode31.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP));
        org.junit.Assert.assertNotNull(dfpArray33);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, number2);
        boolean boolean4 = notStrictlyPositiveException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { 32768L, 10000, 'a', 10.0d, 1.0d };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException13 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException3, localizable5, localizable6, objArray12);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray12);
        java.lang.Throwable[] throwableArray15 = mathIllegalArgumentException14.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(throwableArray15);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        double double2 = org.apache.commons.math.util.FastMath.pow((-1.0d), 43.663374525997426d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp((long) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField7.newDfp((long) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp5.subtract(dfp13);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        double double1 = org.apache.commons.math.util.FastMath.ulp(7.105427357601027E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5777218104420236E-30d + "'", double1 == 1.5777218104420236E-30d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        double double2 = org.apache.commons.math.util.FastMath.max(7.105427357601027E-15d, (double) 32768.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32768.0d + "'", double2 == 32768.0d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-0.27140411408419574d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-15.55031027951152d) + "'", double1 == (-15.55031027951152d));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((long) (-1));
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)");
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getZero();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.getLn2();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp7.multiply(dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField14.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField14.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField14.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp11.nextAfter(dfp18);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp3.divide(dfp11);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp11.power10K(0);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        int int3 = dfp2.log10();
        double[] doubleArray4 = dfp2.toSplitDouble();
        boolean boolean5 = dfp2.isNaN();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp4.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp11 = dfp8.newInstance();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp8.floor();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(1283169405);
        boolean boolean2 = mersenneTwister1.nextBoolean();
        mersenneTwister1.setSeed((long) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.7763568394002505E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0177774980683254E-13d + "'", double1 == 1.0177774980683254E-13d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)");
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 8);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 8L + "'", long1 == 8L);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.multiply(dfp7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.power10K((int) (short) 0);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getZero();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getZero();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.getLn2();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp14.multiply(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getZero();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.getZero();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.getLn2();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp23.multiply(dfp27);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getZero();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField30.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.getZero();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.getLn2();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp32.multiply(dfp36);
        org.apache.commons.math.dfp.Dfp dfp38 = org.apache.commons.math.dfp.DfpField.computeLn(dfp18, dfp27, dfp32);
        double[] doubleArray39 = dfp32.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField40 = dfp32.getField();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField40.getPi();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField40.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField44.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField44.newDfp((long) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField44.newDfp((int) (byte) -1);
        boolean boolean50 = dfp42.unequal(dfp49);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp10.nextAfter(dfp49);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp49.newInstance(100);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(dfpField40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp53);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        double double1 = org.apache.commons.math.util.FastMath.cosh(22025.465794806718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        double double1 = org.apache.commons.math.util.FastMath.tanh(5.106711636108507E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister0.setSeed(1);
        int int4 = mersenneTwister0.nextInt(89128932);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 46265381 + "'", int4 == 46265381);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.multiply(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getZero();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.multiply(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getZero();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.getLn2();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp21.multiply(dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp16, dfp21);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp16.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField32.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField32.newDfp((long) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField32.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField32.newDfp((long) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField32.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField32.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField44.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray46 = dfpField44.getESplit();
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField44.newDfp((byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField50.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray52 = dfpField50.getESplit();
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField50.newDfp();
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField50.getLn2();
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField50.newDfp();
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField50.getSqr3();
        boolean boolean57 = dfp48.greaterThan(dfp56);
        org.apache.commons.math.dfp.Dfp dfp58 = dfp56.rint();
        org.apache.commons.math.dfp.Dfp dfp59 = dfp42.remainder(dfp58);
        org.apache.commons.math.dfp.DfpField dfpField61 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField61.newDfp(100);
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField61.getTwo();
        org.apache.commons.math.dfp.Dfp dfp65 = dfp16.dotrap(2147483647, "org.apache.commons.math.exception.MathRuntimeException: {0} is smaller than, or equal to, the minimum ({1}): {0} is smaller than, or equal to, the minimum ({1})", dfp59, dfp64);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfpArray46);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfpArray52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        double double1 = org.apache.commons.math.util.FastMath.abs(5.267831587699267d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.267831587699267d + "'", double1 == 5.267831587699267d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((double) 1283169405);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getLn2();
        dfpField1.setIEEEFlagsBits(10);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.multiply(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getZero();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.multiply(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getZero();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.getLn2();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp21.multiply(dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp16, dfp21);
        java.lang.Class<?> wildcardClass28 = dfp16.getClass();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp16.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getZero();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.getZero();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField35.getLn2();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp33.multiply(dfp37);
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField40.getZero();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField40.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField44.getZero();
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField44.getLn2();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp42.multiply(dfp46);
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField49.getZero();
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField49.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField53 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField53.getZero();
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField53.getLn2();
        org.apache.commons.math.dfp.Dfp dfp56 = dfp51.multiply(dfp55);
        org.apache.commons.math.dfp.Dfp dfp57 = org.apache.commons.math.dfp.DfpField.computeLn(dfp37, dfp46, dfp51);
        double[] doubleArray58 = dfp51.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField59 = dfp51.getField();
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField59.getPi();
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField59.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField63 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField63.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp66 = dfpField63.newDfp((long) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField63.newDfp((int) (byte) -1);
        boolean boolean69 = dfp61.unequal(dfp68);
        org.apache.commons.math.dfp.Dfp dfp70 = dfp16.divide(dfp61);
        org.apache.commons.math.dfp.Dfp dfp72 = dfp70.newInstance((long) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp73 = dfp72.rint();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(dfpField59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp73);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        int int0 = org.apache.commons.math.dfp.Dfp.ERR_SCALE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32760 + "'", int0 == 32760);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        int int2 = org.apache.commons.math.util.FastMath.min((-155033141), (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-155033141) + "'", int2 == (-155033141));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        dfpField1.setIEEEFlagsBits((-543263219));
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        double double1 = org.apache.commons.math.util.FastMath.cosh(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test412() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test412");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        int int1 = mersenneTwister0.nextInt();
//        double double2 = mersenneTwister0.nextGaussian();
//        double double3 = mersenneTwister0.nextGaussian();
//        try {
//            int int5 = mersenneTwister0.nextInt(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-736991639) + "'", int1 == (-736991639));
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.08485925529238895d) + "'", double2 == (-0.08485925529238895d));
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.6773343666594525d + "'", double3 == 1.6773343666594525d);
//    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.0f);
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable2, number3);
        boolean boolean5 = notStrictlyPositiveException4.getBoundIsAllowed();
        java.lang.String str6 = notStrictlyPositiveException4.toString();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.0f);
        notStrictlyPositiveException4.addSuppressed((java.lang.Throwable) notStrictlyPositiveException8);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException8);
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) mathRuntimeException10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)" + "'", str6.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        int[] intArray3 = new int[] { (byte) -1, 2147483647, (byte) 10 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(22.0d);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 10);
        int int3 = mersenneTwister1.nextInt(2);
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister((-1L));
        byte[] byteArray9 = new byte[] { (byte) 10, (byte) 3, (byte) 10 };
        mersenneTwister5.nextBytes(byteArray9);
        mersenneTwister1.nextBytes(byteArray9);
        double double12 = mersenneTwister1.nextDouble();
        double double13 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.020751945593803d + "'", double12 == 0.020751945593803d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-0.5078406675752701d) + "'", double13 == (-0.5078406675752701d));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        double double1 = org.apache.commons.math.util.FastMath.expm1(22.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.584912845131592E9d + "'", double1 == 3.584912845131592E9d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1L));
        int int2 = mersenneTwister1.nextInt();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 93740670 + "'", int2 == 93740670);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.multiply(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField10.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField10.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.newDfp();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp7.nextAfter(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getZero();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getZero();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.getLn2();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp19.multiply(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getZero();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getZero();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField30.getLn2();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp28.multiply(dfp32);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.getZero();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField35.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField39.getZero();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField39.getLn2();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp37.multiply(dfp41);
        org.apache.commons.math.dfp.Dfp dfp43 = org.apache.commons.math.dfp.DfpField.computeLn(dfp23, dfp32, dfp37);
        double[] doubleArray44 = dfp37.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField45 = dfp37.getField();
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.getPi();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField45.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField49.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField49.newDfp((long) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField49.newDfp((int) (byte) -1);
        boolean boolean55 = dfp47.unequal(dfp54);
        org.apache.commons.math.dfp.Dfp dfp56 = dfp7.subtract(dfp47);
        org.apache.commons.math.dfp.Dfp dfp57 = dfp56.floor();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(dfpField45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((long) (short) -1);
        org.apache.commons.math.dfp.DfpField dfpField8 = dfp7.getField();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField8.getSqr2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpField8);
        org.junit.Assert.assertNotNull(dfpArray9);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.multiply(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getZero();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.multiply(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getZero();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.getLn2();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp21.multiply(dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp16, dfp21);
        double[] doubleArray28 = dfp21.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField29 = dfp21.getField();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getPi();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField29.newDfp((int) 'a');
        org.apache.commons.math.dfp.Dfp[] dfpArray33 = dfpField29.getSqr2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(dfpField29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfpArray33);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn5Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.multiply(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getZero();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.multiply(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getZero();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.getLn2();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp21.multiply(dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp16, dfp21);
        double[] doubleArray28 = dfp21.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField29 = dfp21.getField();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getPi();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.getSqr3();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode32 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP;
        dfpField29.setRoundingMode(roundingMode32);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(dfpField29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + roundingMode32 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP + "'", roundingMode32.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(181.01933598375618d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.159383422690394d + "'", double1 == 3.159383422690394d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(0);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((double) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.getTwo();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298292365610485d + "'", double1 == 5.298292365610485d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, number1);
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        java.lang.String str4 = notStrictlyPositiveException2.toString();
        java.lang.Number number5 = notStrictlyPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)" + "'", str4.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.multiply(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getZero();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.multiply(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getZero();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.getLn2();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp21.multiply(dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp16, dfp21);
        double[] doubleArray28 = dfp21.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray32 = dfpField30.getESplit();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField30.newDfp();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp33.getOne();
        int int35 = dfp33.log10K();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp21.nextAfter(dfp33);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfpArray32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(dfp36);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((long) (short) -1);
        org.apache.commons.math.dfp.DfpField dfpField8 = dfp7.getField();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.newDfp((long) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.newInstance((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp13.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.newInstance((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField8.newDfp(dfp19);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode21 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        dfpField8.setRoundingMode(roundingMode21);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpField8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + roundingMode21 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode21.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(0);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((double) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr2Reciprocal();
        int int10 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr3();
        dfpField1.setIEEEFlagsBits((-32767));
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(0);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((double) (byte) 1);
        java.lang.Class<?> wildcardClass7 = dfpField1.getClass();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        double double2 = org.apache.commons.math.util.FastMath.max(1.5650407125795116d, 3.831008000716577E22d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.831008000716577E22d + "'", double2 == 3.831008000716577E22d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 0, (double) 0L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getZero();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getZero();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.getLn2();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp11.multiply(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getZero();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.getZero();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.getLn2();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp20.multiply(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getZero();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getZero();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.getLn2();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp29.multiply(dfp33);
        org.apache.commons.math.dfp.Dfp dfp35 = org.apache.commons.math.dfp.DfpField.computeLn(dfp15, dfp24, dfp29);
        java.lang.Class<?> wildcardClass36 = dfp24.getClass();
        org.apache.commons.math.dfp.Dfp dfp37 = org.apache.commons.math.dfp.DfpField.computeExp(dfp7, dfp24);
        boolean boolean38 = dfp37.isNaN();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp37.newInstance((byte) -1, (byte) 100);
        int int42 = dfp37.log10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(22.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1260.507149287811d + "'", double1 == 1260.507149287811d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(115.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.86294413109428d + "'", double1 == 4.86294413109428d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.843506246783419d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9448497831582735d + "'", double1 == 0.9448497831582735d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.multiply(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getZero();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getLn2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.multiply(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getZero();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.getLn2();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp21.multiply(dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp16, dfp21);
        double[] doubleArray28 = dfp21.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField29 = dfp21.getField();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getPi();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField33.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.newDfp((long) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField33.newDfp((int) (byte) -1);
        boolean boolean39 = dfp31.unequal(dfp38);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp38.ceil();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp40.negate();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(dfpField29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 0.7847284f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.191811581091157d + "'", double1 == 2.191811581091157d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(0);
        dfpField1.setIEEEFlags((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        double double1 = org.apache.commons.math.util.FastMath.atan(11013.232920103323d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707055269358083d + "'", double1 == 1.5707055269358083d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("org.apache.commons.math.exception.NotStrictlyPositiveException: null is smaller than, or equal to, the minimum (0)");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp((long) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp10.newInstance((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getZero();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getZero();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.getLn2();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp18.multiply(dfp22);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.getZero();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getZero();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.getLn2();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp27.multiply(dfp31);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.getZero();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField38.getZero();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField38.getLn2();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp36.multiply(dfp40);
        org.apache.commons.math.dfp.Dfp dfp42 = org.apache.commons.math.dfp.DfpField.computeLn(dfp22, dfp31, dfp36);
        java.lang.Class<?> wildcardClass43 = dfp31.getClass();
        org.apache.commons.math.dfp.Dfp dfp44 = dfp31.getTwo();
        boolean boolean45 = dfp10.greaterThan(dfp31);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp5.nextAfter(dfp10);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp10.newInstance((long) (-1814071466));
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp48);
    }
}

