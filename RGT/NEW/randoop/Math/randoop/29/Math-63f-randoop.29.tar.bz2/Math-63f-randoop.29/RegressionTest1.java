import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        double double1 = org.apache.commons.math.util.FastMath.floor(4.644483341943245d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232874703393d + "'", double1 == 11013.232874703393d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(1, (-1074790265));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(4.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.9999999999999996d + "'", double2 == 3.9999999999999996d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-1074790265));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        long long1 = org.apache.commons.math.util.FastMath.abs((-1074790301L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1074790301L + "'", long1 == 1074790301L);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        double double1 = org.apache.commons.math.util.FastMath.atanh(3.9512437185814275d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        double double1 = org.apache.commons.math.util.FastMath.exp(25600.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 104857599L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 104857600 + "'", int1 == 104857600);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection10, false);
        java.lang.Number number13 = nonMonotonousSequenceException12.getArgument();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        int int15 = nonMonotonousSequenceException12.getIndex();
        boolean boolean16 = nonMonotonousSequenceException12.getStrict();
        int int17 = nonMonotonousSequenceException12.getIndex();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0L + "'", number13.equals(0L));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 32 + "'", int15 == 32);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 32 + "'", int17 == 32);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        double double1 = org.apache.commons.math.util.MathUtils.sign((-0.027178546456142455d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(1089L, 52L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 56628L + "'", long2 == 56628L);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (short) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.4770643681037948d, (java.lang.Number) (byte) -1, 32);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (byte) 1);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 1);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) (short) 0);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) (byte) 1);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 0);
        java.math.BigInteger bigInteger20 = null;
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) (short) 0);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, bigInteger22);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger23);
        java.math.BigInteger bigInteger25 = null;
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, (long) (short) 0);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (long) (byte) 1);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 0);
        java.math.BigInteger bigInteger32 = null;
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, (long) (short) 0);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, bigInteger34);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 1);
        java.math.BigInteger bigInteger38 = null;
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, (long) (short) 0);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, (long) (byte) 1);
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, 0);
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, bigInteger44);
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, bigInteger37);
        try {
            java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, (-2L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger46);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(350000L, (long) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 33950000L + "'", long2 == 33950000L);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 645219163, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 645219164L + "'", long2 == 645219164L);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-1074790399));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0747904E9f + "'", float1 == 1.0747904E9f);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection10, false);
        java.lang.Number number13 = nonMonotonousSequenceException12.getArgument();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        java.lang.Throwable[] throwableArray15 = nonMonotonousSequenceException5.getSuppressed();
        boolean boolean16 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0L + "'", number13.equals(0L));
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 25.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1077477376 + "'", int1 == 1077477376);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) (-104857599L), 0.8813735870195429d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1074790399);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-1), (float) (-1074790399L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0747904E9f) + "'", float2 == (-1.0747904E9f));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(5.69035945432406d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 148.00168918918916d + "'", double1 == 148.00168918918916d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        double[] doubleArray0 = null;
        double[] doubleArray1 = null;
        try {
            double double2 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-10), 645219163);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        long long1 = org.apache.commons.math.util.MathUtils.sign(100L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) '#', 24);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 840 + "'", int2 == 840);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.4770643681037948d, (java.lang.Number) (byte) -1, 32);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        double double1 = org.apache.commons.math.util.FastMath.log(1.7182818284590453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5413248546129181d + "'", double1 == 0.5413248546129181d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        double double2 = org.apache.commons.math.util.FastMath.min(2.3978952727983707d, (double) 1089L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.3978952727983707d + "'", double2 == 2.3978952727983707d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        double double1 = org.apache.commons.math.util.FastMath.signum(3.469446951953614E-18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.8997923511366261d, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-1074790400), (-1074790301L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1155174297527910400L + "'", long2 == 1155174297527910400L);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(3.9512437185814275d, 100.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 296L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 0, 24, 100);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5729.5779513082325d + "'", double1 == 5729.5779513082325d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        long long1 = org.apache.commons.math.util.MathUtils.sign(33950000L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(800.0d, (-0.6156264703860141d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 799.9999999999999d + "'", double2 == 799.9999999999999d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        double double1 = org.apache.commons.math.util.FastMath.atan(363.7393755555636d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.568047112528285d + "'", double1 == 1.568047112528285d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        long long2 = org.apache.commons.math.util.FastMath.max(3104L, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3104L + "'", long2 == 3104L);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-1.07479027E9f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(840, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.733401891837359d + "'", double2 == 6.733401891837359d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-349698017));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-1074790272));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7182818284590453d + "'", double1 == 1.7182818284590453d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(1.0747904E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 104857600, (int) (short) 100, 25);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (-1.61728282E9f), (double) (-1074790399L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0747903974632568E9d) + "'", double2 == (-1.0747903974632568E9d));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.21513152916302059d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 784365034 + "'", int1 == 784365034);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(645219163, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        double double1 = org.apache.commons.math.util.FastMath.rint(5.794493116621174d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.0d + "'", double1 == 6.0d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        double double1 = org.apache.commons.math.util.FastMath.signum((-0.9707928525119764d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-1074790272));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(5.794493116621174d, 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.345392677303175E30d + "'", double2 == 7.345392677303175E30d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 3104, (long) (-1074790400));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1074787296L) + "'", long2 == (-1074787296L));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (short) 0, 35L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) (-1074790399), 1.0747904E9d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        double double1 = org.apache.commons.math.util.FastMath.asinh(6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.537297501373361d + "'", double1 == 2.537297501373361d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.3187475604206444d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.31358290969207164d + "'", double1 == 0.31358290969207164d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.1752011936438014d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3945753355078114d + "'", double1 == 2.3945753355078114d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 3628800L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3628800.0f + "'", float1 == 3628800.0f);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-0.5859157583671175d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-33.57050010464278d) + "'", double1 == (-33.57050010464278d));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(332, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 24, 148.00168918918916d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.8775659957116055E204d + "'", double2 == 1.8775659957116055E204d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 840);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 1074790399L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.031323778267323d + "'", double1 == 9.031323778267323d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        long long1 = org.apache.commons.math.util.FastMath.round(3.4657359027997265d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3L + "'", long1 == 3L);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 645219164L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1261198808765266E7d + "'", double1 == 1.1261198808765266E7d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(331);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1593.321431732963d + "'", double1 == 1593.321431732963d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 0, 350000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        int int1 = org.apache.commons.math.util.MathUtils.sign(3104);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 331);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 56628L, 784365034, (int) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, 104857599L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        double double2 = org.apache.commons.math.util.FastMath.min(52.0d, 171.49903622517783d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (-1074790265));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0747902649999998E9d) + "'", double1 == (-1.0747902649999998E9d));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 25600L, 10.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 332, (int) (byte) 100);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        double double2 = org.apache.commons.math.util.FastMath.pow(2.877157801747449d, 1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0000000000000002d + "'", double2 == 1.0000000000000002d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        double double2 = org.apache.commons.math.util.MathUtils.round(1.5713088006770572d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.8997923511366261d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        double double1 = org.apache.commons.math.util.FastMath.tan((-0.9707928525119764d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.4616850498538323d) + "'", double1 == (-1.4616850498538323d));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        int int2 = org.apache.commons.math.util.FastMath.max(4, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) (short) 0, (-1074790300));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1074790300) + "'", int2 == (-1074790300));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.0185715175166554d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017777426647700732d + "'", double1 == 0.017777426647700732d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        int int1 = org.apache.commons.math.util.MathUtils.sign(31);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-356830412468L), (long) 10000);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        long long2 = org.apache.commons.math.util.FastMath.min(100L, 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        double double1 = org.apache.commons.math.util.FastMath.tan(2.537297501373361d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.690460899280118d) + "'", double1 == (-0.690460899280118d));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        double double1 = org.apache.commons.math.util.FastMath.ceil(11013.232874703393d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11014.0d + "'", double1 == 11014.0d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-1074790300));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-1074790399L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.7853981633974483d), (java.lang.Number) 2.356194490192345d, 10);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (2.356 >= -0.785)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (2.356 >= -0.785)"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1074790399);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0747904E9f + "'", float1 == 1.0747904E9f);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 784365034, (long) 331);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 331L + "'", long2 == 331L);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 3628800L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 840);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 3104L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) (short) 1, 3104);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-1074790399), (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1074790347L) + "'", long2 == (-1074790347L));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        double double1 = org.apache.commons.math.util.MathUtils.sign(3.469446951953614E-18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1074790300));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1074790300 + "'", int1 == 1074790300);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5422326689561365d + "'", double1 == 1.5422326689561365d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) 0);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        double double1 = org.apache.commons.math.util.FastMath.rint((-1.2246467991473532E-16d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.10336039907518849d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2113877735) + "'", int1 == (-2113877735));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) 1);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 104857600);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(10000, (-2113877735));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2113867735) + "'", int2 == (-2113867735));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.6585287573834833d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-1.61728282E9f), (double) 3500L, 10000);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (byte) -1, 11013.232874703393d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        double double1 = org.apache.commons.math.util.FastMath.tan((-33.57050010464278d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5138200998174591d + "'", double1 == 1.5138200998174591d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.568047112528285d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2319257889732327d + "'", double1 == 1.2319257889732327d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(784365034);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        float float2 = org.apache.commons.math.util.FastMath.min(25.0f, (float) (-1L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray7 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray7);
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray1);
        int int10 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray11 = new double[] {};
        double[] doubleArray17 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray17);
        double[] doubleArray19 = new double[] {};
        double[] doubleArray25 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray25);
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray25);
        double[] doubleArray28 = new double[] {};
        double[] doubleArray34 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray34);
        double[] doubleArray36 = new double[] {};
        double[] doubleArray42 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray36, doubleArray42);
        double double44 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray42);
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray34);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray34);
        try {
            double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, 1.3440585709080678E43d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        double[] doubleArray8 = new double[] {};
        double[] doubleArray14 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray14);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5574077246549023d), (java.lang.Number) 28.382454981066388d, (-10), orderDirection20, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14, orderDirection20, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not increasing (39,481,480,091,340.34 > 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection20.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        int int2 = org.apache.commons.math.util.FastMath.max((int) ' ', (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.267884728309446d + "'", double1 == 5.267884728309446d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1074790265), 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1074790275) + "'", int2 == (-1074790275));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(104857599, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 1074790347L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 104857599, (long) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        double double1 = org.apache.commons.math.util.FastMath.abs(2.302585092994046d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.302585092994046d + "'", double1 == 2.302585092994046d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(35.0d, (double) (-1074790272));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 34.99999999999999d + "'", double2 == 34.99999999999999d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 52L, (double) (byte) 0, (double) (-1074790272));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        int int2 = org.apache.commons.math.util.FastMath.min((-10), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-10) + "'", int2 == (-10));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.8324875211176866d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9320322838607713d + "'", double1 == 0.9320322838607713d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        double double1 = org.apache.commons.math.util.FastMath.asinh(5.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3124383412727525d + "'", double1 == 2.3124383412727525d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (-104857599L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-104857599), (-1.0747903974632568E9d), 0.7071067811865476d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        double double1 = org.apache.commons.math.util.FastMath.tan(2.993222846126381d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.1494681981443936d) + "'", double1 == (-0.1494681981443936d));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection10, false);
        java.lang.Number number13 = nonMonotonousSequenceException12.getArgument();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException12.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection19, false);
        java.lang.Throwable[] throwableArray22 = nonMonotonousSequenceException21.getSuppressed();
        java.lang.Number number23 = nonMonotonousSequenceException21.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = nonMonotonousSequenceException21.getDirection();
        java.lang.Throwable[] throwableArray25 = nonMonotonousSequenceException21.getSuppressed();
        nonMonotonousSequenceException12.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException21);
        java.lang.Throwable[] throwableArray27 = nonMonotonousSequenceException12.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0L + "'", number13.equals(0L));
        org.junit.Assert.assertNull(orderDirection15);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0L + "'", number23.equals(0L));
        org.junit.Assert.assertNull(orderDirection24);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(throwableArray27);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-1074790400L), (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 104857599, (java.lang.Number) (-1.0747904E9f), (int) (short) 10);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        double double1 = org.apache.commons.math.util.FastMath.acos((-0.5859157583671175d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1968059704696543d + "'", double1 == 2.1968059704696543d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-104857599));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 104L, (double) 1074790300);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 104.00000000000001d + "'", double2 == 104.00000000000001d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) (short) -1, (-1074790347L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 8519509564645355905L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.8775659957116055E204d, (java.lang.Number) (-1.1752011936438014d), 4);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray7 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray7);
        double[] doubleArray9 = new double[] {};
        double[] doubleArray15 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray15);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray15);
        double[] doubleArray18 = new double[] {};
        double[] doubleArray24 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray24);
        double[] doubleArray26 = new double[] {};
        double[] doubleArray32 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray32);
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray24);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) 32L);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray15);
        double[] doubleArray39 = new double[] {};
        double[] doubleArray45 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray45);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray39);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.5422326689561365d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9995920864606948d + "'", double1 == 0.9995920864606948d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 35, 100.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(1.8775659957116055E204d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-1.1752011936438014d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-67.3340684745264d) + "'", double1 == (-67.3340684745264d));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1074790399, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) (short) 1, 331);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 3.948148009134E13d, 1074790399);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        int int2 = org.apache.commons.math.util.FastMath.min(0, 104857599);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 416L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.6843418860808015E-14d + "'", double1 == 5.6843418860808015E-14d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((int) '#', (-1074790265));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-1074790399));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (byte) 1);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 1);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) (short) 0);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) (byte) 1);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 0);
        java.math.BigInteger bigInteger20 = null;
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) (short) 0);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, bigInteger22);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger23);
        java.math.BigInteger bigInteger25 = null;
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, (long) (short) 0);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (long) (byte) 1);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 0);
        java.math.BigInteger bigInteger32 = null;
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, (long) (short) 0);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, bigInteger34);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 1);
        java.math.BigInteger bigInteger38 = null;
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, (long) (short) 0);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, (long) (byte) 1);
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, 0);
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, bigInteger44);
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, bigInteger37);
        java.math.BigInteger bigInteger47 = null;
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger47, (long) (short) 0);
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger49, (long) (byte) 1);
        java.math.BigInteger bigInteger53 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, 0);
        java.math.BigInteger bigInteger54 = null;
        java.math.BigInteger bigInteger56 = org.apache.commons.math.util.MathUtils.pow(bigInteger54, (long) (short) 0);
        java.math.BigInteger bigInteger57 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, bigInteger56);
        java.math.BigInteger bigInteger59 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, 1);
        java.math.BigInteger bigInteger60 = null;
        java.math.BigInteger bigInteger62 = org.apache.commons.math.util.MathUtils.pow(bigInteger60, (long) (short) 0);
        java.math.BigInteger bigInteger64 = org.apache.commons.math.util.MathUtils.pow(bigInteger62, (long) (byte) 1);
        java.math.BigInteger bigInteger66 = org.apache.commons.math.util.MathUtils.pow(bigInteger64, 0);
        java.math.BigInteger bigInteger67 = null;
        java.math.BigInteger bigInteger69 = org.apache.commons.math.util.MathUtils.pow(bigInteger67, (long) (short) 0);
        java.math.BigInteger bigInteger70 = org.apache.commons.math.util.MathUtils.pow(bigInteger64, bigInteger69);
        java.math.BigInteger bigInteger71 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, bigInteger70);
        java.lang.Class<?> wildcardClass72 = bigInteger71.getClass();
        java.math.BigInteger bigInteger73 = org.apache.commons.math.util.MathUtils.pow(bigInteger46, bigInteger71);
        try {
            java.math.BigInteger bigInteger75 = org.apache.commons.math.util.MathUtils.pow(bigInteger46, (-2113877735));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger49);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger53);
        org.junit.Assert.assertNotNull(bigInteger56);
        org.junit.Assert.assertNotNull(bigInteger57);
        org.junit.Assert.assertNotNull(bigInteger59);
        org.junit.Assert.assertNotNull(bigInteger62);
        org.junit.Assert.assertNotNull(bigInteger64);
        org.junit.Assert.assertNotNull(bigInteger66);
        org.junit.Assert.assertNotNull(bigInteger69);
        org.junit.Assert.assertNotNull(bigInteger70);
        org.junit.Assert.assertNotNull(bigInteger71);
        org.junit.Assert.assertNotNull(wildcardClass72);
        org.junit.Assert.assertNotNull(bigInteger73);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 0L, Float.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + Float.NEGATIVE_INFINITY + "'", float2 == Float.NEGATIVE_INFINITY);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 10, 56628L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        long long1 = org.apache.commons.math.util.FastMath.round(0.8997923511366261d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-349698017));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        float float1 = org.apache.commons.math.util.FastMath.abs(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        int int2 = org.apache.commons.math.util.MathUtils.pow(840, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) 100, (float) 784365034);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 7.8436506E8f + "'", float2 == 7.8436506E8f);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        double[] doubleArray8 = new double[] {};
        double[] doubleArray14 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray14);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        double[] doubleArray18 = new double[] {};
        double[] doubleArray24 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray24);
        double[] doubleArray26 = new double[] {};
        double[] doubleArray32 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray32);
        double[] doubleArray35 = new double[] {};
        double[] doubleArray41 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray35, doubleArray41);
        double[] doubleArray43 = new double[] {};
        double[] doubleArray49 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray43, doubleArray49);
        double double51 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray49);
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray41);
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) 32L);
        double double55 = org.apache.commons.math.util.MathUtils.distance(doubleArray14, doubleArray32);
        double[] doubleArray56 = new double[] {};
        double[] doubleArray62 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray56, doubleArray62);
        double[] doubleArray64 = new double[] {};
        double[] doubleArray70 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray64, doubleArray70);
        double double72 = org.apache.commons.math.util.MathUtils.distance1(doubleArray62, doubleArray70);
        double[] doubleArray73 = new double[] {};
        double[] doubleArray79 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray73, doubleArray79);
        double[] doubleArray81 = new double[] {};
        double[] doubleArray87 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean88 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray81, doubleArray87);
        double double89 = org.apache.commons.math.util.MathUtils.distance1(doubleArray79, doubleArray87);
        double double90 = org.apache.commons.math.util.MathUtils.distance1(doubleArray70, doubleArray79);
        double[] doubleArray97 = new double[] { 0.7853981633974483d, 1.5430806348152437d, (byte) 1, 100.0f, 33.0d, (byte) 0 };
        double double98 = org.apache.commons.math.util.MathUtils.distance(doubleArray79, doubleArray97);
        double double99 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray32, doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1617282775) + "'", int17 == (-1617282775));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray97);
        org.junit.Assert.assertTrue("'" + double98 + "' != '" + 3.94814800913388E13d + "'", double98 == 3.94814800913388E13d);
        org.junit.Assert.assertTrue("'" + double99 + "' != '" + 0.0d + "'", double99 == 0.0d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-1074790400), 25600L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 25600L + "'", long2 == 25600L);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(22025.465794806718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 384.416897404767d + "'", double1 == 384.416897404767d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        double[] doubleArray8 = new double[] {};
        double[] doubleArray14 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray14);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        double[] doubleArray18 = new double[] {};
        double[] doubleArray24 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray24);
        double[] doubleArray26 = new double[] {};
        double[] doubleArray32 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray32);
        double[] doubleArray35 = new double[] {};
        double[] doubleArray41 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray35, doubleArray41);
        double[] doubleArray43 = new double[] {};
        double[] doubleArray49 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray43, doubleArray49);
        double double51 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray49);
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray41);
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) 32L);
        double double55 = org.apache.commons.math.util.MathUtils.distance(doubleArray14, doubleArray32);
        double[] doubleArray56 = null;
        try {
            double double57 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray32, doubleArray56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1617282775) + "'", int17 == (-1617282775));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        double double1 = org.apache.commons.math.util.FastMath.tan((-1.4616850498538323d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-9.128556195892921d) + "'", double1 == (-9.128556195892921d));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.154434690031884d + "'", double1 == 2.154434690031884d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 104857600, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.266676217317581d + "'", double2 == 2.266676217317581d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.10336039907518849d, (double) '#', (double) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(32L, (-349698017));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        int[] intArray0 = new int[] {};
        int[] intArray1 = null;
        double double2 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray1);
        int[] intArray8 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray15 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray8, intArray15);
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray8);
        int[] intArray23 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray30 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int31 = org.apache.commons.math.util.MathUtils.distanceInf(intArray23, intArray30);
        int[] intArray37 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray44 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int45 = org.apache.commons.math.util.MathUtils.distanceInf(intArray37, intArray44);
        int[] intArray51 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray58 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int59 = org.apache.commons.math.util.MathUtils.distanceInf(intArray51, intArray58);
        int int60 = org.apache.commons.math.util.MathUtils.distanceInf(intArray37, intArray58);
        int int61 = org.apache.commons.math.util.MathUtils.distance1(intArray30, intArray58);
        double double62 = org.apache.commons.math.util.MathUtils.distance(intArray8, intArray30);
        int[] intArray68 = new int[] { ' ', (-104857599), ' ', (byte) -1, 104857599 };
        try {
            double double69 = org.apache.commons.math.util.MathUtils.distance(intArray30, intArray68);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 100 + "'", int31 == 100);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 100 + "'", int45 == 100);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 100 + "'", int59 == 100);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 100 + "'", int60 == 100);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 175.57049866079439d + "'", double62 == 175.57049866079439d);
        org.junit.Assert.assertNotNull(intArray68);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(840, (-1074790275));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1074791115 + "'", int2 == 1074791115);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) '#', 2.1968059704696543d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.221357926205738d + "'", double2 == 0.221357926205738d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.8775659957116055E204d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(104857599, 332);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 104857931 + "'", int2 == 104857931);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-1074790275), 33950000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1074790275L) + "'", long2 == (-1074790275L));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1074790399), (-2113867735));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        double double1 = org.apache.commons.math.util.FastMath.atan(6.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4056476493802699d + "'", double1 == 1.4056476493802699d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.7071067811865476d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(4L, 33L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-29L) + "'", long2 == (-29L));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(100.53096491487338d, (double) (-1074790275L));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection3, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.4770643681037948d, (java.lang.Number) (byte) -1, 32);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        java.lang.Number number11 = nonMonotonousSequenceException9.getPrevious();
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (byte) -1 + "'", number11.equals((byte) -1));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        double double2 = org.apache.commons.math.util.FastMath.atan2(100.0d, 22026.465794806718d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.004539961784557667d + "'", double2 == 0.004539961784557667d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        int[] intArray0 = new int[] {};
        int[] intArray1 = null;
        double double2 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray1);
        int[] intArray8 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray15 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray8, intArray15);
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray8);
        int[] intArray23 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray30 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int31 = org.apache.commons.math.util.MathUtils.distanceInf(intArray23, intArray30);
        int[] intArray37 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray44 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int45 = org.apache.commons.math.util.MathUtils.distanceInf(intArray37, intArray44);
        int int46 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray44);
        int int47 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray23);
        int[] intArray53 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray60 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int61 = org.apache.commons.math.util.MathUtils.distanceInf(intArray53, intArray60);
        int[] intArray67 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray74 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int75 = org.apache.commons.math.util.MathUtils.distanceInf(intArray67, intArray74);
        int[] intArray81 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray88 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int89 = org.apache.commons.math.util.MathUtils.distanceInf(intArray81, intArray88);
        int int90 = org.apache.commons.math.util.MathUtils.distanceInf(intArray67, intArray88);
        int int91 = org.apache.commons.math.util.MathUtils.distance1(intArray60, intArray88);
        double double92 = org.apache.commons.math.util.MathUtils.distance(intArray23, intArray88);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 100 + "'", int31 == 100);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 100 + "'", int45 == 100);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 331 + "'", int46 == 331);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 100 + "'", int61 == 100);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 100 + "'", int75 == 100);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertNotNull(intArray88);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 100 + "'", int89 == 100);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 100 + "'", int90 == 100);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 0 + "'", int91 == 0);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 175.57049866079439d + "'", double92 == 175.57049866079439d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) ' ', (int) 'a');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (double) (-29L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-2113877735));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2.11387776E9f + "'", float1 == 2.11387776E9f);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (byte) 1);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 1);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) (short) 0);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) (byte) 1);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 0);
        java.math.BigInteger bigInteger20 = null;
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) (short) 0);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, bigInteger22);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger23);
        java.math.BigInteger bigInteger25 = null;
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, (long) (short) 0);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (long) (byte) 1);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 0);
        java.math.BigInteger bigInteger32 = null;
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, (long) (short) 0);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, bigInteger34);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 1);
        java.math.BigInteger bigInteger38 = null;
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, (long) (short) 0);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, (long) (byte) 1);
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, 0);
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, bigInteger44);
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, bigInteger37);
        java.math.BigInteger bigInteger47 = null;
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger47, (long) (short) 0);
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger49, (long) (byte) 1);
        java.math.BigInteger bigInteger53 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, 0);
        java.math.BigInteger bigInteger54 = null;
        java.math.BigInteger bigInteger56 = org.apache.commons.math.util.MathUtils.pow(bigInteger54, (long) (short) 0);
        java.math.BigInteger bigInteger57 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, bigInteger56);
        java.math.BigInteger bigInteger59 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, 1);
        java.math.BigInteger bigInteger60 = null;
        java.math.BigInteger bigInteger62 = org.apache.commons.math.util.MathUtils.pow(bigInteger60, (long) (short) 0);
        java.math.BigInteger bigInteger64 = org.apache.commons.math.util.MathUtils.pow(bigInteger62, (long) (byte) 1);
        java.math.BigInteger bigInteger66 = org.apache.commons.math.util.MathUtils.pow(bigInteger64, 0);
        java.math.BigInteger bigInteger67 = null;
        java.math.BigInteger bigInteger69 = org.apache.commons.math.util.MathUtils.pow(bigInteger67, (long) (short) 0);
        java.math.BigInteger bigInteger70 = org.apache.commons.math.util.MathUtils.pow(bigInteger64, bigInteger69);
        java.math.BigInteger bigInteger71 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, bigInteger70);
        java.lang.Class<?> wildcardClass72 = bigInteger71.getClass();
        java.math.BigInteger bigInteger73 = org.apache.commons.math.util.MathUtils.pow(bigInteger46, bigInteger71);
        java.math.BigInteger bigInteger75 = org.apache.commons.math.util.MathUtils.pow(bigInteger71, 0L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger49);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger53);
        org.junit.Assert.assertNotNull(bigInteger56);
        org.junit.Assert.assertNotNull(bigInteger57);
        org.junit.Assert.assertNotNull(bigInteger59);
        org.junit.Assert.assertNotNull(bigInteger62);
        org.junit.Assert.assertNotNull(bigInteger64);
        org.junit.Assert.assertNotNull(bigInteger66);
        org.junit.Assert.assertNotNull(bigInteger69);
        org.junit.Assert.assertNotNull(bigInteger70);
        org.junit.Assert.assertNotNull(bigInteger71);
        org.junit.Assert.assertNotNull(wildcardClass72);
        org.junit.Assert.assertNotNull(bigInteger73);
        org.junit.Assert.assertNotNull(bigInteger75);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        double double1 = org.apache.commons.math.util.FastMath.cos(800.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.44812751321749233d) + "'", double1 == (-0.44812751321749233d));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-104857599L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-104857600) + "'", int1 == (-104857600));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        int int2 = org.apache.commons.math.util.MathUtils.pow(104857599, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-1074790347L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-0.014686439244896978d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963267948966d) + "'", double2 == (-1.5707963267948966d));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 1074790301L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.488538591220372d + "'", double1 == 21.488538591220372d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1074790399);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-356830412468L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.227865568816026E9d) + "'", double1 == (-6.227865568816026E9d));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5860134523134308E15d + "'", double1 == 1.5860134523134308E15d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        int int1 = org.apache.commons.math.util.MathUtils.hash((-0.014686439244896978d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1032654167 + "'", int1 == 1032654167);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (byte) 1);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 1);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) (short) 0);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) (byte) 1);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 0);
        java.math.BigInteger bigInteger20 = null;
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) (short) 0);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, bigInteger22);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger23);
        java.math.BigInteger bigInteger25 = null;
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, (long) (short) 0);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (long) (byte) 1);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 0);
        java.math.BigInteger bigInteger32 = null;
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, (long) (short) 0);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, bigInteger34);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 1);
        java.math.BigInteger bigInteger38 = null;
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, (long) (short) 0);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, (long) (byte) 1);
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, 0);
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, bigInteger44);
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, bigInteger37);
        java.math.BigInteger bigInteger47 = null;
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger47, (long) (short) 0);
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger49, (long) (byte) 1);
        java.math.BigInteger bigInteger53 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, 0);
        java.math.BigInteger bigInteger54 = null;
        java.math.BigInteger bigInteger56 = org.apache.commons.math.util.MathUtils.pow(bigInteger54, (long) (short) 0);
        java.math.BigInteger bigInteger57 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, bigInteger56);
        java.math.BigInteger bigInteger59 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, 1);
        java.math.BigInteger bigInteger60 = null;
        java.math.BigInteger bigInteger62 = org.apache.commons.math.util.MathUtils.pow(bigInteger60, (long) (short) 0);
        java.math.BigInteger bigInteger64 = org.apache.commons.math.util.MathUtils.pow(bigInteger62, (long) (byte) 1);
        java.math.BigInteger bigInteger66 = org.apache.commons.math.util.MathUtils.pow(bigInteger64, 0);
        java.math.BigInteger bigInteger67 = null;
        java.math.BigInteger bigInteger69 = org.apache.commons.math.util.MathUtils.pow(bigInteger67, (long) (short) 0);
        java.math.BigInteger bigInteger70 = org.apache.commons.math.util.MathUtils.pow(bigInteger64, bigInteger69);
        java.math.BigInteger bigInteger71 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, bigInteger70);
        java.lang.Class<?> wildcardClass72 = bigInteger71.getClass();
        java.math.BigInteger bigInteger73 = org.apache.commons.math.util.MathUtils.pow(bigInteger46, bigInteger71);
        java.math.BigInteger bigInteger74 = null;
        java.math.BigInteger bigInteger76 = org.apache.commons.math.util.MathUtils.pow(bigInteger74, (long) (short) 0);
        java.math.BigInteger bigInteger78 = org.apache.commons.math.util.MathUtils.pow(bigInteger76, (long) (byte) 1);
        java.math.BigInteger bigInteger80 = org.apache.commons.math.util.MathUtils.pow(bigInteger78, 0);
        java.math.BigInteger bigInteger81 = null;
        java.math.BigInteger bigInteger83 = org.apache.commons.math.util.MathUtils.pow(bigInteger81, (long) (short) 0);
        java.math.BigInteger bigInteger84 = org.apache.commons.math.util.MathUtils.pow(bigInteger78, bigInteger83);
        java.math.BigInteger bigInteger86 = org.apache.commons.math.util.MathUtils.pow(bigInteger78, 840);
        java.math.BigInteger bigInteger87 = org.apache.commons.math.util.MathUtils.pow(bigInteger73, bigInteger86);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger49);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger53);
        org.junit.Assert.assertNotNull(bigInteger56);
        org.junit.Assert.assertNotNull(bigInteger57);
        org.junit.Assert.assertNotNull(bigInteger59);
        org.junit.Assert.assertNotNull(bigInteger62);
        org.junit.Assert.assertNotNull(bigInteger64);
        org.junit.Assert.assertNotNull(bigInteger66);
        org.junit.Assert.assertNotNull(bigInteger69);
        org.junit.Assert.assertNotNull(bigInteger70);
        org.junit.Assert.assertNotNull(bigInteger71);
        org.junit.Assert.assertNotNull(wildcardClass72);
        org.junit.Assert.assertNotNull(bigInteger73);
        org.junit.Assert.assertNotNull(bigInteger76);
        org.junit.Assert.assertNotNull(bigInteger78);
        org.junit.Assert.assertNotNull(bigInteger80);
        org.junit.Assert.assertNotNull(bigInteger83);
        org.junit.Assert.assertNotNull(bigInteger84);
        org.junit.Assert.assertNotNull(bigInteger86);
        org.junit.Assert.assertNotNull(bigInteger87);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        double[] doubleArray8 = new double[] {};
        double[] doubleArray14 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray14);
        double[] doubleArray16 = new double[] {};
        double[] doubleArray22 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray22);
        double[] doubleArray25 = new double[] {};
        double[] doubleArray31 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray31);
        double[] doubleArray33 = new double[] {};
        double[] doubleArray39 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray39);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray31, doubleArray39);
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray31);
        double[] doubleArray43 = null;
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray43);
        double double45 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray43);
        double[] doubleArray46 = new double[] {};
        double[] doubleArray52 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray46, doubleArray52);
        double[] doubleArray54 = new double[] {};
        double[] doubleArray60 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray54, doubleArray60);
        double[] doubleArray62 = new double[] {};
        double[] doubleArray68 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray68);
        double double70 = org.apache.commons.math.util.MathUtils.distance1(doubleArray60, doubleArray68);
        double[] doubleArray71 = new double[] {};
        double[] doubleArray77 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray71, doubleArray77);
        double[] doubleArray79 = new double[] {};
        double[] doubleArray85 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray79, doubleArray85);
        double double87 = org.apache.commons.math.util.MathUtils.distance1(doubleArray77, doubleArray85);
        double double88 = org.apache.commons.math.util.MathUtils.distance1(doubleArray68, doubleArray77);
        double[] doubleArray89 = null;
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray68, doubleArray89);
        double double91 = org.apache.commons.math.util.MathUtils.distance(doubleArray46, doubleArray89);
        try {
            double double92 = org.apache.commons.math.util.MathUtils.distance1(doubleArray43, doubleArray89);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 416L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 416L + "'", long1 == 416L);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 31);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        float float1 = org.apache.commons.math.util.MathUtils.sign(25.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        int int1 = org.apache.commons.math.util.FastMath.round(Float.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2147483648) + "'", int1 == (-2147483648));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-10), (float) 31);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 31.0f + "'", float2 == 31.0f);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 4L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 1077477376);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5574077246549023d), (java.lang.Number) 28.382454981066388d, (-10), orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.49536728921867335d, (java.lang.Number) 1, 0);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection8, false);
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException10.getSuppressed();
        java.lang.Number number12 = nonMonotonousSequenceException10.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException10.getDirection();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        java.lang.Class<?> wildcardClass15 = nonMonotonousSequenceException3.getClass();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0L + "'", number12.equals(0L));
        org.junit.Assert.assertNull(orderDirection13);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.5413248546129181d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7357478199851618d + "'", double1 == 0.7357478199851618d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) -1, 1074790300);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        int int1 = org.apache.commons.math.util.MathUtils.sign(800);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(645219163, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(2.3978952727983707d, 1.5860134523134308E15d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5860134523134298E15d + "'", double2 == 1.5860134523134298E15d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 1089L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1089.0d + "'", double1 == 1089.0d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        long long1 = org.apache.commons.math.util.MathUtils.sign(1074790347L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1074790300, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1661992960 + "'", int2 == 1661992960);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) 0, (long) 24);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 1074790399L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1024.3332245675347d + "'", double1 == 1024.3332245675347d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        int[] intArray5 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray12 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int13 = org.apache.commons.math.util.MathUtils.distanceInf(intArray5, intArray12);
        int[] intArray14 = new int[] {};
        int[] intArray15 = new int[] {};
        int[] intArray16 = null;
        double double17 = org.apache.commons.math.util.MathUtils.distance(intArray15, intArray16);
        int int18 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray16);
        int[] intArray24 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray31 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int32 = org.apache.commons.math.util.MathUtils.distanceInf(intArray24, intArray31);
        int[] intArray38 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray45 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int46 = org.apache.commons.math.util.MathUtils.distanceInf(intArray38, intArray45);
        int[] intArray52 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray59 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int60 = org.apache.commons.math.util.MathUtils.distanceInf(intArray52, intArray59);
        int int61 = org.apache.commons.math.util.MathUtils.distanceInf(intArray38, intArray59);
        int int62 = org.apache.commons.math.util.MathUtils.distance1(intArray31, intArray59);
        java.lang.Class<?> wildcardClass63 = intArray31.getClass();
        int int64 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray31);
        int int65 = org.apache.commons.math.util.MathUtils.distanceInf(intArray12, intArray31);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 100 + "'", int32 == 100);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 100 + "'", int46 == 100);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 100 + "'", int60 == 100);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 100 + "'", int61 == 100);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 35);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) -1);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) -1 + "'", byte1 == (byte) -1);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        int int2 = org.apache.commons.math.util.FastMath.min((-1074790265), (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1074790265) + "'", int2 == (-1074790265));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 3628800L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1095479168 + "'", int1 == 1095479168);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 97L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.0d + "'", double1 == 97.0d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, 0.7945982305639963d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (byte) 100, 52L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-0.30005830960817476d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.29136597282280424d) + "'", double1 == (-0.29136597282280424d));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 10, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 331);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.424151709070136d) + "'", double1 == (-0.424151709070136d));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 104857599);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963172581534d + "'", double1 == 1.5707963172581534d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-0.29136597282280424d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963267948966d) + "'", double1 == (-1.5707963267948966d));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.9995920864606948d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(28.382454981066388d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.49536728921867335d + "'", double1 == 0.49536728921867335d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        long long1 = org.apache.commons.math.util.FastMath.round(1.7182818284590453d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-1), 1077477376, (-1617282775));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1074790300), (-104857600));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 840);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 28.982753492378876d + "'", double1 == 28.982753492378876d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5063656411097588d) + "'", double1 == (-0.5063656411097588d));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (-349698017L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        int int2 = org.apache.commons.math.util.FastMath.min(24, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.3030247335881318d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.6804121146529942d + "'", double1 == 3.6804121146529942d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(1024.3332245675347d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) -1, (-2147483648));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(4, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (byte) 1);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger9);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) (short) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) (byte) 1);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 0);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) (byte) 100);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        double double1 = org.apache.commons.math.util.FastMath.tan(4.641588833612779d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 14.100656565716534d + "'", double1 == 14.100656565716534d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 0, 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) ' ', 0.9320322838607713d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 31.999999999999996d + "'", double2 == 31.999999999999996d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        double double1 = org.apache.commons.math.util.FastMath.asin(1024.3332245675347d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5860134523134298E15d + "'", double1 == 1.5860134523134298E15d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(9.031323778267323d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4180.46006726935d + "'", double1 == 4180.46006726935d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, 3104);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 645219164L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1920928955078125E-7d + "'", double1 == 1.1920928955078125E-7d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        double double1 = org.apache.commons.math.util.FastMath.abs(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 31.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 104857599);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.048576E8f + "'", float1 == 1.048576E8f);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-1074790275), (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1074790274L) + "'", long2 == (-1074790274L));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-0.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-1074790275));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.7407750251209115d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 4L, 0, 1074790399);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (-1074790399));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1555698629817919d + "'", double1 == 1.1555698629817919d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        long long2 = org.apache.commons.math.util.FastMath.min(1155174297527910400L, (long) 332);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 332L + "'", long2 == 332L);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.004539961784557667d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1991318963) + "'", int1 == (-1991318963));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-29L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1661.5776058793872d) + "'", double1 == (-1661.5776058793872d));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1074790399));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1074790399 + "'", int1 == 1074790399);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 32);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.6585287573834833d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, 11013.232874703393d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.31358290969207164d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.31358290969207164d + "'", double1 == 0.31358290969207164d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        double double1 = org.apache.commons.math.util.FastMath.cosh(3.6804121146529942d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 19.843974440965976d + "'", double1 == 19.843974440965976d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((int) 'a', (-1074790272));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 331, (double) (-1));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1095479168, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, 1074790399);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.8813735870195429d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.414213562373095d + "'", double1 == 1.414213562373095d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        int int2 = org.apache.commons.math.util.FastMath.max(1095479168, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1095479168 + "'", int2 == 1095479168);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        int int1 = org.apache.commons.math.util.MathUtils.hash(33.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1077968896 + "'", int1 == 1077968896);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-104857600));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.048576E8d) + "'", double1 == (-1.048576E8d));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) '#', (double) 31);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.346988750381666E47d + "'", double2 == 7.346988750381666E47d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(2.3124383412727525d, (double) 1661992960, (int) ' ');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        double double1 = org.apache.commons.math.util.FastMath.asinh(97.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.267884728309446d + "'", double1 == 5.267884728309446d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-1074790400));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        double[] doubleArray8 = new double[] {};
        double[] doubleArray14 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray14);
        double[] doubleArray17 = new double[] {};
        double[] doubleArray23 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray23);
        double[] doubleArray25 = new double[] {};
        double[] doubleArray31 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray31);
        double[] doubleArray34 = new double[] {};
        double[] doubleArray40 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray40);
        double[] doubleArray42 = new double[] {};
        double[] doubleArray48 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray42, doubleArray48);
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray48);
        double double51 = org.apache.commons.math.util.MathUtils.distance1(doubleArray31, doubleArray40);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray40);
        double[] doubleArray53 = null;
        double[] doubleArray54 = new double[] {};
        double[] doubleArray60 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray54, doubleArray60);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray53, doubleArray54);
        int int63 = org.apache.commons.math.util.MathUtils.hash(doubleArray54);
        double double64 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray54);
        double[] doubleArray65 = new double[] {};
        double[] doubleArray71 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray65, doubleArray71);
        double[] doubleArray73 = new double[] {};
        double[] doubleArray79 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray73, doubleArray79);
        double double81 = org.apache.commons.math.util.MathUtils.distance1(doubleArray71, doubleArray79);
        double double82 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray79);
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equals(doubleArray54, doubleArray79);
        try {
            double double84 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray54);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 3.948148009134034E13d + "'", double82 == 3.948148009134034E13d);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection10, false);
        java.lang.Number number13 = nonMonotonousSequenceException12.getArgument();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        boolean boolean15 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number16 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0L + "'", number13.equals(0L));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (byte) -1 + "'", number16.equals((byte) -1));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.5422326689561365d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9955392511135347d + "'", double1 == 0.9955392511135347d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        double double1 = org.apache.commons.math.util.FastMath.ulp(16.015625d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.552713678800501E-15d + "'", double1 == 3.552713678800501E-15d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0L + "'", number6.equals(0L));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 33950000L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.7945982305639963d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(100, 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 132 + "'", int2 == 132);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 33L, (-6.227865568816026E9d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (-2113877735));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 31, (long) (-1074790272));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1074790241L) + "'", long2 == (-1074790241L));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.0732178989295803E14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.07321789892958E14d + "'", double1 == 1.07321789892958E14d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-2113877735));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(1.3440585709080678E43d, (double) 7.8436506E8f, (double) (-1074790275));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 33L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5405025668761214d + "'", double1 == 1.5405025668761214d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        double double2 = org.apache.commons.math.util.MathUtils.log(1.3440585709080678E43d, (double) 5865987981925416961L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.4351734182358252d + "'", double2 == 0.4351734182358252d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        int[] intArray5 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray12 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int13 = org.apache.commons.math.util.MathUtils.distanceInf(intArray5, intArray12);
        int[] intArray19 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray26 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int27 = org.apache.commons.math.util.MathUtils.distanceInf(intArray19, intArray26);
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray26);
        int[] intArray29 = null;
        try {
            int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 100 + "'", int27 == 100);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 331 + "'", int28 == 331);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(10000, 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10004 + "'", int2 == 10004);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 800);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 800L + "'", long1 == 800L);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        double double1 = org.apache.commons.math.util.FastMath.expm1(2.302585092994046d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.000000000000002d + "'", double1 == 9.000000000000002d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (-2113877735));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) 3500L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3500.0f + "'", float2 == 3500.0f);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 1074790399);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32783.99608040484d + "'", double1 == 32783.99608040484d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-2113877735));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1074790400), 645219163);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        double double1 = org.apache.commons.math.util.MathUtils.sign(25600.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 32, 800);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        double[] doubleArray8 = new double[] {};
        double[] doubleArray14 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray14);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) (byte) 0);
        double[] doubleArray20 = new double[] {};
        double[] doubleArray26 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray26);
        double[] doubleArray28 = new double[] {};
        double[] doubleArray34 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray34);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray34);
        double[] doubleArray37 = new double[] {};
        double[] doubleArray43 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray37, doubleArray43);
        double[] doubleArray45 = new double[] {};
        double[] doubleArray51 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray43, doubleArray51);
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray43);
        double[] doubleArray55 = null;
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray55);
        double[] doubleArray57 = new double[] {};
        double[] doubleArray63 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray57, doubleArray63);
        int int65 = org.apache.commons.math.util.MathUtils.hash(doubleArray57);
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray57);
        double double67 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1617282775) + "'", int17 == (-1617282775));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.1261198808765266E7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.49536728921867335d, (java.lang.Number) 1, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection8, false);
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException10.getSuppressed();
        java.lang.Number number12 = nonMonotonousSequenceException10.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException10.getDirection();
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException10.getSuppressed();
        java.lang.Number number15 = nonMonotonousSequenceException10.getPrevious();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        boolean boolean17 = nonMonotonousSequenceException10.getStrict();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.49536728921867335d + "'", number4.equals(0.49536728921867335d));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0L + "'", number12.equals(0L));
        org.junit.Assert.assertNull(orderDirection13);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (byte) -1 + "'", number15.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) '4', (double) (-1074790400));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 51.99999999999999d + "'", double2 == 51.99999999999999d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray7 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray7);
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray1);
        int int10 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray11 = new double[] {};
        double[] doubleArray17 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray17);
        double[] doubleArray19 = new double[] {};
        double[] doubleArray25 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray25);
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray25);
        double[] doubleArray28 = new double[] {};
        double[] doubleArray34 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray34);
        double[] doubleArray36 = new double[] {};
        double[] doubleArray42 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray36, doubleArray42);
        double double44 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray42);
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray34);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray34);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray34);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (39,481,480,091,340.34 >= 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(840, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-1.0747902649999998E9d), 3.948148009133937E13d, 0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((-0.5872139151569291d), 3.948148009133937E13d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 1089L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1089.0000000000002d + "'", double1 == 1089.0000000000002d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-1074790275), 104857931);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, (double) 645219163);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-2113877735), (long) (-2147483648));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2147483648L) + "'", long2 == (-2147483648L));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (short) 0, 1077968896);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) (-1074790399L), 0.26136380610379895d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 5865987981925416961L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3104L, number1, 31);
        java.lang.Class<?> wildcardClass4 = nonMonotonousSequenceException3.getClass();
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        long long2 = org.apache.commons.math.util.MathUtils.pow(1155174297527910400L, 33950000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        int int1 = org.apache.commons.math.util.FastMath.abs(3104);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3104 + "'", int1 == 3104);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (byte) 1);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 1);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) (short) 0);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) (byte) 1);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 0);
        java.math.BigInteger bigInteger20 = null;
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) (short) 0);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, bigInteger22);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger23);
        java.math.BigInteger bigInteger25 = null;
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, (long) (short) 0);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (long) (byte) 1);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 0);
        java.math.BigInteger bigInteger32 = null;
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, (long) (short) 0);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, bigInteger34);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 1);
        java.math.BigInteger bigInteger38 = null;
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, (long) (short) 0);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, (long) (byte) 1);
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, 0);
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, bigInteger44);
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, bigInteger37);
        java.math.BigInteger bigInteger47 = null;
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger47, (long) (short) 0);
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger49, (long) (byte) 1);
        java.math.BigInteger bigInteger53 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, 0);
        java.math.BigInteger bigInteger55 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, (long) (byte) 100);
        java.math.BigInteger bigInteger56 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger49);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger53);
        org.junit.Assert.assertNotNull(bigInteger55);
        org.junit.Assert.assertNotNull(bigInteger56);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 3104);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9943386700091609d + "'", double1 == 0.9943386700091609d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.5860134523134308E15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.570796326794896d + "'", double1 == 1.570796326794896d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.5413248546129181d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.814990705660335d + "'", double1 == 0.814990705660335d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        float float2 = org.apache.commons.math.util.FastMath.min(100.0f, (float) 1095479168);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray7 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray7);
        double[] doubleArray9 = new double[] {};
        double[] doubleArray15 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray15);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray15);
        double[] doubleArray18 = new double[] {};
        double[] doubleArray24 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray24);
        double[] doubleArray26 = new double[] {};
        double[] doubleArray32 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray32);
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray24);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) 32L);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray15);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection39 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0, orderDirection39, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + orderDirection39 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection39.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        double double3 = org.apache.commons.math.util.MathUtils.round((double) (-1074787296L), (int) '4', 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.074787296E9d) + "'", double3 == (-1.074787296E9d));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-2113877735), (long) (-1074790300));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.1555698629817919d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        float float2 = org.apache.commons.math.util.FastMath.max(1.0f, (float) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        int int1 = org.apache.commons.math.util.MathUtils.sign(104857599);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        double double1 = org.apache.commons.math.util.FastMath.log(33.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.4965075614664802d + "'", double1 == 3.4965075614664802d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-104857599L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (byte) 0, 33.0d, 3.141592653589793d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        double double1 = org.apache.commons.math.util.FastMath.acosh(2.47859127706984d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5574077246549023d + "'", double1 == 1.5574077246549023d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        double double2 = org.apache.commons.math.util.FastMath.max(97.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.9866275920404853d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 1074791115, (double) (-349698017));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.4969801864315724E8d) + "'", double2 == (-3.4969801864315724E8d));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        double double2 = org.apache.commons.math.util.FastMath.max(3.948148009134034E13d, 3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.948148009134034E13d + "'", double2 == 3.948148009134034E13d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(11014.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 192.23056381465545d + "'", double1 == 192.23056381465545d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-1617282775));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        double double1 = org.apache.commons.math.util.FastMath.sinh(4.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 27.28991719712775d + "'", double1 == 27.28991719712775d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 3500.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3500.0d + "'", double1 == 3500.0d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        double double1 = org.apache.commons.math.util.FastMath.exp(6.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 403.4287934927351d + "'", double1 == 403.4287934927351d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        int int2 = org.apache.commons.math.util.MathUtils.pow(10000, 332);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (short) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1 == 10.0f);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        int int1 = org.apache.commons.math.util.MathUtils.sign(132);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 8519509564645355905L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.017777426647700732d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0177755541101581d + "'", double1 == 0.0177755541101581d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (short) 0, (-1074790274L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1074790274L + "'", long2 == 1074790274L);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(51.99999999999999d, (double) (-2147483648), 0.9955392511135347d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.1261198808765266E7d, (double) 296L, (double) 52L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(56628L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.5430806348152437d, 1089.0000000000002d, (double) 104857600);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.0747904E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.031323778671396d + "'", double1 == 9.031323778671396d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        int[] intArray5 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray12 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int13 = org.apache.commons.math.util.MathUtils.distanceInf(intArray5, intArray12);
        int[] intArray19 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray26 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int27 = org.apache.commons.math.util.MathUtils.distanceInf(intArray19, intArray26);
        int[] intArray33 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray40 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int41 = org.apache.commons.math.util.MathUtils.distanceInf(intArray33, intArray40);
        int int42 = org.apache.commons.math.util.MathUtils.distanceInf(intArray19, intArray40);
        int int43 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray40);
        java.lang.Class<?> wildcardClass44 = intArray12.getClass();
        int[] intArray50 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray57 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int58 = org.apache.commons.math.util.MathUtils.distanceInf(intArray50, intArray57);
        int[] intArray64 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray71 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int72 = org.apache.commons.math.util.MathUtils.distanceInf(intArray64, intArray71);
        int[] intArray78 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray85 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int86 = org.apache.commons.math.util.MathUtils.distanceInf(intArray78, intArray85);
        int int87 = org.apache.commons.math.util.MathUtils.distanceInf(intArray64, intArray85);
        int int88 = org.apache.commons.math.util.MathUtils.distanceInf(intArray57, intArray85);
        int int89 = org.apache.commons.math.util.MathUtils.distanceInf(intArray12, intArray85);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 100 + "'", int27 == 100);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 100 + "'", int41 == 100);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 100 + "'", int42 == 100);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 100 + "'", int58 == 100);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 100 + "'", int72 == 100);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 100 + "'", int86 == 100);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 100 + "'", int87 == 100);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 0 + "'", int88 == 0);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 0 + "'", int89 == 0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 104857599);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        int int1 = org.apache.commons.math.util.MathUtils.sign(10004);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-10), (long) (-1074790272));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1074790272L) + "'", long2 == (-1074790272L));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(10000, (-1074790399));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        long long1 = org.apache.commons.math.util.FastMath.round(24.132741228718345d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24L + "'", long1 == 24L);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-10), (long) (-1074790300));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1074790310L) + "'", long2 == (-1074790310L));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 10L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-1074790274L), 1095479168);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        double double1 = org.apache.commons.math.util.FastMath.log((-1.0747903E9d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        double double1 = org.apache.commons.math.util.FastMath.log((-1661.5776058793872d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 800L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1368683772161603E-13d + "'", double1 == 1.1368683772161603E-13d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) (short) 100, (-2113877735));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 1074791115);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32784.00700036529d + "'", double1 == 32784.00700036529d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-1074790275));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-0.014686439244896978d), (double) 31.0f, (double) 8519509564645355905L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.49536728921867335d, (java.lang.Number) 1, 0);
        java.lang.Number number7 = nonMonotonousSequenceException6.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection11, false);
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException13.getSuppressed();
        java.lang.Number number15 = nonMonotonousSequenceException13.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = nonMonotonousSequenceException13.getDirection();
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException13.getSuppressed();
        java.lang.Number number18 = nonMonotonousSequenceException13.getPrevious();
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 0L, 0, orderDirection20, true);
        java.lang.Number number23 = nonMonotonousSequenceException22.getArgument();
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0.49536728921867335d + "'", number7.equals(0.49536728921867335d));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 0L + "'", number15.equals(0L));
        org.junit.Assert.assertNull(orderDirection16);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (byte) -1 + "'", number18.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection20.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (short) 0 + "'", number23.equals((short) 0));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        double[] doubleArray8 = new double[] {};
        double[] doubleArray14 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray14);
        double[] doubleArray17 = new double[] {};
        double[] doubleArray23 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray23);
        double[] doubleArray25 = new double[] {};
        double[] doubleArray31 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray31);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray23);
        double[] doubleArray35 = new double[] {};
        double[] doubleArray41 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray35, doubleArray41);
        double[] doubleArray43 = new double[] {};
        double[] doubleArray49 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray43, doubleArray49);
        double double51 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray49);
        double[] doubleArray52 = new double[] {};
        double[] doubleArray58 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray52, doubleArray58);
        double[] doubleArray60 = new double[] {};
        double[] doubleArray66 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray60, doubleArray66);
        double double68 = org.apache.commons.math.util.MathUtils.distance1(doubleArray58, doubleArray66);
        double[] doubleArray69 = new double[] {};
        double[] doubleArray75 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray69, doubleArray75);
        double[] doubleArray77 = new double[] {};
        double[] doubleArray83 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray77, doubleArray83);
        double double85 = org.apache.commons.math.util.MathUtils.distance1(doubleArray75, doubleArray83);
        double double86 = org.apache.commons.math.util.MathUtils.distance1(doubleArray66, doubleArray75);
        double double87 = org.apache.commons.math.util.MathUtils.distance1(doubleArray49, doubleArray66);
        double double88 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray14, doubleArray66);
        int int89 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + (-1617282775) + "'", int89 == (-1617282775));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(2.356194490192345d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.322752149519959d + "'", double1 == 5.322752149519959d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (short) 10, 1.5707963172581534d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 37.22170966680758d + "'", double2 == 37.22170966680758d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 0, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) (short) 0);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) (byte) 1);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0);
        java.math.BigInteger bigInteger8 = null;
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) (short) 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, bigInteger10);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) (short) 0);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, (long) (byte) 1);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 0);
        java.math.BigInteger bigInteger19 = null;
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, (long) (short) 0);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, bigInteger21);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 1);
        java.math.BigInteger bigInteger25 = null;
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, (long) (short) 0);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (long) (byte) 1);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 0);
        java.math.BigInteger bigInteger32 = null;
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, (long) (short) 0);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, bigInteger34);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, bigInteger35);
        java.math.BigInteger bigInteger37 = null;
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, (long) (short) 0);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger39, (long) (byte) 1);
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger41, 0);
        java.math.BigInteger bigInteger44 = null;
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger44, (long) (short) 0);
        java.math.BigInteger bigInteger47 = org.apache.commons.math.util.MathUtils.pow(bigInteger41, bigInteger46);
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger41, 1);
        java.math.BigInteger bigInteger50 = null;
        java.math.BigInteger bigInteger52 = org.apache.commons.math.util.MathUtils.pow(bigInteger50, (long) (short) 0);
        java.math.BigInteger bigInteger54 = org.apache.commons.math.util.MathUtils.pow(bigInteger52, (long) (byte) 1);
        java.math.BigInteger bigInteger56 = org.apache.commons.math.util.MathUtils.pow(bigInteger54, 0);
        java.math.BigInteger bigInteger57 = org.apache.commons.math.util.MathUtils.pow(bigInteger49, bigInteger56);
        java.math.BigInteger bigInteger58 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, bigInteger49);
        java.math.BigInteger bigInteger59 = null;
        java.math.BigInteger bigInteger61 = org.apache.commons.math.util.MathUtils.pow(bigInteger59, (long) (short) 0);
        java.math.BigInteger bigInteger63 = org.apache.commons.math.util.MathUtils.pow(bigInteger61, (long) (byte) 1);
        java.math.BigInteger bigInteger65 = org.apache.commons.math.util.MathUtils.pow(bigInteger63, 0);
        java.math.BigInteger bigInteger66 = null;
        java.math.BigInteger bigInteger68 = org.apache.commons.math.util.MathUtils.pow(bigInteger66, (long) (short) 0);
        java.math.BigInteger bigInteger69 = org.apache.commons.math.util.MathUtils.pow(bigInteger63, bigInteger68);
        java.math.BigInteger bigInteger71 = org.apache.commons.math.util.MathUtils.pow(bigInteger63, 1);
        java.math.BigInteger bigInteger72 = null;
        java.math.BigInteger bigInteger74 = org.apache.commons.math.util.MathUtils.pow(bigInteger72, (long) (short) 0);
        java.math.BigInteger bigInteger76 = org.apache.commons.math.util.MathUtils.pow(bigInteger74, (long) (byte) 1);
        java.math.BigInteger bigInteger78 = org.apache.commons.math.util.MathUtils.pow(bigInteger76, 0);
        java.math.BigInteger bigInteger79 = null;
        java.math.BigInteger bigInteger81 = org.apache.commons.math.util.MathUtils.pow(bigInteger79, (long) (short) 0);
        java.math.BigInteger bigInteger82 = org.apache.commons.math.util.MathUtils.pow(bigInteger76, bigInteger81);
        java.math.BigInteger bigInteger83 = org.apache.commons.math.util.MathUtils.pow(bigInteger63, bigInteger82);
        java.lang.Class<?> wildcardClass84 = bigInteger83.getClass();
        java.math.BigInteger bigInteger85 = org.apache.commons.math.util.MathUtils.pow(bigInteger58, bigInteger83);
        java.math.BigInteger bigInteger86 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, bigInteger85);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException88 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.4056476493802699d, (java.lang.Number) bigInteger86, (int) (short) 10);
        java.math.BigInteger bigInteger90 = org.apache.commons.math.util.MathUtils.pow(bigInteger86, 1661992960);
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger47);
        org.junit.Assert.assertNotNull(bigInteger49);
        org.junit.Assert.assertNotNull(bigInteger52);
        org.junit.Assert.assertNotNull(bigInteger54);
        org.junit.Assert.assertNotNull(bigInteger56);
        org.junit.Assert.assertNotNull(bigInteger57);
        org.junit.Assert.assertNotNull(bigInteger58);
        org.junit.Assert.assertNotNull(bigInteger61);
        org.junit.Assert.assertNotNull(bigInteger63);
        org.junit.Assert.assertNotNull(bigInteger65);
        org.junit.Assert.assertNotNull(bigInteger68);
        org.junit.Assert.assertNotNull(bigInteger69);
        org.junit.Assert.assertNotNull(bigInteger71);
        org.junit.Assert.assertNotNull(bigInteger74);
        org.junit.Assert.assertNotNull(bigInteger76);
        org.junit.Assert.assertNotNull(bigInteger78);
        org.junit.Assert.assertNotNull(bigInteger81);
        org.junit.Assert.assertNotNull(bigInteger82);
        org.junit.Assert.assertNotNull(bigInteger83);
        org.junit.Assert.assertNotNull(wildcardClass84);
        org.junit.Assert.assertNotNull(bigInteger85);
        org.junit.Assert.assertNotNull(bigInteger86);
        org.junit.Assert.assertNotNull(bigInteger90);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        double double1 = org.apache.commons.math.util.FastMath.rint((-0.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(25);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5511210043331066E25d + "'", double1 == 1.5511210043331066E25d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 33950000L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.395E7d + "'", double1 == 3.395E7d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1, 1074791115);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1074791115 + "'", int2 == 1074791115);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 10, (java.lang.Number) 2.3260349202281993E-8d, 31, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection9, false);
        int int12 = nonMonotonousSequenceException11.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection16, false);
        java.lang.Throwable[] throwableArray19 = nonMonotonousSequenceException18.getSuppressed();
        java.lang.Number number20 = nonMonotonousSequenceException18.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = nonMonotonousSequenceException18.getDirection();
        java.lang.Throwable[] throwableArray22 = nonMonotonousSequenceException18.getSuppressed();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        java.lang.Number number25 = nonMonotonousSequenceException11.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 32 + "'", int12 == 32);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0L + "'", number20.equals(0L));
        org.junit.Assert.assertNull(orderDirection21);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 0L + "'", number25.equals(0L));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection3, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.4770643681037948d, (java.lang.Number) (byte) -1, 32);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertNull(orderDirection11);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-2147483648L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2147483648) + "'", int1 == (-2147483648));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        int[] intArray0 = new int[] {};
        int[] intArray1 = null;
        double double2 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray1);
        int[] intArray8 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray15 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray8, intArray15);
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray8);
        int[] intArray23 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray30 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int31 = org.apache.commons.math.util.MathUtils.distanceInf(intArray23, intArray30);
        int[] intArray37 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray44 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int45 = org.apache.commons.math.util.MathUtils.distanceInf(intArray37, intArray44);
        int int46 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray44);
        int int47 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray23);
        int[] intArray48 = new int[] {};
        int[] intArray49 = new int[] {};
        int[] intArray50 = null;
        double double51 = org.apache.commons.math.util.MathUtils.distance(intArray49, intArray50);
        int int52 = org.apache.commons.math.util.MathUtils.distanceInf(intArray48, intArray50);
        int[] intArray53 = new int[] {};
        int[] intArray54 = new int[] {};
        int[] intArray55 = null;
        double double56 = org.apache.commons.math.util.MathUtils.distance(intArray54, intArray55);
        int int57 = org.apache.commons.math.util.MathUtils.distanceInf(intArray53, intArray55);
        int[] intArray63 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray70 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int71 = org.apache.commons.math.util.MathUtils.distanceInf(intArray63, intArray70);
        int[] intArray77 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray84 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int85 = org.apache.commons.math.util.MathUtils.distanceInf(intArray77, intArray84);
        int int86 = org.apache.commons.math.util.MathUtils.distance1(intArray63, intArray84);
        int int87 = org.apache.commons.math.util.MathUtils.distanceInf(intArray53, intArray63);
        double double88 = org.apache.commons.math.util.MathUtils.distance(intArray48, intArray53);
        try {
            double double89 = org.apache.commons.math.util.MathUtils.distance(intArray23, intArray53);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 100 + "'", int31 == 100);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 100 + "'", int45 == 100);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 331 + "'", int46 == 331);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 100 + "'", int71 == 100);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertNotNull(intArray84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 100 + "'", int85 == 100);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 331 + "'", int86 == 331);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 0 + "'", int87 == 0);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-1991318963));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection3, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.4770643681037948d, (java.lang.Number) (byte) -1, 32);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        java.lang.Number number11 = nonMonotonousSequenceException9.getArgument();
        java.lang.Throwable[] throwableArray12 = nonMonotonousSequenceException9.getSuppressed();
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0.4770643681037948d + "'", number11.equals(0.4770643681037948d));
        org.junit.Assert.assertNotNull(throwableArray12);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 3104);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3104.0d + "'", double1 == 3104.0d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(6.0d, 0, 25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 1074790301L, (double) 104857599L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0747903009999998E9d + "'", double2 == 1.0747903009999998E9d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 1155174297527910400L, 16.015625d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7031839360032603E-108d + "'", double1 == 1.7031839360032603E-108d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(33L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        long long1 = org.apache.commons.math.util.FastMath.abs((-1074790275L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1074790275L + "'", long1 == 1074790275L);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(1.2319257889732327d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 104857931, (long) (-2147483648));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2042625717L) + "'", long2 == (-2042625717L));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.5091784786580567d, (java.lang.Number) (-1074790400L), 619996103);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) (byte) 0, 619996103);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 619996103 + "'", int2 == 619996103);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 10000);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-183792213), 104857931);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-3.4485442308546683d), 3.141592653589793d, (double) 800L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.9866275920404853d, (double) 2L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 3104, (long) 1077968896);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1077965792L) + "'", long2 == (-1077965792L));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection3, false);
        int int6 = nonMonotonousSequenceException5.getIndex();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1074791115);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.26136380610379895d, (-104857600));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.26136380610379895d + "'", double2 == 0.26136380610379895d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1074790300), (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        double double1 = org.apache.commons.math.util.FastMath.ulp(100.53096491487338d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-0.9707928525119764d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.130627094654336d) + "'", double1 == (-1.130627094654336d));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) Float.NaN, (double) 331);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 2L, (double) 645219164L, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-1074790400L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        double[] doubleArray8 = new double[] {};
        double[] doubleArray14 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray14);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        double[] doubleArray18 = null;
        double[] doubleArray19 = new double[] {};
        double[] doubleArray25 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray25);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray19);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        double[] doubleArray29 = new double[] {};
        double[] doubleArray35 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray35);
        double[] doubleArray37 = new double[] {};
        double[] doubleArray43 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray37, doubleArray43);
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray43);
        double[] doubleArray46 = new double[] {};
        double[] doubleArray52 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray46, doubleArray52);
        double[] doubleArray54 = new double[] {};
        double[] doubleArray60 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray54, doubleArray60);
        double double62 = org.apache.commons.math.util.MathUtils.distance1(doubleArray52, doubleArray60);
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray43, doubleArray52);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray52);
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray52);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (39,481,480,091,340.34 >= 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1617282775) + "'", int17 == (-1617282775));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        double[] doubleArray8 = new double[] {};
        double[] doubleArray14 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray14);
        double[] doubleArray17 = new double[] {};
        double[] doubleArray23 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray23);
        double[] doubleArray25 = new double[] {};
        double[] doubleArray31 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray31);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray23);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (39,481,480,091,340.34 >= 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1032654167, 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 20.75539818593891d + "'", double2 == 20.75539818593891d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-1074790300));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        double double1 = org.apache.commons.math.util.FastMath.asin(2.3260349202281993E-8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3260349202281996E-8d + "'", double1 == 2.3260349202281996E-8d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        double double1 = org.apache.commons.math.util.FastMath.cosh(4.666310772197643E157d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 10, (java.lang.Number) 2.3260349202281993E-8d, 31, orderDirection6, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5604874136486533d, (java.lang.Number) 0.10317723866239005d, (int) (byte) -1, orderDirection6, false);
        java.lang.String str11 = nonMonotonousSequenceException10.toString();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not increasing (0.103 > 1.56)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not increasing (0.103 > 1.56)"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        double double1 = org.apache.commons.math.util.FastMath.signum(2.154434690031884d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int[] intArray2 = null;
        double double3 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray2);
        int int4 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray2);
        int[] intArray10 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray17 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int18 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray17);
        int[] intArray24 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray31 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int32 = org.apache.commons.math.util.MathUtils.distanceInf(intArray24, intArray31);
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray31);
        int int34 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray10);
        int[] intArray35 = new int[] {};
        int[] intArray36 = null;
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray35, intArray36);
        int[] intArray43 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray50 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int51 = org.apache.commons.math.util.MathUtils.distanceInf(intArray43, intArray50);
        int int52 = org.apache.commons.math.util.MathUtils.distanceInf(intArray35, intArray43);
        int[] intArray58 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray65 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int66 = org.apache.commons.math.util.MathUtils.distanceInf(intArray58, intArray65);
        int[] intArray72 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray79 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int80 = org.apache.commons.math.util.MathUtils.distanceInf(intArray72, intArray79);
        int[] intArray86 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray93 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int94 = org.apache.commons.math.util.MathUtils.distanceInf(intArray86, intArray93);
        int int95 = org.apache.commons.math.util.MathUtils.distanceInf(intArray72, intArray93);
        int int96 = org.apache.commons.math.util.MathUtils.distance1(intArray65, intArray93);
        double double97 = org.apache.commons.math.util.MathUtils.distance(intArray43, intArray65);
        int int98 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray43);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 100 + "'", int18 == 100);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 100 + "'", int32 == 100);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 331 + "'", int33 == 331);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 100 + "'", int51 == 100);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 100 + "'", int66 == 100);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertNotNull(intArray79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 100 + "'", int80 == 100);
        org.junit.Assert.assertNotNull(intArray86);
        org.junit.Assert.assertNotNull(intArray93);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 100 + "'", int94 == 100);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 100 + "'", int95 == 100);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 0 + "'", int96 == 0);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 175.57049866079439d + "'", double97 == 175.57049866079439d);
        org.junit.Assert.assertTrue("'" + int98 + "' != '" + 0 + "'", int98 == 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        double double2 = org.apache.commons.math.util.FastMath.pow(6.733401891837359d, 1.5707963172581534d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 19.998055071752454d + "'", double2 == 19.998055071752454d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.7853981633974483d), (java.lang.Number) 2.356194490192345d, 10);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(10.0f, 10, 1074791115);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        double double1 = org.apache.commons.math.util.FastMath.acos(5.267884728309446d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 800, Double.POSITIVE_INFINITY, (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((-0.6156264703860141d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1955590117745327d + "'", double1 == 1.1955590117745327d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        double double1 = org.apache.commons.math.util.FastMath.cos(5729.5779513082325d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.773121177104694d + "'", double1 == 0.773121177104694d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) (-1074790347L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-1074787296L), 1024.3332245675347d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-0.424151709070136d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0913090197869904d + "'", double1 == 1.0913090197869904d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 10004);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 573186.9782488756d + "'", double1 == 573186.9782488756d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        double double1 = org.apache.commons.math.util.FastMath.tan(11013.232920103324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.5045996724326973d) + "'", double1 == (-2.5045996724326973d));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 33L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0732178989295803E14d + "'", double1 == 1.0732178989295803E14d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(3104);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.1261198808765266E7d, (double) 31);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707935739796302d + "'", double2 == 1.5707935739796302d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        double[] doubleArray8 = new double[] {};
        double[] doubleArray14 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray14);
        double[] doubleArray17 = new double[] {};
        double[] doubleArray23 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray23);
        double[] doubleArray25 = new double[] {};
        double[] doubleArray31 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray31);
        double[] doubleArray34 = new double[] {};
        double[] doubleArray40 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray40);
        double[] doubleArray42 = new double[] {};
        double[] doubleArray48 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray42, doubleArray48);
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray48);
        double double51 = org.apache.commons.math.util.MathUtils.distance1(doubleArray31, doubleArray40);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray40);
        double[] doubleArray53 = new double[] {};
        double[] doubleArray59 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray53, doubleArray59);
        double[] doubleArray61 = new double[] {};
        double[] doubleArray67 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray61, doubleArray67);
        double double69 = org.apache.commons.math.util.MathUtils.distance1(doubleArray59, doubleArray67);
        double double70 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray59);
        double double71 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 3.948148009134034E13d + "'", double71 == 3.948148009134034E13d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1095479168);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(16.015625d, 4.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 10, (java.lang.Number) 2.3260349202281993E-8d, 31, orderDirection6, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5604874136486533d, (java.lang.Number) 0.10317723866239005d, (int) (byte) -1, orderDirection6, false);
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException10.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray11);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 10004);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.570696366779236d + "'", double1 == 1.570696366779236d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.7853981633974483d), (java.lang.Number) 2.356194490192345d, 10);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 2.356194490192345d + "'", number4.equals(2.356194490192345d));
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(33950000L, (long) 840);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 28518000000L + "'", long2 == 28518000000L);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-1), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (short) 1, 1074790300);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((-104857599L), (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 104857599L + "'", long2 == 104857599L);
    }
}

