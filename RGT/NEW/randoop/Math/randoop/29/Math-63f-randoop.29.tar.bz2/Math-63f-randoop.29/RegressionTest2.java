import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        long long1 = org.apache.commons.math.util.FastMath.abs((-1074787296L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1074787296L + "'", long1 == 1074787296L);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        int[] intArray0 = new int[] {};
        int[] intArray1 = null;
        double double2 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray1);
        int[] intArray3 = null;
        try {
            int int4 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (byte) 100, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        double[] doubleArray8 = new double[] {};
        double[] doubleArray14 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray14);
        double[] doubleArray17 = new double[] {};
        double[] doubleArray23 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray23);
        double[] doubleArray25 = new double[] {};
        double[] doubleArray31 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray31);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray23);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) 32L);
        double[] doubleArray37 = null;
        double[] doubleArray38 = new double[] {};
        double[] doubleArray44 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray38, doubleArray44);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray37, doubleArray38);
        try {
            double double47 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray14, doubleArray38);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (-1074790265));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963258644826d) + "'", double1 == (-1.5707963258644826d));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (short) 1, 104857599);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (short) -1, (-183792213));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-104857600), 1L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-104857600) + "'", int2 == (-104857600));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 100.0f, 2.5091784786580567d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.19976577695852665d + "'", double2 == 0.19976577695852665d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 1077968896, (long) (-1074790272));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1077968896L + "'", long2 == 1077968896L);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        double[] doubleArray8 = new double[] {};
        double[] doubleArray14 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray14);
        double[] doubleArray17 = new double[] {};
        double[] doubleArray23 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray23);
        double[] doubleArray25 = new double[] {};
        double[] doubleArray31 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray31);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray23);
        double[] doubleArray35 = null;
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray35);
        double[] doubleArray37 = new double[] {};
        double[] doubleArray43 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray37, doubleArray43);
        int int45 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray37);
        java.lang.Class<?> wildcardClass47 = doubleArray14.getClass();
        double[] doubleArray48 = null;
        double[] doubleArray49 = new double[] {};
        double[] doubleArray55 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray49, doubleArray55);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray48, doubleArray49);
        int int58 = org.apache.commons.math.util.MathUtils.hash(doubleArray49);
        double[] doubleArray59 = new double[] {};
        double[] doubleArray65 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray59, doubleArray65);
        double[] doubleArray67 = new double[] {};
        double[] doubleArray73 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray67, doubleArray73);
        double double75 = org.apache.commons.math.util.MathUtils.distance1(doubleArray65, doubleArray73);
        double[] doubleArray76 = new double[] {};
        double[] doubleArray82 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray76, doubleArray82);
        double[] doubleArray84 = new double[] {};
        double[] doubleArray90 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray84, doubleArray90);
        double double92 = org.apache.commons.math.util.MathUtils.distance1(doubleArray82, doubleArray90);
        double double93 = org.apache.commons.math.util.MathUtils.distance1(doubleArray73, doubleArray82);
        boolean boolean94 = org.apache.commons.math.util.MathUtils.equals(doubleArray49, doubleArray82);
        try {
            double double95 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray14, doubleArray49);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 0.0d + "'", double93 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number3, (java.lang.Number) 840, 1074790399);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 800L, (java.lang.Number) 1593.321431732963d, (int) (short) -1, orderDirection7, true);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 35L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) '#', 0.773121177104694d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 15.622542110419388d + "'", double2 == 15.622542110419388d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-104857600), 104L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-104857600L) + "'", long2 == (-104857600L));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        double double1 = org.apache.commons.math.util.FastMath.exp(2.877157801747449d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 17.76371336805023d + "'", double1 == 17.76371336805023d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(104857600);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.5859157583671175d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8332060551719964d + "'", double1 == 0.8332060551719964d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        int int2 = org.apache.commons.math.util.FastMath.max((-104857600), (-1074790399));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-104857600) + "'", int2 == (-104857600));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.570796326794896d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.570796326794896d + "'", double1 == 1.570796326794896d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        long long1 = org.apache.commons.math.util.FastMath.abs(350000L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 350000L + "'", long1 == 350000L);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1095479168, (-1074790300));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.31358290969207164d, (-0.30005830960817476d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.416196940536434d + "'", double2 == 1.416196940536434d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        double double1 = org.apache.commons.math.util.FastMath.ceil(2.154434690031884d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 1155174297527910400L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray7 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray7);
        double[] doubleArray9 = new double[] {};
        double[] doubleArray15 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray15);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray15);
        double[] doubleArray18 = new double[] {};
        double[] doubleArray24 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray24);
        double[] doubleArray26 = new double[] {};
        double[] doubleArray32 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray32);
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray24);
        double[] doubleArray36 = new double[] {};
        double[] doubleArray42 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray36, doubleArray42);
        double[] doubleArray44 = new double[] {};
        double[] doubleArray50 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray44, doubleArray50);
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray50);
        double[] doubleArray53 = new double[] {};
        double[] doubleArray59 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray53, doubleArray59);
        double[] doubleArray61 = new double[] {};
        double[] doubleArray67 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray61, doubleArray67);
        double double69 = org.apache.commons.math.util.MathUtils.distance1(doubleArray59, doubleArray67);
        double double70 = org.apache.commons.math.util.MathUtils.distance1(doubleArray50, doubleArray59);
        double[] doubleArray71 = null;
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray50, doubleArray71);
        double double73 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray50);
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 104857931);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.04857931E8d + "'", double1 == 1.04857931E8d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-356830412468L), 192.23056381465545d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.56830412468E11d) + "'", double2 == (-3.56830412468E11d));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(7.345392677303175E30d, 4.342944819032518d, 2.3260349202281993E-8d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 3L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3L + "'", long1 == 3L);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        int int2 = org.apache.commons.math.util.MathUtils.pow(35, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-86196911) + "'", int2 == (-86196911));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        double[] doubleArray8 = new double[] {};
        double[] doubleArray14 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray14);
        double[] doubleArray17 = new double[] {};
        double[] doubleArray23 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray23);
        double[] doubleArray25 = new double[] {};
        double[] doubleArray31 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray31);
        double[] doubleArray34 = new double[] {};
        double[] doubleArray40 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray40);
        double[] doubleArray42 = new double[] {};
        double[] doubleArray48 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray42, doubleArray48);
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray48);
        double double51 = org.apache.commons.math.util.MathUtils.distance1(doubleArray31, doubleArray40);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray40);
        double[] doubleArray53 = null;
        double[] doubleArray54 = new double[] {};
        double[] doubleArray60 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray54, doubleArray60);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equals(doubleArray53, doubleArray54);
        double double63 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray54);
        try {
            double double64 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray54);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        long long1 = org.apache.commons.math.util.FastMath.round(9.031323778267323d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 9L + "'", long1 == 9L);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        int int2 = org.apache.commons.math.util.FastMath.min(1074790300, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        double double1 = org.apache.commons.math.util.FastMath.tan(1593.321431732963d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5912439661771183d + "'", double1 == 0.5912439661771183d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(331, (long) (-104857599));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        float float1 = org.apache.commons.math.util.MathUtils.indicator(1.048576E8f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        double double1 = org.apache.commons.math.util.FastMath.asinh(4.666310772197643E157d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 4L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0947125472611012d + "'", double1 == 2.0947125472611012d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-1074790300));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-2113867735), (-1074790265));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        double double1 = org.apache.commons.math.util.FastMath.asin((-0.027178546456142455d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.02718189358035228d) + "'", double1 == (-0.02718189358035228d));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-349698017), 9L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3147282153L + "'", long2 == 3147282153L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) 'a', (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 331);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5677751879502697d + "'", double1 == 1.5677751879502697d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 3628800.0f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3628800L + "'", long1 == 3628800L);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) (-104857600));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        long long2 = org.apache.commons.math.util.FastMath.min(3147282153L, 4L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.5860134523134308E15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 25, (-4299161204L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-107479030100L) + "'", long2 == (-107479030100L));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        int[] intArray0 = new int[] {};
        int[] intArray1 = null;
        double double2 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray1);
        int[] intArray8 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray15 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray8, intArray15);
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray8);
        int[] intArray23 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray30 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int31 = org.apache.commons.math.util.MathUtils.distanceInf(intArray23, intArray30);
        int[] intArray37 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray44 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int45 = org.apache.commons.math.util.MathUtils.distanceInf(intArray37, intArray44);
        int int46 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray44);
        int int47 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray23);
        int[] intArray53 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray60 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int61 = org.apache.commons.math.util.MathUtils.distanceInf(intArray53, intArray60);
        int[] intArray67 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray74 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int75 = org.apache.commons.math.util.MathUtils.distanceInf(intArray67, intArray74);
        int int76 = org.apache.commons.math.util.MathUtils.distance1(intArray53, intArray74);
        int int77 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray53);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 100 + "'", int31 == 100);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 100 + "'", int45 == 100);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 331 + "'", int46 == 331);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 100 + "'", int61 == 100);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 100 + "'", int75 == 100);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 331 + "'", int76 == 331);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((-1.5707963258644826d), 51.99999999999999d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 54.97787143875179d + "'", double2 == 54.97787143875179d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-10), (long) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(3L, (long) (-1074790300));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3224370900L) + "'", long2 == (-3224370900L));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        double[] doubleArray8 = new double[] {};
        double[] doubleArray14 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray14);
        double[] doubleArray17 = new double[] {};
        double[] doubleArray23 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray23);
        double[] doubleArray25 = new double[] {};
        double[] doubleArray31 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray31);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray23);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) 32L);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        double[] doubleArray38 = new double[] {};
        double[] doubleArray44 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray38, doubleArray44);
        double[] doubleArray46 = new double[] {};
        double[] doubleArray52 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray46, doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray44, doubleArray52);
        double[] doubleArray55 = new double[] {};
        double[] doubleArray61 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray55, doubleArray61);
        double[] doubleArray63 = new double[] {};
        double[] doubleArray69 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray63, doubleArray69);
        double double71 = org.apache.commons.math.util.MathUtils.distance1(doubleArray61, doubleArray69);
        double[] doubleArray72 = new double[] {};
        double[] doubleArray78 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray72, doubleArray78);
        double[] doubleArray80 = new double[] {};
        double[] doubleArray86 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean87 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray80, doubleArray86);
        double double88 = org.apache.commons.math.util.MathUtils.distance1(doubleArray78, doubleArray86);
        double double89 = org.apache.commons.math.util.MathUtils.distance1(doubleArray69, doubleArray78);
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray44, doubleArray78);
        double[] doubleArray92 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, (-0.44812751321749233d));
        boolean boolean93 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1617282775) + "'", int37 == (-1617282775));
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (-1617282775));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 27.28991719712775d + "'", double1 == 27.28991719712775d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        long long1 = org.apache.commons.math.util.FastMath.round(2.1968059704696543d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        long long1 = org.apache.commons.math.util.MathUtils.sign(97L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(35, 331);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11585 + "'", int2 == 11585);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-1074790399));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.074790399E9d) + "'", double1 == (-1.074790399E9d));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        double[] doubleArray8 = new double[] {};
        double[] doubleArray14 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray14);
        double[] doubleArray17 = new double[] {};
        double[] doubleArray23 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray23);
        double[] doubleArray25 = new double[] {};
        double[] doubleArray31 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray31);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray23);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) 32L);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        double double38 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1617282775) + "'", int37 == (-1617282775));
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 3.948148009134034E13d + "'", double38 == 3.948148009134034E13d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 28518000000L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6765833317027634d + "'", double1 == 0.6765833317027634d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 3500.0f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3500L + "'", long1 == 3500L);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.19976577695852665d, (double) 1074790274L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0747902748645732E9d + "'", double2 == 1.0747902748645732E9d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        double double1 = org.apache.commons.math.util.FastMath.expm1(15.622542110419388d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6092334.784589741d + "'", double1 == 6092334.784589741d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-1074790399L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.875863123137357E7d) + "'", double1 == (-1.875863123137357E7d));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        int int2 = org.apache.commons.math.util.MathUtils.pow(800, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-183792213), number1, 800);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(5865987981925416961L, (-1074790400));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.0177755541101581d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0001579893218906d + "'", double1 == 1.0001579893218906d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray7 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray7);
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray1);
        int int10 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray11 = new double[] {};
        double[] doubleArray17 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray17);
        double[] doubleArray19 = new double[] {};
        double[] doubleArray25 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray25);
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray25);
        double[] doubleArray28 = new double[] {};
        double[] doubleArray34 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray34);
        double[] doubleArray36 = new double[] {};
        double[] doubleArray42 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray36, doubleArray42);
        double double44 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray42);
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray34);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray34);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        int int1 = org.apache.commons.math.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-1074790265), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1074790265) + "'", int2 == (-1074790265));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 104857599, (-0.5063656411097588d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2666762173175812d + "'", double2 == 1.2666762173175812d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number10 = nonMonotonousSequenceException5.getPrevious();
        java.lang.String str11 = nonMonotonousSequenceException5.toString();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0L + "'", number7.equals(0L));
        org.junit.Assert.assertNull(orderDirection8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (byte) -1 + "'", number10.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not decreasing (-1 < 0)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not decreasing (-1 < 0)"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        double[] doubleArray8 = null;
        double[] doubleArray9 = new double[] {};
        double[] doubleArray15 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray15);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray9);
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray9);
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        double[] doubleArray20 = new double[] {};
        double[] doubleArray26 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray26);
        double[] doubleArray28 = new double[] {};
        double[] doubleArray34 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray34);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray34);
        double double37 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray9, doubleArray34);
        double[] doubleArray39 = new double[] {};
        double[] doubleArray45 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray45);
        double[] doubleArray47 = new double[] {};
        double[] doubleArray53 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray47, doubleArray53);
        double double55 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray53);
        int int56 = org.apache.commons.math.util.MathUtils.hash(doubleArray53);
        double[] doubleArray57 = new double[] {};
        double[] doubleArray63 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray57, doubleArray63);
        double[] doubleArray65 = new double[] {};
        double[] doubleArray71 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray65, doubleArray71);
        double double73 = org.apache.commons.math.util.MathUtils.distance1(doubleArray63, doubleArray71);
        double[] doubleArray74 = new double[] {};
        double[] doubleArray80 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray74, doubleArray80);
        double[] doubleArray82 = new double[] {};
        double[] doubleArray88 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean89 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray82, doubleArray88);
        double double90 = org.apache.commons.math.util.MathUtils.distance1(doubleArray80, doubleArray88);
        double double91 = org.apache.commons.math.util.MathUtils.distance1(doubleArray71, doubleArray80);
        double[] doubleArray93 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray71, (double) 32L);
        double double94 = org.apache.commons.math.util.MathUtils.distance(doubleArray53, doubleArray71);
        boolean boolean95 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray71);
        double double96 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray71);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection97 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray71, orderDirection97, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 3.948148009134034E13d + "'", double37 == 3.948148009134034E13d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1617282775) + "'", int56 == (-1617282775));
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 0.0d + "'", double94 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 0.0d + "'", double96 == 0.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.473814720414451d + "'", double1 == 0.473814720414451d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(100.0d, 22026.465794806718d, (double) 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1593.321431732963d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1594.0d + "'", double1 == 1594.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 3628800L, 3500.0d, 1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        double double2 = org.apache.commons.math.util.FastMath.min(1594.0d, 3.948148009134E13d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1594.0d + "'", double2 == 1594.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.10336039907518849d, 37.22170966680758d, (-1.074787296E9d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 800);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 13.962634015954636d + "'", double1 == 13.962634015954636d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        double[] doubleArray8 = new double[] {};
        double[] doubleArray14 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray14);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (39,481,480,091,340.34 >= 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) '#', (-1074790275L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-37617659625L) + "'", long2 == (-37617659625L));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((-1.61728282E9f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((-0.1494681981443936d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.01119118281972d + "'", double1 == 1.01119118281972d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        int[] intArray0 = null;
        int[] intArray6 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray13 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int14 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray13);
        int[] intArray20 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray27 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int28 = org.apache.commons.math.util.MathUtils.distanceInf(intArray20, intArray27);
        int[] intArray34 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray41 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int42 = org.apache.commons.math.util.MathUtils.distanceInf(intArray34, intArray41);
        int int43 = org.apache.commons.math.util.MathUtils.distanceInf(intArray20, intArray41);
        int int44 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray41);
        java.lang.Class<?> wildcardClass45 = intArray13.getClass();
        try {
            int int46 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 100 + "'", int28 == 100);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 100 + "'", int42 == 100);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 100 + "'", int43 == 100);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(wildcardClass45);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(619996103, (-1074790400));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.49536728921867335d, (java.lang.Number) 1, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection8, false);
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException10.getSuppressed();
        java.lang.Number number12 = nonMonotonousSequenceException10.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException10.getDirection();
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException10.getSuppressed();
        java.lang.Number number15 = nonMonotonousSequenceException10.getPrevious();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        java.lang.String str17 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.49536728921867335d + "'", number4.equals(0.49536728921867335d));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0L + "'", number12.equals(0L));
        org.junit.Assert.assertNull(orderDirection13);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (byte) -1 + "'", number15.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (1 >= 0.495)" + "'", str17.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (1 >= 0.495)"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        double[] doubleArray8 = new double[] {};
        double[] doubleArray14 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray14);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        double[] doubleArray18 = null;
        double[] doubleArray19 = new double[] {};
        double[] doubleArray25 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray25);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray19);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        double[] doubleArray29 = new double[] {};
        double[] doubleArray35 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray35);
        double[] doubleArray37 = new double[] {};
        double[] doubleArray43 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray37, doubleArray43);
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray43);
        double[] doubleArray46 = new double[] {};
        double[] doubleArray52 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray46, doubleArray52);
        double[] doubleArray54 = new double[] {};
        double[] doubleArray60 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray54, doubleArray60);
        double double62 = org.apache.commons.math.util.MathUtils.distance1(doubleArray52, doubleArray60);
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray43, doubleArray52);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray52);
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray52);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (39,481,480,091,340.34 >= 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1617282775) + "'", int17 == (-1617282775));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 104857931, 4L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        double double1 = org.apache.commons.math.util.FastMath.tan((-3.56830412468E11d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.9461143921009185d + "'", double1 == 2.9461143921009185d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-1991318963));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        double double1 = org.apache.commons.math.util.FastMath.acos(28.382454981066388d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        double double1 = org.apache.commons.math.util.FastMath.exp(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 35);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        double double1 = org.apache.commons.math.util.FastMath.floor(25600.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 25600.0d + "'", double1 == 25600.0d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.0732178989295803E14d, 3.948148009134034E13d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(100, (-2113867735));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        int int1 = org.apache.commons.math.util.MathUtils.hash(3.9481480091340336E13d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1903521260) + "'", int1 == (-1903521260));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(1.5707935739796302d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 645219164L, (java.lang.Number) 5.777039824101231d, 10);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (5.777 >= 645,219,164)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (5.777 >= 645,219,164)"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        double[] doubleArray8 = new double[] {};
        double[] doubleArray14 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray14);
        double[] doubleArray17 = new double[] {};
        double[] doubleArray23 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray23);
        double[] doubleArray25 = new double[] {};
        double[] doubleArray31 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray31);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray23);
        double[] doubleArray35 = null;
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray35);
        double[] doubleArray37 = new double[] {};
        double[] doubleArray43 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray37, doubleArray43);
        int int45 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray37);
        double[] doubleArray47 = new double[] {};
        double[] doubleArray53 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray47, doubleArray53);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray53);
        double[] doubleArray60 = new double[] { 3104, 363.7393755555636d, 3.9512437185814275d, 0.0177755541101581d };
        int int61 = org.apache.commons.math.util.MathUtils.hash(doubleArray60);
        try {
            double double62 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray14, doubleArray60);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 619996103 + "'", int61 == 619996103);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection10, false);
        java.lang.Number number13 = nonMonotonousSequenceException12.getArgument();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException12.getDirection();
        java.lang.Number number16 = nonMonotonousSequenceException12.getPrevious();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0L + "'", number13.equals(0L));
        org.junit.Assert.assertNull(orderDirection15);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (byte) -1 + "'", number16.equals((byte) -1));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 645219164L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 332);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 332L + "'", long1 == 332L);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        double[] doubleArray0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection1 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0, orderDirection1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + orderDirection1 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection1.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 10, (java.lang.Number) 2.3260349202281993E-8d, 31, orderDirection11, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection17, false);
        int int20 = nonMonotonousSequenceException19.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException26 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection24, false);
        java.lang.Throwable[] throwableArray27 = nonMonotonousSequenceException26.getSuppressed();
        java.lang.Number number28 = nonMonotonousSequenceException26.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = nonMonotonousSequenceException26.getDirection();
        java.lang.Throwable[] throwableArray30 = nonMonotonousSequenceException26.getSuppressed();
        nonMonotonousSequenceException19.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException26);
        nonMonotonousSequenceException13.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        java.lang.Number number34 = nonMonotonousSequenceException13.getArgument();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0L + "'", number6.equals(0L));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (byte) -1 + "'", number7.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 32 + "'", int20 == 32);
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 0L + "'", number28.equals(0L));
        org.junit.Assert.assertNull(orderDirection29);
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + (byte) 10 + "'", number34.equals((byte) 10));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        int[] intArray0 = null;
        int[] intArray1 = null;
        try {
            double double2 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 1074790301L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1024.3331934344385d + "'", double1 == 1024.3331934344385d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-1077965792L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.5840734641020676d, 1074790300);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.607527216071292E-31d + "'", double2 == 4.607527216071292E-31d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        long long2 = org.apache.commons.math.util.FastMath.max(331L, (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 331L + "'", long2 == 331L);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        double[] doubleArray8 = new double[] {};
        double[] doubleArray14 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray14);
        double[] doubleArray17 = new double[] {};
        double[] doubleArray23 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray23);
        double[] doubleArray25 = new double[] {};
        double[] doubleArray31 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray31);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray23);
        double[] doubleArray35 = null;
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray35);
        double[] doubleArray37 = new double[] {};
        double[] doubleArray43 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray37, doubleArray43);
        int int45 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray37);
        double[] doubleArray47 = null;
        double[] doubleArray48 = new double[] {};
        double[] doubleArray54 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray48, doubleArray54);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray47, doubleArray48);
        try {
            double double57 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray14, doubleArray47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray7 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray7);
        double[] doubleArray9 = new double[] {};
        double[] doubleArray15 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray15);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray15);
        double[] doubleArray18 = new double[] {};
        double[] doubleArray24 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray24);
        double[] doubleArray26 = new double[] {};
        double[] doubleArray32 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray32);
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray24);
        double[] doubleArray36 = new double[] {};
        double[] doubleArray42 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray36, doubleArray42);
        double[] doubleArray44 = new double[] {};
        double[] doubleArray50 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray44, doubleArray50);
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray50);
        double[] doubleArray53 = new double[] {};
        double[] doubleArray59 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray53, doubleArray59);
        double[] doubleArray61 = new double[] {};
        double[] doubleArray67 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray61, doubleArray67);
        double double69 = org.apache.commons.math.util.MathUtils.distance1(doubleArray59, doubleArray67);
        double double70 = org.apache.commons.math.util.MathUtils.distance1(doubleArray50, doubleArray59);
        double[] doubleArray71 = null;
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray50, doubleArray71);
        double double73 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray50);
        double[] doubleArray75 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, 1.7031839360032603E-108d);
        try {
            double double76 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray75);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray75);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        double double1 = org.apache.commons.math.util.FastMath.atan(2.3260349202281993E-8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.326034920228199E-8d + "'", double1 == 2.326034920228199E-8d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        double double1 = org.apache.commons.math.util.FastMath.log1p(5.794493116621174d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.916112448296906d + "'", double1 == 1.916112448296906d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(56628L, 56628L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3206730384L + "'", long2 == 3206730384L);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(0, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-0.690460899280118d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 32, (long) (-1074790265));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection10, false);
        java.lang.Number number13 = nonMonotonousSequenceException12.getArgument();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException12.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection19, false);
        java.lang.Throwable[] throwableArray22 = nonMonotonousSequenceException21.getSuppressed();
        java.lang.Number number23 = nonMonotonousSequenceException21.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = nonMonotonousSequenceException21.getDirection();
        java.lang.Throwable[] throwableArray25 = nonMonotonousSequenceException21.getSuppressed();
        nonMonotonousSequenceException12.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException21);
        java.lang.Number number27 = nonMonotonousSequenceException12.getPrevious();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0L + "'", number13.equals(0L));
        org.junit.Assert.assertNull(orderDirection15);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0L + "'", number23.equals(0L));
        org.junit.Assert.assertNull(orderDirection24);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + (byte) -1 + "'", number27.equals((byte) -1));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-2L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2.0f + "'", float1 == 2.0f);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        java.lang.Number number0 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.0d), number7, (-1074790265), orderDirection9, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.61728282E9f), (java.lang.Number) 0.9866275920404853d, (-1617282775), orderDirection9, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) (-29L), (int) (short) 100, orderDirection9, false);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        double[] doubleArray8 = new double[] {};
        double[] doubleArray14 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray14);
        double[] doubleArray17 = new double[] {};
        double[] doubleArray23 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray23);
        double[] doubleArray25 = new double[] {};
        double[] doubleArray31 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray31);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray23);
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1617282775) + "'", int35 == (-1617282775));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 3104);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.10686226145001441d + "'", double1 == 0.10686226145001441d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 1074790275L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(9.031323778671396d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0052160951704283d + "'", double1 == 3.0052160951704283d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (byte) 1);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (short) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (byte) 1);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) (byte) 100);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger13);
        java.math.BigInteger bigInteger15 = null;
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) (short) 0);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (long) (byte) 1);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, 0);
        java.math.BigInteger bigInteger22 = null;
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (long) (short) 0);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, bigInteger24);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, 1);
        java.math.BigInteger bigInteger28 = null;
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, (long) (short) 0);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, (long) (byte) 1);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, 0);
        java.math.BigInteger bigInteger35 = null;
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger35, (long) (short) 0);
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, bigInteger37);
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, bigInteger38);
        java.math.BigInteger bigInteger40 = null;
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, (long) (short) 0);
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, (long) (byte) 1);
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger44, 0);
        java.math.BigInteger bigInteger47 = null;
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger47, (long) (short) 0);
        java.math.BigInteger bigInteger50 = org.apache.commons.math.util.MathUtils.pow(bigInteger44, bigInteger49);
        java.math.BigInteger bigInteger52 = org.apache.commons.math.util.MathUtils.pow(bigInteger44, 1);
        java.math.BigInteger bigInteger53 = null;
        java.math.BigInteger bigInteger55 = org.apache.commons.math.util.MathUtils.pow(bigInteger53, (long) (short) 0);
        java.math.BigInteger bigInteger57 = org.apache.commons.math.util.MathUtils.pow(bigInteger55, (long) (byte) 1);
        java.math.BigInteger bigInteger59 = org.apache.commons.math.util.MathUtils.pow(bigInteger57, 0);
        java.math.BigInteger bigInteger60 = org.apache.commons.math.util.MathUtils.pow(bigInteger52, bigInteger59);
        java.math.BigInteger bigInteger61 = org.apache.commons.math.util.MathUtils.pow(bigInteger39, bigInteger52);
        java.math.BigInteger bigInteger62 = null;
        java.math.BigInteger bigInteger64 = org.apache.commons.math.util.MathUtils.pow(bigInteger62, (long) (short) 0);
        java.math.BigInteger bigInteger66 = org.apache.commons.math.util.MathUtils.pow(bigInteger64, (long) (byte) 1);
        java.math.BigInteger bigInteger68 = org.apache.commons.math.util.MathUtils.pow(bigInteger66, 0);
        java.math.BigInteger bigInteger69 = null;
        java.math.BigInteger bigInteger71 = org.apache.commons.math.util.MathUtils.pow(bigInteger69, (long) (short) 0);
        java.math.BigInteger bigInteger72 = org.apache.commons.math.util.MathUtils.pow(bigInteger66, bigInteger71);
        java.math.BigInteger bigInteger74 = org.apache.commons.math.util.MathUtils.pow(bigInteger66, 1);
        java.math.BigInteger bigInteger75 = null;
        java.math.BigInteger bigInteger77 = org.apache.commons.math.util.MathUtils.pow(bigInteger75, (long) (short) 0);
        java.math.BigInteger bigInteger79 = org.apache.commons.math.util.MathUtils.pow(bigInteger77, (long) (byte) 1);
        java.math.BigInteger bigInteger81 = org.apache.commons.math.util.MathUtils.pow(bigInteger79, 0);
        java.math.BigInteger bigInteger82 = null;
        java.math.BigInteger bigInteger84 = org.apache.commons.math.util.MathUtils.pow(bigInteger82, (long) (short) 0);
        java.math.BigInteger bigInteger85 = org.apache.commons.math.util.MathUtils.pow(bigInteger79, bigInteger84);
        java.math.BigInteger bigInteger86 = org.apache.commons.math.util.MathUtils.pow(bigInteger66, bigInteger85);
        java.lang.Class<?> wildcardClass87 = bigInteger86.getClass();
        java.math.BigInteger bigInteger88 = org.apache.commons.math.util.MathUtils.pow(bigInteger61, bigInteger86);
        java.math.BigInteger bigInteger89 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, bigInteger61);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException92 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger14, (java.lang.Number) 1.5405025668761214d, 132);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger49);
        org.junit.Assert.assertNotNull(bigInteger50);
        org.junit.Assert.assertNotNull(bigInteger52);
        org.junit.Assert.assertNotNull(bigInteger55);
        org.junit.Assert.assertNotNull(bigInteger57);
        org.junit.Assert.assertNotNull(bigInteger59);
        org.junit.Assert.assertNotNull(bigInteger60);
        org.junit.Assert.assertNotNull(bigInteger61);
        org.junit.Assert.assertNotNull(bigInteger64);
        org.junit.Assert.assertNotNull(bigInteger66);
        org.junit.Assert.assertNotNull(bigInteger68);
        org.junit.Assert.assertNotNull(bigInteger71);
        org.junit.Assert.assertNotNull(bigInteger72);
        org.junit.Assert.assertNotNull(bigInteger74);
        org.junit.Assert.assertNotNull(bigInteger77);
        org.junit.Assert.assertNotNull(bigInteger79);
        org.junit.Assert.assertNotNull(bigInteger81);
        org.junit.Assert.assertNotNull(bigInteger84);
        org.junit.Assert.assertNotNull(bigInteger85);
        org.junit.Assert.assertNotNull(bigInteger86);
        org.junit.Assert.assertNotNull(wildcardClass87);
        org.junit.Assert.assertNotNull(bigInteger88);
        org.junit.Assert.assertNotNull(bigInteger89);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray7 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray7);
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray1);
        int int10 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray11 = new double[] {};
        double[] doubleArray17 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray17);
        double[] doubleArray19 = new double[] {};
        double[] doubleArray25 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray25);
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray25);
        double[] doubleArray28 = new double[] {};
        double[] doubleArray34 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray34);
        double[] doubleArray36 = new double[] {};
        double[] doubleArray42 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray36, doubleArray42);
        double double44 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray42);
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray34);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray34);
        try {
            double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 1089L);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-2147483648), (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 15.104412573075516d + "'", double1 == 15.104412573075516d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1074790399, 784365034);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 559939585 + "'", int2 == 559939585);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 28518000000L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.455119064678403d + "'", double1 == 10.455119064678403d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, 2.1968059704696543d, 3);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) (-10), 3, 4);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-10.0f) + "'", float3 == (-10.0f));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 800L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 2.11387776E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.6894126896682486E7d + "'", double1 == 3.6894126896682486E7d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        int int2 = org.apache.commons.math.util.FastMath.max(35, 1074790300);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1074790300 + "'", int2 == 1074790300);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1032654167, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (short) 0, (double) (-2113867735));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.113867735E9d) + "'", double2 == (-2.113867735E9d));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.8332060551719964d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2125203721) + "'", int1 == (-2125203721));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-37617659625L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2147483648) + "'", int1 == (-2147483648));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(35L, (long) (-1617282775));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 11320979425L + "'", long2 == 11320979425L);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 22025.465794806718d, (java.lang.Number) 10000, (int) 'a');
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        java.lang.Class<?> wildcardClass6 = nonMonotonousSequenceException3.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly increasing (10,000 >= 22,025.466)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly increasing (10,000 >= 22,025.466)"));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) (-1.07479027E9f), (int) '#');
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 619996103);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(104857600, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 104857601 + "'", int2 == 104857601);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-1074790399), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 1074790274L, (double) 296L, (double) 1.0747904E9f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 3.395E7d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (byte) 1);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 1);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) (short) 0);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) (byte) 1);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 0);
        java.math.BigInteger bigInteger20 = null;
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) (short) 0);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, bigInteger22);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger23);
        java.lang.Class<?> wildcardClass25 = bigInteger23.getClass();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(wildcardClass25);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        int int8 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number9 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Number number10 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0L + "'", number7.equals(0L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 32 + "'", int8 == 32);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (byte) -1 + "'", number9.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0L + "'", number10.equals(0L));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 104857601, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        double double2 = org.apache.commons.math.util.FastMath.min(32783.99608040484d, (double) 3628800L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32783.99608040484d + "'", double2 == 32783.99608040484d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        double double2 = org.apache.commons.math.util.FastMath.min(1.5707963172581534d, (double) (-1.0747904E9f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0747904E9d) + "'", double2 == (-1.0747904E9d));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection3, false);
        int int6 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (byte) -1 + "'", number7.equals((byte) -1));
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 572.9577951308232d + "'", double1 == 572.9577951308232d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 1074787296L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.03132252442497d + "'", double1 == 9.03132252442497d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (byte) 1);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger9);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) (short) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) (byte) 1);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 0);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (long) (short) 0);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger20);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 1);
        java.math.BigInteger bigInteger24 = null;
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, (long) (short) 0);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, (long) (byte) 1);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, 0);
        java.math.BigInteger bigInteger31 = null;
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, (long) (short) 0);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, bigInteger33);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger34);
        java.math.BigInteger bigInteger36 = null;
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, (long) (short) 0);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, (long) (byte) 1);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, 0);
        java.math.BigInteger bigInteger43 = null;
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger43, (long) (short) 0);
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, bigInteger45);
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, 1);
        java.math.BigInteger bigInteger49 = null;
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger49, (long) (short) 0);
        java.math.BigInteger bigInteger53 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, (long) (byte) 1);
        java.math.BigInteger bigInteger55 = org.apache.commons.math.util.MathUtils.pow(bigInteger53, 0);
        java.math.BigInteger bigInteger56 = org.apache.commons.math.util.MathUtils.pow(bigInteger48, bigInteger55);
        java.math.BigInteger bigInteger57 = org.apache.commons.math.util.MathUtils.pow(bigInteger35, bigInteger48);
        java.math.BigInteger bigInteger58 = null;
        java.math.BigInteger bigInteger60 = org.apache.commons.math.util.MathUtils.pow(bigInteger58, (long) (short) 0);
        java.math.BigInteger bigInteger62 = org.apache.commons.math.util.MathUtils.pow(bigInteger60, (long) (byte) 1);
        java.math.BigInteger bigInteger64 = org.apache.commons.math.util.MathUtils.pow(bigInteger62, 0);
        java.math.BigInteger bigInteger65 = null;
        java.math.BigInteger bigInteger67 = org.apache.commons.math.util.MathUtils.pow(bigInteger65, (long) (short) 0);
        java.math.BigInteger bigInteger68 = org.apache.commons.math.util.MathUtils.pow(bigInteger62, bigInteger67);
        java.math.BigInteger bigInteger70 = org.apache.commons.math.util.MathUtils.pow(bigInteger62, 1);
        java.math.BigInteger bigInteger71 = null;
        java.math.BigInteger bigInteger73 = org.apache.commons.math.util.MathUtils.pow(bigInteger71, (long) (short) 0);
        java.math.BigInteger bigInteger75 = org.apache.commons.math.util.MathUtils.pow(bigInteger73, (long) (byte) 1);
        java.math.BigInteger bigInteger77 = org.apache.commons.math.util.MathUtils.pow(bigInteger75, 0);
        java.math.BigInteger bigInteger78 = null;
        java.math.BigInteger bigInteger80 = org.apache.commons.math.util.MathUtils.pow(bigInteger78, (long) (short) 0);
        java.math.BigInteger bigInteger81 = org.apache.commons.math.util.MathUtils.pow(bigInteger75, bigInteger80);
        java.math.BigInteger bigInteger82 = org.apache.commons.math.util.MathUtils.pow(bigInteger62, bigInteger81);
        java.lang.Class<?> wildcardClass83 = bigInteger82.getClass();
        java.math.BigInteger bigInteger84 = org.apache.commons.math.util.MathUtils.pow(bigInteger57, bigInteger82);
        java.math.BigInteger bigInteger85 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger84);
        java.math.BigInteger bigInteger86 = null;
        java.math.BigInteger bigInteger88 = org.apache.commons.math.util.MathUtils.pow(bigInteger86, (long) (short) 0);
        java.math.BigInteger bigInteger90 = org.apache.commons.math.util.MathUtils.pow(bigInteger88, 104857599);
        java.lang.Class<?> wildcardClass91 = bigInteger88.getClass();
        java.math.BigInteger bigInteger92 = org.apache.commons.math.util.MathUtils.pow(bigInteger85, bigInteger88);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger48);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger53);
        org.junit.Assert.assertNotNull(bigInteger55);
        org.junit.Assert.assertNotNull(bigInteger56);
        org.junit.Assert.assertNotNull(bigInteger57);
        org.junit.Assert.assertNotNull(bigInteger60);
        org.junit.Assert.assertNotNull(bigInteger62);
        org.junit.Assert.assertNotNull(bigInteger64);
        org.junit.Assert.assertNotNull(bigInteger67);
        org.junit.Assert.assertNotNull(bigInteger68);
        org.junit.Assert.assertNotNull(bigInteger70);
        org.junit.Assert.assertNotNull(bigInteger73);
        org.junit.Assert.assertNotNull(bigInteger75);
        org.junit.Assert.assertNotNull(bigInteger77);
        org.junit.Assert.assertNotNull(bigInteger80);
        org.junit.Assert.assertNotNull(bigInteger81);
        org.junit.Assert.assertNotNull(bigInteger82);
        org.junit.Assert.assertNotNull(wildcardClass83);
        org.junit.Assert.assertNotNull(bigInteger84);
        org.junit.Assert.assertNotNull(bigInteger85);
        org.junit.Assert.assertNotNull(bigInteger88);
        org.junit.Assert.assertNotNull(bigInteger90);
        org.junit.Assert.assertNotNull(wildcardClass91);
        org.junit.Assert.assertNotNull(bigInteger92);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-104857599), (-2147483648));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2042626049 + "'", int2 == 2042626049);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) (-37617659625L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) 'a', 1077968896);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        double double2 = org.apache.commons.math.util.FastMath.max(1.5032385536E11d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5032385536E11d + "'", double2 == 1.5032385536E11d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) 1);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-0.6156264703860141d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8506921561246407d) + "'", double1 == (-0.8506921561246407d));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.19976577695852665d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0200196260684236d + "'", double1 == 1.0200196260684236d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        int int2 = org.apache.commons.math.util.FastMath.max((-183792213), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(2.0947125472611012d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0947125472611017d + "'", double1 == 2.0947125472611017d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, 403.4287934927351d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        double[] doubleArray8 = new double[] {};
        double[] doubleArray14 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray14);
        double[] doubleArray17 = new double[] {};
        double[] doubleArray23 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray23);
        double[] doubleArray25 = new double[] {};
        double[] doubleArray31 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray31);
        double[] doubleArray34 = new double[] {};
        double[] doubleArray40 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray40);
        double[] doubleArray42 = new double[] {};
        double[] doubleArray48 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray42, doubleArray48);
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray48);
        double double51 = org.apache.commons.math.util.MathUtils.distance1(doubleArray31, doubleArray40);
        double[] doubleArray52 = null;
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray52);
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        double double55 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1617282775) + "'", int54 == (-1617282775));
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 1, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        long long1 = org.apache.commons.math.util.FastMath.round(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, 97L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        double double1 = org.apache.commons.math.util.FastMath.rint(6.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.0d + "'", double1 == 6.0d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.5860134523134298E15d, 0.0d, 100.53096491487338d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        long long1 = org.apache.commons.math.util.FastMath.round(1.5422326689561365d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 332, (double) (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 331.99999999999994d + "'", double2 == 331.99999999999994d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) 1, (-1074790310L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1074790310L) + "'", long2 == (-1074790310L));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1074791115, 3104);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5027893144409464193L + "'", long2 == 5027893144409464193L);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        double[] doubleArray0 = null;
        double[] doubleArray1 = null;
        double[] doubleArray2 = new double[] {};
        double[] doubleArray8 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray2);
        try {
            double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) '#', (long) 1661992960);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1661992925L) + "'", long2 == (-1661992925L));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(10000, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        double double2 = org.apache.commons.math.util.FastMath.min(2.9461143921009185d, 32783.99608040484d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.9461143921009185d + "'", double2 == 2.9461143921009185d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1032654167, 1.4210854715202004E-14d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-86196911), 0.0d, 11585);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((-0.8414709848078965d), 1089.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1086.1495871572604d + "'", double2 == 1086.1495871572604d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        double double1 = org.apache.commons.math.util.FastMath.asin(22026.465794806718d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.0d, 3.948148009133937E13d, (double) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 11320979425L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-1.07479027E9f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.074790273E9d) + "'", double1 == (-1.074790273E9d));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.5840734641020676d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7642469915557847d + "'", double1 == 0.7642469915557847d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1074790399), (java.lang.Number) 4.666310772197643E157d, (-1074790265));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 1074790275L, (double) 296L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        java.lang.Number number4 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.0d), number4, (-1074790265), orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.61728282E9f), (java.lang.Number) 0.9866275920404853d, (-1617282775), orderDirection6, false);
        java.lang.Number number11 = nonMonotonousSequenceException10.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0.9866275920404853d + "'", number11.equals(0.9866275920404853d));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        int int2 = org.apache.commons.math.util.FastMath.max((-1991318963), (-2113867735));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1991318963) + "'", int2 == (-1991318963));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-1617282775));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 24.0d + "'", double1 == 24.0d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 416L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 416 + "'", int1 == 416);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 1155174297527910400L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.42543965992489424d + "'", double1 == 0.42543965992489424d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number10 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Number number11 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0L + "'", number7.equals(0L));
        org.junit.Assert.assertNull(orderDirection8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (byte) -1 + "'", number10.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (byte) -1 + "'", number11.equals((byte) -1));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (short) 100, 1074790300);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1074790300 + "'", int2 == 1074790300);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-0.027181892591221314d), (int) '4', 2042626049);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        long long1 = org.apache.commons.math.util.MathUtils.sign((-1074787296L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-1074790272), (long) 416);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1074790688L) + "'", long2 == (-1074790688L));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-104857599L), 559939585, 31);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (byte) -1, (-1074790265));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1074790264 + "'", int2 == 1074790264);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        int int2 = org.apache.commons.math.util.FastMath.min(619996103, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-1991318963));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection10, false);
        java.lang.Number number13 = nonMonotonousSequenceException12.getArgument();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException12.getDirection();
        java.lang.String str16 = nonMonotonousSequenceException12.toString();
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException12.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0L + "'", number13.equals(0L));
        org.junit.Assert.assertNull(orderDirection15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not decreasing (-1 < 0)" + "'", str16.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not decreasing (-1 < 0)"));
        org.junit.Assert.assertNotNull(throwableArray17);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        int int1 = org.apache.commons.math.util.MathUtils.hash((-1.130627094654336d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-800446574) + "'", int1 == (-800446574));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.49536728921867335d, (java.lang.Number) 1, 0);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        java.lang.String str7 = nonMonotonousSequenceException3.toString();
        java.lang.Number number8 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (1 >= 0.495)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (1 >= 0.495)"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (1 >= 0.495)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (1 >= 0.495)"));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0.49536728921867335d + "'", number8.equals(0.49536728921867335d));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        double double1 = org.apache.commons.math.util.FastMath.log(25600.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.150347630467653d + "'", double1 == 10.150347630467653d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-1074790274L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 25, (java.lang.Number) 2L, (-1074790300));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((-1074790275L), (long) 5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1074790270L) + "'", long2 == (-1074790270L));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.416196940536434d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.3611093629270335E-15d + "'", double1 == 6.3611093629270335E-15d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 1155174297527910400L, 33.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        double double1 = org.apache.commons.math.util.FastMath.ulp(5.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        double double1 = org.apache.commons.math.util.FastMath.asin(52.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 0L, (-1074790275));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(0, 1095479168);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1095479168 + "'", int2 == 1095479168);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (byte) 1);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 1);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) (short) 0);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) (byte) 1);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 0);
        java.math.BigInteger bigInteger20 = null;
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) (short) 0);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, bigInteger22);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger23);
        java.lang.Class<?> wildcardClass25 = bigInteger24.getClass();
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, 1074790300);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(bigInteger27);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (byte) 1, 840);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 1074790300);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0747903E9d + "'", double1 == 1.0747903E9d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(19.843974440965976d, (-1.074790399E9d), 331.99999999999994d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(332, 331);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.805134968916488d + "'", double2 == 5.805134968916488d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(25, (-1074790275));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        double double1 = org.apache.commons.math.util.FastMath.sinh(9.031323778671396d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4180.460068958561d + "'", double1 == 4180.460068958561d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        double double1 = org.apache.commons.math.util.FastMath.log1p(7.105427357601002E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357600977E-15d + "'", double1 == 7.105427357600977E-15d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(9.031323778267323d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0052160951031994d + "'", double1 == 3.0052160951031994d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(0, (-183792213));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 619996103);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.19996103E8d + "'", double1 == 6.19996103E8d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        long long1 = org.apache.commons.math.util.FastMath.round(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (byte) 1);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 1);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) (short) 0);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) (byte) 1);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 0);
        java.math.BigInteger bigInteger20 = null;
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) (short) 0);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, bigInteger22);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger23);
        java.math.BigInteger bigInteger25 = null;
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, (long) (short) 0);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (long) (byte) 1);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 0);
        java.math.BigInteger bigInteger32 = null;
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, (long) (short) 0);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, bigInteger34);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 1);
        java.math.BigInteger bigInteger38 = null;
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, (long) (short) 0);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, (long) (byte) 1);
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, 0);
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, bigInteger44);
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, bigInteger37);
        java.math.BigInteger bigInteger47 = null;
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger47, (long) (short) 0);
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger49, (long) (byte) 1);
        java.math.BigInteger bigInteger53 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, 0);
        java.math.BigInteger bigInteger54 = null;
        java.math.BigInteger bigInteger56 = org.apache.commons.math.util.MathUtils.pow(bigInteger54, (long) (short) 0);
        java.math.BigInteger bigInteger57 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, bigInteger56);
        java.math.BigInteger bigInteger59 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, 1);
        java.math.BigInteger bigInteger60 = null;
        java.math.BigInteger bigInteger62 = org.apache.commons.math.util.MathUtils.pow(bigInteger60, (long) (short) 0);
        java.math.BigInteger bigInteger64 = org.apache.commons.math.util.MathUtils.pow(bigInteger62, (long) (byte) 1);
        java.math.BigInteger bigInteger66 = org.apache.commons.math.util.MathUtils.pow(bigInteger64, 0);
        java.math.BigInteger bigInteger67 = null;
        java.math.BigInteger bigInteger69 = org.apache.commons.math.util.MathUtils.pow(bigInteger67, (long) (short) 0);
        java.math.BigInteger bigInteger70 = org.apache.commons.math.util.MathUtils.pow(bigInteger64, bigInteger69);
        java.math.BigInteger bigInteger71 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, bigInteger70);
        java.lang.Class<?> wildcardClass72 = bigInteger71.getClass();
        java.math.BigInteger bigInteger73 = org.apache.commons.math.util.MathUtils.pow(bigInteger46, bigInteger71);
        java.math.BigInteger bigInteger75 = org.apache.commons.math.util.MathUtils.pow(bigInteger71, 1077968896);
        java.math.BigInteger bigInteger77 = org.apache.commons.math.util.MathUtils.pow(bigInteger75, 784365034);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger49);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger53);
        org.junit.Assert.assertNotNull(bigInteger56);
        org.junit.Assert.assertNotNull(bigInteger57);
        org.junit.Assert.assertNotNull(bigInteger59);
        org.junit.Assert.assertNotNull(bigInteger62);
        org.junit.Assert.assertNotNull(bigInteger64);
        org.junit.Assert.assertNotNull(bigInteger66);
        org.junit.Assert.assertNotNull(bigInteger69);
        org.junit.Assert.assertNotNull(bigInteger70);
        org.junit.Assert.assertNotNull(bigInteger71);
        org.junit.Assert.assertNotNull(wildcardClass72);
        org.junit.Assert.assertNotNull(bigInteger73);
        org.junit.Assert.assertNotNull(bigInteger75);
        org.junit.Assert.assertNotNull(bigInteger77);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        long long1 = org.apache.commons.math.util.FastMath.abs(5865987981925416961L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 5865987981925416961L + "'", long1 == 5865987981925416961L);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) ' ', 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        double[] doubleArray8 = new double[] {};
        double[] doubleArray14 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray14);
        double[] doubleArray17 = null;
        double[] doubleArray18 = new double[] {};
        double[] doubleArray24 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray17, doubleArray18);
        double[] doubleArray27 = null;
        double[] doubleArray28 = new double[] {};
        double[] doubleArray34 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray34);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray27, doubleArray28);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        double double38 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        double[] doubleArray39 = new double[] {};
        double[] doubleArray45 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray45);
        double[] doubleArray47 = new double[] {};
        double[] doubleArray53 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray47, doubleArray53);
        double double55 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray53);
        double double56 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray53);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray53);
        double double58 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray18, doubleArray28);
        try {
            double double59 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray14, doubleArray28);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 3.948148009134034E13d + "'", double56 == 3.948148009134034E13d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) Float.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (byte) 1);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 1);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) (short) 0);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) (byte) 1);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 0);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger19);
        java.lang.Number number27 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException31 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.0d), number27, (-1074790265), orderDirection29, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException33 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.61728282E9f), (java.lang.Number) 0.9866275920404853d, (-1617282775), orderDirection29, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException35 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger20, (java.lang.Number) (-800446574), 104857599, orderDirection29, false);
        java.lang.String str36 = nonMonotonousSequenceException35.toString();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection29.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 104,857,598 and 104,857,599 are not increasing (-800,446,574 > 1)" + "'", str36.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 104,857,598 and 104,857,599 are not increasing (-800,446,574 > 1)"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(11320979425L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        long long2 = org.apache.commons.math.util.FastMath.min(1089L, (long) (-2113877735));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2113877735L) + "'", long2 == (-2113877735L));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-2125203721));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2125203712) + "'", int1 == (-2125203712));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        double double1 = org.apache.commons.math.util.FastMath.cos(10.000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8390715290764514d) + "'", double1 == (-0.8390715290764514d));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-1617282775));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (byte) 1);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 1);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) (short) 0);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) (byte) 1);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 0);
        java.math.BigInteger bigInteger20 = null;
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) (short) 0);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, bigInteger22);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger23);
        java.math.BigInteger bigInteger25 = null;
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, (long) (short) 0);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (long) (byte) 1);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 0);
        java.math.BigInteger bigInteger32 = null;
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, (long) (short) 0);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, bigInteger34);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 1);
        java.math.BigInteger bigInteger38 = null;
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, (long) (short) 0);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, (long) (byte) 1);
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, 0);
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, bigInteger44);
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, bigInteger37);
        java.math.BigInteger bigInteger47 = null;
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger47, (long) (short) 0);
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger49, (long) (byte) 1);
        java.math.BigInteger bigInteger53 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, 0);
        java.math.BigInteger bigInteger54 = null;
        java.math.BigInteger bigInteger56 = org.apache.commons.math.util.MathUtils.pow(bigInteger54, (long) (short) 0);
        java.math.BigInteger bigInteger57 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, bigInteger56);
        java.math.BigInteger bigInteger59 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, 1);
        java.math.BigInteger bigInteger60 = null;
        java.math.BigInteger bigInteger62 = org.apache.commons.math.util.MathUtils.pow(bigInteger60, (long) (short) 0);
        java.math.BigInteger bigInteger64 = org.apache.commons.math.util.MathUtils.pow(bigInteger62, (long) (byte) 1);
        java.math.BigInteger bigInteger66 = org.apache.commons.math.util.MathUtils.pow(bigInteger64, 0);
        java.math.BigInteger bigInteger67 = null;
        java.math.BigInteger bigInteger69 = org.apache.commons.math.util.MathUtils.pow(bigInteger67, (long) (short) 0);
        java.math.BigInteger bigInteger70 = org.apache.commons.math.util.MathUtils.pow(bigInteger64, bigInteger69);
        java.math.BigInteger bigInteger71 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, bigInteger70);
        java.lang.Class<?> wildcardClass72 = bigInteger71.getClass();
        java.math.BigInteger bigInteger73 = org.apache.commons.math.util.MathUtils.pow(bigInteger46, bigInteger71);
        java.math.BigInteger bigInteger74 = null;
        java.math.BigInteger bigInteger76 = org.apache.commons.math.util.MathUtils.pow(bigInteger74, (long) (short) 0);
        java.math.BigInteger bigInteger78 = org.apache.commons.math.util.MathUtils.pow(bigInteger76, (long) (byte) 1);
        java.math.BigInteger bigInteger80 = org.apache.commons.math.util.MathUtils.pow(bigInteger78, 0);
        java.math.BigInteger bigInteger82 = org.apache.commons.math.util.MathUtils.pow(bigInteger78, (long) (byte) 100);
        java.math.BigInteger bigInteger83 = org.apache.commons.math.util.MathUtils.pow(bigInteger71, bigInteger78);
        java.math.BigInteger bigInteger85 = org.apache.commons.math.util.MathUtils.pow(bigInteger83, 0L);
        java.math.BigInteger bigInteger86 = null;
        java.math.BigInteger bigInteger88 = org.apache.commons.math.util.MathUtils.pow(bigInteger86, (long) (short) 0);
        java.math.BigInteger bigInteger90 = org.apache.commons.math.util.MathUtils.pow(bigInteger88, 104857599);
        java.lang.Class<?> wildcardClass91 = bigInteger88.getClass();
        java.math.BigInteger bigInteger92 = org.apache.commons.math.util.MathUtils.pow(bigInteger85, bigInteger88);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger49);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger53);
        org.junit.Assert.assertNotNull(bigInteger56);
        org.junit.Assert.assertNotNull(bigInteger57);
        org.junit.Assert.assertNotNull(bigInteger59);
        org.junit.Assert.assertNotNull(bigInteger62);
        org.junit.Assert.assertNotNull(bigInteger64);
        org.junit.Assert.assertNotNull(bigInteger66);
        org.junit.Assert.assertNotNull(bigInteger69);
        org.junit.Assert.assertNotNull(bigInteger70);
        org.junit.Assert.assertNotNull(bigInteger71);
        org.junit.Assert.assertNotNull(wildcardClass72);
        org.junit.Assert.assertNotNull(bigInteger73);
        org.junit.Assert.assertNotNull(bigInteger76);
        org.junit.Assert.assertNotNull(bigInteger78);
        org.junit.Assert.assertNotNull(bigInteger80);
        org.junit.Assert.assertNotNull(bigInteger82);
        org.junit.Assert.assertNotNull(bigInteger83);
        org.junit.Assert.assertNotNull(bigInteger85);
        org.junit.Assert.assertNotNull(bigInteger88);
        org.junit.Assert.assertNotNull(bigInteger90);
        org.junit.Assert.assertNotNull(wildcardClass91);
        org.junit.Assert.assertNotNull(bigInteger92);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 2L, (double) 2.11387776E9f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 30.977244805853132d + "'", double2 == 30.977244805853132d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(33.0d, 3.9481480091340336E13d, (double) (-29L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 3, (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(1077968896L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        double[] doubleArray8 = new double[] {};
        double[] doubleArray14 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray14);
        double[] doubleArray17 = new double[] {};
        double[] doubleArray23 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray23);
        double[] doubleArray25 = new double[] {};
        double[] doubleArray31 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray31);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray23);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) 32L);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray36);
        double[] doubleArray38 = new double[] {};
        double[] doubleArray44 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray38, doubleArray44);
        double[] doubleArray46 = new double[] {};
        double[] doubleArray52 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray46, doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray44, doubleArray52);
        double[] doubleArray55 = new double[] {};
        double[] doubleArray61 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray55, doubleArray61);
        double[] doubleArray63 = new double[] {};
        double[] doubleArray69 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray63, doubleArray69);
        double double71 = org.apache.commons.math.util.MathUtils.distance1(doubleArray61, doubleArray69);
        double double72 = org.apache.commons.math.util.MathUtils.distance1(doubleArray52, doubleArray61);
        double[] doubleArray73 = null;
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray52, doubleArray73);
        double[] doubleArray75 = new double[] {};
        double[] doubleArray81 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray75, doubleArray81);
        int int83 = org.apache.commons.math.util.MathUtils.hash(doubleArray75);
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray75);
        double double85 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray36, doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-183792213) + "'", int37 == (-183792213));
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 1 + "'", int83 == 1);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 3.948148009130834E13d + "'", double85 == 3.948148009130834E13d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-3224370900L), (double) (-1077965792L));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(24);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        long long1 = org.apache.commons.math.util.FastMath.round(21.488538591220372d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 21L + "'", long1 == 21L);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-1074790400));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        java.lang.Number number4 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.0d), number4, (-1074790265), orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.02718189358035228d), (java.lang.Number) (-104857600), 1077968896, orderDirection6, false);
        int int11 = nonMonotonousSequenceException10.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1077968896 + "'", int11 == 1077968896);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((-2147483648L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2147483648L) + "'", long2 == (-2147483648L));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 31, (long) 132);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4092L + "'", long2 == 4092L);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        double double1 = org.apache.commons.math.util.FastMath.ulp(11013.232874703393d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8189894035458565E-12d + "'", double1 == 1.8189894035458565E-12d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 800, (java.lang.Number) 1.4711276743037347d, (-800446574));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(840, 800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40 + "'", int2 == 40);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(100, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 2042626049, 3.948148009405236E13d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.619275968248924E151d + "'", double1 == 9.619275968248924E151d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-1074790270L), (long) 800);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-1), (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-10L) + "'", long2 == (-10L));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        double double2 = org.apache.commons.math.util.FastMath.pow(4.0d, 3.4657359027997265d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 122.06212533523829d + "'", double2 == 122.06212533523829d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection10, false);
        java.lang.Number number13 = nonMonotonousSequenceException12.getArgument();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection18, false);
        int int21 = nonMonotonousSequenceException20.getIndex();
        java.lang.Number number22 = nonMonotonousSequenceException20.getPrevious();
        nonMonotonousSequenceException12.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException20);
        boolean boolean24 = nonMonotonousSequenceException20.getStrict();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0L + "'", number13.equals(0L));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 32 + "'", int21 == 32);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (byte) -1 + "'", number22.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        double double2 = org.apache.commons.math.util.FastMath.max(1.0200196260684236d, (double) (-1074790399L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0200196260684236d + "'", double2 == 1.0200196260684236d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((-1.048576E8d), (-1.074790273E9d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0747902706482983E9d) + "'", double2 == (-1.0747902706482983E9d));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.42543965992489424d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4022429844072145d + "'", double1 == 0.4022429844072145d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        double double1 = org.apache.commons.math.util.FastMath.floor(1089.0000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1089.0d + "'", double1 == 1089.0d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(33L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 33L + "'", long2 == 33L);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0L + "'", number7.equals(0L));
        org.junit.Assert.assertNull(orderDirection8);
        org.junit.Assert.assertNull(orderDirection9);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(4092L, (-1074790688L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1074794780L + "'", long2 == 1074794780L);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        double double1 = org.apache.commons.math.util.FastMath.ulp(175.57049866079439d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.8421709430404007E-14d + "'", double1 == 2.8421709430404007E-14d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 8519509564645355905L, (double) (-2147483648));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 104L, 800);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(2.0947125472611017d, 0.9866275920404853d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        int int2 = org.apache.commons.math.util.FastMath.max((-104857600), 331);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 331 + "'", int2 == 331);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.4022429844072145d, (double) 11585);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11586.595949423565d + "'", double2 == 11586.595949423565d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        double double1 = org.apache.commons.math.util.FastMath.cos(5.794493116621174d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8829475928589269d + "'", double1 == 0.8829475928589269d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        float float2 = org.apache.commons.math.util.MathUtils.round(Float.NaN, 104857600);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) (-2113867735));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 874479555 + "'", int1 == 874479555);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-104857599L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.7853981633974483d), (java.lang.Number) 2.356194490192345d, 10);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.49536728921867335d, (java.lang.Number) 1, 0);
        java.lang.Number number9 = nonMonotonousSequenceException8.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.Number number11 = nonMonotonousSequenceException3.getPrevious();
        boolean boolean12 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 2.356194490192345d + "'", number4.equals(2.356194490192345d));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0.49536728921867335d + "'", number9.equals(0.49536728921867335d));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 2.356194490192345d + "'", number11.equals(2.356194490192345d));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        int[] intArray0 = null;
        int[] intArray1 = new int[] {};
        int[] intArray2 = null;
        double double3 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray2);
        int[] intArray9 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray16 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray9, intArray16);
        int int18 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray9);
        try {
            int int19 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) -1);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) -1 + "'", byte1 == (byte) -1);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 1077477376, (long) (-2125203712));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8944761402621952L + "'", long2 == 8944761402621952L);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (byte) -1, (-800446574));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int[] intArray2 = null;
        double double3 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray2);
        int int4 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray2);
        int[] intArray10 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray17 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int18 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray17);
        int[] intArray24 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray31 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int32 = org.apache.commons.math.util.MathUtils.distanceInf(intArray24, intArray31);
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray31);
        int int34 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray10);
        int[] intArray40 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray47 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int48 = org.apache.commons.math.util.MathUtils.distanceInf(intArray40, intArray47);
        int[] intArray54 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray61 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int62 = org.apache.commons.math.util.MathUtils.distanceInf(intArray54, intArray61);
        int int63 = org.apache.commons.math.util.MathUtils.distance1(intArray40, intArray61);
        int int64 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray40);
        int[] intArray70 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray77 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int78 = org.apache.commons.math.util.MathUtils.distanceInf(intArray70, intArray77);
        int[] intArray84 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray91 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int92 = org.apache.commons.math.util.MathUtils.distanceInf(intArray84, intArray91);
        int int93 = org.apache.commons.math.util.MathUtils.distanceInf(intArray70, intArray91);
        int int94 = org.apache.commons.math.util.MathUtils.distance1(intArray40, intArray91);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 100 + "'", int18 == 100);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 100 + "'", int32 == 100);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 331 + "'", int33 == 331);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 100 + "'", int48 == 100);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 100 + "'", int62 == 100);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 331 + "'", int63 == 331);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 100 + "'", int78 == 100);
        org.junit.Assert.assertNotNull(intArray84);
        org.junit.Assert.assertNotNull(intArray91);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 100 + "'", int92 == 100);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 100 + "'", int93 == 100);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 331 + "'", int94 == 331);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        long long1 = org.apache.commons.math.util.FastMath.abs((-1074790270L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1074790270L + "'", long1 == 1074790270L);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.8997923511366261d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8997923511366261d + "'", double1 == 0.8997923511366261d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) Float.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963267948966d) + "'", double1 == (-1.5707963267948966d));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((-0.08761992810895707d), 10004);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-7.934579498645831E-73d) + "'", double2 == (-7.934579498645831E-73d));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) (byte) 0, 619996103);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-2125203712), (long) 32);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 10, (java.lang.Number) 2.3260349202281993E-8d, 31, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection9, false);
        int int12 = nonMonotonousSequenceException11.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection16, false);
        java.lang.Throwable[] throwableArray19 = nonMonotonousSequenceException18.getSuppressed();
        java.lang.Number number20 = nonMonotonousSequenceException18.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = nonMonotonousSequenceException18.getDirection();
        java.lang.Throwable[] throwableArray22 = nonMonotonousSequenceException18.getSuppressed();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        boolean boolean25 = nonMonotonousSequenceException5.getStrict();
        java.lang.Class<?> wildcardClass26 = nonMonotonousSequenceException5.getClass();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 32 + "'", int12 == 32);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0L + "'", number20.equals(0L));
        org.junit.Assert.assertNull(orderDirection21);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(wildcardClass26);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) (-10), (-104857599), (-1074790275));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-1077965792L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.077965792E9d + "'", double1 == 1.077965792E9d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        double[] doubleArray8 = new double[] {};
        double[] doubleArray14 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray14);
        double[] doubleArray17 = new double[] {};
        double[] doubleArray23 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray23);
        double[] doubleArray25 = new double[] {};
        double[] doubleArray31 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray31);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray23);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection38 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException40 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 10, (java.lang.Number) 2.3260349202281993E-8d, 31, orderDirection38, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23, orderDirection38, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not increasing (39,481,480,091,340.34 > 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection38 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection38.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        long long1 = org.apache.commons.math.util.FastMath.abs(5L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 5L + "'", long1 == 5L);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-86196911), 416);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-812297727) + "'", int2 == (-812297727));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 840, (long) 332);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 278880L + "'", long2 == 278880L);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.3030247335881318d, (double) 40, 0.6610060414837631d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 1077968896, 3500L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 943222784000L + "'", long2 == 943222784000L);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(25, 1032654167);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 1074790270L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        double double1 = org.apache.commons.math.util.FastMath.asin(19.843974440965976d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 132);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 25, 800L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2687396016051259137L + "'", long2 == 2687396016051259137L);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(9.031323778671396d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.082494217160572d + "'", double1 == 2.082494217160572d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-1), (long) (-1074790399));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-0.027181892591221314d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5574077246549023d) + "'", double1 == (-1.5574077246549023d));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        long long1 = org.apache.commons.math.util.FastMath.round(1.414213562373095d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) (short) 0);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (byte) 1);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) (short) 0);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger12);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 1);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) (short) 0);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (long) (byte) 1);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, 0);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger22);
        java.lang.Number number30 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException34 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.0d), number30, (-1074790265), orderDirection32, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException36 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.61728282E9f), (java.lang.Number) 0.9866275920404853d, (-1617282775), orderDirection32, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException38 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger23, (java.lang.Number) (-800446574), 104857599, orderDirection32, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException40 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.1447298858494002d, (java.lang.Number) 25.0d, 0, orderDirection32, false);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertTrue("'" + orderDirection32 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection32.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.4022429844072145d, 3.9512437185814275d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5087646897449714d) + "'", double2 == (-1.5087646897449714d));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(1.568047112528285d, 2042626049);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.13609422505657d + "'", double2 == 3.13609422505657d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-1.048576E8d), 0.5413248546129181d, 0.42543965992489424d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        double double2 = org.apache.commons.math.util.FastMath.atan2(4.644483341943245d, (double) (-1.61728282E9f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.1415926507180116d + "'", double2 == 3.1415926507180116d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-1074790272L), 1.0732178989295803E14d, 3.948148009405236E13d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(33950000L, (long) 10004);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 33939996L + "'", long2 == 33939996L);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (-1074790241L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1024.3331743733581d) + "'", double1 == (-1024.3331743733581d));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        int int2 = org.apache.commons.math.util.MathUtils.pow(97, 10004);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-24551551) + "'", int2 == (-24551551));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-1074790274L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.07479027E9f + "'", float1 == 1.07479027E9f);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-349698017));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.49698018E8d) + "'", double1 == (-3.49698018E8d));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        double double2 = org.apache.commons.math.util.MathUtils.log(54.97787143875179d, 3.1415926507180116d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2856874629382942d + "'", double2 == 0.2856874629382942d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-1991318963), 1.8189894035458565E-12d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963267948966d) + "'", double2 == (-1.5707963267948966d));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 645219164L, (java.lang.Number) 5.777039824101231d, 10);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Class<?> wildcardClass5 = nonMonotonousSequenceException3.getClass();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        double double1 = org.apache.commons.math.util.FastMath.acos(22026.465794806718d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(2.537297501373361d, 0.0d, (double) 3500L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1074790399L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, 4);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-1L), 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 416);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, 1.4210854715202004E-14d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        double double1 = org.apache.commons.math.util.FastMath.sinh(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.548739357257748d + "'", double1 == 11.548739357257748d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-10));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999999958776927d) + "'", double1 == (-0.9999999958776927d));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1074790270L, 2.11387776E9f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.07479027E9f + "'", float2 == 1.07479027E9f);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        float float2 = org.apache.commons.math.util.FastMath.min(3628800.0f, (float) 11585);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 11585.0f + "'", float2 == 11585.0f);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 3628800L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3628800.0d + "'", double1 == 3628800.0d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-1074790347L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(3.94814800913388E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.9481480091338805E13d + "'", double1 == 3.9481480091338805E13d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-1074790300));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        double[] doubleArray8 = new double[] {};
        double[] doubleArray14 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray14);
        double[] doubleArray17 = new double[] {};
        double[] doubleArray23 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray23);
        double[] doubleArray25 = new double[] {};
        double[] doubleArray31 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray31);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray23);
        double[] doubleArray35 = null;
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray35);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        int int2 = org.apache.commons.math.util.FastMath.max(11585, 1074790399);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1074790399 + "'", int2 == 1074790399);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        int int1 = org.apache.commons.math.util.MathUtils.sign(332);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(3.948148009133937E13d, 0.3187475604206444d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        double[] doubleArray5 = new double[] { 4.9E-324d, (-1.5707963258644826d), 2.47859127706984d, (-0.15051499783199057d), (-1074790270L) };
        double[] doubleArray6 = null;
        double[] doubleArray7 = new double[] {};
        double[] doubleArray13 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray7);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray7);
        double[] doubleArray17 = new double[] {};
        double[] doubleArray23 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray7, doubleArray17);
        double[] doubleArray26 = new double[] {};
        double[] doubleArray32 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray32);
        double[] doubleArray34 = new double[] {};
        double[] doubleArray40 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray40);
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray40);
        double[] doubleArray43 = new double[] {};
        double[] doubleArray49 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray43, doubleArray49);
        double[] doubleArray51 = new double[] {};
        double[] doubleArray57 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray51, doubleArray57);
        double double59 = org.apache.commons.math.util.MathUtils.distance1(doubleArray49, doubleArray57);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray49);
        double[] doubleArray61 = null;
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray61);
        double[] doubleArray63 = new double[] {};
        double[] doubleArray69 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray63, doubleArray69);
        int int71 = org.apache.commons.math.util.MathUtils.hash(doubleArray63);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray63);
        double[] doubleArray73 = new double[] {};
        double[] doubleArray79 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray73, doubleArray79);
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray79);
        double double82 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray79);
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray79);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (0 >= -1.571)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-0.1494681981443936d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.002608712184642947d) + "'", double1 == (-0.002608712184642947d));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int[] intArray2 = null;
        double double3 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray2);
        int int4 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray2);
        int[] intArray10 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray17 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int18 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray17);
        int[] intArray24 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray31 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int32 = org.apache.commons.math.util.MathUtils.distanceInf(intArray24, intArray31);
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray31);
        int int34 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray10);
        int[] intArray40 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray47 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int48 = org.apache.commons.math.util.MathUtils.distanceInf(intArray40, intArray47);
        int int49 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray47);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 100 + "'", int18 == 100);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 100 + "'", int32 == 100);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 331 + "'", int33 == 331);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 100 + "'", int48 == 100);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 1661992960);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963261932094d + "'", double1 == 1.5707963261932094d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(619996103, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 619996103L + "'", long2 == 619996103L);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(2042626049, (int) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 958.3892720340863d + "'", double2 == 958.3892720340863d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, (long) 10004);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 10, 1074791115);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1074791115, 331);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1074791446 + "'", int2 == 1074791446);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (short) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 56628L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.637406022152295d + "'", double1 == 11.637406022152295d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.9866275920404853d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5275028665387276d + "'", double1 == 1.5275028665387276d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) '#', (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1995483777 + "'", int2 == 1995483777);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.10336039907518849d, (double) 331, 2.154434690031884d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 1077968896);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-1617282775));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(104L, (-1991318963));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        double double1 = org.apache.commons.math.util.FastMath.asinh(15.622542110419388d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.4428848108309165d + "'", double1 == 3.4428848108309165d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException5.getDirection();
        java.lang.Throwable[] throwableArray12 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number13 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0L + "'", number7.equals(0L));
        org.junit.Assert.assertNull(orderDirection8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNull(orderDirection10);
        org.junit.Assert.assertNull(orderDirection11);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0L + "'", number13.equals(0L));
        org.junit.Assert.assertNull(orderDirection14);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        double double2 = org.apache.commons.math.util.FastMath.atan2(19.998055071752454d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.5413248546129181d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 3500.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3500.0000000000005d + "'", double1 == 3500.0000000000005d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (-37617659625L), (double) 1424488560);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.761765962499999E10d) + "'", double2 == (-3.761765962499999E10d));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 10000);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-86196911), (-104857600));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-191054511) + "'", int2 == (-191054511));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        int int2 = org.apache.commons.math.util.FastMath.min((-183792213), 645219163);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-183792213) + "'", int2 == (-183792213));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(10000, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10000 + "'", int2 == 10000);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.49536728921867335d, (java.lang.Number) 1, 0);
        boolean boolean11 = nonMonotonousSequenceException10.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection15, false);
        java.lang.Throwable[] throwableArray18 = nonMonotonousSequenceException17.getSuppressed();
        java.lang.Number number19 = nonMonotonousSequenceException17.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = nonMonotonousSequenceException17.getDirection();
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = nonMonotonousSequenceException17.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = nonMonotonousSequenceException17.getDirection();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        java.lang.Throwable[] throwableArray25 = nonMonotonousSequenceException17.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 0L + "'", number19.equals(0L));
        org.junit.Assert.assertNull(orderDirection20);
        org.junit.Assert.assertNull(orderDirection22);
        org.junit.Assert.assertNull(orderDirection23);
        org.junit.Assert.assertNotNull(throwableArray25);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) (-1991318963));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.99131891E9f) + "'", float2 == (-1.99131891E9f));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(0, (-10));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        double double1 = org.apache.commons.math.util.FastMath.sinh(2.082494217160572d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.9499198598577956d + "'", double1 == 3.9499198598577956d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1074791446, (-1617282775));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-2113877735L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(5);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 120.0d + "'", double1 == 120.0d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((-33.57050010464278d), (double) 32);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 29.26135296715308d + "'", double2 == 29.26135296715308d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        int int1 = org.apache.commons.math.util.MathUtils.sign(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int[] intArray2 = null;
        double double3 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray2);
        int int4 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray2);
        int[] intArray5 = null;
        int int6 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray5);
        int[] intArray7 = new int[] {};
        int[] intArray8 = new int[] {};
        int[] intArray9 = null;
        double double10 = org.apache.commons.math.util.MathUtils.distance(intArray8, intArray9);
        int int11 = org.apache.commons.math.util.MathUtils.distanceInf(intArray7, intArray9);
        int[] intArray17 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray24 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray24);
        int[] intArray31 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray38 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int39 = org.apache.commons.math.util.MathUtils.distanceInf(intArray31, intArray38);
        int int40 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray38);
        int int41 = org.apache.commons.math.util.MathUtils.distanceInf(intArray7, intArray17);
        int[] intArray47 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray54 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int55 = org.apache.commons.math.util.MathUtils.distanceInf(intArray47, intArray54);
        int[] intArray61 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray68 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int69 = org.apache.commons.math.util.MathUtils.distanceInf(intArray61, intArray68);
        int int70 = org.apache.commons.math.util.MathUtils.distance1(intArray47, intArray68);
        int int71 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray47);
        try {
            double double72 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 100 + "'", int25 == 100);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 100 + "'", int39 == 100);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 331 + "'", int40 == 331);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 100 + "'", int55 == 100);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 100 + "'", int69 == 100);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 331 + "'", int70 == 331);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, (double) 1089L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-0.6156264703860141d), 5.794493116621174d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.615626470386014d) + "'", double2 == (-0.615626470386014d));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 10000);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, (double) 97);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        double[] doubleArray8 = new double[] {};
        double[] doubleArray14 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray14);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        double[] doubleArray18 = new double[] {};
        double[] doubleArray24 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray24);
        double[] doubleArray26 = new double[] {};
        double[] doubleArray32 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray32);
        double[] doubleArray35 = new double[] {};
        double[] doubleArray41 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray35, doubleArray41);
        double[] doubleArray43 = new double[] {};
        double[] doubleArray49 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray43, doubleArray49);
        double double51 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray49);
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray41);
        double[] doubleArray53 = null;
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray53);
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray14, doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1617282775) + "'", int17 == (-1617282775));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 33950000L, (double) 56628L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        double double1 = org.apache.commons.math.util.FastMath.log10(5.794493116621174d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.763015451294864d + "'", double1 == 0.763015451294864d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-800446574), (long) (-2125203712));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-1074790275));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.074790276E9d) + "'", double1 == (-1.074790276E9d));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (short) 10, 874479555);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-191054511));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 32, (int) '4');
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) (short) 0);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (byte) 1);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) (short) 0);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger12);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 1);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) (short) 0);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (long) (byte) 1);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, 0);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger22);
        java.lang.Number number30 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException34 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.0d), number30, (-1074790265), orderDirection32, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException36 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.61728282E9f), (java.lang.Number) 0.9866275920404853d, (-1617282775), orderDirection32, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException38 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger23, (java.lang.Number) (-800446574), 104857599, orderDirection32, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException40 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-2L), (java.lang.Number) (byte) 1, 840, orderDirection32, true);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertTrue("'" + orderDirection32 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection32.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 2.0f, 2.8421709430404007E-14d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.8421709430404007E-14d + "'", double2 == 2.8421709430404007E-14d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 10L, 3500.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3500.0f + "'", float2 == 3500.0f);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) (-1074790272));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (byte) 1);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 1);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) (short) 0);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) (byte) 1);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 0);
        java.math.BigInteger bigInteger20 = null;
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) (short) 0);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, bigInteger22);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger23);
        java.math.BigInteger bigInteger25 = null;
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, (long) (short) 0);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (long) (byte) 1);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 0);
        java.math.BigInteger bigInteger32 = null;
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, (long) (short) 0);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, bigInteger34);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 1);
        java.math.BigInteger bigInteger38 = null;
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, (long) (short) 0);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, (long) (byte) 1);
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, 0);
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, bigInteger44);
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, bigInteger37);
        java.math.BigInteger bigInteger47 = null;
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger47, (long) (short) 0);
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger49, (long) (byte) 1);
        java.math.BigInteger bigInteger53 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, 0);
        java.math.BigInteger bigInteger54 = null;
        java.math.BigInteger bigInteger56 = org.apache.commons.math.util.MathUtils.pow(bigInteger54, (long) (short) 0);
        java.math.BigInteger bigInteger57 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, bigInteger56);
        java.math.BigInteger bigInteger59 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, 1);
        java.math.BigInteger bigInteger60 = null;
        java.math.BigInteger bigInteger62 = org.apache.commons.math.util.MathUtils.pow(bigInteger60, (long) (short) 0);
        java.math.BigInteger bigInteger64 = org.apache.commons.math.util.MathUtils.pow(bigInteger62, (long) (byte) 1);
        java.math.BigInteger bigInteger66 = org.apache.commons.math.util.MathUtils.pow(bigInteger64, 0);
        java.math.BigInteger bigInteger67 = null;
        java.math.BigInteger bigInteger69 = org.apache.commons.math.util.MathUtils.pow(bigInteger67, (long) (short) 0);
        java.math.BigInteger bigInteger70 = org.apache.commons.math.util.MathUtils.pow(bigInteger64, bigInteger69);
        java.math.BigInteger bigInteger71 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, bigInteger70);
        java.lang.Class<?> wildcardClass72 = bigInteger71.getClass();
        java.math.BigInteger bigInteger73 = org.apache.commons.math.util.MathUtils.pow(bigInteger46, bigInteger71);
        java.math.BigInteger bigInteger75 = org.apache.commons.math.util.MathUtils.pow(bigInteger71, 1077968896);
        java.math.BigInteger bigInteger77 = org.apache.commons.math.util.MathUtils.pow(bigInteger71, 1424488560);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger49);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger53);
        org.junit.Assert.assertNotNull(bigInteger56);
        org.junit.Assert.assertNotNull(bigInteger57);
        org.junit.Assert.assertNotNull(bigInteger59);
        org.junit.Assert.assertNotNull(bigInteger62);
        org.junit.Assert.assertNotNull(bigInteger64);
        org.junit.Assert.assertNotNull(bigInteger66);
        org.junit.Assert.assertNotNull(bigInteger69);
        org.junit.Assert.assertNotNull(bigInteger70);
        org.junit.Assert.assertNotNull(bigInteger71);
        org.junit.Assert.assertNotNull(wildcardClass72);
        org.junit.Assert.assertNotNull(bigInteger73);
        org.junit.Assert.assertNotNull(bigInteger75);
        org.junit.Assert.assertNotNull(bigInteger77);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (short) 100, 0.7945982305639963d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        double[] doubleArray8 = new double[] {};
        double[] doubleArray14 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray14);
        double[] doubleArray17 = new double[] {};
        double[] doubleArray23 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray23);
        double[] doubleArray25 = new double[] {};
        double[] doubleArray31 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray31);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray23);
        double[] doubleArray35 = null;
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray35);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        java.lang.Number number39 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection41 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException43 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.0d), number39, (-1074790265), orderDirection41, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14, orderDirection41, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (39,481,480,091,340.34 >= 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1617282775) + "'", int37 == (-1617282775));
        org.junit.Assert.assertTrue("'" + orderDirection41 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection41.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray7 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray7);
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray1);
        int int10 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray11 = new double[] {};
        double[] doubleArray17 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray11);
        double[] doubleArray20 = new double[] {};
        double[] doubleArray26 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray26);
        double[] doubleArray28 = new double[] {};
        double[] doubleArray34 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray34);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray34);
        double[] doubleArray37 = new double[] {};
        double[] doubleArray43 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray37, doubleArray43);
        double[] doubleArray45 = new double[] {};
        double[] doubleArray51 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray43, doubleArray51);
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray43);
        double[] doubleArray55 = null;
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray55);
        double[] doubleArray57 = new double[] {};
        double[] doubleArray63 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray57, doubleArray63);
        int int65 = org.apache.commons.math.util.MathUtils.hash(doubleArray57);
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray57);
        double[] doubleArray67 = new double[] {};
        double[] doubleArray73 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray67, doubleArray73);
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray73);
        double double76 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray73);
        java.lang.Class<?> wildcardClass77 = doubleArray73.getClass();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass77);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        float float1 = org.apache.commons.math.util.FastMath.abs(Float.NaN);
        org.junit.Assert.assertEquals((float) float1, Float.NaN, 0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 416, 6.19996103E8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 100L, (float) 10L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        double double2 = org.apache.commons.math.util.FastMath.max((-3.4485442308546683d), (double) (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 10004);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-9.128556195892921d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-9.12855619589292d) + "'", double1 == (-9.12855619589292d));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) -1, (float) 3);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.0f + "'", float2 == 3.0f);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        int int2 = org.apache.commons.math.util.FastMath.min(97, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-2125203721), 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-2.12520384E9f) + "'", float2 == (-2.12520384E9f));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        int[] intArray0 = new int[] {};
        int[] intArray1 = null;
        double double2 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray1);
        int[] intArray8 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray15 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray8, intArray15);
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray8);
        int[] intArray23 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray30 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int31 = org.apache.commons.math.util.MathUtils.distanceInf(intArray23, intArray30);
        int[] intArray37 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray44 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int45 = org.apache.commons.math.util.MathUtils.distanceInf(intArray37, intArray44);
        int int46 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray44);
        int int47 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray23);
        int[] intArray48 = new int[] {};
        int[] intArray49 = new int[] {};
        int[] intArray50 = null;
        double double51 = org.apache.commons.math.util.MathUtils.distance(intArray49, intArray50);
        int int52 = org.apache.commons.math.util.MathUtils.distanceInf(intArray48, intArray50);
        int[] intArray53 = new int[] {};
        int[] intArray54 = new int[] {};
        int[] intArray55 = null;
        double double56 = org.apache.commons.math.util.MathUtils.distance(intArray54, intArray55);
        int int57 = org.apache.commons.math.util.MathUtils.distanceInf(intArray53, intArray55);
        int[] intArray63 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray70 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int71 = org.apache.commons.math.util.MathUtils.distanceInf(intArray63, intArray70);
        int[] intArray77 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray84 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int85 = org.apache.commons.math.util.MathUtils.distanceInf(intArray77, intArray84);
        int int86 = org.apache.commons.math.util.MathUtils.distance1(intArray63, intArray84);
        int int87 = org.apache.commons.math.util.MathUtils.distanceInf(intArray53, intArray63);
        double double88 = org.apache.commons.math.util.MathUtils.distance(intArray48, intArray53);
        int int89 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray53);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 100 + "'", int31 == 100);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 100 + "'", int45 == 100);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 331 + "'", int46 == 331);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 100 + "'", int71 == 100);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertNotNull(intArray84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 100 + "'", int85 == 100);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 331 + "'", int86 == 331);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 0 + "'", int87 == 0);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 0 + "'", int89 == 0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        double double2 = org.apache.commons.math.util.MathUtils.log(403.4287934927351d, (-0.002608712184642947d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(2L, (long) (-1617282775));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1617282777L + "'", long2 == 1617282777L);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 24, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24L + "'", long2 == 24L);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(13.962634015954636d, (-0.615626470386014d), (double) (-2L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(3.948148009134034E13d, 1.0000000000000002d, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(559939585, 1074790399);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.0d, (int) (byte) 100, 24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.5413248546129181d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-1074790241L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 1077968896, 1074790301L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1158590514200477696L + "'", long2 == 1158590514200477696L);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        double[] doubleArray8 = new double[] {};
        double[] doubleArray14 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray14);
        double[] doubleArray17 = new double[] {};
        double[] doubleArray23 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray23);
        double[] doubleArray25 = new double[] {};
        double[] doubleArray31 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray31);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray23);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) 32L);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        double[] doubleArray38 = null;
        double[] doubleArray39 = new double[] {};
        double[] doubleArray45 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray45);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray38, doubleArray39);
        int int48 = org.apache.commons.math.util.MathUtils.hash(doubleArray39);
        double[] doubleArray49 = new double[] {};
        double[] doubleArray55 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray49, doubleArray55);
        double[] doubleArray57 = new double[] {};
        double[] doubleArray63 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray57, doubleArray63);
        double double65 = org.apache.commons.math.util.MathUtils.distance1(doubleArray55, doubleArray63);
        double[] doubleArray66 = new double[] {};
        double[] doubleArray72 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray66, doubleArray72);
        double[] doubleArray74 = new double[] {};
        double[] doubleArray80 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray74, doubleArray80);
        double double82 = org.apache.commons.math.util.MathUtils.distance1(doubleArray72, doubleArray80);
        double double83 = org.apache.commons.math.util.MathUtils.distance1(doubleArray63, doubleArray72);
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equals(doubleArray39, doubleArray72);
        boolean boolean85 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray39);
        double[] doubleArray86 = null;
        boolean boolean87 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1617282775) + "'", int37 == (-1617282775));
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        double double2 = org.apache.commons.math.util.FastMath.min(1.0d, 3.6894126896682486E7d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(5, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        double double1 = org.apache.commons.math.util.FastMath.cos(28.982753492378876d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7593910800345889d) + "'", double1 == (-0.7593910800345889d));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        double[] doubleArray8 = new double[] {};
        double[] doubleArray14 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray14);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1617282775) + "'", int17 == (-1617282775));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 3.948148009134034E13d + "'", double18 == 3.948148009134034E13d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        double[] doubleArray8 = new double[] {};
        double[] doubleArray14 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray14);
        double[] doubleArray17 = new double[] {};
        double[] doubleArray23 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray23);
        double[] doubleArray25 = new double[] {};
        double[] doubleArray31 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray31);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray23);
        double[] doubleArray35 = null;
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray35);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        java.lang.Class<?> wildcardClass38 = doubleArray14.getClass();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1617282775) + "'", int37 == (-1617282775));
        org.junit.Assert.assertNotNull(wildcardClass38);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (byte) 1);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 840);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 132);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 132, (java.lang.Number) 3500L, (int) (byte) -1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection21, false);
        java.lang.Throwable[] throwableArray24 = nonMonotonousSequenceException23.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection28, false);
        java.lang.Number number31 = nonMonotonousSequenceException30.getArgument();
        nonMonotonousSequenceException23.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException30);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection33 = nonMonotonousSequenceException30.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection37 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException39 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection37, false);
        java.lang.Throwable[] throwableArray40 = nonMonotonousSequenceException39.getSuppressed();
        java.lang.Number number41 = nonMonotonousSequenceException39.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection42 = nonMonotonousSequenceException39.getDirection();
        java.lang.Throwable[] throwableArray43 = nonMonotonousSequenceException39.getSuppressed();
        nonMonotonousSequenceException30.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException39);
        nonMonotonousSequenceException17.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException39);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 0L + "'", number31.equals(0L));
        org.junit.Assert.assertNull(orderDirection33);
        org.junit.Assert.assertNotNull(throwableArray40);
        org.junit.Assert.assertTrue("'" + number41 + "' != '" + 0L + "'", number41.equals(0L));
        org.junit.Assert.assertNull(orderDirection42);
        org.junit.Assert.assertNotNull(throwableArray43);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 645219163);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        long long1 = org.apache.commons.math.util.MathUtils.sign(645219164L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, 11585);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        double[] doubleArray8 = null;
        double[] doubleArray9 = new double[] {};
        double[] doubleArray15 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray15);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray9);
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray9);
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        double[] doubleArray20 = new double[] {};
        double[] doubleArray26 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray26);
        double[] doubleArray28 = new double[] {};
        double[] doubleArray34 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray34);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray34);
        double double37 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray9, doubleArray34);
        double[] doubleArray39 = new double[] {};
        double[] doubleArray45 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray45);
        double[] doubleArray47 = new double[] {};
        double[] doubleArray53 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray47, doubleArray53);
        double double55 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray53);
        int int56 = org.apache.commons.math.util.MathUtils.hash(doubleArray53);
        double[] doubleArray57 = new double[] {};
        double[] doubleArray63 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray57, doubleArray63);
        double[] doubleArray65 = new double[] {};
        double[] doubleArray71 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray65, doubleArray71);
        double double73 = org.apache.commons.math.util.MathUtils.distance1(doubleArray63, doubleArray71);
        double[] doubleArray74 = new double[] {};
        double[] doubleArray80 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray74, doubleArray80);
        double[] doubleArray82 = new double[] {};
        double[] doubleArray88 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean89 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray82, doubleArray88);
        double double90 = org.apache.commons.math.util.MathUtils.distance1(doubleArray80, doubleArray88);
        double double91 = org.apache.commons.math.util.MathUtils.distance1(doubleArray71, doubleArray80);
        double[] doubleArray93 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray71, (double) 32L);
        double double94 = org.apache.commons.math.util.MathUtils.distance(doubleArray53, doubleArray71);
        boolean boolean95 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray71);
        double double96 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray71);
        int int97 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 3.948148009134034E13d + "'", double37 == 3.948148009134034E13d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1617282775) + "'", int56 == (-1617282775));
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 0.0d + "'", double94 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 0.0d + "'", double96 == 0.0d);
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + (-1617282775) + "'", int97 == (-1617282775));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        java.lang.Number number7 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.0d), number7, (-1074790265), orderDirection9, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.61728282E9f), (java.lang.Number) 0.9866275920404853d, (-1617282775), orderDirection9, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.POSITIVE_INFINITY, (java.lang.Number) (-1617282775), 1424488560, orderDirection9, false);
        java.lang.String str16 = nonMonotonousSequenceException15.toString();
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 1,424,488,559 and 1,424,488,560 are not increasing (-1,617,282,775 > ∞)" + "'", str16.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 1,424,488,559 and 1,424,488,560 are not increasing (-1,617,282,775 > ∞)"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.49536728921867335d, (java.lang.Number) 1, 0);
        java.lang.Number number7 = nonMonotonousSequenceException6.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection11, false);
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException13.getSuppressed();
        java.lang.Number number15 = nonMonotonousSequenceException13.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = nonMonotonousSequenceException13.getDirection();
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException13.getSuppressed();
        java.lang.Number number18 = nonMonotonousSequenceException13.getPrevious();
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 0L, 0, orderDirection20, true);
        java.lang.Number number23 = nonMonotonousSequenceException22.getPrevious();
        java.lang.Number number24 = nonMonotonousSequenceException22.getArgument();
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0.49536728921867335d + "'", number7.equals(0.49536728921867335d));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 0L + "'", number15.equals(0L));
        org.junit.Assert.assertNull(orderDirection16);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (byte) -1 + "'", number18.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection20.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0L + "'", number23.equals(0L));
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (short) 0 + "'", number24.equals((short) 0));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.49536728921867335d, (java.lang.Number) 1, 0);
        boolean boolean12 = nonMonotonousSequenceException11.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection16, false);
        java.lang.Throwable[] throwableArray19 = nonMonotonousSequenceException18.getSuppressed();
        java.lang.Number number20 = nonMonotonousSequenceException18.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = nonMonotonousSequenceException18.getDirection();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        java.lang.Throwable[] throwableArray24 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0L + "'", number6.equals(0L));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (byte) -1 + "'", number7.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0L + "'", number20.equals(0L));
        org.junit.Assert.assertNull(orderDirection21);
        org.junit.Assert.assertNotNull(throwableArray24);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(3L, 97L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, 1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((-191054511), (-191054511));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 191054511 + "'", int2 == 191054511);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        double[] doubleArray8 = new double[] {};
        double[] doubleArray14 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray14);
        double[] doubleArray17 = new double[] {};
        double[] doubleArray23 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray23);
        double[] doubleArray25 = new double[] {};
        double[] doubleArray31 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray31);
        double[] doubleArray34 = new double[] {};
        double[] doubleArray40 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray40);
        double[] doubleArray42 = new double[] {};
        double[] doubleArray48 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray42, doubleArray48);
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray48);
        double double51 = org.apache.commons.math.util.MathUtils.distance1(doubleArray31, doubleArray40);
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray31);
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, 0.221357926205738d);
        double[] doubleArray55 = null;
        double[] doubleArray56 = new double[] {};
        double[] doubleArray62 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray56, doubleArray62);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray55, doubleArray56);
        int int65 = org.apache.commons.math.util.MathUtils.hash(doubleArray56);
        double[] doubleArray66 = new double[] {};
        double[] doubleArray72 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray66, doubleArray72);
        double double74 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray56, doubleArray66);
        double double75 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray66);
        try {
            double double76 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray66);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        double[] doubleArray8 = new double[] {};
        double[] doubleArray14 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray14);
        double[] doubleArray17 = new double[] {};
        double[] doubleArray23 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray23);
        double[] doubleArray25 = new double[] {};
        double[] doubleArray31 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray31);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray23);
        double[] doubleArray41 = new double[] { 0.7853981633974483d, 1.5430806348152437d, (byte) 1, 100.0f, 33.0d, (byte) 0 };
        double double42 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray41);
        double[] doubleArray43 = null;
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray43);
        double[] doubleArray45 = new double[] {};
        double[] doubleArray51 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray51);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 3.94814800913388E13d + "'", double42 == 3.94814800913388E13d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-2125203712), (-1077965792L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1047237920L) + "'", long2 == (-1047237920L));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) 1, (-1074790274L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((-1903521260), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-183792213), 559939585);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 100, (long) 132);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        double[] doubleArray8 = new double[] {};
        double[] doubleArray14 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray14);
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        double[] doubleArray18 = new double[] {};
        double[] doubleArray24 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray24);
        double[] doubleArray26 = new double[] {};
        double[] doubleArray32 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray32);
        double[] doubleArray35 = new double[] {};
        double[] doubleArray41 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray35, doubleArray41);
        double[] doubleArray43 = new double[] {};
        double[] doubleArray49 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray43, doubleArray49);
        double double51 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray49);
        double[] doubleArray52 = new double[] {};
        double[] doubleArray58 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray52, doubleArray58);
        double[] doubleArray60 = new double[] {};
        double[] doubleArray66 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray60, doubleArray66);
        double double68 = org.apache.commons.math.util.MathUtils.distance1(doubleArray58, doubleArray66);
        double double69 = org.apache.commons.math.util.MathUtils.distance1(doubleArray49, doubleArray58);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray58);
        double[] doubleArray72 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (-0.44812751321749233d));
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray72);
        double[] doubleArray75 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) 645219163);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 3.948148009134034E13d + "'", double17 == 3.948148009134034E13d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(doubleArray75);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) (short) 0);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) (byte) 1);
        java.math.BigInteger bigInteger6 = null;
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) (byte) 1);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) (byte) 100);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger14);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.4428848108309165d, (java.lang.Number) bigInteger15, (-1074790399), orderDirection17, true);
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(4.607527216071292E-31d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray7 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray7);
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray1);
        int int10 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double double11 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray12 = new double[] {};
        double[] doubleArray18 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray18);
        double[] doubleArray20 = new double[] {};
        double[] doubleArray26 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray26);
        double double29 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray26);
        double[] doubleArray31 = new double[] {};
        double[] doubleArray37 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray37);
        double[] doubleArray39 = new double[] {};
        double[] doubleArray45 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray45);
        double double47 = org.apache.commons.math.util.MathUtils.distance1(doubleArray37, doubleArray45);
        int int48 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double[] doubleArray49 = new double[] {};
        double[] doubleArray55 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray49, doubleArray55);
        double[] doubleArray57 = new double[] {};
        double[] doubleArray63 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray57, doubleArray63);
        double double65 = org.apache.commons.math.util.MathUtils.distance1(doubleArray55, doubleArray63);
        double[] doubleArray66 = new double[] {};
        double[] doubleArray72 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray66, doubleArray72);
        double[] doubleArray74 = new double[] {};
        double[] doubleArray80 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray74, doubleArray80);
        double double82 = org.apache.commons.math.util.MathUtils.distance1(doubleArray72, doubleArray80);
        double double83 = org.apache.commons.math.util.MathUtils.distance1(doubleArray63, doubleArray72);
        double[] doubleArray85 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray63, (double) 32L);
        double double86 = org.apache.commons.math.util.MathUtils.distance(doubleArray45, doubleArray63);
        boolean boolean87 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray63);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray63);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (39,481,480,091,340.34 >= 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 3.948148009134034E13d + "'", double29 == 3.948148009134034E13d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1617282775) + "'", int48 == (-1617282775));
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        double double1 = org.apache.commons.math.util.FastMath.asinh(2.993222846126381d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8163011535675582d + "'", double1 == 1.8163011535675582d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        int[] intArray4 = new int[] { 1, (byte) -1, (-349698017), (-1074790400) };
        int[] intArray5 = new int[] {};
        int[] intArray6 = null;
        double double7 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray6);
        int[] intArray8 = null;
        int int9 = org.apache.commons.math.util.MathUtils.distanceInf(intArray5, intArray8);
        int[] intArray15 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray22 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int23 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray22);
        int[] intArray29 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray36 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int37 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray36);
        int int38 = org.apache.commons.math.util.MathUtils.distance1(intArray15, intArray36);
        double double39 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray36);
        int int40 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray36);
        int[] intArray41 = new int[] {};
        int[] intArray42 = new int[] {};
        int[] intArray43 = null;
        double double44 = org.apache.commons.math.util.MathUtils.distance(intArray42, intArray43);
        int int45 = org.apache.commons.math.util.MathUtils.distanceInf(intArray41, intArray43);
        int[] intArray51 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray58 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int59 = org.apache.commons.math.util.MathUtils.distanceInf(intArray51, intArray58);
        int[] intArray65 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray72 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int73 = org.apache.commons.math.util.MathUtils.distanceInf(intArray65, intArray72);
        int[] intArray79 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray86 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int87 = org.apache.commons.math.util.MathUtils.distanceInf(intArray79, intArray86);
        int int88 = org.apache.commons.math.util.MathUtils.distanceInf(intArray65, intArray86);
        int int89 = org.apache.commons.math.util.MathUtils.distance1(intArray58, intArray86);
        java.lang.Class<?> wildcardClass90 = intArray58.getClass();
        int int91 = org.apache.commons.math.util.MathUtils.distance1(intArray41, intArray58);
        int int92 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray58);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 100 + "'", int37 == 100);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 331 + "'", int38 == 331);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1424488560 + "'", int40 == 1424488560);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 100 + "'", int59 == 100);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 100 + "'", int73 == 100);
        org.junit.Assert.assertNotNull(intArray79);
        org.junit.Assert.assertNotNull(intArray86);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 100 + "'", int87 == 100);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 100 + "'", int88 == 100);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 0 + "'", int89 == 0);
        org.junit.Assert.assertNotNull(wildcardClass90);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 0 + "'", int91 == 0);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 1424488560 + "'", int92 == 1424488560);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        int int1 = org.apache.commons.math.util.FastMath.abs(32);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 33L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 33.00000000000001d + "'", double1 == 33.00000000000001d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-349698017));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 349698017L + "'", long1 == 349698017L);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        boolean boolean9 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0L + "'", number7.equals(0L));
        org.junit.Assert.assertNull(orderDirection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 1, (java.lang.Number) 0.7407750251209115d, 1074790300);
        java.lang.Class<?> wildcardClass4 = nonMonotonousSequenceException3.getClass();
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        double double1 = org.apache.commons.math.util.FastMath.floor((-0.9707928525119764d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1074790300);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.07479027E9f + "'", float1 == 1.07479027E9f);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        int[] intArray5 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray12 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int13 = org.apache.commons.math.util.MathUtils.distanceInf(intArray5, intArray12);
        int[] intArray14 = new int[] {};
        int[] intArray15 = new int[] {};
        int[] intArray16 = null;
        double double17 = org.apache.commons.math.util.MathUtils.distance(intArray15, intArray16);
        int int18 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray16);
        int[] intArray19 = new int[] {};
        int[] intArray20 = new int[] {};
        int[] intArray21 = null;
        double double22 = org.apache.commons.math.util.MathUtils.distance(intArray20, intArray21);
        int int23 = org.apache.commons.math.util.MathUtils.distanceInf(intArray19, intArray21);
        int[] intArray29 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray36 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int37 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray36);
        int[] intArray43 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray50 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int51 = org.apache.commons.math.util.MathUtils.distanceInf(intArray43, intArray50);
        int int52 = org.apache.commons.math.util.MathUtils.distance1(intArray29, intArray50);
        int int53 = org.apache.commons.math.util.MathUtils.distanceInf(intArray19, intArray29);
        double double54 = org.apache.commons.math.util.MathUtils.distance(intArray14, intArray19);
        try {
            int int55 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray19);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 100 + "'", int37 == 100);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 100 + "'", int51 == 100);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 331 + "'", int52 == 331);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 800);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-0.8506921561246407d), 3.0d, 5.805134968916488d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.0d, (java.lang.Number) (-0.30005830960817476d), (-2147483648));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, (-0.29136597282280424d));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 25);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.600244966869294E10d + "'", double1 == 3.600244966869294E10d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 559939585, (-2125203721));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.473814720414451d, (double) (-1074790400L));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.5713088006770572d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2535185681421146d + "'", double1 == 1.2535185681421146d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.0d, (-86196911));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (byte) -1, (int) ' ', orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number10 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0L + "'", number7.equals(0L));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0L + "'", number10.equals(0L));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        int[] intArray0 = new int[] {};
        int[] intArray1 = null;
        double double2 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray1);
        int[] intArray3 = null;
        int int4 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray3);
        int[] intArray10 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray17 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int18 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray17);
        int[] intArray24 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray31 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int32 = org.apache.commons.math.util.MathUtils.distanceInf(intArray24, intArray31);
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray31);
        double double34 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray31);
        int[] intArray35 = new int[] {};
        int[] intArray36 = null;
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray35, intArray36);
        int[] intArray43 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray50 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int51 = org.apache.commons.math.util.MathUtils.distanceInf(intArray43, intArray50);
        int int52 = org.apache.commons.math.util.MathUtils.distanceInf(intArray35, intArray43);
        int[] intArray58 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray65 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int66 = org.apache.commons.math.util.MathUtils.distanceInf(intArray58, intArray65);
        int[] intArray72 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray79 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int80 = org.apache.commons.math.util.MathUtils.distanceInf(intArray72, intArray79);
        int int81 = org.apache.commons.math.util.MathUtils.distance1(intArray58, intArray79);
        int int82 = org.apache.commons.math.util.MathUtils.distance1(intArray35, intArray58);
        try {
            double double83 = org.apache.commons.math.util.MathUtils.distance(intArray31, intArray35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 100 + "'", int18 == 100);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 100 + "'", int32 == 100);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 331 + "'", int33 == 331);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 100 + "'", int51 == 100);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 100 + "'", int66 == 100);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertNotNull(intArray79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 100 + "'", int80 == 100);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 331 + "'", int81 == 331);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int[] intArray2 = null;
        double double3 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray2);
        int int4 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray2);
        int[] intArray10 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray17 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int18 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray17);
        int[] intArray24 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray31 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int32 = org.apache.commons.math.util.MathUtils.distanceInf(intArray24, intArray31);
        int[] intArray38 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray45 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int46 = org.apache.commons.math.util.MathUtils.distanceInf(intArray38, intArray45);
        int int47 = org.apache.commons.math.util.MathUtils.distanceInf(intArray24, intArray45);
        int int48 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray45);
        java.lang.Class<?> wildcardClass49 = intArray17.getClass();
        int int50 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray17);
        int[] intArray51 = new int[] {};
        int[] intArray52 = null;
        double double53 = org.apache.commons.math.util.MathUtils.distance(intArray51, intArray52);
        int[] intArray59 = new int[] { 0, (byte) 10, (short) 100, (byte) 0, 0 };
        int[] intArray66 = new int[] { 100, (short) 10, 1, ' ', 100, (byte) 0 };
        int int67 = org.apache.commons.math.util.MathUtils.distanceInf(intArray59, intArray66);
        int int68 = org.apache.commons.math.util.MathUtils.distanceInf(intArray51, intArray59);
        int int69 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray51);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 100 + "'", int18 == 100);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 100 + "'", int32 == 100);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 100 + "'", int46 == 100);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 100 + "'", int47 == 100);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 100 + "'", int67 == 100);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (byte) 1);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger9);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) (short) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) (byte) 1);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 0);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (long) (short) 0);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger20);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 1);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        double double1 = org.apache.commons.math.util.FastMath.tanh(11013.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-1903521260), (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        double[] doubleArray8 = new double[] {};
        double[] doubleArray14 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray14);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        double[] doubleArray18 = new double[] {};
        double[] doubleArray24 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray24);
        double[] doubleArray26 = new double[] {};
        double[] doubleArray32 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray32);
        double[] doubleArray35 = new double[] {};
        double[] doubleArray41 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray35, doubleArray41);
        double[] doubleArray43 = new double[] {};
        double[] doubleArray49 = new double[] { 32, 3.948148009134034E13d, 1.0f, (-0.7853981633974483d), 10.0d };
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray43, doubleArray49);
        double double51 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray49);
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray41);
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) 32L);
        double double55 = org.apache.commons.math.util.MathUtils.distance(doubleArray14, doubleArray32);
        java.math.BigInteger bigInteger56 = null;
        java.math.BigInteger bigInteger58 = org.apache.commons.math.util.MathUtils.pow(bigInteger56, (long) (short) 0);
        java.math.BigInteger bigInteger60 = org.apache.commons.math.util.MathUtils.pow(bigInteger58, (long) (byte) 1);
        java.math.BigInteger bigInteger62 = org.apache.commons.math.util.MathUtils.pow(bigInteger60, 0);
        java.math.BigInteger bigInteger63 = null;
        java.math.BigInteger bigInteger65 = org.apache.commons.math.util.MathUtils.pow(bigInteger63, (long) (short) 0);
        java.math.BigInteger bigInteger66 = org.apache.commons.math.util.MathUtils.pow(bigInteger60, bigInteger65);
        java.math.BigInteger bigInteger68 = org.apache.commons.math.util.MathUtils.pow(bigInteger60, 1);
        java.math.BigInteger bigInteger69 = null;
        java.math.BigInteger bigInteger71 = org.apache.commons.math.util.MathUtils.pow(bigInteger69, (long) (short) 0);
        java.math.BigInteger bigInteger73 = org.apache.commons.math.util.MathUtils.pow(bigInteger71, (long) (byte) 1);
        java.math.BigInteger bigInteger75 = org.apache.commons.math.util.MathUtils.pow(bigInteger73, 0);
        java.math.BigInteger bigInteger76 = org.apache.commons.math.util.MathUtils.pow(bigInteger68, bigInteger75);
        java.lang.Number number83 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection85 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException87 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.0d), number83, (-1074790265), orderDirection85, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException89 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.61728282E9f), (java.lang.Number) 0.9866275920404853d, (-1617282775), orderDirection85, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException91 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger76, (java.lang.Number) (-800446574), 104857599, orderDirection85, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32, orderDirection85, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (39,481,480,091,340.34 >= 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1617282775) + "'", int17 == (-1617282775));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(bigInteger58);
        org.junit.Assert.assertNotNull(bigInteger60);
        org.junit.Assert.assertNotNull(bigInteger62);
        org.junit.Assert.assertNotNull(bigInteger65);
        org.junit.Assert.assertNotNull(bigInteger66);
        org.junit.Assert.assertNotNull(bigInteger68);
        org.junit.Assert.assertNotNull(bigInteger71);
        org.junit.Assert.assertNotNull(bigInteger73);
        org.junit.Assert.assertNotNull(bigInteger75);
        org.junit.Assert.assertNotNull(bigInteger76);
        org.junit.Assert.assertTrue("'" + orderDirection85 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection85.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }
}

